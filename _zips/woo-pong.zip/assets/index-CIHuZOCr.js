var Ms=Object.defineProperty;var $s=(n,t,e)=>t in n?Ms(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var d=(n,t,e)=>$s(n,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function e(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function i(s){if(s.ep)return;s.ep=!0;const o=e(s);fetch(s.href,o)}})();function Ls(n,t){return new Proxy(n,{get(e,i,s){return Reflect.get(e,i,s)},set(e,i,s,o){return Reflect.set(e,i,s,o)}})}function Is(n,t){return new Proxy(n,{get(e,i,s){return Reflect.get(e,i,s)},set(e,i,s,o){return Reflect.set(e,i,s,o)}})}globalThis.__trackObject=Ls;globalThis.__trackArray=Is;const ut={paused:0,normal:2,fast:6,faster:30},yt=10,Rs=30,At=10,ee=1,vt=4,g=1e4,U=1e3,S=3*g,Fe=S*2,Ds=Fe*Fe,J=15e3,Ps=200;function Wi(n){return Math.floor(n*vt/ut.normal/1e3)}const Os=Wi(J),Ht=16*g,Ft=8*g,It=2*g,qi=Math.PI,ot=2*qi,Ts=qi/2;function Bs(n,t,e){const[i,s,o,r]=n;return t>=i&&t<i+o&&e>=s&&e<s+r}function Vt(n,t,e=.5){return n+(t-n)*e}function Hs(n){let t=n.length,e;for(;t>0;)e=Math.floor(Math.random()*t),t--,[n[t],n[e]]=[n[e],n[t]];return n}class Ve{static encode(t){const e=[];return Qi(t,e),e.length%2!==0&&e.push(0),new Int16Array(e)}static decode(t,e){let i=0;for(const s of Zi(e)){const o=t[i++];let r=null;o===0||(r=Array.from({length:e.reg.leafLength},()=>t[i++])),ue(e.tree,s,r)}}}function Qi(n,t){for(const e of n)e===null?t.push(0):typeof e[0]=="number"?(t.push(1),t.push(...e.map(Math.round))):Qi(e,t)}const tt={ROUNDRECT:{url:"luts/roundrect-3a04989ce2b4c222.bin",hash:"3a04989ce2b4c2227254db564fed86759fb2bd0e53dd56047779a7a964906d5d",xRad:145,yRad:61},BREAKOUTBRICK:{url:"luts/breakoutbrick-8cef52cb4168881f.bin",hash:"8cef52cb4168881fc86cfbe3abddefa14a97ae4efb4f19d0055351d067f31ff9",xRad:110,yRad:70},DIAMOND:{url:"luts/diamond-203e5d98315cee8b.bin",hash:"203e5d98315cee8b21b9dffea4d0180c583a091fe7216cda8a86edbdb7abcd65",xRad:83,yRad:83},WEDGE:{url:"luts/wedge-034db30dec516d97.bin",hash:"034db30dec516d97de9045348bcfb48f13ca7a26712ea7804dd153913c0b1182",xRad:232,yRad:80},FLIPPER:{url:"luts/flipper-fde3719c0c331179.bin",hash:"fde3719c0c331179192f87650f3d9649a10880c932d2bae8acbdfa636d7ff772",xRad:286,yRad:97},STAR:{url:"luts/star-1cd3f349bd3a44fa.bin",hash:"1cd3f349bd3a44fa13c7988f6d4bfe0f61a1d768212a9bcc4ea25e9cd6dd545c",xRad:87,yRad:84},PAWN:{url:"luts/pawn-f27b9f61f7e0a41a.bin",hash:"f27b9f61f7e0a41a12fc2aedd0b4957b75b96be94184f9acda4b259086fcb1b1",xRad:78,yRad:94},SHIELD:{url:"luts/shield-b6ac4d69170026d7.bin",hash:"b6ac4d69170026d74a02d428fedc487b77aa1128e2b6b2a88e118dbfbb13d202",xRad:86,yRad:94},MEEPLE:{url:"luts/meeple-2c7595ee765801ea.bin",hash:"2c7595ee765801eae04f1d4ee09473876804b9fb0563c0077cc176248f6d2b5b",xRad:94,yRad:94},CLUB:{url:"luts/club-329f4764d1203380.bin",hash:"329f4764d120338080cdb8836eaf10b82ebf8ab7dc9ff34ce6ef95877e1b6a7d",xRad:94,yRad:94},BISHOP:{url:"luts/bishop-1b60bbee854e4c24.bin",hash:"1b60bbee854e4c24824bbf6af4b9926330d11a741719f29f7cbf0eac0ce43380",xRad:63,yRad:104},BOLT:{url:"luts/bolt-a5d21ced490406cc.bin",hash:"a5d21ced490406cc42a605d29f4014eca6fa3e9fd6be25fb71d9e72ace73a480",xRad:62,yRad:102},AIRPLANE:{url:"luts/airplane-401de1b65fb2edc5.bin",hash:"401de1b65fb2edc5c4ede3b8ead5ad297b45f8427297ec7c8c90890214291929",xRad:76,yRad:111},HEAD:{url:"luts/head-48f8c15dc609200f.bin",hash:"48f8c15dc609200f4bf0c9addea895e7998792cc5e3660846893c410cb0a625c",xRad:84,yRad:90},NOTE:{url:"luts/note-e06ac0a716f5f36a.bin",hash:"e06ac0a716f5f36a66e394768bf24b67b7441300c8729b5172bbbbb38821da0f",xRad:85,yRad:95},DISK_FRICTION_LUT:{url:"luts/disk-friction-lut-9f8e66a2dc70f064.bin",hash:"9f8e66a2dc70f06456c6baf67dd2d922e9b7a846fc266a8de88559b493dffa51"},DISK_DISK_LUT:{url:"luts/disk-disk-lut-e9cd18aa3e3da17a.bin",hash:"e9cd18aa3e3da17a07ed2d5fbe3559e39c81868b0f54a103ec98c96b1210d902"},DISK_NORMAL_LUT:{url:"luts/disk-normal-lut-705377676ab3d42c.bin",hash:"705377676ab3d42cd2e6ffcb1f5c3298f1df3018910f934c553c0ee2096e27de"},RACE_LUT:{url:"luts/race-lut-9af9dfae7a4d4a83.bin",hash:"9af9dfae7a4d4a831eaf262706ce54e9e738b6b47b013df9fce31a9c516e5267"}},st=class st{constructor(){d(this,"name",null);d(this,"reg",null);d(this,"tree",[])}loadFromBlob(t){this.tree.length=0,Ve.decode(t,this)}async loadAll(){const t=await Fs(this.blobUrl,this.blobHash);this.tree.length=0,Ve.decode(t,this)}computeAll(){this.tree.length=0;for(const t of Zi(this)){const e=this.computeLeaf(t);if(e!==null){for(const i of e)if(!Number.isInteger(i))throw new Error(`computed leaf includes non-integer: ${e}`)}ue(this.tree,t,e)}}static register(t,e){if(t in this._registry)throw new Error(`lut already registered: '${t}'`);if(this._registry[t]=e,t==="obstacle-lut")return;const i=e.factory();i.reg=e,i.name=t,this._singletonLuts[t]=i}static create(t,e){if(t==="obstacle-lut"){if(!e)throw new Error("shapeName argument is required to create obstacle-lut");const i=this._registry["obstacle-lut"];if(!i)throw new Error("obstacle-lut not registered");if(!Object.hasOwn(st._obstacleLuts,e)){const{factory:s}=i,o=s();o.reg=i,o.name=t,o.shape=e;const{url:r,hash:a,xRad:l=100,yRad:c=100}=tt[e.toUpperCase()];o.blobUrl=r,o.blobHash=a,o.obsOffsetDetailX=l,o.obsOffsetDetailY=c,o.detail=[o.obsOffsetDetailX*2+1,o.obsOffsetDetailY*2+1],o.maxOffsetX=l*U,o.maxOffsetY=c*U,st._obstacleLuts[e]=o}return st._obstacleLuts[e]}else{if(e)throw new Error("shapeName argument should only be used to create obstacle-lut");if(!Object.hasOwn(this._singletonLuts,t))throw new Error(`singleton lut not registered: ${t}`);return this._singletonLuts[t]}}};d(st,"_registry",{}),d(st,"_singletonLuts",{}),d(st,"_obstacleLuts",{});let _=st;async function Fs(n,t){const e=await fetch(n);if(!e.ok)throw new Error(`Failed to fetch blob: ${e.statusText}`);const i=await e.arrayBuffer();if(!crypto.subtle)console.log("skipping integrity check because crypto.subtle is not available");else if(t){const s=await crypto.subtle.digest("SHA-256",i),r=Array.from(new Uint8Array(s)).map(a=>a.toString(16).padStart(2,"0")).join("");if(r!==t)throw new Error(`Integrity check failed: expected ${t}, got ${r}`)}return new Int16Array(i)}function*Zi(n){const t=n.reg.depth,e=Array.from({length:t},()=>0);for(;;)if(yield[...e],Gi(e,n,e.length-1))return}function ue(n,t,e){if(t.length===0)throw new Error("poop");if(t.length===1){if(n.length!==t[0])throw new Error("poop");n.push(e)}else{for(;n.length<=t[0];)n.push([]);ue(n[t[0]],t.slice(1),e)}}function Gi(n,t,e){const i=n[e]+1;return i>=t.detail[e]?e===0?!0:(n[e]=0,Gi(n,t,e-1)):(n[e]=i,!1)}const Vs=100,Ji=100,Ys=n=>n*ot/Ji,F=20,ts=Vs*F,Ye=n=>Math.floor(n*F/ts),Ne=n=>n*ts/F,we=class we extends _{constructor(){super(...arguments);d(this,"blobHash",tt.DISK_NORMAL_LUT.hash);d(this,"blobUrl",tt.DISK_NORMAL_LUT.url);d(this,"detail",[F*2+1,F*2+1,Ji])}computeLeaf(e){const i=Ne(e[0]-F),s=Ne(e[1]-F),o=Ys(e[2]);return Ns(i,s,o)}};_.register("disk-normal-lut",{factory:()=>new we,depth:3,leafLength:2});let Xe=we;function Ns(n,t,e){const i=Math.cos(e),s=Math.sin(e),o=n*i+t*s,r=n-2*o*i,a=t-2*o*s;return[Math.round((r-n)*ee),Math.round((a-t)*ee)]}const Xs=100,z=20,es=Xs*z,is=n=>Math.floor(n*z/es),js=n=>n*es/z,xe=class xe extends _{constructor(){super(...arguments);d(this,"blobHash",tt.DISK_FRICTION_LUT.hash);d(this,"blobUrl",tt.DISK_FRICTION_LUT.url);d(this,"detail",[z*2+1])}computeLeaf(e){const i=js(e[0]-z);return[Math.round(i*ee)]}};_.register("disk-friction-lut",{factory:()=>new xe,depth:1,leafLength:1});let je=xe;function ze(n){const t=_.create("disk-friction-lut"),e=n.dx;let i=is(e);Math.abs(i)>z&&(i=z*Math.sign(i)),n.dx=t.tree[i+z][0]}function zs(n){const t=_.create("disk-friction-lut"),e=n.dy;let i=is(e);Math.abs(i)>z&&(i=z*Math.sign(i)),n.dy=t.tree[i+z][0]}class Yt{constructor(t,e,i,s){d(this,"_x");d(this,"_y");d(this,"_dx");d(this,"_dy");this.x=t,this.y=e,this.dx=i,this.dy=s}get x(){return this._x}set x(t){if(!Number.isInteger(t))throw new Error("x must be an integer");this._x=t}get y(){return this._y}set y(t){if(!Number.isInteger(t))throw new Error("y must be an integer");this._y=t}get dx(){return this._dx}set dx(t){if(!Number.isInteger(t))throw new Error("dx must be an integer");this._dx=t}get dy(){return this._dy}set dy(t){if(!Number.isInteger(t))throw new Error("dy must be an integer");this._dy=t}setAll(t,e,i,s){this.x=t,this.y=e,this.dx=i,this.dy=s}copy(t){this.setAll(t.x,t.y,t.dx,t.dy)}toArray(){return[this._x,this._y,this._dx,this._dy]}static fromArray(t){return new Yt(t[0],t[1],t[2],t[3])}}const ht=100,Ks=0,Rt=[0,0,0],nt=class nt{constructor(){d(this,"pattern","white");d(this,"_history",new Float32Array(ht*2));d(this,"currentState",new Yt(0,0,0,0));d(this,"nextState",new Yt(0,0,0,0));d(this,"stepFrac",0);d(this,"lastStepPos",[0,0]);d(this,"interpolatedPos",[0,0])}static flushStates(t){for(const e of t)e.lastStepPos[0]=e.currentState.x,e.lastStepPos[1]=e.currentState.y,e.currentState.copy(e.nextState)}history(){const t=[];let e=0,i=0,s=0,o=0;for(let r=0;r<ht;r+=10){const a=2*((nt.historyIndex+ht-r)%ht),l=this._history[a],c=this._history[a+1];if(r>0){const h=Math.hypot(l-e,c-i);s+=h}e=l,i=c,s-o<Ks&&r<ht-1||(Rt[0]=Math.round(l),Rt[1]=Math.round(c),Rt[2]=Math.round(s),t.push([...Rt]),o=s)}return t}static updateHistory(t){nt.historyIndex=(nt.historyIndex+1)%ht;const e=nt.historyIndex*2;for(const i of t)i._history[e]=i.currentState.x,i._history[e+1]=i.currentState.y}static fromJson(t){const e=new nt,i=t;return e.currentState.setAll(i[0],i[1],i[2],i[3]),e.nextState.setAll(i[0],i[1],i[2],i[3]),e}toJson(){return this.currentState.toArray()}advance(t){var u;const e=this.currentState.x,i=this.currentState.y,s=this.currentState.dx,o=this.currentState.dy,r=e+s,a=i+o;let l=s,c=o,h=!0,f=0;for(;f<t.length;f++){const p=t[f];if(!p.isHidden&&Bs(p.collisionRect,r,a)){const b=p.lut.obsOffsetDetailX,y=p.lut.obsOffsetDetailY;let x=r-p.pos[0];p.isFlippedX&&(x*=-1);let m=p.lut.offsetToXIndex(x),w=p.lut.offsetToYIndex(a-p.pos[1]);if(Math.abs(m)>b&&(m=b*Math.sign(m)),Math.abs(w)>y&&(w=y*Math.sign(w)),p.lut.tree.length===0)throw new Error("obs.lut.tree has length 0");const M=p.lut.tree[m+b][w+y];if(M){(u=p.room)==null||u.obstacleHit(p);const[it,gt,Et]=M;let rt=Ye(l*(p.isFlippedX?-1:1)),at=Ye(c);Math.abs(rt)>F&&(rt=F*Math.sign(rt)),Math.abs(at)>F&&(at=F*Math.sign(at));const Mt=_.create("disk-normal-lut").tree[rt+F][at+F][Et],[$t,B]=Mt;l+=$t*(p.isFlippedX?-1:1),c+=B,this.nextState.x+=it*(p.isFlippedX?-1:1),this.nextState.y+=gt,this.nextState.dx=l,this.nextState.dy=c,h=!1;return}}}h?(this.nextState.x=r,this.nextState.y=a):(this.nextState.x+=l,this.nextState.y+=c,this.nextState.dx=l,this.nextState.dy=c)}pushInBounds(t){this.nextState.x-S<t[0]&&(this.nextState.x=t[0]+S,this.nextState.dx<0&&(this.nextState.dx*=-1,ze(this.nextState))),this.nextState.y-S<t[1]&&(this.nextState.y=t[1]+S,this.nextState.dy<0&&(this.nextState.dy*=-1,zs(this.nextState))),this.nextState.x+S>t[0]+t[2]&&(this.nextState.x=t[0]+t[2]-S,this.nextState.dx>0&&(this.nextState.dx*=-1,ze(this.nextState)))}};d(nt,"historyIndex",0);let St=nt;const Ke=3*S;function Us(n,t,e=!1,i=!1){const[s,o]=t.interpolatedPos,r=g*.8*(e?5:1),a=2;n.beginPath();let l=0;n.moveTo(s,o),n.arc(s,o,S*(1-l*a/ht),0,ot);for(const[c,h,f]of t.history()){const u=S*(1-Math.min(f,Ke)/Ke);u>0&&(n.moveTo(c,h),n.arc(c,h,u,0,ot)),l++}n.lineWidth=r,n.lineCap="round",n.lineJoin="round",n.strokeStyle=e?"green":"black",n.stroke(),n.fillStyle=fe[t.pattern],n.imageSmoothingEnabled=!1,n.fill()}const ie=["white","black","v-stripe","h-stripe","checkered","hex-a","hex-b"];function Ue(n="#000",t="#fff",e=12,i=32){if(typeof document>"u")return null;const s=document.createElement("canvas"),o=s.getContext("2d"),r=i*Math.sqrt(3)/2;s.width=i*2,s.height=r*2,o.fillStyle=t,o.fillRect(0,0,s.width,s.height);for(let a=0;a<2;a++)for(let l=0;l<2;l++)for(let c=-1;c<=1;c++)for(let h=-1;h<=1;h++){const f=l*i+a*i/2+c*s.width,u=a*r+h*s.height;o.beginPath(),o.arc(f,u,e,0,Math.PI*2),o.fillStyle=n,o.fill()}return s}function Ws(n="#000",t="#fff",e=1,i=1){if(typeof document>"u")return null;const s=document.createElement("canvas"),o=e+i;s.width=1,s.height=o;const r=s.getContext("2d");return r.fillStyle=t,r.fillRect(0,0,s.width,s.height),r.fillStyle=n,r.fillRect(0,0,s.width,e),s}function qs(n="#000",t="#fff",e=1,i=1){if(typeof document>"u")return null;const s=document.createElement("canvas"),o=e+i;s.width=o,s.height=1;const r=s.getContext("2d");return r.fillStyle=t,r.fillRect(0,0,s.width,s.height),r.fillStyle=n,r.fillRect(0,0,e,s.height),s}function Qs(n="#000",t="#fff",e=512/8,i=512){if(typeof document>"u")return null;const s=document.createElement("canvas");s.width=i,s.height=i;const o=s.getContext("2d");o.fillStyle="white",o.fillRect(0,0,s.width,s.height);const r=Math.ceil(i/e)*2;for(let a=-r;a<r;a++)for(let l=-r;l<r;l++){const c=(a+l)%2===0;o.save(),o.translate(i/2,i/2),o.rotate(Math.PI/4),o.fillStyle=c?n:t;for(let h=-1;h<=1;h++)for(let f=-1;f<=1;f++){const u=Math.random();o.fillRect((a+2*h)*e-i/2,(l+2*f)*e-i/2,e*u,e*u)}o.restore()}return s}const Zs={"v-stripe":qs(),"h-stripe":Ws(),checkered:Qs(),"hex-a":Ue("#000","#fff"),"hex-b":Ue("#fff","#000",4)},Gs={black:g,white:g,"h-stripe":g,"v-stripe":g,checkered:g/50,"hex-a":g/10,"hex-b":g/10},fe={black:"black",white:"white","h-stripe":ft("h-stripe"),"v-stripe":ft("v-stripe"),checkered:ft("checkered"),"hex-a":ft("hex-a"),"hex-b":ft("hex-b")};function ft(n,t=1){const e=Zs[n];if(!e)return"white";const s=e.getContext("2d").createPattern(e,"repeat");return t*=Gs[n],s.setTransform(new DOMMatrix().scale(t,t)),s}class Y{constructor(){d(this,"flatConfig")}refreshConfig(){this.flatConfig=ss(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],i=e();return i.refreshConfig(),i}}d(Y,"_registry",{});function ss(n,t={}){for(const[e,i]of Object.entries(n.children))"action"in i||("value"in i?t[e]=i.value:ss(i,t));return t}const ns={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const n of Object.values(ns.children))n.onChange=t=>{_t.refreshConfig(),t.onResize()};const ve=class ve extends Y{constructor(){super(...arguments);d(this,"tree",ns)}};Y.register("layout-config",()=>new ve);let We=ve;const _t=Y.create("layout-config");function Js(n){n.isLandscape,n.isPortrait}function tn(){const{buttonWidth:n}=_t.flatConfig;return n}function en(){const{buttonHeight:n}=_t.flatConfig;return n}function sn(n){return Object.entries(n)}function nn(n,t){return new se(n,t)._computedRects}const W=class W{constructor(t,e){d(this,"_computedRects",{});d(this,"isPortrait",!1);d(this,"isLandscape",!1);d(this,"parent");d(this,"_currentLayoutKey","");d(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const i=600;t[2]<i||t[3]<i?W.isSmall=!0:W.isSmall=!1,Js(this),this.parent=t;for(const[o,r]of Object.entries(e))this.parent=t,this._currentLayoutKey=o,this._computedRects[o]=this.computeRect(r);const s=this._childrenToParse;for(;Object.keys(s).length>0;){const o=Object.keys(s)[0],r=s[o];delete s[o];const a=this._computedRects[o],{_computedRects:l}=new W(a,r);for(const c in l)this._computedRects[`${o}.${c}`]=l[c]}}computeRect(t){let e=[...this.parent];for(const[i,s]of sn(t))if(i==="parent"){if(!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);this.parent=this._computedRects[s],e=[...this.parent]}else if(i.startsWith("parent@")){const[o,r]=i.split("@");if(typeof s!="string"||!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);if(r==="portrait")this.isPortrait&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="landscape")this.isLandscape&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="sm-portrait")this.isPortrait&&W.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="sm-landscape")this.isLandscape&&W.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else if(i==="children")this._childrenToParse[this._currentLayoutKey]=s;else if(i.includes("@")){const[o,r]=i.split("@");if(r==="portrait")this.isPortrait&&(e=this.applyRule(e,o,s));else if(r==="landscape")this.isLandscape&&(e=this.applyRule(e,o,s));else if(r==="sm-portrait")this.isPortrait&&W.isSmall&&(e=this.applyRule(e,o,s));else if(r==="sm-landscape")this.isLandscape&&W.isSmall&&(e=this.applyRule(e,o,s));else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else e=this.applyRule(e,i,s);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,i){const[s,o,r,a]=t,[l,c,h,f]=this.parent,u=(b,y)=>{if(typeof y=="function"&&(y=y()),typeof y=="string"&&y.endsWith("%")){const x=parseFloat(y)/100;return["left","right","width","margin"].includes(b)?h*x:f*x}else{if(y==="auto")return b==="width"?l+h-s:b==="height"?c+f-o:["left","right"].includes(b)?(h-r)/2:(f-a)/2;if(typeof y=="number"&&y<0){if(b==="width")return h+y;if(b==="height")return f+y}}return Number(y)},p=e.split("-");if(p.length===2){const[b,y]=p;let x;if(b==="min")x=Math.max;else if(b==="max")x=Math.min;else throw new Error("only min- or max- prefixed allowed");if(y==="width")return[s,o,x(r,u("width",i)),a];if(y==="height")return[s,o,r,x(a,u("height",i))];if(y==="left")return[x(s,u("left",i)),o,r,a];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[l+u("left",i),o,r,a];case"right":return[l+h-r-u("right",i),o,r,a];case"top":return[s,c+u("top",i),r,a];case"bottom":return[s,c+f-a-u("bottom",i),r,a];case"width":return[s,o,u("width",i),a];case"height":return[s,o,r,u("height",i)];case"margin":{const b=u("margin",i);return[s+b,o+b,r-2*b,a-2*b]}default:return t}}};d(W,"isSmall",!1);let se=W;const on={pause:`
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="4" y="4" width="6" height="16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<rect x="14" y="4" width="6" height="16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
  
  `,play:`
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M17.3125 12L7.6875 19L7.6875 5L17.3125 12Z" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
  
  `,fast:`
  
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.7778 12L4 19.1111L4 4.88892L13.7778 12Z" stroke="currentColor" stroke-width="1.77778" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10.2222 19.1111L20 12L10.2222 4.88892" stroke="currentColor" stroke-width="1.77778" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

  `,faster:`
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.0833 12.0001L1 19.3334L1 4.66675L11.0833 12.0001Z" stroke="currentColor" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M7.41669 19.3334L17.5 12.0001L7.41669 4.66675" stroke="currentColor" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12.9167 19.3334L23 12.0001L12.9167 4.66675" stroke="currentColor" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
  
  `,bsp:`
  <svg viewBox="0 0 62.5 62.5" xmlns="http://www.w3.org/2000/svg">
<circle cx="16.44736842105263" cy="18.092105263157894" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="31.25" cy="18.092105263157894" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="46.05263157894737" cy="18.092105263157894" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="9.046052631578945" cy="31.25" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="23.848684210526315" cy="31.25" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="38.651315789473685" cy="31.25" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="53.453947368421055" cy="31.25" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="16.44736842105263" cy="44.4078947368421" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="31.25" cy="44.4078947368421" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
<circle cx="46.05263157894737" cy="44.4078947368421" r="5.2631578947368425" fill="currentColor" stroke="currentColor" stroke-width="1"/>
</svg>
`};function rn(n,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",s=t.display.classes??[];t.display.type!=="button"&&s.push("noselect");const o=dn(`
    <${e} 
       id="${n}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${s.join(" ")}
        "
        >
      ${t.display.icon?on[t.display.icon]:""}
      <span 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[r,a]of Object.entries(t.display.styles??{}))o.style.setProperty(r,a);return t.id=n,t.htmlElem=o,o}function ne(n,t){t?ln(n):an(n)}function an(n){let t;typeof n=="string"?t=document.getElementById(n):t=n.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function ln(n){let t;typeof n=="string"?t=document.getElementById(n):t=n.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function qe(n,t){if(n.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:i}=n;i&&(i.innerHTML=`
    <span ${n.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function cn(n,t,e){if(!e){n.classList.add("hidden");return}n.style.opacity="";const[i,s,o,r]=e;n.style.display="",n.style.left=`${i}px`,n.style.top=`${s}px`,n.style.width=`${o}px`,n.style.height=`${r}px`;const a=n;a.width=o*window.devicePixelRatio,a.height=r*window.devicePixelRatio}function dn(n){const t=document.createElement("div");return t.innerHTML=n.trim(),t.firstChild}const Qe={};let hn=0;class et{constructor(){d(this,"guiLayout");d(this,"layoutRectangles",{});d(this,"elements",{});d(this,"layoutFactory")}init(t,e,i){this.layoutFactory=e;for(const s of i)if(typeof s.id=="string")this.elements[s.id]=s;else{const o=`_${hn++}`;this.elements[o]=s;const r=rn(o,s);r.onclick=a=>{a.preventDefault(),s.click&&s.click({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointerdown=a=>{a.preventDefault(),s.down&&s.down({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointermove=a=>{a.preventDefault(),s.move&&s.move({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointerup=a=>{a.preventDefault(),s.up&&s.up({elementId:o,pinballWizard:t,pointerEvent:a})},r.style.display="none",document.body.appendChild(r),Qe[o]=r,s.id=o}}refreshLayout(t){const e=[0,0,window.innerWidth,window.innerHeight];this.guiLayout=this.layoutFactory(t),this.layoutRectangles=nn(e,this.guiLayout);for(const i in this.elements){const s=this.elements[i],o=this.layoutRectangles[s.layoutKey];s.rectangle=o,s.rectangle&&(s.dprRectangle=s.rectangle.map(r=>r*window.devicePixelRatio)),cn(Qe[i],s,o)}}keydown(t,e){for(const i in this.elements){const s=this.elements[i],{click:o,hotkeys:r}=s;if(o&&(r!=null&&r.includes(e)))return o({elementId:i,pinballWizard:t}),!0}return!1}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const i=this._registry[e];if(!i)throw new Error(`gui ${e} not registered `);const{factory:s,layoutFactory:o,elements:r}=i,a=s();this._preloaded[e]=a,a.init(t,o,r)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}d(et,"_registry",{}),d(et,"_preloaded",{});const un=()=>_t.flatConfig.outerMargin,ct=()=>_t.flatConfig.innerMargin,fn=tn,R=en,pn={screen:{},_outerMargin:{margin:()=>un(),width:-50,left:"auto"},topBar:{parent:"_outerMargin",width:()=>6*R()+4*ct(),height:()=>R(),left:"auto"},bottomBar:{parent:"_outerMargin",width:()=>7*R()+5*ct(),height:()=>R(),left:"auto",bottom:0},ballsBtn:{parent:"bottomBar",width:()=>R()},clock:{parent:"ballsBtn",width:()=>2*R(),left:()=>R()+ct()},pauseBtn:{parent:"clock",width:()=>R(),left:()=>2*R()+ct()},playBtn:{parent:"pauseBtn",width:()=>R(),left:()=>R()+ct()},fastBtn:{parent:"playBtn",width:()=>R(),left:()=>R()+ct()},fasterBtn:{parent:"fastBtn",width:()=>R(),left:()=>R()+ct()},resetBtn:{parent:"screen",width:()=>fn(),height:()=>R(),left:"auto",top:"auto"}},os={layoutKey:"topBar",display:{type:"panel",label:""}},oe={layoutKey:"ballsBtn",display:{type:"button",icon:"bsp"},click:()=>{N.toggle()}},rs={layoutKey:"clock",display:{type:"panel",label:"00:00"}};function gn(n){const t=Math.floor(n/60),e=Math.floor(n%60),i=String(t).padStart(2,"0"),s=String(e).padStart(2,"0");return`${i}:${s}`}const mn={layoutKey:"pauseBtn",display:{type:"button",icon:"pause"},click:({pinballWizard:n})=>{n.speed="paused"}},bn={layoutKey:"playBtn",display:{type:"button",icon:"play"},click:({pinballWizard:n})=>{n.speed="normal"}},yn={layoutKey:"fastBtn",display:{type:"button",icon:"fast"},click:({pinballWizard:n})=>{n.speed="fast"}},wn={layoutKey:"fasterBtn",display:{type:"button",icon:"faster"},click:({pinballWizard:n})=>{n.speed="faster"}},as={paused:mn,normal:bn,fast:yn,faster:wn},ls={layoutKey:"resetBtn",display:{type:"button",label:"Play Again"},click:({pinballWizard:n})=>{n.reset()}},Ze=[os,oe,rs,...Object.values(as),ls],Se=class Se extends et{update(t,e){const i=t.activeSim.stepCount,s=Wi(i),o=gn(s);qe(rs,o);for(const[a,l]of Object.entries(as)){const c=a===t.speed;l.htmlElem.classList.toggle("active",c)}const r=xn(t,s);qe(os,r)}move(t,e){}down(t,e){}showHideElements(t){for(const e of Ze)ne(e,!t.isTitleScreen);ne(ls,t.activeSim.winningDiskIndex!==-1)}};et.register("playing-gui",{factory:()=>new Se,layoutFactory:()=>pn,elements:Ze});let Ge=Se;function xn(n,t){const e=Os-t;return n.activeSim.winningDiskIndex!==-1?"finished":n.isHalted?"you must choose a ball":n.selectedDiskIndex===-1?`${e} sec choose a ball`:n.hasBranched?"Choice locked. Wait to finish.":`${e} sec to reconsider`}const C=typeof document>"u"?null:document.getElementById("ball-selection-panel-canvas");C&&(C.style.setProperty("border-radius","5px"),C.style.setProperty("border","1px solid black"));const Dt=C?C.getContext("2d"):null;let Je=-1,ti=-1,ei=!1;const pe=[{count:3,offset:.5},{count:4,offset:0},{count:3,offset:.5}],cs=90,ds=80,pt=40,vn=Math.pow(pt,2),Nt=15,Sn=Math.max(...pe.map(({count:n})=>n)),ii=(Sn-1)*cs+2*(pt+Nt),si=(pe.length-1)*ds+2*(pt+Nt),Xt=[];let ni=0,oi=0;for(const n of pe){for(let t=0;t<n.count;t++)ni>=yt||(Xt.push([Nt+pt+(n.offset+t)*cs,Nt+pt+oi*ds]),ni++);oi++}const P=class P{static show(){var t;C.style.setProperty("display","block"),(t=oe.htmlElem)==null||t.classList.add("active")}static hide(){var t;C.style.setProperty("display","none"),(t=oe.htmlElem)==null||t.classList.remove("active")}static toggle(){C.style.display==="none"?P.show():P.hide()}static initListeners(t){if(ei)throw new Error("BallSelectionPanel.initListeners() called multiple times");ei=!0,C.addEventListener("pointerdown",e=>{const i=ri(e);t.trySelectDisk(i),C.style.setProperty("cursor","default")}),C.addEventListener("pointermove",e=>{const i=ri(e);i===-1||t.hasBranched||i===t.selectedDiskIndex?C.style.setProperty("cursor","default"):C.style.setProperty("cursor","pointer")})}static repaint(t){const e=C.width,i=C.height;if(Dt.fillStyle="rgb(221,221,221)",Dt.fillRect(0,0,e,i),!!t.activeSim)for(let s=0;s<yt;s++){const o=t.activeSim.disks[s];if(!o)continue;const r=s===t.selectedDiskIndex;An(Dt,o,r,!1,...Xt[s])}}static setBounds(t,e){P._bounds=t;let[i,s,o,r]=t;const a=o-ii/window.devicePixelRatio,l=r-si/window.devicePixelRatio;if(i+=a/2,o-=a,s+=l/2,r-=l,C.style.setProperty("position","absolute"),C.style.setProperty("left",`${i}px`),C.style.setProperty("top",`${s}px`),o!==Je||r!==ti){C.style.setProperty("width",`${o}px`),C.style.setProperty("height",`${r}px`);const c=window.devicePixelRatio;C.width=o*c,C.height=r*c,P.repaint(e)}Je=o,ti=r}};d(P,"isRepaintQueued",!1),d(P,"cvs",C),d(P,"ctx",Dt),d(P,"totalWidth",ii),d(P,"totalHeight",si),d(P,"diskRadius",pt),d(P,"diskPositions",Xt),d(P,"_drawScale",1),d(P,"_bounds",[1,1,1,1]);let N=P;function ri(n){const t=n.offsetX*window.devicePixelRatio,e=n.offsetY*window.devicePixelRatio;for(const[i,[s,o]]of Xt.entries()){const r=s-t,a=o-e;if(r*r+a*a<vn)return i}return-1}function An(n,t,e=!1,i=!1,s,o){n.beginPath();const[r,a]=t.interpolatedPos.map(l=>-l/g);n.save(),n.translate(r,a),n.moveTo(s-r,o-a),n.arc(s-r,o-a,pt,0,ot),n.lineWidth=e?20:5,n.lineCap="round",n.lineJoin="round",n.strokeStyle=e?"green":"black",n.stroke(),n.fillStyle=kn(t.pattern),n.imageSmoothingEnabled=!1,n.fill(),n.restore()}const Ut={};function kn(n){return Object.hasOwn(Ut,n)||(Ut[n]=Cn(n)),Ut[n]}function Cn(n){const t=fe[n];return t instanceof CanvasPattern?ft(n,20/g):t}function _n(n){const t=Rs;let e=Array(t).fill(0).map(()=>Math.round(10+Math.random()*80)),i=0;function s(r){for(let a=0;a<50;a++){let l=!1;for(const c of n){const h=c.reduce((f,u)=>f+r[u],0);if(h!==100){const f=100-h,u=c.length;for(const p of c)r[p]+=f/u;for(const p of c)r[p]=Math.max(0,Math.min(100,r[p]));l=!0}}if(!l)break}}for(let r=50;r>.1;r*=.95){const a=e.slice(),l=Math.floor(Math.random()*t),c=(Math.random()-.5)*r*2;a[l]=Math.max(0,Math.min(100,a[l]+c)),s(a);const h=new Set(a.map(f=>Math.round(f))).size;(h>i||Math.exp((h-i)/r)>Math.random())&&(e=a.slice(),i=h)}const o=e.map(r=>Math.max(0,Math.min(100,Math.round(r))));for(const r of n){const a=r.reduce((l,c)=>l+o[c],0);if(a!==100){let l=r[0],c=0;for(const f of r){const u=Math.min(100-o[f],o[f]);u>c&&(c=u,l=f)}const h=Math.max(-c,Math.min(c,100-a));o[l]=Math.max(0,Math.min(100,o[l]+h))}}return o}const En={children:{scrollSpeed:{value:-2e3,min:-1e4,max:1e4,step:1,onChange:()=>D.refreshConfig()},rngSeed:{value:-1,min:-1,max:Number.MAX_SAFE_INTEGER,step:1,onChange:()=>D.refreshConfig()},topSpeed:{value:30,min:2,max:1e6,onChange:()=>{D.refreshConfig(),ut.faster=D.flatConfig.topSpeed}},speedLerp:{value:.004,min:0,max:1,onChange:()=>D.refreshConfig()},speedAnimDur:{value:1e3,min:0,max:1e4,onChange:()=>D.refreshConfig()},roomIndex:{value:0,min:-1,max:10,step:1,onChange:()=>D.refreshConfig()}}},Ae=class Ae extends Y{constructor(){super(...arguments);d(this,"tree",En)}};Y.register("top-config",()=>new Ae);let ai=Ae;const D=Y.create("top-config"),I=typeof document>"u"?null:document.getElementById("scrollbar-canvas"),E=I?I.getContext("2d"):null;let li=-1,ci=-1,di=!1,wt=!1;const O=class O{static get isDragging(){return wt}static show(){I.style.setProperty("display","block")}static hide(){I.style.setProperty("display","none")}static initListeners(t){if(di)throw new Error("Scrollbar.initListeners() called multiple times");di=!0,I.addEventListener("pointerdown",e=>{t.camera.pos=-(e.clientY-O._bounds[1])*window.devicePixelRatio/O._drawScale,wt=!0}),document.addEventListener("pointermove",e=>{wt&&(t.camera.pos=-(e.clientY-O._bounds[1])*window.devicePixelRatio/O._drawScale)}),document.addEventListener("pointerup",()=>{wt=!1}),document.addEventListener("pointerleave",()=>{wt=!1})}static setBounds(t,e){O._bounds=t;const[i,s,o,r]=t;if(I.style.setProperty("position","absolute"),I.style.setProperty("left",`${i}px`),I.style.setProperty("top",`${s}px`),o!==li||r!==ci){I.style.setProperty("width",`${o}px`),I.style.setProperty("height",`${r}px`);const a=window.devicePixelRatio;I.width=o*a,I.height=r*a,O.repaint(e)}li=o,ci=r}static repaint(t){const e=t.activeSim;E.fillStyle="red",E.strokeStyle="blue",E.lineWidth=2;const i=I.width,s=I.height;E.fillRect(0,0,i,s),E.strokeRect(0,0,i,s);const o=I.width/100/g;if(this._drawScale=o,E.clearRect(0,0,I.width,I.height),E.save(),E.scale(o,o),e){E.fillStyle=re;for(const a of e.obstacles)v.traceObstacle(E,a),E.fill();const r=t.selectedDiskIndex;for(const[a,l]of e.disks.entries()){const c=a===r;O.drawDisk(l,c)}if(r!==-1){const a=e.disks[r];O.drawDisk(a,!0)}v.drawViewRect(E,t.simViewRect)}E.restore()}static drawDisk(t,e){const[i,s]=t.interpolatedPos,o=g*2*(e?5:1);E.strokeStyle=e?"green":"black",E.lineWidth=o,E.fillStyle=Mn(t.pattern),E.imageSmoothingEnabled=!1,E.beginPath(),E.arc(i,s,S*5,0,ot),E.fill(),E.stroke()}};d(O,"isRepaintQueued",!1),d(O,"cvs",I),d(O,"ctx",E),d(O,"_bounds",[1,1,1,1]),d(O,"_drawScale",1);let j=O;const Wt={};function Mn(n){return Object.hasOwn(Wt,n)||(Wt[n]=$n(n)),Wt[n]}function $n(n){const t=fe[n];return t instanceof CanvasPattern?ft(n,6):t}const X=typeof document>"u"?null:document.getElementById("sim-canvas"),A=X?X.getContext("2d"):null,re="#888",Ln="#000",k=class k{static drawFinish(t){A.fillStyle="rgba(0,255,0,0.5)",A.fillRect(...t.xywh)}static drawBarrier(t){t.isHidden||(A.fillStyle="black",A.fillRect(...t.xywh))}static traceObstacle(t,e){const{isHidden:i,pos:s,points:o}=e;if(!i){t.beginPath();for(const[r,a]of o)t.lineTo(s[0]+r,s[1]+a);t.closePath()}}static onResize(t){var a,l;const e=window.devicePixelRatio,i=window.innerWidth*e,s=600*e;k.innerWidth=Math.min(s,i);let o=Math.floor(k.innerWidth/e),r=Math.floor((i-k.innerWidth)/2/e);if(t){const c=Math.min(600,window.innerHeight),h=((l=(a=t==null?void 0:t.activeSim)==null?void 0:a.level)==null?void 0:l.bounds)??[1,1,1,1],f=c*(h[2]/h[3]),u=[r+o,(window.innerHeight-c)/2,f,c];o+f>window.innerWidth?(r=0,o=window.innerWidth-f,u[0]=r+o,k.innerWidth=o*e):r+o+f>window.innerWidth&&(r=window.innerWidth-o-f,u[0]=r+o,k.innerWidth=o*e);const p=300,b=[r,window.innerHeight-p,o,p];j.setBounds(u,t),N.setBounds(b,t)}X.style.setProperty("position","absolute"),X.style.setProperty("width",`${o}px`),X.style.setProperty("left",`${r}px`),X.width=k.innerWidth,X.height=X.clientHeight*e,k.drawOffset[0]=0,k.cssLeft=r}static drawSim(t){k._updateSimViewRect(t);const e=t.activeSim,{selectedDiskIndex:i,simViewRect:s}=t,o=k.innerWidth/100/g;k.drawSimScale=o,A.clearRect(0,0,X.width,X.height),A.save(),A.translate(...k.drawOffset),A.scale(o,o),A.lineWidth=g;for(const[p,b]of e.disks.entries()){const y=p===i,x=p===e.winningDiskIndex;Us(A,b,y,x)}const r=s[1],a=r+s[3];A.fillStyle=re,A.strokeStyle=Ln,A.lineWidth=.4*g;for(const p of e.obstacles){const[b,y,x,m]=p.collisionRect;y>a||y+m<r||(k.traceObstacle(A,p),A.fill(),A.stroke())}k.drawFinish(e.finish);const l=2*g,c=e.level.bounds[0],h=e.level.bounds[1],f=c+e.level.bounds[2],u=h+e.level.bounds[3];A.fillStyle=re,A.fillRect(c-l,h,l,u-h),A.fillRect(f,h,l,u-h),A.restore()}static _updateSimViewRect(t){const{drawOffset:e,drawSimScale:i}=this;t.simViewRect[0]=e[0]/i,t.simViewRect[1]=-e[1]/i,t.simViewRect[2]=k.innerWidth/i,t.simViewRect[3]=window.innerHeight/i*window.devicePixelRatio}static drawCursor(t){const[e,i]=t;A.fillStyle="rgba(100,100,100,.5)",A.beginPath(),A.moveTo(e,i),A.arc(e,i,S,0,ot),A.fill()}static drawViewRect(t,e){t.strokeStyle="red",t.lineWidth=S,t.strokeRect(...e)}};d(k,"cvs",X),d(k,"ctx",A),d(k,"innerWidth",1),d(k,"drawOffset",[0,0]),d(k,"cssLeft",0),d(k,"drawSimScale",1);let v=k;class hi{constructor(){d(this,"pos",-100*g);d(this,"vel",0);d(this,"_idleDelay",1e3);d(this,"_idleCountdown",0);d(this,"_cameraFriction",.001);d(this,"_snapSpeed",.002);d(this,"targetRoom",0);d(this,"lastDragTime",performance.now());d(this,"isDragging",!1)}jumpToRoom(t,e){this.targetRoom=e}update(t,e){if(!(this.isDragging||j.isDragging||e.isHalted||e.speed==="paused")){if(this._idleCountdown>0&&(this._idleCountdown-=t,this._idleCountdown<=0)){const i=this.targetRoom;D.tree.children.roomIndex.value=i,D.refreshConfig()}if(this._idleCountdown<=0){const{rooms:i}=e.activeSim.level;let s=this.targetRoom;s=Math.max(0,Math.min(i.length-1,s));const o=i[s],r=-o.bounds[1]-o.bounds[3]/2;this.pos=Vt(this.pos,r,this._snapSpeed*t)}this.vel*=1-this._cameraFriction*t,this.pos+=this.vel}}scroll(t){const{scrollSpeed:e}=D.flatConfig;this.pos+=t*e,this._idleCountdown=this._idleDelay}drag(t,e){const i=performance.now(),o=(e-t)/v.drawSimScale*window.devicePixelRatio;this.pos+=o,this._idleCountdown=this._idleDelay,this.isDragging=!0,this.lastDragTime=i}endDrag(){this._idleCountdown=this._idleDelay,this.isDragging=!1}}function In(n){ge.refreshConfig()}const Rn={label:"Graphics",children:{pixelScale:{value:1,min:1,max:10,step:1,onChange:In}}},ke=class ke extends Y{constructor(){super(...arguments);d(this,"tree",Rn)}};Y.register("gfx-config",()=>new ke);let ui=ke;const ge=Y.create("gfx-config"),Dn={children:{...D.tree.children,...ge.tree.children}},Ce=class Ce extends Y{constructor(){super(...arguments);d(this,"tree",Dn)}};Y.register("pinball-wizard-config",()=>new Ce);let fi=Ce;const Pn=Y.create("pinball-wizard-config"),hs={NAMES:["playing-gui"]},pi={NAMES:["disk-friction-lut","disk-disk-lut","obstacle-lut","disk-normal-lut","race-lut"]};function On(n,t){return Math.sqrt(Tn(n,t))}function Tn(n,t){return Math.pow(n[0]-t[0],2)+Math.pow(n[1]-t[1],2)}function bt(n,t,e){return[n[0]+(t[0]-n[0])*e,n[1]+(t[1]-n[1])*e]}function Bn(n,t){const e=n[t+0],i=n[t+1],s=n[t+2],o=n[t+3];let r=3*i[0]-2*e[0]-o[0];r*=r;let a=3*i[1]-2*e[1]-o[1];a*=a;let l=3*s[0]-2*o[0]-e[0];l*=l;let c=3*s[1]-2*o[1]-e[1];return c*=c,r<l&&(r=l),a<c&&(a=c),r+a}function ae(n,t,e,i){const s=i||[];if(Bn(n,t)<e){const o=n[t+0];s.length?On(s[s.length-1],o)>1&&s.push(o):s.push(o),s.push(n[t+3])}else{const r=n[t+0],a=n[t+1],l=n[t+2],c=n[t+3],h=bt(r,a,.5),f=bt(a,l,.5),u=bt(l,c,.5),p=bt(h,f,.5),b=bt(f,u,.5),y=bt(p,b,.5);ae([r,h,p,y],0,e,s),ae([y,b,u,c],0,e,s)}return s}function Hn(n,t=.15,e){const i=[],s=(n.length-1)/3;for(let o=0;o<s;o++){const r=o*3;ae(n,r,t,i)}return i}const Fn=0,le=1,us=2,Pt={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Vn(n){const t=new Array;for(;n!=="";)if(n.match(/^([ \t\r\n,]+)/))n=n.substr(RegExp.$1.length);else if(n.match(/^([aAcChHlLmMqQsStTvVzZ])/))t[t.length]={type:Fn,text:RegExp.$1},n=n.substr(RegExp.$1.length);else if(n.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))t[t.length]={type:le,text:`${parseFloat(RegExp.$1)}`},n=n.substr(RegExp.$1.length);else return[];return t[t.length]={type:us,text:""},t}function qt(n,t){return n.type===t}function fs(n){const t=[],e=Vn(n);let i="BOD",s=0,o=e[s];for(;!qt(o,us);){let r=0;const a=[];if(i==="BOD")if(o.text==="M"||o.text==="m")s++,r=Pt[o.text],i=o.text;else return fs("M0,0"+n);else qt(o,le)?r=Pt[i]:(s++,r=Pt[o.text],i=o.text);if(s+r<e.length){for(let l=s;l<s+r;l++){const c=e[l];if(qt(c,le))a[a.length]=+c.text;else throw new Error("Param not a number: "+i+","+c.text)}if(typeof Pt[i]=="number"){const l={key:i,data:a};t.push(l),s+=r,o=e[s],i==="M"&&(i="L"),i==="m"&&(i="l")}else throw new Error("Bad segment: "+i)}else throw new Error("Path data ended short")}return t}function Yn(n){let t=0,e=0,i=0,s=0;const o=[];for(const{key:r,data:a}of n)switch(r){case"M":o.push({key:"M",data:[...a]}),[t,e]=a,[i,s]=a;break;case"m":t+=a[0],e+=a[1],o.push({key:"M",data:[t,e]}),i=t,s=e;break;case"L":o.push({key:"L",data:[...a]}),[t,e]=a;break;case"l":t+=a[0],e+=a[1],o.push({key:"L",data:[t,e]});break;case"C":o.push({key:"C",data:[...a]}),t=a[4],e=a[5];break;case"c":{const l=a.map((c,h)=>h%2?c+e:c+t);o.push({key:"C",data:l}),t=l[4],e=l[5];break}case"Q":o.push({key:"Q",data:[...a]}),t=a[2],e=a[3];break;case"q":{const l=a.map((c,h)=>h%2?c+e:c+t);o.push({key:"Q",data:l}),t=l[2],e=l[3];break}case"A":o.push({key:"A",data:[...a]}),t=a[5],e=a[6];break;case"a":t+=a[5],e+=a[6],o.push({key:"A",data:[a[0],a[1],a[2],a[3],a[4],t,e]});break;case"H":o.push({key:"H",data:[...a]}),t=a[0];break;case"h":t+=a[0],o.push({key:"H",data:[t]});break;case"V":o.push({key:"V",data:[...a]}),e=a[0];break;case"v":e+=a[0],o.push({key:"V",data:[e]});break;case"S":o.push({key:"S",data:[...a]}),t=a[2],e=a[3];break;case"s":{const l=a.map((c,h)=>h%2?c+e:c+t);o.push({key:"S",data:l}),t=l[2],e=l[3];break}case"T":o.push({key:"T",data:[...a]}),t=a[0],e=a[1];break;case"t":t+=a[0],e+=a[1],o.push({key:"T",data:[t,e]});break;case"Z":case"z":o.push({key:"Z",data:[]}),t=i,e=s;break}return o}function Nn(n){const t=[];let e="",i=0,s=0,o=0,r=0,a=0,l=0;for(const{key:c,data:h}of n){switch(c){case"M":t.push({key:"M",data:[...h]}),[i,s]=h,[o,r]=h;break;case"C":t.push({key:"C",data:[...h]}),i=h[4],s=h[5],a=h[2],l=h[3];break;case"L":t.push({key:"L",data:[...h]}),[i,s]=h;break;case"H":i=h[0],t.push({key:"L",data:[i,s]});break;case"V":s=h[0],t.push({key:"L",data:[i,s]});break;case"S":{let f=0,u=0;e==="C"||e==="S"?(f=i+(i-a),u=s+(s-l)):(f=i,u=s),t.push({key:"C",data:[f,u,...h]}),a=h[0],l=h[1],i=h[2],s=h[3];break}case"T":{const[f,u]=h;let p=0,b=0;e==="Q"||e==="T"?(p=i+(i-a),b=s+(s-l)):(p=i,b=s);const y=i+2*(p-i)/3,x=s+2*(b-s)/3,m=f+2*(p-f)/3,w=u+2*(b-u)/3;t.push({key:"C",data:[y,x,m,w,f,u]}),a=p,l=b,i=f,s=u;break}case"Q":{const[f,u,p,b]=h,y=i+2*(f-i)/3,x=s+2*(u-s)/3,m=p+2*(f-p)/3,w=b+2*(u-b)/3;t.push({key:"C",data:[y,x,m,w,p,b]}),a=f,l=u,i=p,s=b;break}case"A":{const f=Math.abs(h[0]),u=Math.abs(h[1]),p=h[2],b=h[3],y=h[4],x=h[5],m=h[6];f===0||u===0?(t.push({key:"C",data:[i,s,x,m,x,m]}),i=x,s=m):(i!==x||s!==m)&&(ps(i,s,x,m,f,u,p,b,y).forEach(function(M){t.push({key:"C",data:M})}),i=x,s=m);break}case"Z":t.push({key:"Z",data:[]}),i=o,s=r;break}e=c}return t}function Xn(n){return Math.PI*n/180}function xt(n,t,e){const i=n*Math.cos(e)-t*Math.sin(e),s=n*Math.sin(e)+t*Math.cos(e);return[i,s]}function ps(n,t,e,i,s,o,r,a,l,c){const h=Xn(r);let f=[],u=0,p=0,b=0,y=0;if(c)[u,p,b,y]=c;else{[n,t]=xt(n,t,-h),[e,i]=xt(e,i,-h);const B=(n-e)/2,L=(t-i)/2;let K=B*B/(s*s)+L*L/(o*o);K>1&&(K=Math.sqrt(K),s=K*s,o=K*o);const Lt=a===l?-1:1,mt=s*s,Kt=o*o,_s=mt*Kt-mt*L*L-Kt*B*B,Es=mt*L*L+Kt*B*B,He=Lt*Math.sqrt(Math.abs(_s/Es));b=He*s*L/o+(n+e)/2,y=He*-o*B/s+(t+i)/2,u=Math.asin(parseFloat(((t-y)/o).toFixed(9))),p=Math.asin(parseFloat(((i-y)/o).toFixed(9))),n<b&&(u=Math.PI-u),e<b&&(p=Math.PI-p),u<0&&(u=Math.PI*2+u),p<0&&(p=Math.PI*2+p),l&&u>p&&(u=u-Math.PI*2),!l&&p>u&&(p=p-Math.PI*2)}let x=p-u;if(Math.abs(x)>Math.PI*120/180){const B=p,L=e,K=i;l&&p>u?p=u+Math.PI*120/180*1:p=u+Math.PI*120/180*-1,e=b+s*Math.cos(p),i=y+o*Math.sin(p),f=ps(e,i,L,K,s,o,r,0,l,[p,B,b,y])}x=p-u;const m=Math.cos(u),w=Math.sin(u),M=Math.cos(p),it=Math.sin(p),gt=Math.tan(x/4),Et=4/3*s*gt,rt=4/3*o*gt,at=[n,t],lt=[n+Et*w,t-rt*m],Mt=[e+Et*it,i-rt*M],$t=[e,i];if(lt[0]=2*at[0]-lt[0],lt[1]=2*at[1]-lt[1],c)return[lt,Mt,$t].concat(f);{f=[lt,Mt,$t].concat(f);const B=[];for(let L=0;L<f.length;L+=3){const K=xt(f[L][0],f[L][1],h),Lt=xt(f[L+1][0],f[L+1][1],h),mt=xt(f[L+2][0],f[L+2][1],h);B.push([K[0],K[1],Lt[0],Lt[1],mt[0],mt[1]])}return B}}function jn(n,t,e){const i=fs(n),s=Nn(Yn(i)),o=[];let r=[],a=[0,0],l=[];const c=()=>{l.length>=4&&r.push(...Hn(l,t)),l=[]},h=()=>{c(),r.length&&(o.push(r),r=[])};for(const{key:f,data:u}of s)switch(f){case"M":h(),a=[u[0],u[1]],r.push(a);break;case"L":c(),r.push([u[0],u[1]]);break;case"C":if(!l.length){const p=r.length?r[r.length-1]:a;l.push([p[0],p[1]])}l.push([u[0],u[1]]),l.push([u[2],u[3]]),l.push([u[4],u[5]]);break;case"Z":c(),r.push([a[0],a[1]]);break}return h(),o}const zn=1*g,kt={roundrect:{baseSvg:`
    M459.375,38.609c0.203-3.941-0.757-7.569-2.752-10.524c-2.986-5.642-8.415-9.074-14.955-9.427
c-29.919-1.627-404.524-1.716-420.457-1.716c-4.928,0-9.199,1.711-12.405,4.951C2.108,26.049-1.122,33.3,0.351,41.019
c4.134,21.792,6.129,44.811,6.276,72.447c0.005,1.473,0.196,2.902,0.586,4.459c0.848,9.442,7.81,16.369,17.108,16.915
c11.527,0.68,76.52,1.366,151.778,2.163c111.228,1.173,249.649,2.635,266.371,4.636c0.776,0.094,1.533,0.142,2.259,0.142
c2.393,0,4.662-0.485,6.739-1.442c7.819-2.204,12.243-8.912,11.293-17.242C459.202,91.748,458.094,64.116,459.375,38.609z
  M424.895,104.014c-28.381-1.062-135.846-1.925-231.741-2.694c-67.648-0.541-131.946-1.061-150.877-1.528
c-0.5-16.32-1.736-31.74-3.765-46.819l18.349,0.02c82.601,0.084,324.77,0.333,366.13,0.973
C422.792,69.976,423.422,86.449,424.895,104.014z
    `,scale:g/20},breakoutbrick:{baseSvg:Kn(Ht,Ft,zn)},diamond:{baseSvg:"M197.6 42.4 42.4 197.6a60 60 0 0 0 0 84.8l155.2 155.2a60 60 0 0 0 84.8 0l155.2-155.2a60 60 0 0 0 0-84.8L282.4 42.4a60 60 0 0 0-84.8 0Z",scale:g/40},star:{baseSvg:"M256 38.013c-22.458 0-66.472 110.3-84.64 123.502-18.17 13.2-136.674 20.975-143.614 42.334-6.94 21.358 84.362 97.303 91.302 118.662 6.94 21.36-22.286 136.465-4.116 149.665 18.17 13.2 118.61-50.164 141.068-50.164 22.458 0 122.9 63.365 141.068 50.164 18.17-13.2-11.056-128.306-4.116-149.665 6.94-21.36 98.242-97.304 91.302-118.663-6.94-21.36-125.444-29.134-143.613-42.335-18.168-13.2-62.182-123.502-84.64-123.502z",scale:g/40},flipper:{baseSvg:"M434.379,261.305c-29.713-7.156-194.105-21.261-201.267,8.46c-7.146,29.705,145.659,91.979,175.372,99.117 c29.713,7.17,59.598-11.119,66.752-40.84C482.397,298.334,464.092,268.443,434.379,261.305z",scale:g/10,xScale:2,rotation:-.25},pawn:{baseSvg:"M11 3C11 3.76835 10.7111 4.46924 10.2361 5H12V7H10.5714L12 12L14 14V16H2V14L4 12L5.42857 7H4V5H5.76389C5.28885 4.46924 5 3.76835 5 3C5 1.34315 6.34315 0 8 0C9.65685 0 11 1.34315 11 3Z",scale:g*.8,isPathReversed:!0},shield:{baseSvg:"M4.35009 13.3929L8 16L11.6499 13.3929C13.7523 11.8912 15 9.46667 15 6.88306V3L8 0L1 3V6.88306C1 9.46667 2.24773 11.8912 4.35009 13.3929Z",scale:g*.8},meeple:{baseSvg:"M11 3C11 3.48237 10.8862 3.93815 10.6839 4.34193L16 7V10H12.5L15 15V16H10L8 12L6 16H1V15L3.5 10H0V7L5.31613 4.34193C5.11384 3.93815 5 3.48237 5 3C5 1.34315 6.34315 0 8 0C9.65685 0 11 1.34315 11 3Z",scale:g*.8,isPathReversed:!0},club:{baseSvg:"M12 4C12 4.25656 11.9758 4.50748 11.9297 4.75061C11.9531 4.75021 11.9765 4.75 12 4.75C14.2091 4.75 16 6.54086 16 8.75C16 10.9591 14.2091 12.75 12 12.75C10.7347 12.75 9.60658 12.1625 8.87361 11.2454L10 15V16H6V15L7.12639 11.2454C6.39342 12.1625 5.26532 12.75 4 12.75C1.79086 12.75 0 10.9591 0 8.75C0 6.54086 1.79086 4.75 4 4.75C4.02349 4.75 4.04692 4.7502 4.07031 4.75061C4.02415 4.50748 4 4.25656 4 4C4 1.79086 5.79086 0 8 0C10.2091 0 12 1.79086 12 4Z",scale:g*.8,isPathReversed:!0},bishop:{baseSvg:`
      M206.873,255.08h-3.41c2.214-3.337,8.32-14.536-0.712-25.6c-8.9-10.905-25.137-39.546-24.448-64.4h3.57
      c4.418,0,7.667-3.582,7.667-8v-1c0-4.418-3.249-8-7.667-8h-4.333v-4.285c13-8.971,20.511-23.502,20.511-39.914
      c0-10.332-7.011-26.11-15.819-41.721l-18.553,18.595c-3.111,3.111-8.182,3.111-11.294,0.001l-0.921-0.933
      c-3.111-3.11-3.106-8.202,0.005-11.313l21.676-21.674c-4.444-7.069-8.869-13.678-12.703-19.224
      c2.881-2.93,4.663-6.944,4.663-11.379C165.106,7.268,157.841,0,148.874,0c-8.967,0-16.234,7.268-16.234,16.233
      c0,4.434,1.781,8.448,4.662,11.379c-14.585,21.101-37.94,57.587-37.94,76.269c0,16.853,8.178,31.724,21.178,40.625v3.574h-4.667
      c-4.418,0-8.333,3.582-8.333,8v1c0,4.418,3.915,8,8.333,8h3.571c0.689,24.855-15.547,53.495-24.448,64.4
      c-9.031,11.064-2.926,22.263-0.712,25.6h-3.411c-4.418,0-8.333,3.582-8.333,8v9c0,4.078,3,7.438,7,7.931v17.069h118v-17.069
      c4-0.493,7-3.853,7-7.931v-9C214.54,258.662,211.291,255.08,206.873,255.08z
    `,scale:g/20},bolt:{baseSvg:"M68.29,52.67c9.12,1.35,17,2.53,24.9,3.65,3.38.48,6.73.55,9.68,2.91,3.44,2.74,4.63,4.57,3.57,8.65-3.81,14.68-7.23,29.48-12.65,43.7-1.84,4.8-3.56,9.65-5.48,14.89,1.62.71,3.08,1.5,4.64,2,7.06,2.33,14.23,4.37,21.2,6.94,5.58,2.06,6.48,4.3,4.73,10-2.86,9.27-5.4,18.69-8.89,27.73A239.29,239.29,0,0,1,87.72,217.6c-4.82,7.43-9.58,14.92-14.78,22.09-3.52,4.84-7.76,9.15-11.65,13.72-1.86,2.17-4.24,2.7-7,2.62-4.32-.13-6.36-1.79-6.44-6.25a102.08,102.08,0,0,1,.57-15.45c2.45-18.15,3.5-36.51,7.9-54.37a12.7,12.7,0,0,0,0-2.32,17.41,17.41,0,0,0-4-2.18c-5-1.34-10-2.33-15-3.6-9.07-2.32-11.17-5.27-9.11-14,2.83-12,6-23.89,9.24-35.75,1.52-5.5,3.71-10.82,5.56-16.23a32.05,32.05,0,0,0,1.66-5.74,2.91,2.91,0,0,0-2.25-3.24,27,27,0,0,0-4.24-.56c-2.56-.25-5.15-.3-7.67-.74a31.24,31.24,0,0,0-9.28-.46c-5.77.7-11.34-.86-16.6-3.42-3.16-1.55-5-3.85-4.69-7.43.46-5.41.52-10.93,1.71-16.19,4.05-17.86,7.89-35.8,14.74-52.89,1.28-3.18,3-6.22,3.88-9.5.91-3.47,3.13-4.49,6.2-4.82a174.2,174.2,0,0,1,43.7,1.18,27.87,27.87,0,0,1,5,1.23c4.67,1.58,5.58,3.21,5.58,8.27,0,6.51-2.66,12.22-5,18.05-.74,1.85-1.71,3.61-2.3,5.49C71.85,40.52,70.28,46,68.29,52.67ZM58.4,238.25l1.55.8a34.62,34.62,0,0,0,3.28-3.59c3.08-4.49,5.93-9.13,9-13.58,13.54-19.39,23.58-40.55,31.76-62.63,2-5.27,3.58-10.73,3.46-16.51-7.72-3.55-15.2-6.18-23.48-5.78-3.82.19-7.45-.34-9.57-4.63.57-1.49,1.07-3.13,1.79-4.66C84.37,110.2,89.47,91.74,94,73.08c.52-2.17,1.54-4.38-.11-7A37,37,0,0,0,89.22,65C80.15,63.9,71.06,62.88,62,61.84c-5.71-.66-7-2.39-5.58-7.88Q57,51.46,57.86,49q4.94-14.16,9.92-28.31c.94-2.64,2.54-5.15,1-8.71a141.83,141.83,0,0,0-39-1.55c-1.45,2.87-3.06,5.31-3.95,8C19.33,38,13.67,57.78,10.5,78.2c-.34,2.18-.89,4.55,1.4,6.89,5.17,1.37,10.94.47,16.59,1,8.56.73,17.12,1.36,25.66,2.21,3.37.33,6,1.92,6.27,5.79-11.07,21.29-17.29,44.07-22.2,67.84,1.94,1,3.57,2.1,5.38,2.59,5,1.33,10,2.36,15,3.56,8.75,2.09,9.69,3.6,8,12.57-1.5,8.16-3.05,16.31-4.43,24.48-.77,4.51-1.33,9.06-1.84,13.61C59.67,225.21,59.06,231.73,58.4,238.25Z",scale:g/18,rotation:.2,isPathReversed:!0},wedge:{baseSvg:`
    M468.616,93.218c-3.098-0.208-6.241,0.759-9.151,2.838c-62.956,45.13-142.625,86.988-219.655,127.465
c-80.443,42.267-163.62,85.962-228.852,133.843c-1.444,1.056-2.676,2.311-3.732,3.813c-5.675,3.447-8.475,10.841-6.693,17.869
c1.742,6.876,7.279,11.141,14.652,11.141c18.969-0.213,39.321-0.31,60.626-0.31c82.428,0,180.474,1.412,266.978,2.65
c42.426,0.6,82.725,1.184,118.225,1.56h0.203c8.664,0,13.122-5.794,14.473-11.385c1.482-2.382,2.244-5.099,2.255-8.109
c0.142-51.064,2.422-98.478,4.616-144.319c1.863-38.899,3.793-79.12,4.483-122.14c0.071-4.253-1.32-7.945-4.017-10.684
C479.559,93.924,473.953,92.281,468.616,93.218z M62.012,358.73c56.312-39.882,128.247-76.327,197.904-111.608
c68.634-34.767,139.553-70.686,195.238-109.804c-0.924,33.352-2.412,64.498-3.85,94.669c-2.066,43.246-4.017,84.14-4.438,130.72
c-27.975-0.335-59.768-0.772-93.45-1.239c-93.521-1.29-199.524-2.747-280.335-2.747C69.327,358.72,65.641,358.725,62.012,358.73z
    `,scale:g/30,xScale:2.5},airplane:{baseSvg:`
    
M321.434,172.558c-11.918-6.391-24.004-11.903-35.963-16.384c-0.097-7.531-0.102-14.97-0.102-22.302
c-0.015-48.505-0.03-94.326-28.619-125.281c-0.34-0.577-0.706-1.123-1.106-1.628c-3.499-4.461-7.648-6.805-12.515-6.962
c-4.55,0.163-8.63,2.501-12.131,6.962c-0.389,0.505-0.759,1.051-1.102,1.623c-28.589,30.956-28.604,76.776-28.62,125.281
c0,7.477-0.005,15.069-0.104,22.75c-2.953,1.48-11.958,4.961-17.054,6.931c-3.605,1.391-6.495,2.516-7.271,2.889
c-8.104,3.905-16.047,8.331-23.605,13.157c-38.298,24.428-55.139,58.93-48.703,99.768c1.508,9.576,6.952,10.318,8.584,10.318
c0.365,0,0.733-0.031,1.097-0.092c1.17,0.289,2.376,0.259,3.562-0.092c11.43-3.412,22.922-7.657,34.032-11.766
c15.48-5.723,31.451-11.628,47.362-15.289c-0.886,14.878,0.77,28.563,2.369,41.832c1.432,11.807,2.902,24.009,2.628,37.171
c-9.044,6.835-18.809,16.869-28.267,26.578c-8.643,8.876-17.58,18.062-25.588,24.358c-3.469,2.728-5.025,7.841-4.202,13.452
c-0.021,0.243-0.038,0.487-0.038,0.751c0,17.062,0,34.714-0.447,52.268c-0.01,0.361-0.061,1.031-0.135,1.925
c-0.785,10.095-1.003,19.992,2.699,23.988c1.123,1.214,2.555,1.854,4.144,1.854c1.285,0,2.663-0.427,4.087-1.274
c11.085-6.581,29.239-24.567,46.799-41.954c15.043-14.898,30.59-30.295,40.091-36.795c9.498,6.5,25.047,21.896,40.088,36.795
c17.56,17.392,35.714,35.378,46.799,41.954c1.152,0.686,2.331,1.031,3.509,1.031c1.463,0,3.605-0.544,5.453-3.134
c2.971-4.184,3.829-12.136,1.98-17.945c-0.533-23.496-0.589-35.403-0.589-58.712c0-0.273-0.015-0.513-0.076-0.533
c0.863-5.834-0.69-10.942-4.158-13.67c-8.014-6.301-16.956-15.482-25.599-24.369c-9.45-9.709-19.215-19.742-28.259-26.572
c-0.274-13.162,1.203-25.365,2.625-37.176c1.6-13.264,3.255-26.949,2.372-41.822c15.909,3.656,31.879,9.566,47.362,15.284
c11.11,4.108,22.602,8.349,34.032,11.766c1.178,0.346,2.392,0.376,3.555,0.087c0.365,0.065,0.736,0.096,1.097,0.096
c1.636,0,7.079-0.746,8.587-10.312c3.936-24.994-0.919-47.66-14.437-67.383C357.167,196.647,341.609,183.384,321.434,172.558z
  M339.257,250.345c-19.84-7.272-40.359-14.792-61.088-18.202c-5.205-0.889-8.709,3.681-9.217,11.268
c-0.751,2.587-0.995,5.38-0.736,8.32c1.671,18.854,0.127,35.673-1.513,53.486c-1.285,13.985-2.615,28.452-2.265,44.077
c0.102,4.661,1.401,8.541,3.676,10.988c0.909,1.89,2.067,3.362,3.453,4.372c8.404,6.14,17.818,15.94,26.918,25.436
c7.983,8.328,16.22,16.92,23.801,23.029c0.021,15.492,0.102,22.571,0.335,36.703c-9.003-7.033-22.53-20.916-35.662-34.413
c-15.077-15.488-29.32-30.112-37.852-35.77c-1.206-0.792-2.447-1.198-3.689-1.198c-0.708,0-1.412,0.132-2.087,0.396
c-1.851-0.721-3.885-0.446-5.776,0.803c-8.539,5.657-22.775,20.281-37.849,35.77c-13.137,13.497-26.657,27.38-35.667,34.413
c0.233-14.132,0.317-21.205,0.337-36.703c7.582-6.109,15.818-14.701,23.8-23.029c9.1-9.485,18.512-19.296,26.921-25.44
c1.381-1.005,2.542-2.478,3.451-4.367c2.267-2.457,3.567-6.337,3.671-10.993c0.355-15.62-0.978-30.087-2.268-44.082
c-1.637-17.804-3.181-34.622-1.513-53.477c0.261-2.94,0.018-5.733-0.727-8.32c-0.515-7.581-4.009-12.151-9.224-11.268
c-20.728,3.41-41.246,10.93-61.093,18.202c-8.419,3.077-17.087,6.256-25.694,9.089c0.594-10.963,4.281-21.383,10.984-31.008
c0.208-0.297,0.383-0.609,0.614-1.036c26.368-25.558,55.274-37.923,80.087-46.654c5.776-2.031,7.363-10.077,5.974-17.085
c0.193-9.569,0.084-19.354-0.02-28.822c-0.457-41.013-0.884-79.752,21.599-103.456c0.625-0.66,1.191-1.447,1.463-2.009
c0.305-0.363,0.617-0.718,0.934-1.046c0.307,0.307,0.561,0.589,0.66,0.65c0.541,0.958,1.115,1.745,1.737,2.405
c22.482,23.699,22.051,62.438,21.594,103.448c-0.102,9.471-0.213,19.256-0.02,28.825c-1.392,7.013,0.197,15.059,5.977,17.085
c24.811,8.727,53.72,21.091,80.084,46.648c0.188,0.354,0.387,0.701,0.62,1.039c6.703,9.633,10.39,20.048,10.983,31.016
C356.35,256.601,347.677,253.422,339.257,250.345z

    
    `,scale:g/30},head:{baseSvg:`
    
    M284.226,0.167c-0.405-0.036-0.761,0.015-1.147,0.01c-0.025,0-0.051-0.01-0.076-0.01
C168.636-3.796,48.425,62.669,58.814,191.272c0.041,0.521,0.17,0.982,0.264,1.467c-0.15,1.331-0.15,2.724,0.173,4.238
c6.271,29.348-3.354,55.149-27.444,73.141c-1.104,0.822-1.95,1.767-2.689,2.752c-2.435,1.6-4.357,4.053-5.393,7.023
c-4.519,12.969-1.086,26.172,9.278,35.195c1.708,1.482,3.687,2.493,5.746,3.036c6.69,3.697,13.685,6.154,20.949,7.871
c-1.493,8.054-0.759,16.198,3.12,23.866c-7.243,14.117-2.435,29.691,11.865,38.191c0.807,0.482,1.612,0.843,2.404,1.122
c2.427,2.89,2.661,7.531,1.767,11.995c-0.277,1.365-0.312,2.731-0.208,4.062c-0.063,1.209-0.025,2.438,0.208,3.677
c3.77,19.773,20.66,30.691,39.986,31.042c1.041,0.021,2.001-0.087,2.907-0.27c0.894,0.041,1.831-0.01,2.798-0.167
c31.037-5.033,66.375-2.22,78.033,31.869c2.331,6.81,8.559,9.12,14.14,8.221c1.881,1.412,4.357,2.214,7.478,1.996
c56.241-3.931,111.987-12.101,167.83-19.596c1.976-0.265,3.687-0.904,5.164-1.809c6.77-2.112,12.238-9.688,7.866-17.854
c-37.313-69.568,38.328-145.464,52.684-212.295c0.315-1.445,0.32-2.783,0.193-4.058C473.106,116.222,397.155,10.338,284.226,0.167
z M434.112,221.092c-0.147,1.016-0.167,1.988-0.111,2.922c-15.595,71.509-83.984,140.64-56.909,215.515
c-50.855,6.906-101.676,13.995-152.903,17.58c-0.363,0.025-0.68,0.122-1.028,0.178c-18.309-40.751-60.91-48.058-103.06-41.675
c-0.421-0.051-0.812-0.143-1.264-0.152c-4.799-0.092-7.305-0.589-11.05-2.874c0.328,0.102-1.924-1.696-1.904-1.666
c-0.322-0.325-0.523-0.518-0.67-0.645c0-0.097-0.129-0.386-0.602-1.153c-0.713-1.143-1.239-2.752-1.676-4.57
c2.173-15.01-2.089-28.05-14.667-37.647c-1.011-0.767-2.143-1.198-3.313-1.483c-0.363-0.305-0.716-0.599-1.097-0.984
c0.069,0.03,0.005-0.122-0.213-0.473c0-0.31-0.021-0.411-0.056-0.381c0.15-0.649,0.294-1.3,0.523-1.93
c0.005-0.025,1.831-2.858,2.435-3.712c1.688-2.382,2.034-5.271,1.503-8.049c0.502-2.741,0.145-5.605-1.503-7.992
c-4.633-6.713-3.722-12.426,0-19.484c5.33-10.101-4.271-19.321-12.776-18.377c-0.089-0.011-0.168-0.041-0.254-0.056
c-8.628-1.138-16.968-3.662-24.445-8.13c-0.536-0.315-1.062-0.508-1.587-0.747c-0.374-0.543-0.721-1.097-1.034-1.67
c-0.053-0.158-0.094-0.295-0.167-0.519c-0.061-0.284-0.104-0.472-0.145-0.655c-0.021-0.563-0.005-1.117,0.02-1.681
c0.041-0.152,0.12-0.503,0.224-1.046c31.115-24.313,44.48-57.731,36.909-96.791c0.015-0.49,0.066-0.947,0.025-1.468
C73.978,75.679,181.521,21.155,282.997,24.668c0.32,0.01,0.604-0.046,0.914-0.056c0.112,0.01,0.203,0.045,0.314,0.056
C380.565,33.347,447.838,127.304,434.112,221.092z
    
    `,scale:g/40},note:{baseSvg:`
    
    M449.997,258.475c-59.107-20.507-88.519-73.582-116.605-125.565c-19.367-35.853-39.964-72.564-70.421-100.3
C247.736,18.736,231.479,9.453,211.612,4c-9.397-2.58-54.38-11.669-53.197,10.847c2.95,55.807,2.612,111.715,1.503,167.566
c-0.551,27.789-1.31,55.57-1.95,83.359c-0.566,24.567,2.283,51.501-1.658,75.764c0.551-3.387-43.713-8.155-47.413-8.236
c-17.549-0.411-35.353,2.122-51.572,9.054c-40.865,17.463-50.292,63.15-21.386,98.975c54.162,67.131,146.604,32.316,197.485-18.59
c0.744-0.746,1.356-1.514,1.876-2.295c2.193-2.148,3.712-5.124,3.859-9.019c3.052-82.446,2.109-164.923,1.855-247.399
c52.631,47.477,96.982,105.49,170.217,119.18c1.803,1.016,3.925,1.676,6.479,1.712c7.394,0.106,14.188,1.62,21.546,3.112
c5.377,1.087,10.831-0.559,14.096-4.57C461.337,278.167,462.129,262.689,449.997,258.475z M237.017,125.562
c-11.56-8.978-27.18,3.501-22.973,13.967c0.074,88.705,1.46,177.419-1.617,266.091c-39.694,38.583-105.797,69.167-152.042,22.907
c-11.291-11.289-19.205-29.306-11.372-44.575c10.247-19.997,38.315-24.206,60.229-25.176c19.357,0.096,37.339,6.565,54.04,17.62
c9.887,6.541,19.261-2.179,19.708-11.42c0.317-1.163,0.541-2.402,0.541-3.794c0-86.889,4.446-173.715,4.047-260.604
c-0.109-23.8-3.397-49.041-1.3-72.623c0.269-3.047,35.472,9.371,38.057,10.707C237.058,45.24,248.544,54.5,258.34,64.9
c34.637,36.78,54.299,85.082,80.612,127.599c11.44,18.486,24.593,36.498,40.101,51.828
C323.881,217.798,286.04,163.656,237.017,125.562z
    
    `,scale:g/40,rotation:-.2}};function Kn(n,t,e){const i=n/2,s=t/2;return`M${-i+e},${s} L${i-e},${s} Q${i},${s} ${i},${s-e} L${i},${-s+e} Q${i},${-s} ${i-e},${-s} L${-i+e},${-s} Q${-i},${-s} ${-i},${-s+e} L${-i},${s-e} Q${-i},${s} ${-i+e},${s} Z`}const Ot=100,Un=n=>(Math.floor(n*Ot/ot)%Ot+Ot)%Ot,_e=class _e extends _{constructor(){super(...arguments);d(this,"shape","roundrect");d(this,"blobHash","");d(this,"blobUrl","");d(this,"obsOffsetDetailX",1);d(this,"obsOffsetDetailY",1);d(this,"maxOffsetX",1);d(this,"maxOffsetY",1);d(this,"detail",[this.obsOffsetDetailX*2+1,this.obsOffsetDetailY*2+1]);d(this,"offsetToXIndex",e=>Math.floor(e/U));d(this,"offsetToYIndex",e=>Math.floor(e/U));d(this,"indexToXOffset",e=>e*U);d(this,"indexToYOffset",e=>e*U)}computeAll(){const e=kt[this.shape],{baseSvg:i}=e;let s=0,o=0;const r=me(i);be(r,e);for(const a of r){const[l,c]=a.map(h=>Math.abs(h));l>s&&(s=l),c>o&&(o=c)}s+=S,o+=S,s=Math.floor(s/U),o=Math.floor(o/U),this.obsOffsetDetailX=s,this.obsOffsetDetailY=o,this.maxOffsetX=s*U,this.maxOffsetY=o*U,this.detail=[this.obsOffsetDetailX*2+1,this.obsOffsetDetailY*2+1],super.computeAll()}async loadAll(){await super.loadAll()}computeLeaf(e){const i=this.indexToXOffset(e[0]-this.obsOffsetDetailX),s=this.indexToYOffset(e[1]-this.obsOffsetDetailY);return Qn(this.shape,[i,s])}};_.register("obstacle-lut",{factory:()=>new _e,depth:2,leafLength:3});let gi=_e;const Qt={};function Wn(n){if(!Object.hasOwn(Qt,n)){const t=qn(n);Qt[n]=t}return Qt[n]}function me(n){const t=jn(n,.05)[0];let e=1/0,i=-1/0,s=1/0,o=-1/0;for(const l of t){const[c,h]=l;c>i&&(i=c),c<e&&(e=c),h>o&&(o=h),h<s&&(s=h)}const r=(e+i)/2,a=(s+o)/2;for(const l of t)l[0]-=r,l[1]-=a;return t}function qn(n){const t=kt[n],{baseSvg:e,scale:i=1,xScale:s=1,yScale:o=1,isPathReversed:r=!1}=t;let a=me(e);const l=S/10/i/Math.max(s,o);let c=!0;for(;c;){c=!1;const h=[];for(let f=0;f<a.length;f++){const u=a[f],p=a[(f+1)%a.length];h.push(u);const b=p[0]-u[0],y=p[1]-u[1];if(b*b+y*y>l*l){const m=[(u[0]+p[0])/2,(u[1]+p[1])/2];h.push(m),c=!0}}a=h}return be(a,t),r&&a.reverse(),a}function be(n,t){const{rotation:e=0,scale:i=1,xScale:s=1,yScale:o=1}=t;for(const r of n){const[a,l]=r,c=Math.cos(e),h=Math.sin(e);r[0]=(a*c-l*h)*i*s,r[1]=(a*h+l*c)*i*o}}function Qn(n,t){const e=Wn(n),i=Zn(t,e);let s=1/0,o=0;for(const[a,l]of e.entries()){const c=l[0]-t[0],h=l[1]-t[1],f=c*c+h*h;f<s&&(s=f,o=a)}const r=Math.sqrt(s);if(i||r<S){const a=e.length,l=e[(o+1)%a],c=e[(o-1+a)%a],h=Math.atan2(c[1]-l[1],c[0]-l[0])-Ts,f=S-r,u=[Math.round(f*Math.cos(h)),Math.round(f*Math.sin(h))];return[u[0],u[1],Un(h)]}else return null}function Zn(n,t){const[e,i]=n;let s=!1;for(let o=0;o<t.length;o++){const r=(o+1)%t.length,a=t[o][0],l=t[o][1],c=t[r][0],h=t[r][1];l>i!=h>i&&e<(c-a)*(i-l)/(h-l)+a&&(s=!s)}return s}const mi=10,G=class G{static setSeed(t){G.nextInt=yi(t)}static blinkBarrier(t){(G.nextInt()>>>0)%1e3===0&&(t.isHidden=!t.isHidden)}static reverseObstacle(t){(G.nextInt()>>>0)%1e3===0&&(t.vel[0]*=-1)}static perturbDisk(t){if(Math.abs(t.dx)>mi){const e=(G.nextInt()>>>0)%6;e===0?t.dx+=1:e===1&&(t.dx-=1)}if(Math.abs(t.dy)>mi){const e=(G.nextInt()>>>0)%6;e===0?t.dy+=1:e===1&&(t.dy-=1)}}};d(G,"nextInt",yi(bi())),d(G,"randomSeed",bi);let T=G;function bi(){return Math.floor(Math.random()*32e3)}function yi(n){let t=n|0;return t===0&&(t=1),function(){return t^=t<<13,t^=t>>>17,t^=t<<5,t|0}}class zt{constructor(t,e,i,s){d(this,"boundingRect");d(this,"collisionRect");d(this,"points");d(this,"isStatic",!0);d(this,"vel",[100,0]);d(this,"minX",20*g);d(this,"maxX",80*g);d(this,"_isFlippedX",!1);d(this,"isHidden",!1);d(this,"label",null);this.pos=t,this.shape=e,this.lut=i,this.room=s;const o=kt[e],{baseSvg:r}=o;this.points=me(r),be(this.points,o),this.collisionRect=[t[0]-i.maxOffsetX,t[1]-i.maxOffsetY,2*i.maxOffsetX,2*i.maxOffsetY],this.boundingRect=this.collisionRect}set isFlippedX(t){this._isFlippedX=t,this._isFlippedX&&Gn(this)}get isFlippedX(){return this._isFlippedX}step(){if(this.isStatic)return;T.reverseObstacle(this);const{pos:t,vel:e,minX:i,maxX:s,lut:o}=this;(e[0]<0&&t[0]<i||e[0]>0&&t[0]>s)&&(e[0]*=-1),t[0]+=e[0],t[1]+=e[1],this.collisionRect[0]=t[0]-o.maxOffsetX,this.collisionRect[1]=t[1]-o.maxOffsetY}}function Gn(n){const{points:t}=n;for(const e of t)e[0]=-e[0]}const Jn=[[[15*g,100*g],"flipper",!0],[[85*g,100*g],"flipper"]];class H{constructor(){d(this,"name","");d(this,"bounds",{})}wedges(){return Jn.map(([t,e,i])=>{const s=new zt([t[0],t[1]+this.bounds[1]],e,_.create("obstacle-lut",e),this);return i&&(s.isFlippedX=!0),s})}obstacleHit(t){}static register(t,e){if(t in this._registry)throw new Error(`Room already registered: '${t}'`);this._registry[t]=e}static create(t,e){if(!(t in this._registry))throw new Error(`room not registered: ${t}`);const i=this._registry[t],s=i();return s.bounds=e,s.name=t,s}}d(H,"_registry",{});const gs=10,ms=10,to=10,bs=ms+100*At+gs*(At-1)+to,wi=50,eo=[0,bs-wi,100,wi],Tt=1,io=[Tt,Tt,100-2*Tt,bs-2*Tt].map(n=>n*g);class so{constructor(){d(this,"rooms");this.rooms=Array.from({length:At},(t,e)=>{const s=[0,g*(ms+(100+gs)*e),100*g,100*g];return no(e,s)})}get finish(){return eo}get bounds(){return io}buildObstacles(){const t=[];for(const[e,i]of this.rooms.entries())t.push(...i.buildObstacles());return t}}function no(n,t){if(n===0)return H.create("start-room",t);if(n===At-1)return H.create("finish-room",t);const e=T.nextInt()>>>0,i=xi[e%xi.length];return H.create(i,t)}const xi=["basic-room","breakout-room"];class oo{constructor(t,e,i,s){d(this,"isHidden",!1);d(this,"xr");d(this,"yr");d(this,"xywh");t=Math.floor(t),e=Math.floor(e),i=Math.floor(i),s=Math.floor(s),this.xywh=[t,e,i,s],this.xr=[t-S,t+i+S],this.yr=[e-S,e+s+S]}advance(){}isTouchingDisk(t,e){return t>this.xr[0]&&t<this.xr[1]&&e>this.yr[0]&&e<this.yr[1]}isCornerTouchingDisk(){}draw(t){t.fillRect(...this.xywh)}}const ro=100,V=20,ys=ro*V,vi=n=>Math.floor(n*V/ys),Si=n=>n*ys/V,q=10,ws=2*S,Ai=n=>Math.floor(n*q/ws),ki=n=>n*ws/q,Ee=class Ee extends _{constructor(){super(...arguments);d(this,"blobUrl",tt.DISK_DISK_LUT.url);d(this,"blobHash",tt.DISK_DISK_LUT.hash);d(this,"detail",[q*2+1,q*2+1,V*2+1,V*2+1])}computeLeaf(e){const i=ki(e[0]-q),s=ki(e[1]-q),o=Si(e[2]-V),r=Si(e[3]-V);return ao(i,s,o,r)}};_.register("disk-disk-lut",{depth:4,leafLength:4,factory:()=>new Ee});let Ci=Ee;function ao(n,t,e,i){const s=n*n+t*t,o=S*2;if(s<o*o){const r=Math.sqrt(s)||1,a=o-r,l=n/r,c=t/r,h=a/2,f=e*l+i*c;if(f>0)return null;const u=2*f/2;return[Math.round(l*h),Math.round(c*h),-Math.round(u*l),-Math.round(u*c)]}return null}function lo(n,t){const e=Ai(t.currentState.x-n.currentState.x),i=Ai(t.currentState.y-n.currentState.y);if(Math.abs(e)>q||Math.abs(i)>q)return!1;let s=vi(t.currentState.dx-n.currentState.dx),o=vi(t.currentState.dy-n.currentState.dy);Math.abs(s)>V&&(s=V*Math.sign(s)),Math.abs(o)>V&&(o=V*Math.sign(o));const r=_.create("disk-disk-lut").tree[e+q][i+q][s+V][o+V];if(!r)return!1;const[a,l,c,h]=r;if(r.some(f=>isNaN(f)))throw new Error("collisions has nan bounce value");return n.nextState.x-=a,n.nextState.y-=l,t.nextState.x+=a,t.nextState.y+=l,n.nextState.dx-=c,n.nextState.dy-=h,t.nextState.dx+=c,t.nextState.dy+=h,!0}const jt=[];for(let n=0;n<5;n++)for(let t=0;t<2;t++)jt.length!==yt&&jt.push([20+n*10,20+t*10,500-n*10,500+n*5]);if(jt.length!==yt)throw new Error("wrong disk count");class xs{constructor(t){d(this,"level");d(this,"disks");d(this,"obstacles");d(this,"finish");d(this,"branchSeed",-1);d(this,"winningDiskIndex",-1);d(this,"maxBallY",-1/0);d(this,"_stepCount",0);d(this,"t",0);T.setSeed(t),this.level=new so;let e=0;this.disks=jt.map(i=>{const s=[...i];s[0]*=g,s[1]*=g;const o=St.fromJson(s);return o.pattern=ie[e%ie.length],e++,o}),this.obstacles=this.level.buildObstacles(),this.finish=new oo(...this.level.finish.map(i=>i*g))}get stepCount(){return this._stepCount}step(){this._stepCount++;for(const t of this.obstacles)t.step();for(let t=1;t<this.disks.length;t++)for(let e=0;e<t;e++)lo(this.disks[t],this.disks[e]);for(const[t,e]of this.disks.entries())e.advance(this.obstacles),e.pushInBounds(this.level.bounds),T.perturbDisk(e.nextState),e.nextState.dy+=1,this.winningDiskIndex===-1&&this.finish.isTouchingDisk(e.nextState.x,e.nextState.y)&&(this.winningDiskIndex=t),e.nextState.y>this.maxBallY&&(this.maxBallY=e.nextState.y);St.flushStates(this.disks),St.updateHistory(this.disks),this._stepCount===J&&this.branchSeed!==-1&&T.setSeed(this.branchSeed)}update(t,e=!0){this.t+=t;const i=Math.ceil(this.t/vt),s=(this.t-(i-1)*vt)/vt;for(;this._stepCount<i;){if(!e&&this.stepCount>=J-2){this.t=vt*(J-2);break}this.step()}for(const o of this.disks)o.stepFrac=s,o.interpolatedPos[0]=Vt(o.lastStepPos[0],o.currentState.x,s),o.interpolatedPos[1]=Vt(o.lastStepPos[1],o.currentState.y,s)}}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class Q{constructor(t,e,i,s,o="div"){this.parent=t,this.object=e,this.property=i,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(o),this.domElement.classList.add("controller"),this.domElement.classList.add(s),this.$name=document.createElement("div"),this.$name.classList.add("name"),Q.nextNameID=Q.nextNameID||0,this.$name.id=`lil-gui-name-${++Q.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",r=>r.stopPropagation()),this.domElement.addEventListener("keyup",r=>r.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(i)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class co extends Q{constructor(t,e,i){super(t,e,i,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function ce(n){let t,e;return(t=n.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=n.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=n.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const ho={isPrimitive:!0,match:n=>typeof n=="string",fromHexString:ce,toHexString:ce},Ct={isPrimitive:!0,match:n=>typeof n=="number",fromHexString:n=>parseInt(n.substring(1),16),toHexString:n=>"#"+n.toString(16).padStart(6,0)},uo={isPrimitive:!1,match:n=>Array.isArray(n),fromHexString(n,t,e=1){const i=Ct.fromHexString(n);t[0]=(i>>16&255)/255*e,t[1]=(i>>8&255)/255*e,t[2]=(i&255)/255*e},toHexString([n,t,e],i=1){i=255/i;const s=n*i<<16^t*i<<8^e*i<<0;return Ct.toHexString(s)}},fo={isPrimitive:!1,match:n=>Object(n)===n,fromHexString(n,t,e=1){const i=Ct.fromHexString(n);t.r=(i>>16&255)/255*e,t.g=(i>>8&255)/255*e,t.b=(i&255)/255*e},toHexString({r:n,g:t,b:e},i=1){i=255/i;const s=n*i<<16^t*i<<8^e*i<<0;return Ct.toHexString(s)}},po=[ho,Ct,uo,fo];function go(n){return po.find(t=>t.match(n))}class mo extends Q{constructor(t,e,i,s){super(t,e,i,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=go(this.initialValue),this._rgbScale=s,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const o=ce(this.$text.value);o&&this._setValueFromHexString(o)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class Zt extends Q{constructor(t,e,i){super(t,e,i,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",s=>{s.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class bo extends Q{constructor(t,e,i,s,o,r){super(t,e,i,"number"),this._initInput(),this.min(s),this.max(o);const a=r!==void 0;this.step(a?r:this._getImplicitStep(),a),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let w=parseFloat(this.$input.value);isNaN(w)||(this._stepExplicit&&(w=this._snap(w)),this.setValue(this._clamp(w)))},i=w=>{const M=parseFloat(this.$input.value);isNaN(M)||(this._snapClampSetValue(M+w),this.$input.value=this.getValue())},s=w=>{w.key==="Enter"&&this.$input.blur(),w.code==="ArrowUp"&&(w.preventDefault(),i(this._step*this._arrowKeyMultiplier(w))),w.code==="ArrowDown"&&(w.preventDefault(),i(this._step*this._arrowKeyMultiplier(w)*-1))},o=w=>{this._inputFocused&&(w.preventDefault(),i(this._step*this._normalizeMouseWheel(w)))};let r=!1,a,l,c,h,f;const u=5,p=w=>{a=w.clientX,l=c=w.clientY,r=!0,h=this.getValue(),f=0,window.addEventListener("mousemove",b),window.addEventListener("mouseup",y)},b=w=>{if(r){const M=w.clientX-a,it=w.clientY-l;Math.abs(it)>u?(w.preventDefault(),this.$input.blur(),r=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(M)>u&&y()}if(!r){const M=w.clientY-c;f-=M*this._step*this._arrowKeyMultiplier(w),h+f>this._max?f=this._max-h:h+f<this._min&&(f=this._min-h),this._snapClampSetValue(h+f)}c=w.clientY},y=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",b),window.removeEventListener("mouseup",y)},x=()=>{this._inputFocused=!0},m=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",s),this.$input.addEventListener("wheel",o,{passive:!1}),this.$input.addEventListener("mousedown",p),this.$input.addEventListener("focus",x),this.$input.addEventListener("blur",m)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(m,w,M,it,gt)=>(m-w)/(M-w)*(gt-it)+it,e=m=>{const w=this.$slider.getBoundingClientRect();let M=t(m,w.left,w.right,this._min,this._max);this._snapClampSetValue(M)},i=m=>{this._setDraggingStyle(!0),e(m.clientX),window.addEventListener("mousemove",s),window.addEventListener("mouseup",o)},s=m=>{e(m.clientX)},o=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",s),window.removeEventListener("mouseup",o)};let r=!1,a,l;const c=m=>{m.preventDefault(),this._setDraggingStyle(!0),e(m.touches[0].clientX),r=!1},h=m=>{m.touches.length>1||(this._hasScrollBar?(a=m.touches[0].clientX,l=m.touches[0].clientY,r=!0):c(m),window.addEventListener("touchmove",f,{passive:!1}),window.addEventListener("touchend",u))},f=m=>{if(r){const w=m.touches[0].clientX-a,M=m.touches[0].clientY-l;Math.abs(w)>Math.abs(M)?c(m):(window.removeEventListener("touchmove",f),window.removeEventListener("touchend",u))}else m.preventDefault(),e(m.touches[0].clientX)},u=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",f),window.removeEventListener("touchend",u)},p=this._callOnFinishChange.bind(this),b=400;let y;const x=m=>{if(Math.abs(m.deltaX)<Math.abs(m.deltaY)&&this._hasScrollBar)return;m.preventDefault();const M=this._normalizeMouseWheel(m)*this._step;this._snapClampSetValue(this.getValue()+M),this.$input.value=this.getValue(),clearTimeout(y),y=setTimeout(p,b)};this.$slider.addEventListener("mousedown",i),this.$slider.addEventListener("touchstart",h,{passive:!1}),this.$slider.addEventListener("wheel",x,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:i}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,i=-t.wheelDelta/120,i*=this._stepExplicit?1:10),e+-i}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class yo extends Q{constructor(t,e,i,s){super(t,e,i,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(s)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const i=document.createElement("option");i.textContent=e,this.$select.appendChild(i)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class wo extends Q{constructor(t,e,i){super(t,e,i,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",s=>{s.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var xo=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function vo(n){const t=document.createElement("style");t.innerHTML=n;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let _i=!1;class ye{constructor({parent:t,autoPlace:e=t===void 0,container:i,width:s,title:o="Controls",closeFolders:r=!1,injectStyles:a=!0,touchStyles:l=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(o),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),l&&this.domElement.classList.add("allow-touch-styles"),!_i&&a&&(vo(xo),_i=!0),i?i.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),s&&this.domElement.style.setProperty("--width",s+"px"),this._closeFolders=r}add(t,e,i,s,o){if(Object(i)===i)return new yo(this,t,e,i);const r=t[e];switch(typeof r){case"number":return new bo(this,t,e,i,s,o);case"boolean":return new co(this,t,e);case"string":return new wo(this,t,e);case"function":return new Zt(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,r)}addColor(t,e,i=1){return new mo(this,t,e,i)}addFolder(t){const e=new ye({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(i=>{i instanceof Zt||i._name in t.controllers&&i.load(t.controllers[i._name])}),e&&t.folders&&this.folders.forEach(i=>{i._title in t.folders&&i.load(t.folders[i._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(i=>{if(!(i instanceof Zt)){if(i._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${i._name}"`);e.controllers[i._name]=i.save()}}),t&&this.folders.forEach(i=>{if(i._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${i._title}"`);e.folders[i._title]=i.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const i=o=>{o.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",i))};this.$children.addEventListener("transitionend",i);const s=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=s+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(i=>i.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let de={},dt;function So(n,t){de={},dt&&dt.destroy(),dt=new ye({closeFolders:!0,container:document.getElementById("controls-container")}),vs(dt,t,n),dt.onOpenClose(()=>{dt._closed&&setTimeout(()=>{dt.destroy()},200)})}function vs(n,t,e){const i=t.children;for(const s in i){const o=i[s];if(!("isHidden"in o&&o.isHidden))if("action"in o){const r=o,a=o.label??Bt(s),l={[a]:async()=>{await r.action(e)}};n.add(l,a)}else if("options"in o&&Array.isArray(o.options)){const r=o,a={};for(const c of r.options)typeof c=="string"&&(a[c]=c);const l=n.add(r,"value",a).name(r.label??Bt(s)).listen();l.onChange(c=>{r.value=c,r.onChange&&r.onChange(e,c)}),Gt(l,r.tooltip),de[s]=l}else if("value"in o&&typeof o.value=="number"){const r=o,a=n.add(r,"value",r.min,r.max).name(r.label??Bt(s));r.step&&a.step(r.step),a.onChange(l=>{typeof l=="number"&&(r.value=l,r.onChange&&r.onChange(e,l))}),Gt(a,r.tooltip),de[s]=a}else{const r=n.addFolder(o.label??Bt(s));Gt(r,o.tooltip),vs(r,o,e)}}}function Gt(n,t){if(typeof t!="string"||t.trim()==="")return;n.domElement.setAttribute("title",t)}function Bt(n){return/^[A-Z0-9_]+$/.test(n)?n.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():n.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}let Ei=!1,Mi=!1;class Ao{constructor(){d(this,"activeSim");d(this,"gui");d(this,"loadingState","A");d(this,"isTitleScreen",!0);d(this,"selectedDiskIndex",-1);d(this,"currentRoomIndex",0);d(this,"camera",new hi);d(this,"_speed","normal");d(this,"isSeedConfiged",!1);d(this,"_race",[]);d(this,"_speedMult",ut.normal);d(this,"_speedAnim",null);d(this,"_isHalted",!1);d(this,"_speedBeforeHalt","normal");d(this,"mousePos",[0,0]);d(this,"simMousePos",[0,0]);d(this,"simViewRect",[1,1,1,1]);d(this,"hoveredDiskIndex",-1);d(this,"isMouseDown",!1);d(this,"dragY",0);d(this,"didBuildControls",!1);if(Ei)throw new Error("PinballWizard constructed multiple times");Ei=!0}get speed(){return this._speed}set speed(t){if(this._isHalted)return;this._speed=t;const e=ut[t];this._speedMult===e?this._speedAnim=null:this._speedAnim={startTime:performance.now(),endTime:performance.now()+D.flatConfig.speedAnimDur,startSpeed:this._speedMult}}async init(){if(Mi)throw new Error("PinballWizard initialized multiple times");Mi=!0,window.addEventListener("resize",()=>this.onResize()),this.reset()}reset(){this.selectedDiskIndex=-1,this.currentRoomIndex=0,this.camera=new hi,this._isHalted=!1,this._speedMult=ut.normal,this._speed="normal",this._speedBeforeHalt="normal";const t=D.flatConfig.rngSeed;this.isSeedConfiged=t!==-1;const e=_.create("race-lut").tree;this._race=e[Math.floor(Math.random()*e.length)];const i=this.isSeedConfiged?t:this._race[0];Hs(ie),this.activeSim=new xs(i),this.isSeedConfiged||(this.activeSim.branchSeed=this._race[1]),this.gui=et.create("playing-gui"),this.camera.jumpToRoom(this,0),N.isRepaintQueued=!0,this.onResize()}get isHalted(){return this._isHalted}update(t){const e=this.hasBranched,i=this.hasFinished;if(!this._isHalted&&this.activeSim.stepCount>=J-Ps&&this.selectedDiskIndex===-1&&(this._speed!=="paused"&&(this._speedBeforeHalt=this._speed,this.speed="paused"),this._speedMult===0&&(this._isHalted=!0)),this._speedAnim){const{startSpeed:r,startTime:a,endTime:l}=this._speedAnim,h=(performance.now()-a)/(l-a);h>=1?(this._speedMult=ut[this._speed],this._speedAnim=null):this._speedMult=Vt(r,ut[this._speed],h)}!this._isHalted&&this.activeSim.stepCount>=J-5&&this.selectedDiskIndex===-1&&(this._speed!=="paused"&&(this._speedBeforeHalt=this._speed),this._isHalted=!0,this._speedMult=0,this._speed="paused",this._speedAnim=null,this.onResize());const s=this.selectedDiskIndex!==-1;this.activeSim.update(t*this._speedMult,s),this.activeSim.winningDiskIndex!==-1&&(this._speed="paused",this._isHalted=!0,this._speedMult=0),this.hasBranched&&!e&&N.hide(),this.hasFinished&&!i&&this.onResize(),this.camera.update(t,this),v.drawOffset[1]=this.camera.pos*v.drawSimScale+v.cvs.height/2,v.drawSim(this),j.isRepaintQueued=!0,j.isRepaintQueued&&(j.isRepaintQueued=!1,j.repaint(this)),N.isRepaintQueued=!0,N.isRepaintQueued&&(N.isRepaintQueued=!1,N.repaint(this)),this.debugBranchCountdown(v.ctx,v.cvs.width,v.cvs.height);const o=this.currentRoomIndex+1;o<At&&this.activeSim.maxBallY>this.activeSim.level.rooms[o].bounds[1]&&(this.currentRoomIndex=o,this.camera.jumpToRoom(this,this.currentRoomIndex)),this.gui.update(this,t)}get hasBranched(){return this.activeSim.stepCount>=J}get hasFinished(){return this.activeSim.winningDiskIndex!==-1}debugBranchCountdown(t,e,i){const o=Math.min(1,this.activeSim.stepCount/J);t.fillStyle="white",t.fillRect(0,0,e,20),t.fillStyle="black",t.fillRect(0,0,e*o,20)}locateDiskOnScreen(t){const e=this.activeSim.disks[t],[i,s]=e.interpolatedPos,o=S*g*v.drawSimScale,r=v.drawOffset[0]+i*v.drawSimScale,a=v.drawOffset[1]+s*v.drawSimScale;return[r-o+v.cssLeft,a-o,2*o,2*o]}move(t){this.isMouseDown&&(this.camera.drag(this.dragY,t[1]),this.dragY=t[1]);const{drawOffset:e,drawSimScale:i}=v;this.mousePos[0]=t[0]-e[0],this.mousePos[1]=t[1]-e[1];const s=t[0]/i*window.devicePixelRatio-e[0]/i,o=t[1]/i*window.devicePixelRatio-e[1]/i;return this.simMousePos[0]=s,this.simMousePos[1]=o,this.hoveredDiskIndex=this.getHoveredDiskIndex(),this.hoveredDiskIndex===-1||this.hasBranched||this.hoveredDiskIndex===this.selectedDiskIndex?v.cvs.style.setProperty("cursor","default"):v.cvs.style.setProperty("cursor","pointer"),this.mousePos}down(t){this.move(t),this.isMouseDown=!0,this.dragY=t[1],this.trySelectDisk(this.hoveredDiskIndex),v.cvs.style.setProperty("cursor","default")}trySelectDisk(t){t!==-1&&(this.hasBranched||(this.selectedDiskIndex=t,N.isRepaintQueued=!0,this._isHalted&&(this._isHalted=!1,this.speed=this._speedBeforeHalt),this.isSeedConfiged||(this.activeSim.branchSeed=this._race[t+1])))}getHoveredDiskIndex(){let t=Ds,e=-1;for(const[i,s]of this.activeSim.disks.entries()){const[o,r]=s.interpolatedPos,a=Math.pow(this.simMousePos[0]-o,2)+Math.pow(this.simMousePos[1]-r,2);a<t&&(t=a,e=i)}return e}up(t){this.isMouseDown=!1,this.camera.endDrag()}rebuildControls(){this.didBuildControls=!0,So(this,Pn.tree)}onResize(){v.onResize(this);for(const t of hs.NAMES){const e=et.create(t),i=e===this.gui;for(const s in e.elements)ne(s,i);this.gui&&this.gui.refreshLayout(this)}this.gui&&this.gui.showHideElements(this)}}const Ss={"four-by-four":[[0,[15e4,14e4]],[0,[38e4,14e4]],[0,[61e4,14e4]],[0,[84e4,14e4]],[0,[15e4,33e4]],[0,[38e4,33e4]],[0,[61e4,33e4]],[0,[84e4,33e4]],[0,[15e4,52e4]],[0,[38e4,52e4]],[0,[61e4,52e4]],[0,[84e4,52e4]],[0,[15e4,71e4]],[0,[38e4,71e4]],[0,[61e4,71e4]],[0,[84e4,71e4]]],breakout:[[0,[14e4,25e4]],[0,[32e4,25e4]],[0,[5e5,25e4]],[0,[68e4,25e4]],[0,[86e4,25e4]],[0,[14e4,35e4]],[0,[32e4,35e4]],[0,[5e5,35e4]],[0,[68e4,35e4]],[0,[86e4,35e4]],[0,[14e4,45e4]],[0,[32e4,45e4]],[0,[5e5,45e4]],[0,[68e4,45e4]],[0,[86e4,45e4]],[0,[14e4,55e4]],[0,[32e4,55e4]],[0,[5e5,55e4]],[0,[68e4,55e4]],[0,[86e4,55e4]],[0,[14e4,65e4]],[0,[32e4,65e4]],[0,[5e5,65e4]],[0,[68e4,65e4]],[0,[86e4,65e4]],[0,[14e4,75e4]],[0,[32e4,75e4]],[0,[5e5,75e4]],[0,[68e4,75e4]],[0,[86e4,75e4]]],honeycomb:[[0,[39e4,2e5]],[0,[61e4,2e5]],[0,[28e4,42e4]],[1,[5e5,42e4]],[0,[72e4,42e4]],[0,[39e4,64e4]],[0,[61e4,64e4]],[2,[15e4,14e4]],[2,[84e4,14e4]],[2,[15e4,71e4]],[2,[84e4,71e4]]],"three-by-three":[[0,[23e4,2e5]],[0,[5e5,2e5]],[0,[77e4,2e5]],[0,[23e4,42e4]],[0,[5e5,42e4]],[0,[77e4,42e4]],[0,[23e4,64e4]],[0,[5e5,64e4]],[0,[77e4,64e4]]]},Me=class Me extends H{buildObstacles(){const t=(T.nextInt()>>>0)%10>8,e=ko(),i=Ss[e],s={},o=i.map(r=>{const a=r[0],l=r[1];let c;t?c=Ri():(Object.hasOwn(s,a)||(s[a]=Ri()),c=s[a]);const h=new zt([l[0],l[1]+this.bounds[1]],c,_.create("obstacle-lut",c),this);return(T.nextInt()>>>0)%2&&(h.isFlippedX=!0),h});return[...this.wedges(),...o]}};H.register("basic-room",()=>new Me);let $i=Me;const Li=["honeycomb","three-by-three","four-by-four"];function ko(){return Li[(T.nextInt()>>>0)%Li.length]}const Ii=["diamond","star","pawn","shield","meeple","club","bishop","bolt","airplane","head","note"];function Ri(){return Ii[(T.nextInt()>>>0)%Ii.length]}const $e=class $e extends H{constructor(){super(...arguments);d(this,"score",0);d(this,"hitSequence",[]);d(this,"breakoutBricks",[])}static solve(e){return _n(e)}obstacleHit(e){const i=this.breakoutBricks.indexOf(e);if(i===-1)return;if(e.isHidden=!0,j.isRepaintQueued=!0,this.hitSequence.includes(i))throw new Error("brick has already been hit");this.hitSequence.push(i);const s=Number(e.label);this.score+=s}buildObstacles(){const e=Ss.breakout,i="breakoutbrick";return this.breakoutBricks=e.map(([s,o])=>new zt([o[0],o[1]+this.bounds[1]],i,_.create("obstacle-lut",i),this)),[...this.wedges(),...this.breakoutBricks]}};H.register("breakout-room",()=>new $e);let Di=$e;const Le=class Le extends H{buildObstacles(){return[]}};H.register("finish-room",()=>new Le);let Pi=Le;const As=[],Co=20;let Jt=20;for(;Jt<100;)As.push([[50,Jt],"roundrect"]),Jt+=Co;const Ie=class Ie extends H{buildObstacles(){const t=As.map(([e,i])=>{const s=new zt([e[0]*g,e[1]*g+this.bounds[1]],i,_.create("obstacle-lut",i),this);return s.isStatic=!1,(T.nextInt()>>>0)%2&&(s.isFlippedX=!0),s});return[...this.wedges(),...t]}};H.register("pong-room",()=>new Ie);let Oi=Ie;const Re=class Re extends H{buildObstacles(){return[...this.wedges()]}};H.register("start-room",()=>new Re);let Ti=Re;class Z{constructor(){}static register(t,e){if(t in this._registry)throw new Error(`room layout already registered: '${t}'`);this._registry[t]=e;const i=e();this._singletonLayouts[t]=i}static create(t){if(typeof document<"u")throw new Error("should only be used in build scripts, not in browser");if(!Object.hasOwn(this._singletonLayouts,t))throw new Error(`singleton room layout not registered: ${t}`);return this._singletonLayouts[t]}}d(Z,"_registry",{}),d(Z,"_singletonLayouts",{});const De=class De extends Z{computePositions(){const t=Ht+It,e=Ft+It,i=5,s=6,o=Math.floor(50*g-(i*Ht+(i-1)*It)/2+Ht/2),r=Math.floor(50*g-(s*Ft+(s-1)*It)/2+Ft/2),a=[];for(let l=0;l<s;l++)for(let c=0;c<i;c++)a.push([0,[o+c*t,r+l*e]]);return a}};Z.register("breakout",()=>new De);let Bi=De;const Pe=class Pe extends Z{computePositions(){const o=[];for(let r=0;r<4;r++)for(let a=0;a<4;a++)o.push([0,[15e4+a*23e4,14e4+r*19e4]]);return o}};Z.register("four-by-four",()=>new Pe);let Hi=Pe;const _o=[{count:2,offset:.5},{count:3,offset:0},{count:2,offset:.5}],Oe=class Oe extends Z{computePositions(){const t=22*g,e=22*g,i=S,s=Math.floor(S*.1),o=[];let r=0;for(const x of _o){for(let m=0;m<x.count;m++)o.push([0,[s+i+(x.offset+m)*t,s+i+r*e]]);r++}const a=3,l=o[a][1],c=[50*g,42*g],h=c[0]-l[0],f=c[1]-l[1];for(const x of o)x[1][0]+=h,x[1][1]+=f;o[a][0]=1;const u=23e4,p=19e4,b=15e4,y=14e4;for(let x=0;x<4;x+=3)for(let m=0;m<4;m+=3)o.push([2,[b+m*u,y+x*p]]);return o}};Z.register("honeycomb",()=>new Oe);let Fi=Oe;const Te=class Te extends Z{computePositions(){const o=[];for(let f=0;f<3;f++)for(let u=0;u<3;u++)o.push([0,[15e4+u*27e4,14e4+f*22e4]]);const a=o[4][1],l=[50*g,42*g],c=l[0]-a[0],h=l[1]-a[1];for(const f of o)f[1][0]+=c,f[1][1]+=h;return o}};Z.register("three-by-three",()=>new Te);let Vi=Te;const Yi=100,Ni=1e7,he=1+yt;var Ki,Ui;const Be=class Be extends _{constructor(){super(...arguments);d(this,"detail",[Yi]);d(this,"blobUrl",(Ki=tt.RACE_LUT)==null?void 0:Ki.url);d(this,"blobHash",(Ui=tt.RACE_LUT)==null?void 0:Ui.hash)}computeLeaf(e){for(console.log(`race-lut leaf ${e[0]} / ${Yi}`);;){const i=Eo();if(i)return i}}async loadAll(){await super.loadAll()}};_.register("race-lut",{factory:()=>new Be,depth:1,leafLength:he});let Xi=Be;function Eo(){const n=T.randomSeed(),t=Array.from({length:yt},()=>({midSeed:-1,roomSeqs:[]}));console.log(`attempting to solve race with start seed ${n}...`);let e=0;for(;t.some(({midSeed:s})=>s===-1);){const s=new xs(n);for(let r=0;r<J;r++)s.step(),e++;if(s.winningDiskIndex!==-1)throw new Error("sim already has winning disk before branching");const o=T.randomSeed();for(T.setSeed(o);s.winningDiskIndex===-1&&e<Ni;)s.step(),e++;if(t[s.winningDiskIndex]={midSeed:o},e>Ni)break}if(t.some(({midSeed:s})=>s===-1))return console.log(`failed race with start seed ${n}`),null;const i=[n,...t.map(({midSeed:s})=>s)];if(i.length!==he)throw new Error(`result length (${i.length}) doesn't match leaf length ${he}`);return console.log(`solved race with start seed ${n}`),i}function Mo(n){return{locateElement:t=>{if(n.isTitleScreen){const e=window.startBtn,i=e==null?void 0:e.getBoundingClientRect();if(!i||!Object.hasOwn(i,"x"))return[350,450,100,50];const{x:s,y:o,width:r,height:a}=i;return[s,o,r,a]}else if(t.startsWith("ball-")){const e=Number(t.split("-")[1]);return n.locateDiskOnScreen(e)}else{const e=[et.create("playing-gui")];for(const i of e){const s=i.layoutRectangles[t];if(!s)continue;const[o,r,a,l]=s,c=1;return[o*c,r*c,a*c,l*c]}}return null},getCameraPos:()=>[0,0],getSetting:t=>D.flatConfig[t],applySetting:(t,e)=>{if(t in D.tree.children){const i=D.tree.children[t];i.value=e,i.onChange()}},getGameState:()=>{if(n.loadingState)return n.loadingState;if(n.isTitleScreen)return"title-screen";const t=n.activeSim.winningDiskIndex;if(t!==-1)return`ball-${t}-finished`;const e=n.speed,i=n.selectedDiskIndex;return i===-1?`${e}`:`${e}-ball-${i}`},getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.cursorForTestSupport})}}class $o{static update(t){Po(t),Oo()}}const Lo=15,ji=.22,Io=1e-4,Ro=[1,1,1],Do=100,$=[0,1,2].map(n=>{const t=ot*n/3,e=[Math.cos(t)*ji,Math.sin(t)*ji],i=(Math.random()+1)*Io,s=[Math.sin(t),-Math.cos(t)],o=[s[0]*i,s[1]*i];return{pos:e,vel:o,mass:Ro[n],trail:[e.slice()]}});function Po(n){for(let e=0;e<$.length;e++){const i=[0,0];for(let s=0;s<$.length;s++){if(e===s)continue;const o=$[s].pos[0]-$[e].pos[0],r=$[s].pos[1]-$[e].pos[1],a=o*o+r*r+.001,l=Math.sqrt(a),c=1e-8*$[s].mass/a;i[0]+=c*o/l,i[1]+=c*r/l}$[e].vel[0]+=i[0]*n,$[e].vel[1]+=i[1]*n}for(let e=0;e<$.length;e++)$[e].pos[0]+=$[e].vel[0]*n,$[e].pos[1]+=$[e].vel[1]*n,$[e].trail.push([$[e].pos[0],$[e].pos[1]]),$[e].trail.length>Do&&$[e].trail.shift()}function Oo(){const{cvs:n,ctx:t}=v,e=n.width,i=n.height,s=Math.min(e,i)*.5;t.save(),t.globalAlpha=1,t.fillStyle="#ddd",t.fillRect(0,0,e,i),t.restore(),t.fillStyle="#888";for(const o of $)if(o.trail.length>1)for(let r=0;r<o.trail.length;r++){const[a,l]=o.trail[r],c=e/2+a*s,h=i/2+l*s;t.fillRect(c,h,1,1)}for(const o of $){const[r,a]=[e/2+o.pos[0]*s,i/2+o.pos[1]*s];t.beginPath(),t.arc(r,a,Lo,0,2*Math.PI),t.fillStyle="#aaa",t.shadowColor="#999",t.shadowBlur=8,t.fill(),t.shadowBlur=0}}let ks=!0,zi=performance.now();function Cs(){if(!ks)return;requestAnimationFrame(Cs);const n=performance.now(),t=Math.min(50,n-zi);zi=n,$o.update(t)}function te(){v.onResize()}async function To(){te(),window.addEventListener("resize",te),requestAnimationFrame(Cs);const n=document.getElementById("title-iframe");await new Promise(a=>{n.addEventListener("load",()=>a()),n.src="title-screen.html"});const e=n.contentDocument.getElementById("start-button");ge.refreshConfig();const i=new Ao;i.loadingState="B",window.TestSupport=Mo(i),i.loadingState="C";const s=document.getElementById("title-screen");s.classList.remove("hidden"),i.loadingState="K",Bo(i),i.loadingState="D",j.initListeners(i),N.initListeners(i),i.loadingState="E",await Ho(e),i.loadingState="F",e.innerHTML="START",i.loadingState="G";for(const a of hs.NAMES)et.preload(i,a);i.loadingState="H",i.loadingState="I",e.onclick=async()=>{await i.init(),i.gui=et.create("playing-gui"),i.isTitleScreen=!1,i.onResize(),s.classList.add("hidden"),j.show(),ks=!1,document.removeEventListener("resize",te),r()},i.loadingState="J",i.loadingState="L",navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",a=>{window.mouseXForTestSupport=a.clientX,window.mouseYForTestSupport=a.clientY;const l=window.getComputedStyle(a.target).cursor;l==="auto"?window.cursorForTestSupport="default":window.cursorForTestSupport=l,a.stopPropagation()}),i.loadingState="M";let o=performance.now();function r(){requestAnimationFrame(r);const a=performance.now(),l=Math.min(50,a-o);o=a,i.update(l)}i.loadingState=null}To();function Bo(n){const t=[0,0];v.cvs.addEventListener("pointermove",e=>{t[0]=e.offsetX,t[1]=e.offsetY,n.move(t)}),v.cvs.addEventListener("pointerdown",e=>{t[0]=e.offsetX,t[1]=e.offsetY,n.down(t)}),v.cvs.addEventListener("pointerup",e=>{t[0]=e.offsetX,t[1]=e.offsetY,n.up(t)}),v.cvs.addEventListener("pointerleave",e=>{t[0]=e.offsetX,t[1]=e.offsetY,n.up(t)}),v.cvs.addEventListener("wheel",e=>{n.camera.scroll(e.deltaY)})}async function Ho(n){const t=Object.keys(kt).length+(pi.NAMES.length-1);let e=0;async function i(){e++;const s=Math.floor(100*e/t);n&&(n.innerHTML=`LOADING (${s}%)`)}for(const s of pi.NAMES)if(s==="obstacle-lut")for(const o of Object.keys(kt))await _.create(s,o).loadAll(),await i();else await _.create(s).loadAll(),await i()}
