var Fi=Object.defineProperty;var Hi=(n,t,e)=>t in n?Fi(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var h=(n,t,e)=>Hi(n,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const o of s)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function e(s){const o={};return s.integrity&&(o.integrity=s.integrity),s.referrerPolicy&&(o.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?o.credentials="include":s.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function i(s){if(s.ep)return;s.ep=!0;const o=e(s);fetch(s.href,o)}})();const Vi=["Array","Object"],_t={Array:0,Object:0};function Yi(n,t){return _t.Object++,new Proxy(n,{get(e,i,s){return Reflect.get(e,i,s)},set(e,i,s,o){return Reflect.set(e,i,s,o)}})}function Ni(n,t){return _t.Array++,new Proxy(n,{get(e,i,s){return Reflect.get(e,i,s)},set(e,i,s,o){return Reflect.set(e,i,s,o)}})}globalThis.__trackObject=Yi;globalThis.__trackArray=Ni;function Xi(){const n={..._t};n.Object++,setTimeout(()=>{for(const t of Vi){const e=_t[t]-n[t];e>0&&console.log(`constructed ${e} ${t} in one second`)}},1e3)}window.setInterval(Xi,1e3);const li={normal:1,paused:0,fast:10},dt=10,ci=30,ct=5,Yt=1,At=4,w=1e4,H=1e3,A=3*w,Ui=A*A,Ct=1e4,$t=16*w,ot=8*w,It=2*w;function zi(n){const t=ci;let e=Array(t).fill(0).map(()=>Math.round(10+Math.random()*80)),i=0;function s(r){for(let a=0;a<50;a++){let l=!1;for(const c of n){const d=c.reduce((f,u)=>f+r[u],0);if(d!==100){const f=100-d,u=c.length;for(const p of c)r[p]+=f/u;for(const p of c)r[p]=Math.max(0,Math.min(100,r[p]));l=!0}}if(!l)break}}for(let r=50;r>.1;r*=.95){const a=e.slice(),l=Math.floor(Math.random()*t),c=(Math.random()-.5)*r*2;a[l]=Math.max(0,Math.min(100,a[l]+c)),s(a);const d=new Set(a.map(f=>Math.round(f))).size;(d>i||Math.exp((d-i)/r)>Math.random())&&(e=a.slice(),i=d)}const o=e.map(r=>Math.max(0,Math.min(100,Math.round(r))));for(const r of n){const a=r.reduce((l,c)=>l+o[c],0);if(a!==100){let l=r[0],c=0;for(const f of r){const u=Math.min(100-o[f],o[f]);u>c&&(c=u,l=f)}const d=Math.max(-c,Math.min(c,100-a));o[l]=Math.max(0,Math.min(100,o[l]+d))}}return o}class O{constructor(){h(this,"flatConfig")}refreshConfig(){this.flatConfig=hi(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],i=e();return i.refreshConfig(),i}}h(O,"_registry",{});function hi(n,t={}){for(const[e,i]of Object.entries(n.children))"action"in i||("value"in i?t[e]=i.value:hi(i,t));return t}const ji={children:{scrollSpeed:{value:-2e3,min:-1e4,max:1e4,step:1,onChange:()=>M.refreshConfig()},rngSeed:{value:-1,min:-1,max:Number.MAX_SAFE_INTEGER,step:1,onChange:()=>M.refreshConfig()},topSpeed:{value:10,min:2,max:1e6,onChange:()=>{M.refreshConfig(),li.fast=M.flatConfig.topSpeed}},speedLerp:{value:.001,min:0,max:1,onChange:()=>M.refreshConfig()},roomIndex:{value:0,min:-1,max:10,step:1,onChange:()=>M.refreshConfig()}}},se=class se extends O{constructor(){super(...arguments);h(this,"tree",ji)}};O.register("top-config",()=>new se);let we=se;const M=O.create("top-config"),di=Math.PI,rt=2*di,Ki=di/2;function Wi(n,t,e){const[i,s,o,r]=n;return t>=i&&t<i+o&&e>=s&&e<s+r}function Nt(n,t,e=.5){return n+(t-n)*e}function qi(n){let t=n.length,e;for(;t>0;)e=Math.floor(Math.random()*t),t--,[n[t],n[e]]=[n[e],n[t]];return n}class xe{static encode(t){const e=[];return ui(t,e),e.length%2!==0&&e.push(0),new Int16Array(e)}static decode(t,e){let i=0;for(const s of fi(e)){const o=t[i++];let r=null;o===0||(r=Array.from({length:e.reg.leafLength},()=>t[i++])),Jt(e.tree,s,r)}}}function ui(n,t){for(const e of n)e===null?t.push(0):typeof e[0]=="number"?(t.push(1),t.push(...e.map(Math.round))):ui(e,t)}const U={ROUNDRECT:{url:"luts/roundrect-f4a0135924189428.bin",hash:"f4a01359241894282ff7d8fe33dff9d059acd26d9c899d7aca170b006571f8d9",xRad:155,yRad:55},BREAKOUTBRICK:{url:"luts/breakoutbrick-8cef52cb4168881f.bin",hash:"8cef52cb4168881fc86cfbe3abddefa14a97ae4efb4f19d0055351d067f31ff9",xRad:110,yRad:70},DIAMOND:{url:"luts/diamond-f6cea1844d983884.bin",hash:"f6cea1844d983884a9503197cad197c44a6029b290a6c9d0ec67f5810325a497",xRad:143,yRad:143},RIGHTWEDGE:{url:"luts/rightwedge-4b877a5d81585923.bin",hash:"4b877a5d8158592306b52f4205c45e5f7b145a33822f7b325787c5e5da95f90d",xRad:255,yRad:70},LEFTWEDGE:{url:"luts/leftwedge-c2bf9ece830f9ba4.bin",hash:"c2bf9ece830f9ba4e8d7dbe67cc194503396e1b6f8f7900379f509bc11c83746",xRad:255,yRad:70},STAR:{url:"luts/star-162be0d5af7364af.bin",hash:"162be0d5af7364af8767c00440b5b0bf53e262ea8986c7670df1cca8c42af424",xRad:151,yRad:148},DISK_FRICTION_LUT:{url:"luts/disk-friction-lut-9f8e66a2dc70f064.bin",hash:"9f8e66a2dc70f06456c6baf67dd2d922e9b7a846fc266a8de88559b493dffa51"},DISK_DISK_LUT:{url:"luts/disk-disk-lut-e9cd18aa3e3da17a.bin",hash:"e9cd18aa3e3da17a07ed2d5fbe3559e39c81868b0f54a103ec98c96b1210d902"},DISK_NORMAL_LUT:{url:"luts/disk-normal-lut-705377676ab3d42c.bin",hash:"705377676ab3d42cd2e6ffcb1f5c3298f1df3018910f934c553c0ee2096e27de"},RACE_LUT:{url:"luts/race-lut-6fbdcb782dbaf289.bin",hash:"6fbdcb782dbaf2898c99dfa9d0014eb7980358174c1c88683a1b4f64eaa60af0"}},W=class W{constructor(){h(this,"name",null);h(this,"reg",null);h(this,"tree",[])}loadFromBlob(t){this.tree.length=0,xe.decode(t,this)}async loadAll(){const t=await Gi(this.blobUrl,this.blobHash);this.tree.length=0,xe.decode(t,this)}computeAll(){this.tree.length=0;for(const t of fi(this)){const e=this.computeLeaf(t);if(e!==null){for(const i of e)if(!Number.isInteger(i))throw new Error(`computed leaf includes non-integer: ${e}`)}Jt(this.tree,t,e)}}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);if(this._registry[t]=e,t==="obstacle-lut")return;const i=e.factory();i.reg=e,i.name=t,this._singletonLuts[t]=i}static create(t,e){if(t==="obstacle-lut"){if(!e)throw new Error("shapeName argument is required to create obstacle-lut");const i=this._registry["obstacle-lut"];if(!i)throw new Error("obstacle-lut not registered");if(!Object.hasOwn(W._obstacleLuts,e)){const{factory:s}=i,o=s();o.reg=i,o.name=t,o.shape=e;const{url:r,hash:a,xRad:l=100,yRad:c=100}=U[e.toUpperCase()];o.blobUrl=r,o.blobHash=a,o.obsOffsetDetailX=l,o.obsOffsetDetailY=c,o.detail=[o.obsOffsetDetailX*2+1,o.obsOffsetDetailY*2+1],o.maxOffsetX=l*H,o.maxOffsetY=c*H,W._obstacleLuts[e]=o}return W._obstacleLuts[e]}else{if(e)throw new Error("shapeName argument should only be used to create obstacle-lut");if(!Object.hasOwn(this._singletonLuts,t))throw new Error(`singleton lut not registered: ${t}`);return this._singletonLuts[t]}}};h(W,"_registry",{}),h(W,"_singletonLuts",{}),h(W,"_obstacleLuts",{});let _=W;async function Gi(n,t){const e=await fetch(n);if(!e.ok)throw new Error(`Failed to fetch blob: ${e.statusText}`);const i=await e.arrayBuffer();if(!crypto.subtle)console.log("skipping integrity check because crypto.subtle is not availabtl");else if(t){const s=await crypto.subtle.digest("SHA-256",i),r=Array.from(new Uint8Array(s)).map(a=>a.toString(16).padStart(2,"0")).join("");if(r!==t)throw new Error(`Integrity check failed: expected ${t}, got ${r}`)}return new Int16Array(i)}function*fi(n){const t=n.reg.depth,e=Array.from({length:t},()=>0);for(;;)if(yield[...e],pi(e,n,e.length-1))return}function Jt(n,t,e){if(t.length===0)throw new Error("poop");if(t.length===1){if(n.length!==t[0])throw new Error("poop");n.push(e)}else{for(;n.length<=t[0];)n.push([]);Jt(n[t[0]],t.slice(1),e)}}function pi(n,t,e){const i=n[e]+1;return i>=t.detail[e]?e===0?!0:(n[e]=0,pi(n,t,e-1)):(n[e]=i,!1)}const Qi=100,gi=100,Ji=n=>n*rt/gi,L=20,mi=Qi*L,ve=n=>Math.floor(n*L/mi),Se=n=>n*mi/L,ne=class ne extends _{constructor(){super(...arguments);h(this,"blobHash",U.DISK_NORMAL_LUT.hash);h(this,"blobUrl",U.DISK_NORMAL_LUT.url);h(this,"detail",[L*2+1,L*2+1,gi])}computeLeaf(e){const i=Se(e[0]-L),s=Se(e[1]-L),o=Ji(e[2]);return Zi(i,s,o)}};_.register("disk-normal-lut",{factory:()=>new ne,depth:3,leafLength:2});let Ae=ne;function Zi(n,t,e){const i=Math.cos(e),s=Math.sin(e),o=n*i+t*s,r=n-2*o*i,a=t-2*o*s;return[Math.round((r-n)*Yt),Math.round((a-t)*Yt)]}const ts=100,R=20,bi=ts*R,yi=n=>Math.floor(n*R/bi),es=n=>n*bi/R,oe=class oe extends _{constructor(){super(...arguments);h(this,"blobHash",U.DISK_FRICTION_LUT.hash);h(this,"blobUrl",U.DISK_FRICTION_LUT.url);h(this,"detail",[R*2+1])}computeLeaf(e){const i=es(e[0]-R);return[Math.round(i*Yt)]}};_.register("disk-friction-lut",{factory:()=>new oe,depth:1,leafLength:1});let _e=oe;function Ce(n){const t=_.create("disk-friction-lut"),e=n.dx;let i=yi(e);Math.abs(i)>R&&(i=R*Math.sign(i)),n.dx=t.tree[i+R][0]}function is(n){const t=_.create("disk-friction-lut"),e=n.dy;let i=yi(e);Math.abs(i)>R&&(i=R*Math.sign(i)),n.dy=t.tree[i+R][0]}class kt{constructor(t,e,i,s){h(this,"_x");h(this,"_y");h(this,"_dx");h(this,"_dy");this.x=t,this.y=e,this.dx=i,this.dy=s}get x(){return this._x}set x(t){if(!Number.isInteger(t))throw new Error("x must be an integer");this._x=t}get y(){return this._y}set y(t){if(!Number.isInteger(t))throw new Error("y must be an integer");this._y=t}get dx(){return this._dx}set dx(t){if(!Number.isInteger(t))throw new Error("dx must be an integer");this._dx=t}get dy(){return this._dy}set dy(t){if(!Number.isInteger(t))throw new Error("dy must be an integer");this._dy=t}setAll(t,e,i,s){this.x=t,this.y=e,this.dx=i,this.dy=s}copy(t){this.setAll(t.x,t.y,t.dx,t.dy)}toArray(){return[this._x,this._y,this._dx,this._dy]}static fromArray(t){return new kt(t[0],t[1],t[2],t[3])}}const Z=100,ss=0,mt=[0,0,0],q=class q{constructor(){h(this,"pattern","white");h(this,"_history",new Float32Array(Z*2));h(this,"currentState",new kt(0,0,0,0));h(this,"nextState",new kt(0,0,0,0));h(this,"stepFrac",0);h(this,"lastStepPos",[0,0]);h(this,"interpolatedPos",[0,0])}static flushStates(t){for(const e of t)e.lastStepPos[0]=e.currentState.x,e.lastStepPos[1]=e.currentState.y,e.currentState.copy(e.nextState)}history(){const t=[];let e=0,i=0,s=0,o=0;for(let r=0;r<Z;r+=3){const a=2*((q.historyIndex+Z-r)%Z),l=this._history[a],c=this._history[a+1];if(r>0){const d=Math.hypot(l-e,c-i);s+=d}e=l,i=c,s-o<ss&&r<Z-1||(mt[0]=Math.round(l),mt[1]=Math.round(c),mt[2]=Math.round(s),t.push([...mt]),o=s)}return t}static updateHistory(t){q.historyIndex=(q.historyIndex+1)%Z;const e=q.historyIndex*2;for(const i of t)i._history[e]=Math.round(i.interpolatedPos[0]),i._history[e+1]=Math.round(i.interpolatedPos[1])}static fromJson(t){const e=new q,i=t;return e.currentState.setAll(i[0],i[1],i[2],i[3]),e.nextState.setAll(i[0],i[1],i[2],i[3]),e}toJson(){return this.currentState.toArray()}advance(t){var u;const e=this.currentState.x,i=this.currentState.y,s=this.currentState.dx,o=this.currentState.dy,r=e+s,a=i+o;let l=s,c=o,d=!0,f=0;for(;f<t.length;f++){const p=t[f];if(!p.isHidden&&Wi(p.collisionRect,r,a)){let g=p.lut.offsetToXIndex(r-p.pos[0]),y=p.lut.offsetToYIndex(a-p.pos[1]);const x=p.lut.obsOffsetDetailX,b=p.lut.obsOffsetDetailY;if(Math.abs(g)>x&&(g=x*Math.sign(g)),Math.abs(y)>b&&(y=b*Math.sign(y)),p.lut.tree.length===0)throw new Error("obs.lut.tree has length 0");const m=p.lut.tree[g+x][y+b];if(m){(u=p.room)==null||u.obstacleHit(p);const[$,j,et]=m;let G=ve(l),Q=ve(c);Math.abs(G)>L&&(G=L*Math.sign(G)),Math.abs(Q)>L&&(Q=L*Math.sign(Q));const K=_.create("disk-normal-lut").tree[G+L][Q+L][et],[ft,pt]=K;l+=ft,c+=pt,this.nextState.x+=$,this.nextState.y+=j,this.nextState.dx=l,this.nextState.dy=c,d=!1;return}}}d?(this.nextState.x=r,this.nextState.y=a):(this.nextState.x+=l,this.nextState.y+=c,this.nextState.dx=l,this.nextState.dy=c)}pushInBounds(t){this.nextState.x-A<t[0]&&(this.nextState.x=t[0]+A,this.nextState.dx<0&&(this.nextState.dx*=-1,Ce(this.nextState))),this.nextState.y-A<t[1]&&(this.nextState.y=t[1]+A,this.nextState.dy<0&&(this.nextState.dy*=-1,is(this.nextState))),this.nextState.x+A>t[0]+t[2]&&(this.nextState.x=t[0]+t[2]-A,this.nextState.dx>0&&(this.nextState.dx*=-1,Ce(this.nextState)))}};h(q,"historyIndex",0);let lt=q;const $e=3*A;function ns(n,t,e=!1,i=!1){const[s,o]=t.interpolatedPos,r=w*.5*(e?5:1),a=2;n.fillStyle="black",n.beginPath();let l=0;n.moveTo(s,o),n.arc(s,o,A*(1-l*a/Z),0,rt);for(const[c,d,f]of t.history()){n.moveTo(c,d);const u=A*(1-Math.min(f,$e)/$e);n.arc(c,d,u,0,rt),l++}n.lineWidth=r,n.stroke(),n.fillStyle=ls[t.pattern],n.imageSmoothingEnabled=!1,n.fill()}const Xt=["white","black","v-stripe","h-stripe","checkered","hex-a","hex-b"];function ke(n="#000",t="#fff",e=12,i=32,s=128){if(typeof document>"u")return t;const o=document.createElement("canvas"),r=o.getContext("2d"),a=i*Math.sqrt(3)/2;o.width=i*2,o.height=a*2,r.fillStyle=t,r.fillRect(0,0,o.width,o.height);for(let c=0;c<2;c++)for(let d=0;d<2;d++)for(let f=-1;f<=1;f++)for(let u=-1;u<=1;u++){const p=d*i+c*i/2+f*o.width,g=c*a+u*o.height;r.beginPath(),r.arc(p,g,e,0,Math.PI*2),r.fillStyle=n,r.fill()}const l=r.createPattern(o,"repeat");return l.setTransform(new DOMMatrix().scale(w/10,w/10)),l}function os(n="#000",t="#fff",e=1,i=1){if(typeof document>"u")return"white";const s=document.createElement("canvas"),o=e+i;s.width=1,s.height=o;const r=s.getContext("2d");r.fillStyle=t,r.fillRect(0,0,s.width,s.height),r.fillStyle=n,r.fillRect(0,0,s.width,e);const a=r.createPattern(s,"repeat");return a.setTransform(new DOMMatrix().scale(w,w)),a}function rs(n="#000",t="#fff",e=1,i=1){if(typeof document>"u")return"white";const s=document.createElement("canvas"),o=e+i;s.width=o,s.height=1;const r=s.getContext("2d");r.fillStyle=t,r.fillRect(0,0,s.width,s.height),r.fillStyle=n,r.fillRect(0,0,e,s.height);const a=r.createPattern(s,"repeat");return a.setTransform(new DOMMatrix().scale(w,w)),a}function as(n="#000",t="#fff",e=512/8,i=512){if(typeof document>"u")return"white";const s=document.createElement("canvas");s.width=i,s.height=i;const o=s.getContext("2d"),r=Math.ceil(i/e)*2;for(let l=-r;l<r;l++)for(let c=-r;c<r;c++){const d=(l+c)%2===0;o.save(),o.translate(i/2,i/2),o.rotate(Math.PI/4),o.fillStyle=d?n:t;for(let f=-1;f<=1;f++)for(let u=-1;u<=1;u++){const p=Math.random();o.fillRect((l+2*f)*e-i/2,(c+2*u)*e-i/2,e*p,e*p)}o.restore()}const a=o.createPattern(s,"repeat");return a.setTransform(new DOMMatrix().scale(w/50,w/50)),a}const ls={black:"black",white:"white","v-stripe":rs(),"h-stripe":os(),checkered:as(),"hex-a":ke("#000","#fff"),"hex-b":ke("#fff","#000",4)},F=document.getElementById("sim-canvas"),v=F.getContext("2d"),Me="#444",E=class E{static drawFinish(t){v.fillStyle="rgba(0,255,0,0.5)",v.fillRect(...t.xywh)}static drawBarrier(t){t.isHidden||(v.fillStyle="black",v.fillRect(...t.xywh))}static drawObstacle(t){v.fillStyle=Me;const{isHidden:e,pos:i,points:s}=t;if(!e){v.beginPath();for(const[o,r]of s)v.lineTo(i[0]+o,i[1]+r);v.closePath(),v.fill()}}static onResize(){const t=window.devicePixelRatio;F.width=F.clientWidth*t,F.height=F.clientHeight*t;const e=600*t;E.innerWidth=Math.min(e,F.width),E.drawOffset[0]=(F.width-E.innerWidth)/2}static drawSim(t,e){const i=E.innerWidth/100/w;E.drawSimScale=i,v.clearRect(0,0,F.width,F.height),v.save(),v.translate(...E.drawOffset),v.scale(i,i),v.lineWidth=w;for(const[c,d]of t.disks.entries()){const f=c===e,u=c===t.winningDiskIndex;ns(v,d,f,u)}for(const c of t.obstacles)E.drawObstacle(c);E.drawFinish(t.finish);const s=2*w,o=t.level.bounds[0],r=t.level.bounds[1],a=o+t.level.bounds[2],l=r+t.level.bounds[3];v.fillStyle=Me,v.fillRect(o-s,r,s,l-r),v.fillRect(a,r,s,l-r),v.restore()}static drawScrollBar(t){}static drawCursor(t){const e=(E.drawOffset[0]+t[0])*window.devicePixelRatio,i=(E.drawOffset[1]+t[1])*window.devicePixelRatio;v.fillStyle="rgba(100,100,100,.5)",v.beginPath(),v.moveTo(e,i),v.arc(e,i,10,0,rt),v.fill()}};h(E,"cvs",F),h(E,"ctx",v),h(E,"innerWidth",1),h(E,"drawOffset",[0,0]),h(E,"drawSimScale",1);let S=E;class cs{constructor(){h(this,"pos",0);h(this,"vel",0);h(this,"_idleDelay",1e3);h(this,"_idleCountdown",0);h(this,"_cameraFriction",.001);h(this,"_snapSpeed",.007);h(this,"lastDragTime",performance.now());h(this,"isDragging",!1)}jumpToRoom(t,e){const i=t.activeSim.level.rooms[e],s=-i.bounds[1]-i.bounds[3]/2;this.pos=s,this.vel=0}update(t,e){if(!this.isDragging){if(this._idleCountdown>0&&(this._idleCountdown-=t,this._idleCountdown<=0)){let i=1/0,s=-1;for(const[o,r]of e.activeSim.level.rooms.entries()){const a=-r.bounds[1]-r.bounds[3]/2,l=Math.abs(this.pos-a);l<i&&(i=l,s=o)}M.tree.children.roomIndex.value=s,M.refreshConfig()}if(this._idleCountdown<=0){const{rooms:i}=e.activeSim.level;let s=M.flatConfig.roomIndex;s=Math.max(0,Math.min(i.length-1,s));const o=i[s],r=-o.bounds[1]-o.bounds[3]/2;this.pos=Nt(this.pos,r,this._snapSpeed*t)}this.vel*=1-this._cameraFriction*t,this.pos+=this.vel}}scroll(t){const{roomIndex:e}=M.flatConfig;let i=e+Math.sign(t);i=Math.max(0,Math.min(ct-1,i)),M.tree.children.roomIndex.value=i,M.refreshConfig()}drag(t,e){const i=performance.now(),s=i-this.lastDragTime,r=(e-t)/S.drawSimScale*window.devicePixelRatio;this.pos+=r,this.vel=r/s,this._idleCountdown=this._idleDelay,this.isDragging=!0,this.lastDragTime=i}endDrag(){this._idleCountdown=this._idleDelay,this.isDragging=!1}}function hs(n){Zt.refreshConfig()}const ds={label:"Graphics",children:{pixelScale:{value:1,min:1,max:10,step:1,onChange:hs}}},re=class re extends O{constructor(){super(...arguments);h(this,"tree",ds)}};O.register("gfx-config",()=>new re);let Ee=re;const Zt=O.create("gfx-config"),wi={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:80,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:35,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const n of Object.values(wi.children))n.onChange=t=>{ut.refreshConfig(),t.onResize()};const ae=class ae extends O{constructor(){super(...arguments);h(this,"tree",wi)}};O.register("layout-config",()=>new ae);let Ie=ae;const ut=O.create("layout-config"),us={children:{...M.tree.children,...Zt.tree.children}},le=class le extends O{constructor(){super(...arguments);h(this,"tree",us)}};O.register("pinball-wizard-config",()=>new le);let Le=le;const fs=O.create("pinball-wizard-config");function ps(n,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",i=t.display.classes??[],s=i.filter(a=>a.startsWith("fa-")),o=i.filter(a=>!a.startsWith("fa-"));t.display.type!=="button"&&o.push("noselect");const r=ws(`
    <${e} 
       id="${n}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${o.join(" ")}
        "
        >

      <span 
        class="${s.join(" ")}" 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[a,l]of Object.entries(t.display.styles??{}))r.style.setProperty(a,l);return t.id=n,t.htmlElem=r,r}function xi(n,t){t?ms(n):gs(n)}function gs(n){let t;typeof n=="string"?t=document.getElementById(n):t=n.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function ms(n){let t;typeof n=="string"?t=document.getElementById(n):t=n.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function bs(n,t){if(n.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:i}=n;i&&(i.innerHTML=`
    <span ${n.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function ys(n,t,e){if(!e){n.classList.add("hidden");return}n.style.opacity="";const[i,s,o,r]=e;n.style.display="",n.style.left=`${i}px`,n.style.top=`${s}px`,n.style.width=`${o}px`,n.style.height=`${r}px`;const a=n;a.width=o*window.devicePixelRatio,a.height=r*window.devicePixelRatio}function ws(n){const t=document.createElement("div");return t.innerHTML=n.trim(),t.firstChild}let te=!0;function xs(n){n.isLandscape,n.isPortrait,te=Mt.isSmall}function vs(){const{buttonWidth:n,smButtonWidth:t}=ut.flatConfig;return te?t:n}function Ss(){const{buttonHeight:n,smButtonHeight:t}=ut.flatConfig;return te?t:n}function As(n){return Object.entries(n)}function _s(n,t){return new Mt(n,t)._computedRects}const V=class V{constructor(t,e){h(this,"_computedRects",{});h(this,"isPortrait",!1);h(this,"isLandscape",!1);h(this,"parent");h(this,"_currentLayoutKey","");h(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const i=600;t[2]<i||t[3]<i?V.isSmall=!0:V.isSmall=!1,xs(this),this.parent=t;for(const[o,r]of Object.entries(e))this.parent=t,this._currentLayoutKey=o,this._computedRects[o]=this.computeRect(r);const s=this._childrenToParse;for(;Object.keys(s).length>0;){const o=Object.keys(s)[0],r=s[o];delete s[o];const a=this._computedRects[o],{_computedRects:l}=new V(a,r);for(const c in l)this._computedRects[`${o}.${c}`]=l[c]}}computeRect(t){let e=[...this.parent];for(const[i,s]of As(t))if(i==="parent"){if(!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);this.parent=this._computedRects[s],e=[...this.parent]}else if(i.startsWith("parent@")){const[o,r]=i.split("@");if(typeof s!="string"||!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);if(r==="portrait")this.isPortrait&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="landscape")this.isLandscape&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="sm-portrait")this.isPortrait&&V.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(r==="sm-landscape")this.isLandscape&&V.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else if(i==="children")this._childrenToParse[this._currentLayoutKey]=s;else if(i.includes("@")){const[o,r]=i.split("@");if(r==="portrait")this.isPortrait&&(e=this.applyRule(e,o,s));else if(r==="landscape")this.isLandscape&&(e=this.applyRule(e,o,s));else if(r==="sm-portrait")this.isPortrait&&V.isSmall&&(e=this.applyRule(e,o,s));else if(r==="sm-landscape")this.isLandscape&&V.isSmall&&(e=this.applyRule(e,o,s));else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else e=this.applyRule(e,i,s);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,i){const[s,o,r,a]=t,[l,c,d,f]=this.parent,u=(g,y)=>{if(typeof y=="function"&&(y=y()),typeof y=="string"&&y.endsWith("%")){const x=parseFloat(y)/100;return["left","right","width","margin"].includes(g)?d*x:f*x}else{if(y==="auto")return g==="width"?l+d-s:g==="height"?c+f-o:["left","right"].includes(g)?(d-r)/2:(f-a)/2;if(typeof y=="number"&&y<0){if(g==="width")return d+y;if(g==="height")return f+y}}return Number(y)},p=e.split("-");if(p.length===2){const[g,y]=p;let x;if(g==="min")x=Math.max;else if(g==="max")x=Math.min;else throw new Error("only min- or max- prefixed allowed");if(y==="width")return[s,o,x(r,u("width",i)),a];if(y==="height")return[s,o,r,x(a,u("height",i))];if(y==="left")return[x(s,u("left",i)),o,r,a];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[l+u("left",i),o,r,a];case"right":return[l+d-r-u("right",i),o,r,a];case"top":return[s,c+u("top",i),r,a];case"bottom":return[s,c+f-a-u("bottom",i),r,a];case"width":return[s,o,u("width",i),a];case"height":return[s,o,r,u("height",i)];case"margin":{const g=u("margin",i);return[s+g,o+g,r-2*g,a-2*g]}default:return t}}};h(V,"isSmall",!1);let Mt=V;const De={};let Cs=0;class z{constructor(){h(this,"guiLayout");h(this,"layoutRectangles",{});h(this,"elements",{});h(this,"layoutFactory")}init(t,e,i){this.layoutFactory=e;for(const s of i)if(typeof s.id=="string")this.elements[s.id]=s;else{const o=`_${Cs++}`;this.elements[o]=s;const r=ps(o,s);r.onclick=a=>{a.preventDefault(),s.click&&s.click({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointerdown=a=>{a.preventDefault(),s.down&&s.down({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointermove=a=>{a.preventDefault(),s.move&&s.move({elementId:o,pinballWizard:t,pointerEvent:a})},r.onpointerup=a=>{a.preventDefault(),s.up&&s.up({elementId:o,pinballWizard:t,pointerEvent:a})},r.style.display="none",document.body.appendChild(r),De[o]=r,s.id=o}}refreshLayout(t){const e=[0,0,window.innerWidth,window.innerHeight];this.guiLayout=this.layoutFactory(t),this.layoutRectangles=_s(e,this.guiLayout);for(const i in this.elements){const s=this.elements[i],o=this.layoutRectangles[s.layoutKey];s.rectangle=o,s.rectangle&&(s.dprRectangle=s.rectangle.map(r=>r*window.devicePixelRatio)),ys(De[i],s,o)}}keydown(t,e){for(const i in this.elements){const s=this.elements[i],{click:o,hotkeys:r}=s;if(o&&(r!=null&&r.includes(e)))return o({elementId:i,pinballWizard:t}),!0}return!1}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const i=this._registry[e];if(!i)throw new Error(`gui ${e} not registered `);const{factory:s,layoutFactory:o,elements:r}=i,a=s();this._preloaded[e]=a,a.init(t,o,r)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}h(z,"_registry",{}),h(z,"_preloaded",{});const $s=()=>ut.flatConfig.outerMargin,bt=()=>ut.flatConfig.innerMargin,st=vs,Tt=Ss,ks={screen:{},_outerMargin:{margin:()=>$s(),width:-50,left:"auto"},topLabel:{parent:"_outerMargin",height:()=>Tt()},bottomLabel:{parent:"_outerMargin",height:()=>Tt(),left:0,bottom:0},bottomBar:{parent:"_outerMargin",width:()=>4*st()+2*bt(),height:()=>Tt(),left:"auto",bottom:0},clock:{parent:"bottomBar",width:()=>2*st()},playPauseBtn:{parent:"clock",width:()=>st(),left:()=>2*st()+bt()},speedUpBtn:{parent:"playPauseBtn",width:()=>st(),left:()=>st()+bt()},rightBar:{parent:"_outerMargin",width:100,height:400,right:0,top:"auto"},_innerRightBar:{parent:"rightBar",margin:()=>bt()}},vi={layoutKey:"clock",display:{type:"panel",label:"00:00"}};function Ms(n){bs(vi,Es(Math.floor(n*At/1e3)))}function Es(n){const t=Math.floor(n/60),e=Math.floor(n%60),i=String(t).padStart(2,"0"),s=String(e).padStart(2,"0");return`${i}:${s}`}const Is={layoutKey:"playPauseBtn",display:{type:"button",label:"PAUSE"},click:({pinballWizard:n})=>{n.speed==="normal"?n.speed="paused":n.speed="normal"}},Ls={layoutKey:"speedUpBtn",display:{type:"button",label:"speed up"},click:({pinballWizard:n})=>{n.speed="fast"}},Oe=[vi,Is,Ls],ce=class ce extends z{update(t,e){}move(t,e){}down(t,e){}showHideElements(t){for(const e of Oe)xi(e,!t.isTitleScreen);t.hasBranched}};z.register("playing-gui",{factory:()=>new ce,layoutFactory:()=>ks,elements:Oe});let Te=ce;const Si={NAMES:["playing-gui"]},Ds={NAMES:["disk-friction-lut","disk-disk-lut","obstacle-lut","disk-normal-lut","race-lut"]};function Os(n,t){return Math.sqrt(Ts(n,t))}function Ts(n,t){return Math.pow(n[0]-t[0],2)+Math.pow(n[1]-t[1],2)}function nt(n,t,e){return[n[0]+(t[0]-n[0])*e,n[1]+(t[1]-n[1])*e]}function Rs(n,t){const e=n[t+0],i=n[t+1],s=n[t+2],o=n[t+3];let r=3*i[0]-2*e[0]-o[0];r*=r;let a=3*i[1]-2*e[1]-o[1];a*=a;let l=3*s[0]-2*o[0]-e[0];l*=l;let c=3*s[1]-2*o[1]-e[1];return c*=c,r<l&&(r=l),a<c&&(a=c),r+a}function Ut(n,t,e,i){const s=i||[];if(Rs(n,t)<e){const o=n[t+0];s.length?Os(s[s.length-1],o)>1&&s.push(o):s.push(o),s.push(n[t+3])}else{const r=n[t+0],a=n[t+1],l=n[t+2],c=n[t+3],d=nt(r,a,.5),f=nt(a,l,.5),u=nt(l,c,.5),p=nt(d,f,.5),g=nt(f,u,.5),y=nt(p,g,.5);Ut([r,d,p,y],0,e,s),Ut([y,g,u,c],0,e,s)}return s}function Ps(n,t=.15,e){const i=[],s=(n.length-1)/3;for(let o=0;o<s;o++){const r=o*3;Ut(n,r,t,i)}return i}const Bs=0,zt=1,Ai=2,yt={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Fs(n){const t=new Array;for(;n!=="";)if(n.match(/^([ \t\r\n,]+)/))n=n.substr(RegExp.$1.length);else if(n.match(/^([aAcChHlLmMqQsStTvVzZ])/))t[t.length]={type:Bs,text:RegExp.$1},n=n.substr(RegExp.$1.length);else if(n.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))t[t.length]={type:zt,text:`${parseFloat(RegExp.$1)}`},n=n.substr(RegExp.$1.length);else return[];return t[t.length]={type:Ai,text:""},t}function Rt(n,t){return n.type===t}function _i(n){const t=[],e=Fs(n);let i="BOD",s=0,o=e[s];for(;!Rt(o,Ai);){let r=0;const a=[];if(i==="BOD")if(o.text==="M"||o.text==="m")s++,r=yt[o.text],i=o.text;else return _i("M0,0"+n);else Rt(o,zt)?r=yt[i]:(s++,r=yt[o.text],i=o.text);if(s+r<e.length){for(let l=s;l<s+r;l++){const c=e[l];if(Rt(c,zt))a[a.length]=+c.text;else throw new Error("Param not a number: "+i+","+c.text)}if(typeof yt[i]=="number"){const l={key:i,data:a};t.push(l),s+=r,o=e[s],i==="M"&&(i="L"),i==="m"&&(i="l")}else throw new Error("Bad segment: "+i)}else throw new Error("Path data ended short")}return t}function Hs(n){let t=0,e=0,i=0,s=0;const o=[];for(const{key:r,data:a}of n)switch(r){case"M":o.push({key:"M",data:[...a]}),[t,e]=a,[i,s]=a;break;case"m":t+=a[0],e+=a[1],o.push({key:"M",data:[t,e]}),i=t,s=e;break;case"L":o.push({key:"L",data:[...a]}),[t,e]=a;break;case"l":t+=a[0],e+=a[1],o.push({key:"L",data:[t,e]});break;case"C":o.push({key:"C",data:[...a]}),t=a[4],e=a[5];break;case"c":{const l=a.map((c,d)=>d%2?c+e:c+t);o.push({key:"C",data:l}),t=l[4],e=l[5];break}case"Q":o.push({key:"Q",data:[...a]}),t=a[2],e=a[3];break;case"q":{const l=a.map((c,d)=>d%2?c+e:c+t);o.push({key:"Q",data:l}),t=l[2],e=l[3];break}case"A":o.push({key:"A",data:[...a]}),t=a[5],e=a[6];break;case"a":t+=a[5],e+=a[6],o.push({key:"A",data:[a[0],a[1],a[2],a[3],a[4],t,e]});break;case"H":o.push({key:"H",data:[...a]}),t=a[0];break;case"h":t+=a[0],o.push({key:"H",data:[t]});break;case"V":o.push({key:"V",data:[...a]}),e=a[0];break;case"v":e+=a[0],o.push({key:"V",data:[e]});break;case"S":o.push({key:"S",data:[...a]}),t=a[2],e=a[3];break;case"s":{const l=a.map((c,d)=>d%2?c+e:c+t);o.push({key:"S",data:l}),t=l[2],e=l[3];break}case"T":o.push({key:"T",data:[...a]}),t=a[0],e=a[1];break;case"t":t+=a[0],e+=a[1],o.push({key:"T",data:[t,e]});break;case"Z":case"z":o.push({key:"Z",data:[]}),t=i,e=s;break}return o}function Vs(n){const t=[];let e="",i=0,s=0,o=0,r=0,a=0,l=0;for(const{key:c,data:d}of n){switch(c){case"M":t.push({key:"M",data:[...d]}),[i,s]=d,[o,r]=d;break;case"C":t.push({key:"C",data:[...d]}),i=d[4],s=d[5],a=d[2],l=d[3];break;case"L":t.push({key:"L",data:[...d]}),[i,s]=d;break;case"H":i=d[0],t.push({key:"L",data:[i,s]});break;case"V":s=d[0],t.push({key:"L",data:[i,s]});break;case"S":{let f=0,u=0;e==="C"||e==="S"?(f=i+(i-a),u=s+(s-l)):(f=i,u=s),t.push({key:"C",data:[f,u,...d]}),a=d[0],l=d[1],i=d[2],s=d[3];break}case"T":{const[f,u]=d;let p=0,g=0;e==="Q"||e==="T"?(p=i+(i-a),g=s+(s-l)):(p=i,g=s);const y=i+2*(p-i)/3,x=s+2*(g-s)/3,b=f+2*(p-f)/3,m=u+2*(g-u)/3;t.push({key:"C",data:[y,x,b,m,f,u]}),a=p,l=g,i=f,s=u;break}case"Q":{const[f,u,p,g]=d,y=i+2*(f-i)/3,x=s+2*(u-s)/3,b=p+2*(f-p)/3,m=g+2*(u-g)/3;t.push({key:"C",data:[y,x,b,m,p,g]}),a=f,l=u,i=p,s=g;break}case"A":{const f=Math.abs(d[0]),u=Math.abs(d[1]),p=d[2],g=d[3],y=d[4],x=d[5],b=d[6];f===0||u===0?(t.push({key:"C",data:[i,s,x,b,x,b]}),i=x,s=b):(i!==x||s!==b)&&(Ci(i,s,x,b,f,u,p,g,y).forEach(function($){t.push({key:"C",data:$})}),i=x,s=b);break}case"Z":t.push({key:"Z",data:[]}),i=o,s=r;break}e=c}return t}function Ys(n){return Math.PI*n/180}function at(n,t,e){const i=n*Math.cos(e)-t*Math.sin(e),s=n*Math.sin(e)+t*Math.cos(e);return[i,s]}function Ci(n,t,e,i,s,o,r,a,l,c){const d=Ys(r);let f=[],u=0,p=0,g=0,y=0;if(c)[u,p,g,y]=c;else{[n,t]=at(n,t,-d),[e,i]=at(e,i,-d);const T=(n-e)/2,k=(t-i)/2;let B=T*T/(s*s)+k*k/(o*o);B>1&&(B=Math.sqrt(B),s=B*s,o=B*o);const gt=a===l?-1:1,it=s*s,Ot=o*o,Pi=it*Ot-it*k*k-Ot*T*T,Bi=it*k*k+Ot*T*T,ye=gt*Math.sqrt(Math.abs(Pi/Bi));g=ye*s*k/o+(n+e)/2,y=ye*-o*T/s+(t+i)/2,u=Math.asin(parseFloat(((t-y)/o).toFixed(9))),p=Math.asin(parseFloat(((i-y)/o).toFixed(9))),n<g&&(u=Math.PI-u),e<g&&(p=Math.PI-p),u<0&&(u=Math.PI*2+u),p<0&&(p=Math.PI*2+p),l&&u>p&&(u=u-Math.PI*2),!l&&p>u&&(p=p-Math.PI*2)}let x=p-u;if(Math.abs(x)>Math.PI*120/180){const T=p,k=e,B=i;l&&p>u?p=u+Math.PI*120/180*1:p=u+Math.PI*120/180*-1,e=g+s*Math.cos(p),i=y+o*Math.sin(p),f=Ci(e,i,k,B,s,o,r,0,l,[p,T,g,y])}x=p-u;const b=Math.cos(u),m=Math.sin(u),$=Math.cos(p),j=Math.sin(p),et=Math.tan(x/4),G=4/3*s*et,Q=4/3*o*et,Dt=[n,t],K=[n+G*m,t-Q*b],ft=[e+G*j,i-Q*$],pt=[e,i];if(K[0]=2*Dt[0]-K[0],K[1]=2*Dt[1]-K[1],c)return[K,ft,pt].concat(f);{f=[K,ft,pt].concat(f);const T=[];for(let k=0;k<f.length;k+=3){const B=at(f[k][0],f[k][1],d),gt=at(f[k+1][0],f[k+1][1],d),it=at(f[k+2][0],f[k+2][1],d);T.push([B[0],B[1],gt[0],gt[1],it[0],it[1]])}return T}}function ee(n,t,e){const i=_i(n),s=Vs(Hs(i)),o=[];let r=[],a=[0,0],l=[];const c=()=>{l.length>=4&&r.push(...Ps(l,t)),l=[]},d=()=>{c(),r.length&&(o.push(r),r=[])};for(const{key:f,data:u}of s)switch(f){case"M":d(),a=[u[0],u[1]],r.push(a);break;case"L":c(),r.push([u[0],u[1]]);break;case"C":if(!l.length){const p=r.length?r[r.length-1]:a;l.push([p[0],p[1]])}l.push([u[0],u[1]]),l.push([u[2],u[3]]),l.push([u[4],u[5]]);break;case"Z":c(),r.push([a[0],a[1]]);break}return d(),o}const Re=10,X=class X{static setSeed(t){X.nextInt=Be(t)}static blinkBarrier(t){(X.nextInt()>>>0)%1e3===0&&(t.isHidden=!t.isHidden)}static reverseObstacle(t){(X.nextInt()>>>0)%1e3===0&&(t.vel[0]*=-1)}static perturbDisk(t){if(Math.abs(t.dx)>Re){const e=(X.nextInt()>>>0)%6;e===0?t.dx+=1:e===1&&(t.dx-=1)}if(Math.abs(t.dy)>Re){const e=(X.nextInt()>>>0)%6;e===0?t.dy+=1:e===1&&(t.dy-=1)}}};h(X,"nextInt",Be(Pe())),h(X,"randomSeed",Pe);let P=X;function Pe(){return Math.floor(Math.random()*32e3)}function Be(n){let t=n|0;return t===0&&(t=1),function(){return t^=t<<13,t^=t>>>17,t^=t<<5,t|0}}class Lt{constructor(t,e,i,s){h(this,"boundingRect");h(this,"collisionRect");h(this,"points");h(this,"vel",[100,0]);h(this,"minX",20*w);h(this,"maxX",80*w);h(this,"isHidden",!1);h(this,"isStatic",!0);h(this,"label",null);this.pos=t,this.path=e,this.lut=i,this.room=s,this.points=ee(e)[0],this.collisionRect=[t[0]-i.maxOffsetX,t[1]-i.maxOffsetY,2*i.maxOffsetX,2*i.maxOffsetY],this.boundingRect=this.collisionRect}step(){if(this.isStatic)return;P.reverseObstacle(this);const{pos:t,vel:e,minX:i,maxX:s,lut:o}=this;(e[0]<0&&t[0]<i||e[0]>0&&t[0]>s)&&(e[0]*=-1),t[0]+=e[0],t[1]+=e[1],this.collisionRect[0]=t[0]-o.maxOffsetX,this.collisionRect[1]=t[1]-o.maxOffsetY}}const Fe=5*w,wt=1*w,He=45*w;function Ve(n,t){return n.replace(/-?\d*\.?\d+(?:e[+-]?\d+)?/gi,e=>String(parseFloat(e)*t))}const tt={roundrect:Ye(5*Fe,1*Fe,wt),breakoutbrick:Ye($t,ot,wt),diamond:Ve("M197.6 42.4 42.4 197.6a60 60 0 0 0 0 84.8l155.2 155.2a60 60 0 0 0 84.8 0l155.2-155.2a60 60 0 0 0 0-84.8L282.4 42.4a60 60 0 0 0-84.8 0Z",w/40),star:Ve("M256 38.013c-22.458 0-66.472 110.3-84.64 123.502-18.17 13.2-136.674 20.975-143.614 42.334-6.94 21.358 84.362 97.303 91.302 118.662 6.94 21.36-22.286 136.465-4.116 149.665 18.17 13.2 118.61-50.164 141.068-50.164 22.458 0 122.9 63.365 141.068 50.164 18.17-13.2-11.056-128.306-4.116-149.665 6.94-21.36 98.242-97.304 91.302-118.663-6.94-21.36-125.444-29.134-143.613-42.335-18.168-13.2-62.182-123.502-84.64-123.502z",w/40),rightwedge:Ns(He,ot,wt),leftwedge:Xs(He,ot,wt)};function Ns(n,t,e){const i=n/2,s=t/2;return`M${-i+e},${s} L${i-e},${s} Q${i},${s} ${i},${s-e} L${i},${-s+e} Q${i},${-s} ${i-e},${-s} L${-i+e},${s-e} Q${-i},${s} ${-i+e},${s} Z`}function Xs(n,t,e){const i=n/2,s=t/2;return`M${i-e},${s} Q${i},${s} ${i-e},${s-e} L${-i+e},${-s} Q${-i},${-s} ${-i},${-s+e} L${-i},${s-e} Q${-i},${s} ${-i+e},${s} L${i-e},${s} Z`}function Ye(n,t,e){const i=n/2,s=t/2;return`M${-i+e},${s} L${i-e},${s} Q${i},${s} ${i},${s-e} L${i},${-s+e} Q${i},${-s} ${i-e},${-s} L${-i+e},${-s} Q${-i},${-s} ${-i},${-s+e} L${-i},${s-e} Q${-i},${s} ${-i+e},${s} Z`}const Us=[[[20*w,100*w],"leftwedge"],[[80*w,100*w],"rightwedge"]];class I{constructor(){h(this,"name","");h(this,"bounds",{})}wedges(){return Us.map(([t,e])=>new Lt([t[0],t[1]+this.bounds[1]],tt[e],_.create("obstacle-lut",e),this))}obstacleHit(t){}static register(t,e){if(t in this._registry)throw new Error(`Room already registered: '${t}'`);this._registry[t]=e}static create(t,e){if(!(t in this._registry))throw new Error(`room not registered: ${t}`);const i=this._registry[t],s=i();return s.bounds=e,s.name=t,s}}h(I,"_registry",{});const $i=10,ki=10,zs=10,Mi=ki+100*ct+$i*(ct-1)+zs,Ne=50,js=[0,Mi-Ne,100,Ne],xt=1,Ks=[xt,xt,100-2*xt,Mi-2*xt].map(n=>n*w);class Ws{constructor(){h(this,"rooms");this.rooms=Array.from({length:ct},(t,e)=>{const s=[0,w*(ki+(100+$i)*e),100*w,100*w];return qs(e,s)})}get finish(){return js}get bounds(){return Ks}buildObstacles(){const t=[];for(const[e,i]of this.rooms.entries())t.push(...i.buildObstacles());return t}}function qs(n,t){if(n===0)return I.create("start-room",t);if(n===ct-1)return I.create("finish-room",t);const e=P.nextInt()>>>0;let i=Xe[e%Xe.length];return I.create(i,t)}const Xe=["basic-room","breakout-room","pong-room"];class Gs{constructor(t,e,i,s){h(this,"isHidden",!1);h(this,"xr");h(this,"yr");h(this,"xywh");t=Math.floor(t),e=Math.floor(e),i=Math.floor(i),s=Math.floor(s),this.xywh=[t,e,i,s],this.xr=[t-A,t+i+A],this.yr=[e-A,e+s+A]}advance(){}isTouchingDisk(t,e){return t>this.xr[0]&&t<this.xr[1]&&e>this.yr[0]&&e<this.yr[1]}isCornerTouchingDisk(){}draw(t){t.fillRect(...this.xywh)}}const Qs=100,D=20,Ei=Qs*D,Ue=n=>Math.floor(n*D/Ei),ze=n=>n*Ei/D,Y=10,Ii=2*A,je=n=>Math.floor(n*Y/Ii),Ke=n=>n*Ii/Y,he=class he extends _{constructor(){super(...arguments);h(this,"blobUrl",U.DISK_DISK_LUT.url);h(this,"blobHash",U.DISK_DISK_LUT.hash);h(this,"detail",[Y*2+1,Y*2+1,D*2+1,D*2+1])}computeLeaf(e){const i=Ke(e[0]-Y),s=Ke(e[1]-Y),o=ze(e[2]-D),r=ze(e[3]-D);return Js(i,s,o,r)}};_.register("disk-disk-lut",{depth:4,leafLength:4,factory:()=>new he});let We=he;function Js(n,t,e,i){const s=n*n+t*t,o=A*2;if(s<o*o){const r=Math.sqrt(s)||1,a=o-r,l=n/r,c=t/r,d=a/2,f=e*l+i*c;if(f>0)return null;const u=2*f/2;return[Math.round(l*d),Math.round(c*d),-Math.round(u*l),-Math.round(u*c)]}return null}function Zs(n,t){const e=je(t.currentState.x-n.currentState.x),i=je(t.currentState.y-n.currentState.y);if(Math.abs(e)>Y||Math.abs(i)>Y)return!1;let s=Ue(t.currentState.dx-n.currentState.dx),o=Ue(t.currentState.dy-n.currentState.dy);Math.abs(s)>D&&(s=D*Math.sign(s)),Math.abs(o)>D&&(o=D*Math.sign(o));const r=_.create("disk-disk-lut").tree[e+Y][i+Y][s+D][o+D];if(!r)return!1;const[a,l,c,d]=r;if(r.some(f=>isNaN(f)))throw new Error("collisions has nan bounce value");return n.nextState.x-=a,n.nextState.y-=l,t.nextState.x+=a,t.nextState.y+=l,n.nextState.dx-=c,n.nextState.dy-=d,t.nextState.dx+=c,t.nextState.dy+=d,!0}const Et=[];for(let n=0;n<5;n++)for(let t=0;t<2;t++)Et.length!==dt&&Et.push([20+n*10,20+t*10,500-n*10,500+n*5]);if(Et.length!==dt)throw new Error("wrong disk count");class Li{constructor(t){h(this,"level");h(this,"disks");h(this,"obstacles");h(this,"finish");h(this,"branchSeed",-1);h(this,"winningDiskIndex",-1);h(this,"_stepCount",0);h(this,"t",0);P.setSeed(t),this.level=new Ws;let e=0;this.disks=Et.map(i=>{const s=[...i];s[0]*=w,s[1]*=w;const o=lt.fromJson(s);return o.pattern=Xt[e%Xt.length],e++,o}),this.obstacles=this.level.buildObstacles(),this.finish=new Gs(...this.level.finish.map(i=>i*w))}get stepCount(){return this._stepCount}step(){this._stepCount++;for(const t of this.obstacles)t.step();for(let t=1;t<this.disks.length;t++)for(let e=0;e<t;e++)Zs(this.disks[t],this.disks[e]);for(const[t,e]of this.disks.entries())e.advance(this.obstacles),e.pushInBounds(this.level.bounds),P.perturbDisk(e.nextState),e.nextState.dy+=1,this.winningDiskIndex===-1&&this.finish.isTouchingDisk(e.nextState.x,e.nextState.y)&&(this.winningDiskIndex=t);lt.flushStates(this.disks),lt.updateHistory(this.disks),this._stepCount===Ct&&this.branchSeed!==-1&&P.setSeed(this.branchSeed)}update(t){this.t+=t;const e=Math.ceil(this.t/At),i=(this.t-(e-1)*At)/At;for(;this._stepCount<e;)this.step();for(const s of this.disks)s.stepFrac=i,s.interpolatedPos[0]=Nt(s.lastStepPos[0],s.currentState.x,i),s.interpolatedPos[1]=Nt(s.lastStepPos[1],s.currentState.y,i)}}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class N{constructor(t,e,i,s,o="div"){this.parent=t,this.object=e,this.property=i,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(o),this.domElement.classList.add("controller"),this.domElement.classList.add(s),this.$name=document.createElement("div"),this.$name.classList.add("name"),N.nextNameID=N.nextNameID||0,this.$name.id=`lil-gui-name-${++N.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",r=>r.stopPropagation()),this.domElement.addEventListener("keyup",r=>r.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(i)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class tn extends N{constructor(t,e,i){super(t,e,i,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function jt(n){let t,e;return(t=n.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=n.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=n.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const en={isPrimitive:!0,match:n=>typeof n=="string",fromHexString:jt,toHexString:jt},ht={isPrimitive:!0,match:n=>typeof n=="number",fromHexString:n=>parseInt(n.substring(1),16),toHexString:n=>"#"+n.toString(16).padStart(6,0)},sn={isPrimitive:!1,match:n=>Array.isArray(n),fromHexString(n,t,e=1){const i=ht.fromHexString(n);t[0]=(i>>16&255)/255*e,t[1]=(i>>8&255)/255*e,t[2]=(i&255)/255*e},toHexString([n,t,e],i=1){i=255/i;const s=n*i<<16^t*i<<8^e*i<<0;return ht.toHexString(s)}},nn={isPrimitive:!1,match:n=>Object(n)===n,fromHexString(n,t,e=1){const i=ht.fromHexString(n);t.r=(i>>16&255)/255*e,t.g=(i>>8&255)/255*e,t.b=(i&255)/255*e},toHexString({r:n,g:t,b:e},i=1){i=255/i;const s=n*i<<16^t*i<<8^e*i<<0;return ht.toHexString(s)}},on=[en,ht,sn,nn];function rn(n){return on.find(t=>t.match(n))}class an extends N{constructor(t,e,i,s){super(t,e,i,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=rn(this.initialValue),this._rgbScale=s,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const o=jt(this.$text.value);o&&this._setValueFromHexString(o)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class Pt extends N{constructor(t,e,i){super(t,e,i,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",s=>{s.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class ln extends N{constructor(t,e,i,s,o,r){super(t,e,i,"number"),this._initInput(),this.min(s),this.max(o);const a=r!==void 0;this.step(a?r:this._getImplicitStep(),a),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let m=parseFloat(this.$input.value);isNaN(m)||(this._stepExplicit&&(m=this._snap(m)),this.setValue(this._clamp(m)))},i=m=>{const $=parseFloat(this.$input.value);isNaN($)||(this._snapClampSetValue($+m),this.$input.value=this.getValue())},s=m=>{m.key==="Enter"&&this.$input.blur(),m.code==="ArrowUp"&&(m.preventDefault(),i(this._step*this._arrowKeyMultiplier(m))),m.code==="ArrowDown"&&(m.preventDefault(),i(this._step*this._arrowKeyMultiplier(m)*-1))},o=m=>{this._inputFocused&&(m.preventDefault(),i(this._step*this._normalizeMouseWheel(m)))};let r=!1,a,l,c,d,f;const u=5,p=m=>{a=m.clientX,l=c=m.clientY,r=!0,d=this.getValue(),f=0,window.addEventListener("mousemove",g),window.addEventListener("mouseup",y)},g=m=>{if(r){const $=m.clientX-a,j=m.clientY-l;Math.abs(j)>u?(m.preventDefault(),this.$input.blur(),r=!1,this._setDraggingStyle(!0,"vertical")):Math.abs($)>u&&y()}if(!r){const $=m.clientY-c;f-=$*this._step*this._arrowKeyMultiplier(m),d+f>this._max?f=this._max-d:d+f<this._min&&(f=this._min-d),this._snapClampSetValue(d+f)}c=m.clientY},y=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",y)},x=()=>{this._inputFocused=!0},b=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",s),this.$input.addEventListener("wheel",o,{passive:!1}),this.$input.addEventListener("mousedown",p),this.$input.addEventListener("focus",x),this.$input.addEventListener("blur",b)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(b,m,$,j,et)=>(b-m)/($-m)*(et-j)+j,e=b=>{const m=this.$slider.getBoundingClientRect();let $=t(b,m.left,m.right,this._min,this._max);this._snapClampSetValue($)},i=b=>{this._setDraggingStyle(!0),e(b.clientX),window.addEventListener("mousemove",s),window.addEventListener("mouseup",o)},s=b=>{e(b.clientX)},o=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",s),window.removeEventListener("mouseup",o)};let r=!1,a,l;const c=b=>{b.preventDefault(),this._setDraggingStyle(!0),e(b.touches[0].clientX),r=!1},d=b=>{b.touches.length>1||(this._hasScrollBar?(a=b.touches[0].clientX,l=b.touches[0].clientY,r=!0):c(b),window.addEventListener("touchmove",f,{passive:!1}),window.addEventListener("touchend",u))},f=b=>{if(r){const m=b.touches[0].clientX-a,$=b.touches[0].clientY-l;Math.abs(m)>Math.abs($)?c(b):(window.removeEventListener("touchmove",f),window.removeEventListener("touchend",u))}else b.preventDefault(),e(b.touches[0].clientX)},u=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",f),window.removeEventListener("touchend",u)},p=this._callOnFinishChange.bind(this),g=400;let y;const x=b=>{if(Math.abs(b.deltaX)<Math.abs(b.deltaY)&&this._hasScrollBar)return;b.preventDefault();const $=this._normalizeMouseWheel(b)*this._step;this._snapClampSetValue(this.getValue()+$),this.$input.value=this.getValue(),clearTimeout(y),y=setTimeout(p,g)};this.$slider.addEventListener("mousedown",i),this.$slider.addEventListener("touchstart",d,{passive:!1}),this.$slider.addEventListener("wheel",x,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:i}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,i=-t.wheelDelta/120,i*=this._stepExplicit?1:10),e+-i}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class cn extends N{constructor(t,e,i,s){super(t,e,i,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(s)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const i=document.createElement("option");i.textContent=e,this.$select.appendChild(i)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class hn extends N{constructor(t,e,i){super(t,e,i,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",s=>{s.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var dn=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function un(n){const t=document.createElement("style");t.innerHTML=n;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let qe=!1;class ie{constructor({parent:t,autoPlace:e=t===void 0,container:i,width:s,title:o="Controls",closeFolders:r=!1,injectStyles:a=!0,touchStyles:l=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(o),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),l&&this.domElement.classList.add("allow-touch-styles"),!qe&&a&&(un(dn),qe=!0),i?i.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),s&&this.domElement.style.setProperty("--width",s+"px"),this._closeFolders=r}add(t,e,i,s,o){if(Object(i)===i)return new cn(this,t,e,i);const r=t[e];switch(typeof r){case"number":return new ln(this,t,e,i,s,o);case"boolean":return new tn(this,t,e);case"string":return new hn(this,t,e);case"function":return new Pt(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,r)}addColor(t,e,i=1){return new an(this,t,e,i)}addFolder(t){const e=new ie({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(i=>{i instanceof Pt||i._name in t.controllers&&i.load(t.controllers[i._name])}),e&&t.folders&&this.folders.forEach(i=>{i._title in t.folders&&i.load(t.folders[i._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(i=>{if(!(i instanceof Pt)){if(i._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${i._name}"`);e.controllers[i._name]=i.save()}}),t&&this.folders.forEach(i=>{if(i._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${i._title}"`);e.folders[i._title]=i.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const i=o=>{o.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",i))};this.$children.addEventListener("transitionend",i);const s=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=s+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(i=>i.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let Kt={},J;function fn(n,t){Kt={},J&&J.destroy(),J=new ie({closeFolders:!0,container:document.getElementById("controls-container")}),Di(J,t,n),J.onOpenClose(()=>{J._closed&&setTimeout(()=>{J.destroy()},200)})}function Di(n,t,e){const i=t.children;for(const s in i){const o=i[s];if(!("isHidden"in o&&o.isHidden))if("action"in o){const r=o,a=o.label??vt(s),l={[a]:async()=>{await r.action(e)}};n.add(l,a)}else if("options"in o&&Array.isArray(o.options)){const r=o,a={};for(const c of r.options)typeof c=="string"&&(a[c]=c);const l=n.add(r,"value",a).name(r.label??vt(s)).listen();l.onChange(c=>{r.value=c,r.onChange&&r.onChange(e,c)}),Bt(l,r.tooltip),Kt[s]=l}else if("value"in o&&typeof o.value=="number"){const r=o,a=n.add(r,"value",r.min,r.max).name(r.label??vt(s));r.step&&a.step(r.step),a.onChange(l=>{typeof l=="number"&&(r.value=l,r.onChange&&r.onChange(e,l))}),Bt(a,r.tooltip),Kt[s]=a}else{const r=n.addFolder(o.label??vt(s));Bt(r,o.tooltip),Di(r,o,e)}}}function Bt(n,t){if(typeof t!="string"||t.trim()==="")return;n.domElement.setAttribute("title",t)}function vt(n){return/^[A-Z0-9_]+$/.test(n)?n.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():n.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}let Ge=!1,Qe=!1;class pn{constructor(){h(this,"activeSim");h(this,"gui");h(this,"isTitleScreen",!0);h(this,"speed","normal");h(this,"selectedDiskIndex",-1);h(this,"camera",new cs);h(this,"isSeedConfiged",!1);h(this,"_race",[]);h(this,"_speedMult",1);h(this,"mousePos",[0,0]);h(this,"simMousePos",[0,0]);h(this,"isMouseDown",!1);h(this,"dragY",0);h(this,"didBuildControls",!1);if(Ge)throw new Error("PinballWizard constructed multiple times");Ge=!0}async init(){if(Qe)throw new Error("PinballWizard initialized multiple times");Qe=!0;const t=M.flatConfig.rngSeed;this.isSeedConfiged=t!==-1;const e=_.create("race-lut").tree;this._race=e[Math.floor(Math.random()*e.length)];const i=this.isSeedConfiged?t:this._race[0];qi(Xt),this.activeSim=new Li(i),this.isSeedConfiged||(this.activeSim.branchSeed=this._race[1]);const s=1+dt,o=this.activeSim.level.rooms.find(r=>"breakoutBricks"in r);if(o)for(let r=0;r<ci;r++)o.breakoutBricks[r].label=`${this._race[r+s]}`;this.gui=z.create("playing-gui"),this.camera.jumpToRoom(this,0),window.addEventListener("resize",()=>this.onResize()),this.onResize()}update(t){const e=this.hasBranched,i=li[this.speed],s=t*M.flatConfig.speedLerp;this._speedMult<i&&(this._speedMult=Math.min(i,this._speedMult+s)),this._speedMult>i&&(this._speedMult=Math.max(i,this._speedMult-s)),this.activeSim.update(t*this._speedMult),this.activeSim.winningDiskIndex!==-1&&(this.speed="paused",this._speedMult=0),this.hasBranched&&!e&&this.onResize(),this.camera.update(t,this),S.drawOffset[1]=this.camera.pos*S.drawSimScale+S.cvs.height/2,S.drawSim(this.activeSim,this.selectedDiskIndex),S.drawCursor(this.mousePos),Ms(this.activeSim.stepCount),this.debugBranchCountdown(S.ctx,S.cvs.width,S.cvs.height)}get hasBranched(){return this.activeSim.stepCount>=Ct}debugBranchCountdown(t,e,i){const o=Math.min(1,this.activeSim.stepCount/Ct);t.fillStyle="white",t.fillRect(0,0,e,20),t.fillStyle="black",t.fillRect(0,0,e*o,20)}locateDiskOnScreen(t){const e=this.activeSim.disks[t],[i,s]=e.interpolatedPos,o=A*w*S.drawSimScale,r=S.drawOffset[0]+i*S.drawSimScale,a=S.drawOffset[1]+s*S.drawSimScale;return[r-o,a-o,2*o,2*o]}move(t){this.isMouseDown&&(this.camera.drag(this.dragY,t[1]),this.dragY=t[1]);const{drawOffset:e,drawSimScale:i}=S;this.mousePos[0]=t[0]-e[0],this.mousePos[1]=t[1]-e[1];const s=t[0]/i*window.devicePixelRatio-e[0]/i,o=t[1]/i*window.devicePixelRatio-e[1]/i;return this.simMousePos[0]=s,this.simMousePos[1]=o,this.mousePos}down(t){if(this.move(t),this.isMouseDown=!0,this.dragY=t[1],!this.hasBranched)for(const[e,i]of this.activeSim.disks.entries()){const[s,o]=i.interpolatedPos;Math.pow(this.simMousePos[0]-s,2)+Math.pow(this.simMousePos[1]-o,2)<Ui&&(this.selectedDiskIndex=e,this.isSeedConfiged||(this.activeSim.branchSeed=this._race[e+1]))}}up(t){this.isMouseDown=!1,this.camera.endDrag()}rebuildControls(){this.didBuildControls=!0,fn(this,fs.tree)}onResize(){S.onResize();for(const t of Si.NAMES){const e=z.create(t),i=e===this.gui;for(const s in e.elements)xi(s,i);this.gui&&this.gui.refreshLayout(this)}this.gui&&this.gui.showHideElements(this)}}const Oi=[],gn=20,mn=20;let Ft=10;for(;Ft<80;){let n=10;for(;n<80;)Oi.push([[Ft,n]]),n+=mn;Ft+=gn}const de=class de extends I{buildObstacles(){const t=["diamond","star"],e=P.nextInt()>>>0,i=t[e%t.length],s=Oi.map(([o])=>new Lt([o[0]*w,o[1]*w+this.bounds[1]],tt[i],_.create("obstacle-lut",i),this));return[...this.wedges(),...s]}};I.register("basic-room",()=>new de);let Je=de;const bn=$t+It,yn=ot+It,Wt=5,qt=6,wn=Math.floor(50*w-(Wt*$t+(Wt-1)*It)/2+$t/2),xn=Math.floor(50*w-(qt*ot+(qt-1)*It)/2+ot/2),Ti=[];for(let n=0;n<qt;n++)for(let t=0;t<Wt;t++)Ti.push([[wn+t*bn,xn+n*yn],"breakoutbrick"]);const ue=class ue extends I{constructor(){super(...arguments);h(this,"score",0);h(this,"hitSequence",[]);h(this,"breakoutBricks",[])}static solve(e){return zi(e)}obstacleHit(e){const i=this.breakoutBricks.indexOf(e);if(i===-1)return;if(e.isHidden=!0,this.hitSequence.includes(i))throw new Error("brick has already been hit");this.hitSequence.push(i);const s=Number(e.label);this.score+=s}buildObstacles(){return this.breakoutBricks=Ti.map(([e,i])=>new Lt([e[0],e[1]+this.bounds[1]],tt[i],_.create("obstacle-lut",i),this)),[...this.wedges(),...this.breakoutBricks]}};I.register("breakout-room",()=>new ue);let Gt=ue;const fe=class fe extends I{buildObstacles(){return[]}};I.register("finish-room",()=>new fe);let Ze=fe;const Ri=[],vn=20;let Ht=20;for(;Ht<100;)Ri.push([[50,Ht],"roundrect"]),Ht+=vn;const pe=class pe extends I{buildObstacles(){const t=Ri.map(([e,i])=>{const s=new Lt([e[0]*w,e[1]*w+this.bounds[1]],tt[i],_.create("obstacle-lut",i),this);return s.isStatic=!1,s});return[...this.wedges(),...t]}};I.register("pong-room",()=>new pe);let ti=pe;const ge=class ge extends I{buildObstacles(){return[...this.wedges()]}};I.register("start-room",()=>new ge);let ei=ge;const St=100,Sn=n=>(Math.floor(n*St/rt)%St+St)%St,me=class me extends _{constructor(){super(...arguments);h(this,"shape","roundrect");h(this,"blobHash","");h(this,"blobUrl","");h(this,"obsOffsetDetailX",1);h(this,"obsOffsetDetailY",1);h(this,"maxOffsetX",1);h(this,"maxOffsetY",1);h(this,"detail",[this.obsOffsetDetailX*2+1,this.obsOffsetDetailY*2+1]);h(this,"offsetToXIndex",e=>Math.floor(e/H));h(this,"offsetToYIndex",e=>Math.floor(e/H));h(this,"indexToXOffset",e=>e*H);h(this,"indexToYOffset",e=>e*H)}computeAll(){let e=0,i=0;for(const s of ee(tt[this.shape])[0]){const[o,r]=s.map(a=>Math.abs(a));o>e&&(e=o),r>i&&(i=r)}e+=A,i+=A,e=Math.floor(e/H),i=Math.floor(i/H),this.obsOffsetDetailX=e,this.obsOffsetDetailY=i,this.maxOffsetX=e*H,this.maxOffsetY=i*H,this.detail=[this.obsOffsetDetailX*2+1,this.obsOffsetDetailY*2+1],super.computeAll()}async loadAll(){await super.loadAll()}computeLeaf(e){const i=this.indexToXOffset(e[0]-this.obsOffsetDetailX),s=this.indexToYOffset(e[1]-this.obsOffsetDetailY);return Cn(this.shape,[i,s])}};_.register("obstacle-lut",{factory:()=>new me,depth:2,leafLength:3});let ii=me;const Vt={};function An(n){if(!Object.hasOwn(Vt,n)){const t=_n(tt[n]);Vt[n]=t}return Vt[n]}function _n(n){let t=ee(n)[0];const e=A/10;let i=!0;for(;i;){i=!1;const s=[];for(let o=0;o<t.length;o++){const r=t[o],a=t[(o+1)%t.length];s.push(r);const l=a[0]-r[0],c=a[1]-r[1];if(l*l+c*c>e*e){const f=[(r[0]+a[0])/2,(r[1]+a[1])/2];s.push(f),i=!0}}t=s}return t}function Cn(n,t){const e=An(n),i=$n(t,e);let s=1/0,o=0;for(const[a,l]of e.entries()){const c=l[0]-t[0],d=l[1]-t[1],f=c*c+d*d;f<s&&(s=f,o=a)}const r=Math.sqrt(s);if(i||r<A){const a=e.length,l=e[(o+1)%a],c=e[(o-1+a)%a],d=Math.atan2(c[1]-l[1],c[0]-l[0])-Ki,f=A-r,u=[Math.round(f*Math.cos(d)),Math.round(f*Math.sin(d))];return[u[0],u[1],Sn(d)]}else return null}function $n(n,t){const[e,i]=n;let s=!1;for(let o=0;o<t.length;o++){const r=(o+1)%t.length,a=t[o][0],l=t[o][1],c=t[r][0],d=t[r][1];l>i!=d>i&&e<(c-a)*(i-l)/(d-l)+a&&(s=!s)}return s}const kn=100,si=1e7,Qt=1+dt;var ri,ai;const be=class be extends _{constructor(){super(...arguments);h(this,"detail",[kn]);h(this,"blobUrl",(ri=U.RACE_LUT)==null?void 0:ri.url);h(this,"blobHash",(ai=U.RACE_LUT)==null?void 0:ai.hash)}computeLeaf(e){for(;;){const i=Mn();if(i)return i}}async loadAll(){await super.loadAll()}};_.register("race-lut",{factory:()=>new be,depth:1,leafLength:Qt});let ni=be;function Mn(){const n=P.randomSeed(),t=Array.from({length:dt},()=>({midSeed:-1,roomSeqs:[]}));let e=0;for(;t.some(({midSeed:s})=>s===-1);){const s=new Li(n);for(let a=0;a<Ct;a++)s.step(),e++;if(s.winningDiskIndex!==-1)throw new Error("sim already has winning disk before branching");const o=P.randomSeed();for(P.setSeed(o);s.winningDiskIndex===-1&&e<si;)s.step(),e++;const r=[];for(const[a,l]of s.level.rooms.entries())l instanceof Gt?r.push(l.hitSequence):r.push(null);if(t[s.winningDiskIndex]={midSeed:o,roomSeqs:r},e>si)break}if(t.some(({midSeed:s})=>s===-1))return console.log(`failed race with start seed ${n}`),null;const i=[n,...t.map(({midSeed:s})=>s)];if(i.length!==Qt)throw new Error(`result length (${i.length}) doesn't match leaf length ${Qt}`);return console.log(`solved race with start seed ${n}`),i}function En(n){return{locateElement:t=>{if(n.isTitleScreen){const s=document.getElementById("title-iframe").contentDocument.getElementById(t),{x:o,y:r,width:a,height:l}=s==null?void 0:s.getBoundingClientRect();return[o,r,a,l]}else if(t.startsWith("ball-")){const e=Number(t.split("-")[1]);return n.locateDiskOnScreen(e)}else{const e=[z.create("playing-gui")];for(const i of e){const s=i.layoutRectangles[t];if(!s)continue;const[o,r,a,l]=s,c=1;return[o*c,r*c,a*c,l*c]}}return[100,100,100,100]},getCameraPos:()=>[0,0],getSetting:t=>M.flatConfig[t],applySetting:(t,e)=>{if(t in M.tree.children){const i=M.tree.children[t];i.value=e,i.onChange()}},getGameState:()=>{if(n.isTitleScreen)return"title-screen";const t=n.activeSim.winningDiskIndex;if(t!==-1)return`ball-${t}-finished`;const e=n.speed==="paused"?"paused":"playing",i=n.selectedDiskIndex;return i===-1?`${e}-no-ball-selected`:`${e}-ball-${i}-selected`},getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.cursorForTestSupport})}}class In{static update(t){Rn(t),Pn()}}const Ln=5,oi=.22,Dn=1e-4,On=[1,1,1],Tn=100,C=[0,1,2].map(n=>{const t=rt*n/3,e=[Math.cos(t)*oi,Math.sin(t)*oi],i=(Math.random()+1)*Dn,s=[Math.sin(t),-Math.cos(t)],o=[s[0]*i,s[1]*i];return{pos:e,vel:o,mass:On[n],trail:[e.slice()]}});function Rn(n){for(let e=0;e<C.length;e++){const i=[0,0];for(let s=0;s<C.length;s++){if(e===s)continue;const o=C[s].pos[0]-C[e].pos[0],r=C[s].pos[1]-C[e].pos[1],a=o*o+r*r+.001,l=Math.sqrt(a),c=1e-8*C[s].mass/a;i[0]+=c*o/l,i[1]+=c*r/l}C[e].vel[0]+=i[0]*n,C[e].vel[1]+=i[1]*n}for(let e=0;e<C.length;e++)C[e].pos[0]+=C[e].vel[0]*n,C[e].pos[1]+=C[e].vel[1]*n,C[e].trail.push([C[e].pos[0],C[e].pos[1]]),C[e].trail.length>Tn&&C[e].trail.shift()}function Pn(){const{cvs:n,ctx:t}=S,e=n.width,i=n.height,s=Math.min(e,i)*.5;t.save(),t.globalAlpha=1,t.fillStyle="#ddd",t.fillRect(0,0,e,i),t.restore(),t.fillStyle="#888";for(const o of C)if(o.trail.length>1)for(let r=0;r<o.trail.length;r++){const[a,l]=o.trail[r],c=e/2+a*s,d=i/2+l*s;t.fillRect(c,d,1,1)}for(const o of C){const[r,a]=[e/2+o.pos[0]*s,i/2+o.pos[1]*s];t.beginPath(),t.arc(r,a,Ln,0,2*Math.PI),t.fillStyle="#888",t.shadowColor="#555",t.shadowBlur=8,t.fill(),t.shadowBlur=0}}async function Bn(){await new Promise(a=>{const l=document.getElementById("title-iframe");l.contentDocument&&l.contentDocument.readyState==="complete"?a():l.addEventListener("load",()=>a(),{once:!0})}),Zt.refreshConfig();const n=new pn;window.TestSupport=En(n),Fn(n),await Hn();for(const a of Si.NAMES)z.preload(n,a);n.onResize();const i=document.getElementById("title-iframe").contentDocument.getElementById("start-button");i.onclick=async()=>{await n.init(),n.gui=z.create("playing-gui"),n.isTitleScreen=!1,n.onResize(),s.classList.add("hidden")};const s=document.getElementById("title-screen");s.classList.remove("hidden"),navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",a=>{window.mouseXForTestSupport=a.clientX,window.mouseYForTestSupport=a.clientY;const l=window.getComputedStyle(a.target).cursor;l==="auto"?window.cursorForTestSupport="default":window.cursorForTestSupport=l,a.stopPropagation()});let o=performance.now();function r(){requestAnimationFrame(r);const a=performance.now(),l=Math.min(50,a-o);o=a,n.isTitleScreen?In.update(l):n.update(l)}r()}Bn();function Fn(n){const t=[0,0];S.cvs.addEventListener("pointermove",e=>{t[0]=e.clientX,t[1]=e.clientY,n.move(t)}),S.cvs.addEventListener("pointerdown",e=>{t[0]=e.clientX,t[1]=e.clientY,n.down(t)}),S.cvs.addEventListener("pointerup",e=>{t[0]=e.clientX,t[1]=e.clientY,n.up(t)}),S.cvs.addEventListener("pointerleave",e=>{t[0]=e.clientX,t[1]=e.clientY,n.up(t)}),S.cvs.addEventListener("wheel",e=>{n.camera.scroll(e.deltaY)})}async function Hn(){for(const n of Ds.NAMES)if(n==="obstacle-lut")for(const t of Object.keys(tt))await _.create(n,t).loadAll();else await _.create(n).loadAll()}
