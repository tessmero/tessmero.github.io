var Bc=Object.defineProperty;var Hc=(i,e,t)=>e in i?Bc(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var ye=(i,e,t)=>Hc(i,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const o of s.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();function Gc(i,e){return new Proxy(i,{get(t,n,r){return Reflect.get(t,n,r)},set(t,n,r,s){return Reflect.set(t,n,r,s)}})}function Vc(i,e){return new Proxy(i,{get(t,n,r){return Reflect.get(t,n,r)},set(t,n,r,s){return Reflect.set(t,n,r,s)}})}globalThis.__trackObject=Gc;globalThis.__trackArray=Vc;/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Va="181",Oi={ROTATE:0,DOLLY:1,PAN:2},yi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},kc=0,So=1,Wc=2,Ul=1,Yc=2,In=3,Kt=0,It=1,ln=2,bn=0,Ci=1,mo=2,Ao=3,xo=4,zc=5,si=100,Kc=101,Xc=102,qc=103,Zc=104,Jc=200,jc=201,Qc=202,$c=203,Xs=204,qs=205,eu=206,tu=207,nu=208,iu=209,ru=210,su=211,au=212,ou=213,lu=214,Zs=0,Js=1,js=2,Di=3,Qs=4,$s=5,ea=6,ta=7,wl=0,cu=1,uu=2,Xn=0,hu=1,du=2,fu=3,pu=4,Eu=5,Su=6,mu=7,Fl=300,Pi=301,Ui=302,na=303,ia=304,rs=306,ra=1e3,Ln=1001,sa=1002,Yt=1003,Au=1004,Ar=1005,$t=1006,hs=1007,oi=1008,Cn=1009,Bl=1010,Hl=1011,sr=1012,ka=1013,ci=1014,yn=1015,Hi=1016,Wa=1017,Ya=1018,ar=1020,Gl=35902,Vl=35899,kl=1021,Wl=1022,un=1023,or=1026,lr=1027,Yl=1028,za=1029,Ka=1030,Xa=1031,qa=1033,Yr=33776,zr=33777,Kr=33778,Xr=33779,aa=35840,oa=35841,la=35842,ca=35843,ua=36196,ha=37492,da=37496,fa=37808,pa=37809,Ea=37810,Sa=37811,ma=37812,Aa=37813,xa=37814,_a=37815,ga=37816,Ta=37817,Ra=37818,va=37819,Ma=37820,Ia=37821,La=36492,ya=36494,ba=36495,Oa=36283,Ca=36284,Na=36285,Da=36286,xu=3200,_u=3201,gu=0,Tu=1,Wn="",Ft="srgb",wi="srgb-linear",jr="linear",rt="srgb",pi=7680,_o=519,Ru=512,vu=513,Mu=514,zl=515,Iu=516,Lu=517,yu=518,bu=519,go=35044,To="300 es",mn=2e3,Qr=2001;function Kl(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function $r(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Ou(){const i=$r("canvas");return i.style.display="block",i}const Ro={};function vo(...i){const e="THREE."+i.shift();console.log(e,...i)}function Ke(...i){const e="THREE."+i.shift();console.warn(e,...i)}function dt(...i){const e="THREE."+i.shift();console.error(e,...i)}function cr(...i){const e=i.join(" ");e in Ro||(Ro[e]=!0,Ke(...i))}function Cu(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}class hi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,o=r.length;s<o;s++)r[s].call(this,e);e.target=null}}}const Lt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],qr=Math.PI/180,Pa=180/Math.PI;function Gi(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Lt[i&255]+Lt[i>>8&255]+Lt[i>>16&255]+Lt[i>>24&255]+"-"+Lt[e&255]+Lt[e>>8&255]+"-"+Lt[e>>16&15|64]+Lt[e>>24&255]+"-"+Lt[t&63|128]+Lt[t>>8&255]+"-"+Lt[t>>16&255]+Lt[t>>24&255]+Lt[n&255]+Lt[n>>8&255]+Lt[n>>16&255]+Lt[n>>24&255]).toLowerCase()}function Je(i,e,t){return Math.max(e,Math.min(t,i))}function Nu(i,e){return(i%e+e)%e}function ds(i,e,t){return(1-t)*i+t*e}function Xi(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function Ut(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const Du={DEG2RAD:qr};class oe{constructor(e=0,t=0){oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*n-o*r+e.x,this.y=s*r+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Nn{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,o,c){let d=n[r+0],h=n[r+1],p=n[r+2],a=n[r+3],l=s[o+0],u=s[o+1],E=s[o+2],m=s[o+3];if(c<=0){e[t+0]=d,e[t+1]=h,e[t+2]=p,e[t+3]=a;return}if(c>=1){e[t+0]=l,e[t+1]=u,e[t+2]=E,e[t+3]=m;return}if(a!==m||d!==l||h!==u||p!==E){let S=d*l+h*u+p*E+a*m;S<0&&(l=-l,u=-u,E=-E,m=-m,S=-S);let f=1-c;if(S<.9995){const v=Math.acos(S),A=Math.sin(v);f=Math.sin(f*v)/A,c=Math.sin(c*v)/A,d=d*f+l*c,h=h*f+u*c,p=p*f+E*c,a=a*f+m*c}else{d=d*f+l*c,h=h*f+u*c,p=p*f+E*c,a=a*f+m*c;const v=1/Math.sqrt(d*d+h*h+p*p+a*a);d*=v,h*=v,p*=v,a*=v}}e[t]=d,e[t+1]=h,e[t+2]=p,e[t+3]=a}static multiplyQuaternionsFlat(e,t,n,r,s,o){const c=n[r],d=n[r+1],h=n[r+2],p=n[r+3],a=s[o],l=s[o+1],u=s[o+2],E=s[o+3];return e[t]=c*E+p*a+d*u-h*l,e[t+1]=d*E+p*l+h*a-c*u,e[t+2]=h*E+p*u+c*l-d*a,e[t+3]=p*E-c*a-d*l-h*u,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,o=e._order,c=Math.cos,d=Math.sin,h=c(n/2),p=c(r/2),a=c(s/2),l=d(n/2),u=d(r/2),E=d(s/2);switch(o){case"XYZ":this._x=l*p*a+h*u*E,this._y=h*u*a-l*p*E,this._z=h*p*E+l*u*a,this._w=h*p*a-l*u*E;break;case"YXZ":this._x=l*p*a+h*u*E,this._y=h*u*a-l*p*E,this._z=h*p*E-l*u*a,this._w=h*p*a+l*u*E;break;case"ZXY":this._x=l*p*a-h*u*E,this._y=h*u*a+l*p*E,this._z=h*p*E+l*u*a,this._w=h*p*a-l*u*E;break;case"ZYX":this._x=l*p*a-h*u*E,this._y=h*u*a+l*p*E,this._z=h*p*E-l*u*a,this._w=h*p*a+l*u*E;break;case"YZX":this._x=l*p*a+h*u*E,this._y=h*u*a+l*p*E,this._z=h*p*E-l*u*a,this._w=h*p*a-l*u*E;break;case"XZY":this._x=l*p*a-h*u*E,this._y=h*u*a-l*p*E,this._z=h*p*E+l*u*a,this._w=h*p*a+l*u*E;break;default:Ke("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],o=t[1],c=t[5],d=t[9],h=t[2],p=t[6],a=t[10],l=n+c+a;if(l>0){const u=.5/Math.sqrt(l+1);this._w=.25/u,this._x=(p-d)*u,this._y=(s-h)*u,this._z=(o-r)*u}else if(n>c&&n>a){const u=2*Math.sqrt(1+n-c-a);this._w=(p-d)/u,this._x=.25*u,this._y=(r+o)/u,this._z=(s+h)/u}else if(c>a){const u=2*Math.sqrt(1+c-n-a);this._w=(s-h)/u,this._x=(r+o)/u,this._y=.25*u,this._z=(d+p)/u}else{const u=2*Math.sqrt(1+a-n-c);this._w=(o-r)/u,this._x=(s+h)/u,this._y=(d+p)/u,this._z=.25*u}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Je(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,o=e._w,c=t._x,d=t._y,h=t._z,p=t._w;return this._x=n*p+o*c+r*h-s*d,this._y=r*p+o*d+s*c-n*h,this._z=s*p+o*h+n*d-r*c,this._w=o*p-n*c-r*d-s*h,this._onChangeCallback(),this}slerp(e,t){if(t<=0)return this;if(t>=1)return this.copy(e);let n=e._x,r=e._y,s=e._z,o=e._w,c=this.dot(e);c<0&&(n=-n,r=-r,s=-s,o=-o,c=-c);let d=1-t;if(c<.9995){const h=Math.acos(c),p=Math.sin(h);d=Math.sin(d*h)/p,t=Math.sin(t*h)/p,this._x=this._x*d+n*t,this._y=this._y*d+r*t,this._z=this._z*d+s*t,this._w=this._w*d+o*t,this._onChangeCallback()}else this._x=this._x*d+n*t,this._y=this._y*d+r*t,this._z=this._z*d+s*t,this._w=this._w*d+o*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class V{constructor(e=0,t=0,n=0){V.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Mo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Mo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,o=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*o,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*o,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,o=e.y,c=e.z,d=e.w,h=2*(o*r-c*n),p=2*(c*t-s*r),a=2*(s*n-o*t);return this.x=t+d*h+o*a-c*p,this.y=n+d*p+c*h-s*a,this.z=r+d*a+s*p-o*h,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,o=t.x,c=t.y,d=t.z;return this.x=r*d-s*c,this.y=s*o-n*d,this.z=n*c-r*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return fs.copy(this).projectOnVector(e),this.sub(fs)}reflect(e){return this.sub(fs.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const fs=new V,Mo=new Nn;class Ye{constructor(e,t,n,r,s,o,c,d,h){Ye.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,o,c,d,h)}set(e,t,n,r,s,o,c,d,h){const p=this.elements;return p[0]=e,p[1]=r,p[2]=c,p[3]=t,p[4]=s,p[5]=d,p[6]=n,p[7]=o,p[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,o=n[0],c=n[3],d=n[6],h=n[1],p=n[4],a=n[7],l=n[2],u=n[5],E=n[8],m=r[0],S=r[3],f=r[6],v=r[1],A=r[4],R=r[7],C=r[2],y=r[5],N=r[8];return s[0]=o*m+c*v+d*C,s[3]=o*S+c*A+d*y,s[6]=o*f+c*R+d*N,s[1]=h*m+p*v+a*C,s[4]=h*S+p*A+a*y,s[7]=h*f+p*R+a*N,s[2]=l*m+u*v+E*C,s[5]=l*S+u*A+E*y,s[8]=l*f+u*R+E*N,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],c=e[5],d=e[6],h=e[7],p=e[8];return t*o*p-t*c*h-n*s*p+n*c*d+r*s*h-r*o*d}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],c=e[5],d=e[6],h=e[7],p=e[8],a=p*o-c*h,l=c*d-p*s,u=h*s-o*d,E=t*a+n*l+r*u;if(E===0)return this.set(0,0,0,0,0,0,0,0,0);const m=1/E;return e[0]=a*m,e[1]=(r*h-p*n)*m,e[2]=(c*n-r*o)*m,e[3]=l*m,e[4]=(p*t-r*d)*m,e[5]=(r*s-c*t)*m,e[6]=u*m,e[7]=(n*d-h*t)*m,e[8]=(o*t-n*s)*m,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,o,c){const d=Math.cos(s),h=Math.sin(s);return this.set(n*d,n*h,-n*(d*o+h*c)+o+e,-r*h,r*d,-r*(-h*o+d*c)+c+t,0,0,1),this}scale(e,t){return this.premultiply(ps.makeScale(e,t)),this}rotate(e){return this.premultiply(ps.makeRotation(-e)),this}translate(e,t){return this.premultiply(ps.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const ps=new Ye,Io=new Ye().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Lo=new Ye().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Pu(){const i={enabled:!0,workingColorSpace:wi,spaces:{},convert:function(r,s,o){return this.enabled===!1||s===o||!s||!o||(this.spaces[s].transfer===rt&&(r.r=On(r.r),r.g=On(r.g),r.b=On(r.b)),this.spaces[s].primaries!==this.spaces[o].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===rt&&(r.r=Ni(r.r),r.g=Ni(r.g),r.b=Ni(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Wn?jr:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,o){return r.copy(this.spaces[s].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,s){return cr("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(r,s)},toWorkingColorSpace:function(r,s){return cr("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(r,s)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[wi]:{primaries:e,whitePoint:n,transfer:jr,toXYZ:Io,fromXYZ:Lo,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Ft},outputColorSpaceConfig:{drawingBufferColorSpace:Ft}},[Ft]:{primaries:e,whitePoint:n,transfer:rt,toXYZ:Io,fromXYZ:Lo,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Ft}}}),i}const $e=Pu();function On(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Ni(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let Ei;class Uu{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Ei===void 0&&(Ei=$r("canvas")),Ei.width=e.width,Ei.height=e.height;const r=Ei.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=Ei}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=$r("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let o=0;o<s.length;o++)s[o]=On(s[o]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(On(t[n]/255)*255):t[n]=On(t[n]);return{data:t,width:e.width,height:e.height}}else return Ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let wu=0;class Za{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:wu++}),this.uuid=Gi(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let o=0,c=r.length;o<c;o++)r[o].isDataTexture?s.push(Es(r[o].image)):s.push(Es(r[o]))}else s=Es(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Es(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Uu.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Ke("Texture: Unable to serialize Texture."),{})}let Fu=0;const Ss=new V;class Nt extends hi{constructor(e=Nt.DEFAULT_IMAGE,t=Nt.DEFAULT_MAPPING,n=Ln,r=Ln,s=$t,o=oi,c=un,d=Cn,h=Nt.DEFAULT_ANISOTROPY,p=Wn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Fu++}),this.uuid=Gi(),this.name="",this.source=new Za(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=o,this.anisotropy=h,this.format=c,this.internalFormat=null,this.type=d,this.offset=new oe(0,0),this.repeat=new oe(1,1),this.center=new oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ye,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=p,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Ss).x}get height(){return this.source.getSize(Ss).y}get depth(){return this.source.getSize(Ss).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){Ke(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Ke(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Fl)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case ra:e.x=e.x-Math.floor(e.x);break;case Ln:e.x=e.x<0?0:1;break;case sa:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case ra:e.y=e.y-Math.floor(e.y);break;case Ln:e.y=e.y<0?0:1;break;case sa:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Nt.DEFAULT_IMAGE=null;Nt.DEFAULT_MAPPING=Fl;Nt.DEFAULT_ANISOTROPY=1;class St{constructor(e=0,t=0,n=0,r=1){St.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*r+o[12]*s,this.y=o[1]*t+o[5]*n+o[9]*r+o[13]*s,this.z=o[2]*t+o[6]*n+o[10]*r+o[14]*s,this.w=o[3]*t+o[7]*n+o[11]*r+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const d=e.elements,h=d[0],p=d[4],a=d[8],l=d[1],u=d[5],E=d[9],m=d[2],S=d[6],f=d[10];if(Math.abs(p-l)<.01&&Math.abs(a-m)<.01&&Math.abs(E-S)<.01){if(Math.abs(p+l)<.1&&Math.abs(a+m)<.1&&Math.abs(E+S)<.1&&Math.abs(h+u+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const A=(h+1)/2,R=(u+1)/2,C=(f+1)/2,y=(p+l)/4,N=(a+m)/4,w=(E+S)/4;return A>R&&A>C?A<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(A),r=y/n,s=N/n):R>C?R<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(R),n=y/r,s=w/r):C<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(C),n=N/s,r=w/s),this.set(n,r,s,t),this}let v=Math.sqrt((S-E)*(S-E)+(a-m)*(a-m)+(l-p)*(l-p));return Math.abs(v)<.001&&(v=1),this.x=(S-E)/v,this.y=(a-m)/v,this.z=(l-p)/v,this.w=Math.acos((h+u+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this.w=Je(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this.w=Je(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Bu extends hi{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:$t,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new St(0,0,e,t),this.scissorTest=!1,this.viewport=new St(0,0,e,t);const r={width:e,height:t,depth:n.depth},s=new Nt(r);this.textures=[];const o=n.count;for(let c=0;c<o;c++)this.textures[c]=s.clone(),this.textures[c].isRenderTargetTexture=!0,this.textures[c].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:$t,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new Za(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Zn extends Bu{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Xl extends Nt{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Yt,this.minFilter=Yt,this.wrapR=Ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Hu extends Nt{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Yt,this.minFilter=Yt,this.wrapR=Ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Vi{constructor(e=new V(1/0,1/0,1/0),t=new V(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(nn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(nn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=nn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,c=s.count;o<c;o++)e.isMesh===!0?e.getVertexPosition(o,nn):nn.fromBufferAttribute(s,o),nn.applyMatrix4(e.matrixWorld),this.expandByPoint(nn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),xr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),xr.copy(n.boundingBox)),xr.applyMatrix4(e.matrixWorld),this.union(xr)}const r=e.children;for(let s=0,o=r.length;s<o;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,nn),nn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(qi),_r.subVectors(this.max,qi),Si.subVectors(e.a,qi),mi.subVectors(e.b,qi),Ai.subVectors(e.c,qi),Pn.subVectors(mi,Si),Un.subVectors(Ai,mi),Qn.subVectors(Si,Ai);let t=[0,-Pn.z,Pn.y,0,-Un.z,Un.y,0,-Qn.z,Qn.y,Pn.z,0,-Pn.x,Un.z,0,-Un.x,Qn.z,0,-Qn.x,-Pn.y,Pn.x,0,-Un.y,Un.x,0,-Qn.y,Qn.x,0];return!ms(t,Si,mi,Ai,_r)||(t=[1,0,0,0,1,0,0,0,1],!ms(t,Si,mi,Ai,_r))?!1:(gr.crossVectors(Pn,Un),t=[gr.x,gr.y,gr.z],ms(t,Si,mi,Ai,_r))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,nn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(nn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(xn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),xn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),xn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),xn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),xn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),xn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),xn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),xn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(xn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const xn=[new V,new V,new V,new V,new V,new V,new V,new V],nn=new V,xr=new Vi,Si=new V,mi=new V,Ai=new V,Pn=new V,Un=new V,Qn=new V,qi=new V,_r=new V,gr=new V,$n=new V;function ms(i,e,t,n,r){for(let s=0,o=i.length-3;s<=o;s+=3){$n.fromArray(i,s);const c=r.x*Math.abs($n.x)+r.y*Math.abs($n.y)+r.z*Math.abs($n.z),d=e.dot($n),h=t.dot($n),p=n.dot($n);if(Math.max(-Math.max(d,h,p),Math.min(d,h,p))>c)return!1}return!0}const Gu=new Vi,Zi=new V,As=new V;class Ja{constructor(e=new V,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Gu.setFromPoints(e).getCenter(n);let r=0;for(let s=0,o=e.length;s<o;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Zi.subVectors(e,this.center);const t=Zi.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(Zi,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(As.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Zi.copy(e.center).add(As)),this.expandByPoint(Zi.copy(e.center).sub(As))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const _n=new V,xs=new V,Tr=new V,wn=new V,_s=new V,Rr=new V,gs=new V;class ja{constructor(e=new V,t=new V(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,_n)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=_n.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(_n.copy(this.origin).addScaledVector(this.direction,t),_n.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){xs.copy(e).add(t).multiplyScalar(.5),Tr.copy(t).sub(e).normalize(),wn.copy(this.origin).sub(xs);const s=e.distanceTo(t)*.5,o=-this.direction.dot(Tr),c=wn.dot(this.direction),d=-wn.dot(Tr),h=wn.lengthSq(),p=Math.abs(1-o*o);let a,l,u,E;if(p>0)if(a=o*d-c,l=o*c-d,E=s*p,a>=0)if(l>=-E)if(l<=E){const m=1/p;a*=m,l*=m,u=a*(a+o*l+2*c)+l*(o*a+l+2*d)+h}else l=s,a=Math.max(0,-(o*l+c)),u=-a*a+l*(l+2*d)+h;else l=-s,a=Math.max(0,-(o*l+c)),u=-a*a+l*(l+2*d)+h;else l<=-E?(a=Math.max(0,-(-o*s+c)),l=a>0?-s:Math.min(Math.max(-s,-d),s),u=-a*a+l*(l+2*d)+h):l<=E?(a=0,l=Math.min(Math.max(-s,-d),s),u=l*(l+2*d)+h):(a=Math.max(0,-(o*s+c)),l=a>0?s:Math.min(Math.max(-s,-d),s),u=-a*a+l*(l+2*d)+h);else l=o>0?-s:s,a=Math.max(0,-(o*l+c)),u=-a*a+l*(l+2*d)+h;return n&&n.copy(this.origin).addScaledVector(this.direction,a),r&&r.copy(xs).addScaledVector(Tr,l),u}intersectSphere(e,t){_n.subVectors(e.center,this.origin);const n=_n.dot(this.direction),r=_n.dot(_n)-n*n,s=e.radius*e.radius;if(r>s)return null;const o=Math.sqrt(s-r),c=n-o,d=n+o;return d<0?null:c<0?this.at(d,t):this.at(c,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,o,c,d;const h=1/this.direction.x,p=1/this.direction.y,a=1/this.direction.z,l=this.origin;return h>=0?(n=(e.min.x-l.x)*h,r=(e.max.x-l.x)*h):(n=(e.max.x-l.x)*h,r=(e.min.x-l.x)*h),p>=0?(s=(e.min.y-l.y)*p,o=(e.max.y-l.y)*p):(s=(e.max.y-l.y)*p,o=(e.min.y-l.y)*p),n>o||s>r||((s>n||isNaN(n))&&(n=s),(o<r||isNaN(r))&&(r=o),a>=0?(c=(e.min.z-l.z)*a,d=(e.max.z-l.z)*a):(c=(e.max.z-l.z)*a,d=(e.min.z-l.z)*a),n>d||c>r)||((c>n||n!==n)&&(n=c),(d<r||r!==r)&&(r=d),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,_n)!==null}intersectTriangle(e,t,n,r,s){_s.subVectors(t,e),Rr.subVectors(n,e),gs.crossVectors(_s,Rr);let o=this.direction.dot(gs),c;if(o>0){if(r)return null;c=1}else if(o<0)c=-1,o=-o;else return null;wn.subVectors(this.origin,e);const d=c*this.direction.dot(Rr.crossVectors(wn,Rr));if(d<0)return null;const h=c*this.direction.dot(_s.cross(wn));if(h<0||d+h>o)return null;const p=-c*wn.dot(gs);return p<0?null:this.at(p/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class mt{constructor(e,t,n,r,s,o,c,d,h,p,a,l,u,E,m,S){mt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,o,c,d,h,p,a,l,u,E,m,S)}set(e,t,n,r,s,o,c,d,h,p,a,l,u,E,m,S){const f=this.elements;return f[0]=e,f[4]=t,f[8]=n,f[12]=r,f[1]=s,f[5]=o,f[9]=c,f[13]=d,f[2]=h,f[6]=p,f[10]=a,f[14]=l,f[3]=u,f[7]=E,f[11]=m,f[15]=S,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new mt().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,r=1/xi.setFromMatrixColumn(e,0).length(),s=1/xi.setFromMatrixColumn(e,1).length(),o=1/xi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,o=Math.cos(n),c=Math.sin(n),d=Math.cos(r),h=Math.sin(r),p=Math.cos(s),a=Math.sin(s);if(e.order==="XYZ"){const l=o*p,u=o*a,E=c*p,m=c*a;t[0]=d*p,t[4]=-d*a,t[8]=h,t[1]=u+E*h,t[5]=l-m*h,t[9]=-c*d,t[2]=m-l*h,t[6]=E+u*h,t[10]=o*d}else if(e.order==="YXZ"){const l=d*p,u=d*a,E=h*p,m=h*a;t[0]=l+m*c,t[4]=E*c-u,t[8]=o*h,t[1]=o*a,t[5]=o*p,t[9]=-c,t[2]=u*c-E,t[6]=m+l*c,t[10]=o*d}else if(e.order==="ZXY"){const l=d*p,u=d*a,E=h*p,m=h*a;t[0]=l-m*c,t[4]=-o*a,t[8]=E+u*c,t[1]=u+E*c,t[5]=o*p,t[9]=m-l*c,t[2]=-o*h,t[6]=c,t[10]=o*d}else if(e.order==="ZYX"){const l=o*p,u=o*a,E=c*p,m=c*a;t[0]=d*p,t[4]=E*h-u,t[8]=l*h+m,t[1]=d*a,t[5]=m*h+l,t[9]=u*h-E,t[2]=-h,t[6]=c*d,t[10]=o*d}else if(e.order==="YZX"){const l=o*d,u=o*h,E=c*d,m=c*h;t[0]=d*p,t[4]=m-l*a,t[8]=E*a+u,t[1]=a,t[5]=o*p,t[9]=-c*p,t[2]=-h*p,t[6]=u*a+E,t[10]=l-m*a}else if(e.order==="XZY"){const l=o*d,u=o*h,E=c*d,m=c*h;t[0]=d*p,t[4]=-a,t[8]=h*p,t[1]=l*a+m,t[5]=o*p,t[9]=u*a-E,t[2]=E*a-u,t[6]=c*p,t[10]=m*a+l}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Vu,e,ku)}lookAt(e,t,n){const r=this.elements;return Gt.subVectors(e,t),Gt.lengthSq()===0&&(Gt.z=1),Gt.normalize(),Fn.crossVectors(n,Gt),Fn.lengthSq()===0&&(Math.abs(n.z)===1?Gt.x+=1e-4:Gt.z+=1e-4,Gt.normalize(),Fn.crossVectors(n,Gt)),Fn.normalize(),vr.crossVectors(Gt,Fn),r[0]=Fn.x,r[4]=vr.x,r[8]=Gt.x,r[1]=Fn.y,r[5]=vr.y,r[9]=Gt.y,r[2]=Fn.z,r[6]=vr.z,r[10]=Gt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,o=n[0],c=n[4],d=n[8],h=n[12],p=n[1],a=n[5],l=n[9],u=n[13],E=n[2],m=n[6],S=n[10],f=n[14],v=n[3],A=n[7],R=n[11],C=n[15],y=r[0],N=r[4],w=r[8],I=r[12],_=r[1],P=r[5],G=r[9],Z=r[13],j=r[2],$=r[6],ie=r[10],Q=r[14],B=r[3],pe=r[7],le=r[11],_e=r[15];return s[0]=o*y+c*_+d*j+h*B,s[4]=o*N+c*P+d*$+h*pe,s[8]=o*w+c*G+d*ie+h*le,s[12]=o*I+c*Z+d*Q+h*_e,s[1]=p*y+a*_+l*j+u*B,s[5]=p*N+a*P+l*$+u*pe,s[9]=p*w+a*G+l*ie+u*le,s[13]=p*I+a*Z+l*Q+u*_e,s[2]=E*y+m*_+S*j+f*B,s[6]=E*N+m*P+S*$+f*pe,s[10]=E*w+m*G+S*ie+f*le,s[14]=E*I+m*Z+S*Q+f*_e,s[3]=v*y+A*_+R*j+C*B,s[7]=v*N+A*P+R*$+C*pe,s[11]=v*w+A*G+R*ie+C*le,s[15]=v*I+A*Z+R*Q+C*_e,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],o=e[1],c=e[5],d=e[9],h=e[13],p=e[2],a=e[6],l=e[10],u=e[14],E=e[3],m=e[7],S=e[11],f=e[15];return E*(+s*d*a-r*h*a-s*c*l+n*h*l+r*c*u-n*d*u)+m*(+t*d*u-t*h*l+s*o*l-r*o*u+r*h*p-s*d*p)+S*(+t*h*a-t*c*u-s*o*a+n*o*u+s*c*p-n*h*p)+f*(-r*c*p-t*d*a+t*c*l+r*o*a-n*o*l+n*d*p)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],c=e[5],d=e[6],h=e[7],p=e[8],a=e[9],l=e[10],u=e[11],E=e[12],m=e[13],S=e[14],f=e[15],v=a*S*h-m*l*h+m*d*u-c*S*u-a*d*f+c*l*f,A=E*l*h-p*S*h-E*d*u+o*S*u+p*d*f-o*l*f,R=p*m*h-E*a*h+E*c*u-o*m*u-p*c*f+o*a*f,C=E*a*d-p*m*d-E*c*l+o*m*l+p*c*S-o*a*S,y=t*v+n*A+r*R+s*C;if(y===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const N=1/y;return e[0]=v*N,e[1]=(m*l*s-a*S*s-m*r*u+n*S*u+a*r*f-n*l*f)*N,e[2]=(c*S*s-m*d*s+m*r*h-n*S*h-c*r*f+n*d*f)*N,e[3]=(a*d*s-c*l*s-a*r*h+n*l*h+c*r*u-n*d*u)*N,e[4]=A*N,e[5]=(p*S*s-E*l*s+E*r*u-t*S*u-p*r*f+t*l*f)*N,e[6]=(E*d*s-o*S*s-E*r*h+t*S*h+o*r*f-t*d*f)*N,e[7]=(o*l*s-p*d*s+p*r*h-t*l*h-o*r*u+t*d*u)*N,e[8]=R*N,e[9]=(E*a*s-p*m*s-E*n*u+t*m*u+p*n*f-t*a*f)*N,e[10]=(o*m*s-E*c*s+E*n*h-t*m*h-o*n*f+t*c*f)*N,e[11]=(p*c*s-o*a*s-p*n*h+t*a*h+o*n*u-t*c*u)*N,e[12]=C*N,e[13]=(p*m*r-E*a*r+E*n*l-t*m*l-p*n*S+t*a*S)*N,e[14]=(E*c*r-o*m*r-E*n*d+t*m*d+o*n*S-t*c*S)*N,e[15]=(o*a*r-p*c*r+p*n*d-t*a*d-o*n*l+t*c*l)*N,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,o=e.x,c=e.y,d=e.z,h=s*o,p=s*c;return this.set(h*o+n,h*c-r*d,h*d+r*c,0,h*c+r*d,p*c+n,p*d-r*o,0,h*d-r*c,p*d+r*o,s*d*d+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,o){return this.set(1,n,s,0,e,1,o,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,o=t._y,c=t._z,d=t._w,h=s+s,p=o+o,a=c+c,l=s*h,u=s*p,E=s*a,m=o*p,S=o*a,f=c*a,v=d*h,A=d*p,R=d*a,C=n.x,y=n.y,N=n.z;return r[0]=(1-(m+f))*C,r[1]=(u+R)*C,r[2]=(E-A)*C,r[3]=0,r[4]=(u-R)*y,r[5]=(1-(l+f))*y,r[6]=(S+v)*y,r[7]=0,r[8]=(E+A)*N,r[9]=(S-v)*N,r[10]=(1-(l+m))*N,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;let s=xi.set(r[0],r[1],r[2]).length();const o=xi.set(r[4],r[5],r[6]).length(),c=xi.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],rn.copy(this);const h=1/s,p=1/o,a=1/c;return rn.elements[0]*=h,rn.elements[1]*=h,rn.elements[2]*=h,rn.elements[4]*=p,rn.elements[5]*=p,rn.elements[6]*=p,rn.elements[8]*=a,rn.elements[9]*=a,rn.elements[10]*=a,t.setFromRotationMatrix(rn),n.x=s,n.y=o,n.z=c,this}makePerspective(e,t,n,r,s,o,c=mn,d=!1){const h=this.elements,p=2*s/(t-e),a=2*s/(n-r),l=(t+e)/(t-e),u=(n+r)/(n-r);let E,m;if(d)E=s/(o-s),m=o*s/(o-s);else if(c===mn)E=-(o+s)/(o-s),m=-2*o*s/(o-s);else if(c===Qr)E=-o/(o-s),m=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+c);return h[0]=p,h[4]=0,h[8]=l,h[12]=0,h[1]=0,h[5]=a,h[9]=u,h[13]=0,h[2]=0,h[6]=0,h[10]=E,h[14]=m,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(e,t,n,r,s,o,c=mn,d=!1){const h=this.elements,p=2/(t-e),a=2/(n-r),l=-(t+e)/(t-e),u=-(n+r)/(n-r);let E,m;if(d)E=1/(o-s),m=o/(o-s);else if(c===mn)E=-2/(o-s),m=-(o+s)/(o-s);else if(c===Qr)E=-1/(o-s),m=-s/(o-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+c);return h[0]=p,h[4]=0,h[8]=0,h[12]=l,h[1]=0,h[5]=a,h[9]=0,h[13]=u,h[2]=0,h[6]=0,h[10]=E,h[14]=m,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const xi=new V,rn=new mt,Vu=new V(0,0,0),ku=new V(1,1,1),Fn=new V,vr=new V,Gt=new V,yo=new mt,bo=new Nn;class Dn{constructor(e=0,t=0,n=0,r=Dn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],o=r[4],c=r[8],d=r[1],h=r[5],p=r[9],a=r[2],l=r[6],u=r[10];switch(t){case"XYZ":this._y=Math.asin(Je(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-p,u),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(l,h),this._z=0);break;case"YXZ":this._x=Math.asin(-Je(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(c,u),this._z=Math.atan2(d,h)):(this._y=Math.atan2(-a,s),this._z=0);break;case"ZXY":this._x=Math.asin(Je(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(-a,u),this._z=Math.atan2(-o,h)):(this._y=0,this._z=Math.atan2(d,s));break;case"ZYX":this._y=Math.asin(-Je(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(l,u),this._z=Math.atan2(d,s)):(this._x=0,this._z=Math.atan2(-o,h));break;case"YZX":this._z=Math.asin(Je(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-p,h),this._y=Math.atan2(-a,s)):(this._x=0,this._y=Math.atan2(c,u));break;case"XZY":this._z=Math.asin(-Je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(l,h),this._y=Math.atan2(c,s)):(this._x=Math.atan2(-p,u),this._y=0);break;default:Ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return yo.makeRotationFromQuaternion(e),this.setFromRotationMatrix(yo,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return bo.setFromEuler(this),this.setFromQuaternion(bo,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Dn.DEFAULT_ORDER="XYZ";class Qa{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Wu=0;const Oo=new V,_i=new Nn,gn=new mt,Mr=new V,Ji=new V,Yu=new V,zu=new Nn,Co=new V(1,0,0),No=new V(0,1,0),Do=new V(0,0,1),Po={type:"added"},Ku={type:"removed"},gi={type:"childadded",child:null},Ts={type:"childremoved",child:null};class zt extends hi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Wu++}),this.uuid=Gi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=zt.DEFAULT_UP.clone();const e=new V,t=new Dn,n=new Nn,r=new V(1,1,1);function s(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new mt},normalMatrix:{value:new Ye}}),this.matrix=new mt,this.matrixWorld=new mt,this.matrixAutoUpdate=zt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=zt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Qa,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return _i.setFromAxisAngle(e,t),this.quaternion.multiply(_i),this}rotateOnWorldAxis(e,t){return _i.setFromAxisAngle(e,t),this.quaternion.premultiply(_i),this}rotateX(e){return this.rotateOnAxis(Co,e)}rotateY(e){return this.rotateOnAxis(No,e)}rotateZ(e){return this.rotateOnAxis(Do,e)}translateOnAxis(e,t){return Oo.copy(e).applyQuaternion(this.quaternion),this.position.add(Oo.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Co,e)}translateY(e){return this.translateOnAxis(No,e)}translateZ(e){return this.translateOnAxis(Do,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(gn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Mr.copy(e):Mr.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),Ji.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?gn.lookAt(Ji,Mr,this.up):gn.lookAt(Mr,Ji,this.up),this.quaternion.setFromRotationMatrix(gn),r&&(gn.extractRotation(r.matrixWorld),_i.setFromRotationMatrix(gn),this.quaternion.premultiply(_i.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(dt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Po),gi.child=e,this.dispatchEvent(gi),gi.child=null):dt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Ku),Ts.child=e,this.dispatchEvent(Ts),Ts.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),gn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),gn.multiply(e.parent.matrixWorld)),e.applyMatrix4(gn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Po),gi.child=e,this.dispatchEvent(gi),gi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ji,e,Yu),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ji,zu,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(c=>({...c,boundingBox:c.boundingBox?c.boundingBox.toJSON():void 0,boundingSphere:c.boundingSphere?c.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(c=>({...c})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(c,d){return c[d.uuid]===void 0&&(c[d.uuid]=d.toJSON(e)),d.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const c=this.geometry.parameters;if(c!==void 0&&c.shapes!==void 0){const d=c.shapes;if(Array.isArray(d))for(let h=0,p=d.length;h<p;h++){const a=d[h];s(e.shapes,a)}else s(e.shapes,d)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const c=[];for(let d=0,h=this.material.length;d<h;d++)c.push(s(e.materials,this.material[d]));r.material=c}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let c=0;c<this.children.length;c++)r.children.push(this.children[c].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let c=0;c<this.animations.length;c++){const d=this.animations[c];r.animations.push(s(e.animations,d))}}if(t){const c=o(e.geometries),d=o(e.materials),h=o(e.textures),p=o(e.images),a=o(e.shapes),l=o(e.skeletons),u=o(e.animations),E=o(e.nodes);c.length>0&&(n.geometries=c),d.length>0&&(n.materials=d),h.length>0&&(n.textures=h),p.length>0&&(n.images=p),a.length>0&&(n.shapes=a),l.length>0&&(n.skeletons=l),u.length>0&&(n.animations=u),E.length>0&&(n.nodes=E)}return n.object=r,n;function o(c){const d=[];for(const h in c){const p=c[h];delete p.metadata,d.push(p)}return d}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}}zt.DEFAULT_UP=new V(0,1,0);zt.DEFAULT_MATRIX_AUTO_UPDATE=!0;zt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const sn=new V,Tn=new V,Rs=new V,Rn=new V,Ti=new V,Ri=new V,Uo=new V,vs=new V,Ms=new V,Is=new V,Ls=new St,ys=new St,bs=new St;class cn{constructor(e=new V,t=new V,n=new V){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),sn.subVectors(e,t),r.cross(sn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){sn.subVectors(r,t),Tn.subVectors(n,t),Rs.subVectors(e,t);const o=sn.dot(sn),c=sn.dot(Tn),d=sn.dot(Rs),h=Tn.dot(Tn),p=Tn.dot(Rs),a=o*h-c*c;if(a===0)return s.set(0,0,0),null;const l=1/a,u=(h*d-c*p)*l,E=(o*p-c*d)*l;return s.set(1-u-E,E,u)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Rn)===null?!1:Rn.x>=0&&Rn.y>=0&&Rn.x+Rn.y<=1}static getInterpolation(e,t,n,r,s,o,c,d){return this.getBarycoord(e,t,n,r,Rn)===null?(d.x=0,d.y=0,"z"in d&&(d.z=0),"w"in d&&(d.w=0),null):(d.setScalar(0),d.addScaledVector(s,Rn.x),d.addScaledVector(o,Rn.y),d.addScaledVector(c,Rn.z),d)}static getInterpolatedAttribute(e,t,n,r,s,o){return Ls.setScalar(0),ys.setScalar(0),bs.setScalar(0),Ls.fromBufferAttribute(e,t),ys.fromBufferAttribute(e,n),bs.fromBufferAttribute(e,r),o.setScalar(0),o.addScaledVector(Ls,s.x),o.addScaledVector(ys,s.y),o.addScaledVector(bs,s.z),o}static isFrontFacing(e,t,n,r){return sn.subVectors(n,t),Tn.subVectors(e,t),sn.cross(Tn).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return sn.subVectors(this.c,this.b),Tn.subVectors(this.a,this.b),sn.cross(Tn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return cn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return cn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return cn.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return cn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return cn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let o,c;Ti.subVectors(r,n),Ri.subVectors(s,n),vs.subVectors(e,n);const d=Ti.dot(vs),h=Ri.dot(vs);if(d<=0&&h<=0)return t.copy(n);Ms.subVectors(e,r);const p=Ti.dot(Ms),a=Ri.dot(Ms);if(p>=0&&a<=p)return t.copy(r);const l=d*a-p*h;if(l<=0&&d>=0&&p<=0)return o=d/(d-p),t.copy(n).addScaledVector(Ti,o);Is.subVectors(e,s);const u=Ti.dot(Is),E=Ri.dot(Is);if(E>=0&&u<=E)return t.copy(s);const m=u*h-d*E;if(m<=0&&h>=0&&E<=0)return c=h/(h-E),t.copy(n).addScaledVector(Ri,c);const S=p*E-u*a;if(S<=0&&a-p>=0&&u-E>=0)return Uo.subVectors(s,r),c=(a-p)/(a-p+(u-E)),t.copy(r).addScaledVector(Uo,c);const f=1/(S+m+l);return o=m*f,c=l*f,t.copy(n).addScaledVector(Ti,o).addScaledVector(Ri,c)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const ql={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Bn={h:0,s:0,l:0},Ir={h:0,s:0,l:0};function Os(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class tt{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Ft){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,$e.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=$e.workingColorSpace){return this.r=e,this.g=t,this.b=n,$e.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=$e.workingColorSpace){if(e=Nu(e,1),t=Je(t,0,1),n=Je(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,o=2*n-s;this.r=Os(o,s,e+1/3),this.g=Os(o,s,e),this.b=Os(o,s,e-1/3)}return $e.colorSpaceToWorking(this,r),this}setStyle(e,t=Ft){function n(s){s!==void 0&&parseFloat(s)<1&&Ke("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const o=r[1],c=r[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:Ke("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);Ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Ft){const n=ql[e.toLowerCase()];return n!==void 0?this.setHex(n,t):Ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=On(e.r),this.g=On(e.g),this.b=On(e.b),this}copyLinearToSRGB(e){return this.r=Ni(e.r),this.g=Ni(e.g),this.b=Ni(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ft){return $e.workingToColorSpace(yt.copy(this),e),Math.round(Je(yt.r*255,0,255))*65536+Math.round(Je(yt.g*255,0,255))*256+Math.round(Je(yt.b*255,0,255))}getHexString(e=Ft){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=$e.workingColorSpace){$e.workingToColorSpace(yt.copy(this),t);const n=yt.r,r=yt.g,s=yt.b,o=Math.max(n,r,s),c=Math.min(n,r,s);let d,h;const p=(c+o)/2;if(c===o)d=0,h=0;else{const a=o-c;switch(h=p<=.5?a/(o+c):a/(2-o-c),o){case n:d=(r-s)/a+(r<s?6:0);break;case r:d=(s-n)/a+2;break;case s:d=(n-r)/a+4;break}d/=6}return e.h=d,e.s=h,e.l=p,e}getRGB(e,t=$e.workingColorSpace){return $e.workingToColorSpace(yt.copy(this),t),e.r=yt.r,e.g=yt.g,e.b=yt.b,e}getStyle(e=Ft){$e.workingToColorSpace(yt.copy(this),e);const t=yt.r,n=yt.g,r=yt.b;return e!==Ft?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(Bn),this.setHSL(Bn.h+e,Bn.s+t,Bn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Bn),e.getHSL(Ir);const n=ds(Bn.h,Ir.h,t),r=ds(Bn.s,Ir.s,t),s=ds(Bn.l,Ir.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const yt=new tt;tt.NAMES=ql;let Xu=0;class ss extends hi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Xu++}),this.uuid=Gi(),this.name="",this.type="Material",this.blending=Ci,this.side=Kt,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Xs,this.blendDst=qs,this.blendEquation=si,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new tt(0,0,0),this.blendAlpha=0,this.depthFunc=Di,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=_o,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=pi,this.stencilZFail=pi,this.stencilZPass=pi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){Ke(`Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){Ke(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ci&&(n.blending=this.blending),this.side!==Kt&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Xs&&(n.blendSrc=this.blendSrc),this.blendDst!==qs&&(n.blendDst=this.blendDst),this.blendEquation!==si&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Di&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==_o&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==pi&&(n.stencilFail=this.stencilFail),this.stencilZFail!==pi&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==pi&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const o=[];for(const c in s){const d=s[c];delete d.metadata,o.push(d)}return o}if(t){const s=r(e.textures),o=r(e.images);s.length>0&&(n.textures=s),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Qt extends ss{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new tt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Dn,this.combine=wl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const At=new V,Lr=new oe;let qu=0;class dn{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:qu++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=go,this.updateRanges=[],this.gpuType=yn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Lr.fromBufferAttribute(this,t),Lr.applyMatrix3(e),this.setXY(t,Lr.x,Lr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)At.fromBufferAttribute(this,t),At.applyMatrix3(e),this.setXYZ(t,At.x,At.y,At.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)At.fromBufferAttribute(this,t),At.applyMatrix4(e),this.setXYZ(t,At.x,At.y,At.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)At.fromBufferAttribute(this,t),At.applyNormalMatrix(e),this.setXYZ(t,At.x,At.y,At.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)At.fromBufferAttribute(this,t),At.transformDirection(e),this.setXYZ(t,At.x,At.y,At.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Xi(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Ut(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Xi(t,this.array)),t}setX(e,t){return this.normalized&&(t=Ut(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Xi(t,this.array)),t}setY(e,t){return this.normalized&&(t=Ut(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Xi(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Ut(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Xi(t,this.array)),t}setW(e,t){return this.normalized&&(t=Ut(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Ut(t,this.array),n=Ut(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=Ut(t,this.array),n=Ut(n,this.array),r=Ut(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=Ut(t,this.array),n=Ut(n,this.array),r=Ut(r,this.array),s=Ut(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==go&&(e.usage=this.usage),e}}class Zl extends dn{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Jl extends dn{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class xt extends dn{constructor(e,t,n){super(new Float32Array(e),t,n)}}let Zu=0;const qt=new mt,Cs=new zt,vi=new V,Vt=new Vi,ji=new Vi,vt=new V;class gt extends hi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Zu++}),this.uuid=Gi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Kl(e)?Jl:Zl)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new Ye().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return qt.makeRotationFromQuaternion(e),this.applyMatrix4(qt),this}rotateX(e){return qt.makeRotationX(e),this.applyMatrix4(qt),this}rotateY(e){return qt.makeRotationY(e),this.applyMatrix4(qt),this}rotateZ(e){return qt.makeRotationZ(e),this.applyMatrix4(qt),this}translate(e,t,n){return qt.makeTranslation(e,t,n),this.applyMatrix4(qt),this}scale(e,t,n){return qt.makeScale(e,t,n),this.applyMatrix4(qt),this}lookAt(e){return Cs.lookAt(e),Cs.updateMatrix(),this.applyMatrix4(Cs.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(vi).negate(),this.translate(vi.x,vi.y,vi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const o=e[r];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new xt(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&Ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Vi);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new V(-1/0,-1/0,-1/0),new V(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];Vt.setFromBufferAttribute(s),this.morphTargetsRelative?(vt.addVectors(this.boundingBox.min,Vt.min),this.boundingBox.expandByPoint(vt),vt.addVectors(this.boundingBox.max,Vt.max),this.boundingBox.expandByPoint(vt)):(this.boundingBox.expandByPoint(Vt.min),this.boundingBox.expandByPoint(Vt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&dt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ja);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new V,1/0);return}if(e){const n=this.boundingSphere.center;if(Vt.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){const c=t[s];ji.setFromBufferAttribute(c),this.morphTargetsRelative?(vt.addVectors(Vt.min,ji.min),Vt.expandByPoint(vt),vt.addVectors(Vt.max,ji.max),Vt.expandByPoint(vt)):(Vt.expandByPoint(ji.min),Vt.expandByPoint(ji.max))}Vt.getCenter(n);let r=0;for(let s=0,o=e.count;s<o;s++)vt.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(vt));if(t)for(let s=0,o=t.length;s<o;s++){const c=t[s],d=this.morphTargetsRelative;for(let h=0,p=c.count;h<p;h++)vt.fromBufferAttribute(c,h),d&&(vi.fromBufferAttribute(e,h),vt.add(vi)),r=Math.max(r,n.distanceToSquared(vt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&dt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){dt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new dn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),c=[],d=[];for(let w=0;w<n.count;w++)c[w]=new V,d[w]=new V;const h=new V,p=new V,a=new V,l=new oe,u=new oe,E=new oe,m=new V,S=new V;function f(w,I,_){h.fromBufferAttribute(n,w),p.fromBufferAttribute(n,I),a.fromBufferAttribute(n,_),l.fromBufferAttribute(s,w),u.fromBufferAttribute(s,I),E.fromBufferAttribute(s,_),p.sub(h),a.sub(h),u.sub(l),E.sub(l);const P=1/(u.x*E.y-E.x*u.y);isFinite(P)&&(m.copy(p).multiplyScalar(E.y).addScaledVector(a,-u.y).multiplyScalar(P),S.copy(a).multiplyScalar(u.x).addScaledVector(p,-E.x).multiplyScalar(P),c[w].add(m),c[I].add(m),c[_].add(m),d[w].add(S),d[I].add(S),d[_].add(S))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let w=0,I=v.length;w<I;++w){const _=v[w],P=_.start,G=_.count;for(let Z=P,j=P+G;Z<j;Z+=3)f(e.getX(Z+0),e.getX(Z+1),e.getX(Z+2))}const A=new V,R=new V,C=new V,y=new V;function N(w){C.fromBufferAttribute(r,w),y.copy(C);const I=c[w];A.copy(I),A.sub(C.multiplyScalar(C.dot(I))).normalize(),R.crossVectors(y,I);const P=R.dot(d[w])<0?-1:1;o.setXYZW(w,A.x,A.y,A.z,P)}for(let w=0,I=v.length;w<I;++w){const _=v[w],P=_.start,G=_.count;for(let Z=P,j=P+G;Z<j;Z+=3)N(e.getX(Z+0)),N(e.getX(Z+1)),N(e.getX(Z+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new dn(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let l=0,u=n.count;l<u;l++)n.setXYZ(l,0,0,0);const r=new V,s=new V,o=new V,c=new V,d=new V,h=new V,p=new V,a=new V;if(e)for(let l=0,u=e.count;l<u;l+=3){const E=e.getX(l+0),m=e.getX(l+1),S=e.getX(l+2);r.fromBufferAttribute(t,E),s.fromBufferAttribute(t,m),o.fromBufferAttribute(t,S),p.subVectors(o,s),a.subVectors(r,s),p.cross(a),c.fromBufferAttribute(n,E),d.fromBufferAttribute(n,m),h.fromBufferAttribute(n,S),c.add(p),d.add(p),h.add(p),n.setXYZ(E,c.x,c.y,c.z),n.setXYZ(m,d.x,d.y,d.z),n.setXYZ(S,h.x,h.y,h.z)}else for(let l=0,u=t.count;l<u;l+=3)r.fromBufferAttribute(t,l+0),s.fromBufferAttribute(t,l+1),o.fromBufferAttribute(t,l+2),p.subVectors(o,s),a.subVectors(r,s),p.cross(a),n.setXYZ(l+0,p.x,p.y,p.z),n.setXYZ(l+1,p.x,p.y,p.z),n.setXYZ(l+2,p.x,p.y,p.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)vt.fromBufferAttribute(e,t),vt.normalize(),e.setXYZ(t,vt.x,vt.y,vt.z)}toNonIndexed(){function e(c,d){const h=c.array,p=c.itemSize,a=c.normalized,l=new h.constructor(d.length*p);let u=0,E=0;for(let m=0,S=d.length;m<S;m++){c.isInterleavedBufferAttribute?u=d[m]*c.data.stride+c.offset:u=d[m]*p;for(let f=0;f<p;f++)l[E++]=h[u++]}return new dn(l,p,a)}if(this.index===null)return Ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new gt,n=this.index.array,r=this.attributes;for(const c in r){const d=r[c],h=e(d,n);t.setAttribute(c,h)}const s=this.morphAttributes;for(const c in s){const d=[],h=s[c];for(let p=0,a=h.length;p<a;p++){const l=h[p],u=e(l,n);d.push(u)}t.morphAttributes[c]=d}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let c=0,d=o.length;c<d;c++){const h=o[c];t.addGroup(h.start,h.count,h.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const d=this.parameters;for(const h in d)d[h]!==void 0&&(e[h]=d[h]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const d in n){const h=n[d];e.data.attributes[d]=h.toJSON(e.data)}const r={};let s=!1;for(const d in this.morphAttributes){const h=this.morphAttributes[d],p=[];for(let a=0,l=h.length;a<l;a++){const u=h[a];p.push(u.toJSON(e.data))}p.length>0&&(r[d]=p,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const c=this.boundingSphere;return c!==null&&(e.data.boundingSphere=c.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const h in r){const p=r[h];this.setAttribute(h,p.clone(t))}const s=e.morphAttributes;for(const h in s){const p=[],a=s[h];for(let l=0,u=a.length;l<u;l++)p.push(a[l].clone(t));this.morphAttributes[h]=p}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let h=0,p=o.length;h<p;h++){const a=o[h];this.addGroup(a.start,a.count,a.materialIndex)}const c=e.boundingBox;c!==null&&(this.boundingBox=c.clone());const d=e.boundingSphere;return d!==null&&(this.boundingSphere=d.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const wo=new mt,ei=new ja,yr=new Ja,Fo=new V,br=new V,Or=new V,Cr=new V,Ns=new V,Nr=new V,Bo=new V,Dr=new V;class Mt extends zt{constructor(e=new gt,t=new Qt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){const c=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[c]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const c=this.morphTargetInfluences;if(s&&c){Nr.set(0,0,0);for(let d=0,h=s.length;d<h;d++){const p=c[d],a=s[d];p!==0&&(Ns.fromBufferAttribute(a,e),o?Nr.addScaledVector(Ns,p):Nr.addScaledVector(Ns.sub(t),p))}t.add(Nr)}return t}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),yr.copy(n.boundingSphere),yr.applyMatrix4(s),ei.copy(e.ray).recast(e.near),!(yr.containsPoint(ei.origin)===!1&&(ei.intersectSphere(yr,Fo)===null||ei.origin.distanceToSquared(Fo)>(e.far-e.near)**2))&&(wo.copy(s).invert(),ei.copy(e.ray).applyMatrix4(wo),!(n.boundingBox!==null&&ei.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ei)))}_computeIntersections(e,t,n){let r;const s=this.geometry,o=this.material,c=s.index,d=s.attributes.position,h=s.attributes.uv,p=s.attributes.uv1,a=s.attributes.normal,l=s.groups,u=s.drawRange;if(c!==null)if(Array.isArray(o))for(let E=0,m=l.length;E<m;E++){const S=l[E],f=o[S.materialIndex],v=Math.max(S.start,u.start),A=Math.min(c.count,Math.min(S.start+S.count,u.start+u.count));for(let R=v,C=A;R<C;R+=3){const y=c.getX(R),N=c.getX(R+1),w=c.getX(R+2);r=Pr(this,f,e,n,h,p,a,y,N,w),r&&(r.faceIndex=Math.floor(R/3),r.face.materialIndex=S.materialIndex,t.push(r))}}else{const E=Math.max(0,u.start),m=Math.min(c.count,u.start+u.count);for(let S=E,f=m;S<f;S+=3){const v=c.getX(S),A=c.getX(S+1),R=c.getX(S+2);r=Pr(this,o,e,n,h,p,a,v,A,R),r&&(r.faceIndex=Math.floor(S/3),t.push(r))}}else if(d!==void 0)if(Array.isArray(o))for(let E=0,m=l.length;E<m;E++){const S=l[E],f=o[S.materialIndex],v=Math.max(S.start,u.start),A=Math.min(d.count,Math.min(S.start+S.count,u.start+u.count));for(let R=v,C=A;R<C;R+=3){const y=R,N=R+1,w=R+2;r=Pr(this,f,e,n,h,p,a,y,N,w),r&&(r.faceIndex=Math.floor(R/3),r.face.materialIndex=S.materialIndex,t.push(r))}}else{const E=Math.max(0,u.start),m=Math.min(d.count,u.start+u.count);for(let S=E,f=m;S<f;S+=3){const v=S,A=S+1,R=S+2;r=Pr(this,o,e,n,h,p,a,v,A,R),r&&(r.faceIndex=Math.floor(S/3),t.push(r))}}}}function Ju(i,e,t,n,r,s,o,c){let d;if(e.side===It?d=n.intersectTriangle(o,s,r,!0,c):d=n.intersectTriangle(r,s,o,e.side===Kt,c),d===null)return null;Dr.copy(c),Dr.applyMatrix4(i.matrixWorld);const h=t.ray.origin.distanceTo(Dr);return h<t.near||h>t.far?null:{distance:h,point:Dr.clone(),object:i}}function Pr(i,e,t,n,r,s,o,c,d,h){i.getVertexPosition(c,br),i.getVertexPosition(d,Or),i.getVertexPosition(h,Cr);const p=Ju(i,e,t,n,br,Or,Cr,Bo);if(p){const a=new V;cn.getBarycoord(Bo,br,Or,Cr,a),r&&(p.uv=cn.getInterpolatedAttribute(r,c,d,h,a,new oe)),s&&(p.uv1=cn.getInterpolatedAttribute(s,c,d,h,a,new oe)),o&&(p.normal=cn.getInterpolatedAttribute(o,c,d,h,a,new V),p.normal.dot(n.direction)>0&&p.normal.multiplyScalar(-1));const l={a:c,b:d,c:h,normal:new V,materialIndex:0};cn.getNormal(br,Or,Cr,l.normal),p.face=l,p.barycoord=a}return p}class di extends gt{constructor(e=1,t=1,n=1,r=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:o};const c=this;r=Math.floor(r),s=Math.floor(s),o=Math.floor(o);const d=[],h=[],p=[],a=[];let l=0,u=0;E("z","y","x",-1,-1,n,t,e,o,s,0),E("z","y","x",1,-1,n,t,-e,o,s,1),E("x","z","y",1,1,e,n,t,r,o,2),E("x","z","y",1,-1,e,n,-t,r,o,3),E("x","y","z",1,-1,e,t,n,r,s,4),E("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(d),this.setAttribute("position",new xt(h,3)),this.setAttribute("normal",new xt(p,3)),this.setAttribute("uv",new xt(a,2));function E(m,S,f,v,A,R,C,y,N,w,I){const _=R/N,P=C/w,G=R/2,Z=C/2,j=y/2,$=N+1,ie=w+1;let Q=0,B=0;const pe=new V;for(let le=0;le<ie;le++){const _e=le*P-Z;for(let Ue=0;Ue<$;Ue++){const He=Ue*_-G;pe[m]=He*v,pe[S]=_e*A,pe[f]=j,h.push(pe.x,pe.y,pe.z),pe[m]=0,pe[S]=0,pe[f]=y>0?1:-1,p.push(pe.x,pe.y,pe.z),a.push(Ue/N),a.push(1-le/w),Q+=1}}for(let le=0;le<w;le++)for(let _e=0;_e<N;_e++){const Ue=l+_e+$*le,He=l+_e+$*(le+1),X=l+(_e+1)+$*(le+1),U=l+(_e+1)+$*le;d.push(Ue,He,U),d.push(He,X,U),B+=6}c.addGroup(u,B,I),u+=B,l+=Q}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new di(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Fi(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(Ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone():Array.isArray(r)?e[t][n]=r.slice():e[t][n]=r}}return e}function Ot(i){const e={};for(let t=0;t<i.length;t++){const n=Fi(i[t]);for(const r in n)e[r]=n[r]}return e}function ju(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function jl(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:$e.workingColorSpace}const Qu={clone:Fi,merge:Ot};var $u=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,eh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class en extends ss{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=$u,this.fragmentShader=eh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Fi(e.uniforms),this.uniformsGroups=ju(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const o=this.uniforms[r].value;o&&o.isTexture?t.uniforms[r]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[r]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[r]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[r]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[r]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[r]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[r]={type:"m4",value:o.toArray()}:t.uniforms[r]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Ql extends zt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new mt,this.projectionMatrix=new mt,this.projectionMatrixInverse=new mt,this.coordinateSystem=mn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Hn=new V,Ho=new oe,Go=new oe;class jt extends Ql{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Pa*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(qr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Pa*2*Math.atan(Math.tan(qr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Hn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Hn.x,Hn.y).multiplyScalar(-e/Hn.z),Hn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Hn.x,Hn.y).multiplyScalar(-e/Hn.z)}getViewSize(e,t){return this.getViewBounds(e,Ho,Go),t.subVectors(Go,Ho)}setViewOffset(e,t,n,r,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(qr*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const o=this.view;if(this.view!==null&&this.view.enabled){const d=o.fullWidth,h=o.fullHeight;s+=o.offsetX*r/d,t-=o.offsetY*n/h,r*=o.width/d,n*=o.height/h}const c=this.filmOffset;c!==0&&(s+=e*c/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Mi=-90,Ii=1;class th extends zt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new jt(Mi,Ii,e,t);r.layers=this.layers,this.add(r);const s=new jt(Mi,Ii,e,t);s.layers=this.layers,this.add(s);const o=new jt(Mi,Ii,e,t);o.layers=this.layers,this.add(o);const c=new jt(Mi,Ii,e,t);c.layers=this.layers,this.add(c);const d=new jt(Mi,Ii,e,t);d.layers=this.layers,this.add(d);const h=new jt(Mi,Ii,e,t);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,o,c,d]=t;for(const h of t)this.remove(h);if(e===mn)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),c.up.set(0,1,0),c.lookAt(0,0,1),d.up.set(0,1,0),d.lookAt(0,0,-1);else if(e===Qr)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),c.up.set(0,-1,0),c.lookAt(0,0,1),d.up.set(0,-1,0),d.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const h of t)this.add(h),h.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,o,c,d,h,p]=this.children,a=e.getRenderTarget(),l=e.getActiveCubeFace(),u=e.getActiveMipmapLevel(),E=e.xr.enabled;e.xr.enabled=!1;const m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,r),e.render(t,s),e.setRenderTarget(n,1,r),e.render(t,o),e.setRenderTarget(n,2,r),e.render(t,c),e.setRenderTarget(n,3,r),e.render(t,d),e.setRenderTarget(n,4,r),e.render(t,h),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),e.render(t,p),e.setRenderTarget(a,l,u),e.xr.enabled=E,n.texture.needsPMREMUpdate=!0}}class $l extends Nt{constructor(e=[],t=Pi,n,r,s,o,c,d,h,p){super(e,t,n,r,s,o,c,d,h,p),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class nh extends Zn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new $l(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new di(5,5,5),s=new en({name:"CubemapFromEquirect",uniforms:Fi(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:It,blending:bn});s.uniforms.tEquirect.value=t;const o=new Mt(r,s),c=t.minFilter;return t.minFilter===oi&&(t.minFilter=$t),new th(1,10,this).update(e,o),t.minFilter=c,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,r);e.setRenderTarget(s)}}class zn extends zt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const ih={type:"move"};class Ds{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new zn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new zn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new V,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new V),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new zn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new V,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new V),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,o=null;const c=this._targetRay,d=this._grip,h=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(h&&e.hand){o=!0;for(const m of e.hand.values()){const S=t.getJointPose(m,n),f=this._getHandJoint(h,m);S!==null&&(f.matrix.fromArray(S.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=S.radius),f.visible=S!==null}const p=h.joints["index-finger-tip"],a=h.joints["thumb-tip"],l=p.position.distanceTo(a.position),u=.02,E=.005;h.inputState.pinching&&l>u+E?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!h.inputState.pinching&&l<=u-E&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else d!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(d.matrix.fromArray(s.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,s.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(s.linearVelocity)):d.hasLinearVelocity=!1,s.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(s.angularVelocity)):d.hasAngularVelocity=!1));c!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1,this.dispatchEvent(ih)))}return c!==null&&(c.visible=r!==null),d!==null&&(d.visible=s!==null),h!==null&&(h.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new zn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class Vo extends zt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Dn,this.environmentIntensity=1,this.environmentRotation=new Dn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class rh extends Nt{constructor(e=null,t=1,n=1,r,s,o,c,d,h=Yt,p=Yt,a,l){super(null,o,c,d,h,p,r,s,a,l),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Ps=new V,sh=new V,ah=new Ye;class kn{constructor(e=new V(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=Ps.subVectors(n,t).cross(sh.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Ps),r=this.normal.dot(n);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||ah.getNormalMatrix(e),r=this.coplanarPoint(Ps).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ti=new Ja,oh=new oe(.5,.5),Ur=new V;class ec{constructor(e=new kn,t=new kn,n=new kn,r=new kn,s=new kn,o=new kn){this.planes=[e,t,n,r,s,o]}set(e,t,n,r,s,o){const c=this.planes;return c[0].copy(e),c[1].copy(t),c[2].copy(n),c[3].copy(r),c[4].copy(s),c[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=mn,n=!1){const r=this.planes,s=e.elements,o=s[0],c=s[1],d=s[2],h=s[3],p=s[4],a=s[5],l=s[6],u=s[7],E=s[8],m=s[9],S=s[10],f=s[11],v=s[12],A=s[13],R=s[14],C=s[15];if(r[0].setComponents(h-o,u-p,f-E,C-v).normalize(),r[1].setComponents(h+o,u+p,f+E,C+v).normalize(),r[2].setComponents(h+c,u+a,f+m,C+A).normalize(),r[3].setComponents(h-c,u-a,f-m,C-A).normalize(),n)r[4].setComponents(d,l,S,R).normalize(),r[5].setComponents(h-d,u-l,f-S,C-R).normalize();else if(r[4].setComponents(h-d,u-l,f-S,C-R).normalize(),t===mn)r[5].setComponents(h+d,u+l,f+S,C+R).normalize();else if(t===Qr)r[5].setComponents(d,l,S,R).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ti.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ti.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ti)}intersectsSprite(e){ti.center.set(0,0,0);const t=oh.distanceTo(e.center);return ti.radius=.7071067811865476+t,ti.applyMatrix4(e.matrixWorld),this.intersectsSphere(ti)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Ur.x=r.normal.x>0?e.max.x:e.min.x,Ur.y=r.normal.y>0?e.max.y:e.min.y,Ur.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ur)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class tc extends Nt{constructor(e,t,n=ci,r,s,o,c=Yt,d=Yt,h,p=or,a=1){if(p!==or&&p!==lr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const l={width:e,height:t,depth:a};super(l,r,s,o,c,d,p,n,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Za(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class nc extends Nt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class An{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Ke("Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,r=this.getPoint(0),s=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),s+=n.distanceTo(r),t.push(s),r=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let r=0;const s=n.length;let o;t?o=t:o=e*n[s-1];let c=0,d=s-1,h;for(;c<=d;)if(r=Math.floor(c+(d-c)/2),h=n[r]-o,h<0)c=r+1;else if(h>0)d=r-1;else{d=r;break}if(r=d,n[r]===o)return r/(s-1);const p=n[r],l=n[r+1]-p,u=(o-p)/l;return(r+u)/(s-1)}getTangent(e,t){let r=e-1e-4,s=e+1e-4;r<0&&(r=0),s>1&&(s=1);const o=this.getPoint(r),c=this.getPoint(s),d=t||(o.isVector2?new oe:new V);return d.copy(c).sub(o).normalize(),d}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new V,r=[],s=[],o=[],c=new V,d=new mt;for(let u=0;u<=e;u++){const E=u/e;r[u]=this.getTangentAt(E,new V)}s[0]=new V,o[0]=new V;let h=Number.MAX_VALUE;const p=Math.abs(r[0].x),a=Math.abs(r[0].y),l=Math.abs(r[0].z);p<=h&&(h=p,n.set(1,0,0)),a<=h&&(h=a,n.set(0,1,0)),l<=h&&n.set(0,0,1),c.crossVectors(r[0],n).normalize(),s[0].crossVectors(r[0],c),o[0].crossVectors(r[0],s[0]);for(let u=1;u<=e;u++){if(s[u]=s[u-1].clone(),o[u]=o[u-1].clone(),c.crossVectors(r[u-1],r[u]),c.length()>Number.EPSILON){c.normalize();const E=Math.acos(Je(r[u-1].dot(r[u]),-1,1));s[u].applyMatrix4(d.makeRotationAxis(c,E))}o[u].crossVectors(r[u],s[u])}if(t===!0){let u=Math.acos(Je(s[0].dot(s[e]),-1,1));u/=e,r[0].dot(c.crossVectors(s[0],s[e]))>0&&(u=-u);for(let E=1;E<=e;E++)s[E].applyMatrix4(d.makeRotationAxis(r[E],u*E)),o[E].crossVectors(r[E],s[E])}return{tangents:r,normals:s,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class $a extends An{constructor(e=0,t=0,n=1,r=1,s=0,o=Math.PI*2,c=!1,d=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=r,this.aStartAngle=s,this.aEndAngle=o,this.aClockwise=c,this.aRotation=d}getPoint(e,t=new oe){const n=t,r=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const o=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=r;for(;s>r;)s-=r;s<Number.EPSILON&&(o?s=0:s=r),this.aClockwise===!0&&!o&&(s===r?s=-r:s=s-r);const c=this.aStartAngle+e*s;let d=this.aX+this.xRadius*Math.cos(c),h=this.aY+this.yRadius*Math.sin(c);if(this.aRotation!==0){const p=Math.cos(this.aRotation),a=Math.sin(this.aRotation),l=d-this.aX,u=h-this.aY;d=l*p-u*a+this.aX,h=l*a+u*p+this.aY}return n.set(d,h)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class lh extends $a{constructor(e,t,n,r,s,o){super(e,t,n,n,r,s,o),this.isArcCurve=!0,this.type="ArcCurve"}}function eo(){let i=0,e=0,t=0,n=0;function r(s,o,c,d){i=s,e=c,t=-3*s+3*o-2*c-d,n=2*s-2*o+c+d}return{initCatmullRom:function(s,o,c,d,h){r(o,c,h*(c-s),h*(d-o))},initNonuniformCatmullRom:function(s,o,c,d,h,p,a){let l=(o-s)/h-(c-s)/(h+p)+(c-o)/p,u=(c-o)/p-(d-o)/(p+a)+(d-c)/a;l*=p,u*=p,r(o,c,l,u)},calc:function(s){const o=s*s,c=o*s;return i+e*s+t*o+n*c}}}const wr=new V,Us=new eo,ws=new eo,Fs=new eo;class ch extends An{constructor(e=[],t=!1,n="centripetal",r=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=r}getPoint(e,t=new V){const n=t,r=this.points,s=r.length,o=(s-(this.closed?0:1))*e;let c=Math.floor(o),d=o-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/s)+1)*s:d===0&&c===s-1&&(c=s-2,d=1);let h,p;this.closed||c>0?h=r[(c-1)%s]:(wr.subVectors(r[0],r[1]).add(r[0]),h=wr);const a=r[c%s],l=r[(c+1)%s];if(this.closed||c+2<s?p=r[(c+2)%s]:(wr.subVectors(r[s-1],r[s-2]).add(r[s-1]),p=wr),this.curveType==="centripetal"||this.curveType==="chordal"){const u=this.curveType==="chordal"?.5:.25;let E=Math.pow(h.distanceToSquared(a),u),m=Math.pow(a.distanceToSquared(l),u),S=Math.pow(l.distanceToSquared(p),u);m<1e-4&&(m=1),E<1e-4&&(E=m),S<1e-4&&(S=m),Us.initNonuniformCatmullRom(h.x,a.x,l.x,p.x,E,m,S),ws.initNonuniformCatmullRom(h.y,a.y,l.y,p.y,E,m,S),Fs.initNonuniformCatmullRom(h.z,a.z,l.z,p.z,E,m,S)}else this.curveType==="catmullrom"&&(Us.initCatmullRom(h.x,a.x,l.x,p.x,this.tension),ws.initCatmullRom(h.y,a.y,l.y,p.y,this.tension),Fs.initCatmullRom(h.z,a.z,l.z,p.z,this.tension));return n.set(Us.calc(d),ws.calc(d),Fs.calc(d)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(r.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const r=this.points[t];e.points.push(r.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(new V().fromArray(r))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function ko(i,e,t,n,r){const s=(n-e)*.5,o=(r-t)*.5,c=i*i,d=i*c;return(2*t-2*n+s+o)*d+(-3*t+3*n-2*s-o)*c+s*i+t}function uh(i,e){const t=1-i;return t*t*e}function hh(i,e){return 2*(1-i)*i*e}function dh(i,e){return i*i*e}function nr(i,e,t,n){return uh(i,e)+hh(i,t)+dh(i,n)}function fh(i,e){const t=1-i;return t*t*t*e}function ph(i,e){const t=1-i;return 3*t*t*i*e}function Eh(i,e){return 3*(1-i)*i*i*e}function Sh(i,e){return i*i*i*e}function ir(i,e,t,n,r){return fh(i,e)+ph(i,t)+Eh(i,n)+Sh(i,r)}class ic extends An{constructor(e=new oe,t=new oe,n=new oe,r=new oe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new oe){const n=t,r=this.v0,s=this.v1,o=this.v2,c=this.v3;return n.set(ir(e,r.x,s.x,o.x,c.x),ir(e,r.y,s.y,o.y,c.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class mh extends An{constructor(e=new V,t=new V,n=new V,r=new V){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=r}getPoint(e,t=new V){const n=t,r=this.v0,s=this.v1,o=this.v2,c=this.v3;return n.set(ir(e,r.x,s.x,o.x,c.x),ir(e,r.y,s.y,o.y,c.y),ir(e,r.z,s.z,o.z,c.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class rc extends An{constructor(e=new oe,t=new oe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new oe){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new oe){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Ah extends An{constructor(e=new V,t=new V){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new V){const n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new V){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class sc extends An{constructor(e=new oe,t=new oe,n=new oe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new oe){const n=t,r=this.v0,s=this.v1,o=this.v2;return n.set(nr(e,r.x,s.x,o.x),nr(e,r.y,s.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class xh extends An{constructor(e=new V,t=new V,n=new V){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new V){const n=t,r=this.v0,s=this.v1,o=this.v2;return n.set(nr(e,r.x,s.x,o.x),nr(e,r.y,s.y,o.y),nr(e,r.z,s.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class ac extends An{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new oe){const n=t,r=this.points,s=(r.length-1)*e,o=Math.floor(s),c=s-o,d=r[o===0?o:o-1],h=r[o],p=r[o>r.length-2?r.length-1:o+1],a=r[o>r.length-3?r.length-1:o+2];return n.set(ko(c,d.x,h.x,p.x,a.x),ko(c,d.y,h.y,p.y,a.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){const r=this.points[t];e.points.push(r.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){const r=e.points[t];this.points.push(new oe().fromArray(r))}return this}}var Ua=Object.freeze({__proto__:null,ArcCurve:lh,CatmullRomCurve3:ch,CubicBezierCurve:ic,CubicBezierCurve3:mh,EllipseCurve:$a,LineCurve:rc,LineCurve3:Ah,QuadraticBezierCurve:sc,QuadraticBezierCurve3:xh,SplineCurve:ac});class _h extends An{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Ua[n](t,e))}return this}getPoint(e,t){const n=e*this.getLength(),r=this.getCurveLengths();let s=0;for(;s<r.length;){if(r[s]>=n){const o=r[s]-n,c=this.curves[s],d=c.getLength(),h=d===0?0:1-o/d;return c.getPointAt(h,t)}s++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let n=0,r=this.curves.length;n<r;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let n;for(let r=0,s=this.curves;r<s.length;r++){const o=s[r],c=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,d=o.getPoints(c);for(let h=0;h<d.length;h++){const p=d[h];n&&n.equals(p)||(t.push(p),n=p)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const r=e.curves[t];this.curves.push(r.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){const r=this.curves[t];e.curves.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){const r=e.curves[t];this.curves.push(new Ua[r.type]().fromJSON(r))}return this}}class li extends _h{constructor(e){super(),this.type="Path",this.currentPoint=new oe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const n=new rc(this.currentPoint.clone(),new oe(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,r){const s=new sc(this.currentPoint.clone(),new oe(e,t),new oe(n,r));return this.curves.push(s),this.currentPoint.set(n,r),this}bezierCurveTo(e,t,n,r,s,o){const c=new ic(this.currentPoint.clone(),new oe(e,t),new oe(n,r),new oe(s,o));return this.curves.push(c),this.currentPoint.set(s,o),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),n=new ac(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,r,s,o){const c=this.currentPoint.x,d=this.currentPoint.y;return this.absarc(e+c,t+d,n,r,s,o),this}absarc(e,t,n,r,s,o){return this.absellipse(e,t,n,n,r,s,o),this}ellipse(e,t,n,r,s,o,c,d){const h=this.currentPoint.x,p=this.currentPoint.y;return this.absellipse(e+h,t+p,n,r,s,o,c,d),this}absellipse(e,t,n,r,s,o,c,d){const h=new $a(e,t,n,r,s,o,c,d);if(this.curves.length>0){const a=h.getPoint(0);a.equals(this.currentPoint)||this.lineTo(a.x,a.y)}this.curves.push(h);const p=h.getPoint(1);return this.currentPoint.copy(p),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class qn extends li{constructor(e){super(e),this.uuid=Gi(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let n=0,r=this.holes.length;n<r;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const r=e.holes[t];this.holes.push(r.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){const r=this.holes[t];e.holes.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){const r=e.holes[t];this.holes.push(new li().fromJSON(r))}return this}}function gh(i,e,t=2){const n=e&&e.length,r=n?e[0]*t:i.length;let s=oc(i,0,r,t,!0);const o=[];if(!s||s.next===s.prev)return o;let c,d,h;if(n&&(s=Ih(i,e,s,t)),i.length>80*t){c=i[0],d=i[1];let p=c,a=d;for(let l=t;l<r;l+=t){const u=i[l],E=i[l+1];u<c&&(c=u),E<d&&(d=E),u>p&&(p=u),E>a&&(a=E)}h=Math.max(p-c,a-d),h=h!==0?32767/h:0}return ur(s,o,t,c,d,h,0),o}function oc(i,e,t,n,r){let s;if(r===Fh(i,e,t,n)>0)for(let o=e;o<t;o+=n)s=Wo(o/n|0,i[o],i[o+1],s);else for(let o=t-n;o>=e;o-=n)s=Wo(o/n|0,i[o],i[o+1],s);return s&&Bi(s,s.next)&&(dr(s),s=s.next),s}function ui(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(Bi(t,t.next)||ft(t.prev,t,t.next)===0)){if(dr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function ur(i,e,t,n,r,s,o){if(!i)return;!o&&s&&Ch(i,n,r,s);let c=i;for(;i.prev!==i.next;){const d=i.prev,h=i.next;if(s?Rh(i,n,r,s):Th(i)){e.push(d.i,i.i,h.i),dr(i),i=h.next,c=h.next;continue}if(i=h,i===c){o?o===1?(i=vh(ui(i),e),ur(i,e,t,n,r,s,2)):o===2&&Mh(i,e,t,n,r,s):ur(ui(i),e,t,n,r,s,1);break}}}function Th(i){const e=i.prev,t=i,n=i.next;if(ft(e,t,n)>=0)return!1;const r=e.x,s=t.x,o=n.x,c=e.y,d=t.y,h=n.y,p=Math.min(r,s,o),a=Math.min(c,d,h),l=Math.max(r,s,o),u=Math.max(c,d,h);let E=n.next;for(;E!==e;){if(E.x>=p&&E.x<=l&&E.y>=a&&E.y<=u&&er(r,c,s,d,o,h,E.x,E.y)&&ft(E.prev,E,E.next)>=0)return!1;E=E.next}return!0}function Rh(i,e,t,n){const r=i.prev,s=i,o=i.next;if(ft(r,s,o)>=0)return!1;const c=r.x,d=s.x,h=o.x,p=r.y,a=s.y,l=o.y,u=Math.min(c,d,h),E=Math.min(p,a,l),m=Math.max(c,d,h),S=Math.max(p,a,l),f=wa(u,E,e,t,n),v=wa(m,S,e,t,n);let A=i.prevZ,R=i.nextZ;for(;A&&A.z>=f&&R&&R.z<=v;){if(A.x>=u&&A.x<=m&&A.y>=E&&A.y<=S&&A!==r&&A!==o&&er(c,p,d,a,h,l,A.x,A.y)&&ft(A.prev,A,A.next)>=0||(A=A.prevZ,R.x>=u&&R.x<=m&&R.y>=E&&R.y<=S&&R!==r&&R!==o&&er(c,p,d,a,h,l,R.x,R.y)&&ft(R.prev,R,R.next)>=0))return!1;R=R.nextZ}for(;A&&A.z>=f;){if(A.x>=u&&A.x<=m&&A.y>=E&&A.y<=S&&A!==r&&A!==o&&er(c,p,d,a,h,l,A.x,A.y)&&ft(A.prev,A,A.next)>=0)return!1;A=A.prevZ}for(;R&&R.z<=v;){if(R.x>=u&&R.x<=m&&R.y>=E&&R.y<=S&&R!==r&&R!==o&&er(c,p,d,a,h,l,R.x,R.y)&&ft(R.prev,R,R.next)>=0)return!1;R=R.nextZ}return!0}function vh(i,e){let t=i;do{const n=t.prev,r=t.next.next;!Bi(n,r)&&cc(n,t,t.next,r)&&hr(n,r)&&hr(r,n)&&(e.push(n.i,t.i,r.i),dr(t),dr(t.next),t=i=r),t=t.next}while(t!==i);return ui(t)}function Mh(i,e,t,n,r,s){let o=i;do{let c=o.next.next;for(;c!==o.prev;){if(o.i!==c.i&&Ph(o,c)){let d=uc(o,c);o=ui(o,o.next),d=ui(d,d.next),ur(o,e,t,n,r,s,0),ur(d,e,t,n,r,s,0);return}c=c.next}o=o.next}while(o!==i)}function Ih(i,e,t,n){const r=[];for(let s=0,o=e.length;s<o;s++){const c=e[s]*n,d=s<o-1?e[s+1]*n:i.length,h=oc(i,c,d,n,!1);h===h.next&&(h.steiner=!0),r.push(Dh(h))}r.sort(Lh);for(let s=0;s<r.length;s++)t=yh(r[s],t);return t}function Lh(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){const n=(i.next.y-i.y)/(i.next.x-i.x),r=(e.next.y-e.y)/(e.next.x-e.x);t=n-r}return t}function yh(i,e){const t=bh(i,e);if(!t)return e;const n=uc(t,i);return ui(n,n.next),ui(t,t.next)}function bh(i,e){let t=e;const n=i.x,r=i.y;let s=-1/0,o;if(Bi(i,t))return t;do{if(Bi(i,t.next))return t.next;if(r<=t.y&&r>=t.next.y&&t.next.y!==t.y){const a=t.x+(r-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(a<=n&&a>s&&(s=a,o=t.x<t.next.x?t:t.next,a===n))return o}t=t.next}while(t!==e);if(!o)return null;const c=o,d=o.x,h=o.y;let p=1/0;t=o;do{if(n>=t.x&&t.x>=d&&n!==t.x&&lc(r<h?n:s,r,d,h,r<h?s:n,r,t.x,t.y)){const a=Math.abs(r-t.y)/(n-t.x);hr(t,i)&&(a<p||a===p&&(t.x>o.x||t.x===o.x&&Oh(o,t)))&&(o=t,p=a)}t=t.next}while(t!==c);return o}function Oh(i,e){return ft(i.prev,i,e.prev)<0&&ft(e.next,i,i.next)<0}function Ch(i,e,t,n){let r=i;do r.z===0&&(r.z=wa(r.x,r.y,e,t,n)),r.prevZ=r.prev,r.nextZ=r.next,r=r.next;while(r!==i);r.prevZ.nextZ=null,r.prevZ=null,Nh(r)}function Nh(i){let e,t=1;do{let n=i,r;i=null;let s=null;for(e=0;n;){e++;let o=n,c=0;for(let h=0;h<t&&(c++,o=o.nextZ,!!o);h++);let d=t;for(;c>0||d>0&&o;)c!==0&&(d===0||!o||n.z<=o.z)?(r=n,n=n.nextZ,c--):(r=o,o=o.nextZ,d--),s?s.nextZ=r:i=r,r.prevZ=s,s=r;n=o}s.nextZ=null,t*=2}while(e>1);return i}function wa(i,e,t,n,r){return i=(i-t)*r|0,e=(e-n)*r|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Dh(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function lc(i,e,t,n,r,s,o,c){return(r-o)*(e-c)>=(i-o)*(s-c)&&(i-o)*(n-c)>=(t-o)*(e-c)&&(t-o)*(s-c)>=(r-o)*(n-c)}function er(i,e,t,n,r,s,o,c){return!(i===o&&e===c)&&lc(i,e,t,n,r,s,o,c)}function Ph(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Uh(i,e)&&(hr(i,e)&&hr(e,i)&&wh(i,e)&&(ft(i.prev,i,e.prev)||ft(i,e.prev,e))||Bi(i,e)&&ft(i.prev,i,i.next)>0&&ft(e.prev,e,e.next)>0)}function ft(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function Bi(i,e){return i.x===e.x&&i.y===e.y}function cc(i,e,t,n){const r=Br(ft(i,e,t)),s=Br(ft(i,e,n)),o=Br(ft(t,n,i)),c=Br(ft(t,n,e));return!!(r!==s&&o!==c||r===0&&Fr(i,t,e)||s===0&&Fr(i,n,e)||o===0&&Fr(t,i,n)||c===0&&Fr(t,e,n))}function Fr(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function Br(i){return i>0?1:i<0?-1:0}function Uh(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&cc(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function hr(i,e){return ft(i.prev,i,i.next)<0?ft(i,e,i.next)>=0&&ft(i,i.prev,e)>=0:ft(i,e,i.prev)<0||ft(i,i.next,e)<0}function wh(i,e){let t=i,n=!1;const r=(i.x+e.x)/2,s=(i.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&r<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function uc(i,e){const t=Fa(i.i,i.x,i.y),n=Fa(e.i,e.x,e.y),r=i.next,s=e.prev;return i.next=e,e.prev=i,t.next=r,r.prev=t,n.next=t,t.prev=n,s.next=n,n.prev=s,n}function Wo(i,e,t,n){const r=Fa(i,e,t);return n?(r.next=n.next,r.prev=n,n.next.prev=r,n.next=r):(r.prev=r,r.next=r),r}function dr(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function Fa(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Fh(i,e,t,n){let r=0;for(let s=e,o=t-n;s<t;s+=n)r+=(i[o]-i[s])*(i[s+1]+i[o+1]),o=s;return r}class Bh{static triangulate(e,t,n=2){return gh(e,t,n)}}class hn{static area(e){const t=e.length;let n=0;for(let r=t-1,s=0;s<t;r=s++)n+=e[r].x*e[s].y-e[s].x*e[r].y;return n*.5}static isClockWise(e){return hn.area(e)<0}static triangulateShape(e,t){const n=[],r=[],s=[];Yo(e),zo(n,e);let o=e.length;t.forEach(Yo);for(let d=0;d<t.length;d++)r.push(o),o+=t[d].length,zo(n,t[d]);const c=Bh.triangulate(n,r);for(let d=0;d<c.length;d+=3)s.push(c.slice(d,d+3));return s}}function Yo(i){const e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function zo(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}class to extends gt{constructor(e=new qn([new oe(.5,.5),new oe(-.5,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const n=this,r=[],s=[];for(let c=0,d=e.length;c<d;c++){const h=e[c];o(h)}this.setAttribute("position",new xt(r,3)),this.setAttribute("uv",new xt(s,2)),this.computeVertexNormals();function o(c){const d=[],h=t.curveSegments!==void 0?t.curveSegments:12,p=t.steps!==void 0?t.steps:1,a=t.depth!==void 0?t.depth:1;let l=t.bevelEnabled!==void 0?t.bevelEnabled:!0,u=t.bevelThickness!==void 0?t.bevelThickness:.2,E=t.bevelSize!==void 0?t.bevelSize:u-.1,m=t.bevelOffset!==void 0?t.bevelOffset:0,S=t.bevelSegments!==void 0?t.bevelSegments:3;const f=t.extrudePath,v=t.UVGenerator!==void 0?t.UVGenerator:Hh;let A,R=!1,C,y,N,w;f&&(A=f.getSpacedPoints(p),R=!0,l=!1,C=f.computeFrenetFrames(p,!1),y=new V,N=new V,w=new V),l||(S=0,u=0,E=0,m=0);const I=c.extractPoints(h);let _=I.shape;const P=I.holes;if(!hn.isClockWise(_)){_=_.reverse();for(let H=0,T=P.length;H<T;H++){const q=P[H];hn.isClockWise(q)&&(P[H]=q.reverse())}}function Z(H){const q=10000000000000001e-36;let J=H[0];for(let D=1;D<=H.length;D++){const b=D%H.length,ae=H[b],ce=ae.x-J.x,Te=ae.y-J.y,O=ce*ce+Te*Te,x=Math.max(Math.abs(ae.x),Math.abs(ae.y),Math.abs(J.x),Math.abs(J.y)),W=q*x*x;if(O<=W){H.splice(b,1),D--;continue}J=ae}}Z(_),P.forEach(Z);const j=P.length,$=_;for(let H=0;H<j;H++){const T=P[H];_=_.concat(T)}function ie(H,T,q){return T||dt("ExtrudeGeometry: vec does not exist"),H.clone().addScaledVector(T,q)}const Q=_.length;function B(H,T,q){let J,D,b;const ae=H.x-T.x,ce=H.y-T.y,Te=q.x-H.x,O=q.y-H.y,x=ae*ae+ce*ce,W=ae*O-ce*Te;if(Math.abs(W)>Number.EPSILON){const re=Math.sqrt(x),fe=Math.sqrt(Te*Te+O*O),ne=T.x-ce/re,Ne=T.y+ae/re,ge=q.x-O/fe,we=q.y+Te/fe,Ce=((ge-ne)*O-(we-Ne)*Te)/(ae*O-ce*Te);J=ne+ae*Ce-H.x,D=Ne+ce*Ce-H.y;const Ee=J*J+D*D;if(Ee<=2)return new oe(J,D);b=Math.sqrt(Ee/2)}else{let re=!1;ae>Number.EPSILON?Te>Number.EPSILON&&(re=!0):ae<-Number.EPSILON?Te<-Number.EPSILON&&(re=!0):Math.sign(ce)===Math.sign(O)&&(re=!0),re?(J=-ce,D=ae,b=Math.sqrt(x)):(J=ae,D=ce,b=Math.sqrt(x/2))}return new oe(J/b,D/b)}const pe=[];for(let H=0,T=$.length,q=T-1,J=H+1;H<T;H++,q++,J++)q===T&&(q=0),J===T&&(J=0),pe[H]=B($[H],$[q],$[J]);const le=[];let _e,Ue=pe.concat();for(let H=0,T=j;H<T;H++){const q=P[H];_e=[];for(let J=0,D=q.length,b=D-1,ae=J+1;J<D;J++,b++,ae++)b===D&&(b=0),ae===D&&(ae=0),_e[J]=B(q[J],q[b],q[ae]);le.push(_e),Ue=Ue.concat(_e)}let He;if(S===0)He=hn.triangulateShape($,P);else{const H=[],T=[];for(let q=0;q<S;q++){const J=q/S,D=u*Math.cos(J*Math.PI/2),b=E*Math.sin(J*Math.PI/2)+m;for(let ae=0,ce=$.length;ae<ce;ae++){const Te=ie($[ae],pe[ae],b);se(Te.x,Te.y,-D),J===0&&H.push(Te)}for(let ae=0,ce=j;ae<ce;ae++){const Te=P[ae];_e=le[ae];const O=[];for(let x=0,W=Te.length;x<W;x++){const re=ie(Te[x],_e[x],b);se(re.x,re.y,-D),J===0&&O.push(re)}J===0&&T.push(O)}}He=hn.triangulateShape(H,T)}const X=He.length,U=E+m;for(let H=0;H<Q;H++){const T=l?ie(_[H],Ue[H],U):_[H];R?(N.copy(C.normals[0]).multiplyScalar(T.x),y.copy(C.binormals[0]).multiplyScalar(T.y),w.copy(A[0]).add(N).add(y),se(w.x,w.y,w.z)):se(T.x,T.y,0)}for(let H=1;H<=p;H++)for(let T=0;T<Q;T++){const q=l?ie(_[T],Ue[T],U):_[T];R?(N.copy(C.normals[H]).multiplyScalar(q.x),y.copy(C.binormals[H]).multiplyScalar(q.y),w.copy(A[H]).add(N).add(y),se(w.x,w.y,w.z)):se(q.x,q.y,a/p*H)}for(let H=S-1;H>=0;H--){const T=H/S,q=u*Math.cos(T*Math.PI/2),J=E*Math.sin(T*Math.PI/2)+m;for(let D=0,b=$.length;D<b;D++){const ae=ie($[D],pe[D],J);se(ae.x,ae.y,a+q)}for(let D=0,b=P.length;D<b;D++){const ae=P[D];_e=le[D];for(let ce=0,Te=ae.length;ce<Te;ce++){const O=ie(ae[ce],_e[ce],J);R?se(O.x,O.y+A[p-1].y,A[p-1].x+q):se(O.x,O.y,a+q)}}}M(),g();function M(){const H=r.length/3;if(l){let T=0,q=Q*T;for(let J=0;J<X;J++){const D=He[J];k(D[2]+q,D[1]+q,D[0]+q)}T=p+S*2,q=Q*T;for(let J=0;J<X;J++){const D=He[J];k(D[0]+q,D[1]+q,D[2]+q)}}else{for(let T=0;T<X;T++){const q=He[T];k(q[2],q[1],q[0])}for(let T=0;T<X;T++){const q=He[T];k(q[0]+Q*p,q[1]+Q*p,q[2]+Q*p)}}n.addGroup(H,r.length/3-H,0)}function g(){const H=r.length/3;let T=0;z($,T),T+=$.length;for(let q=0,J=P.length;q<J;q++){const D=P[q];z(D,T),T+=D.length}n.addGroup(H,r.length/3-H,1)}function z(H,T){let q=H.length;for(;--q>=0;){const J=q;let D=q-1;D<0&&(D=H.length-1);for(let b=0,ae=p+S*2;b<ae;b++){const ce=Q*b,Te=Q*(b+1),O=T+J+ce,x=T+D+ce,W=T+D+Te,re=T+J+Te;ue(O,x,W,re)}}}function se(H,T,q){d.push(H),d.push(T),d.push(q)}function k(H,T,q){me(H),me(T),me(q);const J=r.length/3,D=v.generateTopUV(n,r,J-3,J-2,J-1);he(D[0]),he(D[1]),he(D[2])}function ue(H,T,q,J){me(H),me(T),me(J),me(T),me(q),me(J);const D=r.length/3,b=v.generateSideWallUV(n,r,D-6,D-3,D-2,D-1);he(b[0]),he(b[1]),he(b[3]),he(b[1]),he(b[2]),he(b[3])}function me(H){r.push(d[H*3+0]),r.push(d[H*3+1]),r.push(d[H*3+2])}function he(H){s.push(H.x),s.push(H.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return Gh(t,n,e)}static fromJSON(e,t){const n=[];for(let s=0,o=e.shapes.length;s<o;s++){const c=t[e.shapes[s]];n.push(c)}const r=e.options.extrudePath;return r!==void 0&&(e.options.extrudePath=new Ua[r.type]().fromJSON(r)),new to(n,e.options)}}const Hh={generateTopUV:function(i,e,t,n,r){const s=e[t*3],o=e[t*3+1],c=e[n*3],d=e[n*3+1],h=e[r*3],p=e[r*3+1];return[new oe(s,o),new oe(c,d),new oe(h,p)]},generateSideWallUV:function(i,e,t,n,r,s){const o=e[t*3],c=e[t*3+1],d=e[t*3+2],h=e[n*3],p=e[n*3+1],a=e[n*3+2],l=e[r*3],u=e[r*3+1],E=e[r*3+2],m=e[s*3],S=e[s*3+1],f=e[s*3+2];return Math.abs(c-p)<Math.abs(o-h)?[new oe(o,1-d),new oe(h,1-a),new oe(l,1-E),new oe(m,1-f)]:[new oe(c,1-d),new oe(p,1-a),new oe(u,1-E),new oe(S,1-f)]}};function Gh(i,e,t){if(t.shapes=[],Array.isArray(i))for(let n=0,r=i.length;n<r;n++){const s=i[n];t.shapes.push(s.uuid)}else t.shapes.push(i.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class as extends gt{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,o=t/2,c=Math.floor(n),d=Math.floor(r),h=c+1,p=d+1,a=e/c,l=t/d,u=[],E=[],m=[],S=[];for(let f=0;f<p;f++){const v=f*l-o;for(let A=0;A<h;A++){const R=A*a-s;E.push(R,-v,0),m.push(0,0,1),S.push(A/c),S.push(1-f/d)}}for(let f=0;f<d;f++)for(let v=0;v<c;v++){const A=v+h*f,R=v+h*(f+1),C=v+1+h*(f+1),y=v+1+h*f;u.push(A,R,y),u.push(R,C,y)}this.setIndex(u),this.setAttribute("position",new xt(E,3)),this.setAttribute("normal",new xt(m,3)),this.setAttribute("uv",new xt(S,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new as(e.width,e.height,e.widthSegments,e.heightSegments)}}class no extends gt{constructor(e=new qn([new oe(0,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const n=[],r=[],s=[],o=[];let c=0,d=0;if(Array.isArray(e)===!1)h(e);else for(let p=0;p<e.length;p++)h(e[p]),this.addGroup(c,d,p),c+=d,d=0;this.setIndex(n),this.setAttribute("position",new xt(r,3)),this.setAttribute("normal",new xt(s,3)),this.setAttribute("uv",new xt(o,2));function h(p){const a=r.length/3,l=p.extractPoints(t);let u=l.shape;const E=l.holes;hn.isClockWise(u)===!1&&(u=u.reverse());for(let S=0,f=E.length;S<f;S++){const v=E[S];hn.isClockWise(v)===!0&&(E[S]=v.reverse())}const m=hn.triangulateShape(u,E);for(let S=0,f=E.length;S<f;S++){const v=E[S];u=u.concat(v)}for(let S=0,f=u.length;S<f;S++){const v=u[S];r.push(v.x,v.y,0),s.push(0,0,1),o.push(v.x,v.y)}for(let S=0,f=m.length;S<f;S++){const v=m[S],A=v[0]+a,R=v[1]+a,C=v[2]+a;n.push(A,R,C),d+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Vh(t,e)}static fromJSON(e,t){const n=[];for(let r=0,s=e.shapes.length;r<s;r++){const o=t[e.shapes[r]];n.push(o)}return new no(n,e.curveSegments)}}function Vh(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){const r=i[t];e.shapes.push(r.uuid)}else e.shapes.push(i.uuid);return e}class kh extends ss{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=xu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Wh extends ss{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Ko={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class Yh{constructor(e,t,n){const r=this;let s=!1,o=0,c=0,d;const h=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this._abortController=null,this.itemStart=function(p){c++,s===!1&&r.onStart!==void 0&&r.onStart(p,o,c),s=!0},this.itemEnd=function(p){o++,r.onProgress!==void 0&&r.onProgress(p,o,c),o===c&&(s=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(p){r.onError!==void 0&&r.onError(p)},this.resolveURL=function(p){return d?d(p):p},this.setURLModifier=function(p){return d=p,this},this.addHandler=function(p,a){return h.push(p,a),this},this.removeHandler=function(p){const a=h.indexOf(p);return a!==-1&&h.splice(a,2),this},this.getHandler=function(p){for(let a=0,l=h.length;a<l;a+=2){const u=h[a],E=h[a+1];if(u.global&&(u.lastIndex=0),u.test(p))return E}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const zh=new Yh;class io{constructor(e){this.manager=e!==void 0?e:zh,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(r,s){n.load(e,r,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}io.DEFAULT_MATERIAL_NAME="__DEFAULT";const vn={};class Kh extends Error{constructor(e,t){super(e),this.response=t}}class Xh extends io{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=Ko.get(`file:${e}`);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(vn[e]!==void 0){vn[e].push({onLoad:t,onProgress:n,onError:r});return}vn[e]=[],vn[e].push({onLoad:t,onProgress:n,onError:r});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),c=this.mimeType,d=this.responseType;fetch(o).then(h=>{if(h.status===200||h.status===0){if(h.status===0&&Ke("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||h.body===void 0||h.body.getReader===void 0)return h;const p=vn[e],a=h.body.getReader(),l=h.headers.get("X-File-Size")||h.headers.get("Content-Length"),u=l?parseInt(l):0,E=u!==0;let m=0;const S=new ReadableStream({start(f){v();function v(){a.read().then(({done:A,value:R})=>{if(A)f.close();else{m+=R.byteLength;const C=new ProgressEvent("progress",{lengthComputable:E,loaded:m,total:u});for(let y=0,N=p.length;y<N;y++){const w=p[y];w.onProgress&&w.onProgress(C)}f.enqueue(R),v()}},A=>{f.error(A)})}}});return new Response(S)}else throw new Kh(`fetch for "${h.url}" responded with ${h.status}: ${h.statusText}`,h)}).then(h=>{switch(d){case"arraybuffer":return h.arrayBuffer();case"blob":return h.blob();case"document":return h.text().then(p=>new DOMParser().parseFromString(p,c));case"json":return h.json();default:if(c==="")return h.text();{const a=/charset="?([^;"\s]*)"?/i.exec(c),l=a&&a[1]?a[1].toLowerCase():void 0,u=new TextDecoder(l);return h.arrayBuffer().then(E=>u.decode(E))}}}).then(h=>{Ko.add(`file:${e}`,h);const p=vn[e];delete vn[e];for(let a=0,l=p.length;a<l;a++){const u=p[a];u.onLoad&&u.onLoad(h)}}).catch(h=>{const p=vn[e];if(p===void 0)throw this.manager.itemError(e),h;delete vn[e];for(let a=0,l=p.length;a<l;a++){const u=p[a];u.onError&&u.onError(h)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class qh extends Ql{constructor(e=-1,t=1,n=1,r=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,o=n+e,c=r+t,d=r-t;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,p=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=h*this.view.offsetX,o=s+h*this.view.width,c-=p*this.view.offsetY,d=c-p*this.view.height}this.projectionMatrix.makeOrthographic(s,o,c,d,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Zh extends jt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const Xo=new mt;class hc{constructor(e,t,n=0,r=1/0){this.ray=new ja(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new Qa,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):dt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return Xo.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Xo),this}intersectObject(e,t=!0,n=[]){return Ba(e,this,n,t),n.sort(qo),n}intersectObjects(e,t=!0,n=[]){for(let r=0,s=e.length;r<s;r++)Ba(e[r],this,n,t);return n.sort(qo),n}}function qo(i,e){return i.distance-e.distance}function Ba(i,e,t,n){let r=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(r=!1),r===!0&&n===!0){const s=i.children;for(let o=0,c=s.length;o<c;o++)Ba(s[o],e,t,!0)}}class Zo{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Je(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(Je(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const Jo=new oe;class Jh{constructor(e=new oe(1/0,1/0),t=new oe(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Jo.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Jo).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}class ni{constructor(){this.type="ShapePath",this.color=new tt,this.subPaths=[],this.currentPath=null}moveTo(e,t){return this.currentPath=new li,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,n,r){return this.currentPath.quadraticCurveTo(e,t,n,r),this}bezierCurveTo(e,t,n,r,s,o){return this.currentPath.bezierCurveTo(e,t,n,r,s,o),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(e){function t(f){const v=[];for(let A=0,R=f.length;A<R;A++){const C=f[A],y=new qn;y.curves=C.curves,v.push(y)}return v}function n(f,v){const A=v.length;let R=!1;for(let C=A-1,y=0;y<A;C=y++){let N=v[C],w=v[y],I=w.x-N.x,_=w.y-N.y;if(Math.abs(_)>Number.EPSILON){if(_<0&&(N=v[y],I=-I,w=v[C],_=-_),f.y<N.y||f.y>w.y)continue;if(f.y===N.y){if(f.x===N.x)return!0}else{const P=_*(f.x-N.x)-I*(f.y-N.y);if(P===0)return!0;if(P<0)continue;R=!R}}else{if(f.y!==N.y)continue;if(w.x<=f.x&&f.x<=N.x||N.x<=f.x&&f.x<=w.x)return!0}}return R}const r=hn.isClockWise,s=this.subPaths;if(s.length===0)return[];let o,c,d;const h=[];if(s.length===1)return c=s[0],d=new qn,d.curves=c.curves,h.push(d),h;let p=!r(s[0].getPoints());p=e?!p:p;const a=[],l=[];let u=[],E=0,m;l[E]=void 0,u[E]=[];for(let f=0,v=s.length;f<v;f++)c=s[f],m=c.getPoints(),o=r(m),o=e?!o:o,o?(!p&&l[E]&&E++,l[E]={s:new qn,p:m},l[E].s.curves=c.curves,p&&E++,u[E]=[]):u[E].push({h:c,p:m[0]});if(!l[0])return t(s);if(l.length>1){let f=!1,v=0;for(let A=0,R=l.length;A<R;A++)a[A]=[];for(let A=0,R=l.length;A<R;A++){const C=u[A];for(let y=0;y<C.length;y++){const N=C[y];let w=!0;for(let I=0;I<l.length;I++)n(N.p,l[I].p)&&(A!==I&&v++,w?(w=!1,a[I].push(N)):f=!0);w&&a[A].push(N)}}v>0&&f===!1&&(u=a)}let S;for(let f=0,v=l.length;f<v;f++){d=l[f].s,h.push(d),S=u[f];for(let A=0,R=S.length;A<R;A++)d.holes.push(S[A].h)}return h}}class jh extends hi{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){Ke("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function jo(i,e,t,n){const r=Qh(n);switch(t){case kl:return i*e;case Yl:return i*e/r.components*r.byteLength;case za:return i*e/r.components*r.byteLength;case Ka:return i*e*2/r.components*r.byteLength;case Xa:return i*e*2/r.components*r.byteLength;case Wl:return i*e*3/r.components*r.byteLength;case un:return i*e*4/r.components*r.byteLength;case qa:return i*e*4/r.components*r.byteLength;case Yr:case zr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Kr:case Xr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case oa:case ca:return Math.max(i,16)*Math.max(e,8)/4;case aa:case la:return Math.max(i,8)*Math.max(e,8)/2;case ua:case ha:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case da:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case fa:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case pa:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Ea:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Sa:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case ma:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Aa:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case xa:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case _a:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case ga:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Ta:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Ra:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case va:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Ma:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Ia:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case La:case ya:case ba:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Oa:case Ca:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Na:case Da:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Qh(i){switch(i){case Cn:case Bl:return{byteLength:1,components:1};case sr:case Hl:case Hi:return{byteLength:2,components:1};case Wa:case Ya:return{byteLength:2,components:4};case ci:case ka:case yn:return{byteLength:4,components:1};case Gl:case Vl:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Va}}));typeof window<"u"&&(window.__THREE__?Ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Va);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function dc(){let i=null,e=!1,t=null,n=null;function r(s,o){t(s,o),n=i.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function $h(i){const e=new WeakMap;function t(c,d){const h=c.array,p=c.usage,a=h.byteLength,l=i.createBuffer();i.bindBuffer(d,l),i.bufferData(d,h,p),c.onUploadCallback();let u;if(h instanceof Float32Array)u=i.FLOAT;else if(typeof Float16Array<"u"&&h instanceof Float16Array)u=i.HALF_FLOAT;else if(h instanceof Uint16Array)c.isFloat16BufferAttribute?u=i.HALF_FLOAT:u=i.UNSIGNED_SHORT;else if(h instanceof Int16Array)u=i.SHORT;else if(h instanceof Uint32Array)u=i.UNSIGNED_INT;else if(h instanceof Int32Array)u=i.INT;else if(h instanceof Int8Array)u=i.BYTE;else if(h instanceof Uint8Array)u=i.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)u=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:l,type:u,bytesPerElement:h.BYTES_PER_ELEMENT,version:c.version,size:a}}function n(c,d,h){const p=d.array,a=d.updateRanges;if(i.bindBuffer(h,c),a.length===0)i.bufferSubData(h,0,p);else{a.sort((u,E)=>u.start-E.start);let l=0;for(let u=1;u<a.length;u++){const E=a[l],m=a[u];m.start<=E.start+E.count+1?E.count=Math.max(E.count,m.start+m.count-E.start):(++l,a[l]=m)}a.length=l+1;for(let u=0,E=a.length;u<E;u++){const m=a[u];i.bufferSubData(h,m.start*p.BYTES_PER_ELEMENT,p,m.start,m.count)}d.clearUpdateRanges()}d.onUploadCallback()}function r(c){return c.isInterleavedBufferAttribute&&(c=c.data),e.get(c)}function s(c){c.isInterleavedBufferAttribute&&(c=c.data);const d=e.get(c);d&&(i.deleteBuffer(d.buffer),e.delete(c))}function o(c,d){if(c.isInterleavedBufferAttribute&&(c=c.data),c.isGLBufferAttribute){const p=e.get(c);(!p||p.version<c.version)&&e.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}const h=e.get(c);if(h===void 0)e.set(c,t(c,d));else if(h.version<c.version){if(h.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(h.buffer,c,d),h.version=c.version}}return{get:r,remove:s,update:o}}var ed=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,td=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,nd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,id=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,rd=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,sd=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,ad=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,od=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,ld=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,cd=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,ud=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,hd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,dd=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,fd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,pd=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ed=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Sd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,md=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Ad=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,xd=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,_d=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,gd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Td=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Rd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,vd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Md=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Id=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ld=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,yd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,bd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Od="gl_FragColor = linearToOutputTexel( gl_FragColor );",Cd=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Nd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Dd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Pd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Ud=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Fd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Bd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Hd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Gd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Vd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,kd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Wd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Yd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,zd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Kd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Xd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,qd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Zd=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Jd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,jd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Qd=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,$d=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,ef=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,tf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,nf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,rf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,sf=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,af=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,of=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,lf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,cf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,uf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,hf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,df=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,ff=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,pf=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Ef=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Sf=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,mf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Af=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,xf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,_f=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,gf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Tf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Rf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,vf=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Mf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,If=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Lf=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,yf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,bf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Of=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Cf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Nf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Df=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Pf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Uf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,wf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Ff=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Bf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Hf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Gf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Vf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,kf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Wf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Yf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,zf=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Kf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Xf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,qf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Zf=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Jf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Qf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,$f=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const ep=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,tp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,np=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ip=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,sp=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ap=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,op=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,lp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,cp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,up=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,hp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dp=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,pp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Ep=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,mp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ap=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,xp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_p=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,gp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Tp=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rp=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vp=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Mp=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ip=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lp=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,yp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,bp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Op=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Cp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Np=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Dp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ze={alphahash_fragment:ed,alphahash_pars_fragment:td,alphamap_fragment:nd,alphamap_pars_fragment:id,alphatest_fragment:rd,alphatest_pars_fragment:sd,aomap_fragment:ad,aomap_pars_fragment:od,batching_pars_vertex:ld,batching_vertex:cd,begin_vertex:ud,beginnormal_vertex:hd,bsdfs:dd,iridescence_fragment:fd,bumpmap_pars_fragment:pd,clipping_planes_fragment:Ed,clipping_planes_pars_fragment:Sd,clipping_planes_pars_vertex:md,clipping_planes_vertex:Ad,color_fragment:xd,color_pars_fragment:_d,color_pars_vertex:gd,color_vertex:Td,common:Rd,cube_uv_reflection_fragment:vd,defaultnormal_vertex:Md,displacementmap_pars_vertex:Id,displacementmap_vertex:Ld,emissivemap_fragment:yd,emissivemap_pars_fragment:bd,colorspace_fragment:Od,colorspace_pars_fragment:Cd,envmap_fragment:Nd,envmap_common_pars_fragment:Dd,envmap_pars_fragment:Pd,envmap_pars_vertex:Ud,envmap_physical_pars_fragment:Kd,envmap_vertex:wd,fog_vertex:Fd,fog_pars_vertex:Bd,fog_fragment:Hd,fog_pars_fragment:Gd,gradientmap_pars_fragment:Vd,lightmap_pars_fragment:kd,lights_lambert_fragment:Wd,lights_lambert_pars_fragment:Yd,lights_pars_begin:zd,lights_toon_fragment:Xd,lights_toon_pars_fragment:qd,lights_phong_fragment:Zd,lights_phong_pars_fragment:Jd,lights_physical_fragment:jd,lights_physical_pars_fragment:Qd,lights_fragment_begin:$d,lights_fragment_maps:ef,lights_fragment_end:tf,logdepthbuf_fragment:nf,logdepthbuf_pars_fragment:rf,logdepthbuf_pars_vertex:sf,logdepthbuf_vertex:af,map_fragment:of,map_pars_fragment:lf,map_particle_fragment:cf,map_particle_pars_fragment:uf,metalnessmap_fragment:hf,metalnessmap_pars_fragment:df,morphinstance_vertex:ff,morphcolor_vertex:pf,morphnormal_vertex:Ef,morphtarget_pars_vertex:Sf,morphtarget_vertex:mf,normal_fragment_begin:Af,normal_fragment_maps:xf,normal_pars_fragment:_f,normal_pars_vertex:gf,normal_vertex:Tf,normalmap_pars_fragment:Rf,clearcoat_normal_fragment_begin:vf,clearcoat_normal_fragment_maps:Mf,clearcoat_pars_fragment:If,iridescence_pars_fragment:Lf,opaque_fragment:yf,packing:bf,premultiplied_alpha_fragment:Of,project_vertex:Cf,dithering_fragment:Nf,dithering_pars_fragment:Df,roughnessmap_fragment:Pf,roughnessmap_pars_fragment:Uf,shadowmap_pars_fragment:wf,shadowmap_pars_vertex:Ff,shadowmap_vertex:Bf,shadowmask_pars_fragment:Hf,skinbase_vertex:Gf,skinning_pars_vertex:Vf,skinning_vertex:kf,skinnormal_vertex:Wf,specularmap_fragment:Yf,specularmap_pars_fragment:zf,tonemapping_fragment:Kf,tonemapping_pars_fragment:Xf,transmission_fragment:qf,transmission_pars_fragment:Zf,uv_pars_fragment:Jf,uv_pars_vertex:jf,uv_vertex:Qf,worldpos_vertex:$f,background_vert:ep,background_frag:tp,backgroundCube_vert:np,backgroundCube_frag:ip,cube_vert:rp,cube_frag:sp,depth_vert:ap,depth_frag:op,distanceRGBA_vert:lp,distanceRGBA_frag:cp,equirect_vert:up,equirect_frag:hp,linedashed_vert:dp,linedashed_frag:fp,meshbasic_vert:pp,meshbasic_frag:Ep,meshlambert_vert:Sp,meshlambert_frag:mp,meshmatcap_vert:Ap,meshmatcap_frag:xp,meshnormal_vert:_p,meshnormal_frag:gp,meshphong_vert:Tp,meshphong_frag:Rp,meshphysical_vert:vp,meshphysical_frag:Mp,meshtoon_vert:Ip,meshtoon_frag:Lp,points_vert:yp,points_frag:bp,shadow_vert:Op,shadow_frag:Cp,sprite_vert:Np,sprite_frag:Dp},Me={common:{diffuse:{value:new tt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ye}},envmap:{envMap:{value:null},envMapRotation:{value:new Ye},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ye}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ye}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ye},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ye},normalScale:{value:new oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ye},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ye}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ye}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ye}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new tt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new tt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0},uvTransform:{value:new Ye}},sprite:{diffuse:{value:new tt(16777215)},opacity:{value:1},center:{value:new oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}}},Sn={basic:{uniforms:Ot([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.fog]),vertexShader:Ze.meshbasic_vert,fragmentShader:Ze.meshbasic_frag},lambert:{uniforms:Ot([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,Me.lights,{emissive:{value:new tt(0)}}]),vertexShader:Ze.meshlambert_vert,fragmentShader:Ze.meshlambert_frag},phong:{uniforms:Ot([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,Me.lights,{emissive:{value:new tt(0)},specular:{value:new tt(1118481)},shininess:{value:30}}]),vertexShader:Ze.meshphong_vert,fragmentShader:Ze.meshphong_frag},standard:{uniforms:Ot([Me.common,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.roughnessmap,Me.metalnessmap,Me.fog,Me.lights,{emissive:{value:new tt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag},toon:{uniforms:Ot([Me.common,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.gradientmap,Me.fog,Me.lights,{emissive:{value:new tt(0)}}]),vertexShader:Ze.meshtoon_vert,fragmentShader:Ze.meshtoon_frag},matcap:{uniforms:Ot([Me.common,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,{matcap:{value:null}}]),vertexShader:Ze.meshmatcap_vert,fragmentShader:Ze.meshmatcap_frag},points:{uniforms:Ot([Me.points,Me.fog]),vertexShader:Ze.points_vert,fragmentShader:Ze.points_frag},dashed:{uniforms:Ot([Me.common,Me.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ze.linedashed_vert,fragmentShader:Ze.linedashed_frag},depth:{uniforms:Ot([Me.common,Me.displacementmap]),vertexShader:Ze.depth_vert,fragmentShader:Ze.depth_frag},normal:{uniforms:Ot([Me.common,Me.bumpmap,Me.normalmap,Me.displacementmap,{opacity:{value:1}}]),vertexShader:Ze.meshnormal_vert,fragmentShader:Ze.meshnormal_frag},sprite:{uniforms:Ot([Me.sprite,Me.fog]),vertexShader:Ze.sprite_vert,fragmentShader:Ze.sprite_frag},background:{uniforms:{uvTransform:{value:new Ye},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ze.background_vert,fragmentShader:Ze.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ye}},vertexShader:Ze.backgroundCube_vert,fragmentShader:Ze.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ze.cube_vert,fragmentShader:Ze.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ze.equirect_vert,fragmentShader:Ze.equirect_frag},distanceRGBA:{uniforms:Ot([Me.common,Me.displacementmap,{referencePosition:{value:new V},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ze.distanceRGBA_vert,fragmentShader:Ze.distanceRGBA_frag},shadow:{uniforms:Ot([Me.lights,Me.fog,{color:{value:new tt(0)},opacity:{value:1}}]),vertexShader:Ze.shadow_vert,fragmentShader:Ze.shadow_frag}};Sn.physical={uniforms:Ot([Sn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ye},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ye},clearcoatNormalScale:{value:new oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ye},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ye},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ye},sheen:{value:0},sheenColor:{value:new tt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ye},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ye},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ye},transmissionSamplerSize:{value:new oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ye},attenuationDistance:{value:0},attenuationColor:{value:new tt(0)},specularColor:{value:new tt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ye},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ye},anisotropyVector:{value:new oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ye}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag};const Hr={r:0,b:0,g:0},ii=new Dn,Pp=new mt;function Up(i,e,t,n,r,s,o){const c=new tt(0);let d=s===!0?0:1,h,p,a=null,l=0,u=null;function E(A){let R=A.isScene===!0?A.background:null;return R&&R.isTexture&&(R=(A.backgroundBlurriness>0?t:e).get(R)),R}function m(A){let R=!1;const C=E(A);C===null?f(c,d):C&&C.isColor&&(f(C,1),R=!0);const y=i.xr.getEnvironmentBlendMode();y==="additive"?n.buffers.color.setClear(0,0,0,1,o):y==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||R)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function S(A,R){const C=E(R);C&&(C.isCubeTexture||C.mapping===rs)?(p===void 0&&(p=new Mt(new di(1,1,1),new en({name:"BackgroundCubeMaterial",uniforms:Fi(Sn.backgroundCube.uniforms),vertexShader:Sn.backgroundCube.vertexShader,fragmentShader:Sn.backgroundCube.fragmentShader,side:It,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(y,N,w){this.matrixWorld.copyPosition(w.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(p)),ii.copy(R.backgroundRotation),ii.x*=-1,ii.y*=-1,ii.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(ii.y*=-1,ii.z*=-1),p.material.uniforms.envMap.value=C,p.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,p.material.uniforms.backgroundBlurriness.value=R.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=R.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(Pp.makeRotationFromEuler(ii)),p.material.toneMapped=$e.getTransfer(C.colorSpace)!==rt,(a!==C||l!==C.version||u!==i.toneMapping)&&(p.material.needsUpdate=!0,a=C,l=C.version,u=i.toneMapping),p.layers.enableAll(),A.unshift(p,p.geometry,p.material,0,0,null)):C&&C.isTexture&&(h===void 0&&(h=new Mt(new as(2,2),new en({name:"BackgroundMaterial",uniforms:Fi(Sn.background.uniforms),vertexShader:Sn.background.vertexShader,fragmentShader:Sn.background.fragmentShader,side:Kt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),Object.defineProperty(h.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(h)),h.material.uniforms.t2D.value=C,h.material.uniforms.backgroundIntensity.value=R.backgroundIntensity,h.material.toneMapped=$e.getTransfer(C.colorSpace)!==rt,C.matrixAutoUpdate===!0&&C.updateMatrix(),h.material.uniforms.uvTransform.value.copy(C.matrix),(a!==C||l!==C.version||u!==i.toneMapping)&&(h.material.needsUpdate=!0,a=C,l=C.version,u=i.toneMapping),h.layers.enableAll(),A.unshift(h,h.geometry,h.material,0,0,null))}function f(A,R){A.getRGB(Hr,jl(i)),n.buffers.color.setClear(Hr.r,Hr.g,Hr.b,R,o)}function v(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0)}return{getClearColor:function(){return c},setClearColor:function(A,R=1){c.set(A),d=R,f(c,d)},getClearAlpha:function(){return d},setClearAlpha:function(A){d=A,f(c,d)},render:m,addToRenderList:S,dispose:v}}function wp(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=l(null);let s=r,o=!1;function c(_,P,G,Z,j){let $=!1;const ie=a(Z,G,P);s!==ie&&(s=ie,h(s.object)),$=u(_,Z,G,j),$&&E(_,Z,G,j),j!==null&&e.update(j,i.ELEMENT_ARRAY_BUFFER),($||o)&&(o=!1,R(_,P,G,Z),j!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(j).buffer))}function d(){return i.createVertexArray()}function h(_){return i.bindVertexArray(_)}function p(_){return i.deleteVertexArray(_)}function a(_,P,G){const Z=G.wireframe===!0;let j=n[_.id];j===void 0&&(j={},n[_.id]=j);let $=j[P.id];$===void 0&&($={},j[P.id]=$);let ie=$[Z];return ie===void 0&&(ie=l(d()),$[Z]=ie),ie}function l(_){const P=[],G=[],Z=[];for(let j=0;j<t;j++)P[j]=0,G[j]=0,Z[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:G,attributeDivisors:Z,object:_,attributes:{},index:null}}function u(_,P,G,Z){const j=s.attributes,$=P.attributes;let ie=0;const Q=G.getAttributes();for(const B in Q)if(Q[B].location>=0){const le=j[B];let _e=$[B];if(_e===void 0&&(B==="instanceMatrix"&&_.instanceMatrix&&(_e=_.instanceMatrix),B==="instanceColor"&&_.instanceColor&&(_e=_.instanceColor)),le===void 0||le.attribute!==_e||_e&&le.data!==_e.data)return!0;ie++}return s.attributesNum!==ie||s.index!==Z}function E(_,P,G,Z){const j={},$=P.attributes;let ie=0;const Q=G.getAttributes();for(const B in Q)if(Q[B].location>=0){let le=$[B];le===void 0&&(B==="instanceMatrix"&&_.instanceMatrix&&(le=_.instanceMatrix),B==="instanceColor"&&_.instanceColor&&(le=_.instanceColor));const _e={};_e.attribute=le,le&&le.data&&(_e.data=le.data),j[B]=_e,ie++}s.attributes=j,s.attributesNum=ie,s.index=Z}function m(){const _=s.newAttributes;for(let P=0,G=_.length;P<G;P++)_[P]=0}function S(_){f(_,0)}function f(_,P){const G=s.newAttributes,Z=s.enabledAttributes,j=s.attributeDivisors;G[_]=1,Z[_]===0&&(i.enableVertexAttribArray(_),Z[_]=1),j[_]!==P&&(i.vertexAttribDivisor(_,P),j[_]=P)}function v(){const _=s.newAttributes,P=s.enabledAttributes;for(let G=0,Z=P.length;G<Z;G++)P[G]!==_[G]&&(i.disableVertexAttribArray(G),P[G]=0)}function A(_,P,G,Z,j,$,ie){ie===!0?i.vertexAttribIPointer(_,P,G,j,$):i.vertexAttribPointer(_,P,G,Z,j,$)}function R(_,P,G,Z){m();const j=Z.attributes,$=G.getAttributes(),ie=P.defaultAttributeValues;for(const Q in $){const B=$[Q];if(B.location>=0){let pe=j[Q];if(pe===void 0&&(Q==="instanceMatrix"&&_.instanceMatrix&&(pe=_.instanceMatrix),Q==="instanceColor"&&_.instanceColor&&(pe=_.instanceColor)),pe!==void 0){const le=pe.normalized,_e=pe.itemSize,Ue=e.get(pe);if(Ue===void 0)continue;const He=Ue.buffer,X=Ue.type,U=Ue.bytesPerElement,M=X===i.INT||X===i.UNSIGNED_INT||pe.gpuType===ka;if(pe.isInterleavedBufferAttribute){const g=pe.data,z=g.stride,se=pe.offset;if(g.isInstancedInterleavedBuffer){for(let k=0;k<B.locationSize;k++)f(B.location+k,g.meshPerAttribute);_.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=g.meshPerAttribute*g.count)}else for(let k=0;k<B.locationSize;k++)S(B.location+k);i.bindBuffer(i.ARRAY_BUFFER,He);for(let k=0;k<B.locationSize;k++)A(B.location+k,_e/B.locationSize,X,le,z*U,(se+_e/B.locationSize*k)*U,M)}else{if(pe.isInstancedBufferAttribute){for(let g=0;g<B.locationSize;g++)f(B.location+g,pe.meshPerAttribute);_.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=pe.meshPerAttribute*pe.count)}else for(let g=0;g<B.locationSize;g++)S(B.location+g);i.bindBuffer(i.ARRAY_BUFFER,He);for(let g=0;g<B.locationSize;g++)A(B.location+g,_e/B.locationSize,X,le,_e*U,_e/B.locationSize*g*U,M)}}else if(ie!==void 0){const le=ie[Q];if(le!==void 0)switch(le.length){case 2:i.vertexAttrib2fv(B.location,le);break;case 3:i.vertexAttrib3fv(B.location,le);break;case 4:i.vertexAttrib4fv(B.location,le);break;default:i.vertexAttrib1fv(B.location,le)}}}}v()}function C(){w();for(const _ in n){const P=n[_];for(const G in P){const Z=P[G];for(const j in Z)p(Z[j].object),delete Z[j];delete P[G]}delete n[_]}}function y(_){if(n[_.id]===void 0)return;const P=n[_.id];for(const G in P){const Z=P[G];for(const j in Z)p(Z[j].object),delete Z[j];delete P[G]}delete n[_.id]}function N(_){for(const P in n){const G=n[P];if(G[_.id]===void 0)continue;const Z=G[_.id];for(const j in Z)p(Z[j].object),delete Z[j];delete G[_.id]}}function w(){I(),o=!0,s!==r&&(s=r,h(s.object))}function I(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:c,reset:w,resetDefaultState:I,dispose:C,releaseStatesOfGeometry:y,releaseStatesOfProgram:N,initAttributes:m,enableAttribute:S,disableUnusedAttributes:v}}function Fp(i,e,t){let n;function r(h){n=h}function s(h,p){i.drawArrays(n,h,p),t.update(p,n,1)}function o(h,p,a){a!==0&&(i.drawArraysInstanced(n,h,p,a),t.update(p,n,a))}function c(h,p,a){if(a===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,h,0,p,0,a);let u=0;for(let E=0;E<a;E++)u+=p[E];t.update(u,n,1)}function d(h,p,a,l){if(a===0)return;const u=e.get("WEBGL_multi_draw");if(u===null)for(let E=0;E<h.length;E++)o(h[E],p[E],l[E]);else{u.multiDrawArraysInstancedWEBGL(n,h,0,p,0,l,0,a);let E=0;for(let m=0;m<a;m++)E+=p[m]*l[m];t.update(E,n,1)}}this.setMode=r,this.render=s,this.renderInstances=o,this.renderMultiDraw=c,this.renderMultiDrawInstances=d}function Bp(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const N=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(N.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function o(N){return!(N!==un&&n.convert(N)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function c(N){const w=N===Hi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(N!==Cn&&n.convert(N)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&N!==yn&&!w)}function d(N){if(N==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";N="mediump"}return N==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=t.precision!==void 0?t.precision:"highp";const p=d(h);p!==h&&(Ke("WebGLRenderer:",h,"not supported, using",p,"instead."),h=p);const a=t.logarithmicDepthBuffer===!0,l=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),E=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_TEXTURE_SIZE),S=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),v=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),A=i.getParameter(i.MAX_VARYING_VECTORS),R=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),C=E>0,y=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:d,textureFormatReadable:o,textureTypeReadable:c,precision:h,logarithmicDepthBuffer:a,reversedDepthBuffer:l,maxTextures:u,maxVertexTextures:E,maxTextureSize:m,maxCubemapSize:S,maxAttributes:f,maxVertexUniforms:v,maxVaryings:A,maxFragmentUniforms:R,vertexTextures:C,maxSamples:y}}function Hp(i){const e=this;let t=null,n=0,r=!1,s=!1;const o=new kn,c=new Ye,d={value:null,needsUpdate:!1};this.uniform=d,this.numPlanes=0,this.numIntersection=0,this.init=function(a,l){const u=a.length!==0||l||n!==0||r;return r=l,n=a.length,u},this.beginShadows=function(){s=!0,p(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(a,l){t=p(a,l,0)},this.setState=function(a,l,u){const E=a.clippingPlanes,m=a.clipIntersection,S=a.clipShadows,f=i.get(a);if(!r||E===null||E.length===0||s&&!S)s?p(null):h();else{const v=s?0:n,A=v*4;let R=f.clippingState||null;d.value=R,R=p(E,l,A,u);for(let C=0;C!==A;++C)R[C]=t[C];f.clippingState=R,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=v}};function h(){d.value!==t&&(d.value=t,d.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function p(a,l,u,E){const m=a!==null?a.length:0;let S=null;if(m!==0){if(S=d.value,E!==!0||S===null){const f=u+m*4,v=l.matrixWorldInverse;c.getNormalMatrix(v),(S===null||S.length<f)&&(S=new Float32Array(f));for(let A=0,R=u;A!==m;++A,R+=4)o.copy(a[A]).applyMatrix4(v,c),o.normal.toArray(S,R),S[R+3]=o.constant}d.value=S,d.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,S}}function Gp(i){let e=new WeakMap;function t(o,c){return c===na?o.mapping=Pi:c===ia&&(o.mapping=Ui),o}function n(o){if(o&&o.isTexture){const c=o.mapping;if(c===na||c===ia)if(e.has(o)){const d=e.get(o).texture;return t(d,o.mapping)}else{const d=o.image;if(d&&d.height>0){const h=new nh(d.height);return h.fromEquirectangularTexture(i,o),e.set(o,h),o.addEventListener("dispose",r),t(h.texture,o.mapping)}else return null}}return o}function r(o){const c=o.target;c.removeEventListener("dispose",r);const d=e.get(c);d!==void 0&&(e.delete(c),d.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}const Kn=4,Qo=[.125,.215,.35,.446,.526,.582],ai=20,Vp=256,Qi=new qh,$o=new tt;let Bs=null,Hs=0,Gs=0,Vs=!1;const kp=new V;class el{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,s={}){const{size:o=256,position:c=kp}=s;Bs=this._renderer.getRenderTarget(),Hs=this._renderer.getActiveCubeFace(),Gs=this._renderer.getActiveMipmapLevel(),Vs=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const d=this._allocateTargets();return d.depthBuffer=!0,this._sceneToCubeUV(e,n,r,d,c),t>0&&this._blur(d,0,0,t),this._applyPMREM(d),this._cleanup(d),d}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=il(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=nl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Bs,Hs,Gs),this._renderer.xr.enabled=Vs,e.scissorTest=!1,Li(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Pi||e.mapping===Ui?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Bs=this._renderer.getRenderTarget(),Hs=this._renderer.getActiveCubeFace(),Gs=this._renderer.getActiveMipmapLevel(),Vs=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:$t,minFilter:$t,generateMipmaps:!1,type:Hi,format:un,colorSpace:wi,depthBuffer:!1},r=tl(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=tl(e,t,n);const{_lodMax:s}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Wp(s)),this._blurMaterial=zp(s,e,t),this._ggxMaterial=Yp(s,e,t)}return r}_compileMaterial(e){const t=new Mt(new gt,e);this._renderer.compile(t,Qi)}_sceneToCubeUV(e,t,n,r,s){const d=new jt(90,1,t,n),h=[1,-1,1,1,1,1],p=[1,1,1,-1,-1,-1],a=this._renderer,l=a.autoClear,u=a.toneMapping;a.getClearColor($o),a.toneMapping=Xn,a.autoClear=!1,a.state.buffers.depth.getReversed()&&(a.setRenderTarget(r),a.clearDepth(),a.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Mt(new di,new Qt({name:"PMREM.Background",side:It,depthWrite:!1,depthTest:!1})));const m=this._backgroundBox,S=m.material;let f=!1;const v=e.background;v?v.isColor&&(S.color.copy(v),e.background=null,f=!0):(S.color.copy($o),f=!0);for(let A=0;A<6;A++){const R=A%3;R===0?(d.up.set(0,h[A],0),d.position.set(s.x,s.y,s.z),d.lookAt(s.x+p[A],s.y,s.z)):R===1?(d.up.set(0,0,h[A]),d.position.set(s.x,s.y,s.z),d.lookAt(s.x,s.y+p[A],s.z)):(d.up.set(0,h[A],0),d.position.set(s.x,s.y,s.z),d.lookAt(s.x,s.y,s.z+p[A]));const C=this._cubeSize;Li(r,R*C,A>2?C:0,C,C),a.setRenderTarget(r),f&&a.render(m,d),a.render(e,d)}a.toneMapping=u,a.autoClear=l,e.background=v}_textureToCubeUV(e,t){const n=this._renderer,r=e.mapping===Pi||e.mapping===Ui;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=il()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=nl());const s=r?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=s;const c=s.uniforms;c.envMap.value=e;const d=this._cubeSize;Li(t,0,0,3*d,2*d),n.setRenderTarget(t),n.render(o,Qi)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const r=this._lodMeshes.length;for(let s=1;s<r;s++)this._applyGGXFilter(e,s-1,s);t.autoClear=n}_applyGGXFilter(e,t,n){const r=this._renderer,s=this._pingPongRenderTarget,o=this._ggxMaterial,c=this._lodMeshes[n];c.material=o;const d=o.uniforms,h=n/(this._lodMeshes.length-1),p=t/(this._lodMeshes.length-1),a=Math.sqrt(h*h-p*p),l=.05+h*.95,u=a*l,{_lodMax:E}=this,m=this._sizeLods[n],S=3*m*(n>E-Kn?n-E+Kn:0),f=4*(this._cubeSize-m);d.envMap.value=e.texture,d.roughness.value=u,d.mipInt.value=E-t,Li(s,S,f,3*m,2*m),r.setRenderTarget(s),r.render(c,Qi),d.envMap.value=s.texture,d.roughness.value=0,d.mipInt.value=E-n,Li(e,S,f,3*m,2*m),r.setRenderTarget(e),r.render(c,Qi)}_blur(e,t,n,r,s){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,r,"latitudinal",s),this._halfBlur(o,e,n,n,r,"longitudinal",s)}_halfBlur(e,t,n,r,s,o,c){const d=this._renderer,h=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&dt("blur direction must be either latitudinal or longitudinal!");const p=3,a=this._lodMeshes[r];a.material=h;const l=h.uniforms,u=this._sizeLods[n]-1,E=isFinite(s)?Math.PI/(2*u):2*Math.PI/(2*ai-1),m=s/E,S=isFinite(s)?1+Math.floor(p*m):ai;S>ai&&Ke(`sigmaRadians, ${s}, is too large and will clip, as it requested ${S} samples when the maximum is set to ${ai}`);const f=[];let v=0;for(let N=0;N<ai;++N){const w=N/m,I=Math.exp(-w*w/2);f.push(I),N===0?v+=I:N<S&&(v+=2*I)}for(let N=0;N<f.length;N++)f[N]=f[N]/v;l.envMap.value=e.texture,l.samples.value=S,l.weights.value=f,l.latitudinal.value=o==="latitudinal",c&&(l.poleAxis.value=c);const{_lodMax:A}=this;l.dTheta.value=E,l.mipInt.value=A-n;const R=this._sizeLods[r],C=3*R*(r>A-Kn?r-A+Kn:0),y=4*(this._cubeSize-R);Li(t,C,y,3*R,2*R),d.setRenderTarget(t),d.render(a,Qi)}}function Wp(i){const e=[],t=[],n=[];let r=i;const s=i-Kn+1+Qo.length;for(let o=0;o<s;o++){const c=Math.pow(2,r);e.push(c);let d=1/c;o>i-Kn?d=Qo[o-i+Kn-1]:o===0&&(d=0),t.push(d);const h=1/(c-2),p=-h,a=1+h,l=[p,p,a,p,a,a,p,p,a,a,p,a],u=6,E=6,m=3,S=2,f=1,v=new Float32Array(m*E*u),A=new Float32Array(S*E*u),R=new Float32Array(f*E*u);for(let y=0;y<u;y++){const N=y%3*2/3-1,w=y>2?0:-1,I=[N,w,0,N+2/3,w,0,N+2/3,w+1,0,N,w,0,N+2/3,w+1,0,N,w+1,0];v.set(I,m*E*y),A.set(l,S*E*y);const _=[y,y,y,y,y,y];R.set(_,f*E*y)}const C=new gt;C.setAttribute("position",new dn(v,m)),C.setAttribute("uv",new dn(A,S)),C.setAttribute("faceIndex",new dn(R,f)),n.push(new Mt(C,null)),r>Kn&&r--}return{lodMeshes:n,sizeLods:e,sigmas:t}}function tl(i,e,t){const n=new Zn(i,e,t);return n.texture.mapping=rs,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Li(i,e,t,n,r){i.viewport.set(e,t,n,r),i.scissor.set(e,t,n,r)}function Yp(i,e,t){return new en({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Vp,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:os(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function zp(i,e,t){const n=new Float32Array(ai),r=new V(0,1,0);return new en({name:"SphericalGaussianBlur",defines:{n:ai,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:os(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function nl(){return new en({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:os(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function il(){return new en({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:os(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:bn,depthTest:!1,depthWrite:!1})}function os(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Kp(i){let e=new WeakMap,t=null;function n(c){if(c&&c.isTexture){const d=c.mapping,h=d===na||d===ia,p=d===Pi||d===Ui;if(h||p){let a=e.get(c);const l=a!==void 0?a.texture.pmremVersion:0;if(c.isRenderTargetTexture&&c.pmremVersion!==l)return t===null&&(t=new el(i)),a=h?t.fromEquirectangular(c,a):t.fromCubemap(c,a),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),a.texture;if(a!==void 0)return a.texture;{const u=c.image;return h&&u&&u.height>0||p&&u&&r(u)?(t===null&&(t=new el(i)),a=h?t.fromEquirectangular(c):t.fromCubemap(c),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),c.addEventListener("dispose",s),a.texture):null}}}return c}function r(c){let d=0;const h=6;for(let p=0;p<h;p++)c[p]!==void 0&&d++;return d===h}function s(c){const d=c.target;d.removeEventListener("dispose",s);const h=e.get(d);h!==void 0&&(e.delete(d),h.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function Xp(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const r=i.getExtension(n);return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&cr("WebGLRenderer: "+n+" extension not supported."),r}}}function qp(i,e,t,n){const r={},s=new WeakMap;function o(a){const l=a.target;l.index!==null&&e.remove(l.index);for(const E in l.attributes)e.remove(l.attributes[E]);l.removeEventListener("dispose",o),delete r[l.id];const u=s.get(l);u&&(e.remove(u),s.delete(l)),n.releaseStatesOfGeometry(l),l.isInstancedBufferGeometry===!0&&delete l._maxInstanceCount,t.memory.geometries--}function c(a,l){return r[l.id]===!0||(l.addEventListener("dispose",o),r[l.id]=!0,t.memory.geometries++),l}function d(a){const l=a.attributes;for(const u in l)e.update(l[u],i.ARRAY_BUFFER)}function h(a){const l=[],u=a.index,E=a.attributes.position;let m=0;if(u!==null){const v=u.array;m=u.version;for(let A=0,R=v.length;A<R;A+=3){const C=v[A+0],y=v[A+1],N=v[A+2];l.push(C,y,y,N,N,C)}}else if(E!==void 0){const v=E.array;m=E.version;for(let A=0,R=v.length/3-1;A<R;A+=3){const C=A+0,y=A+1,N=A+2;l.push(C,y,y,N,N,C)}}else return;const S=new(Kl(l)?Jl:Zl)(l,1);S.version=m;const f=s.get(a);f&&e.remove(f),s.set(a,S)}function p(a){const l=s.get(a);if(l){const u=a.index;u!==null&&l.version<u.version&&h(a)}else h(a);return s.get(a)}return{get:c,update:d,getWireframeAttribute:p}}function Zp(i,e,t){let n;function r(l){n=l}let s,o;function c(l){s=l.type,o=l.bytesPerElement}function d(l,u){i.drawElements(n,u,s,l*o),t.update(u,n,1)}function h(l,u,E){E!==0&&(i.drawElementsInstanced(n,u,s,l*o,E),t.update(u,n,E))}function p(l,u,E){if(E===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,s,l,0,E);let S=0;for(let f=0;f<E;f++)S+=u[f];t.update(S,n,1)}function a(l,u,E,m){if(E===0)return;const S=e.get("WEBGL_multi_draw");if(S===null)for(let f=0;f<l.length;f++)h(l[f]/o,u[f],m[f]);else{S.multiDrawElementsInstancedWEBGL(n,u,0,s,l,0,m,0,E);let f=0;for(let v=0;v<E;v++)f+=u[v]*m[v];t.update(f,n,1)}}this.setMode=r,this.setIndex=c,this.render=d,this.renderInstances=h,this.renderMultiDraw=p,this.renderMultiDrawInstances=a}function Jp(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,o,c){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=c*(s/3);break;case i.LINES:t.lines+=c*(s/2);break;case i.LINE_STRIP:t.lines+=c*(s-1);break;case i.LINE_LOOP:t.lines+=c*s;break;case i.POINTS:t.points+=c*s;break;default:dt("WebGLInfo: Unknown draw mode:",o);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function jp(i,e,t){const n=new WeakMap,r=new St;function s(o,c,d){const h=o.morphTargetInfluences,p=c.morphAttributes.position||c.morphAttributes.normal||c.morphAttributes.color,a=p!==void 0?p.length:0;let l=n.get(c);if(l===void 0||l.count!==a){let _=function(){w.dispose(),n.delete(c),c.removeEventListener("dispose",_)};var u=_;l!==void 0&&l.texture.dispose();const E=c.morphAttributes.position!==void 0,m=c.morphAttributes.normal!==void 0,S=c.morphAttributes.color!==void 0,f=c.morphAttributes.position||[],v=c.morphAttributes.normal||[],A=c.morphAttributes.color||[];let R=0;E===!0&&(R=1),m===!0&&(R=2),S===!0&&(R=3);let C=c.attributes.position.count*R,y=1;C>e.maxTextureSize&&(y=Math.ceil(C/e.maxTextureSize),C=e.maxTextureSize);const N=new Float32Array(C*y*4*a),w=new Xl(N,C,y,a);w.type=yn,w.needsUpdate=!0;const I=R*4;for(let P=0;P<a;P++){const G=f[P],Z=v[P],j=A[P],$=C*y*4*P;for(let ie=0;ie<G.count;ie++){const Q=ie*I;E===!0&&(r.fromBufferAttribute(G,ie),N[$+Q+0]=r.x,N[$+Q+1]=r.y,N[$+Q+2]=r.z,N[$+Q+3]=0),m===!0&&(r.fromBufferAttribute(Z,ie),N[$+Q+4]=r.x,N[$+Q+5]=r.y,N[$+Q+6]=r.z,N[$+Q+7]=0),S===!0&&(r.fromBufferAttribute(j,ie),N[$+Q+8]=r.x,N[$+Q+9]=r.y,N[$+Q+10]=r.z,N[$+Q+11]=j.itemSize===4?r.w:1)}}l={count:a,texture:w,size:new oe(C,y)},n.set(c,l),c.addEventListener("dispose",_)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)d.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let E=0;for(let S=0;S<h.length;S++)E+=h[S];const m=c.morphTargetsRelative?1:1-E;d.getUniforms().setValue(i,"morphTargetBaseInfluence",m),d.getUniforms().setValue(i,"morphTargetInfluences",h)}d.getUniforms().setValue(i,"morphTargetsTexture",l.texture,t),d.getUniforms().setValue(i,"morphTargetsTextureSize",l.size)}return{update:s}}function Qp(i,e,t,n){let r=new WeakMap;function s(d){const h=n.render.frame,p=d.geometry,a=e.get(d,p);if(r.get(a)!==h&&(e.update(a),r.set(a,h)),d.isInstancedMesh&&(d.hasEventListener("dispose",c)===!1&&d.addEventListener("dispose",c),r.get(d)!==h&&(t.update(d.instanceMatrix,i.ARRAY_BUFFER),d.instanceColor!==null&&t.update(d.instanceColor,i.ARRAY_BUFFER),r.set(d,h))),d.isSkinnedMesh){const l=d.skeleton;r.get(l)!==h&&(l.update(),r.set(l,h))}return a}function o(){r=new WeakMap}function c(d){const h=d.target;h.removeEventListener("dispose",c),t.remove(h.instanceMatrix),h.instanceColor!==null&&t.remove(h.instanceColor)}return{update:s,dispose:o}}const fc=new Nt,rl=new tc(1,1),pc=new Xl,Ec=new Hu,Sc=new $l,sl=[],al=[],ol=new Float32Array(16),ll=new Float32Array(9),cl=new Float32Array(4);function ki(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=sl[r];if(s===void 0&&(s=new Float32Array(r),sl[r]=s),e!==0){n.toArray(s,0);for(let o=1,c=0;o!==e;++o)c+=t,i[o].toArray(s,c)}return s}function Tt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Rt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function ls(i,e){let t=al[e];t===void 0&&(t=new Int32Array(e),al[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function $p(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function eE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Tt(t,e))return;i.uniform2fv(this.addr,e),Rt(t,e)}}function tE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Tt(t,e))return;i.uniform3fv(this.addr,e),Rt(t,e)}}function nE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Tt(t,e))return;i.uniform4fv(this.addr,e),Rt(t,e)}}function iE(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Tt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Rt(t,e)}else{if(Tt(t,n))return;cl.set(n),i.uniformMatrix2fv(this.addr,!1,cl),Rt(t,n)}}function rE(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Tt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Rt(t,e)}else{if(Tt(t,n))return;ll.set(n),i.uniformMatrix3fv(this.addr,!1,ll),Rt(t,n)}}function sE(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Tt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Rt(t,e)}else{if(Tt(t,n))return;ol.set(n),i.uniformMatrix4fv(this.addr,!1,ol),Rt(t,n)}}function aE(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function oE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Tt(t,e))return;i.uniform2iv(this.addr,e),Rt(t,e)}}function lE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Tt(t,e))return;i.uniform3iv(this.addr,e),Rt(t,e)}}function cE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Tt(t,e))return;i.uniform4iv(this.addr,e),Rt(t,e)}}function uE(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function hE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Tt(t,e))return;i.uniform2uiv(this.addr,e),Rt(t,e)}}function dE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Tt(t,e))return;i.uniform3uiv(this.addr,e),Rt(t,e)}}function fE(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Tt(t,e))return;i.uniform4uiv(this.addr,e),Rt(t,e)}}function pE(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?(rl.compareFunction=zl,s=rl):s=fc,t.setTexture2D(e||s,r)}function EE(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||Ec,r)}function SE(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTextureCube(e||Sc,r)}function mE(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||pc,r)}function AE(i){switch(i){case 5126:return $p;case 35664:return eE;case 35665:return tE;case 35666:return nE;case 35674:return iE;case 35675:return rE;case 35676:return sE;case 5124:case 35670:return aE;case 35667:case 35671:return oE;case 35668:case 35672:return lE;case 35669:case 35673:return cE;case 5125:return uE;case 36294:return hE;case 36295:return dE;case 36296:return fE;case 35678:case 36198:case 36298:case 36306:case 35682:return pE;case 35679:case 36299:case 36307:return EE;case 35680:case 36300:case 36308:case 36293:return SE;case 36289:case 36303:case 36311:case 36292:return mE}}function xE(i,e){i.uniform1fv(this.addr,e)}function _E(i,e){const t=ki(e,this.size,2);i.uniform2fv(this.addr,t)}function gE(i,e){const t=ki(e,this.size,3);i.uniform3fv(this.addr,t)}function TE(i,e){const t=ki(e,this.size,4);i.uniform4fv(this.addr,t)}function RE(i,e){const t=ki(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function vE(i,e){const t=ki(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function ME(i,e){const t=ki(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function IE(i,e){i.uniform1iv(this.addr,e)}function LE(i,e){i.uniform2iv(this.addr,e)}function yE(i,e){i.uniform3iv(this.addr,e)}function bE(i,e){i.uniform4iv(this.addr,e)}function OE(i,e){i.uniform1uiv(this.addr,e)}function CE(i,e){i.uniform2uiv(this.addr,e)}function NE(i,e){i.uniform3uiv(this.addr,e)}function DE(i,e){i.uniform4uiv(this.addr,e)}function PE(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Tt(n,s)||(i.uniform1iv(this.addr,s),Rt(n,s));for(let o=0;o!==r;++o)t.setTexture2D(e[o]||fc,s[o])}function UE(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Tt(n,s)||(i.uniform1iv(this.addr,s),Rt(n,s));for(let o=0;o!==r;++o)t.setTexture3D(e[o]||Ec,s[o])}function wE(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Tt(n,s)||(i.uniform1iv(this.addr,s),Rt(n,s));for(let o=0;o!==r;++o)t.setTextureCube(e[o]||Sc,s[o])}function FE(i,e,t){const n=this.cache,r=e.length,s=ls(t,r);Tt(n,s)||(i.uniform1iv(this.addr,s),Rt(n,s));for(let o=0;o!==r;++o)t.setTexture2DArray(e[o]||pc,s[o])}function BE(i){switch(i){case 5126:return xE;case 35664:return _E;case 35665:return gE;case 35666:return TE;case 35674:return RE;case 35675:return vE;case 35676:return ME;case 5124:case 35670:return IE;case 35667:case 35671:return LE;case 35668:case 35672:return yE;case 35669:case 35673:return bE;case 5125:return OE;case 36294:return CE;case 36295:return NE;case 36296:return DE;case 35678:case 36198:case 36298:case 36306:case 35682:return PE;case 35679:case 36299:case 36307:return UE;case 35680:case 36300:case 36308:case 36293:return wE;case 36289:case 36303:case 36311:case 36292:return FE}}class HE{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=AE(t.type)}}class GE{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=BE(t.type)}}class VE{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,o=r.length;s!==o;++s){const c=r[s];c.setValue(e,t[c.id],n)}}}const ks=/(\w+)(\])?(\[|\.)?/g;function ul(i,e){i.seq.push(e),i.map[e.id]=e}function kE(i,e,t){const n=i.name,r=n.length;for(ks.lastIndex=0;;){const s=ks.exec(n),o=ks.lastIndex;let c=s[1];const d=s[2]==="]",h=s[3];if(d&&(c=c|0),h===void 0||h==="["&&o+2===r){ul(t,h===void 0?new HE(c,i,e):new GE(c,i,e));break}else{let a=t.map[c];a===void 0&&(a=new VE(c),ul(t,a)),t=a}}}class Zr{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const s=e.getActiveUniform(t,r),o=e.getUniformLocation(t,s.name);kE(s,o,this)}}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,o=t.length;s!==o;++s){const c=t[s],d=n[c.id];d.needsUpdate!==!1&&c.setValue(e,d.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const o=e[r];o.id in t&&n.push(o)}return n}}function hl(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const WE=37297;let YE=0;function zE(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=r;o<s;o++){const c=o+1;n.push(`${c===e?">":" "} ${c}: ${t[o]}`)}return n.join(`
`)}const dl=new Ye;function KE(i){$e._getMatrix(dl,$e.workingColorSpace,i);const e=`mat3( ${dl.elements.map(t=>t.toFixed(4))} )`;switch($e.getTransfer(i)){case jr:return[e,"LinearTransferOETF"];case rt:return[e,"sRGBTransferOETF"];default:return Ke("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function fl(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=(i.getShaderInfoLog(e)||"").trim();if(n&&s==="")return"";const o=/ERROR: 0:(\d+)/.exec(s);if(o){const c=parseInt(o[1]);return t.toUpperCase()+`

`+s+`

`+zE(i.getShaderSource(e),c)}else return s}function XE(i,e){const t=KE(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function qE(i,e){let t;switch(e){case hu:t="Linear";break;case du:t="Reinhard";break;case fu:t="Cineon";break;case pu:t="ACESFilmic";break;case Su:t="AgX";break;case mu:t="Neutral";break;case Eu:t="Custom";break;default:Ke("WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Gr=new V;function ZE(){$e.getLuminanceCoefficients(Gr);const i=Gr.x.toFixed(4),e=Gr.y.toFixed(4),t=Gr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function JE(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(tr).join(`
`)}function jE(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function QE(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),o=s.name;let c=1;s.type===i.FLOAT_MAT2&&(c=2),s.type===i.FLOAT_MAT3&&(c=3),s.type===i.FLOAT_MAT4&&(c=4),t[o]={type:s.type,location:i.getAttribLocation(e,o),locationSize:c}}return t}function tr(i){return i!==""}function pl(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function El(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const $E=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ha(i){return i.replace($E,tS)}const eS=new Map;function tS(i,e){let t=Ze[e];if(t===void 0){const n=eS.get(e);if(n!==void 0)t=Ze[n],Ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Ha(t)}const nS=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Sl(i){return i.replace(nS,iS)}function iS(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function ml(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function rS(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Ul?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===Yc?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===In&&(e="SHADOWMAP_TYPE_VSM"),e}function sS(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Pi:case Ui:e="ENVMAP_TYPE_CUBE";break;case rs:e="ENVMAP_TYPE_CUBE_UV";break}return e}function aS(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Ui:e="ENVMAP_MODE_REFRACTION";break}return e}function oS(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case wl:e="ENVMAP_BLENDING_MULTIPLY";break;case cu:e="ENVMAP_BLENDING_MIX";break;case uu:e="ENVMAP_BLENDING_ADD";break}return e}function lS(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function cS(i,e,t,n){const r=i.getContext(),s=t.defines;let o=t.vertexShader,c=t.fragmentShader;const d=rS(t),h=sS(t),p=aS(t),a=oS(t),l=lS(t),u=JE(t),E=jE(s),m=r.createProgram();let S,f,v=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(S=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,E].filter(tr).join(`
`),S.length>0&&(S+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,E].filter(tr).join(`
`),f.length>0&&(f+=`
`)):(S=[ml(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,E,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+p:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(tr).join(`
`),f=[ml(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,E,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.envMap?"#define "+p:"",t.envMap?"#define "+a:"",l?"#define CUBEUV_TEXEL_WIDTH "+l.texelWidth:"",l?"#define CUBEUV_TEXEL_HEIGHT "+l.texelHeight:"",l?"#define CUBEUV_MAX_MIP "+l.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Xn?"#define TONE_MAPPING":"",t.toneMapping!==Xn?Ze.tonemapping_pars_fragment:"",t.toneMapping!==Xn?qE("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ze.colorspace_pars_fragment,XE("linearToOutputTexel",t.outputColorSpace),ZE(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(tr).join(`
`)),o=Ha(o),o=pl(o,t),o=El(o,t),c=Ha(c),c=pl(c,t),c=El(c,t),o=Sl(o),c=Sl(c),t.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,S=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+S,f=["#define varying in",t.glslVersion===To?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===To?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const A=v+S+o,R=v+f+c,C=hl(r,r.VERTEX_SHADER,A),y=hl(r,r.FRAGMENT_SHADER,R);r.attachShader(m,C),r.attachShader(m,y),t.index0AttributeName!==void 0?r.bindAttribLocation(m,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(m,0,"position"),r.linkProgram(m);function N(P){if(i.debug.checkShaderErrors){const G=r.getProgramInfoLog(m)||"",Z=r.getShaderInfoLog(C)||"",j=r.getShaderInfoLog(y)||"",$=G.trim(),ie=Z.trim(),Q=j.trim();let B=!0,pe=!0;if(r.getProgramParameter(m,r.LINK_STATUS)===!1)if(B=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,m,C,y);else{const le=fl(r,C,"vertex"),_e=fl(r,y,"fragment");dt("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(m,r.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+$+`
`+le+`
`+_e)}else $!==""?Ke("WebGLProgram: Program Info Log:",$):(ie===""||Q==="")&&(pe=!1);pe&&(P.diagnostics={runnable:B,programLog:$,vertexShader:{log:ie,prefix:S},fragmentShader:{log:Q,prefix:f}})}r.deleteShader(C),r.deleteShader(y),w=new Zr(r,m),I=QE(r,m)}let w;this.getUniforms=function(){return w===void 0&&N(this),w};let I;this.getAttributes=function(){return I===void 0&&N(this),I};let _=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return _===!1&&(_=r.getProgramParameter(m,WE)),_},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=YE++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=C,this.fragmentShader=y,this}let uS=0;class hS{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(r)===!1&&(o.add(r),r.usedTimes++),o.has(s)===!1&&(o.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new dS(e),t.set(e,n)),n}}class dS{constructor(e){this.id=uS++,this.code=e,this.usedTimes=0}}function fS(i,e,t,n,r,s,o){const c=new Qa,d=new hS,h=new Set,p=[],a=r.logarithmicDepthBuffer,l=r.vertexTextures;let u=r.precision;const E={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function m(I){return h.add(I),I===0?"uv":`uv${I}`}function S(I,_,P,G,Z){const j=G.fog,$=Z.geometry,ie=I.isMeshStandardMaterial?G.environment:null,Q=(I.isMeshStandardMaterial?t:e).get(I.envMap||ie),B=Q&&Q.mapping===rs?Q.image.height:null,pe=E[I.type];I.precision!==null&&(u=r.getMaxPrecision(I.precision),u!==I.precision&&Ke("WebGLProgram.getParameters:",I.precision,"not supported, using",u,"instead."));const le=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,_e=le!==void 0?le.length:0;let Ue=0;$.morphAttributes.position!==void 0&&(Ue=1),$.morphAttributes.normal!==void 0&&(Ue=2),$.morphAttributes.color!==void 0&&(Ue=3);let He,X,U,M;if(pe){const nt=Sn[pe];He=nt.vertexShader,X=nt.fragmentShader}else He=I.vertexShader,X=I.fragmentShader,d.update(I),U=d.getVertexShaderID(I),M=d.getFragmentShaderID(I);const g=i.getRenderTarget(),z=i.state.buffers.depth.getReversed(),se=Z.isInstancedMesh===!0,k=Z.isBatchedMesh===!0,ue=!!I.map,me=!!I.matcap,he=!!Q,H=!!I.aoMap,T=!!I.lightMap,q=!!I.bumpMap,J=!!I.normalMap,D=!!I.displacementMap,b=!!I.emissiveMap,ae=!!I.metalnessMap,ce=!!I.roughnessMap,Te=I.anisotropy>0,O=I.clearcoat>0,x=I.dispersion>0,W=I.iridescence>0,re=I.sheen>0,fe=I.transmission>0,ne=Te&&!!I.anisotropyMap,Ne=O&&!!I.clearcoatMap,ge=O&&!!I.clearcoatNormalMap,we=O&&!!I.clearcoatRoughnessMap,Ce=W&&!!I.iridescenceMap,Ee=W&&!!I.iridescenceThicknessMap,Ae=re&&!!I.sheenColorMap,ke=re&&!!I.sheenRoughnessMap,Ge=!!I.specularMap,be=!!I.specularColorMap,ze=!!I.specularIntensityMap,F=fe&&!!I.transmissionMap,Ie=fe&&!!I.thicknessMap,Re=!!I.gradientMap,ve=!!I.alphaMap,Se=I.alphaTest>0,de=!!I.alphaHash,De=!!I.extensions;let Xe=Xn;I.toneMapped&&(g===null||g.isXRRenderTarget===!0)&&(Xe=i.toneMapping);const ot={shaderID:pe,shaderType:I.type,shaderName:I.name,vertexShader:He,fragmentShader:X,defines:I.defines,customVertexShaderID:U,customFragmentShaderID:M,isRawShaderMaterial:I.isRawShaderMaterial===!0,glslVersion:I.glslVersion,precision:u,batching:k,batchingColor:k&&Z._colorsTexture!==null,instancing:se,instancingColor:se&&Z.instanceColor!==null,instancingMorph:se&&Z.morphTexture!==null,supportsVertexTextures:l,outputColorSpace:g===null?i.outputColorSpace:g.isXRRenderTarget===!0?g.texture.colorSpace:wi,alphaToCoverage:!!I.alphaToCoverage,map:ue,matcap:me,envMap:he,envMapMode:he&&Q.mapping,envMapCubeUVHeight:B,aoMap:H,lightMap:T,bumpMap:q,normalMap:J,displacementMap:l&&D,emissiveMap:b,normalMapObjectSpace:J&&I.normalMapType===Tu,normalMapTangentSpace:J&&I.normalMapType===gu,metalnessMap:ae,roughnessMap:ce,anisotropy:Te,anisotropyMap:ne,clearcoat:O,clearcoatMap:Ne,clearcoatNormalMap:ge,clearcoatRoughnessMap:we,dispersion:x,iridescence:W,iridescenceMap:Ce,iridescenceThicknessMap:Ee,sheen:re,sheenColorMap:Ae,sheenRoughnessMap:ke,specularMap:Ge,specularColorMap:be,specularIntensityMap:ze,transmission:fe,transmissionMap:F,thicknessMap:Ie,gradientMap:Re,opaque:I.transparent===!1&&I.blending===Ci&&I.alphaToCoverage===!1,alphaMap:ve,alphaTest:Se,alphaHash:de,combine:I.combine,mapUv:ue&&m(I.map.channel),aoMapUv:H&&m(I.aoMap.channel),lightMapUv:T&&m(I.lightMap.channel),bumpMapUv:q&&m(I.bumpMap.channel),normalMapUv:J&&m(I.normalMap.channel),displacementMapUv:D&&m(I.displacementMap.channel),emissiveMapUv:b&&m(I.emissiveMap.channel),metalnessMapUv:ae&&m(I.metalnessMap.channel),roughnessMapUv:ce&&m(I.roughnessMap.channel),anisotropyMapUv:ne&&m(I.anisotropyMap.channel),clearcoatMapUv:Ne&&m(I.clearcoatMap.channel),clearcoatNormalMapUv:ge&&m(I.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:we&&m(I.clearcoatRoughnessMap.channel),iridescenceMapUv:Ce&&m(I.iridescenceMap.channel),iridescenceThicknessMapUv:Ee&&m(I.iridescenceThicknessMap.channel),sheenColorMapUv:Ae&&m(I.sheenColorMap.channel),sheenRoughnessMapUv:ke&&m(I.sheenRoughnessMap.channel),specularMapUv:Ge&&m(I.specularMap.channel),specularColorMapUv:be&&m(I.specularColorMap.channel),specularIntensityMapUv:ze&&m(I.specularIntensityMap.channel),transmissionMapUv:F&&m(I.transmissionMap.channel),thicknessMapUv:Ie&&m(I.thicknessMap.channel),alphaMapUv:ve&&m(I.alphaMap.channel),vertexTangents:!!$.attributes.tangent&&(J||Te),vertexColors:I.vertexColors,vertexAlphas:I.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,pointsUvs:Z.isPoints===!0&&!!$.attributes.uv&&(ue||ve),fog:!!j,useFog:I.fog===!0,fogExp2:!!j&&j.isFogExp2,flatShading:I.flatShading===!0&&I.wireframe===!1,sizeAttenuation:I.sizeAttenuation===!0,logarithmicDepthBuffer:a,reversedDepthBuffer:z,skinning:Z.isSkinnedMesh===!0,morphTargets:$.morphAttributes.position!==void 0,morphNormals:$.morphAttributes.normal!==void 0,morphColors:$.morphAttributes.color!==void 0,morphTargetsCount:_e,morphTextureStride:Ue,numDirLights:_.directional.length,numPointLights:_.point.length,numSpotLights:_.spot.length,numSpotLightMaps:_.spotLightMap.length,numRectAreaLights:_.rectArea.length,numHemiLights:_.hemi.length,numDirLightShadows:_.directionalShadowMap.length,numPointLightShadows:_.pointShadowMap.length,numSpotLightShadows:_.spotShadowMap.length,numSpotLightShadowsWithMaps:_.numSpotLightShadowsWithMaps,numLightProbes:_.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:I.dithering,shadowMapEnabled:i.shadowMap.enabled&&P.length>0,shadowMapType:i.shadowMap.type,toneMapping:Xe,decodeVideoTexture:ue&&I.map.isVideoTexture===!0&&$e.getTransfer(I.map.colorSpace)===rt,decodeVideoTextureEmissive:b&&I.emissiveMap.isVideoTexture===!0&&$e.getTransfer(I.emissiveMap.colorSpace)===rt,premultipliedAlpha:I.premultipliedAlpha,doubleSided:I.side===ln,flipSided:I.side===It,useDepthPacking:I.depthPacking>=0,depthPacking:I.depthPacking||0,index0AttributeName:I.index0AttributeName,extensionClipCullDistance:De&&I.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(De&&I.extensions.multiDraw===!0||k)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:I.customProgramCacheKey()};return ot.vertexUv1s=h.has(1),ot.vertexUv2s=h.has(2),ot.vertexUv3s=h.has(3),h.clear(),ot}function f(I){const _=[];if(I.shaderID?_.push(I.shaderID):(_.push(I.customVertexShaderID),_.push(I.customFragmentShaderID)),I.defines!==void 0)for(const P in I.defines)_.push(P),_.push(I.defines[P]);return I.isRawShaderMaterial===!1&&(v(_,I),A(_,I),_.push(i.outputColorSpace)),_.push(I.customProgramCacheKey),_.join()}function v(I,_){I.push(_.precision),I.push(_.outputColorSpace),I.push(_.envMapMode),I.push(_.envMapCubeUVHeight),I.push(_.mapUv),I.push(_.alphaMapUv),I.push(_.lightMapUv),I.push(_.aoMapUv),I.push(_.bumpMapUv),I.push(_.normalMapUv),I.push(_.displacementMapUv),I.push(_.emissiveMapUv),I.push(_.metalnessMapUv),I.push(_.roughnessMapUv),I.push(_.anisotropyMapUv),I.push(_.clearcoatMapUv),I.push(_.clearcoatNormalMapUv),I.push(_.clearcoatRoughnessMapUv),I.push(_.iridescenceMapUv),I.push(_.iridescenceThicknessMapUv),I.push(_.sheenColorMapUv),I.push(_.sheenRoughnessMapUv),I.push(_.specularMapUv),I.push(_.specularColorMapUv),I.push(_.specularIntensityMapUv),I.push(_.transmissionMapUv),I.push(_.thicknessMapUv),I.push(_.combine),I.push(_.fogExp2),I.push(_.sizeAttenuation),I.push(_.morphTargetsCount),I.push(_.morphAttributeCount),I.push(_.numDirLights),I.push(_.numPointLights),I.push(_.numSpotLights),I.push(_.numSpotLightMaps),I.push(_.numHemiLights),I.push(_.numRectAreaLights),I.push(_.numDirLightShadows),I.push(_.numPointLightShadows),I.push(_.numSpotLightShadows),I.push(_.numSpotLightShadowsWithMaps),I.push(_.numLightProbes),I.push(_.shadowMapType),I.push(_.toneMapping),I.push(_.numClippingPlanes),I.push(_.numClipIntersection),I.push(_.depthPacking)}function A(I,_){c.disableAll(),_.supportsVertexTextures&&c.enable(0),_.instancing&&c.enable(1),_.instancingColor&&c.enable(2),_.instancingMorph&&c.enable(3),_.matcap&&c.enable(4),_.envMap&&c.enable(5),_.normalMapObjectSpace&&c.enable(6),_.normalMapTangentSpace&&c.enable(7),_.clearcoat&&c.enable(8),_.iridescence&&c.enable(9),_.alphaTest&&c.enable(10),_.vertexColors&&c.enable(11),_.vertexAlphas&&c.enable(12),_.vertexUv1s&&c.enable(13),_.vertexUv2s&&c.enable(14),_.vertexUv3s&&c.enable(15),_.vertexTangents&&c.enable(16),_.anisotropy&&c.enable(17),_.alphaHash&&c.enable(18),_.batching&&c.enable(19),_.dispersion&&c.enable(20),_.batchingColor&&c.enable(21),_.gradientMap&&c.enable(22),I.push(c.mask),c.disableAll(),_.fog&&c.enable(0),_.useFog&&c.enable(1),_.flatShading&&c.enable(2),_.logarithmicDepthBuffer&&c.enable(3),_.reversedDepthBuffer&&c.enable(4),_.skinning&&c.enable(5),_.morphTargets&&c.enable(6),_.morphNormals&&c.enable(7),_.morphColors&&c.enable(8),_.premultipliedAlpha&&c.enable(9),_.shadowMapEnabled&&c.enable(10),_.doubleSided&&c.enable(11),_.flipSided&&c.enable(12),_.useDepthPacking&&c.enable(13),_.dithering&&c.enable(14),_.transmission&&c.enable(15),_.sheen&&c.enable(16),_.opaque&&c.enable(17),_.pointsUvs&&c.enable(18),_.decodeVideoTexture&&c.enable(19),_.decodeVideoTextureEmissive&&c.enable(20),_.alphaToCoverage&&c.enable(21),I.push(c.mask)}function R(I){const _=E[I.type];let P;if(_){const G=Sn[_];P=Qu.clone(G.uniforms)}else P=I.uniforms;return P}function C(I,_){let P;for(let G=0,Z=p.length;G<Z;G++){const j=p[G];if(j.cacheKey===_){P=j,++P.usedTimes;break}}return P===void 0&&(P=new cS(i,_,I,s),p.push(P)),P}function y(I){if(--I.usedTimes===0){const _=p.indexOf(I);p[_]=p[p.length-1],p.pop(),I.destroy()}}function N(I){d.remove(I)}function w(){d.dispose()}return{getParameters:S,getProgramCacheKey:f,getUniforms:R,acquireProgram:C,releaseProgram:y,releaseShaderCache:N,programs:p,dispose:w}}function pS(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let c=i.get(o);return c===void 0&&(c={},i.set(o,c)),c}function n(o){i.delete(o)}function r(o,c,d){i.get(o)[c]=d}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function ES(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Al(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function xl(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function o(a,l,u,E,m,S){let f=i[e];return f===void 0?(f={id:a.id,object:a,geometry:l,material:u,groupOrder:E,renderOrder:a.renderOrder,z:m,group:S},i[e]=f):(f.id=a.id,f.object=a,f.geometry=l,f.material=u,f.groupOrder=E,f.renderOrder=a.renderOrder,f.z=m,f.group=S),e++,f}function c(a,l,u,E,m,S){const f=o(a,l,u,E,m,S);u.transmission>0?n.push(f):u.transparent===!0?r.push(f):t.push(f)}function d(a,l,u,E,m,S){const f=o(a,l,u,E,m,S);u.transmission>0?n.unshift(f):u.transparent===!0?r.unshift(f):t.unshift(f)}function h(a,l){t.length>1&&t.sort(a||ES),n.length>1&&n.sort(l||Al),r.length>1&&r.sort(l||Al)}function p(){for(let a=e,l=i.length;a<l;a++){const u=i[a];if(u.id===null)break;u.id=null,u.object=null,u.geometry=null,u.material=null,u.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:c,unshift:d,finish:p,sort:h}}function SS(){let i=new WeakMap;function e(n,r){const s=i.get(n);let o;return s===void 0?(o=new xl,i.set(n,[o])):r>=s.length?(o=new xl,s.push(o)):o=s[r],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function mS(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new V,color:new tt};break;case"SpotLight":t={position:new V,direction:new V,color:new tt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new V,color:new tt,distance:0,decay:0};break;case"HemisphereLight":t={direction:new V,skyColor:new tt,groundColor:new tt};break;case"RectAreaLight":t={color:new tt,position:new V,halfWidth:new V,halfHeight:new V};break}return i[e.id]=t,t}}}function AS(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let xS=0;function _S(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function gS(i){const e=new mS,t=AS(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)n.probe.push(new V);const r=new V,s=new mt,o=new mt;function c(h){let p=0,a=0,l=0;for(let I=0;I<9;I++)n.probe[I].set(0,0,0);let u=0,E=0,m=0,S=0,f=0,v=0,A=0,R=0,C=0,y=0,N=0;h.sort(_S);for(let I=0,_=h.length;I<_;I++){const P=h[I],G=P.color,Z=P.intensity,j=P.distance,$=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)p+=G.r*Z,a+=G.g*Z,l+=G.b*Z;else if(P.isLightProbe){for(let ie=0;ie<9;ie++)n.probe[ie].addScaledVector(P.sh.coefficients[ie],Z);N++}else if(P.isDirectionalLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){const Q=P.shadow,B=t.get(P);B.shadowIntensity=Q.intensity,B.shadowBias=Q.bias,B.shadowNormalBias=Q.normalBias,B.shadowRadius=Q.radius,B.shadowMapSize=Q.mapSize,n.directionalShadow[u]=B,n.directionalShadowMap[u]=$,n.directionalShadowMatrix[u]=P.shadow.matrix,v++}n.directional[u]=ie,u++}else if(P.isSpotLight){const ie=e.get(P);ie.position.setFromMatrixPosition(P.matrixWorld),ie.color.copy(G).multiplyScalar(Z),ie.distance=j,ie.coneCos=Math.cos(P.angle),ie.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),ie.decay=P.decay,n.spot[m]=ie;const Q=P.shadow;if(P.map&&(n.spotLightMap[C]=P.map,C++,Q.updateMatrices(P),P.castShadow&&y++),n.spotLightMatrix[m]=Q.matrix,P.castShadow){const B=t.get(P);B.shadowIntensity=Q.intensity,B.shadowBias=Q.bias,B.shadowNormalBias=Q.normalBias,B.shadowRadius=Q.radius,B.shadowMapSize=Q.mapSize,n.spotShadow[m]=B,n.spotShadowMap[m]=$,R++}m++}else if(P.isRectAreaLight){const ie=e.get(P);ie.color.copy(G).multiplyScalar(Z),ie.halfWidth.set(P.width*.5,0,0),ie.halfHeight.set(0,P.height*.5,0),n.rectArea[S]=ie,S++}else if(P.isPointLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),ie.distance=P.distance,ie.decay=P.decay,P.castShadow){const Q=P.shadow,B=t.get(P);B.shadowIntensity=Q.intensity,B.shadowBias=Q.bias,B.shadowNormalBias=Q.normalBias,B.shadowRadius=Q.radius,B.shadowMapSize=Q.mapSize,B.shadowCameraNear=Q.camera.near,B.shadowCameraFar=Q.camera.far,n.pointShadow[E]=B,n.pointShadowMap[E]=$,n.pointShadowMatrix[E]=P.shadow.matrix,A++}n.point[E]=ie,E++}else if(P.isHemisphereLight){const ie=e.get(P);ie.skyColor.copy(P.color).multiplyScalar(Z),ie.groundColor.copy(P.groundColor).multiplyScalar(Z),n.hemi[f]=ie,f++}}S>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Me.LTC_FLOAT_1,n.rectAreaLTC2=Me.LTC_FLOAT_2):(n.rectAreaLTC1=Me.LTC_HALF_1,n.rectAreaLTC2=Me.LTC_HALF_2)),n.ambient[0]=p,n.ambient[1]=a,n.ambient[2]=l;const w=n.hash;(w.directionalLength!==u||w.pointLength!==E||w.spotLength!==m||w.rectAreaLength!==S||w.hemiLength!==f||w.numDirectionalShadows!==v||w.numPointShadows!==A||w.numSpotShadows!==R||w.numSpotMaps!==C||w.numLightProbes!==N)&&(n.directional.length=u,n.spot.length=m,n.rectArea.length=S,n.point.length=E,n.hemi.length=f,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=A,n.pointShadowMap.length=A,n.spotShadow.length=R,n.spotShadowMap.length=R,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=A,n.spotLightMatrix.length=R+C-y,n.spotLightMap.length=C,n.numSpotLightShadowsWithMaps=y,n.numLightProbes=N,w.directionalLength=u,w.pointLength=E,w.spotLength=m,w.rectAreaLength=S,w.hemiLength=f,w.numDirectionalShadows=v,w.numPointShadows=A,w.numSpotShadows=R,w.numSpotMaps=C,w.numLightProbes=N,n.version=xS++)}function d(h,p){let a=0,l=0,u=0,E=0,m=0;const S=p.matrixWorldInverse;for(let f=0,v=h.length;f<v;f++){const A=h[f];if(A.isDirectionalLight){const R=n.directional[a];R.direction.setFromMatrixPosition(A.matrixWorld),r.setFromMatrixPosition(A.target.matrixWorld),R.direction.sub(r),R.direction.transformDirection(S),a++}else if(A.isSpotLight){const R=n.spot[u];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(S),R.direction.setFromMatrixPosition(A.matrixWorld),r.setFromMatrixPosition(A.target.matrixWorld),R.direction.sub(r),R.direction.transformDirection(S),u++}else if(A.isRectAreaLight){const R=n.rectArea[E];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(S),o.identity(),s.copy(A.matrixWorld),s.premultiply(S),o.extractRotation(s),R.halfWidth.set(A.width*.5,0,0),R.halfHeight.set(0,A.height*.5,0),R.halfWidth.applyMatrix4(o),R.halfHeight.applyMatrix4(o),E++}else if(A.isPointLight){const R=n.point[l];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(S),l++}else if(A.isHemisphereLight){const R=n.hemi[m];R.direction.setFromMatrixPosition(A.matrixWorld),R.direction.transformDirection(S),m++}}}return{setup:c,setupView:d,state:n}}function _l(i){const e=new gS(i),t=[],n=[];function r(p){h.camera=p,t.length=0,n.length=0}function s(p){t.push(p)}function o(p){n.push(p)}function c(){e.setup(t)}function d(p){e.setupView(t,p)}const h={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:h,setupLights:c,setupLightsView:d,pushLight:s,pushShadow:o}}function TS(i){let e=new WeakMap;function t(r,s=0){const o=e.get(r);let c;return o===void 0?(c=new _l(i),e.set(r,[c])):s>=o.length?(c=new _l(i),o.push(c)):c=o[s],c}function n(){e=new WeakMap}return{get:t,dispose:n}}const RS=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,vS=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function MS(i,e,t){let n=new ec;const r=new oe,s=new oe,o=new St,c=new kh({depthPacking:_u}),d=new Wh,h={},p=t.maxTextureSize,a={[Kt]:It,[It]:Kt,[ln]:ln},l=new en({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new oe},radius:{value:4}},vertexShader:RS,fragmentShader:vS}),u=l.clone();u.defines.HORIZONTAL_PASS=1;const E=new gt;E.setAttribute("position",new dn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const m=new Mt(E,l),S=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ul;let f=this.type;this.render=function(y,N,w){if(S.enabled===!1||S.autoUpdate===!1&&S.needsUpdate===!1||y.length===0)return;const I=i.getRenderTarget(),_=i.getActiveCubeFace(),P=i.getActiveMipmapLevel(),G=i.state;G.setBlending(bn),G.buffers.depth.getReversed()===!0?G.buffers.color.setClear(0,0,0,0):G.buffers.color.setClear(1,1,1,1),G.buffers.depth.setTest(!0),G.setScissorTest(!1);const Z=f!==In&&this.type===In,j=f===In&&this.type!==In;for(let $=0,ie=y.length;$<ie;$++){const Q=y[$],B=Q.shadow;if(B===void 0){Ke("WebGLShadowMap:",Q,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;r.copy(B.mapSize);const pe=B.getFrameExtents();if(r.multiply(pe),s.copy(B.mapSize),(r.x>p||r.y>p)&&(r.x>p&&(s.x=Math.floor(p/pe.x),r.x=s.x*pe.x,B.mapSize.x=s.x),r.y>p&&(s.y=Math.floor(p/pe.y),r.y=s.y*pe.y,B.mapSize.y=s.y)),B.map===null||Z===!0||j===!0){const _e=this.type!==In?{minFilter:Yt,magFilter:Yt}:{};B.map!==null&&B.map.dispose(),B.map=new Zn(r.x,r.y,_e),B.map.texture.name=Q.name+".shadowMap",B.camera.updateProjectionMatrix()}i.setRenderTarget(B.map),i.clear();const le=B.getViewportCount();for(let _e=0;_e<le;_e++){const Ue=B.getViewport(_e);o.set(s.x*Ue.x,s.y*Ue.y,s.x*Ue.z,s.y*Ue.w),G.viewport(o),B.updateMatrices(Q,_e),n=B.getFrustum(),R(N,w,B.camera,Q,this.type)}B.isPointLightShadow!==!0&&this.type===In&&v(B,w),B.needsUpdate=!1}f=this.type,S.needsUpdate=!1,i.setRenderTarget(I,_,P)};function v(y,N){const w=e.update(m);l.defines.VSM_SAMPLES!==y.blurSamples&&(l.defines.VSM_SAMPLES=y.blurSamples,u.defines.VSM_SAMPLES=y.blurSamples,l.needsUpdate=!0,u.needsUpdate=!0),y.mapPass===null&&(y.mapPass=new Zn(r.x,r.y)),l.uniforms.shadow_pass.value=y.map.texture,l.uniforms.resolution.value=y.mapSize,l.uniforms.radius.value=y.radius,i.setRenderTarget(y.mapPass),i.clear(),i.renderBufferDirect(N,null,w,l,m,null),u.uniforms.shadow_pass.value=y.mapPass.texture,u.uniforms.resolution.value=y.mapSize,u.uniforms.radius.value=y.radius,i.setRenderTarget(y.map),i.clear(),i.renderBufferDirect(N,null,w,u,m,null)}function A(y,N,w,I){let _=null;const P=w.isPointLight===!0?y.customDistanceMaterial:y.customDepthMaterial;if(P!==void 0)_=P;else if(_=w.isPointLight===!0?d:c,i.localClippingEnabled&&N.clipShadows===!0&&Array.isArray(N.clippingPlanes)&&N.clippingPlanes.length!==0||N.displacementMap&&N.displacementScale!==0||N.alphaMap&&N.alphaTest>0||N.map&&N.alphaTest>0||N.alphaToCoverage===!0){const G=_.uuid,Z=N.uuid;let j=h[G];j===void 0&&(j={},h[G]=j);let $=j[Z];$===void 0&&($=_.clone(),j[Z]=$,N.addEventListener("dispose",C)),_=$}if(_.visible=N.visible,_.wireframe=N.wireframe,I===In?_.side=N.shadowSide!==null?N.shadowSide:N.side:_.side=N.shadowSide!==null?N.shadowSide:a[N.side],_.alphaMap=N.alphaMap,_.alphaTest=N.alphaToCoverage===!0?.5:N.alphaTest,_.map=N.map,_.clipShadows=N.clipShadows,_.clippingPlanes=N.clippingPlanes,_.clipIntersection=N.clipIntersection,_.displacementMap=N.displacementMap,_.displacementScale=N.displacementScale,_.displacementBias=N.displacementBias,_.wireframeLinewidth=N.wireframeLinewidth,_.linewidth=N.linewidth,w.isPointLight===!0&&_.isMeshDistanceMaterial===!0){const G=i.properties.get(_);G.light=w}return _}function R(y,N,w,I,_){if(y.visible===!1)return;if(y.layers.test(N.layers)&&(y.isMesh||y.isLine||y.isPoints)&&(y.castShadow||y.receiveShadow&&_===In)&&(!y.frustumCulled||n.intersectsObject(y))){y.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,y.matrixWorld);const Z=e.update(y),j=y.material;if(Array.isArray(j)){const $=Z.groups;for(let ie=0,Q=$.length;ie<Q;ie++){const B=$[ie],pe=j[B.materialIndex];if(pe&&pe.visible){const le=A(y,pe,I,_);y.onBeforeShadow(i,y,N,w,Z,le,B),i.renderBufferDirect(w,null,Z,le,y,B),y.onAfterShadow(i,y,N,w,Z,le,B)}}}else if(j.visible){const $=A(y,j,I,_);y.onBeforeShadow(i,y,N,w,Z,$,null),i.renderBufferDirect(w,null,Z,$,y,null),y.onAfterShadow(i,y,N,w,Z,$,null)}}const G=y.children;for(let Z=0,j=G.length;Z<j;Z++)R(G[Z],N,w,I,_)}function C(y){y.target.removeEventListener("dispose",C);for(const w in h){const I=h[w],_=y.target.uuid;_ in I&&(I[_].dispose(),delete I[_])}}}const IS={[Zs]:Js,[js]:ea,[Qs]:ta,[Di]:$s,[Js]:Zs,[ea]:js,[ta]:Qs,[$s]:Di};function LS(i,e){function t(){let F=!1;const Ie=new St;let Re=null;const ve=new St(0,0,0,0);return{setMask:function(Se){Re!==Se&&!F&&(i.colorMask(Se,Se,Se,Se),Re=Se)},setLocked:function(Se){F=Se},setClear:function(Se,de,De,Xe,ot){ot===!0&&(Se*=Xe,de*=Xe,De*=Xe),Ie.set(Se,de,De,Xe),ve.equals(Ie)===!1&&(i.clearColor(Se,de,De,Xe),ve.copy(Ie))},reset:function(){F=!1,Re=null,ve.set(-1,0,0,0)}}}function n(){let F=!1,Ie=!1,Re=null,ve=null,Se=null;return{setReversed:function(de){if(Ie!==de){const De=e.get("EXT_clip_control");de?De.clipControlEXT(De.LOWER_LEFT_EXT,De.ZERO_TO_ONE_EXT):De.clipControlEXT(De.LOWER_LEFT_EXT,De.NEGATIVE_ONE_TO_ONE_EXT),Ie=de;const Xe=Se;Se=null,this.setClear(Xe)}},getReversed:function(){return Ie},setTest:function(de){de?g(i.DEPTH_TEST):z(i.DEPTH_TEST)},setMask:function(de){Re!==de&&!F&&(i.depthMask(de),Re=de)},setFunc:function(de){if(Ie&&(de=IS[de]),ve!==de){switch(de){case Zs:i.depthFunc(i.NEVER);break;case Js:i.depthFunc(i.ALWAYS);break;case js:i.depthFunc(i.LESS);break;case Di:i.depthFunc(i.LEQUAL);break;case Qs:i.depthFunc(i.EQUAL);break;case $s:i.depthFunc(i.GEQUAL);break;case ea:i.depthFunc(i.GREATER);break;case ta:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ve=de}},setLocked:function(de){F=de},setClear:function(de){Se!==de&&(Ie&&(de=1-de),i.clearDepth(de),Se=de)},reset:function(){F=!1,Re=null,ve=null,Se=null,Ie=!1}}}function r(){let F=!1,Ie=null,Re=null,ve=null,Se=null,de=null,De=null,Xe=null,ot=null;return{setTest:function(nt){F||(nt?g(i.STENCIL_TEST):z(i.STENCIL_TEST))},setMask:function(nt){Ie!==nt&&!F&&(i.stencilMask(nt),Ie=nt)},setFunc:function(nt,fn,tn){(Re!==nt||ve!==fn||Se!==tn)&&(i.stencilFunc(nt,fn,tn),Re=nt,ve=fn,Se=tn)},setOp:function(nt,fn,tn){(de!==nt||De!==fn||Xe!==tn)&&(i.stencilOp(nt,fn,tn),de=nt,De=fn,Xe=tn)},setLocked:function(nt){F=nt},setClear:function(nt){ot!==nt&&(i.clearStencil(nt),ot=nt)},reset:function(){F=!1,Ie=null,Re=null,ve=null,Se=null,de=null,De=null,Xe=null,ot=null}}}const s=new t,o=new n,c=new r,d=new WeakMap,h=new WeakMap;let p={},a={},l=new WeakMap,u=[],E=null,m=!1,S=null,f=null,v=null,A=null,R=null,C=null,y=null,N=new tt(0,0,0),w=0,I=!1,_=null,P=null,G=null,Z=null,j=null;const $=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let ie=!1,Q=0;const B=i.getParameter(i.VERSION);B.indexOf("WebGL")!==-1?(Q=parseFloat(/^WebGL (\d)/.exec(B)[1]),ie=Q>=1):B.indexOf("OpenGL ES")!==-1&&(Q=parseFloat(/^OpenGL ES (\d)/.exec(B)[1]),ie=Q>=2);let pe=null,le={};const _e=i.getParameter(i.SCISSOR_BOX),Ue=i.getParameter(i.VIEWPORT),He=new St().fromArray(_e),X=new St().fromArray(Ue);function U(F,Ie,Re,ve){const Se=new Uint8Array(4),de=i.createTexture();i.bindTexture(F,de),i.texParameteri(F,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(F,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let De=0;De<Re;De++)F===i.TEXTURE_3D||F===i.TEXTURE_2D_ARRAY?i.texImage3D(Ie,0,i.RGBA,1,1,ve,0,i.RGBA,i.UNSIGNED_BYTE,Se):i.texImage2D(Ie+De,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Se);return de}const M={};M[i.TEXTURE_2D]=U(i.TEXTURE_2D,i.TEXTURE_2D,1),M[i.TEXTURE_CUBE_MAP]=U(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),M[i.TEXTURE_2D_ARRAY]=U(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),M[i.TEXTURE_3D]=U(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),c.setClear(0),g(i.DEPTH_TEST),o.setFunc(Di),q(!1),J(So),g(i.CULL_FACE),H(bn);function g(F){p[F]!==!0&&(i.enable(F),p[F]=!0)}function z(F){p[F]!==!1&&(i.disable(F),p[F]=!1)}function se(F,Ie){return a[F]!==Ie?(i.bindFramebuffer(F,Ie),a[F]=Ie,F===i.DRAW_FRAMEBUFFER&&(a[i.FRAMEBUFFER]=Ie),F===i.FRAMEBUFFER&&(a[i.DRAW_FRAMEBUFFER]=Ie),!0):!1}function k(F,Ie){let Re=u,ve=!1;if(F){Re=l.get(Ie),Re===void 0&&(Re=[],l.set(Ie,Re));const Se=F.textures;if(Re.length!==Se.length||Re[0]!==i.COLOR_ATTACHMENT0){for(let de=0,De=Se.length;de<De;de++)Re[de]=i.COLOR_ATTACHMENT0+de;Re.length=Se.length,ve=!0}}else Re[0]!==i.BACK&&(Re[0]=i.BACK,ve=!0);ve&&i.drawBuffers(Re)}function ue(F){return E!==F?(i.useProgram(F),E=F,!0):!1}const me={[si]:i.FUNC_ADD,[Kc]:i.FUNC_SUBTRACT,[Xc]:i.FUNC_REVERSE_SUBTRACT};me[qc]=i.MIN,me[Zc]=i.MAX;const he={[Jc]:i.ZERO,[jc]:i.ONE,[Qc]:i.SRC_COLOR,[Xs]:i.SRC_ALPHA,[ru]:i.SRC_ALPHA_SATURATE,[nu]:i.DST_COLOR,[eu]:i.DST_ALPHA,[$c]:i.ONE_MINUS_SRC_COLOR,[qs]:i.ONE_MINUS_SRC_ALPHA,[iu]:i.ONE_MINUS_DST_COLOR,[tu]:i.ONE_MINUS_DST_ALPHA,[su]:i.CONSTANT_COLOR,[au]:i.ONE_MINUS_CONSTANT_COLOR,[ou]:i.CONSTANT_ALPHA,[lu]:i.ONE_MINUS_CONSTANT_ALPHA};function H(F,Ie,Re,ve,Se,de,De,Xe,ot,nt){if(F===bn){m===!0&&(z(i.BLEND),m=!1);return}if(m===!1&&(g(i.BLEND),m=!0),F!==zc){if(F!==S||nt!==I){if((f!==si||R!==si)&&(i.blendEquation(i.FUNC_ADD),f=si,R=si),nt)switch(F){case Ci:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case mo:i.blendFunc(i.ONE,i.ONE);break;case Ao:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case xo:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:dt("WebGLState: Invalid blending: ",F);break}else switch(F){case Ci:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case mo:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Ao:dt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case xo:dt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:dt("WebGLState: Invalid blending: ",F);break}v=null,A=null,C=null,y=null,N.set(0,0,0),w=0,S=F,I=nt}return}Se=Se||Ie,de=de||Re,De=De||ve,(Ie!==f||Se!==R)&&(i.blendEquationSeparate(me[Ie],me[Se]),f=Ie,R=Se),(Re!==v||ve!==A||de!==C||De!==y)&&(i.blendFuncSeparate(he[Re],he[ve],he[de],he[De]),v=Re,A=ve,C=de,y=De),(Xe.equals(N)===!1||ot!==w)&&(i.blendColor(Xe.r,Xe.g,Xe.b,ot),N.copy(Xe),w=ot),S=F,I=!1}function T(F,Ie){F.side===ln?z(i.CULL_FACE):g(i.CULL_FACE);let Re=F.side===It;Ie&&(Re=!Re),q(Re),F.blending===Ci&&F.transparent===!1?H(bn):H(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.blendColor,F.blendAlpha,F.premultipliedAlpha),o.setFunc(F.depthFunc),o.setTest(F.depthTest),o.setMask(F.depthWrite),s.setMask(F.colorWrite);const ve=F.stencilWrite;c.setTest(ve),ve&&(c.setMask(F.stencilWriteMask),c.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),c.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),b(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?g(i.SAMPLE_ALPHA_TO_COVERAGE):z(i.SAMPLE_ALPHA_TO_COVERAGE)}function q(F){_!==F&&(F?i.frontFace(i.CW):i.frontFace(i.CCW),_=F)}function J(F){F!==kc?(g(i.CULL_FACE),F!==P&&(F===So?i.cullFace(i.BACK):F===Wc?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):z(i.CULL_FACE),P=F}function D(F){F!==G&&(ie&&i.lineWidth(F),G=F)}function b(F,Ie,Re){F?(g(i.POLYGON_OFFSET_FILL),(Z!==Ie||j!==Re)&&(i.polygonOffset(Ie,Re),Z=Ie,j=Re)):z(i.POLYGON_OFFSET_FILL)}function ae(F){F?g(i.SCISSOR_TEST):z(i.SCISSOR_TEST)}function ce(F){F===void 0&&(F=i.TEXTURE0+$-1),pe!==F&&(i.activeTexture(F),pe=F)}function Te(F,Ie,Re){Re===void 0&&(pe===null?Re=i.TEXTURE0+$-1:Re=pe);let ve=le[Re];ve===void 0&&(ve={type:void 0,texture:void 0},le[Re]=ve),(ve.type!==F||ve.texture!==Ie)&&(pe!==Re&&(i.activeTexture(Re),pe=Re),i.bindTexture(F,Ie||M[F]),ve.type=F,ve.texture=Ie)}function O(){const F=le[pe];F!==void 0&&F.type!==void 0&&(i.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function x(){try{i.compressedTexImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function W(){try{i.compressedTexImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function re(){try{i.texSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function fe(){try{i.texSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ne(){try{i.compressedTexSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Ne(){try{i.compressedTexSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ge(){try{i.texStorage2D(...arguments)}catch(F){F("WebGLState:",F)}}function we(){try{i.texStorage3D(...arguments)}catch(F){F("WebGLState:",F)}}function Ce(){try{i.texImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Ee(){try{i.texImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function Ae(F){He.equals(F)===!1&&(i.scissor(F.x,F.y,F.z,F.w),He.copy(F))}function ke(F){X.equals(F)===!1&&(i.viewport(F.x,F.y,F.z,F.w),X.copy(F))}function Ge(F,Ie){let Re=h.get(Ie);Re===void 0&&(Re=new WeakMap,h.set(Ie,Re));let ve=Re.get(F);ve===void 0&&(ve=i.getUniformBlockIndex(Ie,F.name),Re.set(F,ve))}function be(F,Ie){const ve=h.get(Ie).get(F);d.get(Ie)!==ve&&(i.uniformBlockBinding(Ie,ve,F.__bindingPointIndex),d.set(Ie,ve))}function ze(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),p={},pe=null,le={},a={},l=new WeakMap,u=[],E=null,m=!1,S=null,f=null,v=null,A=null,R=null,C=null,y=null,N=new tt(0,0,0),w=0,I=!1,_=null,P=null,G=null,Z=null,j=null,He.set(0,0,i.canvas.width,i.canvas.height),X.set(0,0,i.canvas.width,i.canvas.height),s.reset(),o.reset(),c.reset()}return{buffers:{color:s,depth:o,stencil:c},enable:g,disable:z,bindFramebuffer:se,drawBuffers:k,useProgram:ue,setBlending:H,setMaterial:T,setFlipSided:q,setCullFace:J,setLineWidth:D,setPolygonOffset:b,setScissorTest:ae,activeTexture:ce,bindTexture:Te,unbindTexture:O,compressedTexImage2D:x,compressedTexImage3D:W,texImage2D:Ce,texImage3D:Ee,updateUBOMapping:Ge,uniformBlockBinding:be,texStorage2D:ge,texStorage3D:we,texSubImage2D:re,texSubImage3D:fe,compressedTexSubImage2D:ne,compressedTexSubImage3D:Ne,scissor:Ae,viewport:ke,reset:ze}}function yS(i,e,t,n,r,s,o){const c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,d=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new oe,p=new WeakMap;let a;const l=new WeakMap;let u=!1;try{u=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(O,x){return u?new OffscreenCanvas(O,x):$r("canvas")}function m(O,x,W){let re=1;const fe=Te(O);if((fe.width>W||fe.height>W)&&(re=W/Math.max(fe.width,fe.height)),re<1)if(typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&O instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&O instanceof ImageBitmap||typeof VideoFrame<"u"&&O instanceof VideoFrame){const ne=Math.floor(re*fe.width),Ne=Math.floor(re*fe.height);a===void 0&&(a=E(ne,Ne));const ge=x?E(ne,Ne):a;return ge.width=ne,ge.height=Ne,ge.getContext("2d").drawImage(O,0,0,ne,Ne),Ke("WebGLRenderer: Texture has been resized from ("+fe.width+"x"+fe.height+") to ("+ne+"x"+Ne+")."),ge}else return"data"in O&&Ke("WebGLRenderer: Image in DataTexture is too big ("+fe.width+"x"+fe.height+")."),O;return O}function S(O){return O.generateMipmaps}function f(O){i.generateMipmap(O)}function v(O){return O.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:O.isWebGL3DRenderTarget?i.TEXTURE_3D:O.isWebGLArrayRenderTarget||O.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function A(O,x,W,re,fe=!1){if(O!==null){if(i[O]!==void 0)return i[O];Ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+O+"'")}let ne=x;if(x===i.RED&&(W===i.FLOAT&&(ne=i.R32F),W===i.HALF_FLOAT&&(ne=i.R16F),W===i.UNSIGNED_BYTE&&(ne=i.R8)),x===i.RED_INTEGER&&(W===i.UNSIGNED_BYTE&&(ne=i.R8UI),W===i.UNSIGNED_SHORT&&(ne=i.R16UI),W===i.UNSIGNED_INT&&(ne=i.R32UI),W===i.BYTE&&(ne=i.R8I),W===i.SHORT&&(ne=i.R16I),W===i.INT&&(ne=i.R32I)),x===i.RG&&(W===i.FLOAT&&(ne=i.RG32F),W===i.HALF_FLOAT&&(ne=i.RG16F),W===i.UNSIGNED_BYTE&&(ne=i.RG8)),x===i.RG_INTEGER&&(W===i.UNSIGNED_BYTE&&(ne=i.RG8UI),W===i.UNSIGNED_SHORT&&(ne=i.RG16UI),W===i.UNSIGNED_INT&&(ne=i.RG32UI),W===i.BYTE&&(ne=i.RG8I),W===i.SHORT&&(ne=i.RG16I),W===i.INT&&(ne=i.RG32I)),x===i.RGB_INTEGER&&(W===i.UNSIGNED_BYTE&&(ne=i.RGB8UI),W===i.UNSIGNED_SHORT&&(ne=i.RGB16UI),W===i.UNSIGNED_INT&&(ne=i.RGB32UI),W===i.BYTE&&(ne=i.RGB8I),W===i.SHORT&&(ne=i.RGB16I),W===i.INT&&(ne=i.RGB32I)),x===i.RGBA_INTEGER&&(W===i.UNSIGNED_BYTE&&(ne=i.RGBA8UI),W===i.UNSIGNED_SHORT&&(ne=i.RGBA16UI),W===i.UNSIGNED_INT&&(ne=i.RGBA32UI),W===i.BYTE&&(ne=i.RGBA8I),W===i.SHORT&&(ne=i.RGBA16I),W===i.INT&&(ne=i.RGBA32I)),x===i.RGB&&(W===i.UNSIGNED_INT_5_9_9_9_REV&&(ne=i.RGB9_E5),W===i.UNSIGNED_INT_10F_11F_11F_REV&&(ne=i.R11F_G11F_B10F)),x===i.RGBA){const Ne=fe?jr:$e.getTransfer(re);W===i.FLOAT&&(ne=i.RGBA32F),W===i.HALF_FLOAT&&(ne=i.RGBA16F),W===i.UNSIGNED_BYTE&&(ne=Ne===rt?i.SRGB8_ALPHA8:i.RGBA8),W===i.UNSIGNED_SHORT_4_4_4_4&&(ne=i.RGBA4),W===i.UNSIGNED_SHORT_5_5_5_1&&(ne=i.RGB5_A1)}return(ne===i.R16F||ne===i.R32F||ne===i.RG16F||ne===i.RG32F||ne===i.RGBA16F||ne===i.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function R(O,x){let W;return O?x===null||x===ci||x===ar?W=i.DEPTH24_STENCIL8:x===yn?W=i.DEPTH32F_STENCIL8:x===sr&&(W=i.DEPTH24_STENCIL8,Ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):x===null||x===ci||x===ar?W=i.DEPTH_COMPONENT24:x===yn?W=i.DEPTH_COMPONENT32F:x===sr&&(W=i.DEPTH_COMPONENT16),W}function C(O,x){return S(O)===!0||O.isFramebufferTexture&&O.minFilter!==Yt&&O.minFilter!==$t?Math.log2(Math.max(x.width,x.height))+1:O.mipmaps!==void 0&&O.mipmaps.length>0?O.mipmaps.length:O.isCompressedTexture&&Array.isArray(O.image)?x.mipmaps.length:1}function y(O){const x=O.target;x.removeEventListener("dispose",y),w(x),x.isVideoTexture&&p.delete(x)}function N(O){const x=O.target;x.removeEventListener("dispose",N),_(x)}function w(O){const x=n.get(O);if(x.__webglInit===void 0)return;const W=O.source,re=l.get(W);if(re){const fe=re[x.__cacheKey];fe.usedTimes--,fe.usedTimes===0&&I(O),Object.keys(re).length===0&&l.delete(W)}n.remove(O)}function I(O){const x=n.get(O);i.deleteTexture(x.__webglTexture);const W=O.source,re=l.get(W);delete re[x.__cacheKey],o.memory.textures--}function _(O){const x=n.get(O);if(O.depthTexture&&(O.depthTexture.dispose(),n.remove(O.depthTexture)),O.isWebGLCubeRenderTarget)for(let re=0;re<6;re++){if(Array.isArray(x.__webglFramebuffer[re]))for(let fe=0;fe<x.__webglFramebuffer[re].length;fe++)i.deleteFramebuffer(x.__webglFramebuffer[re][fe]);else i.deleteFramebuffer(x.__webglFramebuffer[re]);x.__webglDepthbuffer&&i.deleteRenderbuffer(x.__webglDepthbuffer[re])}else{if(Array.isArray(x.__webglFramebuffer))for(let re=0;re<x.__webglFramebuffer.length;re++)i.deleteFramebuffer(x.__webglFramebuffer[re]);else i.deleteFramebuffer(x.__webglFramebuffer);if(x.__webglDepthbuffer&&i.deleteRenderbuffer(x.__webglDepthbuffer),x.__webglMultisampledFramebuffer&&i.deleteFramebuffer(x.__webglMultisampledFramebuffer),x.__webglColorRenderbuffer)for(let re=0;re<x.__webglColorRenderbuffer.length;re++)x.__webglColorRenderbuffer[re]&&i.deleteRenderbuffer(x.__webglColorRenderbuffer[re]);x.__webglDepthRenderbuffer&&i.deleteRenderbuffer(x.__webglDepthRenderbuffer)}const W=O.textures;for(let re=0,fe=W.length;re<fe;re++){const ne=n.get(W[re]);ne.__webglTexture&&(i.deleteTexture(ne.__webglTexture),o.memory.textures--),n.remove(W[re])}n.remove(O)}let P=0;function G(){P=0}function Z(){const O=P;return O>=r.maxTextures&&Ke("WebGLTextures: Trying to use "+O+" texture units while this GPU supports only "+r.maxTextures),P+=1,O}function j(O){const x=[];return x.push(O.wrapS),x.push(O.wrapT),x.push(O.wrapR||0),x.push(O.magFilter),x.push(O.minFilter),x.push(O.anisotropy),x.push(O.internalFormat),x.push(O.format),x.push(O.type),x.push(O.generateMipmaps),x.push(O.premultiplyAlpha),x.push(O.flipY),x.push(O.unpackAlignment),x.push(O.colorSpace),x.join()}function $(O,x){const W=n.get(O);if(O.isVideoTexture&&ae(O),O.isRenderTargetTexture===!1&&O.isExternalTexture!==!0&&O.version>0&&W.__version!==O.version){const re=O.image;if(re===null)Ke("WebGLRenderer: Texture marked for update but no image data found.");else if(re.complete===!1)Ke("WebGLRenderer: Texture marked for update but image is incomplete");else{M(W,O,x);return}}else O.isExternalTexture&&(W.__webglTexture=O.sourceTexture?O.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,W.__webglTexture,i.TEXTURE0+x)}function ie(O,x){const W=n.get(O);if(O.isRenderTargetTexture===!1&&O.version>0&&W.__version!==O.version){M(W,O,x);return}else O.isExternalTexture&&(W.__webglTexture=O.sourceTexture?O.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,W.__webglTexture,i.TEXTURE0+x)}function Q(O,x){const W=n.get(O);if(O.isRenderTargetTexture===!1&&O.version>0&&W.__version!==O.version){M(W,O,x);return}t.bindTexture(i.TEXTURE_3D,W.__webglTexture,i.TEXTURE0+x)}function B(O,x){const W=n.get(O);if(O.version>0&&W.__version!==O.version){g(W,O,x);return}t.bindTexture(i.TEXTURE_CUBE_MAP,W.__webglTexture,i.TEXTURE0+x)}const pe={[ra]:i.REPEAT,[Ln]:i.CLAMP_TO_EDGE,[sa]:i.MIRRORED_REPEAT},le={[Yt]:i.NEAREST,[Au]:i.NEAREST_MIPMAP_NEAREST,[Ar]:i.NEAREST_MIPMAP_LINEAR,[$t]:i.LINEAR,[hs]:i.LINEAR_MIPMAP_NEAREST,[oi]:i.LINEAR_MIPMAP_LINEAR},_e={[Ru]:i.NEVER,[bu]:i.ALWAYS,[vu]:i.LESS,[zl]:i.LEQUAL,[Mu]:i.EQUAL,[yu]:i.GEQUAL,[Iu]:i.GREATER,[Lu]:i.NOTEQUAL};function Ue(O,x){if(x.type===yn&&e.has("OES_texture_float_linear")===!1&&(x.magFilter===$t||x.magFilter===hs||x.magFilter===Ar||x.magFilter===oi||x.minFilter===$t||x.minFilter===hs||x.minFilter===Ar||x.minFilter===oi)&&Ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(O,i.TEXTURE_WRAP_S,pe[x.wrapS]),i.texParameteri(O,i.TEXTURE_WRAP_T,pe[x.wrapT]),(O===i.TEXTURE_3D||O===i.TEXTURE_2D_ARRAY)&&i.texParameteri(O,i.TEXTURE_WRAP_R,pe[x.wrapR]),i.texParameteri(O,i.TEXTURE_MAG_FILTER,le[x.magFilter]),i.texParameteri(O,i.TEXTURE_MIN_FILTER,le[x.minFilter]),x.compareFunction&&(i.texParameteri(O,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(O,i.TEXTURE_COMPARE_FUNC,_e[x.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(x.magFilter===Yt||x.minFilter!==Ar&&x.minFilter!==oi||x.type===yn&&e.has("OES_texture_float_linear")===!1)return;if(x.anisotropy>1||n.get(x).__currentAnisotropy){const W=e.get("EXT_texture_filter_anisotropic");i.texParameterf(O,W.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(x.anisotropy,r.getMaxAnisotropy())),n.get(x).__currentAnisotropy=x.anisotropy}}}function He(O,x){let W=!1;O.__webglInit===void 0&&(O.__webglInit=!0,x.addEventListener("dispose",y));const re=x.source;let fe=l.get(re);fe===void 0&&(fe={},l.set(re,fe));const ne=j(x);if(ne!==O.__cacheKey){fe[ne]===void 0&&(fe[ne]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,W=!0),fe[ne].usedTimes++;const Ne=fe[O.__cacheKey];Ne!==void 0&&(fe[O.__cacheKey].usedTimes--,Ne.usedTimes===0&&I(x)),O.__cacheKey=ne,O.__webglTexture=fe[ne].texture}return W}function X(O,x,W){return Math.floor(Math.floor(O/W)/x)}function U(O,x,W,re){const ne=O.updateRanges;if(ne.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,x.width,x.height,W,re,x.data);else{ne.sort((Ee,Ae)=>Ee.start-Ae.start);let Ne=0;for(let Ee=1;Ee<ne.length;Ee++){const Ae=ne[Ne],ke=ne[Ee],Ge=Ae.start+Ae.count,be=X(ke.start,x.width,4),ze=X(Ae.start,x.width,4);ke.start<=Ge+1&&be===ze&&X(ke.start+ke.count-1,x.width,4)===be?Ae.count=Math.max(Ae.count,ke.start+ke.count-Ae.start):(++Ne,ne[Ne]=ke)}ne.length=Ne+1;const ge=i.getParameter(i.UNPACK_ROW_LENGTH),we=i.getParameter(i.UNPACK_SKIP_PIXELS),Ce=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,x.width);for(let Ee=0,Ae=ne.length;Ee<Ae;Ee++){const ke=ne[Ee],Ge=Math.floor(ke.start/4),be=Math.ceil(ke.count/4),ze=Ge%x.width,F=Math.floor(Ge/x.width),Ie=be,Re=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,ze),i.pixelStorei(i.UNPACK_SKIP_ROWS,F),t.texSubImage2D(i.TEXTURE_2D,0,ze,F,Ie,Re,W,re,x.data)}O.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,ge),i.pixelStorei(i.UNPACK_SKIP_PIXELS,we),i.pixelStorei(i.UNPACK_SKIP_ROWS,Ce)}}function M(O,x,W){let re=i.TEXTURE_2D;(x.isDataArrayTexture||x.isCompressedArrayTexture)&&(re=i.TEXTURE_2D_ARRAY),x.isData3DTexture&&(re=i.TEXTURE_3D);const fe=He(O,x),ne=x.source;t.bindTexture(re,O.__webglTexture,i.TEXTURE0+W);const Ne=n.get(ne);if(ne.version!==Ne.__version||fe===!0){t.activeTexture(i.TEXTURE0+W);const ge=$e.getPrimaries($e.workingColorSpace),we=x.colorSpace===Wn?null:$e.getPrimaries(x.colorSpace),Ce=x.colorSpace===Wn||ge===we?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,x.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,x.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ce);let Ee=m(x.image,!1,r.maxTextureSize);Ee=ce(x,Ee);const Ae=s.convert(x.format,x.colorSpace),ke=s.convert(x.type);let Ge=A(x.internalFormat,Ae,ke,x.colorSpace,x.isVideoTexture);Ue(re,x);let be;const ze=x.mipmaps,F=x.isVideoTexture!==!0,Ie=Ne.__version===void 0||fe===!0,Re=ne.dataReady,ve=C(x,Ee);if(x.isDepthTexture)Ge=R(x.format===lr,x.type),Ie&&(F?t.texStorage2D(i.TEXTURE_2D,1,Ge,Ee.width,Ee.height):t.texImage2D(i.TEXTURE_2D,0,Ge,Ee.width,Ee.height,0,Ae,ke,null));else if(x.isDataTexture)if(ze.length>0){F&&Ie&&t.texStorage2D(i.TEXTURE_2D,ve,Ge,ze[0].width,ze[0].height);for(let Se=0,de=ze.length;Se<de;Se++)be=ze[Se],F?Re&&t.texSubImage2D(i.TEXTURE_2D,Se,0,0,be.width,be.height,Ae,ke,be.data):t.texImage2D(i.TEXTURE_2D,Se,Ge,be.width,be.height,0,Ae,ke,be.data);x.generateMipmaps=!1}else F?(Ie&&t.texStorage2D(i.TEXTURE_2D,ve,Ge,Ee.width,Ee.height),Re&&U(x,Ee,Ae,ke)):t.texImage2D(i.TEXTURE_2D,0,Ge,Ee.width,Ee.height,0,Ae,ke,Ee.data);else if(x.isCompressedTexture)if(x.isCompressedArrayTexture){F&&Ie&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ve,Ge,ze[0].width,ze[0].height,Ee.depth);for(let Se=0,de=ze.length;Se<de;Se++)if(be=ze[Se],x.format!==un)if(Ae!==null)if(F){if(Re)if(x.layerUpdates.size>0){const De=jo(be.width,be.height,x.format,x.type);for(const Xe of x.layerUpdates){const ot=be.data.subarray(Xe*De/be.data.BYTES_PER_ELEMENT,(Xe+1)*De/be.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Se,0,0,Xe,be.width,be.height,1,Ae,ot)}x.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,Se,0,0,0,be.width,be.height,Ee.depth,Ae,be.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,Se,Ge,be.width,be.height,Ee.depth,0,be.data,0,0);else Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else F?Re&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,Se,0,0,0,be.width,be.height,Ee.depth,Ae,ke,be.data):t.texImage3D(i.TEXTURE_2D_ARRAY,Se,Ge,be.width,be.height,Ee.depth,0,Ae,ke,be.data)}else{F&&Ie&&t.texStorage2D(i.TEXTURE_2D,ve,Ge,ze[0].width,ze[0].height);for(let Se=0,de=ze.length;Se<de;Se++)be=ze[Se],x.format!==un?Ae!==null?F?Re&&t.compressedTexSubImage2D(i.TEXTURE_2D,Se,0,0,be.width,be.height,Ae,be.data):t.compressedTexImage2D(i.TEXTURE_2D,Se,Ge,be.width,be.height,0,be.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):F?Re&&t.texSubImage2D(i.TEXTURE_2D,Se,0,0,be.width,be.height,Ae,ke,be.data):t.texImage2D(i.TEXTURE_2D,Se,Ge,be.width,be.height,0,Ae,ke,be.data)}else if(x.isDataArrayTexture)if(F){if(Ie&&t.texStorage3D(i.TEXTURE_2D_ARRAY,ve,Ge,Ee.width,Ee.height,Ee.depth),Re)if(x.layerUpdates.size>0){const Se=jo(Ee.width,Ee.height,x.format,x.type);for(const de of x.layerUpdates){const De=Ee.data.subarray(de*Se/Ee.data.BYTES_PER_ELEMENT,(de+1)*Se/Ee.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,de,Ee.width,Ee.height,1,Ae,ke,De)}x.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,Ee.width,Ee.height,Ee.depth,Ae,ke,Ee.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Ge,Ee.width,Ee.height,Ee.depth,0,Ae,ke,Ee.data);else if(x.isData3DTexture)F?(Ie&&t.texStorage3D(i.TEXTURE_3D,ve,Ge,Ee.width,Ee.height,Ee.depth),Re&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,Ee.width,Ee.height,Ee.depth,Ae,ke,Ee.data)):t.texImage3D(i.TEXTURE_3D,0,Ge,Ee.width,Ee.height,Ee.depth,0,Ae,ke,Ee.data);else if(x.isFramebufferTexture){if(Ie)if(F)t.texStorage2D(i.TEXTURE_2D,ve,Ge,Ee.width,Ee.height);else{let Se=Ee.width,de=Ee.height;for(let De=0;De<ve;De++)t.texImage2D(i.TEXTURE_2D,De,Ge,Se,de,0,Ae,ke,null),Se>>=1,de>>=1}}else if(ze.length>0){if(F&&Ie){const Se=Te(ze[0]);t.texStorage2D(i.TEXTURE_2D,ve,Ge,Se.width,Se.height)}for(let Se=0,de=ze.length;Se<de;Se++)be=ze[Se],F?Re&&t.texSubImage2D(i.TEXTURE_2D,Se,0,0,Ae,ke,be):t.texImage2D(i.TEXTURE_2D,Se,Ge,Ae,ke,be);x.generateMipmaps=!1}else if(F){if(Ie){const Se=Te(Ee);t.texStorage2D(i.TEXTURE_2D,ve,Ge,Se.width,Se.height)}Re&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Ae,ke,Ee)}else t.texImage2D(i.TEXTURE_2D,0,Ge,Ae,ke,Ee);S(x)&&f(re),Ne.__version=ne.version,x.onUpdate&&x.onUpdate(x)}O.__version=x.version}function g(O,x,W){if(x.image.length!==6)return;const re=He(O,x),fe=x.source;t.bindTexture(i.TEXTURE_CUBE_MAP,O.__webglTexture,i.TEXTURE0+W);const ne=n.get(fe);if(fe.version!==ne.__version||re===!0){t.activeTexture(i.TEXTURE0+W);const Ne=$e.getPrimaries($e.workingColorSpace),ge=x.colorSpace===Wn?null:$e.getPrimaries(x.colorSpace),we=x.colorSpace===Wn||Ne===ge?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,x.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,x.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,we);const Ce=x.isCompressedTexture||x.image[0].isCompressedTexture,Ee=x.image[0]&&x.image[0].isDataTexture,Ae=[];for(let de=0;de<6;de++)!Ce&&!Ee?Ae[de]=m(x.image[de],!0,r.maxCubemapSize):Ae[de]=Ee?x.image[de].image:x.image[de],Ae[de]=ce(x,Ae[de]);const ke=Ae[0],Ge=s.convert(x.format,x.colorSpace),be=s.convert(x.type),ze=A(x.internalFormat,Ge,be,x.colorSpace),F=x.isVideoTexture!==!0,Ie=ne.__version===void 0||re===!0,Re=fe.dataReady;let ve=C(x,ke);Ue(i.TEXTURE_CUBE_MAP,x);let Se;if(Ce){F&&Ie&&t.texStorage2D(i.TEXTURE_CUBE_MAP,ve,ze,ke.width,ke.height);for(let de=0;de<6;de++){Se=Ae[de].mipmaps;for(let De=0;De<Se.length;De++){const Xe=Se[De];x.format!==un?Ge!==null?F?Re&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De,0,0,Xe.width,Xe.height,Ge,Xe.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De,ze,Xe.width,Xe.height,0,Xe.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):F?Re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De,0,0,Xe.width,Xe.height,Ge,be,Xe.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De,ze,Xe.width,Xe.height,0,Ge,be,Xe.data)}}}else{if(Se=x.mipmaps,F&&Ie){Se.length>0&&ve++;const de=Te(Ae[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,ve,ze,de.width,de.height)}for(let de=0;de<6;de++)if(Ee){F?Re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0,0,0,Ae[de].width,Ae[de].height,Ge,be,Ae[de].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0,ze,Ae[de].width,Ae[de].height,0,Ge,be,Ae[de].data);for(let De=0;De<Se.length;De++){const ot=Se[De].image[de].image;F?Re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De+1,0,0,ot.width,ot.height,Ge,be,ot.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De+1,ze,ot.width,ot.height,0,Ge,be,ot.data)}}else{F?Re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0,0,0,Ge,be,Ae[de]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,0,ze,Ge,be,Ae[de]);for(let De=0;De<Se.length;De++){const Xe=Se[De];F?Re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De+1,0,0,Ge,be,Xe.image[de]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+de,De+1,ze,Ge,be,Xe.image[de])}}}S(x)&&f(i.TEXTURE_CUBE_MAP),ne.__version=fe.version,x.onUpdate&&x.onUpdate(x)}O.__version=x.version}function z(O,x,W,re,fe,ne){const Ne=s.convert(W.format,W.colorSpace),ge=s.convert(W.type),we=A(W.internalFormat,Ne,ge,W.colorSpace),Ce=n.get(x),Ee=n.get(W);if(Ee.__renderTarget=x,!Ce.__hasExternalTextures){const Ae=Math.max(1,x.width>>ne),ke=Math.max(1,x.height>>ne);fe===i.TEXTURE_3D||fe===i.TEXTURE_2D_ARRAY?t.texImage3D(fe,ne,we,Ae,ke,x.depth,0,Ne,ge,null):t.texImage2D(fe,ne,we,Ae,ke,0,Ne,ge,null)}t.bindFramebuffer(i.FRAMEBUFFER,O),b(x)?c.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,re,fe,Ee.__webglTexture,0,D(x)):(fe===i.TEXTURE_2D||fe>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&fe<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,re,fe,Ee.__webglTexture,ne),t.bindFramebuffer(i.FRAMEBUFFER,null)}function se(O,x,W){if(i.bindRenderbuffer(i.RENDERBUFFER,O),x.depthBuffer){const re=x.depthTexture,fe=re&&re.isDepthTexture?re.type:null,ne=R(x.stencilBuffer,fe),Ne=x.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ge=D(x);b(x)?c.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ge,ne,x.width,x.height):W?i.renderbufferStorageMultisample(i.RENDERBUFFER,ge,ne,x.width,x.height):i.renderbufferStorage(i.RENDERBUFFER,ne,x.width,x.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ne,i.RENDERBUFFER,O)}else{const re=x.textures;for(let fe=0;fe<re.length;fe++){const ne=re[fe],Ne=s.convert(ne.format,ne.colorSpace),ge=s.convert(ne.type),we=A(ne.internalFormat,Ne,ge,ne.colorSpace),Ce=D(x);W&&b(x)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ce,we,x.width,x.height):b(x)?c.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ce,we,x.width,x.height):i.renderbufferStorage(i.RENDERBUFFER,we,x.width,x.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function k(O,x){if(x&&x.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,O),!(x.depthTexture&&x.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const re=n.get(x.depthTexture);re.__renderTarget=x,(!re.__webglTexture||x.depthTexture.image.width!==x.width||x.depthTexture.image.height!==x.height)&&(x.depthTexture.image.width=x.width,x.depthTexture.image.height=x.height,x.depthTexture.needsUpdate=!0),$(x.depthTexture,0);const fe=re.__webglTexture,ne=D(x);if(x.depthTexture.format===or)b(x)?c.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,fe,0,ne):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,fe,0);else if(x.depthTexture.format===lr)b(x)?c.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,fe,0,ne):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,fe,0);else throw new Error("Unknown depthTexture format")}function ue(O){const x=n.get(O),W=O.isWebGLCubeRenderTarget===!0;if(x.__boundDepthTexture!==O.depthTexture){const re=O.depthTexture;if(x.__depthDisposeCallback&&x.__depthDisposeCallback(),re){const fe=()=>{delete x.__boundDepthTexture,delete x.__depthDisposeCallback,re.removeEventListener("dispose",fe)};re.addEventListener("dispose",fe),x.__depthDisposeCallback=fe}x.__boundDepthTexture=re}if(O.depthTexture&&!x.__autoAllocateDepthBuffer){if(W)throw new Error("target.depthTexture not supported in Cube render targets");const re=O.texture.mipmaps;re&&re.length>0?k(x.__webglFramebuffer[0],O):k(x.__webglFramebuffer,O)}else if(W){x.__webglDepthbuffer=[];for(let re=0;re<6;re++)if(t.bindFramebuffer(i.FRAMEBUFFER,x.__webglFramebuffer[re]),x.__webglDepthbuffer[re]===void 0)x.__webglDepthbuffer[re]=i.createRenderbuffer(),se(x.__webglDepthbuffer[re],O,!1);else{const fe=O.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer[re];i.bindRenderbuffer(i.RENDERBUFFER,ne),i.framebufferRenderbuffer(i.FRAMEBUFFER,fe,i.RENDERBUFFER,ne)}}else{const re=O.texture.mipmaps;if(re&&re.length>0?t.bindFramebuffer(i.FRAMEBUFFER,x.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,x.__webglFramebuffer),x.__webglDepthbuffer===void 0)x.__webglDepthbuffer=i.createRenderbuffer(),se(x.__webglDepthbuffer,O,!1);else{const fe=O.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,ne),i.framebufferRenderbuffer(i.FRAMEBUFFER,fe,i.RENDERBUFFER,ne)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function me(O,x,W){const re=n.get(O);x!==void 0&&z(re.__webglFramebuffer,O,O.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),W!==void 0&&ue(O)}function he(O){const x=O.texture,W=n.get(O),re=n.get(x);O.addEventListener("dispose",N);const fe=O.textures,ne=O.isWebGLCubeRenderTarget===!0,Ne=fe.length>1;if(Ne||(re.__webglTexture===void 0&&(re.__webglTexture=i.createTexture()),re.__version=x.version,o.memory.textures++),ne){W.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(x.mipmaps&&x.mipmaps.length>0){W.__webglFramebuffer[ge]=[];for(let we=0;we<x.mipmaps.length;we++)W.__webglFramebuffer[ge][we]=i.createFramebuffer()}else W.__webglFramebuffer[ge]=i.createFramebuffer()}else{if(x.mipmaps&&x.mipmaps.length>0){W.__webglFramebuffer=[];for(let ge=0;ge<x.mipmaps.length;ge++)W.__webglFramebuffer[ge]=i.createFramebuffer()}else W.__webglFramebuffer=i.createFramebuffer();if(Ne)for(let ge=0,we=fe.length;ge<we;ge++){const Ce=n.get(fe[ge]);Ce.__webglTexture===void 0&&(Ce.__webglTexture=i.createTexture(),o.memory.textures++)}if(O.samples>0&&b(O)===!1){W.__webglMultisampledFramebuffer=i.createFramebuffer(),W.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,W.__webglMultisampledFramebuffer);for(let ge=0;ge<fe.length;ge++){const we=fe[ge];W.__webglColorRenderbuffer[ge]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,W.__webglColorRenderbuffer[ge]);const Ce=s.convert(we.format,we.colorSpace),Ee=s.convert(we.type),Ae=A(we.internalFormat,Ce,Ee,we.colorSpace,O.isXRRenderTarget===!0),ke=D(O);i.renderbufferStorageMultisample(i.RENDERBUFFER,ke,Ae,O.width,O.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,W.__webglColorRenderbuffer[ge])}i.bindRenderbuffer(i.RENDERBUFFER,null),O.depthBuffer&&(W.__webglDepthRenderbuffer=i.createRenderbuffer(),se(W.__webglDepthRenderbuffer,O,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ne){t.bindTexture(i.TEXTURE_CUBE_MAP,re.__webglTexture),Ue(i.TEXTURE_CUBE_MAP,x);for(let ge=0;ge<6;ge++)if(x.mipmaps&&x.mipmaps.length>0)for(let we=0;we<x.mipmaps.length;we++)z(W.__webglFramebuffer[ge][we],O,x,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,we);else z(W.__webglFramebuffer[ge],O,x,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);S(x)&&f(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ne){for(let ge=0,we=fe.length;ge<we;ge++){const Ce=fe[ge],Ee=n.get(Ce);let Ae=i.TEXTURE_2D;(O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(Ae=O.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Ae,Ee.__webglTexture),Ue(Ae,Ce),z(W.__webglFramebuffer,O,Ce,i.COLOR_ATTACHMENT0+ge,Ae,0),S(Ce)&&f(Ae)}t.unbindTexture()}else{let ge=i.TEXTURE_2D;if((O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(ge=O.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(ge,re.__webglTexture),Ue(ge,x),x.mipmaps&&x.mipmaps.length>0)for(let we=0;we<x.mipmaps.length;we++)z(W.__webglFramebuffer[we],O,x,i.COLOR_ATTACHMENT0,ge,we);else z(W.__webglFramebuffer,O,x,i.COLOR_ATTACHMENT0,ge,0);S(x)&&f(ge),t.unbindTexture()}O.depthBuffer&&ue(O)}function H(O){const x=O.textures;for(let W=0,re=x.length;W<re;W++){const fe=x[W];if(S(fe)){const ne=v(O),Ne=n.get(fe).__webglTexture;t.bindTexture(ne,Ne),f(ne),t.unbindTexture()}}}const T=[],q=[];function J(O){if(O.samples>0){if(b(O)===!1){const x=O.textures,W=O.width,re=O.height;let fe=i.COLOR_BUFFER_BIT;const ne=O.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ne=n.get(O),ge=x.length>1;if(ge)for(let Ce=0;Ce<x.length;Ce++)t.bindFramebuffer(i.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ce,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,Ne.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ce,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer);const we=O.texture.mipmaps;we&&we.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer);for(let Ce=0;Ce<x.length;Ce++){if(O.resolveDepthBuffer&&(O.depthBuffer&&(fe|=i.DEPTH_BUFFER_BIT),O.stencilBuffer&&O.resolveStencilBuffer&&(fe|=i.STENCIL_BUFFER_BIT)),ge){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ne.__webglColorRenderbuffer[Ce]);const Ee=n.get(x[Ce]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,Ee,0)}i.blitFramebuffer(0,0,W,re,0,0,W,re,fe,i.NEAREST),d===!0&&(T.length=0,q.length=0,T.push(i.COLOR_ATTACHMENT0+Ce),O.depthBuffer&&O.resolveDepthBuffer===!1&&(T.push(ne),q.push(ne),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,q)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,T))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ge)for(let Ce=0;Ce<x.length;Ce++){t.bindFramebuffer(i.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ce,i.RENDERBUFFER,Ne.__webglColorRenderbuffer[Ce]);const Ee=n.get(x[Ce]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,Ne.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ce,i.TEXTURE_2D,Ee,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer)}else if(O.depthBuffer&&O.resolveDepthBuffer===!1&&d){const x=O.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[x])}}}function D(O){return Math.min(r.maxSamples,O.samples)}function b(O){const x=n.get(O);return O.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&x.__useRenderToTexture!==!1}function ae(O){const x=o.render.frame;p.get(O)!==x&&(p.set(O,x),O.update())}function ce(O,x){const W=O.colorSpace,re=O.format,fe=O.type;return O.isCompressedTexture===!0||O.isVideoTexture===!0||W!==wi&&W!==Wn&&($e.getTransfer(W)===rt?(re!==un||fe!==Cn)&&Ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):dt("WebGLTextures: Unsupported texture color space:",W)),x}function Te(O){return typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement?(h.width=O.naturalWidth||O.width,h.height=O.naturalHeight||O.height):typeof VideoFrame<"u"&&O instanceof VideoFrame?(h.width=O.displayWidth,h.height=O.displayHeight):(h.width=O.width,h.height=O.height),h}this.allocateTextureUnit=Z,this.resetTextureUnits=G,this.setTexture2D=$,this.setTexture2DArray=ie,this.setTexture3D=Q,this.setTextureCube=B,this.rebindTextures=me,this.setupRenderTarget=he,this.updateRenderTargetMipmap=H,this.updateMultisampleRenderTarget=J,this.setupDepthRenderbuffer=ue,this.setupFrameBufferTexture=z,this.useMultisampledRTT=b}function bS(i,e){function t(n,r=Wn){let s;const o=$e.getTransfer(r);if(n===Cn)return i.UNSIGNED_BYTE;if(n===Wa)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Ya)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Gl)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Vl)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Bl)return i.BYTE;if(n===Hl)return i.SHORT;if(n===sr)return i.UNSIGNED_SHORT;if(n===ka)return i.INT;if(n===ci)return i.UNSIGNED_INT;if(n===yn)return i.FLOAT;if(n===Hi)return i.HALF_FLOAT;if(n===kl)return i.ALPHA;if(n===Wl)return i.RGB;if(n===un)return i.RGBA;if(n===or)return i.DEPTH_COMPONENT;if(n===lr)return i.DEPTH_STENCIL;if(n===Yl)return i.RED;if(n===za)return i.RED_INTEGER;if(n===Ka)return i.RG;if(n===Xa)return i.RG_INTEGER;if(n===qa)return i.RGBA_INTEGER;if(n===Yr||n===zr||n===Kr||n===Xr)if(o===rt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Yr)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===zr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Kr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Xr)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Yr)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===zr)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Kr)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Xr)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===aa||n===oa||n===la||n===ca)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===aa)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===oa)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===la)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===ca)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===ua||n===ha||n===da)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===ua||n===ha)return o===rt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===da)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===fa||n===pa||n===Ea||n===Sa||n===ma||n===Aa||n===xa||n===_a||n===ga||n===Ta||n===Ra||n===va||n===Ma||n===Ia)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===fa)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===pa)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Ea)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Sa)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===ma)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Aa)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===xa)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===_a)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===ga)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ta)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ra)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===va)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ma)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Ia)return o===rt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===La||n===ya||n===ba)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===La)return o===rt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===ya)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===ba)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Oa||n===Ca||n===Na||n===Da)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===Oa)return s.COMPRESSED_RED_RGTC1_EXT;if(n===Ca)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Na)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Da)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===ar?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const OS=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,CS=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class NS{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new nc(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new en({vertexShader:OS,fragmentShader:CS,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Mt(new as(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class DS extends hi{constructor(e,t){super();const n=this;let r=null,s=1,o=null,c="local-floor",d=1,h=null,p=null,a=null,l=null,u=null,E=null;const m=typeof XRWebGLBinding<"u",S=new NS,f={},v=t.getContextAttributes();let A=null,R=null;const C=[],y=[],N=new oe;let w=null;const I=new jt;I.viewport=new St;const _=new jt;_.viewport=new St;const P=[I,_],G=new Zh;let Z=null,j=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(M){let g=C[M];return g===void 0&&(g=new Ds,C[M]=g),g.getTargetRaySpace()},this.getControllerGrip=function(M){let g=C[M];return g===void 0&&(g=new Ds,C[M]=g),g.getGripSpace()},this.getHand=function(M){let g=C[M];return g===void 0&&(g=new Ds,C[M]=g),g.getHandSpace()};function $(M){const g=y.indexOf(M.inputSource);if(g===-1)return;const z=C[g];z!==void 0&&(z.update(M.inputSource,M.frame,h||o),z.dispatchEvent({type:M.type,data:M.inputSource}))}function ie(){r.removeEventListener("select",$),r.removeEventListener("selectstart",$),r.removeEventListener("selectend",$),r.removeEventListener("squeeze",$),r.removeEventListener("squeezestart",$),r.removeEventListener("squeezeend",$),r.removeEventListener("end",ie),r.removeEventListener("inputsourceschange",Q);for(let M=0;M<C.length;M++){const g=y[M];g!==null&&(y[M]=null,C[M].disconnect(g))}Z=null,j=null,S.reset();for(const M in f)delete f[M];e.setRenderTarget(A),u=null,l=null,a=null,r=null,R=null,U.stop(),n.isPresenting=!1,e.setPixelRatio(w),e.setSize(N.width,N.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(M){s=M,n.isPresenting===!0&&Ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(M){c=M,n.isPresenting===!0&&Ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||o},this.setReferenceSpace=function(M){h=M},this.getBaseLayer=function(){return l!==null?l:u},this.getBinding=function(){return a===null&&m&&(a=new XRWebGLBinding(r,t)),a},this.getFrame=function(){return E},this.getSession=function(){return r},this.setSession=async function(M){if(r=M,r!==null){if(A=e.getRenderTarget(),r.addEventListener("select",$),r.addEventListener("selectstart",$),r.addEventListener("selectend",$),r.addEventListener("squeeze",$),r.addEventListener("squeezestart",$),r.addEventListener("squeezeend",$),r.addEventListener("end",ie),r.addEventListener("inputsourceschange",Q),v.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(N),m&&"createProjectionLayer"in XRWebGLBinding.prototype){let z=null,se=null,k=null;v.depth&&(k=v.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,z=v.stencil?lr:or,se=v.stencil?ar:ci);const ue={colorFormat:t.RGBA8,depthFormat:k,scaleFactor:s};a=this.getBinding(),l=a.createProjectionLayer(ue),r.updateRenderState({layers:[l]}),e.setPixelRatio(1),e.setSize(l.textureWidth,l.textureHeight,!1),R=new Zn(l.textureWidth,l.textureHeight,{format:un,type:Cn,depthTexture:new tc(l.textureWidth,l.textureHeight,se,void 0,void 0,void 0,void 0,void 0,void 0,z),stencilBuffer:v.stencil,colorSpace:e.outputColorSpace,samples:v.antialias?4:0,resolveDepthBuffer:l.ignoreDepthValues===!1,resolveStencilBuffer:l.ignoreDepthValues===!1})}else{const z={antialias:v.antialias,alpha:!0,depth:v.depth,stencil:v.stencil,framebufferScaleFactor:s};u=new XRWebGLLayer(r,t,z),r.updateRenderState({baseLayer:u}),e.setPixelRatio(1),e.setSize(u.framebufferWidth,u.framebufferHeight,!1),R=new Zn(u.framebufferWidth,u.framebufferHeight,{format:un,type:Cn,colorSpace:e.outputColorSpace,stencilBuffer:v.stencil,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1})}R.isXRRenderTarget=!0,this.setFoveation(d),h=null,o=await r.requestReferenceSpace(c),U.setContext(r),U.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return S.getDepthTexture()};function Q(M){for(let g=0;g<M.removed.length;g++){const z=M.removed[g],se=y.indexOf(z);se>=0&&(y[se]=null,C[se].disconnect(z))}for(let g=0;g<M.added.length;g++){const z=M.added[g];let se=y.indexOf(z);if(se===-1){for(let ue=0;ue<C.length;ue++)if(ue>=y.length){y.push(z),se=ue;break}else if(y[ue]===null){y[ue]=z,se=ue;break}if(se===-1)break}const k=C[se];k&&k.connect(z)}}const B=new V,pe=new V;function le(M,g,z){B.setFromMatrixPosition(g.matrixWorld),pe.setFromMatrixPosition(z.matrixWorld);const se=B.distanceTo(pe),k=g.projectionMatrix.elements,ue=z.projectionMatrix.elements,me=k[14]/(k[10]-1),he=k[14]/(k[10]+1),H=(k[9]+1)/k[5],T=(k[9]-1)/k[5],q=(k[8]-1)/k[0],J=(ue[8]+1)/ue[0],D=me*q,b=me*J,ae=se/(-q+J),ce=ae*-q;if(g.matrixWorld.decompose(M.position,M.quaternion,M.scale),M.translateX(ce),M.translateZ(ae),M.matrixWorld.compose(M.position,M.quaternion,M.scale),M.matrixWorldInverse.copy(M.matrixWorld).invert(),k[10]===-1)M.projectionMatrix.copy(g.projectionMatrix),M.projectionMatrixInverse.copy(g.projectionMatrixInverse);else{const Te=me+ae,O=he+ae,x=D-ce,W=b+(se-ce),re=H*he/O*Te,fe=T*he/O*Te;M.projectionMatrix.makePerspective(x,W,re,fe,Te,O),M.projectionMatrixInverse.copy(M.projectionMatrix).invert()}}function _e(M,g){g===null?M.matrixWorld.copy(M.matrix):M.matrixWorld.multiplyMatrices(g.matrixWorld,M.matrix),M.matrixWorldInverse.copy(M.matrixWorld).invert()}this.updateCamera=function(M){if(r===null)return;let g=M.near,z=M.far;S.texture!==null&&(S.depthNear>0&&(g=S.depthNear),S.depthFar>0&&(z=S.depthFar)),G.near=_.near=I.near=g,G.far=_.far=I.far=z,(Z!==G.near||j!==G.far)&&(r.updateRenderState({depthNear:G.near,depthFar:G.far}),Z=G.near,j=G.far),G.layers.mask=M.layers.mask|6,I.layers.mask=G.layers.mask&3,_.layers.mask=G.layers.mask&5;const se=M.parent,k=G.cameras;_e(G,se);for(let ue=0;ue<k.length;ue++)_e(k[ue],se);k.length===2?le(G,I,_):G.projectionMatrix.copy(I.projectionMatrix),Ue(M,G,se)};function Ue(M,g,z){z===null?M.matrix.copy(g.matrixWorld):(M.matrix.copy(z.matrixWorld),M.matrix.invert(),M.matrix.multiply(g.matrixWorld)),M.matrix.decompose(M.position,M.quaternion,M.scale),M.updateMatrixWorld(!0),M.projectionMatrix.copy(g.projectionMatrix),M.projectionMatrixInverse.copy(g.projectionMatrixInverse),M.isPerspectiveCamera&&(M.fov=Pa*2*Math.atan(1/M.projectionMatrix.elements[5]),M.zoom=1)}this.getCamera=function(){return G},this.getFoveation=function(){if(!(l===null&&u===null))return d},this.setFoveation=function(M){d=M,l!==null&&(l.fixedFoveation=M),u!==null&&u.fixedFoveation!==void 0&&(u.fixedFoveation=M)},this.hasDepthSensing=function(){return S.texture!==null},this.getDepthSensingMesh=function(){return S.getMesh(G)},this.getCameraTexture=function(M){return f[M]};let He=null;function X(M,g){if(p=g.getViewerPose(h||o),E=g,p!==null){const z=p.views;u!==null&&(e.setRenderTargetFramebuffer(R,u.framebuffer),e.setRenderTarget(R));let se=!1;z.length!==G.cameras.length&&(G.cameras.length=0,se=!0);for(let he=0;he<z.length;he++){const H=z[he];let T=null;if(u!==null)T=u.getViewport(H);else{const J=a.getViewSubImage(l,H);T=J.viewport,he===0&&(e.setRenderTargetTextures(R,J.colorTexture,J.depthStencilTexture),e.setRenderTarget(R))}let q=P[he];q===void 0&&(q=new jt,q.layers.enable(he),q.viewport=new St,P[he]=q),q.matrix.fromArray(H.transform.matrix),q.matrix.decompose(q.position,q.quaternion,q.scale),q.projectionMatrix.fromArray(H.projectionMatrix),q.projectionMatrixInverse.copy(q.projectionMatrix).invert(),q.viewport.set(T.x,T.y,T.width,T.height),he===0&&(G.matrix.copy(q.matrix),G.matrix.decompose(G.position,G.quaternion,G.scale)),se===!0&&G.cameras.push(q)}const k=r.enabledFeatures;if(k&&k.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&m){a=n.getBinding();const he=a.getDepthInformation(z[0]);he&&he.isValid&&he.texture&&S.init(he,r.renderState)}if(k&&k.includes("camera-access")&&m){e.state.unbindTexture(),a=n.getBinding();for(let he=0;he<z.length;he++){const H=z[he].camera;if(H){let T=f[H];T||(T=new nc,f[H]=T);const q=a.getCameraImage(H);T.sourceTexture=q}}}}for(let z=0;z<C.length;z++){const se=y[z],k=C[z];se!==null&&k!==void 0&&k.update(se,g,h||o)}He&&He(M,g),g.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:g}),E=null}const U=new dc;U.setAnimationLoop(X),this.setAnimationLoop=function(M){He=M},this.dispose=function(){}}}const ri=new Dn,PS=new mt;function US(i,e){function t(S,f){S.matrixAutoUpdate===!0&&S.updateMatrix(),f.value.copy(S.matrix)}function n(S,f){f.color.getRGB(S.fogColor.value,jl(i)),f.isFog?(S.fogNear.value=f.near,S.fogFar.value=f.far):f.isFogExp2&&(S.fogDensity.value=f.density)}function r(S,f,v,A,R){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(S,f):f.isMeshToonMaterial?(s(S,f),a(S,f)):f.isMeshPhongMaterial?(s(S,f),p(S,f)):f.isMeshStandardMaterial?(s(S,f),l(S,f),f.isMeshPhysicalMaterial&&u(S,f,R)):f.isMeshMatcapMaterial?(s(S,f),E(S,f)):f.isMeshDepthMaterial?s(S,f):f.isMeshDistanceMaterial?(s(S,f),m(S,f)):f.isMeshNormalMaterial?s(S,f):f.isLineBasicMaterial?(o(S,f),f.isLineDashedMaterial&&c(S,f)):f.isPointsMaterial?d(S,f,v,A):f.isSpriteMaterial?h(S,f):f.isShadowMaterial?(S.color.value.copy(f.color),S.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(S,f){S.opacity.value=f.opacity,f.color&&S.diffuse.value.copy(f.color),f.emissive&&S.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(S.map.value=f.map,t(f.map,S.mapTransform)),f.alphaMap&&(S.alphaMap.value=f.alphaMap,t(f.alphaMap,S.alphaMapTransform)),f.bumpMap&&(S.bumpMap.value=f.bumpMap,t(f.bumpMap,S.bumpMapTransform),S.bumpScale.value=f.bumpScale,f.side===It&&(S.bumpScale.value*=-1)),f.normalMap&&(S.normalMap.value=f.normalMap,t(f.normalMap,S.normalMapTransform),S.normalScale.value.copy(f.normalScale),f.side===It&&S.normalScale.value.negate()),f.displacementMap&&(S.displacementMap.value=f.displacementMap,t(f.displacementMap,S.displacementMapTransform),S.displacementScale.value=f.displacementScale,S.displacementBias.value=f.displacementBias),f.emissiveMap&&(S.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,S.emissiveMapTransform)),f.specularMap&&(S.specularMap.value=f.specularMap,t(f.specularMap,S.specularMapTransform)),f.alphaTest>0&&(S.alphaTest.value=f.alphaTest);const v=e.get(f),A=v.envMap,R=v.envMapRotation;A&&(S.envMap.value=A,ri.copy(R),ri.x*=-1,ri.y*=-1,ri.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(ri.y*=-1,ri.z*=-1),S.envMapRotation.value.setFromMatrix4(PS.makeRotationFromEuler(ri)),S.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,S.reflectivity.value=f.reflectivity,S.ior.value=f.ior,S.refractionRatio.value=f.refractionRatio),f.lightMap&&(S.lightMap.value=f.lightMap,S.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,S.lightMapTransform)),f.aoMap&&(S.aoMap.value=f.aoMap,S.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,S.aoMapTransform))}function o(S,f){S.diffuse.value.copy(f.color),S.opacity.value=f.opacity,f.map&&(S.map.value=f.map,t(f.map,S.mapTransform))}function c(S,f){S.dashSize.value=f.dashSize,S.totalSize.value=f.dashSize+f.gapSize,S.scale.value=f.scale}function d(S,f,v,A){S.diffuse.value.copy(f.color),S.opacity.value=f.opacity,S.size.value=f.size*v,S.scale.value=A*.5,f.map&&(S.map.value=f.map,t(f.map,S.uvTransform)),f.alphaMap&&(S.alphaMap.value=f.alphaMap,t(f.alphaMap,S.alphaMapTransform)),f.alphaTest>0&&(S.alphaTest.value=f.alphaTest)}function h(S,f){S.diffuse.value.copy(f.color),S.opacity.value=f.opacity,S.rotation.value=f.rotation,f.map&&(S.map.value=f.map,t(f.map,S.mapTransform)),f.alphaMap&&(S.alphaMap.value=f.alphaMap,t(f.alphaMap,S.alphaMapTransform)),f.alphaTest>0&&(S.alphaTest.value=f.alphaTest)}function p(S,f){S.specular.value.copy(f.specular),S.shininess.value=Math.max(f.shininess,1e-4)}function a(S,f){f.gradientMap&&(S.gradientMap.value=f.gradientMap)}function l(S,f){S.metalness.value=f.metalness,f.metalnessMap&&(S.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,S.metalnessMapTransform)),S.roughness.value=f.roughness,f.roughnessMap&&(S.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,S.roughnessMapTransform)),f.envMap&&(S.envMapIntensity.value=f.envMapIntensity)}function u(S,f,v){S.ior.value=f.ior,f.sheen>0&&(S.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),S.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(S.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,S.sheenColorMapTransform)),f.sheenRoughnessMap&&(S.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,S.sheenRoughnessMapTransform))),f.clearcoat>0&&(S.clearcoat.value=f.clearcoat,S.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(S.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,S.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(S.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,S.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(S.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,S.clearcoatNormalMapTransform),S.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===It&&S.clearcoatNormalScale.value.negate())),f.dispersion>0&&(S.dispersion.value=f.dispersion),f.iridescence>0&&(S.iridescence.value=f.iridescence,S.iridescenceIOR.value=f.iridescenceIOR,S.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],S.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(S.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,S.iridescenceMapTransform)),f.iridescenceThicknessMap&&(S.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,S.iridescenceThicknessMapTransform))),f.transmission>0&&(S.transmission.value=f.transmission,S.transmissionSamplerMap.value=v.texture,S.transmissionSamplerSize.value.set(v.width,v.height),f.transmissionMap&&(S.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,S.transmissionMapTransform)),S.thickness.value=f.thickness,f.thicknessMap&&(S.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,S.thicknessMapTransform)),S.attenuationDistance.value=f.attenuationDistance,S.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(S.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(S.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,S.anisotropyMapTransform))),S.specularIntensity.value=f.specularIntensity,S.specularColor.value.copy(f.specularColor),f.specularColorMap&&(S.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,S.specularColorMapTransform)),f.specularIntensityMap&&(S.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,S.specularIntensityMapTransform))}function E(S,f){f.matcap&&(S.matcap.value=f.matcap)}function m(S,f){const v=e.get(f).light;S.referencePosition.value.setFromMatrixPosition(v.matrixWorld),S.nearDistance.value=v.shadow.camera.near,S.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function wS(i,e,t,n){let r={},s={},o=[];const c=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function d(v,A){const R=A.program;n.uniformBlockBinding(v,R)}function h(v,A){let R=r[v.id];R===void 0&&(E(v),R=p(v),r[v.id]=R,v.addEventListener("dispose",S));const C=A.program;n.updateUBOMapping(v,C);const y=e.render.frame;s[v.id]!==y&&(l(v),s[v.id]=y)}function p(v){const A=a();v.__bindingPointIndex=A;const R=i.createBuffer(),C=v.__size,y=v.usage;return i.bindBuffer(i.UNIFORM_BUFFER,R),i.bufferData(i.UNIFORM_BUFFER,C,y),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,A,R),R}function a(){for(let v=0;v<c;v++)if(o.indexOf(v)===-1)return o.push(v),v;return dt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function l(v){const A=r[v.id],R=v.uniforms,C=v.__cache;i.bindBuffer(i.UNIFORM_BUFFER,A);for(let y=0,N=R.length;y<N;y++){const w=Array.isArray(R[y])?R[y]:[R[y]];for(let I=0,_=w.length;I<_;I++){const P=w[I];if(u(P,y,I,C)===!0){const G=P.__offset,Z=Array.isArray(P.value)?P.value:[P.value];let j=0;for(let $=0;$<Z.length;$++){const ie=Z[$],Q=m(ie);typeof ie=="number"||typeof ie=="boolean"?(P.__data[0]=ie,i.bufferSubData(i.UNIFORM_BUFFER,G+j,P.__data)):ie.isMatrix3?(P.__data[0]=ie.elements[0],P.__data[1]=ie.elements[1],P.__data[2]=ie.elements[2],P.__data[3]=0,P.__data[4]=ie.elements[3],P.__data[5]=ie.elements[4],P.__data[6]=ie.elements[5],P.__data[7]=0,P.__data[8]=ie.elements[6],P.__data[9]=ie.elements[7],P.__data[10]=ie.elements[8],P.__data[11]=0):(ie.toArray(P.__data,j),j+=Q.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,G,P.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function u(v,A,R,C){const y=v.value,N=A+"_"+R;if(C[N]===void 0)return typeof y=="number"||typeof y=="boolean"?C[N]=y:C[N]=y.clone(),!0;{const w=C[N];if(typeof y=="number"||typeof y=="boolean"){if(w!==y)return C[N]=y,!0}else if(w.equals(y)===!1)return w.copy(y),!0}return!1}function E(v){const A=v.uniforms;let R=0;const C=16;for(let N=0,w=A.length;N<w;N++){const I=Array.isArray(A[N])?A[N]:[A[N]];for(let _=0,P=I.length;_<P;_++){const G=I[_],Z=Array.isArray(G.value)?G.value:[G.value];for(let j=0,$=Z.length;j<$;j++){const ie=Z[j],Q=m(ie),B=R%C,pe=B%Q.boundary,le=B+pe;R+=pe,le!==0&&C-le<Q.storage&&(R+=C-le),G.__data=new Float32Array(Q.storage/Float32Array.BYTES_PER_ELEMENT),G.__offset=R,R+=Q.storage}}}const y=R%C;return y>0&&(R+=C-y),v.__size=R,v.__cache={},this}function m(v){const A={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(A.boundary=4,A.storage=4):v.isVector2?(A.boundary=8,A.storage=8):v.isVector3||v.isColor?(A.boundary=16,A.storage=12):v.isVector4?(A.boundary=16,A.storage=16):v.isMatrix3?(A.boundary=48,A.storage=48):v.isMatrix4?(A.boundary=64,A.storage=64):v.isTexture?Ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Ke("WebGLRenderer: Unsupported uniform value type.",v),A}function S(v){const A=v.target;A.removeEventListener("dispose",S);const R=o.indexOf(A.__bindingPointIndex);o.splice(R,1),i.deleteBuffer(r[A.id]),delete r[A.id],delete s[A.id]}function f(){for(const v in r)i.deleteBuffer(r[v]);o=[],r={},s={}}return{bind:d,update:h,dispose:f}}const FS=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let Mn=null;function BS(){return Mn===null&&(Mn=new rh(FS,32,32,Ka,Hi),Mn.minFilter=$t,Mn.magFilter=$t,Mn.wrapS=Ln,Mn.wrapT=Ln,Mn.generateMipmaps=!1,Mn.needsUpdate=!0),Mn}class HS{constructor(e={}){const{canvas:t=Ou(),context:n=null,depth:r=!0,stencil:s=!1,alpha:o=!1,antialias:c=!1,premultipliedAlpha:d=!0,preserveDrawingBuffer:h=!1,powerPreference:p="default",failIfMajorPerformanceCaveat:a=!1,reversedDepthBuffer:l=!1}=e;this.isWebGLRenderer=!0;let u;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");u=n.getContextAttributes().alpha}else u=o;const E=new Set([qa,Xa,za]),m=new Set([Cn,ci,sr,ar,Wa,Ya]),S=new Uint32Array(4),f=new Int32Array(4);let v=null,A=null;const R=[],C=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Xn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const y=this;let N=!1;this._outputColorSpace=Ft;let w=0,I=0,_=null,P=-1,G=null;const Z=new St,j=new St;let $=null;const ie=new tt(0);let Q=0,B=t.width,pe=t.height,le=1,_e=null,Ue=null;const He=new St(0,0,B,pe),X=new St(0,0,B,pe);let U=!1;const M=new ec;let g=!1,z=!1;const se=new mt,k=new V,ue=new St,me={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let he=!1;function H(){return _===null?le:1}let T=n;function q(L,Y){return t.getContext(L,Y)}try{const L={alpha:!0,depth:r,stencil:s,antialias:c,premultipliedAlpha:d,preserveDrawingBuffer:h,powerPreference:p,failIfMajorPerformanceCaveat:a};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Va}`),t.addEventListener("webglcontextlost",Se,!1),t.addEventListener("webglcontextrestored",de,!1),t.addEventListener("webglcontextcreationerror",De,!1),T===null){const Y="webgl2";if(T=q(Y,L),T===null)throw q(Y)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(L){throw L("WebGLRenderer: "+L.message),L}let J,D,b,ae,ce,Te,O,x,W,re,fe,ne,Ne,ge,we,Ce,Ee,Ae,ke,Ge,be,ze,F,Ie;function Re(){J=new Xp(T),J.init(),ze=new bS(T,J),D=new Bp(T,J,e,ze),b=new LS(T,J),D.reversedDepthBuffer&&l&&b.buffers.depth.setReversed(!0),ae=new Jp(T),ce=new pS,Te=new yS(T,J,b,ce,D,ze,ae),O=new Gp(y),x=new Kp(y),W=new $h(T),F=new wp(T,W),re=new qp(T,W,ae,F),fe=new Qp(T,re,W,ae),ke=new jp(T,D,Te),Ce=new Hp(ce),ne=new fS(y,O,x,J,D,F,Ce),Ne=new US(y,ce),ge=new SS,we=new TS(J),Ae=new Up(y,O,x,b,fe,u,d),Ee=new MS(y,fe,D),Ie=new wS(T,ae,D,b),Ge=new Fp(T,J,ae),be=new Zp(T,J,ae),ae.programs=ne.programs,y.capabilities=D,y.extensions=J,y.properties=ce,y.renderLists=ge,y.shadowMap=Ee,y.state=b,y.info=ae}Re();const ve=new DS(y,T);this.xr=ve,this.getContext=function(){return T},this.getContextAttributes=function(){return T.getContextAttributes()},this.forceContextLoss=function(){const L=J.get("WEBGL_lose_context");L&&L.loseContext()},this.forceContextRestore=function(){const L=J.get("WEBGL_lose_context");L&&L.restoreContext()},this.getPixelRatio=function(){return le},this.setPixelRatio=function(L){L!==void 0&&(le=L,this.setSize(B,pe,!1))},this.getSize=function(L){return L.set(B,pe)},this.setSize=function(L,Y,ee=!0){if(ve.isPresenting){Ke("WebGLRenderer: Can't change size while VR device is presenting.");return}B=L,pe=Y,t.width=Math.floor(L*le),t.height=Math.floor(Y*le),ee===!0&&(t.style.width=L+"px",t.style.height=Y+"px"),this.setViewport(0,0,L,Y)},this.getDrawingBufferSize=function(L){return L.set(B*le,pe*le).floor()},this.setDrawingBufferSize=function(L,Y,ee){B=L,pe=Y,le=ee,t.width=Math.floor(L*ee),t.height=Math.floor(Y*ee),this.setViewport(0,0,L,Y)},this.getCurrentViewport=function(L){return L.copy(Z)},this.getViewport=function(L){return L.copy(He)},this.setViewport=function(L,Y,ee,te){L.isVector4?He.set(L.x,L.y,L.z,L.w):He.set(L,Y,ee,te),b.viewport(Z.copy(He).multiplyScalar(le).round())},this.getScissor=function(L){return L.copy(X)},this.setScissor=function(L,Y,ee,te){L.isVector4?X.set(L.x,L.y,L.z,L.w):X.set(L,Y,ee,te),b.scissor(j.copy(X).multiplyScalar(le).round())},this.getScissorTest=function(){return U},this.setScissorTest=function(L){b.setScissorTest(U=L)},this.setOpaqueSort=function(L){_e=L},this.setTransparentSort=function(L){Ue=L},this.getClearColor=function(L){return L.copy(Ae.getClearColor())},this.setClearColor=function(){Ae.setClearColor(...arguments)},this.getClearAlpha=function(){return Ae.getClearAlpha()},this.setClearAlpha=function(){Ae.setClearAlpha(...arguments)},this.clear=function(L=!0,Y=!0,ee=!0){let te=0;if(L){let K=!1;if(_!==null){const xe=_.texture.format;K=E.has(xe)}if(K){const xe=_.texture.type,Le=m.has(xe),Pe=Ae.getClearColor(),Oe=Ae.getClearAlpha(),Ve=Pe.r,We=Pe.g,Fe=Pe.b;Le?(S[0]=Ve,S[1]=We,S[2]=Fe,S[3]=Oe,T.clearBufferuiv(T.COLOR,0,S)):(f[0]=Ve,f[1]=We,f[2]=Fe,f[3]=Oe,T.clearBufferiv(T.COLOR,0,f))}else te|=T.COLOR_BUFFER_BIT}Y&&(te|=T.DEPTH_BUFFER_BIT),ee&&(te|=T.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),T.clear(te)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Se,!1),t.removeEventListener("webglcontextrestored",de,!1),t.removeEventListener("webglcontextcreationerror",De,!1),Ae.dispose(),ge.dispose(),we.dispose(),ce.dispose(),O.dispose(),x.dispose(),fe.dispose(),F.dispose(),Ie.dispose(),ne.dispose(),ve.dispose(),ve.removeEventListener("sessionstart",lo),ve.removeEventListener("sessionend",co),Jn.stop()};function Se(L){L.preventDefault(),vo("WebGLRenderer: Context Lost."),N=!0}function de(){vo("WebGLRenderer: Context Restored."),N=!1;const L=ae.autoReset,Y=Ee.enabled,ee=Ee.autoUpdate,te=Ee.needsUpdate,K=Ee.type;Re(),ae.autoReset=L,Ee.enabled=Y,Ee.autoUpdate=ee,Ee.needsUpdate=te,Ee.type=K}function De(L){dt("WebGLRenderer: A WebGL context could not be created. Reason: ",L.statusMessage)}function Xe(L){const Y=L.target;Y.removeEventListener("dispose",Xe),ot(Y)}function ot(L){nt(L),ce.remove(L)}function nt(L){const Y=ce.get(L).programs;Y!==void 0&&(Y.forEach(function(ee){ne.releaseProgram(ee)}),L.isShaderMaterial&&ne.releaseShaderCache(L))}this.renderBufferDirect=function(L,Y,ee,te,K,xe){Y===null&&(Y=me);const Le=K.isMesh&&K.matrixWorld.determinant()<0,Pe=Nc(L,Y,ee,te,K);b.setMaterial(te,Le);let Oe=ee.index,Ve=1;if(te.wireframe===!0){if(Oe=re.getWireframeAttribute(ee),Oe===void 0)return;Ve=2}const We=ee.drawRange,Fe=ee.attributes.position;let je=We.start*Ve,it=(We.start+We.count)*Ve;xe!==null&&(je=Math.max(je,xe.start*Ve),it=Math.min(it,(xe.start+xe.count)*Ve)),Oe!==null?(je=Math.max(je,0),it=Math.min(it,Oe.count)):Fe!=null&&(je=Math.max(je,0),it=Math.min(it,Fe.count));const pt=it-je;if(pt<0||pt===1/0)return;F.setup(K,te,Pe,ee,Oe);let Et,at=Ge;if(Oe!==null&&(Et=W.get(Oe),at=be,at.setIndex(Et)),K.isMesh)te.wireframe===!0?(b.setLineWidth(te.wireframeLinewidth*H()),at.setMode(T.LINES)):at.setMode(T.TRIANGLES);else if(K.isLine){let Be=te.linewidth;Be===void 0&&(Be=1),b.setLineWidth(Be*H()),K.isLineSegments?at.setMode(T.LINES):K.isLineLoop?at.setMode(T.LINE_LOOP):at.setMode(T.LINE_STRIP)}else K.isPoints?at.setMode(T.POINTS):K.isSprite&&at.setMode(T.TRIANGLES);if(K.isBatchedMesh)if(K._multiDrawInstances!==null)cr("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),at.renderMultiDrawInstances(K._multiDrawStarts,K._multiDrawCounts,K._multiDrawCount,K._multiDrawInstances);else if(J.get("WEBGL_multi_draw"))at.renderMultiDraw(K._multiDrawStarts,K._multiDrawCounts,K._multiDrawCount);else{const Be=K._multiDrawStarts,ut=K._multiDrawCounts,Qe=K._multiDrawCount,Bt=Oe?W.get(Oe).bytesPerElement:1,fi=ce.get(te).currentProgram.getUniforms();for(let Ht=0;Ht<Qe;Ht++)fi.setValue(T,"_gl_DrawID",Ht),at.render(Be[Ht]/Bt,ut[Ht])}else if(K.isInstancedMesh)at.renderInstances(je,pt,K.count);else if(ee.isInstancedBufferGeometry){const Be=ee._maxInstanceCount!==void 0?ee._maxInstanceCount:1/0,ut=Math.min(ee.instanceCount,Be);at.renderInstances(je,pt,ut)}else at.render(je,pt)};function fn(L,Y,ee){L.transparent===!0&&L.side===ln&&L.forceSinglePass===!1?(L.side=It,L.needsUpdate=!0,mr(L,Y,ee),L.side=Kt,L.needsUpdate=!0,mr(L,Y,ee),L.side=ln):mr(L,Y,ee)}this.compile=function(L,Y,ee=null){ee===null&&(ee=L),A=we.get(ee),A.init(Y),C.push(A),ee.traverseVisible(function(K){K.isLight&&K.layers.test(Y.layers)&&(A.pushLight(K),K.castShadow&&A.pushShadow(K))}),L!==ee&&L.traverseVisible(function(K){K.isLight&&K.layers.test(Y.layers)&&(A.pushLight(K),K.castShadow&&A.pushShadow(K))}),A.setupLights();const te=new Set;return L.traverse(function(K){if(!(K.isMesh||K.isPoints||K.isLine||K.isSprite))return;const xe=K.material;if(xe)if(Array.isArray(xe))for(let Le=0;Le<xe.length;Le++){const Pe=xe[Le];fn(Pe,ee,K),te.add(Pe)}else fn(xe,ee,K),te.add(xe)}),A=C.pop(),te},this.compileAsync=function(L,Y,ee=null){const te=this.compile(L,Y,ee);return new Promise(K=>{function xe(){if(te.forEach(function(Le){ce.get(Le).currentProgram.isReady()&&te.delete(Le)}),te.size===0){K(L);return}setTimeout(xe,10)}J.get("KHR_parallel_shader_compile")!==null?xe():setTimeout(xe,10)})};let tn=null;function Cc(L){tn&&tn(L)}function lo(){Jn.stop()}function co(){Jn.start()}const Jn=new dc;Jn.setAnimationLoop(Cc),typeof self<"u"&&Jn.setContext(self),this.setAnimationLoop=function(L){tn=L,ve.setAnimationLoop(L),L===null?Jn.stop():Jn.start()},ve.addEventListener("sessionstart",lo),ve.addEventListener("sessionend",co),this.render=function(L,Y){if(Y!==void 0&&Y.isCamera!==!0){dt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(N===!0)return;if(L.matrixWorldAutoUpdate===!0&&L.updateMatrixWorld(),Y.parent===null&&Y.matrixWorldAutoUpdate===!0&&Y.updateMatrixWorld(),ve.enabled===!0&&ve.isPresenting===!0&&(ve.cameraAutoUpdate===!0&&ve.updateCamera(Y),Y=ve.getCamera()),L.isScene===!0&&L.onBeforeRender(y,L,Y,_),A=we.get(L,C.length),A.init(Y),C.push(A),se.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),M.setFromProjectionMatrix(se,mn,Y.reversedDepth),z=this.localClippingEnabled,g=Ce.init(this.clippingPlanes,z),v=ge.get(L,R.length),v.init(),R.push(v),ve.enabled===!0&&ve.isPresenting===!0){const xe=y.xr.getDepthSensingMesh();xe!==null&&cs(xe,Y,-1/0,y.sortObjects)}cs(L,Y,0,y.sortObjects),v.finish(),y.sortObjects===!0&&v.sort(_e,Ue),he=ve.enabled===!1||ve.isPresenting===!1||ve.hasDepthSensing()===!1,he&&Ae.addToRenderList(v,L),this.info.render.frame++,g===!0&&Ce.beginShadows();const ee=A.state.shadowsArray;Ee.render(ee,L,Y),g===!0&&Ce.endShadows(),this.info.autoReset===!0&&this.info.reset();const te=v.opaque,K=v.transmissive;if(A.setupLights(),Y.isArrayCamera){const xe=Y.cameras;if(K.length>0)for(let Le=0,Pe=xe.length;Le<Pe;Le++){const Oe=xe[Le];ho(te,K,L,Oe)}he&&Ae.render(L);for(let Le=0,Pe=xe.length;Le<Pe;Le++){const Oe=xe[Le];uo(v,L,Oe,Oe.viewport)}}else K.length>0&&ho(te,K,L,Y),he&&Ae.render(L),uo(v,L,Y);_!==null&&I===0&&(Te.updateMultisampleRenderTarget(_),Te.updateRenderTargetMipmap(_)),L.isScene===!0&&L.onAfterRender(y,L,Y),F.resetDefaultState(),P=-1,G=null,C.pop(),C.length>0?(A=C[C.length-1],g===!0&&Ce.setGlobalState(y.clippingPlanes,A.state.camera)):A=null,R.pop(),R.length>0?v=R[R.length-1]:v=null};function cs(L,Y,ee,te){if(L.visible===!1)return;if(L.layers.test(Y.layers)){if(L.isGroup)ee=L.renderOrder;else if(L.isLOD)L.autoUpdate===!0&&L.update(Y);else if(L.isLight)A.pushLight(L),L.castShadow&&A.pushShadow(L);else if(L.isSprite){if(!L.frustumCulled||M.intersectsSprite(L)){te&&ue.setFromMatrixPosition(L.matrixWorld).applyMatrix4(se);const Le=fe.update(L),Pe=L.material;Pe.visible&&v.push(L,Le,Pe,ee,ue.z,null)}}else if((L.isMesh||L.isLine||L.isPoints)&&(!L.frustumCulled||M.intersectsObject(L))){const Le=fe.update(L),Pe=L.material;if(te&&(L.boundingSphere!==void 0?(L.boundingSphere===null&&L.computeBoundingSphere(),ue.copy(L.boundingSphere.center)):(Le.boundingSphere===null&&Le.computeBoundingSphere(),ue.copy(Le.boundingSphere.center)),ue.applyMatrix4(L.matrixWorld).applyMatrix4(se)),Array.isArray(Pe)){const Oe=Le.groups;for(let Ve=0,We=Oe.length;Ve<We;Ve++){const Fe=Oe[Ve],je=Pe[Fe.materialIndex];je&&je.visible&&v.push(L,Le,je,ee,ue.z,Fe)}}else Pe.visible&&v.push(L,Le,Pe,ee,ue.z,null)}}const xe=L.children;for(let Le=0,Pe=xe.length;Le<Pe;Le++)cs(xe[Le],Y,ee,te)}function uo(L,Y,ee,te){const{opaque:K,transmissive:xe,transparent:Le}=L;A.setupLightsView(ee),g===!0&&Ce.setGlobalState(y.clippingPlanes,ee),te&&b.viewport(Z.copy(te)),K.length>0&&Sr(K,Y,ee),xe.length>0&&Sr(xe,Y,ee),Le.length>0&&Sr(Le,Y,ee),b.buffers.depth.setTest(!0),b.buffers.depth.setMask(!0),b.buffers.color.setMask(!0),b.setPolygonOffset(!1)}function ho(L,Y,ee,te){if((ee.isScene===!0?ee.overrideMaterial:null)!==null)return;A.state.transmissionRenderTarget[te.id]===void 0&&(A.state.transmissionRenderTarget[te.id]=new Zn(1,1,{generateMipmaps:!0,type:J.has("EXT_color_buffer_half_float")||J.has("EXT_color_buffer_float")?Hi:Cn,minFilter:oi,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:$e.workingColorSpace}));const xe=A.state.transmissionRenderTarget[te.id],Le=te.viewport||Z;xe.setSize(Le.z*y.transmissionResolutionScale,Le.w*y.transmissionResolutionScale);const Pe=y.getRenderTarget(),Oe=y.getActiveCubeFace(),Ve=y.getActiveMipmapLevel();y.setRenderTarget(xe),y.getClearColor(ie),Q=y.getClearAlpha(),Q<1&&y.setClearColor(16777215,.5),y.clear(),he&&Ae.render(ee);const We=y.toneMapping;y.toneMapping=Xn;const Fe=te.viewport;if(te.viewport!==void 0&&(te.viewport=void 0),A.setupLightsView(te),g===!0&&Ce.setGlobalState(y.clippingPlanes,te),Sr(L,ee,te),Te.updateMultisampleRenderTarget(xe),Te.updateRenderTargetMipmap(xe),J.has("WEBGL_multisampled_render_to_texture")===!1){let je=!1;for(let it=0,pt=Y.length;it<pt;it++){const Et=Y[it],{object:at,geometry:Be,material:ut,group:Qe}=Et;if(ut.side===ln&&at.layers.test(te.layers)){const Bt=ut.side;ut.side=It,ut.needsUpdate=!0,fo(at,ee,te,Be,ut,Qe),ut.side=Bt,ut.needsUpdate=!0,je=!0}}je===!0&&(Te.updateMultisampleRenderTarget(xe),Te.updateRenderTargetMipmap(xe))}y.setRenderTarget(Pe,Oe,Ve),y.setClearColor(ie,Q),Fe!==void 0&&(te.viewport=Fe),y.toneMapping=We}function Sr(L,Y,ee){const te=Y.isScene===!0?Y.overrideMaterial:null;for(let K=0,xe=L.length;K<xe;K++){const Le=L[K],{object:Pe,geometry:Oe,group:Ve}=Le;let We=Le.material;We.allowOverride===!0&&te!==null&&(We=te),Pe.layers.test(ee.layers)&&fo(Pe,Y,ee,Oe,We,Ve)}}function fo(L,Y,ee,te,K,xe){L.onBeforeRender(y,Y,ee,te,K,xe),L.modelViewMatrix.multiplyMatrices(ee.matrixWorldInverse,L.matrixWorld),L.normalMatrix.getNormalMatrix(L.modelViewMatrix),K.onBeforeRender(y,Y,ee,te,L,xe),K.transparent===!0&&K.side===ln&&K.forceSinglePass===!1?(K.side=It,K.needsUpdate=!0,y.renderBufferDirect(ee,Y,te,K,L,xe),K.side=Kt,K.needsUpdate=!0,y.renderBufferDirect(ee,Y,te,K,L,xe),K.side=ln):y.renderBufferDirect(ee,Y,te,K,L,xe),L.onAfterRender(y,Y,ee,te,K,xe)}function mr(L,Y,ee){Y.isScene!==!0&&(Y=me);const te=ce.get(L),K=A.state.lights,xe=A.state.shadowsArray,Le=K.state.version,Pe=ne.getParameters(L,K.state,xe,Y,ee),Oe=ne.getProgramCacheKey(Pe);let Ve=te.programs;te.environment=L.isMeshStandardMaterial?Y.environment:null,te.fog=Y.fog,te.envMap=(L.isMeshStandardMaterial?x:O).get(L.envMap||te.environment),te.envMapRotation=te.environment!==null&&L.envMap===null?Y.environmentRotation:L.envMapRotation,Ve===void 0&&(L.addEventListener("dispose",Xe),Ve=new Map,te.programs=Ve);let We=Ve.get(Oe);if(We!==void 0){if(te.currentProgram===We&&te.lightsStateVersion===Le)return Eo(L,Pe),We}else Pe.uniforms=ne.getUniforms(L),L.onBeforeCompile(Pe,y),We=ne.acquireProgram(Pe,Oe),Ve.set(Oe,We),te.uniforms=Pe.uniforms;const Fe=te.uniforms;return(!L.isShaderMaterial&&!L.isRawShaderMaterial||L.clipping===!0)&&(Fe.clippingPlanes=Ce.uniform),Eo(L,Pe),te.needsLights=Pc(L),te.lightsStateVersion=Le,te.needsLights&&(Fe.ambientLightColor.value=K.state.ambient,Fe.lightProbe.value=K.state.probe,Fe.directionalLights.value=K.state.directional,Fe.directionalLightShadows.value=K.state.directionalShadow,Fe.spotLights.value=K.state.spot,Fe.spotLightShadows.value=K.state.spotShadow,Fe.rectAreaLights.value=K.state.rectArea,Fe.ltc_1.value=K.state.rectAreaLTC1,Fe.ltc_2.value=K.state.rectAreaLTC2,Fe.pointLights.value=K.state.point,Fe.pointLightShadows.value=K.state.pointShadow,Fe.hemisphereLights.value=K.state.hemi,Fe.directionalShadowMap.value=K.state.directionalShadowMap,Fe.directionalShadowMatrix.value=K.state.directionalShadowMatrix,Fe.spotShadowMap.value=K.state.spotShadowMap,Fe.spotLightMatrix.value=K.state.spotLightMatrix,Fe.spotLightMap.value=K.state.spotLightMap,Fe.pointShadowMap.value=K.state.pointShadowMap,Fe.pointShadowMatrix.value=K.state.pointShadowMatrix),te.currentProgram=We,te.uniformsList=null,We}function po(L){if(L.uniformsList===null){const Y=L.currentProgram.getUniforms();L.uniformsList=Zr.seqWithValue(Y.seq,L.uniforms)}return L.uniformsList}function Eo(L,Y){const ee=ce.get(L);ee.outputColorSpace=Y.outputColorSpace,ee.batching=Y.batching,ee.batchingColor=Y.batchingColor,ee.instancing=Y.instancing,ee.instancingColor=Y.instancingColor,ee.instancingMorph=Y.instancingMorph,ee.skinning=Y.skinning,ee.morphTargets=Y.morphTargets,ee.morphNormals=Y.morphNormals,ee.morphColors=Y.morphColors,ee.morphTargetsCount=Y.morphTargetsCount,ee.numClippingPlanes=Y.numClippingPlanes,ee.numIntersection=Y.numClipIntersection,ee.vertexAlphas=Y.vertexAlphas,ee.vertexTangents=Y.vertexTangents,ee.toneMapping=Y.toneMapping}function Nc(L,Y,ee,te,K){Y.isScene!==!0&&(Y=me),Te.resetTextureUnits();const xe=Y.fog,Le=te.isMeshStandardMaterial?Y.environment:null,Pe=_===null?y.outputColorSpace:_.isXRRenderTarget===!0?_.texture.colorSpace:wi,Oe=(te.isMeshStandardMaterial?x:O).get(te.envMap||Le),Ve=te.vertexColors===!0&&!!ee.attributes.color&&ee.attributes.color.itemSize===4,We=!!ee.attributes.tangent&&(!!te.normalMap||te.anisotropy>0),Fe=!!ee.morphAttributes.position,je=!!ee.morphAttributes.normal,it=!!ee.morphAttributes.color;let pt=Xn;te.toneMapped&&(_===null||_.isXRRenderTarget===!0)&&(pt=y.toneMapping);const Et=ee.morphAttributes.position||ee.morphAttributes.normal||ee.morphAttributes.color,at=Et!==void 0?Et.length:0,Be=ce.get(te),ut=A.state.lights;if(g===!0&&(z===!0||L!==G)){const bt=L===G&&te.id===P;Ce.setState(te,L,bt)}let Qe=!1;te.version===Be.__version?(Be.needsLights&&Be.lightsStateVersion!==ut.state.version||Be.outputColorSpace!==Pe||K.isBatchedMesh&&Be.batching===!1||!K.isBatchedMesh&&Be.batching===!0||K.isBatchedMesh&&Be.batchingColor===!0&&K.colorTexture===null||K.isBatchedMesh&&Be.batchingColor===!1&&K.colorTexture!==null||K.isInstancedMesh&&Be.instancing===!1||!K.isInstancedMesh&&Be.instancing===!0||K.isSkinnedMesh&&Be.skinning===!1||!K.isSkinnedMesh&&Be.skinning===!0||K.isInstancedMesh&&Be.instancingColor===!0&&K.instanceColor===null||K.isInstancedMesh&&Be.instancingColor===!1&&K.instanceColor!==null||K.isInstancedMesh&&Be.instancingMorph===!0&&K.morphTexture===null||K.isInstancedMesh&&Be.instancingMorph===!1&&K.morphTexture!==null||Be.envMap!==Oe||te.fog===!0&&Be.fog!==xe||Be.numClippingPlanes!==void 0&&(Be.numClippingPlanes!==Ce.numPlanes||Be.numIntersection!==Ce.numIntersection)||Be.vertexAlphas!==Ve||Be.vertexTangents!==We||Be.morphTargets!==Fe||Be.morphNormals!==je||Be.morphColors!==it||Be.toneMapping!==pt||Be.morphTargetsCount!==at)&&(Qe=!0):(Qe=!0,Be.__version=te.version);let Bt=Be.currentProgram;Qe===!0&&(Bt=mr(te,Y,K));let fi=!1,Ht=!1,Ki=!1;const ht=Bt.getUniforms(),Dt=Be.uniforms;if(b.useProgram(Bt.program)&&(fi=!0,Ht=!0,Ki=!0),te.id!==P&&(P=te.id,Ht=!0),fi||G!==L){b.buffers.depth.getReversed()&&L.reversedDepth!==!0&&(L._reversedDepth=!0,L.updateProjectionMatrix()),ht.setValue(T,"projectionMatrix",L.projectionMatrix),ht.setValue(T,"viewMatrix",L.matrixWorldInverse);const Pt=ht.map.cameraPosition;Pt!==void 0&&Pt.setValue(T,k.setFromMatrixPosition(L.matrixWorld)),D.logarithmicDepthBuffer&&ht.setValue(T,"logDepthBufFC",2/(Math.log(L.far+1)/Math.LN2)),(te.isMeshPhongMaterial||te.isMeshToonMaterial||te.isMeshLambertMaterial||te.isMeshBasicMaterial||te.isMeshStandardMaterial||te.isShaderMaterial)&&ht.setValue(T,"isOrthographic",L.isOrthographicCamera===!0),G!==L&&(G=L,Ht=!0,Ki=!0)}if(K.isSkinnedMesh){ht.setOptional(T,K,"bindMatrix"),ht.setOptional(T,K,"bindMatrixInverse");const bt=K.skeleton;bt&&(bt.boneTexture===null&&bt.computeBoneTexture(),ht.setValue(T,"boneTexture",bt.boneTexture,Te))}K.isBatchedMesh&&(ht.setOptional(T,K,"batchingTexture"),ht.setValue(T,"batchingTexture",K._matricesTexture,Te),ht.setOptional(T,K,"batchingIdTexture"),ht.setValue(T,"batchingIdTexture",K._indirectTexture,Te),ht.setOptional(T,K,"batchingColorTexture"),K._colorsTexture!==null&&ht.setValue(T,"batchingColorTexture",K._colorsTexture,Te));const Xt=ee.morphAttributes;if((Xt.position!==void 0||Xt.normal!==void 0||Xt.color!==void 0)&&ke.update(K,ee,Bt),(Ht||Be.receiveShadow!==K.receiveShadow)&&(Be.receiveShadow=K.receiveShadow,ht.setValue(T,"receiveShadow",K.receiveShadow)),te.isMeshGouraudMaterial&&te.envMap!==null&&(Dt.envMap.value=Oe,Dt.flipEnvMap.value=Oe.isCubeTexture&&Oe.isRenderTargetTexture===!1?-1:1),te.isMeshStandardMaterial&&te.envMap===null&&Y.environment!==null&&(Dt.envMapIntensity.value=Y.environmentIntensity),Dt.dfgLUT!==void 0&&(Dt.dfgLUT.value=BS()),Ht&&(ht.setValue(T,"toneMappingExposure",y.toneMappingExposure),Be.needsLights&&Dc(Dt,Ki),xe&&te.fog===!0&&Ne.refreshFogUniforms(Dt,xe),Ne.refreshMaterialUniforms(Dt,te,le,pe,A.state.transmissionRenderTarget[L.id]),Zr.upload(T,po(Be),Dt,Te)),te.isShaderMaterial&&te.uniformsNeedUpdate===!0&&(Zr.upload(T,po(Be),Dt,Te),te.uniformsNeedUpdate=!1),te.isSpriteMaterial&&ht.setValue(T,"center",K.center),ht.setValue(T,"modelViewMatrix",K.modelViewMatrix),ht.setValue(T,"normalMatrix",K.normalMatrix),ht.setValue(T,"modelMatrix",K.matrixWorld),te.isShaderMaterial||te.isRawShaderMaterial){const bt=te.uniformsGroups;for(let Pt=0,us=bt.length;Pt<us;Pt++){const jn=bt[Pt];Ie.update(jn,Bt),Ie.bind(jn,Bt)}}return Bt}function Dc(L,Y){L.ambientLightColor.needsUpdate=Y,L.lightProbe.needsUpdate=Y,L.directionalLights.needsUpdate=Y,L.directionalLightShadows.needsUpdate=Y,L.pointLights.needsUpdate=Y,L.pointLightShadows.needsUpdate=Y,L.spotLights.needsUpdate=Y,L.spotLightShadows.needsUpdate=Y,L.rectAreaLights.needsUpdate=Y,L.hemisphereLights.needsUpdate=Y}function Pc(L){return L.isMeshLambertMaterial||L.isMeshToonMaterial||L.isMeshPhongMaterial||L.isMeshStandardMaterial||L.isShadowMaterial||L.isShaderMaterial&&L.lights===!0}this.getActiveCubeFace=function(){return w},this.getActiveMipmapLevel=function(){return I},this.getRenderTarget=function(){return _},this.setRenderTargetTextures=function(L,Y,ee){const te=ce.get(L);te.__autoAllocateDepthBuffer=L.resolveDepthBuffer===!1,te.__autoAllocateDepthBuffer===!1&&(te.__useRenderToTexture=!1),ce.get(L.texture).__webglTexture=Y,ce.get(L.depthTexture).__webglTexture=te.__autoAllocateDepthBuffer?void 0:ee,te.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(L,Y){const ee=ce.get(L);ee.__webglFramebuffer=Y,ee.__useDefaultFramebuffer=Y===void 0};const Uc=T.createFramebuffer();this.setRenderTarget=function(L,Y=0,ee=0){_=L,w=Y,I=ee;let te=!0,K=null,xe=!1,Le=!1;if(L){const Oe=ce.get(L);if(Oe.__useDefaultFramebuffer!==void 0)b.bindFramebuffer(T.FRAMEBUFFER,null),te=!1;else if(Oe.__webglFramebuffer===void 0)Te.setupRenderTarget(L);else if(Oe.__hasExternalTextures)Te.rebindTextures(L,ce.get(L.texture).__webglTexture,ce.get(L.depthTexture).__webglTexture);else if(L.depthBuffer){const Fe=L.depthTexture;if(Oe.__boundDepthTexture!==Fe){if(Fe!==null&&ce.has(Fe)&&(L.width!==Fe.image.width||L.height!==Fe.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Te.setupDepthRenderbuffer(L)}}const Ve=L.texture;(Ve.isData3DTexture||Ve.isDataArrayTexture||Ve.isCompressedArrayTexture)&&(Le=!0);const We=ce.get(L).__webglFramebuffer;L.isWebGLCubeRenderTarget?(Array.isArray(We[Y])?K=We[Y][ee]:K=We[Y],xe=!0):L.samples>0&&Te.useMultisampledRTT(L)===!1?K=ce.get(L).__webglMultisampledFramebuffer:Array.isArray(We)?K=We[ee]:K=We,Z.copy(L.viewport),j.copy(L.scissor),$=L.scissorTest}else Z.copy(He).multiplyScalar(le).floor(),j.copy(X).multiplyScalar(le).floor(),$=U;if(ee!==0&&(K=Uc),b.bindFramebuffer(T.FRAMEBUFFER,K)&&te&&b.drawBuffers(L,K),b.viewport(Z),b.scissor(j),b.setScissorTest($),xe){const Oe=ce.get(L.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_CUBE_MAP_POSITIVE_X+Y,Oe.__webglTexture,ee)}else if(Le){const Oe=Y;for(let Ve=0;Ve<L.textures.length;Ve++){const We=ce.get(L.textures[Ve]);T.framebufferTextureLayer(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0+Ve,We.__webglTexture,ee,Oe)}}else if(L!==null&&ee!==0){const Oe=ce.get(L.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,Oe.__webglTexture,ee)}P=-1},this.readRenderTargetPixels=function(L,Y,ee,te,K,xe,Le,Pe=0){if(!(L&&L.isWebGLRenderTarget)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Oe=ce.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&Le!==void 0&&(Oe=Oe[Le]),Oe){b.bindFramebuffer(T.FRAMEBUFFER,Oe);try{const Ve=L.textures[Pe],We=Ve.format,Fe=Ve.type;if(!D.textureFormatReadable(We)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!D.textureTypeReadable(Fe)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Y>=0&&Y<=L.width-te&&ee>=0&&ee<=L.height-K&&(L.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Pe),T.readPixels(Y,ee,te,K,ze.convert(We),ze.convert(Fe),xe))}finally{const Ve=_!==null?ce.get(_).__webglFramebuffer:null;b.bindFramebuffer(T.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(L,Y,ee,te,K,xe,Le,Pe=0){if(!(L&&L.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Oe=ce.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&Le!==void 0&&(Oe=Oe[Le]),Oe)if(Y>=0&&Y<=L.width-te&&ee>=0&&ee<=L.height-K){b.bindFramebuffer(T.FRAMEBUFFER,Oe);const Ve=L.textures[Pe],We=Ve.format,Fe=Ve.type;if(!D.textureFormatReadable(We))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!D.textureTypeReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const je=T.createBuffer();T.bindBuffer(T.PIXEL_PACK_BUFFER,je),T.bufferData(T.PIXEL_PACK_BUFFER,xe.byteLength,T.STREAM_READ),L.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Pe),T.readPixels(Y,ee,te,K,ze.convert(We),ze.convert(Fe),0);const it=_!==null?ce.get(_).__webglFramebuffer:null;b.bindFramebuffer(T.FRAMEBUFFER,it);const pt=T.fenceSync(T.SYNC_GPU_COMMANDS_COMPLETE,0);return T.flush(),await Cu(T,pt,4),T.bindBuffer(T.PIXEL_PACK_BUFFER,je),T.getBufferSubData(T.PIXEL_PACK_BUFFER,0,xe),T.deleteBuffer(je),T.deleteSync(pt),xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(L,Y=null,ee=0){const te=Math.pow(2,-ee),K=Math.floor(L.image.width*te),xe=Math.floor(L.image.height*te),Le=Y!==null?Y.x:0,Pe=Y!==null?Y.y:0;Te.setTexture2D(L,0),T.copyTexSubImage2D(T.TEXTURE_2D,ee,0,0,Le,Pe,K,xe),b.unbindTexture()};const wc=T.createFramebuffer(),Fc=T.createFramebuffer();this.copyTextureToTexture=function(L,Y,ee=null,te=null,K=0,xe=null){xe===null&&(K!==0?(cr("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),xe=K,K=0):xe=0);let Le,Pe,Oe,Ve,We,Fe,je,it,pt;const Et=L.isCompressedTexture?L.mipmaps[xe]:L.image;if(ee!==null)Le=ee.max.x-ee.min.x,Pe=ee.max.y-ee.min.y,Oe=ee.isBox3?ee.max.z-ee.min.z:1,Ve=ee.min.x,We=ee.min.y,Fe=ee.isBox3?ee.min.z:0;else{const Xt=Math.pow(2,-K);Le=Math.floor(Et.width*Xt),Pe=Math.floor(Et.height*Xt),L.isDataArrayTexture?Oe=Et.depth:L.isData3DTexture?Oe=Math.floor(Et.depth*Xt):Oe=1,Ve=0,We=0,Fe=0}te!==null?(je=te.x,it=te.y,pt=te.z):(je=0,it=0,pt=0);const at=ze.convert(Y.format),Be=ze.convert(Y.type);let ut;Y.isData3DTexture?(Te.setTexture3D(Y,0),ut=T.TEXTURE_3D):Y.isDataArrayTexture||Y.isCompressedArrayTexture?(Te.setTexture2DArray(Y,0),ut=T.TEXTURE_2D_ARRAY):(Te.setTexture2D(Y,0),ut=T.TEXTURE_2D),T.pixelStorei(T.UNPACK_FLIP_Y_WEBGL,Y.flipY),T.pixelStorei(T.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),T.pixelStorei(T.UNPACK_ALIGNMENT,Y.unpackAlignment);const Qe=T.getParameter(T.UNPACK_ROW_LENGTH),Bt=T.getParameter(T.UNPACK_IMAGE_HEIGHT),fi=T.getParameter(T.UNPACK_SKIP_PIXELS),Ht=T.getParameter(T.UNPACK_SKIP_ROWS),Ki=T.getParameter(T.UNPACK_SKIP_IMAGES);T.pixelStorei(T.UNPACK_ROW_LENGTH,Et.width),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,Et.height),T.pixelStorei(T.UNPACK_SKIP_PIXELS,Ve),T.pixelStorei(T.UNPACK_SKIP_ROWS,We),T.pixelStorei(T.UNPACK_SKIP_IMAGES,Fe);const ht=L.isDataArrayTexture||L.isData3DTexture,Dt=Y.isDataArrayTexture||Y.isData3DTexture;if(L.isDepthTexture){const Xt=ce.get(L),bt=ce.get(Y),Pt=ce.get(Xt.__renderTarget),us=ce.get(bt.__renderTarget);b.bindFramebuffer(T.READ_FRAMEBUFFER,Pt.__webglFramebuffer),b.bindFramebuffer(T.DRAW_FRAMEBUFFER,us.__webglFramebuffer);for(let jn=0;jn<Oe;jn++)ht&&(T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ce.get(L).__webglTexture,K,Fe+jn),T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ce.get(Y).__webglTexture,xe,pt+jn)),T.blitFramebuffer(Ve,We,Le,Pe,je,it,Le,Pe,T.DEPTH_BUFFER_BIT,T.NEAREST);b.bindFramebuffer(T.READ_FRAMEBUFFER,null),b.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else if(K!==0||L.isRenderTargetTexture||ce.has(L)){const Xt=ce.get(L),bt=ce.get(Y);b.bindFramebuffer(T.READ_FRAMEBUFFER,wc),b.bindFramebuffer(T.DRAW_FRAMEBUFFER,Fc);for(let Pt=0;Pt<Oe;Pt++)ht?T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,Xt.__webglTexture,K,Fe+Pt):T.framebufferTexture2D(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,Xt.__webglTexture,K),Dt?T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,bt.__webglTexture,xe,pt+Pt):T.framebufferTexture2D(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,bt.__webglTexture,xe),K!==0?T.blitFramebuffer(Ve,We,Le,Pe,je,it,Le,Pe,T.COLOR_BUFFER_BIT,T.NEAREST):Dt?T.copyTexSubImage3D(ut,xe,je,it,pt+Pt,Ve,We,Le,Pe):T.copyTexSubImage2D(ut,xe,je,it,Ve,We,Le,Pe);b.bindFramebuffer(T.READ_FRAMEBUFFER,null),b.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else Dt?L.isDataTexture||L.isData3DTexture?T.texSubImage3D(ut,xe,je,it,pt,Le,Pe,Oe,at,Be,Et.data):Y.isCompressedArrayTexture?T.compressedTexSubImage3D(ut,xe,je,it,pt,Le,Pe,Oe,at,Et.data):T.texSubImage3D(ut,xe,je,it,pt,Le,Pe,Oe,at,Be,Et):L.isDataTexture?T.texSubImage2D(T.TEXTURE_2D,xe,je,it,Le,Pe,at,Be,Et.data):L.isCompressedTexture?T.compressedTexSubImage2D(T.TEXTURE_2D,xe,je,it,Et.width,Et.height,at,Et.data):T.texSubImage2D(T.TEXTURE_2D,xe,je,it,Le,Pe,at,Be,Et);T.pixelStorei(T.UNPACK_ROW_LENGTH,Qe),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,Bt),T.pixelStorei(T.UNPACK_SKIP_PIXELS,fi),T.pixelStorei(T.UNPACK_SKIP_ROWS,Ht),T.pixelStorei(T.UNPACK_SKIP_IMAGES,Ki),xe===0&&Y.generateMipmaps&&T.generateMipmap(ut),b.unbindTexture()},this.initRenderTarget=function(L){ce.get(L).__webglFramebuffer===void 0&&Te.setupRenderTarget(L)},this.initTexture=function(L){L.isCubeTexture?Te.setTextureCube(L,0):L.isData3DTexture?Te.setTexture3D(L,0):L.isDataArrayTexture||L.isCompressedArrayTexture?Te.setTexture2DArray(L,0):Te.setTexture2D(L,0),b.unbindTexture()},this.resetState=function(){w=0,I=0,_=null,b.reset(),F.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return mn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=$e._getDrawingBufferColorSpace(e),t.unpackColorSpace=$e._getUnpackColorSpace()}}var $i=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},Ws={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var gl;function GS(){return gl||(gl=1,(function(i){(function(){var e=function(){this.init()};e.prototype={init:function(){var a=this||t;return a._counter=1e3,a._html5AudioPool=[],a.html5PoolSize=10,a._codecs={},a._howls=[],a._muted=!1,a._volume=1,a._canPlayEvent="canplaythrough",a._navigator=typeof window<"u"&&window.navigator?window.navigator:null,a.masterGain=null,a.noAudio=!1,a.usingWebAudio=!0,a.autoSuspend=!0,a.ctx=null,a.autoUnlock=!0,a._setup(),a},volume:function(a){var l=this||t;if(a=parseFloat(a),l.ctx||p(),typeof a<"u"&&a>=0&&a<=1){if(l._volume=a,l._muted)return l;l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a,t.ctx.currentTime);for(var u=0;u<l._howls.length;u++)if(!l._howls[u]._webAudio)for(var E=l._howls[u]._getSoundIds(),m=0;m<E.length;m++){var S=l._howls[u]._soundById(E[m]);S&&S._node&&(S._node.volume=S._volume*a)}return l}return l._volume},mute:function(a){var l=this||t;l.ctx||p(),l._muted=a,l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a?0:l._volume,t.ctx.currentTime);for(var u=0;u<l._howls.length;u++)if(!l._howls[u]._webAudio)for(var E=l._howls[u]._getSoundIds(),m=0;m<E.length;m++){var S=l._howls[u]._soundById(E[m]);S&&S._node&&(S._node.muted=a?!0:S._muted)}return l},stop:function(){for(var a=this||t,l=0;l<a._howls.length;l++)a._howls[l].stop();return a},unload:function(){for(var a=this||t,l=a._howls.length-1;l>=0;l--)a._howls[l].unload();return a.usingWebAudio&&a.ctx&&typeof a.ctx.close<"u"&&(a.ctx.close(),a.ctx=null,p()),a},codecs:function(a){return(this||t)._codecs[a.replace(/^x-/,"")]},_setup:function(){var a=this||t;if(a.state=a.ctx&&a.ctx.state||"suspended",a._autoSuspend(),!a.usingWebAudio)if(typeof Audio<"u")try{var l=new Audio;typeof l.oncanplaythrough>"u"&&(a._canPlayEvent="canplay")}catch{a.noAudio=!0}else a.noAudio=!0;try{var l=new Audio;l.muted&&(a.noAudio=!0)}catch{}return a.noAudio||a._setupCodecs(),a},_setupCodecs:function(){var a=this||t,l=null;try{l=typeof Audio<"u"?new Audio:null}catch{return a}if(!l||typeof l.canPlayType!="function")return a;var u=l.canPlayType("audio/mpeg;").replace(/^no$/,""),E=a._navigator?a._navigator.userAgent:"",m=E.match(/OPR\/(\d+)/g),S=m&&parseInt(m[0].split("/")[1],10)<33,f=E.indexOf("Safari")!==-1&&E.indexOf("Chrome")===-1,v=E.match(/Version\/(.*?) /),A=f&&v&&parseInt(v[1],10)<15;return a._codecs={mp3:!!(!S&&(u||l.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!u,opus:!!l.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(l.canPlayType('audio/wav; codecs="1"')||l.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!l.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!l.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(l.canPlayType("audio/x-m4a;")||l.canPlayType("audio/m4a;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(l.canPlayType("audio/x-m4b;")||l.canPlayType("audio/m4b;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(l.canPlayType("audio/x-mp4;")||l.canPlayType("audio/mp4;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!l.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(l.canPlayType("audio/x-flac;")||l.canPlayType("audio/flac;")).replace(/^no$/,"")},a},_unlockAudio:function(){var a=this||t;if(!(a._audioUnlocked||!a.ctx)){a._audioUnlocked=!1,a.autoUnlock=!1,!a._mobileUnloaded&&a.ctx.sampleRate!==44100&&(a._mobileUnloaded=!0,a.unload()),a._scratchBuffer=a.ctx.createBuffer(1,1,22050);var l=function(u){for(;a._html5AudioPool.length<a.html5PoolSize;)try{var E=new Audio;E._unlocked=!0,a._releaseHtml5Audio(E)}catch{a.noAudio=!0;break}for(var m=0;m<a._howls.length;m++)if(!a._howls[m]._webAudio)for(var S=a._howls[m]._getSoundIds(),f=0;f<S.length;f++){var v=a._howls[m]._soundById(S[f]);v&&v._node&&!v._node._unlocked&&(v._node._unlocked=!0,v._node.load())}a._autoResume();var A=a.ctx.createBufferSource();A.buffer=a._scratchBuffer,A.connect(a.ctx.destination),typeof A.start>"u"?A.noteOn(0):A.start(0),typeof a.ctx.resume=="function"&&a.ctx.resume(),A.onended=function(){A.disconnect(0),a._audioUnlocked=!0,document.removeEventListener("touchstart",l,!0),document.removeEventListener("touchend",l,!0),document.removeEventListener("click",l,!0),document.removeEventListener("keydown",l,!0);for(var R=0;R<a._howls.length;R++)a._howls[R]._emit("unlock")}};return document.addEventListener("touchstart",l,!0),document.addEventListener("touchend",l,!0),document.addEventListener("click",l,!0),document.addEventListener("keydown",l,!0),a}},_obtainHtml5Audio:function(){var a=this||t;if(a._html5AudioPool.length)return a._html5AudioPool.pop();var l=new Audio().play();return l&&typeof Promise<"u"&&(l instanceof Promise||typeof l.then=="function")&&l.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(a){var l=this||t;return a._unlocked&&l._html5AudioPool.push(a),l},_autoSuspend:function(){var a=this;if(!(!a.autoSuspend||!a.ctx||typeof a.ctx.suspend>"u"||!t.usingWebAudio)){for(var l=0;l<a._howls.length;l++)if(a._howls[l]._webAudio){for(var u=0;u<a._howls[l]._sounds.length;u++)if(!a._howls[l]._sounds[u]._paused)return a}return a._suspendTimer&&clearTimeout(a._suspendTimer),a._suspendTimer=setTimeout(function(){if(a.autoSuspend){a._suspendTimer=null,a.state="suspending";var E=function(){a.state="suspended",a._resumeAfterSuspend&&(delete a._resumeAfterSuspend,a._autoResume())};a.ctx.suspend().then(E,E)}},3e4),a}},_autoResume:function(){var a=this;if(!(!a.ctx||typeof a.ctx.resume>"u"||!t.usingWebAudio))return a.state==="running"&&a.ctx.state!=="interrupted"&&a._suspendTimer?(clearTimeout(a._suspendTimer),a._suspendTimer=null):a.state==="suspended"||a.state==="running"&&a.ctx.state==="interrupted"?(a.ctx.resume().then(function(){a.state="running";for(var l=0;l<a._howls.length;l++)a._howls[l]._emit("resume")}),a._suspendTimer&&(clearTimeout(a._suspendTimer),a._suspendTimer=null)):a.state==="suspending"&&(a._resumeAfterSuspend=!0),a}};var t=new e,n=function(a){var l=this;if(!a.src||a.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}l.init(a)};n.prototype={init:function(a){var l=this;return t.ctx||p(),l._autoplay=a.autoplay||!1,l._format=typeof a.format!="string"?a.format:[a.format],l._html5=a.html5||!1,l._muted=a.mute||!1,l._loop=a.loop||!1,l._pool=a.pool||5,l._preload=typeof a.preload=="boolean"||a.preload==="metadata"?a.preload:!0,l._rate=a.rate||1,l._sprite=a.sprite||{},l._src=typeof a.src!="string"?a.src:[a.src],l._volume=a.volume!==void 0?a.volume:1,l._xhr={method:a.xhr&&a.xhr.method?a.xhr.method:"GET",headers:a.xhr&&a.xhr.headers?a.xhr.headers:null,withCredentials:a.xhr&&a.xhr.withCredentials?a.xhr.withCredentials:!1},l._duration=0,l._state="unloaded",l._sounds=[],l._endTimers={},l._queue=[],l._playLock=!1,l._onend=a.onend?[{fn:a.onend}]:[],l._onfade=a.onfade?[{fn:a.onfade}]:[],l._onload=a.onload?[{fn:a.onload}]:[],l._onloaderror=a.onloaderror?[{fn:a.onloaderror}]:[],l._onplayerror=a.onplayerror?[{fn:a.onplayerror}]:[],l._onpause=a.onpause?[{fn:a.onpause}]:[],l._onplay=a.onplay?[{fn:a.onplay}]:[],l._onstop=a.onstop?[{fn:a.onstop}]:[],l._onmute=a.onmute?[{fn:a.onmute}]:[],l._onvolume=a.onvolume?[{fn:a.onvolume}]:[],l._onrate=a.onrate?[{fn:a.onrate}]:[],l._onseek=a.onseek?[{fn:a.onseek}]:[],l._onunlock=a.onunlock?[{fn:a.onunlock}]:[],l._onresume=[],l._webAudio=t.usingWebAudio&&!l._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(l),l._autoplay&&l._queue.push({event:"play",action:function(){l.play()}}),l._preload&&l._preload!=="none"&&l.load(),l},load:function(){var a=this,l=null;if(t.noAudio){a._emit("loaderror",null,"No audio support.");return}typeof a._src=="string"&&(a._src=[a._src]);for(var u=0;u<a._src.length;u++){var E,m;if(a._format&&a._format[u])E=a._format[u];else{if(m=a._src[u],typeof m!="string"){a._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}E=/^data:audio\/([^;,]+);/i.exec(m),E||(E=/\.([^.]+)$/.exec(m.split("?",1)[0])),E&&(E=E[1].toLowerCase())}if(E||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),E&&t.codecs(E)){l=a._src[u];break}}if(!l){a._emit("loaderror",null,"No codec support for selected audio sources.");return}return a._src=l,a._state="loading",window.location.protocol==="https:"&&l.slice(0,5)==="http:"&&(a._html5=!0,a._webAudio=!1),new r(a),a._webAudio&&o(a),a},play:function(a,l){var u=this,E=null;if(typeof a=="number")E=a,a=null;else{if(typeof a=="string"&&u._state==="loaded"&&!u._sprite[a])return null;if(typeof a>"u"&&(a="__default",!u._playLock)){for(var m=0,S=0;S<u._sounds.length;S++)u._sounds[S]._paused&&!u._sounds[S]._ended&&(m++,E=u._sounds[S]._id);m===1?a=null:E=null}}var f=E?u._soundById(E):u._inactiveSound();if(!f)return null;if(E&&!a&&(a=f._sprite||"__default"),u._state!=="loaded"){f._sprite=a,f._ended=!1;var v=f._id;return u._queue.push({event:"play",action:function(){u.play(v)}}),v}if(E&&!f._paused)return l||u._loadQueue("play"),f._id;u._webAudio&&t._autoResume();var A=Math.max(0,f._seek>0?f._seek:u._sprite[a][0]/1e3),R=Math.max(0,(u._sprite[a][0]+u._sprite[a][1])/1e3-A),C=R*1e3/Math.abs(f._rate),y=u._sprite[a][0]/1e3,N=(u._sprite[a][0]+u._sprite[a][1])/1e3;f._sprite=a,f._ended=!1;var w=function(){f._paused=!1,f._seek=A,f._start=y,f._stop=N,f._loop=!!(f._loop||u._sprite[a][2])};if(A>=N){u._ended(f);return}var I=f._node;if(u._webAudio){var _=function(){u._playLock=!1,w(),u._refreshBuffer(f);var j=f._muted||u._muted?0:f._volume;I.gain.setValueAtTime(j,t.ctx.currentTime),f._playStart=t.ctx.currentTime,typeof I.bufferSource.start>"u"?f._loop?I.bufferSource.noteGrainOn(0,A,86400):I.bufferSource.noteGrainOn(0,A,R):f._loop?I.bufferSource.start(0,A,86400):I.bufferSource.start(0,A,R),C!==1/0&&(u._endTimers[f._id]=setTimeout(u._ended.bind(u,f),C)),l||setTimeout(function(){u._emit("play",f._id),u._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?_():(u._playLock=!0,u.once("resume",_),u._clearTimer(f._id))}else{var P=function(){I.currentTime=A,I.muted=f._muted||u._muted||t._muted||I.muted,I.volume=f._volume*t.volume(),I.playbackRate=f._rate;try{var j=I.play();if(j&&typeof Promise<"u"&&(j instanceof Promise||typeof j.then=="function")?(u._playLock=!0,w(),j.then(function(){u._playLock=!1,I._unlocked=!0,l?u._loadQueue():u._emit("play",f._id)}).catch(function(){u._playLock=!1,u._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),f._ended=!0,f._paused=!0})):l||(u._playLock=!1,w(),u._emit("play",f._id)),I.playbackRate=f._rate,I.paused){u._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}a!=="__default"||f._loop?u._endTimers[f._id]=setTimeout(u._ended.bind(u,f),C):(u._endTimers[f._id]=function(){u._ended(f),I.removeEventListener("ended",u._endTimers[f._id],!1)},I.addEventListener("ended",u._endTimers[f._id],!1))}catch($){u._emit("playerror",f._id,$)}};I.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(I.src=u._src,I.load());var G=window&&window.ejecta||!I.readyState&&t._navigator.isCocoonJS;if(I.readyState>=3||G)P();else{u._playLock=!0,u._state="loading";var Z=function(){u._state="loaded",P(),I.removeEventListener(t._canPlayEvent,Z,!1)};I.addEventListener(t._canPlayEvent,Z,!1),u._clearTimer(f._id)}}return f._id},pause:function(a){var l=this;if(l._state!=="loaded"||l._playLock)return l._queue.push({event:"pause",action:function(){l.pause(a)}}),l;for(var u=l._getSoundIds(a),E=0;E<u.length;E++){l._clearTimer(u[E]);var m=l._soundById(u[E]);if(m&&!m._paused&&(m._seek=l.seek(u[E]),m._rateSeek=0,m._paused=!0,l._stopFade(u[E]),m._node))if(l._webAudio){if(!m._node.bufferSource)continue;typeof m._node.bufferSource.stop>"u"?m._node.bufferSource.noteOff(0):m._node.bufferSource.stop(0),l._cleanBuffer(m._node)}else(!isNaN(m._node.duration)||m._node.duration===1/0)&&m._node.pause();arguments[1]||l._emit("pause",m?m._id:null)}return l},stop:function(a,l){var u=this;if(u._state!=="loaded"||u._playLock)return u._queue.push({event:"stop",action:function(){u.stop(a)}}),u;for(var E=u._getSoundIds(a),m=0;m<E.length;m++){u._clearTimer(E[m]);var S=u._soundById(E[m]);S&&(S._seek=S._start||0,S._rateSeek=0,S._paused=!0,S._ended=!0,u._stopFade(E[m]),S._node&&(u._webAudio?S._node.bufferSource&&(typeof S._node.bufferSource.stop>"u"?S._node.bufferSource.noteOff(0):S._node.bufferSource.stop(0),u._cleanBuffer(S._node)):(!isNaN(S._node.duration)||S._node.duration===1/0)&&(S._node.currentTime=S._start||0,S._node.pause(),S._node.duration===1/0&&u._clearSound(S._node))),l||u._emit("stop",S._id))}return u},mute:function(a,l){var u=this;if(u._state!=="loaded"||u._playLock)return u._queue.push({event:"mute",action:function(){u.mute(a,l)}}),u;if(typeof l>"u")if(typeof a=="boolean")u._muted=a;else return u._muted;for(var E=u._getSoundIds(l),m=0;m<E.length;m++){var S=u._soundById(E[m]);S&&(S._muted=a,S._interval&&u._stopFade(S._id),u._webAudio&&S._node?S._node.gain.setValueAtTime(a?0:S._volume,t.ctx.currentTime):S._node&&(S._node.muted=t._muted?!0:a),u._emit("mute",S._id))}return u},volume:function(){var a=this,l=arguments,u,E;if(l.length===0)return a._volume;if(l.length===1||l.length===2&&typeof l[1]>"u"){var m=a._getSoundIds(),S=m.indexOf(l[0]);S>=0?E=parseInt(l[0],10):u=parseFloat(l[0])}else l.length>=2&&(u=parseFloat(l[0]),E=parseInt(l[1],10));var f;if(typeof u<"u"&&u>=0&&u<=1){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"volume",action:function(){a.volume.apply(a,l)}}),a;typeof E>"u"&&(a._volume=u),E=a._getSoundIds(E);for(var v=0;v<E.length;v++)f=a._soundById(E[v]),f&&(f._volume=u,l[2]||a._stopFade(E[v]),a._webAudio&&f._node&&!f._muted?f._node.gain.setValueAtTime(u,t.ctx.currentTime):f._node&&!f._muted&&(f._node.volume=u*t.volume()),a._emit("volume",f._id))}else return f=E?a._soundById(E):a._sounds[0],f?f._volume:0;return a},fade:function(a,l,u,E){var m=this;if(m._state!=="loaded"||m._playLock)return m._queue.push({event:"fade",action:function(){m.fade(a,l,u,E)}}),m;a=Math.min(Math.max(0,parseFloat(a)),1),l=Math.min(Math.max(0,parseFloat(l)),1),u=parseFloat(u),m.volume(a,E);for(var S=m._getSoundIds(E),f=0;f<S.length;f++){var v=m._soundById(S[f]);if(v){if(E||m._stopFade(S[f]),m._webAudio&&!v._muted){var A=t.ctx.currentTime,R=A+u/1e3;v._volume=a,v._node.gain.setValueAtTime(a,A),v._node.gain.linearRampToValueAtTime(l,R)}m._startFadeInterval(v,a,l,u,S[f],typeof E>"u")}}return m},_startFadeInterval:function(a,l,u,E,m,S){var f=this,v=l,A=u-l,R=Math.abs(A/.01),C=Math.max(4,R>0?E/R:E),y=Date.now();a._fadeTo=u,a._interval=setInterval(function(){var N=(Date.now()-y)/E;y=Date.now(),v+=A*N,v=Math.round(v*100)/100,A<0?v=Math.max(u,v):v=Math.min(u,v),f._webAudio?a._volume=v:f.volume(v,a._id,!0),S&&(f._volume=v),(u<l&&v<=u||u>l&&v>=u)&&(clearInterval(a._interval),a._interval=null,a._fadeTo=null,f.volume(u,a._id),f._emit("fade",a._id))},C)},_stopFade:function(a){var l=this,u=l._soundById(a);return u&&u._interval&&(l._webAudio&&u._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(u._interval),u._interval=null,l.volume(u._fadeTo,a),u._fadeTo=null,l._emit("fade",a)),l},loop:function(){var a=this,l=arguments,u,E,m;if(l.length===0)return a._loop;if(l.length===1)if(typeof l[0]=="boolean")u=l[0],a._loop=u;else return m=a._soundById(parseInt(l[0],10)),m?m._loop:!1;else l.length===2&&(u=l[0],E=parseInt(l[1],10));for(var S=a._getSoundIds(E),f=0;f<S.length;f++)m=a._soundById(S[f]),m&&(m._loop=u,a._webAudio&&m._node&&m._node.bufferSource&&(m._node.bufferSource.loop=u,u&&(m._node.bufferSource.loopStart=m._start||0,m._node.bufferSource.loopEnd=m._stop,a.playing(S[f])&&(a.pause(S[f],!0),a.play(S[f],!0)))));return a},rate:function(){var a=this,l=arguments,u,E;if(l.length===0)E=a._sounds[0]._id;else if(l.length===1){var m=a._getSoundIds(),S=m.indexOf(l[0]);S>=0?E=parseInt(l[0],10):u=parseFloat(l[0])}else l.length===2&&(u=parseFloat(l[0]),E=parseInt(l[1],10));var f;if(typeof u=="number"){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"rate",action:function(){a.rate.apply(a,l)}}),a;typeof E>"u"&&(a._rate=u),E=a._getSoundIds(E);for(var v=0;v<E.length;v++)if(f=a._soundById(E[v]),f){a.playing(E[v])&&(f._rateSeek=a.seek(E[v]),f._playStart=a._webAudio?t.ctx.currentTime:f._playStart),f._rate=u,a._webAudio&&f._node&&f._node.bufferSource?f._node.bufferSource.playbackRate.setValueAtTime(u,t.ctx.currentTime):f._node&&(f._node.playbackRate=u);var A=a.seek(E[v]),R=(a._sprite[f._sprite][0]+a._sprite[f._sprite][1])/1e3-A,C=R*1e3/Math.abs(f._rate);(a._endTimers[E[v]]||!f._paused)&&(a._clearTimer(E[v]),a._endTimers[E[v]]=setTimeout(a._ended.bind(a,f),C)),a._emit("rate",f._id)}}else return f=a._soundById(E),f?f._rate:a._rate;return a},seek:function(){var a=this,l=arguments,u,E;if(l.length===0)a._sounds.length&&(E=a._sounds[0]._id);else if(l.length===1){var m=a._getSoundIds(),S=m.indexOf(l[0]);S>=0?E=parseInt(l[0],10):a._sounds.length&&(E=a._sounds[0]._id,u=parseFloat(l[0]))}else l.length===2&&(u=parseFloat(l[0]),E=parseInt(l[1],10));if(typeof E>"u")return 0;if(typeof u=="number"&&(a._state!=="loaded"||a._playLock))return a._queue.push({event:"seek",action:function(){a.seek.apply(a,l)}}),a;var f=a._soundById(E);if(f)if(typeof u=="number"&&u>=0){var v=a.playing(E);v&&a.pause(E,!0),f._seek=u,f._ended=!1,a._clearTimer(E),!a._webAudio&&f._node&&!isNaN(f._node.duration)&&(f._node.currentTime=u);var A=function(){v&&a.play(E,!0),a._emit("seek",E)};if(v&&!a._webAudio){var R=function(){a._playLock?setTimeout(R,0):A()};setTimeout(R,0)}else A()}else if(a._webAudio){var C=a.playing(E)?t.ctx.currentTime-f._playStart:0,y=f._rateSeek?f._rateSeek-f._seek:0;return f._seek+(y+C*Math.abs(f._rate))}else return f._node.currentTime;return a},playing:function(a){var l=this;if(typeof a=="number"){var u=l._soundById(a);return u?!u._paused:!1}for(var E=0;E<l._sounds.length;E++)if(!l._sounds[E]._paused)return!0;return!1},duration:function(a){var l=this,u=l._duration,E=l._soundById(a);return E&&(u=l._sprite[E._sprite][1]/1e3),u},state:function(){return this._state},unload:function(){for(var a=this,l=a._sounds,u=0;u<l.length;u++)l[u]._paused||a.stop(l[u]._id),a._webAudio||(a._clearSound(l[u]._node),l[u]._node.removeEventListener("error",l[u]._errorFn,!1),l[u]._node.removeEventListener(t._canPlayEvent,l[u]._loadFn,!1),l[u]._node.removeEventListener("ended",l[u]._endFn,!1),t._releaseHtml5Audio(l[u]._node)),delete l[u]._node,a._clearTimer(l[u]._id);var E=t._howls.indexOf(a);E>=0&&t._howls.splice(E,1);var m=!0;for(u=0;u<t._howls.length;u++)if(t._howls[u]._src===a._src||a._src.indexOf(t._howls[u]._src)>=0){m=!1;break}return s&&m&&delete s[a._src],t.noAudio=!1,a._state="unloaded",a._sounds=[],a=null,null},on:function(a,l,u,E){var m=this,S=m["_on"+a];return typeof l=="function"&&S.push(E?{id:u,fn:l,once:E}:{id:u,fn:l}),m},off:function(a,l,u){var E=this,m=E["_on"+a],S=0;if(typeof l=="number"&&(u=l,l=null),l||u)for(S=0;S<m.length;S++){var f=u===m[S].id;if(l===m[S].fn&&f||!l&&f){m.splice(S,1);break}}else if(a)E["_on"+a]=[];else{var v=Object.keys(E);for(S=0;S<v.length;S++)v[S].indexOf("_on")===0&&Array.isArray(E[v[S]])&&(E[v[S]]=[])}return E},once:function(a,l,u){var E=this;return E.on(a,l,u,1),E},_emit:function(a,l,u){for(var E=this,m=E["_on"+a],S=m.length-1;S>=0;S--)(!m[S].id||m[S].id===l||a==="load")&&(setTimeout((function(f){f.call(this,l,u)}).bind(E,m[S].fn),0),m[S].once&&E.off(a,m[S].fn,m[S].id));return E._loadQueue(a),E},_loadQueue:function(a){var l=this;if(l._queue.length>0){var u=l._queue[0];u.event===a&&(l._queue.shift(),l._loadQueue()),a||u.action()}return l},_ended:function(a){var l=this,u=a._sprite;if(!l._webAudio&&a._node&&!a._node.paused&&!a._node.ended&&a._node.currentTime<a._stop)return setTimeout(l._ended.bind(l,a),100),l;var E=!!(a._loop||l._sprite[u][2]);if(l._emit("end",a._id),!l._webAudio&&E&&l.stop(a._id,!0).play(a._id),l._webAudio&&E){l._emit("play",a._id),a._seek=a._start||0,a._rateSeek=0,a._playStart=t.ctx.currentTime;var m=(a._stop-a._start)*1e3/Math.abs(a._rate);l._endTimers[a._id]=setTimeout(l._ended.bind(l,a),m)}return l._webAudio&&!E&&(a._paused=!0,a._ended=!0,a._seek=a._start||0,a._rateSeek=0,l._clearTimer(a._id),l._cleanBuffer(a._node),t._autoSuspend()),!l._webAudio&&!E&&l.stop(a._id,!0),l},_clearTimer:function(a){var l=this;if(l._endTimers[a]){if(typeof l._endTimers[a]!="function")clearTimeout(l._endTimers[a]);else{var u=l._soundById(a);u&&u._node&&u._node.removeEventListener("ended",l._endTimers[a],!1)}delete l._endTimers[a]}return l},_soundById:function(a){for(var l=this,u=0;u<l._sounds.length;u++)if(a===l._sounds[u]._id)return l._sounds[u];return null},_inactiveSound:function(){var a=this;a._drain();for(var l=0;l<a._sounds.length;l++)if(a._sounds[l]._ended)return a._sounds[l].reset();return new r(a)},_drain:function(){var a=this,l=a._pool,u=0,E=0;if(!(a._sounds.length<l)){for(E=0;E<a._sounds.length;E++)a._sounds[E]._ended&&u++;for(E=a._sounds.length-1;E>=0;E--){if(u<=l)return;a._sounds[E]._ended&&(a._webAudio&&a._sounds[E]._node&&a._sounds[E]._node.disconnect(0),a._sounds.splice(E,1),u--)}}},_getSoundIds:function(a){var l=this;if(typeof a>"u"){for(var u=[],E=0;E<l._sounds.length;E++)u.push(l._sounds[E]._id);return u}else return[a]},_refreshBuffer:function(a){var l=this;return a._node.bufferSource=t.ctx.createBufferSource(),a._node.bufferSource.buffer=s[l._src],a._panner?a._node.bufferSource.connect(a._panner):a._node.bufferSource.connect(a._node),a._node.bufferSource.loop=a._loop,a._loop&&(a._node.bufferSource.loopStart=a._start||0,a._node.bufferSource.loopEnd=a._stop||0),a._node.bufferSource.playbackRate.setValueAtTime(a._rate,t.ctx.currentTime),l},_cleanBuffer:function(a){var l=this,u=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!a.bufferSource)return l;if(t._scratchBuffer&&a.bufferSource&&(a.bufferSource.onended=null,a.bufferSource.disconnect(0),u))try{a.bufferSource.buffer=t._scratchBuffer}catch{}return a.bufferSource=null,l},_clearSound:function(a){var l=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);l||(a.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var r=function(a){this._parent=a,this.init()};r.prototype={init:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,l._sounds.push(a),a.create(),a},create:function(){var a=this,l=a._parent,u=t._muted||a._muted||a._parent._muted?0:a._volume;return l._webAudio?(a._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),a._node.gain.setValueAtTime(u,t.ctx.currentTime),a._node.paused=!0,a._node.connect(t.masterGain)):t.noAudio||(a._node=t._obtainHtml5Audio(),a._errorFn=a._errorListener.bind(a),a._node.addEventListener("error",a._errorFn,!1),a._loadFn=a._loadListener.bind(a),a._node.addEventListener(t._canPlayEvent,a._loadFn,!1),a._endFn=a._endListener.bind(a),a._node.addEventListener("ended",a._endFn,!1),a._node.src=l._src,a._node.preload=l._preload===!0?"auto":l._preload,a._node.volume=u*t.volume(),a._node.load()),a},reset:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._rateSeek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,a},_errorListener:function(){var a=this;a._parent._emit("loaderror",a._id,a._node.error?a._node.error.code:0),a._node.removeEventListener("error",a._errorFn,!1)},_loadListener:function(){var a=this,l=a._parent;l._duration=Math.ceil(a._node.duration*10)/10,Object.keys(l._sprite).length===0&&(l._sprite={__default:[0,l._duration*1e3]}),l._state!=="loaded"&&(l._state="loaded",l._emit("load"),l._loadQueue()),a._node.removeEventListener(t._canPlayEvent,a._loadFn,!1)},_endListener:function(){var a=this,l=a._parent;l._duration===1/0&&(l._duration=Math.ceil(a._node.duration*10)/10,l._sprite.__default[1]===1/0&&(l._sprite.__default[1]=l._duration*1e3),l._ended(a)),a._node.removeEventListener("ended",a._endFn,!1)}};var s={},o=function(a){var l=a._src;if(s[l]){a._duration=s[l].duration,h(a);return}if(/^data:[^;]+;base64,/.test(l)){for(var u=atob(l.split(",")[1]),E=new Uint8Array(u.length),m=0;m<u.length;++m)E[m]=u.charCodeAt(m);d(E.buffer,a)}else{var S=new XMLHttpRequest;S.open(a._xhr.method,l,!0),S.withCredentials=a._xhr.withCredentials,S.responseType="arraybuffer",a._xhr.headers&&Object.keys(a._xhr.headers).forEach(function(f){S.setRequestHeader(f,a._xhr.headers[f])}),S.onload=function(){var f=(S.status+"")[0];if(f!=="0"&&f!=="2"&&f!=="3"){a._emit("loaderror",null,"Failed loading audio file with status: "+S.status+".");return}d(S.response,a)},S.onerror=function(){a._webAudio&&(a._html5=!0,a._webAudio=!1,a._sounds=[],delete s[l],a.load())},c(S)}},c=function(a){try{a.send()}catch{a.onerror()}},d=function(a,l){var u=function(){l._emit("loaderror",null,"Decoding audio data failed.")},E=function(m){m&&l._sounds.length>0?(s[l._src]=m,h(l,m)):u()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(a).then(E).catch(u):t.ctx.decodeAudioData(a,E,u)},h=function(a,l){l&&!a._duration&&(a._duration=l.duration),Object.keys(a._sprite).length===0&&(a._sprite={__default:[0,a._duration*1e3]}),a._state!=="loaded"&&(a._state="loaded",a._emit("load"),a._loadQueue())},p=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var a=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),l=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),u=l?parseInt(l[1],10):null;if(a&&u&&u<9){var E=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!E&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};i.Howler=t,i.Howl=n,typeof $i<"u"?($i.HowlerGlobal=e,$i.Howler=t,$i.Howl=n,$i.Sound=r):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=n,window.Sound=r)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var n=this;if(!n.ctx||!n.ctx.listener)return n;for(var r=n._howls.length-1;r>=0;r--)n._howls[r].stereo(t);return n},HowlerGlobal.prototype.pos=function(t,n,r){var s=this;if(!s.ctx||!s.ctx.listener)return s;if(n=typeof n!="number"?s._pos[1]:n,r=typeof r!="number"?s._pos[2]:r,typeof t=="number")s._pos=[t,n,r],typeof s.ctx.listener.positionX<"u"?(s.ctx.listener.positionX.setTargetAtTime(s._pos[0],Howler.ctx.currentTime,.1),s.ctx.listener.positionY.setTargetAtTime(s._pos[1],Howler.ctx.currentTime,.1),s.ctx.listener.positionZ.setTargetAtTime(s._pos[2],Howler.ctx.currentTime,.1)):s.ctx.listener.setPosition(s._pos[0],s._pos[1],s._pos[2]);else return s._pos;return s},HowlerGlobal.prototype.orientation=function(t,n,r,s,o,c){var d=this;if(!d.ctx||!d.ctx.listener)return d;var h=d._orientation;if(n=typeof n!="number"?h[1]:n,r=typeof r!="number"?h[2]:r,s=typeof s!="number"?h[3]:s,o=typeof o!="number"?h[4]:o,c=typeof c!="number"?h[5]:c,typeof t=="number")d._orientation=[t,n,r,s,o,c],typeof d.ctx.listener.forwardX<"u"?(d.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),d.ctx.listener.forwardY.setTargetAtTime(n,Howler.ctx.currentTime,.1),d.ctx.listener.forwardZ.setTargetAtTime(r,Howler.ctx.currentTime,.1),d.ctx.listener.upX.setTargetAtTime(s,Howler.ctx.currentTime,.1),d.ctx.listener.upY.setTargetAtTime(o,Howler.ctx.currentTime,.1),d.ctx.listener.upZ.setTargetAtTime(c,Howler.ctx.currentTime,.1)):d.ctx.listener.setOrientation(t,n,r,s,o,c);else return h;return d},Howl.prototype.init=(function(t){return function(n){var r=this;return r._orientation=n.orientation||[1,0,0],r._stereo=n.stereo||null,r._pos=n.pos||null,r._pannerAttr={coneInnerAngle:typeof n.coneInnerAngle<"u"?n.coneInnerAngle:360,coneOuterAngle:typeof n.coneOuterAngle<"u"?n.coneOuterAngle:360,coneOuterGain:typeof n.coneOuterGain<"u"?n.coneOuterGain:0,distanceModel:typeof n.distanceModel<"u"?n.distanceModel:"inverse",maxDistance:typeof n.maxDistance<"u"?n.maxDistance:1e4,panningModel:typeof n.panningModel<"u"?n.panningModel:"HRTF",refDistance:typeof n.refDistance<"u"?n.refDistance:1,rolloffFactor:typeof n.rolloffFactor<"u"?n.rolloffFactor:1},r._onstereo=n.onstereo?[{fn:n.onstereo}]:[],r._onpos=n.onpos?[{fn:n.onpos}]:[],r._onorientation=n.onorientation?[{fn:n.onorientation}]:[],t.call(this,n)}})(Howl.prototype.init),Howl.prototype.stereo=function(t,n){var r=this;if(!r._webAudio)return r;if(r._state!=="loaded")return r._queue.push({event:"stereo",action:function(){r.stereo(t,n)}}),r;var s=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof n>"u")if(typeof t=="number")r._stereo=t,r._pos=[t,0,0];else return r._stereo;for(var o=r._getSoundIds(n),c=0;c<o.length;c++){var d=r._soundById(o[c]);if(d)if(typeof t=="number")d._stereo=t,d._pos=[t,0,0],d._node&&(d._pannerAttr.panningModel="equalpower",(!d._panner||!d._panner.pan)&&e(d,s),s==="spatial"?typeof d._panner.positionX<"u"?(d._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),d._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),d._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):d._panner.setPosition(t,0,0):d._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),r._emit("stereo",d._id);else return d._stereo}return r},Howl.prototype.pos=function(t,n,r,s){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"pos",action:function(){o.pos(t,n,r,s)}}),o;if(n=typeof n!="number"?0:n,r=typeof r!="number"?-.5:r,typeof s>"u")if(typeof t=="number")o._pos=[t,n,r];else return o._pos;for(var c=o._getSoundIds(s),d=0;d<c.length;d++){var h=o._soundById(c[d]);if(h)if(typeof t=="number")h._pos=[t,n,r],h._node&&((!h._panner||h._panner.pan)&&e(h,"spatial"),typeof h._panner.positionX<"u"?(h._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),h._panner.positionY.setValueAtTime(n,Howler.ctx.currentTime),h._panner.positionZ.setValueAtTime(r,Howler.ctx.currentTime)):h._panner.setPosition(t,n,r)),o._emit("pos",h._id);else return h._pos}return o},Howl.prototype.orientation=function(t,n,r,s){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"orientation",action:function(){o.orientation(t,n,r,s)}}),o;if(n=typeof n!="number"?o._orientation[1]:n,r=typeof r!="number"?o._orientation[2]:r,typeof s>"u")if(typeof t=="number")o._orientation=[t,n,r];else return o._orientation;for(var c=o._getSoundIds(s),d=0;d<c.length;d++){var h=o._soundById(c[d]);if(h)if(typeof t=="number")h._orientation=[t,n,r],h._node&&(h._panner||(h._pos||(h._pos=o._pos||[0,0,-.5]),e(h,"spatial")),typeof h._panner.orientationX<"u"?(h._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),h._panner.orientationY.setValueAtTime(n,Howler.ctx.currentTime),h._panner.orientationZ.setValueAtTime(r,Howler.ctx.currentTime)):h._panner.setOrientation(t,n,r)),o._emit("orientation",h._id);else return h._orientation}return o},Howl.prototype.pannerAttr=function(){var t=this,n=arguments,r,s,o;if(!t._webAudio)return t;if(n.length===0)return t._pannerAttr;if(n.length===1)if(typeof n[0]=="object")r=n[0],typeof s>"u"&&(r.pannerAttr||(r.pannerAttr={coneInnerAngle:r.coneInnerAngle,coneOuterAngle:r.coneOuterAngle,coneOuterGain:r.coneOuterGain,distanceModel:r.distanceModel,maxDistance:r.maxDistance,refDistance:r.refDistance,rolloffFactor:r.rolloffFactor,panningModel:r.panningModel}),t._pannerAttr={coneInnerAngle:typeof r.pannerAttr.coneInnerAngle<"u"?r.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof r.pannerAttr.coneOuterAngle<"u"?r.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof r.pannerAttr.coneOuterGain<"u"?r.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof r.pannerAttr.distanceModel<"u"?r.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof r.pannerAttr.maxDistance<"u"?r.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof r.pannerAttr.refDistance<"u"?r.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof r.pannerAttr.rolloffFactor<"u"?r.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof r.pannerAttr.panningModel<"u"?r.pannerAttr.panningModel:t._panningModel});else return o=t._soundById(parseInt(n[0],10)),o?o._pannerAttr:t._pannerAttr;else n.length===2&&(r=n[0],s=parseInt(n[1],10));for(var c=t._getSoundIds(s),d=0;d<c.length;d++)if(o=t._soundById(c[d]),o){var h=o._pannerAttr;h={coneInnerAngle:typeof r.coneInnerAngle<"u"?r.coneInnerAngle:h.coneInnerAngle,coneOuterAngle:typeof r.coneOuterAngle<"u"?r.coneOuterAngle:h.coneOuterAngle,coneOuterGain:typeof r.coneOuterGain<"u"?r.coneOuterGain:h.coneOuterGain,distanceModel:typeof r.distanceModel<"u"?r.distanceModel:h.distanceModel,maxDistance:typeof r.maxDistance<"u"?r.maxDistance:h.maxDistance,refDistance:typeof r.refDistance<"u"?r.refDistance:h.refDistance,rolloffFactor:typeof r.rolloffFactor<"u"?r.rolloffFactor:h.rolloffFactor,panningModel:typeof r.panningModel<"u"?r.panningModel:h.panningModel};var p=o._panner;p||(o._pos||(o._pos=t._pos||[0,0,-.5]),e(o,"spatial"),p=o._panner),p.coneInnerAngle=h.coneInnerAngle,p.coneOuterAngle=h.coneOuterAngle,p.coneOuterGain=h.coneOuterGain,p.distanceModel=h.distanceModel,p.maxDistance=h.maxDistance,p.refDistance=h.refDistance,p.rolloffFactor=h.rolloffFactor,p.panningModel=h.panningModel}return t},Sound.prototype.init=(function(t){return function(){var n=this,r=n._parent;n._orientation=r._orientation,n._stereo=r._stereo,n._pos=r._pos,n._pannerAttr=r._pannerAttr,t.call(this),n._stereo?r.stereo(n._stereo):n._pos&&r.pos(n._pos[0],n._pos[1],n._pos[2],n._id)}})(Sound.prototype.init),Sound.prototype.reset=(function(t){return function(){var n=this,r=n._parent;return n._orientation=r._orientation,n._stereo=r._stereo,n._pos=r._pos,n._pannerAttr=r._pannerAttr,n._stereo?r.stereo(n._stereo):n._pos?r.pos(n._pos[0],n._pos[1],n._pos[2],n._id):n._panner&&(n._panner.disconnect(0),n._panner=void 0,r._refreshBuffer(n)),t.call(this)}})(Sound.prototype.reset);var e=function(t,n){n=n||"spatial",n==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()})(Ws)),Ws}var VS=GS();const kS=["click_002.ogg"],Tl=["object-meshes","track-geometry","track-boosts","sound-effects","tile-glyph-geometries"],Rl={"object-meshes":50,"track-geometry":50,"track-boosts":50,"sound-effects":50,"tile-glyph-geometries":100},mc=new Map;function Ac(i,e){mc.set(i,e)}async function WS(i){const e=Tl.reduce((r,s)=>r+(Rl[s]??0),0);let t=0;const n=new Map;for(const r of Tl){const s=mc.get(r),o=performance.now();s&&await s();const c=performance.now()-o;n.set(r,c),t+=Rl[r]??c,e>0&&i(Math.round(100*t/e))}i(100)}const vl=new Map;Ac("sound-effects",YS);async function YS(){kS.map(async i=>{vl.set(i,new VS.Howl({src:[`sounds/${i}`],format:["ogg"]}))}),await Promise.all(Object.values(vl).map(i=>new Promise((e,t)=>{const n=i;n.once("load",e),n.once("loaderror",()=>{t()})})))}const zS=`aback
abaft
abase
abate
abbey
abbot
abhor
abide
abler
abode
about
above
abuse
abyss
ached
aches
acids
acorn
acres
acrid
acted
actor
acute
adage
adapt
added
adder
adept
adieu
admit
adobe
adopt
adore
adorn
adult
aegis
aeons
affix
afire
afoot
after
again
agape
agate
agent
agile
aging
aglow
agony
agree
ahead
aided
aides
ailed
aimed
aired
aisle
alarm
album
alder
alert
alias
alibi
alien
alike
alive
allay
alley
allot
allow
alloy
aloes
aloft
alone
along
aloof
aloud
alpha
altar
alter
altos
amass
amaze
amber
amble
amend
amigo
amiss
amity
among
amour
ample
amply
amuse
angel
anger
angle
angry
angst
anime
ankle
annex
annoy
annul
antes
antic
anvil
apace
apart
aping
appal
apple
apply
apron
aptly
areas
arena
argue
arise
armed
aroma
arose
array
arrow
arson
ashen
ashes
aside
asked
askew
aspen
assay
asses
asset
aster
astir
atlas
atoll
atoms
atone
attar
attic
audio
audit
auger
aught
augur
aunts
auras
autos
avail
avers
avert
avoid
avows
await
awake
award
aware
awful
awoke
axiom
axles
azure
babel
babes
backs
bacon
badge
badly
baggy
baits
baize
baked
baker
bales
balls
balmy
banal
bands
bandy
bangs
banjo
banks
banns
barbs
bards
bared
barge
barks
barns
baron
basal
based
baser
bases
basic
basil
basin
basis
basso
baste
batch
bated
bathe
baths
baton
bayou
beach
beads
beady
beaks
beams
beans
beard
bears
beast
beaux
beech
beets
befit
began
begat
beget
begin
begot
begun
being
belie
belle
bells
belly
below
belts
bench
bends
bergs
berry
berth
beryl
beset
besom
bevel
bible
bided
bides
bight
bigot
bilge
bills
billy
binds
biped
birch
birds
birth
bison
bitch
bites
black
blade
blame
bland
blank
blare
blast
blaze
bleak
bleat
bleed
blend
blent
bless
blest
blind
blink
bliss
block
blocs
blond
blood
bloom
blots
blown
blows
bluer
blues
bluff
blunt
blurt
blush
board
boars
boast
boats
boded
bodes
boggy
bogus
boils
boles
bolts
bombs
bonds
boned
bones
bonny
bonus
booby
books
booms
boons
boors
boost
booth
boots
booty
booze
borax
bored
bores
borne
bosom
bough
bound
bouts
bowed
bowel
bower
bowls
boxed
boxer
boxes
brace
brags
braid
brain
brake
brand
brass
brats
brave
bravo
brawl
brawn
bread
break
breed
briar
bribe
brick
bride
brief
brier
brigs
brims
brine
bring
brink
briny
brisk
broad
broil
broke
brood
brook
broom
broth
brown
brows
bruin
brunt
brush
brute
bucks
budge
buggy
bugle
build
built
bulbs
bulge
bulks
bulky
bulls
bully
bumps
bunch
bunks
buoys
burly
burns
burnt
burro
burrs
burst
bushy
busts
butte
butts
buxom
buyer
cabal
cabby
cabin
cable
cacao
cache
cadet
cadre
caged
cages
cairn
caked
cakes
calls
calms
calyx
camel
cameo
camps
canal
candy
canes
canny
canoe
canon
canto
caper
capes
capon
cards
cared
cares
cargo
carol
carry
carts
carve
cased
cases
casks
caste
casts
catch
cater
cause
caved
caves
cavil
cease
cedar
ceded
cells
cents
chafe
chaff
chain
chair
chalk
champ
chant
chaos
chaps
charm
chart
chary
chase
chasm
chats
cheap
cheat
check
cheek
cheer
chefs
chess
chest
chick
chide
chief
child
chill
chime
china
chink
chins
chips
chirp
choir
choke
chops
chord
chose
chuck
chump
chums
chunk
churl
churn
chute
cider
cigar
cinch
circa
cited
cites
civet
civic
civil
clack
claim
clamp
clams
clang
clank
clans
claps
clash
clasp
class
claws
clean
clear
clefs
cleft
clerk
clews
click
cliff
climb
clime
cling
clink
clips
cloak
clock
clods
clogs
close
cloth
cloud
clout
clove
clown
clubs
cluck
clues
clump
clung
coach
coals
coast
coats
cobra
cocks
cocoa
codes
coils
coins
colds
colic
colon
colts
combs
comer
comes
comet
comic
comma
conch
cones
conic
cooed
cooks
cools
copra
copse
coral
cords
cores
corks
corns
corps
costs
cotes
couch
cough
could
count
coupe
coups
court
cover
coves
covet
covey
cowed
cower
coyly
cozen
crabs
crack
craft
crags
cramp
crane
crank
crape
crash
crass
crate
crave
crawl
craze
crazy
creak
cream
credo
creed
creek
creep
crepe
crept
cress
crest
crews
cribs
crick
cried
crier
cries
crime
crimp
crisp
croak
crock
crone
crony
crook
crops
cross
croup
crowd
crown
crows
crude
cruel
crumb
crush
crust
crypt
cubes
cubic
cubit
cuffs
cults
curds
cured
cures
curls
curly
curry
curse
curve
cycle
cynic
daddy
daily
dairy
daisy
dales
dally
dames
damps
dance
dandy
dared
dares
darts
dated
dates
datum
daubs
daunt
dawns
dazed
deals
dealt
deans
dears
death
debar
debit
debts
debut
decay
decks
decoy
decry
deeds
deems
deeps
defer
deign
deity
delay
dells
delta
delve
demon
demur
dense
dents
depot
depth
derby
desks
deter
deuce
devil
diary
diced
dices
dicta
diets
digit
dikes
dimes
dimly
dined
diner
dines
dingy
dirge
dirty
discs
disks
ditch
ditto
ditty
divan
dived
diver
dives
dizzy
docks
dodge
doers
dogma
doing
doled
dolls
domed
domes
donor
dooms
doors
dosed
doses
doted
dotes
doubt
dough
doves
dowdy
downs
downy
dowry
dozed
dozen
draft
drags
drain
drake
drama
drams
drank
drape
drawl
drawn
draws
drays
dread
dream
dregs
dress
dried
drier
dries
drift
drill
drily
drink
drips
drive
droll
drone
droop
drops
dross
drove
drown
drugs
drums
drunk
dryly
ducal
ducat
duchy
ducks
ducts
duels
duets
dukes
dully
dummy
dumps
dumpy
dunce
dunes
dunno
duped
dupes
dusky
dusty
dwarf
dwell
dwelt
dying
dykes
eager
eagle
earls
early
earns
earth
eased
easel
eases
eaten
eater
eaves
ebbed
ebony
edged
edges
edict
edify
eerie
egged
eight
eject
elate
elbow
elder
elect
elegy
elfin
elite
elope
elude
elves
email
emits
empty
enact
ended
endow
enemy
enjoy
ennui
enrol
ensue
enter
entry
envoy
epics
epoch
equal
equip
erase
erect
erred
error
essay
ether
ethic
evade
event
every
evils
evoke
exact
exalt
excel
exert
exile
exist
exits
expel
extol
extra
exult
eying
eyrie
fable
faced
faces
facts
faded
fades
fails
faint
fairs
fairy
faith
fakir
falls
false
famed
fancy
fangs
farce
fared
fares
farms
fasts
fatal
fated
fates
fatty
fault
fauna
fauns
fawns
fears
feast
feats
feeds
feels
feign
feint
fells
felon
fence
feral
ferns
ferry
fetch
feted
fetid
fetus
feuds
fever
fewer
fiche
fiefs
field
fiend
fiery
fifes
fifth
fifty
fight
filch
filed
files
filet
fills
filly
films
filmy
filth
final
finch
finds
fined
finer
fines
finis
finny
fiord
fired
fires
firms
first
fishy
fists
fitly
fives
fixed
fixer
fixes
fjord
flags
flail
flair
flake
flaky
flame
flank
flaps
flare
flash
flask
flats
flaws
fleas
fleck
flees
fleet
flesh
flick
flier
flies
fling
flint
flirt
flits
float
flock
floes
flood
floor
flora
floss
flour
flout
flown
flows
flues
fluff
fluid
fluke
flume
flung
flush
flute
flyer
foams
foamy
focal
focus
foggy
foils
foist
folds
folio
folks
folly
foods
fools
foray
force
fords
forge
forgo
forks
forms
forte
forth
forts
forty
forum
found
fount
fours
fowls
foxes
foyer
frail
frame
franc
frank
fraud
freak
freed
freer
frees
fresh
frets
friar
fried
frill
frisk
frock
frogs
frond
front
frost
froth
frown
froze
fruit
fudge
fuels
fugue
fully
fumed
fumes
funds
fungi
funny
furry
furze
fused
fuses
fussy
fuzzy
gable
gaily
gains
gales
galls
games
gamin
gamma
gamut
gangs
gaped
gapes
gases
gasps
gates
gaudy
gauge
gaunt
gauze
gauzy
gavel
gawky
gayer
gayly
gazed
gazer
gazes
gears
geese
genie
genii
genre
gents
genus
germs
ghost
giant
gibes
giddy
gifts
gilds
gills
gimme
gipsy
girds
girls
girth
given
gives
glade
gland
glare
glass
glaze
gleam
glean
glens
glide
glint
gloat
globe
gloom
glory
gloss
glove
glows
glued
gnash
gnats
gnaws
gnome
goads
goals
goats
godly
going
golly
gongs
gonna
goods
goody
goose
gored
gorge
gorse
gotta
gouge
gourd
gouty
gowns
grabs
grace
grade
graft
grain
grams
grand
grant
grape
graph
grasp
grass
grate
grave
gravy
graze
great
greed
green
greet
greys
grief
grill
grime
grimy
grind
grins
gripe
grips
grist
groan
groin
groom
grope
gross
group
grove
growl
grown
grows
grubs
gruel
gruff
grunt
guano
guard
guess
guest
guide
guild
guile
guilt
guise
gulch
gulfs
gulls
gully
gummy
gusto
gusts
gusty
gypsy
habit
hacks
hails
hairs
hairy
haled
halls
halts
halve
hands
handy
hangs
happy
hardy
harem
hares
harms
harps
harpy
harry
harsh
harts
haste
hasty
hatch
hated
hater
hauls
haven
havoc
hawks
hazel
heads
heady
heals
heaps
heard
hears
heart
heath
heats
heave
heavy
hedge
heeds
heels
heirs
helix
hello
helms
helps
hence
herbs
herds
heron
heros
hewed
hides
hills
hilly
hilts
hinds
hinge
hints
hired
hires
hitch
hives
hoard
hoary
hobby
hoist
holds
holes
holly
homes
honey
hoods
hoofs
hooks
hoops
hoots
hoped
hopes
horde
horns
horny
horse
hosts
hotel
hotly
hound
hours
house
hovel
hover
howls
hulks
hulls
human
humid
humps
humus
hunch
hunts
hurls
hurry
hurts
husks
husky
hussy
hydra
hyena
hymns
icily
icing
ideal
ideas
idiom
idiot
idled
idler
idols
idyll
igloo
image
imbue
impel
imply
inane
incur
index
inept
inert
infer
ingot
inlet
inner
inter
inure
irate
irked
irons
irony
isles
islet
issue
items
ivory
jacks
jaded
jails
jaunt
jeans
jeers
jelly
jerks
jerky
jests
jetty
jewel
jiffy
joins
joint
joked
joker
jokes
jolly
joust
joyed
judge
juice
juicy
jumps
junks
junta
juror
karma
keels
keeps
ketch
keyed
khaki
kicks
kills
kinda
kinds
kings
kiosk
kites
knack
knave
knead
kneel
knees
knell
knelt
knife
knits
knobs
knock
knoll
knots
known
knows
label
laced
laces
lacks
laden
ladle
lager
lairs
laity
lakes
lambs
lamed
lames
lamps
lance
lands
lanes
lanky
lapel
lapse
larch
large
largo
larks
larva
lasso
lasts
latch
later
lathe
laths
laugh
lawns
layer
leads
leafy
leaks
leaky
leans
leaps
leapt
learn
lease
leash
least
leave
ledge
leech
leeks
legal
lemme
lemon
lends
leper
levee
level
lever
liars
libel
licks
liege
liens
lifts
light
liked
liken
liker
likes
lilac
limbo
limbs
limes
limit
lined
linen
liner
lines
lingo
links
lions
lists
lithe
lived
liver
lives
livid
llama
loads
loamy
loans
loath
lobby
lobes
local
locks
locus
lodge
lofty
loges
logic
login
loins
longs
looks
looms
loons
loops
loose
lords
loser
loses
lotus
louse
lousy
loved
lover
loves
lowed
lower
lowly
loyal
lucid
lucky
lulls
lumps
lumpy
lunar
lunch
lunge
lungs
lurch
lured
lures
lurid
lurks
lusts
lusty
lutes
lying
lymph
lynch
lyric
maces
madam
madly
magic
maids
mails
mains
maize
major
maker
makes
males
mamma
manes
manga
mange
mango
mangy
mania
manly
manna
manor
manse
maple
march
mares
marks
marry
marsh
marts
masks
mason
masts
match
mated
mates
mauve
maxim
maybe
mayor
mazes
meals
mealy
means
meant
meats
medal
media
meets
melon
melts
memes
mends
menus
mercy
meres
merge
merit
merry
mesas
metal
meted
meter
mewed
midst
miens
might
milch
miles
milky
mills
mimes
mimic
mince
minds
mined
miner
mines
minor
mints
minus
mirth
miser
mists
mites
mixed
mixes
moans
moats
mocks
model
modem
modes
moist
molar
moles
momma
money
monks
month
moods
moody
moons
moors
moose
moped
moral
mores
mossy
motes
moths
motif
motor
motto
mound
mount
mourn
mouse
mouth
moved
mover
moves
movie
mowed
mower
mucus
muddy
mules
multi
mummy
mumps
munch
mural
murky
mused
muses
music
musky
musty
muted
mutes
myrrh
myths
nabob
nails
naive
naked
named
names
nasal
nasty
natal
natty
naval
navel
naves
nears
necks
needs
needy
neigh
nerve
nests
never
newer
newly
nicer
niche
niece
night
ninny
noble
nobly
noise
noisy
nomad
nonce
nooks
noose
north
nosed
noses
notch
noted
notes
nouns
novel
nudge
nurse
nymph
oaken
oakum
oases
oasis
oaten
oaths
obese
obeys
occur
ocean
ochre
odder
oddly
odium
offal
offer
often
oiled
olden
older
omens
omits
onion
onset
oozed
oozes
opals
opens
opera
opine
opium
optic
orbit
order
organ
osier
other
otter
ought
ounce
outdo
outer
ovals
ovary
ovens
overt
owing
owned
owner
oxide
ozone
paces
packs
paddy
padre
paean
pagan
pages
pails
pains
paint
pairs
paled
paler
pales
palms
palmy
palsy
panel
panes
pangs
panic
pansy
pants
papal
papas
paper
pared
parka
parks
parry
parse
parts
party
pasha
paste
pasty
patch
pates
paths
patio
pause
paved
pawed
pawns
payed
payer
peace
peach
peaks
peals
pearl
pears
pease
pecks
pedal
peeps
peers
pelts
penal
pence
penis
penny
peons
perch
peril
pesky
pesos
pests
petal
petty
phase
phial
phone
photo
piano
picks
piece
piers
piety
pigmy
pikes
piled
piles
pills
pilot
pinch
pined
pines
pinks
pinto
pints
pious
piped
piper
pipes
pique
pitch
pithy
pivot
place
plaid
plain
plait
plane
plank
plans
plant
plate
plays
plaza
plead
pleas
plied
plies
plots
pluck
plugs
plumb
plume
plums
plush
podia
poems
poesy
poets
point
poise
poked
poker
pokes
polar
poles
polka
polls
ponds
pools
popes
poppa
poppy
porch
pored
pores
ports
posed
poser
poses
posse
posts
pouch
pound
pours
power
prank
prate
prays
press
preys
price
prick
pride
pried
pries
prime
print
prior
prism
privy
prize
probe
prone
proof
props
prose
prosy
proud
prove
prowl
prows
proxy
prude
prune
psalm
pshaw
pudgy
puffs
puffy
pulls
pulpy
pulse
pumps
punch
pupil
puppy
puree
purer
purge
purse
pussy
putty
quack
quaff
quail
quake
qualm
quart
quasi
quays
queen
queer
quell
query
quest
queue
quick
quiet
quill
quilt
quips
quire
quite
quits
quota
quote
quoth
rabbi
rabid
raced
racer
races
racks
radii
radio
rafts
raged
rages
raids
rails
rains
rainy
raise
rajah
raked
rakes
rally
ranch
range
ranks
rapid
rarer
rares
rated
rates
ratio
raved
raven
raves
rayon
razed
razor
reach
react
reads
ready
realm
reals
reams
reaps
rears
rebel
rebus
rebut
recur
reeds
reedy
reefs
reeks
reels
reeve
refer
refit
regal
reign
reins
relax
relay
relic
remit
rends
renew
rents
repay
repel
reply
reset
resin
rests
revel
rhyme
rider
rides
ridge
rifle
rifts
right
rigid
riled
rimes
rings
rinse
riots
ripen
riper
risen
riser
rises
risks
risky
rites
rival
riven
river
rivet
roads
roams
roars
roast
robed
robes
robin
rocks
rocky
rogue
roles
rolls
roman
roofs
rooks
rooms
roomy
roost
roots
roped
ropes
roses
rosin
rouge
rough
round
rouse
route
routs
roved
rover
rowdy
rowed
royal
ruder
ruffs
ruins
ruled
ruler
rules
runes
rungs
rupee
rural
ruses
sable
sabre
sacks
sadly
safer
sagas
sages
sails
saint
salad
sales
sally
salon
salsa
salts
salty
salve
salvo
sands
sandy
saner
sated
satin
satyr
sauce
saucy
saved
saves
sawed
scald
scale
scalp
scaly
scans
scant
scare
scarf
scars
scene
scent
scion
scoff
scold
scoop
scope
score
scorn
scour
scout
scowl
scrap
screw
scrip
scrub
scull
seals
seams
seamy
seats
sects
sedan
sedge
seeds
seedy
seeks
seems
seers
seize
sells
semen
sends
sense
serfs
serge
serum
serve
seven
sever
sewed
sewer
sexes
shack
shade
shady
shaft
shake
shaky
shale
shall
shalt
shame
shams
shank
shape
share
shark
sharp
shave
shawl
sheaf
shear
sheds
sheen
sheep
sheer
sheet
sheik
shelf
shell
shied
shift
shine
shins
shiny
ships
shire
shirk
shirt
shoal
shock
shoes
shone
shook
shoon
shoot
shops
shore
shorn
short
shots
shout
shove
shown
shows
showy
shred
shrew
shrub
shrug
shuns
shuts
shyly
sided
sides
siege
sieve
sighs
sight
sigma
signs
silks
silky
sills
silly
since
sinew
singe
sings
sinks
siren
sires
sites
sixes
sixth
sixty
sized
sizes
skate
skein
skies
skiff
skill
skims
skins
skips
skirt
skulk
skull
skunk
slabs
slack
slags
slain
slake
slang
slant
slaps
slash
slate
slats
slave
slays
sleds
sleek
sleep
sleet
slept
slice
slick
slide
slily
slime
slimy
sling
slink
slips
slits
sloop
slope
slops
sloth
slugs
slump
slums
slung
slunk
slush
slyly
smack
small
smart
smash
smear
smell
smelt
smile
smirk
smite
smith
smock
smoke
smoky
smote
snack
snags
snail
snake
snaky
snaps
snare
snarl
sneak
sneer
sniff
snipe
snobs
snore
snort
snout
snows
snowy
snuff
soapy
soars
sober
socks
sofas
soggy
soils
solar
soles
solid
solos
solve
songs
sonny
sooth
sooty
sores
sorry
sorts
sough
souls
sound
soups
souse
south
sowed
sower
space
spade
spake
spank
spans
spare
spark
spars
spasm
spawn
speak
spear
speck
speed
spell
spelt
spend
spent
sperm
spice
spicy
spied
spies
spike
spill
spilt
spine
spins
spiny
spire
spite
spits
split
spoil
spoke
spook
spool
spoon
spoor
spore
sport
spots
spout
spray
spree
sprig
spunk
spurn
spurs
spurt
squad
squat
squaw
stabs
stack
staff
stage
stags
staid
stain
stair
stake
stale
stalk
stall
stamp
stand
stank
stare
stark
stars
start
state
stave
stays
stead
steak
steal
steam
steed
steel
steep
steer
stems
steps
stern
stews
stick
stiff
stile
still
sting
stink
stint
stirs
stock
stoic
stole
stone
stony
stood
stool
stoop
stops
store
stork
storm
story
stout
stove
strap
straw
stray
strew
strip
strut
stuck
studs
study
stuff
stump
stung
stunt
style
suave
sucks
sugar
suing
suite
suits
sulks
sulky
sully
sunny
super
surer
surge
surly
swain
swamp
swans
sward
swarm
sways
swear
sweat
sweep
sweet
swell
swept
swift
swill
swims
swine
swing
swirl
swish
swoon
swoop
sword
swore
sworn
swung
synod
syrup
tabby
table
taboo
tacit
tacks
tails
taint
taken
takes
tales
talks
tally
talon
tamed
tamer
tanks
taper
tapes
tardy
tarry
tarts
tasks
taste
tasty
taunt
tawny
taxed
taxes
teach
teams
tears
tease
teems
teens
teeth
tells
tempo
tends
tenet
tenor
tense
tenth
tents
tepid
terms
terse
tests
testy
texts
thank
theft
their
theme
there
these
thick
thief
thigh
thine
thing
think
third
thong
thorn
those
three
threw
throb
throe
throw
thumb
thump
thyme
tiara
tibia
ticks
tidal
tides
tiers
tiger
tight
tilde
tiled
tiles
tills
tilts
timed
times
timid
tinge
tints
tipsy
tired
tires
tithe
title
toads
toast
today
toddy
toils
token
tolls
tombs
tomes
toned
tones
tongs
tonic
tools
tooth
topaz
topic
toque
torch
torso
torts
total
totem
touch
tough
tours
towed
towel
tower
towns
toxic
toyed
trace
track
tract
trade
trail
train
trait
tramp
trams
traps
trash
trays
tread
treat
treed
trees
trend
tress
triad
trial
tribe
trice
trick
tried
tries
trill
tripe
trips
trite
troll
troop
troth
trots
trout
truce
truck
truer
truly
trump
trunk
truss
trust
truth
tryst
tubes
tufts
tulip
tulle
tuned
tunes
tunic
turns
tusks
tutor
twain
twang
tweed
twice
twigs
twine
twins
twirl
twist
tying
typed
types
udder
ulcer
ultra
uncle
uncut
under
undid
undue
unfit
union
unite
units
unity
unsay
untie
until
upper
upset
urban
urged
urges
urine
usage
users
usher
using
usual
usurp
usury
utter
vague
vales
valet
valid
value
valve
vanes
vapid
vases
vault
vaunt
veils
veins
veldt
venal
venom
vents
venue
verbs
verge
verse
verve
vests
vexed
vexes
vials
vicar
vices
video
views
vigil
viler
villa
vines
viola
viper
virus
visit
visor
vista
vital
vivid
vixen
vizor
vocal
vodka
vogue
voice
voile
volts
vomit
voted
voter
votes
vouch
vowed
vowel
vying
waded
wafer
wafts
waged
wager
wages
wagon
waifs
wails
waist
waits
waive
waked
waken
wakes
walks
walls
waltz
wands
waned
wanes
wants
wards
wares
warms
warns
warts
wasps
waste
watch
water
waved
waver
waves
waxed
waxen
waxes
wears
weary
weave
wedge
weeds
weedy
weeks
weeps
weigh
weird
welch
wells
wench
whack
whale
wharf
wheat
wheel
whelp
where
which
whiff
while
whims
whine
whips
whirl
whirr
whisk
whist
white
whole
whoop
whore
whose
wicks
widen
wider
widow
width
wield
wight
wilds
wiles
wills
wince
winch
winds
windy
wines
wings
winks
wiped
wipes
wired
wires
wiser
wisps
witch
witty
wives
woman
women
woods
woody
wooed
wooer
words
wordy
works
world
worms
worry
worse
worst
worth
would
wound
wrack
wraps
wrapt
wrath
wreak
wreck
wrest
wring
wrist
write
writs
wrong
wrote
wroth
yacht
yards
yarns
yawns
yearn
years
yeast
yells
yelps
yield
yoked
yokes
yolks
young
yours
youth
zebra
zones`,Ys=["GAUGER    OBESEA    NATAL","OAKUMU  S T  U EQUALR  L ","CLEANR X OE I VD S EO T L","CROPSI U TGENIIA C NR E G","LIEGEI  A EXULTN  E SLASH","KNOWNN W UI I DF N GEAGLE","IDYLLD    ODIUML    SCOFF","BELTSE    GULFSI    NAKED","SOLOSC  W AMENDN  E SNARL","IDLERN A  APRONN V  EXALT","WALTZO  I ROOTSL  L DOMED","REAMSE M NP U AL S IY E L","WRESTH Q AI U WR I NREPAY","CLAIMR   UALARMF   PTAILS","FREESO S UY S IEXALTR Y E","MYTHSO W AO I TD C YSHEAR","BUSTSA H ACLEANK E DSORRY","LUNCHE E EA R LF V IY E X","FETEDR R EO A AWISERN H S","BOUGHE  I ABODED  D SWAYS","PAYERU    ROMANG    EIGHT","TENORO  V RULESS  N OBESE","GENUSN E EAGAINW R SS S E","WHIRLI C ODYINGE N ERAGES","ALLOTL  X OASISE  D SEWER","LOBBYU E  R A  ENDOWS Y  ","MEDALA  B N  A OMITSR  E ","RIVALE   UG   CA   ILACED","FAULTU N OENDOWL I ES D L","MESASO I IU G GNYMPHT A T","COVETH  M U  P ROOTSL  Y ","CROWDH   AINLETD   EEBBED","TRUNKI  A N  T GOUTYE  Y ","SCOPET U  ARGUER H  SATED","FUNNYA  E W  W NAILSS  Y ","TAILSI  I BALMYI  B AROSE","SLICKT N NA E EN R LD T T","BABELL A OE S NEYINGD N S","SHADEO F JU F EP I CS X T","FORTEL  H ACORNI  E L  W ","LEAKSU I  TURNSE E  SIDED","EATERY  D I  I NONCEG  T ","SHAREA M QL U UVISTAE E L","PENNYO  A D  K INTERA  D ","CURRYA E ISTAKEE L LDOMED","FILMSI   AROYALM   VSHADE","MINESA A EP T RL T FE Y S","THUMBA R UBEGUNB E KY S S","FASTSA    IDOLSR    SLOTH","DRAGSA  L T  A EARNSS  D ","GAPESO R LN I UGANGSS T H","VOICEO S ACOSTSA U ELIENS","BURNTR  O A  S GRUELS  D ","STEERP   EOBESEI   FLOONS","VERGEO A  MIGHTI E  TESTS","FIELDL L IA A AINTERL E Y","FREAKL A IO S OUSERST L K","GLORYA  E LOVEDL  V SIRES","BEANSA  E STRIPA  G LIGHT","LATHSI   HNASTYE   LDIRTY","DEPOTR O EU E NMYTHSS S E","BLESSU L TTIBIAT O IE W R","GRASPA G IIRATEN I CSINCE","TEAMSA  O B  T LITHEE  S ","QUITSU  R E  I URGESE  S ","SPRAYT   OO   UN   NYOUNG","CRIBSR  R ANTICS  G HUSSY","WORLDI A IN C KCREPEH S S","CYCLEH  I UTTERM  G SPIES","FUMESI E TX E OE T OS S D","SIXESP  R INERTR  O EVERY","PAUSEO S LL E AE R TS S E","GRAFTR L EA I SCIVETE E Y","NONCEA E AK W RE E LDIRTY","COLICH A AO P VS S IE E L","SEVENO A OB L TE E ERATED","FUMESI  M ORBITR  T DENSE","OPTICM E II A VTASTES E T","BEGOTI O AL D BL L BSHYLY","SAUCYH    OAKUMN    EDIFY","VEXEDI  T R  H UDDERS  R ","LUMPYO E  YEASTA L  LOYAL","BLURTO  A ROARSN  E ERASE","PARSEA   RNEVERS   EYIELD","PORCHE H ES Y LT M IS E X","VAGUEE A XL I CDENSET S L","SLAINA    LOYALA    DEANS","MINTSA A EU V NVIEWSE L E","SHIEDT   IUNCUTD   CYOUTH","FREESI   ALIKEDE   LDECRY","GRILLA  O P  I EVENTS  S ","PLANKO  U S  R SPASME  E ","WITCHO  H ORBITE  M RIPEN","RIDGEI  L S  E KNEADS  N ","PHIALA  I WHIRLE  E DANDY","QUEUEU L  ADDERC E  KARMA","VICARI  N VERGEI  L DETER","ROWEDU A RL F IE T LRISKY","BRISKA  H I  E ZONESE  R ","ROOKSE   TI   AGIPSYN   S","GAPES C E FIERY D I ASHES","DULLY N U SCANT U C  T H ","PETTY S   USURY A   HYDRA","BLEND E U  P R LEASH R E ","TAINT F  OOFTEN I  E X  D","WREAK I D  S U SKULL S T ","SPUNK I  N L  OBELOW S  S","AMISS O H  O O SNOWS S Y ","GLOBE U U USURP T S  Y T ","CHEAP U  ACRAMP T  EUSHER","WINDS M E DAIRY G B BERYL","EPOCH O  U P  SNEEDS S  Y","SEWED A  ACRIED L  DGYPSY","SHARE O E  A A BRIDE D S ","LEEKS D  N I  I F  F Y  F","EASED M B  I O AGENT O Y ","ACRES I X  V E  E R STATE","TUNIC N   TINGE T   LYRIC","FJORD A A CURRY N E  T S ","COPSE C  DGENII A  FUNITY","FRIED A  AEVENT E  EASKED","AWARE H  TWINCH S  IETHIC","GRUFF A L DIVAN D K ASHEN","PARTY M A  A R ASIDE S Y ","SHAKE O  YRADII R  NEYING","GOING L  OEDGED E  LDRYLY","BIGOT D  E O  AFLIER S  S","BRIEF E N ABATE U E STARK","BURNS D  PADOBE E  EBROAD","GONNA R  T B  LDICTA T  S","SHOES U V  R A TRADE Y E ","ROUTE W E SNEAK E C  R H ","FREAK I  E T  EDEVIL S  S","BLAZE O  L U  EUSING Y  Y","ROCKS V  WMEDIA R  MSTRIP","BOLTS A E USING I S ISLET","BISON R  I K  G E  HEDICT","RIMES T  TEERIE M  AUSUAL","RAINY G   WASTE I   ANVIL","PURSE D E ADORN E F FRISK","ROUSE V   GENRE N   ASTIR","LAWNS G   PRAYS E   LEANS","QUALM S E HUMAN A D CLASS","SCRUB A  U L  OIMPLY S  S","BOOTY A  ESKILL U  PAMASS","CELLS V E TILDE L G ASHEN","GRINS O  L V  A E  TGRIPS","DOVES N  H I  AMOVER N  E","LULLS N  O D  RFIRST D  S","SWEAT I  RIGLOO H  TSTABS","GLOVE I O  M C REGAL S L ","WINDS R  P O  IANGEL S  T","DUKES N D  C I SLACK E T ","DOORS R  I D  X E  EDREGS","GIRLS S A FLARE E V ASSAY","PEASE X  NOCHRE E  MSLILY","BORAX A N STAGE H E PSALM","YELPS N  HUSAGE U  A E  F","FLOUT I   SKIRT E   ADULT","CHINK O A  P V FEWER D S ","DELTA N A  A X ACHED T D ","FAWNS B A SOLVE V E KEELS","SMITH E I  D M  I I YARDS","FELLS N  EPARKA C  MSTEWS","FUNGI S R CHEAT E S TRIPE","CAMPS P  P T  ECLOWN Y  T","WIELD D  USERUM A  MESSAY","OAKUM N N STAIN E T  S S ","SOUPS P  U E  IONION S  G","CLOTH I  AONION E  GIDOLS","UNCLE O I RUFFS N T  S S ","WAIST U  ISTEAD O  AUSUAL","MODES A  OSKIFF U  AAMASS","DITTO T  A E  TSMASH S  S","TAWNY L Y  L M COUPS W H ","WAXES C   GRAVY E   USURP","BUMPS N L LILAC T I NEEDY","BITCH N  I D  VNERVE X  S","CHASM E   SLIME I   EXILE","ROSES A  W T  ITHEIR S  L","HORSE L H  D E JEWEL R P ","POSER F   OFTEN A   CLAIM","SANDY N R STOOP E L PSALM","HEIRS N I  J N  O S TYPES","GIRLS C   MIXED L   LYRIC","PINED S  IASTIR U  GSENSE","USURY C  ITOQUE R  LKNEAD","STAKE R  L U  ISMART P  E","PRONE O  Y W  I D  NEYING","DOWRY U  AANTIC C  HRESET","REARS T  WPHONE E  ECRAMP","COBRA X E MIXED D K DENSE","DOMES F  HAFTER A  UPLUMB","WOMAN T  OCHEAT E  ECRIBS","DINES G A ALERT O L  O Y ","SHARK O A MOURN K E  S S ","GUARD N A  T V RILED L N ","CLASP I   AMISS E   USING","GENRE X E  I G PSHAW T L ","BLIND I A SKATE E A PSALM","BUMPSR O LANNOYS E LSHYLY","FLAREE S AWHISTE D ER E R","LOCALI H EN O VENSUEN E L","RAINYA N EJ F LA E PHERDS","SLANT  L RCLOSE  E ECASED","OWINGR R AB A MI T MT E A","CAPESL O KI L IM K RBLAST","DERBY  I  NOSED  K  CRYPT","LIBELE I AA T GNICHES H R","STAGSL D LU U AMULTIP T N","SEATSW L OI I UNEARSG S E","SKIESE D  COLDST E  SIDED","FAREDL I EA S NREELSE S E","OTTERP O ET O AI T LC H S","MOUTH  N AALIBI  T RPASTY","FURRYO I AR M RDREADS S S","VAGUEO A  TESTYE P  DISKS","DAREDU A RPIGMYE E LDADDY","COWERO E OM E UE D GT Y H","OAKUM  E IROYAL  E KMADLY","SWISH  N  RULER  E  HATER","HULLSE I LN K UCREAME R P","SWINEW R LANKLER E GDADDY","SNEERY R EREEVEU C DPITHY","DREGSU A LC S AA E PLUSTS","BROIL  V E  A V  R EIDYLL","SCALEU R  I O  TASTYE E  ","ANGLE  O ATWANG  L EVISOR","TWANGR P OACTEDI L LT Y Y","WAKEDH H RO A ERAKESE I S","DUNNOA O BN I EDISKSY E E","FEATSI F AN O WC O EHATED","BRAVEU L AR T SSPARET R L","FEINTU G UMOLESE O KSHOWS","WHOSEI X NN I VK D OSEEDY","FLIRTO R RU O ERUNGSS S S","CARGOO A BU I EGENUSH Y E","PENNYO O EKARMAE T SR H T","QUICK  D  SOILS  O  DAMES","JOUST  P A  P CBREAK  R S","HUMUSA U ER S NPLIEDS C S","BLUNTR N HA I EKNOTSE N E","FOAMSU L PSTEALE R ID T T","OILEDB E EE E NSECTSE H E","BEECHR X OASTIRT O SSALVE","TARRYE A OA C USKEINE S G","RUNESO E HA V OSWEATT R S","SCOPET W XO N UI E LCADET","SQUATT L EA T NLARGEL A T","BUTTER O XA A TWIDERL S A","AWARDU B IDOOMSI V CTEEMS","USINGL D RT E OR A AARSON","WEAVEH C AE U RE T NLIENS","SNAKYW D OABACKM G EPLEAD","UDDER  R UQUAIL  G EFUSES","TONICW A HI T ASITEST Y M","AMPLY  A  LARKS  K  EASEL","PLUMS  R ACABIN  A DLINES","LIVEDE I AALLOTN L ESEALS","OZONER L XB D IIDEAST R T","SMITEU M LCOPRAK L TSTYLE","WOULDI N AT T DCHILDH L Y","IDIOT  M ESUAVE  G MPLEAS","BROODE N EA I LSTOOLT N S","BURLYL O AU S CFRESHF S T","MOTOR  O  PIQUE  U  TWEED","BANKSL A TU I AFEVERF E T","AMAZEB S XA H ICLEFSK S T","SOARSP B LA A UWAFTSN T H","ROVEDE A AARSONC E DHUSSY","THONGR R AU D VSCENES R L","BEGATO R AAXIOMS S ETUTOR","SPAWNT C ERITESE O TWIRES","SPENTL L EAREASN G TT Y S","ENNUIX A CI S IT T LSHYLY","FALSER U NE T TSHEERH S Y","PANSY  O  WISPS  E  GUSTO","OBESEP L RE E RR G OA Y R","SWEAR  L ASOUND  D ICREDO","FLAGSL S HU H IFREERF N E","BRIARA N UT F LCREPEH R S","NICHEA U  M L  ENTRYD S  ","CATERO I AWATERE L EREELS","LADLEO I XU C ESATYRE A T","AGENTM D HBAIZEE F RRHYME","SUAVEP U AE T TA O ERISER","PIPERO A AEATERM H ES S S","TURNSR I II F LE L KSTEMS","FAIRS  M I  A GBEGAN  E S","HIREDO O AO O TD M US Y M","USING  N  RACED  U  FERNS","FORTSL E IAHEADN K EK S S","DAISYU S IPULSEE E LDOSED","WISPSE H TD O RGOTTAE S P","GRISTR S IIDLEDE E AF S L","COACHL I AU R NBLEEDS D Y","TAMERI U ON R UTAKENS Y D","BIDEDI R AR O ICASKSH S Y","BURROU I  NEVERC E  HERON","RAINSO N LU T ASHEDSE R H","RURALA  C B  H BAREDI  S ","SERGE   R BABEL   E POSTS","FUNGI N A ADOBE E L ORDER","VALID D G  A L SPOOR T O ","NOSEDO  G TWIGSE  E SEEDS","FLAGSO  R R  A TWAINY  N ","MOANSO  A U  M S  E ERASE","ASSESB  N O  S VALUEE  E ","MAMMAO  U T  S OFTENR  D ","LIVES S N BLENT E U ASTIR","GLASSU  A I  I SPENDE  T ","STAINN  N A  A GONNAS  E ","SHORNH  A EDIFYA  T RAISE","SPAWNL  H A  A BULLSS  E ","GIVES N V MEDAL P D OTHER","TRICEU  R NASALE  S DUCHY","LOCKS Z N LOCAL N V SEWED","TICKS N N  A E ANGLE E L ","JOUSTU  P N  U T  R ACUTE","SWIFTO  A ALBUMR  N STRAY","ARISE A E  Y E MOODY N Y ","EXACTL  R I  O TRACKE  K ","THROB U C  M C PIQUE D R ","SIREST  N A  A CLICKK  T ","SIXES S V OLDER E N STATE","GREYSI  O P  U SORTSY  H ","SPILL O I  W V  E I PRIDE","CARVEU  O BULGEI  U COTES","CRUEL A N BRINE E U ORBIT","HULKS S E HUNTS R C  P H ","MIMES R L  K I JETTY D E ","CLUBSH  R A  O IDIOMN  K ","BAREDE  V LEMONO  K WAFER","BURNT R E  G R NERVE D E ","OMITS A A DRILY K E  S S ","GOADSI  A FACTST  U SLIMY","OZONEU  I T  N EBONYR  Y ","CLUCKO  H WOMANE  I DIARY","AMENDB  A I  M DEFERE  S ","BREAD A M ACRID E G PRIOR","TOOTHO  R TEPIDA  E LEASH","SHEIK A D  V E SOLAR C S ","RIMES N L STAID E T ORDER","TROUT E R  B I SUING T E ","BOXER P D CARGO L E ASIDE","CLAIMA  M SLAPSE  L DRAYS","GNASHA  T TREATE  L STALE","SWEARL  W I  O NOOKSK  E ","FORTEL  A U  S N  K GUEST","KNOWNN  O OVERTW  S NORTH","NAILSE  I E  B D  E SAILS","OLDER A Y FRUIT C N THIGH","DRINKR  E OPTICL  G LIGHT","ADAGE O R  E O DROVE S E ","SULKS N E  C E CURLS T S ","ERRED E R GENRE V O PEARL","NUDGEA  A SPOUTT  Z YOKED","CLIFF A U OSIER T L  S S ","ACUTE   E CLANS   D COPSE","KICKSN  N ERRORL  T LOUSE","DEEMSE  A VEINSI  E LEASH","CREEP I A  G G WIELD D E ","BAKED S X  T I FEELS R E ","ZEBRA T A SHINE I K  C S ","COURT P O MASON L M  S Y ","NORTH R A  B L FILLS T Y ","TIARAR  A I  V ACHESL  S ","PASTYA  R GROINE  T SUPER","TULLEE  O ALLOYR  M SMASH","HUMPSO  O SKIPST  P SOLAR","TUNESR  X U  A TRUCKH  T ","SLINGA  O C  B KILLSS  Y ","WANESR  V IRKEDT  N SOOTH","CAKED P N  P T ALTER Y R ","INGOT   A KHAKI   E STANK","SPADE E A ADULT A L PLAYS","VIPER N I RANGE N H HEATH","OFFER A L STRUT T D TYPES","STUNTL  A A  T BOLTSS  Y ","PILEDE  D S  I KETCHY  T ","AMUSED  H ORGANR  D NOTES","COCKS V N  A O PRATE Y S ","OASES L I DINGY B H DIETS","ONSET A X  M I DEITY D S ","JERKSA  N CHAIRK  F SATED","CADET R L  M O LEAPT D E ","DENTS   I STABS   I ATTAR","COOLSL  O ALLOWS  N PUSSY","FEVER X L STEER R C PASTE","LOCALE  F A  O SPOONT  T ","IDOLSR  A OUNCEN  E SLUSH","TEASE D E  G R  E G ODDER","FARCEI  R L  A MUMMYS  P ","BUTTS S H AUGUR A M SLOPS","NEWER L V MEWED G R  Y Y ","TRUSSO  P D  E DUELSY  L ","AGILE R I  A C STAKE E S ","PUSSYI  N NABOBC  W HARSH","RENTS S A  S C PATIO Y T ","YARNS L E FLAWS O L SWAYS","IDIOM    IOZONE    NDUELS","TITHE  R JCHOSE  T CRESET","CLEAR O  A Y  DRABBI L  I","TREES O  W W  I E  FADEPT","OASESV L WA I IRATESY S H","REBEL    IGIVES    TBUMPS","LUSTSO   QBAYOUE   ASQUAW","SERGEH O XI U TRATIOK S L","PHONE A  X Z  UVENAL L  T","BUILDA   ESTOOPS   OOUGHT","BESOM S  A S  RTAPER Y  Y","STILE O  A W  RMEDAL D  S","SNAKEK E LE G EICINGN S Y","FLIER  M ETIBIA  U CEVENT","PROWSR   HIGLOOC   CKNOCK","ADEPT O  H G  R M  ONABOB","FRANCR U AE D BALIBIK O N","DUMPYW   OADIEUR   NFLING","STILL O  O Q  WTULLE E  R","SNOUT A  H K  EREALM D  E","PESOSI A UCANALK E KSERFS","QUAYS    WCOCOA    NSCANS","EIGHTN L ISHAFTU N HE D E","LUCKYI L OM E UBEFITS T H","GLEAMU L ISPURNT D DOPENS","MINESI O WN N ITICKSS E H","BLASTL L RU P IF H BFLARE","QUAKE  R N  R TWHOSE  W R","HOVERO E EO I SFUNGIS S N","CRATEU U AR G VE H ESITES","TUSKS  T TBOOZE  R WCOMBS","MOUNTO S UU U NN R ITOPIC","MIMIC  O LBATHE  T FGHOST","FLOUR O  E Y  EBANAL L  S","SMILEW G AU L RN O TG O H","PRIVYU   ORIVALE   KEARLS","RUFFSE A NADIEUD T FS H F","LURES R  OVIGIL N  ANEWER","SPOOL O  IVIXEN S  EHEWED","IDLED I  I C  V T  ACAPON","LIVER D  E E  ARAZED L  Y","GROWN A  O J  O A  SCHASE","RACERE L AV U ZE N OLAGER","BELLY    ABLUER    NHULLS","AGILEN   NTILEDE   ESQUAD","WEARSE I IA M ZREEVEY D D","SEDGE X  RVIPER L  EMETED","WHARFA L IN I FE B ESHINS","CACAOL R FU O FB W AS N L","BOXED N  U I  P O  EGNAWS","SEAMS  L TWRITE  K EFREER","PRIED O  R V  O E  VPRUNE","SWINE    JGORGE    CPLANT","ASKEWL   RIMBUEA   CSHOOK","DECAY  A E  D AJUROR  E S","TORCH V  ADEPOT R  C T  H","SLICK A  E T  ESHOAL S  S","CAREDA E ESTEAMK F US S R","LIENS G  NALIBI O  PFORGE","GALES F  A T  BFERAL R  E","CROSSO   CPASHAR   NABOUT","WIVES  I L  X I  E DVENUE","ASKEDP I RP N ILADLEE S S","GILLS    TGUSTO    OSTAMP","LEADS D  TCIRCA C  BATOMS","COSTS    HGOTTA    NWHACK","CONCHE O ED I AA S PREEDS","WHIFFA   LR   UM   FSNIFF","MURALA   ITRUSTC   HHORSE","LAKES  H LLLAMA  K CPRICK","CHARYL   AINCURM   NBEAMS","EMITSD N II C NC U ETHROW","SCREWA U HLARGOL A OY L P","SUITE N  L I  U T  DASIDE","KNELLI D EC G VK E ES D L","BRINEI   AP   GE   EDONOR","SNIPE E  M I  IAGENT H  S","FLANK I  I A  NWRING S  S","GRAND    RLASSO    WWAKEN","ELDER E  A A  V S  ECHAPS","BERGSA I LY G IONIONU D G","SLAPSU   IGRUELA   KROOMY","WAXEDR   OADIEUP   GSMITH","GRAMS O  HMANIA S  KSTRAY","IDEASN M ICAPONU T ER Y W","STAID W  URISEN C  CGENRE","HAIRYA N OS A UT N NY E G","BROTHO   AAWFULT   ESATED","VEXEDE   ORENEWV   REDIFY","GREATO T OR H WS I EEXCEL","WRATHH L IA I LRIVALF E S","LOINSE N TPIANOE N IR E C","CLUBSO N LV C IEQUIPT T S","MUDDY N  OKIOSK T  EASKED","LINKSI O NK R EEXTRAR H K","TEASE E  AORBIT I  ERESIN","TRUSTI N RL S ADEANSE Y H","KIOSK  W NALIBI  N FROGUE","LONGSO A TU M OSTEERY D E","TOQUE R  VIGLOO A  KANIME","E R ATWEEDH P OE L PR Y T","M  G OVERTC  U KNIFES  F ","A  P PALERR  N OPTICN  S ","A  S CROWDU  E TIDALE  T ","O  R FILETT  L E  I NOTCH","G C PAVAILU S ANATTYT S S","S  M COMETO  M USHERR  S ","U L PSWINEI N RN E IG S L","P T CREACHA M EY E ASYRUP","S G STWAINR V OU E RTILDE","R O EOOZEDS O GE N ESLEDS","S  I TILDEU  E N  A THOSE","S A ECABBYO H RF O IFARCE","A  P CURSET  H E  A DRAWS","A H SSHIFTS L OALTERY S K","P  U STANKH  C ADULTW  E ","T C BHORSEE E ASPECKE P S","G   CEXPELN   EU   FSCOUT","A W  GIRLSL E  OVARYW K  ","T L  WHISKI C  RAKESL S  ","B E  LAMPSO A  CRIMPS L  ","B   TACTORN   AK   CSHACK","A  B LOVERI  G BEGUNI  N ","U P  STARTA S  GATESE Y  ","O  E FLINGF  D E  E READY","S  I CRAMPA  P LOVESY  L ","S  O HALTSO  T ANGELL  R ","A  E COYLYH  E ELEGYS  Y ","A S  WATCHF R  USURYL T  ","P O ESPRIGA D GLIEGEM R D","S S UPIKESI E ICAIRNE N G","U  S SALTSU  E ACHEDL  D ","I F OSAILSL C IE H ESHEER","A  M STOICH  R E  T SIGHT","A G  POREDA A  COZENE E  ","A D JBRAVEB N EOLDERT Y S","S  N MOTORI  I LOOSEE  Y ","A  S SWINEH  E E  E SABRE","S R STHANKI D UREIGNS O K","O A IFISTST S LEVADEN Y S","U M OSTORMI D EN E NGAMES","S  H TIRESI  R F  D FEAST","A  S BEAKSY  A S  T SHREW","A  F SHALLT  O ENVOYR  D ","A W PSHIPST D HE E ARENEW","S A KELFINA O ET O ASATED","S S OTEPIDU I ID K UY E M","A  S SELLST  O I  P RUSES","A S TBITCHY Y RSALVES E W","B  D ODDERO  C ZEBRAE  Y ","S T SPRICKI M ITWIRLE D L","S  L PURERI  A THEFTE  Y ","S U SCONCHO S AWHACKL Y E","A  S FRIARO  U OUNCET  Y ","E   USIGNSS   IA   NYOUNG","A C LLARGEO I DO E GFORTE","M F UACIDSR O URARERY D Y","S B ACAREDA O OR O PS D T","S  S HASTYA  A D  R EATER","M  F INGOTL  R LORDSS  S ","K  M NABOBE  D L  E TAILS","P C WSAUCEA R EL L KMASKS","A  S MEANTB  E E  E ROARS","S S PKITESI A HL K AL E W","S S YMINCEE A ALICKSL K T","U T  STIFFE A  RARESS A  ","S A HCOBRAI L SOVERTN R E","A O AGERMSL D KOBESEW R W","C R ALIARSA G PWHERES S N","S  A CRUDER  O E  R WARES","S L ATHIEFA N IK E REYRIE","P S  LACESA A  YELPSS Y  ","A G  BENDSO A  V S  ETHIC","L V AALIASY Z HELOPER R N","A D ISEEDSP L SE L UN S E","I G SDOUBTI A UO N NTHONG","S  O COUNTO  S RUSESN  T ","S  S CRYPTA  A RENDSF  E ","A    DRINKE    P    TOUGH","H R  OWINGL S  DEEPSS S  ","F  S ROOKSI  I ACHEDR  S ","F  B LOWLYO  A OCHRED  E ","A  A DRAMSO  U B  S EATEN","U V BSNEERI N UNOTESG S H","I K IDRESSL E LE P EDOSES","A A MLUCKYI T TA O HSERFS","S A LHUSSYU S MN A PS Y H","E C LQUASIU V VA I ELULLS","S  E CROAKA  G L  E YOURS","S A  TIGHTA R  TRESSE E  ","T R  HEARTR I  OASISW E  ","S  E MOODYI  I LATCHE  T ","A F ABEINGU R LS M OE S W","U  O SHIFTH  F E  A REALM","A E PRUPEEE I ANICERA S S","A U SBOSOMY U AS A CS L K","A S PCOCOAR O LINURED R R","S G AHULKSA A SL D ETREES","A  S GONNAE  E N  A TASKS","S  L PEDALU  G RITEST  R "," S   STUCK O   TRAYS E   "," A F OVERT A A  I N CLICK"," G  ACOMES R  T G  EDEBAR"," C  ABRAID I  D E  EADDER"," H B VEXED N G ACTOR E T "," S  CDEMUR A  USTEWS S  H"," G S HARPS Z A FETCH S E "," F  SMERIT L  E O  AUNDID"," T G TREAD E S HAPPY T S "," M I JAUNT R U SCORE H E "," H S SUITS S U USING Y G "," F  SCLOUT E  A A  RUSAGE"," Q G CURLY I O  T V DEFER"," S  ASHRED O  IWROTE N  U"," G D VALES B V FLAIR E L "," O E OWING N A LEECH R T "," S  GSANER V  A E  NADOPT"," S  IEPICS U  LPRIDE S  T"," T U THINE I C KNELL G E "," K W ONSET O I  W R ASIDE"," D  SNOTCH O  O R  EISLES"," S  PPURSE G  APANTS R  E"," O A AVOWS E F ARGUE T L "," A  CALPHA O  N O  OOFTEN"," F  VPULSE D  R G  BVEXES"," F A GIRDS R A  E G ODDER"," G  EGAZED U  G Z  EMYTHS"," F  UFIFES N  E A  RCLAPS"," C  ACLAPS A  S S  ESPLIT"," C  WPOWER U  IDROWN T  G"," A S AVOID A N  I E CLEWS"," C L CLOUT A R ENTER K D "," S M APRON I R INTER S S "," B   MISER S    O   ENNUI"," T  UDAWNS C  U I  RSTRIP"," F  UBITES L  I C  NTHONG"," O  ASUITS G  HCHASE T  N"," N S LANKY T I STANK Y S "," G A OUNCE I R ALTER T S "," S G CLEAR A Z VILER N D "," G O TRIPE I I ANNUL D M "," C I SUING L T  T E USURP"," S D ALERT A E  K A TERMS"," H  IPOSED R  LGNOME S  R"," H S MOUTH O O SPICY S K "," R   FIGHT O   STAYS S   "," M  AMOORS V  KMINCE E  D"," G  CTRUER A  OOFTEN T  E"," S U TOAST U A  G G SHOES"," H G RAPID B V KITES T S "," F A TOUCH R H SKIES S S "," H  ABEARS E  TADORE S  R"," R E TUFTS D H VEXES R R "," F  GNEWER R  AFRUIT Y  E"," T  BARGUE I  L P  IVERSE"," H D MERRY R O  O W USING"," B S PRANK I A  G R ASHES"," P V BLOOD A I  N C STEED"," E  APAWED S  O E  RASPEN"," A  BALIVE L  RSOOTY W  L"," T  EFARED I  G N  ESTEPS"," H N PAWED L S  V T FEAST"," F T GENII T E CURRY S S "," T  LVILLA L  RCLUNG S  O"," J S BEGAN T B  T R TYPES"," S B SPURT A I  S N IMAGE"," T S PECKS M A SPITS O E "," S S STALE E Y DEALS L Y "," H S BERTH A I ODDLY Y L "," N D BORES I A  S T  E H "," H  ACOUPS S  H T  EASPEN"," F F JOLLY I A  S I STILL"," M S LYNCH T A THIRD S F "," S  ESTEPS A  SHYDRA S  Y"," V  ISORTS T  L E  EIDOLS"," L  ABOSOM A  USTABS H  E"," C  FNOOSE L  LLIMBO C  N"," M F NOMAD C B  K L USHER"," W B VILLA P U LEVEE D S "," D  ASERUM C  A O  SDYKES"," G  ADOLED R  D G  EVEXED"," P E SONGS U G ACHED H D "," B  ATAMED T  O H  RSERGE"," M S FAKIR X R HIRED M N "," R S DESKS L U FITLY C L "," H C WAKEN T D METAL R R "," R  AGERMS I  HAGATE N  N"," R  AHELMS A  T C  ECHOIR"," G A WRACK O H  U E SPADE"," C D TAKES R B IRATE Y S "," F  RCAUSE C  SREEVE D  T"," S R OASES I B  N E STALK"," H U HOUND W D  L E USERS"," B  BLLAMA O  S T  IUSUAL"," P  CCOVEY L  NRABBI R  C"," C  IFUNDS R  LFLAME S  T"," I  CINFER U  APROWS E  H"," S C GLORY O E  T A CHAMP"," H  TGAWKY B  PTINGE T  S"," P C BLEED A D  N E STUDS","S D FCOWERO E OU L GTELLS","R W UHEARSY V IM E NE S G","P E SROSINI S OZ A BE Y S","S F  TEEMSO T  OBEYSL D  ","S O AWARTSA G SR A AMANLY","E O HSALTYS D EA E NY R A","C P MHUSKYI H TCRASHK W S","G A AARSONN S GGRASSS Y T","A C LFORAYF Y MI P PX T H","A A SBEGATA I ISANERE G S","B S AACTEDT A OO K RNIECE","D E BWATERA H UR E NFIRST","A M AGRIEFE M TNIECET S R","  S IYIELD  W O  E LBIDES","M I SADMITR B EEQUIPS E S","  S  FLEES  E  HARPS  S  ","A B UBLOWNO M IDEBUTE S S","H D SARENAP L NPILEDY S S","A S SMIMICO I AUTTERR H S","C S CRECURO O ON R NY N Y","  U WVISOR  H IPIERS  R T","I C  DIRTYL E  EMPTYR E  ","O F ABURNSE O ISIZEDE E E","S S AKNOTSI L TR V ITHEIR","  O  SLILY  L  SHEET  D  ","A N CPLAZAA V NCLEANE L Y","O A UVEILSE M UN E RSADLY","A F GBALMYA U PS E SESSAY","  L  FIELD  V  BEETS  R  ","S O AWAVESE E SA N ATESTY","S S TPIETYE E PANKLER S S","  L SGOOSE  Y NHEAPS  L E","  P GCLEAN  S A  O WOASIS","A C TSURLYI E IDRAWNE M G","A B OSCRUBI O EDIARYE D S","S R ACLANSO T PPRIMEE O N","W A KARSONT S AC A VH Y E","B S CLATERE A UACTEDT E E","V A  ONSETU K  CHEFSH D  ","S V ITROTSU I SN L UTHESE","  A SCUBIT  A E  F ROATEN","A H SVAUNTA M UI I NL D G","A A BVIGILO A UW P NSCENT","O B ASOUNDI R OE L RRAYON","A D USHUNSK N UE C ADWELL","B A ARIGHTO A OI P MLEEKS","D A SELBOWL H OT O RAPRON","D B GREEDYU L PGULLSS Y Y","  H SGREET  A O  P PMASTS","  B  DAISY  N    D  ARSON","A A SDIGITA I APENALT G E","  O VCOPSE  I N  U ACAMEL","S S  POPESA O  WIRESN T  ","A R  BLANDA B  TUBESE I  ","A B SGRAFTA S AP E NENDED","  U DWORSE  G V  E IBASAL","S R UPRIESI D UL E RTESTY","S A UPAILSO D EU E RTUSKS","C P UHIRESI I ELIVERD Y S","  G AJEANS  P SSCENE  S S","R S BOUNCEO A RFURRYS L L","F G UROLESO I AW N GN T E","A E EGALLSI B SN O AGAWKY","  K ASMELT  Y THYENA  D R","S U UCURLSI G UO E ANASAL","A N SSMIRKT G IETHERR T T","S I BNASALA S AP U DSIEVE","  M USLEDS  E ETUTOR  S S","Z V SEDICTB S AR T LAPACE","O C NDRAPED G RE E VRIDGE","A S OMAKESP U ILANCEE K R","O S IPOLESE E LREEVEA T T","S W  WRINGE C  POKERT S  ","A F GDALLYO A PRUNESE K Y","S D EPLUMBU P BNIECEK D D","A C UFILMSF I UI M RX B Y","F O ARAVESE A PE R ERAYON","S A ITILEDA T EI E ARARES","A S ULUMPSO A UO L RFILLY","A F AGRIPSO N SNIECEY R S","  C ABLOOM  M AMEMES  A S","S I UWIDENO L DO E IPORED","  S IHUMAN  I F  T EQUEER","D S RRANGEA I VN P EKNEEL","U C SSTINTU N RR C APSHAW","A R SCROWNH U AE N KDODGE","P B AINERTL N OOLDENT S E","  M SSMIRK  L U  K LIDYLL","D V SWREAKE L ILEDGET T S","T F SWEIGHI O IGORSES D D","  S  BEETS  N  MASKS  E  ","S S AWEEDSO A IO M DP Y E","  E  VIXEN  E  TIRED  T  ","A M SSTACKT R II E PRISKS","T D  WAISTI T  SACKST H  ","S L SQUIREU V RA E GTASTE","  U GSANER  I IBATON  E D","E S GDECAYI A PCARDST F Y","S P STRACKR C EA E IW S N","A S OTONEDT O DI W LCOYLY","   K FRANC   O WHILE   L "," R U AEONS B I LUSTS T E "," F S TRICK I A  A N WRITS"," S T BEGOT A N SLAGS S S "," P A DIRGE A A  N P HONEY","A  H MENUSA  S SPAKES  Y "," R A PATCH T R  I I CORDS"," T C REARS N O  O W ARENA","A  N VALETE  S R  T SLUSH"," S C UPSET O A  O S CREEK","A  I BLONDA  E SABREE  T "," C S BAITS M I  E L ROLLS","A  A SLATSK  T E  A DWARF"," V L SALES G A HUMPS E T ","A  M PIPESP  T A  E LORDS"," A P AFFIX I N  R E HEADS","O  S FAUNSF  A AWOKEL  Y "," G S GAWKY M U  M N RANKS"," A D QUIRE G U SUNNY R K ","A  A CRABSR  B E  O SOOTH","S  C PASHAO  A O  P ROUSE"," F R RAGES K V RIVEN R L ","P  T SCOOPA  W LEPERM  R ","O  S WORMSN  I EXERTD  K "," H S NATTY V O BEARD N M ","C  A RANGEI  A MUMPSP  E "," M D BEAUX N C  D H  S Y ","G  I ALERTV  A EXITSL  E "," H H LUNAR N L  C T CHASM"," F R PORES C N DUSTY S S ","U  B SORRYU  I A  B LAYER"," F A CLOSE O T MAGIC T R "," B W REBEL E A  C R CHASE","S  M TUNEDE  M MATESS  S ","O  S FLAKYF  U AMENDL  K "," S A SMITH I O  L M BEAST"," H L WAXES Z A WEARS L N ","S  S PUTTYI  E CLERKY  N "," Z C CELLS B A  R I MAMMA"," P F MALES G I BARGE N N "," T C BASIN S T  T E TENDS"," D A HOBBY N U HOIST R E "," P O GRAFT I F OCEAN E L "," S C STILL A O ABOVE S E ","E  D BURROO  I NERVEY  E "," C D OOZED W C  E A DRAYS"," F A CRAVE E E SABRE K S "," C A FLUME E B GAYER R R "," P W CREEK O I  W G ALPHA"," B S PORTS O O PROUD S T ","O  F WELLSI  O N  S GOOSE"," H D TYPED D L  R T NATAL","S  L PRIESE  A NOOSED  H ","A  T BROWNU  E SHOESE  D ","F  C IDEASL  M E  E STOLE"," M S GUSTY R U  A F CLEFT","B  C UTTERX  A O  S MOWED"," D T BROWN A I  W G GLASS","   H BREED   A    T NIGHT"," R L SATYR B R  B I PINCH"," F E CURDS R G  Z E REEDY","B  L INNERG  V HIREST  E "," C I PRUDE E E  A A AMUSE","U  P SWISHU  A A  L LOOMS","S  O CANDYA  D L  E EXERT","P  N RATESO  C O  K FLUSH","A  M STRUTH  R EVOKEN  Y ","S  S KETCHU  E L  N KNEEL"," S S STEPS I A FLING E S "," V W BELOW R R ABIDE S S "," I L UNDUE D N BERGS X S ","A  I GRADEI  I N  O GIMME","E  A PULSEI  H CUBESS  S "," C A GRIEF E G  D I HOIST"," A O TRIPE I I  S U REAMS","A  A GUESSI  S N  A GREYS","S  P TITHEE  A A  S MAKES"," P R LOGIN R S  C E THORN","S  A PORCHE  O LEARNL  N "," S H BASIC L L TABLE D S ","B  A EYRIEI  D N  E GNASH"," D M DOSES Z S METAL N S ","A  A FIRSTO  T OAKENT  R "," H C WIELD L I BLAME S B ","C  A HENCEA  H P  E SHEDS"," C S WHALE A I STALE S Y "," A S SMOKY E I ANGLE D L "," S S FINCH L A SKIRT Y F ","S  B THREWA  A THINGE  S "," E B ENTER R L  O L PLAYS"," S M GAYER N A  E L GREYS"," H I CEASE A L  V E TEETH"," F P CREAK A P FUMES D R "," I W ADMIT Y N  L D BLESS"," B A NEEDS G A LUNGE N E ","P  T AREASN  X E  E LEASH"," I U SMART P G ULCER Y S "," M S RISKS N E HUMID S N ","T  T HIREDO  A SABREE  S "," L P FAIRY I O GROWL S S "," V  SCIVIC S  U T  LPANEL","S U CHUSSYA U NL R ITOPIC"," T  WGRACE O  NCOLIC P  H"," D  HGRIPE A  E P  DAEGIS","O F SFILETF U EARENAL S D","  C LFALSE  E AHERBS  K H","E N LQUAKEU B AA O FLOBBY"," C  GFROZE A  N Z  UFEATS","O T SBREAKE M EY P ISPOON","N S SEXULTR P AV E GEARNS","  B CLURCH  I A  G RUPSET","  B ASWORD  U M  T IONSET"," O  TWAVER T  EZEBRA N  T"," F  AFLITS O  IRAGED T  E","A F PBIRDSI O HD N AENDOW"," F  AGLOWS A  KISSUE H  D","A B CBERRYA I NFUNGIT K C","A H ASHELFI A FD V IE Y X","U C ISPURSH R LE L ERISES","R A EALBUMD B AI E IIDYLL"," D  HDRONE I  R V  OLEEKS","C A AYELPSC O TL N EEAGER"," L  SCOUNT A  OIDLER S  M","A S OSPURSK I IE N EWAGER","O K IFINEDF E IA A OL D M","W C UHOOFSI W UM E RSTRAP"," A  BACTOR O  ABRING N  S"," A  DFUSSY D  I I  NSTING"," S  ESHUTS O  S O  AENJOY","A S ULOTUSO U HN N EEATER","A C CSMITHS V UE I MS C P","N G AAMENDB N DO I EBUILD"," F  AWANES L  SFLUTE S  S","M A HASSAYP S ML E NE T S","  V TSLIME  S M  I POUTDO","    SSCENT    O    RCOPSE","S A NWINCEE T EPRIEDT C Y","P G SSPECKH N IA I FWHIFF","S A THUSSYO I PWEDGEN E D"," H  SPASHA T  L E  TDRIPS"," I  DGRIPE K  AREMIT D  H","B T MLARVAE U SE E TDARTS","S C KTALONA U OCONICK G K","E C EGOODYG R RENNUID S E"," R  AFATED N  D C  ECHOIR"," L  AHOUND N  O G  RASPEN"," C  AWRING I  RVERGE R  E"," P  UDINES O  HNURSE S  R","S O STRAILA K ATHUMBE M S"," G  APRAYS O  SBORNE M  S","S U TMISERA I UCONICK G K","S C ATROTSA N PCRIMEK C N","U H UPRAYSS C UE K AT S L","R E AALARMY R IO L TNASTY","U T USKIRTU D TR A EPOLAR","  C GSILLY  E PBRASS  R Y","O N ISPENDI E IE D ORESET","  H IFIEFS  L L  L ESHORT","  C UQUITS  V ICLEAN  T G","A B AFLUNGI T AR T PENSUE"," A  SFLIRT P  A H  RSABLE"," S  ARUSES L  SSKATE Y  T"," P  SBURST T  ISTERN Y  G","S   UTOWNSE   AE   GPRONE","S   IMUCUSA   LCYCLEK   T","  S UFATES  R A  A GMAYBE","E P EBOLTSO A SN I AY N Y","P A GHYDRAO D YT E EORDER","  B LSEEDY  G ISTAIN  N G"," B  FNOVEL L  U T  MUSAGE","S G STHEFTE N AA I LDRINK"," T  RCOMMA R  T C  IPHOTO","S I ALOVESE O SPARSET Y T","S R AWEEPSE F SL E AL R Y","A M SBLOCKO L UDRAINE R K"," T  SCRANK I  E T  IMELON"," S  EAPPLY I  I N  NVYING","O H ACREAME L PA L LNOOSE","  H SWHORE  R NBODED  E S","I W ASTIRSS D TUNTIEE H R","S   ACAVEDA   DL   EDONOR","S T STHREWI U ECOCOAK E R"," S  SSPILT A  E W  A N  M","L H BINUREO S NNAKEDS S S"," S  SSTOUT R  U A  NSPRIG"," L  ALAWNS B  T E  IFLAIR","  S EJOKED  E I  I FSUNNY","S S STAKENR E AA I IPANEL","  I ECADET  E HKHAKI  L C","R S WOTHERU A EG F AH T K","S T TWHICHO G AR H NN T K"," G  SMOUTH O  OADIEU Y  T","S R TNEEDYA L PGUILES C S","A G BWEAVEF S SU E OL S M"," B  UBALLS S  IRISEN N  G","A T SBRICKU M ISKILLE D L","  O MUNITE  L RWHERE  D S","U M ESHAPEU S RR K IPASTE","S B DQUERYU G IAGAINT N G","P A ULASTSU S US E AH S L","L H FI A OBASICE T ALOYAL","ODIUMC S AHUSKSR U TE E S","T M MA O ECOWEDI E ATIDAL","LAPSEO A  YACHTA E  LASSO","R B HA A AVENALE G VN S E","DREAMI   UNOTESE   ESPEED","R T AI R NTYINGE L LSOLVE","W H GH E AEARLSA O ETESTS","LOBBYA L  SLACKS Z  OBESE","R P TA E ECLAWSE K TRISKS","SALSAP   UINERTL   OLEAKS","B F GR I ROUTDOO L AK Y N","G K OA N BTHEREE A SSEDGE","LEAVEO   AWRAPSE   EDRAWL","PIPERA   EGROPEE   DSITES","W E UA D NRUINSD C AS T Y","E R MN U AJIFFYO F BY S E","DEEDSE N  BUNCHT U  SKIES","DROOPI V OTHEREC N SHUSKY","HERONY E  MUSTYN T  S S  ","VALVEI E ASLABSI K ETASKS","SPACET  O ERASEM  T SWISH","E B HA O YTAXEDE E RR S A","RIFTSE  H SAFERI  I NEARS","DOUGHI   UCROPST   KALLEY","DROVEE    SIGHTK    SHRUG","BREADO   OGRUNTG   EYARDS","B G PE I EGIBESI E TNESTS","H B BO R OBRATSB S OY S M","J  M I  A FIORDF  C YACHT","POSTSA    DUMMYD    YOLKS","REFERI    SWISHK    YACHT","TASTEI W  CLOGSK O  SUPER","WRAPSA    FEEDST    SHOPS","USURPP    PENISE    REMIT","MUNCHI  O MAPLEI  O COINS","PROBES  R HARESA  A WEEKS","GATESU R OSPOILT O VY P E","PARKAE   SCANESK   ESOULS","W C AA R CFRESHT D ESNOWS","LASTSO N  CLASSA R  LEECH","DEATHE   AMENDSU   TREADY","ANGLES O  HUNTSE N  SPARK","LOTUSU   TCHUTEK   PYOLKS","S G CE E RDINGYA I PN I T","DROSSU  E SIEVET  E YOUNG","GREETU X OSPARKT L EY T N","T F OI R RBEARDI U EALDER","APPLYL L  BEAUXU I  MUNCH","SPLITA E WLEVEET E EYIELD","OMITSC  R CREAMU  C RAGES","SAUCEA  A BANDSL  R EASEL","UNDUER  N GOOSEE  A SWAYS","RAVEDA I  FUSEDT T  SLANT","R W PE H OBUILDE R IL L A","Y T OO R BURINER A SSEDGE","SADLYT A  EERIER T  NASAL","VENOMI   UTRUSSA   KLAITY","W C CA R OSCOOPP W RS S A","AGONYL  I BESETU  C MIXED","O W FC O RHORSER L EELDER","PROOFS   AHAVENA   GWAXES","ROCKYO  N WAKESE  L DEATH","CIGARO R OARENAT E DSITES","LARVAU  A MANGYP  U SINEW","BROKEA Z NBOOZEE N ML E Y","F T UO R SROUGHT C ESWEAR","TIDESO R  REACTC W  HELIX","P A PU D EFRIARF E CYOUTH","AEGISL R EPROSEH W RASSES","RENDSE  R BARONE  L LOWLY","W I AI D BDRYLYT L SHOLDS","MARRYU  U DROLLD  E YOURS","GREATA X RBLAZEL L NE T D","H C RO A APULPYE Y OD X N","BLAMEU  I GRANDL  U EXIST","E  W A  E GAYLYE  L ROOST","HEARTA   EPRONEP   TYOUTH","ROSESA  A TRUTHI  E OVENS","LIVIDO  D GILLSI  E CANDY","U  V N  A DRAGSI  U DARES","M M WO U AVELDTE T CSMITH","COVETA I UBLASTA L OLOSER","LIEGEA P JSNIPET C CS S T","W G AA I BLYMPHK M OSMEAR","O R CR O OGLUEDA G EN H S","THEFTO  A QUICKU  E EXIST","GRIEFA   ETOWELE   OSKEIN","DUCHYR  Y ITEMSE  N SOUSE","DRAFTI  I KILLSE  M SWAYS","VOICEO  A CRESTA  T LOUSY","FUSEDL    ASKEWI    REIGN","M A AA U IJADEDO I ER O D","HARTSA  I SCULLT  T EXIST","RILEDI    FORDSL    EQUIP","ODDERC   AHAVOCR   KEDGES","MULTIE  W RESETR  E YARDS","CUBICI O ATILTSE T EDISKS","GRIMEI    FIXEDT    STOCK","DREAMU  L CAPESA  R TORTS","OSIER L  IFASTS T  KLEEKS","STAGE U A TRAMP N E  S S "," G A  A C ALPHA L E  S S ","ROVER T  ETHREE E  VBRINE"," C S  L H REBEL F A STARS","OFFAL L R EAVES I A PRESS","GLOVE L   JAUNT M   WAIFS","ISLET T  WDANCE N  EEDGED"," C H  U A CREST D T USHER","SWEPT H   RINGS R   BLOWN"," G J  I U ABIDE E G ASHEN"," A  P M  OLIVES G  SGORGE","STEEP A  OPLACE L  TTYPES","SCENT L  ELAYER I  MAMASS","DUSKY S   JUICY R   UPPER"," W  W O  IMULES N  PIDOLS","SCALE R  LDELVE E  CADMIT","CHEFS O   GOODS F   USING","USHER P  OSOULS R  ETEARS","ELFIN A  OSTART H  CTEACH"," H Y  I A GROWN E N  S S ","AGLOW U  OALTAR F  KASHES","ISSUE A  SCLIPS T  AESSAY"," S  C T  EHALED I  AIDLER","PSALM K  AHILLS M  OASHEN","SWEAR O L BONDS E E ADORN","SCOUT A   STEED C   SHRUG","PSALM H I MASKS V E NEARS","AFTER R N PALSY I U ALOES","SPENT L  AVILER E  TUSERS"," J  A I  IOFFAL F  ETYPED","USURY W   RESTS E   STORK","TRITE A H STOIC I C CORKS"," G  A U  UBEING S  HISLET","CROOK O U PAWNS R C ISLES"," S P  T A PODIA U N STATE","CRIES I   SPRAY E   FROND","ABHOR R A HUSSY S I THESE","ADORE R E CARVE G E PSALM","PAINT H  WREEVE A  EIDLED","IRATE E H VEXES D M ASSET","TWICE A L CLEAN L C  S K ","ICING U  AGRAVY V  EMETER"," F  A L  NBESET A  EUSERS","ASSET H  ISOUND O  ESKIMS","SHAPE E I CAVED P R  S S ","SCREW U  IELFIN T  CUSAGE"," P F  S E WHOLE A O TWANG","USING P U MERRY C S SKIES","GREEN A   SCULL E   PSHAW","HERBS Y   WIDTH N   AGATE","SWEPT R R MERIT A S SKIMS","FENCE T O CHIDE E E PRISM"," I  P T  IWEAVE M  CUSAGE","AFOOT I   FEVER N   ADMIT","AFOOT L  EROSES W  TUNITY","QUOTA S  NSHOCK E  LTRACE","DOERS T E CHUMS E I CRATE","ABYSS O I DOVES K V ASSES","GAUZY I   CLING E   UDDER"," G A  R W CIGAR L I FLITS","IDEAL O S AGATE M E CADRE","USAGE T A CARTS L E YEAST","SCALP R  OPORTS P  TASSES","ABIDE R  ARIVER D  NPEAKS","KARMA B A OBESE O O STING"," G  S L  LGORGE V  E E  P"," S B  E O TRILL V E BEAST"," C  C R  LVOICE C  RSKUNK"," K G  N A SEEMS E M FLEAS","ASHEN T   FEATS A   IDIOM","ONION E P SEWED D R ESSAY"," F F  A I TILED R R  Y Y ","SCREW L  AVIRUS M  TOBESE","PARTS V R LOCUS W C ASKED"," B  L U  ASTOCK T  EHEADS","TWIRL A  AGIANT F  EASTIR","CRIER O  ASULKY G  OSHEEN"," T S  R T MALES C A ATOLL","USAGE L  SCURLS G  AUSURY","ASTIR N N MAZES R R JETTY","POKER C  ONECKS A  IUNION"," G S  R T JOYED I E SNIPE","STABS R E BERRY A R STAYS","AMUSE E  AAREAS C  EHYMNS","AGAPE L  ABEFIT A  EENTER","ASIDE T O CIVIC C N  K G ","WAIFS D A COMIC B T  E H "," D  H O  ECOPRA R  DASSAY","SPELL S O CHUCK A U SWISH","THEIR O  OPROWL D  EREAPS","STAGS R U EARLS I L  T S ","SINKS R  LGOUTY N  LASSAY","CRISP I L ODDER G P SECTS","GOODY C U THOSE R K BERYL","OSIER P L DICES N C HEATH","STIFF I  LAMPLY I  EUDDER","AFTER E  ISTAIN U  SISSUE","KETCH T O SHOCK I O SCRAP","PANIC S  OCHIPS E  TASHES","  F M  O UBURNS  G EHOODS","R A FU L LFAIRYF B ES I R","MOCKSA A TINNERL O ASEEDY","PUFFYO O IPURSEP G LYIELD","EAGER  O EFINDS  N TSTAYS","BEFIT  U AMANOR  D TFASTS","M M JA O ONEWLYG E EACRID","KNELL  L OJEANS  T ESHEER","CUBICI L OGROOMA W BRENTS","DUMMYI E  NOSEDE A  DISKS","E E DN D UVOGUEO E LY D S","  V O  I AWANTS  E EFISTS","BOSOMO T EUSUALT D TS S S","PIPEDA R ODRIEDD D GY E E","C J JU E OFRAILF N LS S Y","STRUT  O HWHORE  M IBUYER","DECAY  A  HOMES  P  NASTY","  Q F  U UTWANG  Y UTASTE","WAILS  D UROYAL  L KKILLS","  H O  A DEASED  T LCOYLY","MOWEDE A ESEVENA E TSORES","SCALP  D OSTOPS  R ERUNES","AISLE  T  SLUSH  M  ALPHA","T U AO L BPETTYI R SCRABS","IDIOM  N AWHEAT  R CWITCH","ARROWM O ABISONL I TE N S","DICTA  A BHOBBY  I SMINUS","COBRAA A BNATTYN O SY N S","NABOB  A USOCKS  O TTONES","W S MA H IFRAUDT M SSWEPT","M G SI N TSHARET T AS S M","G C FA H ISNUFFE N TS K Y","FACTSR O  ODIUMN N  TESTY","LOCAL  R ODRAFT  S UVESTS","  C W  A ILURKS  D ELOSER","FACTS  O  BRATS  C  ABHOR","HACKSO I  PIVOTE E  DITTO","GOUTYA S OSTARKP G ESPEED","  B P  R OCROWN  I DKILLS","SANDY  A  SHIFT  V  GEESE","R D PE U OSUCKSE K STASTE","D L CU I OCONESA E TTASKS","ETHER  E EEERIE  D DMUSKY","POSESA H EWOOERE U FDOTES","ASSET  A HTALLY  T MMAYBE","W B FA O IFORMST E TSIDES","B H OU A CRANCHS D RTHYME","A E BD A ADOSESE E TR S E","GREYSO L UALDERL E ESURER","D S EI C XSHEEPK N ESTEEL","H W EA A ANAVESD E EY S D","REBUTA U AJURORA S TH T S","LAWNSO O  GIRLSI S  NOTES","FAWNS  A ACIVIC  E KROSES","HOBBY  L  KNELT  N  BUTTS","WATER  E AWAXED  T ILASSO","SWEPTA L  GRUFFA D  STEAD","UNCUT  U RCOBRA  E MWASPS","ETHER  O ITESTS  T KMUSTY","W M UI E SPATCHE E ED D R","W L BO O ARAVENL E DDUSTY","LIMBS  A TPURSE  K PBASIS","HAIRSE N IWAFERE E EDARTS","LEMME  E  SHAKY  L  PAYED","YOKEDA N ECLOVEH W PTESTS","  G V  O ILURES  E OUNDER","MANORO I ITONEDI N EFLYER","V V RE I IRACKSV A EEARLS","B F MI L OBRAIDL R EE E S","  F G  L ACROPS  W EPANTS","A S PC O AHOLESE A TSPREE","RIVER  E EFORGE  V FDRESS","PUMPSO I  PINESP C  YIELD","J D FI R UFLAILF M LY S Y","P M FE Y UAGREEK R LS H S","A J FC U OHURRYE O ED R R","  W C  O OFARED  D EFISTS","S P SU O PPOSSEE E ARIDER","B M UA A NSIXESS I AO M Y","P B LR E YORGANX U CY N H","C S CA H IDRAFTR M EE E D","TESTYU T  FEUDST D  SHYLY","FACTSO I ORIDERG E RO R Y","W C GA H AROOMYM K LSEEDY","CATCH  R  FOUND  T  OTHER","DUCAL  I ICIVIC  I KBOLES","RAKES  N  SHOWS  L  GULCH","L J FO U EFOISTT C IY Y D","ASHEN  O  DOTED  L  GAYER","ROLLS  I  MINUS  E  RENDS","HAWKS  H  SEEDY  L  GAPES","WASTE  T  PEARL  L  LIKEN","GAPES  L IDROVE  T GENSUE","AUDIT  E ATHUMB  C LTHEME","R D BI R IFIELDL G EEASED","AMBER  R OFLAGS  N IWIDEN","HOLESE A  LAMPSM E  SIDED","EAGERA L  SLEETE N  DUSKY","P B PO E OSLACKE C ER H S","AMPLYW R  FLAKYU T  LIEGE","WAILSI  O PUFFSE  T STAYS","SCOFF R E HOARD P N  S S ","STAGS O L SQUAW U R SEVER","NURSE N O STUFF I A FEAST","TWIRLA  E BLINDL  D EXIST","RINSEE  T AHEADD  C YOLKS","TOOTHE  E ROPEDM  T SIGHT","GOADSA  R POKESE  A DRUMS","GRAMSA  A LOCKSE  E SPASM","GIMME D E SLASH E A WREST","FARCE B U WHIRL O D AROSE","OVALS A O LUNCH N U  T S "," S T  L I HARMS K E BEADS","OATHS   U MANSE   K PARSE","EXTRAX  A CHOPSE  I LEADS","BRAWL   A PANGS   E ROARS","SCOFF R O QUALM M I ABBOT","EQUALL  U BENDSO  I WRITS","AVOWSI  H DOZENE  E DWELT","SCOFF O A CYNIC L R GYPSY","TULIPI  D CONESK  A SOUSE","LAPSEY  H RAKEDI  A CHEFS","VALVE B E CHARM O G IRKED","BATON   T JESTS   E AVERS"," A Q  C U FRIED E R  S Y ","BUILTO  O REIGNN  E ERASE","SPARSA  I CORPSK  E SPANS"," C C  A O DRINK G C MOTHS","VICAR T I LEMME M E ASIDE","MAYOR C O GRAZE I E  D S ","COMBS   A SILKY   E ABODE","PERILU  G FILLYF  O SALON","BRAWL U A BLAST E T ASPEN","MANGO   A FETUS   G JOYED","BRASS   T FELON   R GRIME","MINCE   R SAGAS   G BOAST","RAISE   W UNDER   A JESTS","VIEWS   E MISER   D POSSE"," F F  I L PLEAD C S  H H ","EIGHTN  U NOBLYU  L I  S ","ADOBEB  I BUMPSE  E YARDS","AFIRE U A FENCE L K  S S ","AMIGO A U EYRIE B L JETTY","SPEED   M CUBIC   T FLASH"," V C  O L GLEAN T S  S S ","MOANSA  A JUNKSO  E READY","CANES R V MOLAR M D GAVEL","SPASM U C GLOOM L O  S P ","UNFIT   M SHIPS   E DEALT","MOUSE   E CURDS   A FOUNT","OFFAL A M LURID N S DAISY"," K C  N A HEATS E C ALPHA","EDICT A A AMBLE P Y  S X ","NIGHTE  E WAKESE  L ROUSE","WARMSO  O REINSM  K SPASM","LEMMEI  U FABLET  E SWISH","CRABSU  E ROPESS  C EIGHT","CLODSE  Y DECKSA  E ROUSE"," S T  M A LATCH L K CLASH","ASIDE M I NATTY L T FLOOR","HURTSO  Y SLOPST  E SENDS","GANGSI  R RIPERL  E STAND","TITHEI  O DIARYE  N SALSA","SWAMPE  A WHISKE  K ROOST","GROWN   H PLIES   E GUILT","RENTS   A LAMPS   E PADRE","CRIBSL  R UNIONC  W K  N ","ABACKI  A MOOSEE  E DEEDS","N  Y A  E BLEAKO  R BLEND","LAMBS B U MULTI S T TENET","MAINSU  E COPSEU  T SLASH","USURP N O DOUBT U I STAND","RIFTSU  A DRAINE  N RESTS"," W T  A A FLAKE T E  Z S ","YACHT M I OPERA L E SEEDS","TORSOA  E SPICET  T YEAST","FROGS   A GROWL   K BERYL","FORDSA  O CRAZYE  E DOWDY","LIMBSU  R LINERL  A SACKS","DITCH R U MAYBE T I BEACH","REAPS M E NASTY I T PLAYS","KNOWS   A POLKA   E AMISS","LASTSU  A LEMMEL  E STUDS","DERBYU  L CADETT  A SLATS","CLAPSO  O WINKSE  E DENSE"," C G  L L FORAY G Z ISLES","ERASER  C ENSUEC  L TULLE","STABS O O OPERA A N  Z E ","DEUCEE  R FETEDE  P ROPES","SPARS H A HOSTS T E HORDE","OMITSW  I IDLEDN  R GYPSY","AMIGO I A ADOPT S E STUDS","ADORNU  E GOUGEH  A TOOLS","CLEFTO  I WAVESE  L DOWDY","RAYONI  F SWIFTK  A YIELD","STIFFE  I DRIFTG  E EXIST","HERDSA  A BULLYI  E THESE","OUTDO   R PETAL   M TRUST","SPASMI  O DAILYE  A SORRY","LOOPS P U BERRY N G ASHEN","WRAPT O  EEVADE E  MEDGES","ELDERM E OIMPELT T LS H S","SPERM L  UHULKS M  TBELLY","IDIOM I  ADRAGS T  KDYKES","  C F  O UVOWEL  E LARRAY","LISTSO H PINANEN M CSTEAK","OAKUMR   OBEFITI   ITHIEF","CLIMB E  UBANAL V  LDELAY","AROMA E  TABAFT U  IETHIC","MINEDA   USHIRKO   ENAMES","N M EO A TBIRTHL S IETHIC","RELIC  E HSHAME  S ACREEP","CHIRPL   AAUGURS   KHYENA","SCOFFO   ICHURNK   ESOWED","RENEWA O ICLUMPE N EDISKS","BREAK  Q EJAUNT  I CDEPTH","CLANG    ITHROB    ELOOKS","MOVED C  ETHUMP R  TBEACH","L G FO O OGOUTYI G ECHEER","L M BU U ACORALK K MY Y Y","P G CI R OGRABSM V TY Y S","QUAFF    RTASTE    EACRES","AGING U  RSERVE S  EASKED","USHER C  IFAWNS R  ERESIN","SCALD  D EQUELL  P TULTRA","D S AE T PCHUMPR N LY G E","P F EA O ALORDSE T ED H S","OTHERT E EHEATSE L ERESET","VENOMO O AMUSTYI E OT D R","MELON P  ORINGS C  EISLES","WIDOWA   IGREEDE   OSTREW","L P DA A ISHIFTT R TS S O","R F JE L EEXALTV R TENEMY","C W SO O HLARVAO S LNATAL","AMBER    IURGES    ECIDER","DEBITR E HIDLERN I EK E W","BURNTA E ACOILSO N TN S E","STING  D RSHINE  O EADMIT","NABOB V  ILATHS I  OCLOWN","ACRES A  OFINAL R  AINCUR"," D  B R  ALASTS M  ALAPEL","  L U  O PYOURS  S ECRYPT","FOUNT P  HDELVE N  FISLET"," A  P B  OSYRUP S  PUSURY","H R QA U USALSAT E CY R K","NABOB    UDEEPS    TPINES","BOILSI   PLEVEEG   NEGGED","THROBU U ATALONO E GRARES","THEIR  X ECHAPS  L TGATES"," B  B A  EARENA O  UANNEX","ROARS    ARAVEN    DPEERS","W C VR A EOWNERN O SGENRE","ODIUMF S ATASTYE U ON E R","RACESO O PCHAIRK L EY S E","G M DI O RMOTTOM I WELFIN","S C AT H ROWINGO N UDRAKE","R V PE I EFELLSE L OREAMS","TOXICA   LSHOVEK   ASKEIN","TUSKSA T OKARMAE U RSITES","WHISTA   OGRAINE   IRELIC","H E NU L OSWAYSS T EY E S","ASKED O  EQUALM S  OSEVEN","FIFTH  L UCROPS  U KBARBS","FLOUR  P UTOTAL  I EKICKS","AIMED    AGROAN    DDRILY","R W AE R TFLINTE T IR S C","SWAYS H  TLOWLY R  LTERSE","ASHESC E MIGLOOD P KS S Y","MOISTE   HSUPERA   OSPADE","E T PT O OHOWLSE E ERUDER","LILACA I OWHEELN N OS S N","ABHORW E UACIDSK R EEASES","SALON  O AKIOSK  K EBASED","S C DH O IREBUTU R TBRAVO","BUXOM    OVELDT    ISHEAF","SHELFU M RLAPSEK T AY Y K","BASICA T ADRAMSG I EE D S","STIFFM   IEERIEL   FTOILS","SWEET    AMINDS    TMAYBE","CABIN W  OFALLS I  ESTOOD","BASIC  T IBURNT  E EYAWNS"," B  P L  ETIGER N  ISKULL","CRUMB    AHOTLY    OADIEU","SURERW A OENJOYP A AT H L","CRAWLH N EANGLEF L CE E H","CLIMBA R ESTAGST T OE E M"," F  P O  OBLEAK L  E Y  R","MANNAA   SCORESE   ESHIFT","SWEEP    OGROWL    LCLASS"," T  O O  MTRIBE S  NBOATS","MAXIM G  UBASES I  KSNAKY","B C EA R VSHONEI S RC S Y","ODIUML T EDEEMSE M ARESTS"," C  V H  ICAKES O  OUSHER","STUFF A  IAPRON E  C S  H"," B  C O  ACODES M  EASHES","LIMBOO E TWRATHE L ER Y R","FOLIO P  CWELCH R  RVALUE","  T P  E USTAYS  R SPASTY","CHEAPA L OMEETSP C ESITES","C O  HATERA T  THEIRS R  ","W P  OMITSR E  DICESS E  ","MOWEDU   RM   EPAILSS   S","C G PRARERE E OABYSSM S E","P C NO H AE A SSHIFTY N Y","T  J ROPESY  E SPURST  S ","MUSICO M HU E ITRAMPH R S","L  Y ERRORA  L KHAKIS  S ","BLUFFA   UR   SBUMPSS   Y","C E  HYMNSE A  SMIRKT L  ","NESTSO C WO O ISOUPSE R H","LAPELE R UA I MSLOOPE R Y","T  P RIVENU  R MOTIFP  L ","E  F PSALMI  E CIGARS  S ","POPPYI  U C  F KNIFES  S ","KNOCKN  U I  B FLAILE  C ","MOTIFU A LD M EDUETSY D H","CHEAPH E SU R ACHILLK E M","P  G ULTRAD  E GIVENY  D ","C  R HAREMA  S RIPENM  T ","PRICEA  R D  O DRANKY  Y ","AWFULP L OA O RROUNDT T S","STOICW   AE   LPOPPYT   X","DUCHYE  I B  R ABBEYR  S ","I S HMOOSEA F WGRAVEE S D","DAUBSR  U E  L GULLSS  S ","F C TIMAGEL S AMOTORY E S","TRYSTE I EN E ADALESS D E","Q V MUNITYE R TSLUSHT S S","KINDSI  A N  T DATUMA  M ","FLUFFL  E A  L SWOOPH  N ","ABATEL  O I  R BOLTSI  S ","H  F AUGURV  M OASESC  D ","BONNYA  A R  V DEBARS  L ","F  B OPERAR  O UNSAYM  D ","TUTORH H OE R ASNOBSE E T","B A SRADIOA O WVERVEE N D","C V PH O IA C TFLASHE L Y","C  O LEASEI  I MATEDE  R ","T   KHAVENI   EREBELD   T","LOWLYO E AO I WPAGANS H S","D  C ROYALO  V PILESS  S ","A T LNOOSEG T ASCARFT L Y","C  L RARERE  E WHACKS  H ","FRAMEL B XO A TOCCURR K A","PEERSL  E A  E NECKSS  S ","B  P ADORNR  O KEEPSS  S ","H A  AREASR O  PANSYS S  ","SCRUBP A UR N RINCURG H O","K  B ISSUEN  G DEALTS  E ","B A SLIMITI O ASKULKS R E","CLOUTR C EA E AVIALSE N E","HATCHE E OL E UMYTHSS H E","TIERSR A MY R ASALTST S H","S  S CIGARR  N IDLERP  R ","BASICL O RE R EALTOSK S S","BEASTL  P E  A SPAWNT  N ","H M WUNITES N DSTUNGY S E","G  W ROARSI  O MOUNDE  G ","DEFERR  D U  I GRAFTS  Y ","DYINGA   IR   DTRIADS   Y","B D LAROMAR W IDONORS Y S","CHUTER  A I  S MELTSE  E ","FORUMI E OR B ASPURNT S S","W    RUNGSA    PADDYT    ","P T WLLAMAU C IMAKESB S T","T  T RAYONI  D BIRDSE  Y ","OPENSC N PE N IADULTN I S","H C TA H OP I LPENALY A S","M T GA E RR R ARIMESY S S","M  W AVOIDT  P CREEKH  S ","CRUDEO S DR I GDANCES G S","C S GROWDYO A PWORDSD M Y","MULTIO  O A  M NOSEDS  S ","GRUFFR  U O  N WARDSL  S ","O  A RENDSG  O AWARDN  N ","S  C MOTIFE  D LOBESL  R ","BERRYL  O U  G FUGUEF  E ","F U RLASSOU U ASORTSH P T","NAKEDA N OT O SAMBLEL S D","M I IOWNEDO A LNONCES E D","S F PL L OE U SPIKEST E E","WHIFFO M IR A SSIGHTE E S","E  R LINEDE  E GROVEY  E ","E  S AMPLEV  Y EVILSS  Y ","S  T TIMIDE  D AURASM  L ","CIVICO  T R  E PRIMES  S ","D T GOTHERU R AGLENSH E S","BRISKR N II E OGERMSS T K","S  A TOOTHU  T CABALK  R ","B  R ALIENT  A HITCHS  H ","DELLSI Y LS I ACANNYS G S","APINGR  A I  T SQUAWE  L ","T F BOZONEM R RBAGGYS E L","LAKESA   CR   AGROANO   T","M  A OXIDET  O TWIRLO  N ","L S  OATHSB I  BONNYY K  ","T  S RIFTSA  O IMBUEN  T ","L U  AUNTSS C  SLUNKO T  ","SALESM E OA M ULAMBSL E E","TRULY E A  B C LUCKY T S "," S T STRAY R B CABBY P Y "," H M AUTOS M W WINES D R ","OFTEN L  I O  GBUNCH R  T","SMOCK E O  A L ATTIC S C "," D  ANEWER L  ISTEMS A  E"," L  QBAYOU T  ASHYLY S  S"," B  FVIGIL G  UWHARF T  F","AVOWS I A  Z V POLES R R "," M   SEEKS A   KNOBS S   "," F S BIGHT C A WHILE E T "," G C TIDAL V S PELTS N S "," D  CHELLO C  MHORSE Y  R"," D B YEARS C U WAIST Y H "," V M FILET R L QUOTH S S ","BERRY L O  O A APART E S "," C  SAUDIT R  UBROWN Y  T"," O  PAVAIL A  USLITS S  H","AGREE L  X E  TRAZOR N  A","ASHES H  H I  EOPINE S  R","AFOOT R  R E  UFAILS K  T","IDIOM E N  E I SPOON S N ","SOAPY P R  A O ALOUD S D "," P  SPRANK A  ASNOUT K  E","ABIDE R R  O E JOUST K S ","TEMPO A L  T A MEANS N S ","TAKES N  P G  AFLAWS E  M"," Y E RENDS A I BRICK N T "," P  WFLESH E  OBANNS D  E"," V C SOARS G E OUTER E K ","DRAKE O N  S O FITLY N L ","COILS U E  G A CHIPS T S "," B  TSOWER D  YREEDS D  T"," C M PROOF E O HANDS K S "," S E SPUNK O D MOTES K D "," D A HERBS C O HOODS Y E "," C S PINTS V A SINGS L S ","STRAP O  O X  IDICES C  E","FLUFF A  R N  ASCORN E  K","OWNED A Y  S I STANK E G ","OFTEN L  A O  VSOLVE D  S","HANDY U U  D C RISKY O S ","MANGY M  O B  UGLEAN E  G"," F M TABOO I L DREAM S R "," Y P REARS A O DRANK N E "," L J VAGUE T I WHACK E Y "," L  SQUASI N  GWATCH R  S"," G B PROUD O G DWELT N E "," E C EXALT T U BOOBY L S ","HARPY H  A E  CCATCH D  T","OMITS I  K L  ACLOUT S  E"," G  ACREAM I  ASPARS S  S"," S W THERE O I SOOTY N E "," B  WSIXTH G  IROAMS T  K"," M  PHATER L  ESEEDY S  S","WHIRL U  O M  WFURZE S  R"," A F SWELL A U LIFTS T E "," O B TRIAD G C CASKS N S "," S  SSHORT O  ARESET S  E"," M S QUICK R O HARPS L E ","SMOTE E I  T M MARES L S ","PSHAW L  R A  IASPEN H  G"," O G SCREW C E CURSE R E ","OPALS R  L O  UAXLES Y  H"," M  MVISTA N  IHUMID S  S"," J S COUNT Y O REARS D T "," S S STRUT O L NOBLE P Y ","STONE H O  R O NOISY E E ","CINCH N  A U  LPROWL E  S"," U W UNION C U BLEND E D ","DIVER D  I L  NDEEDS D  E","BADGE D I  M L KINDS T S ","GREAT I B  D O DELVE S E ","CRAGS U L  R A CADRE L E ","AGILE E    N   FUZZY S   ","ABASE L P  O I MOLES M D "," S C  Q H  U A LASTS W S "," M F OAKUM L S TENET S S ","TWANG A  R K  IPEONS N  T"," S  TSPOKE A  AEDGES E  E"," C C GLARE O E RUPEE D D "," B  ADATUM C  ASKIMS S  S"," A N ADIEU E W UPSET T R "," S  UGLOWS I  IONION G  G"," L  SREGAL M  UTOWNS N  H"," L  LSIEGE V  PDENSE R  R"," S  H T  I R  NEASED P  S"," F P RELAY V N VESTS R S "," F  HAROMA A  RLULLS D  H","ASSES C  I A  ZELOPE D  D"," S G SPARS O O GROVE T E ","STEAK Y N  P G NEWLY D E ","SPADE R I  I V OCEAN E N ","TEACH G R  G A TERMS D P ","PEARL N  O J  OPOSES Y  E"," P H CAPON P P GAZED S S ","APRON A C  U E PSHAW E N "," B H FRIAR E S HASTE K E "," S  MDOGMA L  KAISLE D  R","LACES C B  T O LOINS R Y ","BADGE  R A  O GQUOTE  P R","FUMEDL I WE N EEQUALS S L","A S PTOURST A AANVILR E M","A G ACHAINU M GTWIGSE N T","T S  RULERI O  BOOTHE P  ","S W  CRABSO I  FUSSYF T  ","  D FMORAL  A ADOWNS  N K","COATSR U IE T NAMONGK S S","PESOSE L PA O IRIPENL S S","FLUESI N ME D AFAILSS D H","L S PE P IA E TPINCHT T Y","C T TLARVAA A SCHINKK T S","VOMITO O RU M YCOMBSH A T","W S BE C OI I LGHOSTH N S","L F CADIEUT N BCEASEH L S","  T USHUTS  N ASLING  C E","FIENDE X RI I AGUSTYN T S","  M GSTORY  L PPEALS  R Y","  B  LARKS  U  JUICY  N  ","WISERA P UN I LTITHES S S","DOWDYE A EA F AREELSS R T","C C GL H RU O OBURRSS D S","C P PRARERA A OBAYOUS S D","E S PP T AO O ICRUELH T S","A S TDANDYM E PIRATET K S","S F  LEEKSE L  PALMST S  ","I B TD A IE G TANGELS Y E","  O PVIALS  K HFAUNA  M W","AFFIXT I  O L  LAMESL S  ","S G ACALYXO I LLODGED E S","  C DGLOBE  P NGIRDS  A E","  G DCARVE  I BVOMIT  E S","  T TSLIMY  E PPURSE  S S","S M CLEECHA T EPREYSS R T","CHOPSR R EA G NSOARSH N E","OCHREB U XE M ISLAPSE N T","OVALSI U LL G IETHICD T K","  M BGLARE  N ABEGUN  Y S","CUBITR E IO G CSMACKS N S","WAGESI R HS A OPRIZES N S","S C QO H UU E APIETYS R S","  L NFOLIO  A VLEMME  A L","  O BCAPER  T IQUITE  C R","PIGMYO R ON O LDRANKS N S","PAVEDL O RU C ACHAFFK L T","A B PBLUESO I HDELTAE D W","ISLET  U R  N UVICES  H T","  R  WEEKS  P  DIARY  Y  ","T P UROOFSA E UMOMMAP S L","  S PPANEL  E OBLAST  K S","  D VFORGE  O XSPORE  P D","S M LT U AO M NRAPIDM S S","MOMMAO A SR D TADAGEL M R","P G PRURALO O UOPIUMF N S","GUSTSU L TE A ESEIZET N P","CURSEH A RU C ACHESSK R E","CLAWSL T PO L RDRAMAS S Y","S G GCHAIRR M EICILYP N S","REBUSO R AO O TFOAMYS D R","MERGEA O XU U IVASESE E T","L C  EBONYA P  FURRYY A  ","S S GPIANOI L OCITESY S E","TUFTSO I LW L INAMEDS Y E","  M HFLORA  A TTUNIC  S H","N P AE E ME N EDRAWNY L D","GREENR A OA R IBOLESS S E","C O SREALMO K OCLUCKK M E","M T PI O AG P UHAIRST C E","K T BINANEO B RSMOKYK O L","S F STREATE R AMERITS Y E","COMERL E IO S NWRAPSN S E","RISKSE P OE I RVALETE T S","U S SSWOOPE U AROPEDS S E","P M  OVALSU N  RIGHTS O  ","  H ASTAMP  P ATOPIC  Y E","CUFFSO L CU O OGROUPH R E","COMICR U LO S OWRINGS C S","SNAPSM U LO G ACRUMBK R S","W O VE V OA A WVERVEE Y D","  S WBEACH  L IGNATS  D K","SACKST R HI O ULEASTL K S","W P DHELLOI E ZSCAREK D D","C A BL V UA O CSTINKS D S","ENDOWP E AI P NCROWDS T S","  M AQUITS  M KCLIME  C D","PIQUEO U XE O UMETALS H T","  P SBLINK  N IBUTTE  S S","E K  LOINSE L  GOLLYY S  ","MASTS  L A  O LFLOUT  P Y","DICEDA L UI E PSHAKEY R S","  G CSALSA  O LSTORY  M X","LIGHTE A AV U REGGEDE E Y","DEBITA A AM S RPAINTS N S","MIRTHO E OI C USHUTST R E","C K THENCEA E NSLAPSM D E","A O PCOCOAU E NTRAMSE N Y","PECKSI U AL R LLOVESS E A","P R PR O RO G IPRUDES E S","CASTSA P LB L AAMITYL T S","B B NR E UA G RSWIMSS N E","GRUBS O A  L C FLAKE S S ","HEDGE N R  N E QUAYS I S ","KNAVEN  I O  A TRILLS  S ","R  V EAGERA  N MINUSS  E "," A C BREAK G R BURRS E Y ","FISHYE  O N  I CURSEE  T ","PSHAW L U  A G MYTHS S T ","STEPSW  A I  I SPANKH  S ","TOMBSR  O I  N PHONES  Y ","BARBS D L  O O DRAWL E N ","EIGHT D E  E A SANDS S S ","CRUMB E I  L X NICER C D ","BANJOO  A M  I BELLES  S "," R A CABBY D L LINED I R "," B N DEBUT A D ADAGE Y E ","L  Q UNCUTS  A TRUSTS  I "," V R BISON S A DOGMA R S ","G  F RAZORO  G WINGSN  Y ","GRAPHN  I A  P WAKENS  S ","SHONEP  E I  W CREEDY  R ","A  T USURYG  I UNSAYR  D ","AMUSE A H  I A UNCLE S T "," B G BROAD O M HIRED L S "," V G HARRY P O MINUS D P ","BENCHA  L R  A BLOWNS  S ","SLIMY O O  C O LASSO L E "," D M PODIA W L CREEP Y S ","FLOCK O H  Y I LABEL L F ","DEUCER  Y I  N VAPIDE  C ","CRESSH  C A  A PRUNES  T "," D R GROOM E U HANGS M H ","CHEFS A I  B N SITES T S ","HARRY P O  R U YOUTH N S ","ROLLS D E  D A BLUFF Y Y ","CHEFSI  I N  E CHAFEH  S ","LOUSYO  C B  A BLURTY  F "," D B BORED N A LOOSE R T "," D P FUGUE C P DAMPS T Y ","A  P SPEART  I INERTR  S ","B  I LIENSE  L ADIEUT  T "," M H CAVED X A TILDE M Y ","C  C LATHEO  I WORDSN  E ","M  Q ODIUMO  I SAWEDE  T "," B C ALPHA O E MOOSE M S ","T  V REGALI  L ATTICD  D "," S E START O E TRACT Y T ","O  A CHAMPE  I ABUSEN  S ","SMART O O  T S VICES F S "," Q T BUSHY A R ARSON T E ","FILMS D A  I P COULD T E ","CRAFT A L  Z A DOGMA R E ","C  B REFITA  R SANDYH  S ","V  C OPERAT  I EASELD  D ","CRABSI  I N  G CAPONH  T "," M I BURRO R A WANTS L E ","DOOMSA  U N  L CAVESE  S ","JIFFY   L    O DITCH   K ","VERSEE  H R  E BILLYS  L "," L R SOLOS G P TIMES C S ","B  B REARSI  I GAVELS  R ","COAST A T  K I HELLO N E ","P  G ALBUMR  E TRUSSY  S ","MILES M Q  P U CLAIM Y P "," A Y ENROL V K FIXES L D ","WRATH E R  B A NURSE T H ","LANDS R R  S I BOWEL N D ","   G SHIRT   O CHESS   S ","FIEFSE  R E  O DRAWLS  N ","S  S NAVALA  L GUILTS  Y "," S D GAMUT G C BATHS S Y ","KNACK I H  G I PHONE T S ","JOUST V H  A U DRANK Y S "," F M FLOAT O G BASIL T C ","A  I LEMMEI  A BRAGSI  E ","STAGE O R  L I BLEND S D ","HANDSE  U A  C PUTTYS  S ","L  C ANGLEM  I POEMSS  B ","EBBED E Y  S R COMIC M E ","B  Y ENDOWR  U RUINSY  G ","HARPSI  O N  S GIPSYE  E ","CACHE L U  T S TERSE R Y ","SCOPE O R  A E FLUSH S S "," R R DEPOT A Y CREAK S L ","AVERS I E  T L CABAL L Y ","AGING L A  O T TOOTH M Y ","W  S HILLYA  I CYCLEK  Y ","CARTSU  A R  C SWAINE  T ","LATHS U E  N A START S D ","MAYBE D U  E R SPORE T O ","LEDGE N O  D R SOLES W D ","T  C REBUSI  R LANESL  D "," C B SHRUB E C WALKS P S ","SOOTHL  H U  I SPICEH  K ","TRAYS I O  G K MIXED D S ","RAINY G O  I M CLEAN E D ","T  R ENDOWA  W RUNESS  D ","R  T ALPHAB  R BACONI  B ","SCOFF L I  E F HASTY R Y ","B  F LADLEA  I SALTYT  S ","BLOWSL  A U  K FLEESF  S ","B B AAGENTN A LJUNTAO S S","F B YARENAW R CNOTCHS H T","C F PL A RO L EDUSTYS E S","BLANDE N AE I ITOMESS E Y","V S BO A AL T RTOYEDS R S"," F  SGLOVE A  NFIXED L  S","AGAINV B IO O CWIDTHS E E"," D  DPRIOR U  AAMPLY S  S","C C YLARVAO U CWIDTHN E T","D B BR R OA E OFREERT D S","LASSOI K OS I ZTHEMES S S","LAGER R  E R  ATOYED W  Y","ASKED A  R U  UACORN Y  K","F M QO A UO J IDRONES R T"," S  B C  O O  ABOARS P  T"," I  CADIEU E  RBANNS S  E"," B  STULIP R  ACRIED O  E","FORDSI   TR   OMAJORS   Y"," L  BPURSE L  RFLING S  S","B C BL O RE A ASILKST S S"," T  BCEASE N  RHOLLY R  L","GRUNTI N HP D ESNIFFY D T","W P CR R OA O UTROOPH F S"," L  PFIXER V  OMILES D  E","AGLOW L  O O  RPRISM Y  S"," M  PHASTE Y  AFOCUS R  E","A G CV H HO O EWASPSS T T","W T PA A UI B FSCOFFT O Y","SIXTH D  O E  RCASTS S  E"," C  V R  I A  NOZONE E  S","M S BE O OD U XAMPLEL S D","BRAVO A  L N  DSKATE S  N","MAGICY L AT A LHASTYS S X","BLISSA   HN   OJUICEO   S","S C GO H AU A UTIMIDH P Y","S D BT A UA D XRADIOT Y M","SWUNG  S I  H AQUEEN  R T","STERNH X UA I RMASKSE T E"," T  IHIRED M  OTIDAL D  S","GRIEF E  L V  USEDGE L  S","O V GU E OG R DHOVELT E Y","OUTDOA R VS I AIDEALS D S","TONICO A IM B TBROKES B D","  A RBANJO  I YMOMMA  E L"," M  F I  I N  GMOUTH R  T","SNIFF  N L  F IQUEUE  R S","A S QBAYOUO R AUSURYT P S","FEVER N  I S  GGULCH E  T","OPTICU A RG B EHALLST E T","GRAMSL   WA   ASIXTYS   S","AXIOMB   AA   NCHINSK   E","R G FE U IA S GMATCHS O T"," G  EMAMMA I  GFLAKE Y  R","STOOL A  O I  AUNDID T  S","ASKEW A  R L  AEVENT E  H","P E ZIGLOOE F NRAISES N S"," S  COTTER A  ESIGMA R  M","REALMA L OZ T UOVALSR R E","  G JCREDO  N USPURS  S T","TRUERR R AA B IYEARNS N S","  C SDAUNT  R ESTREW  Y S","S S BMOTTOA I OSOLOSH L T","  A FFUNGI  G RFASTS  T T","F P LU L IN A ODOZENS A S","SCOUTU M RR I IGOTTAE S D"," V  PSEWER X  ESEEDY D  S","TEEMSO   MM   EBEVELS   L","L F EE O XV R IEXULTL M S","S D QL R UA Y AGOLLYS Y S","  C FKHAKI  N SSLASH  L Y","ARENAD Q CO U HBLADEE L S","F   BALPHAR   DCAVILE   Y","PUREEA O GI B GLIEGES D D","IDOLS R  L A  AFINNY N  S","  H VCREDO  R LSHORT  N S","O P FVILLAA E TLLAMAS D L","H G GALIBIL M ALEMONS E T","  P SSCRAP  O ASIXES  Y M","N A MU W UD F TGAUZEE L D"," H  TBUNCH S  EASHES Y  E"," M  PWAVER M  AAMITY A  S","SIRENL E OI M ITWINSS T E","L C MA R AM O NBOWLSS S E"," G  BFLORA E  CPATIO N  N","PANIC U  O N  YSTEAL S  Y","CEASEA N XV V IIDIOTL L S","G S QR N UU O ABERRYS T S","N B RY E OM G APLAIDH N S","A S PMOTTOB U ULADENE Y D"," V  RLINGO T  ONAILS L  T","TOUCHH N AE C RIDLEDR E Y","ANTICP E UP M RAPPALL O S","R R LAMAZEB B ABOILSI D T","CHAFF A  I R  CBROTH Y  E","RABBIE A ME R PLIBELS S Y","SCRUBC I UR N OUNSAYB E S","W G MALIBII L GFILTHS S T","C H CH E RA A EFALLSE S S","MIXESE   TD   AAPPLYL   S","ADDED E  R L  OPAGAN Y  E","G P JALIKEZ V RE O KDITTY","C S PLIEGEI D NM A IBANGS","A C RM L EIDIOMG M IORBIT","BANALA  X K  I E  O DUMMY","LIMESO O IVAULTE S EDUELS","A Q BL U IO A DN S EGUILD","CAMELL    ORBITG    SPECK","WISERH M  IDIOMR R  LIKER","VOTERO H OD I BK C EASKED","C A SONSETL I EI D ECLEAR","PRINTR   EOPERAW   MSIZES","SECTSH   TRATIOU   OBANAL","C K HRINSEI O DE W GDANCE","TRIPSH   LUNDUEM   EBOAST","D  D UNFITC  V A  A LIENS","TIGHTH R  USAGEM I  BANAL","CRACKA  R INFERR  E NEEDS","C K CR N ROZONEU W DPINTO","STINKH  I OUNCEO  H NEWER","TREEDH X EUNTILM R VBRAKE","THUMBH L RR T IO R CWRACK","STOLEW    UNTILN    GAUZY","CATERA H IRARESO E ELOWER","PILLSE  U ALONGC  A EXTRA","T  S HALTSU  E M  E BURLY","WELCHA  L GLOOME  V SHEEP","A   URAFTSR   IO   NWRONG","W O AHIVESI E HR N ERUSES","N  S AMBERB  V O  E BANNS","SHARET M  APPLYY L  SPEND","PANGSA   HWORRYE   LDALLY","BASERL H EUNIONS N DHUSKS","CEDARL O  INTERM E  BASED","B  M IDEALP  C E  E DAISY","USURPS   AUNITSR   TPROXY","SNAGSH D  RAINYU E  BOUGH","APRONS O OTIMESE A ERENTS","BEFITU U  INNERL G  DYING","SOBERC A OR Y BU O IBRUIN","DOWRYO    CLEARK    STOIC","GLEAMA    VESTSE    LOCAL","S A CC R HR E AU N FBRAKE","DOMEDR U OARSONM E OADDER","FUSEDA N WUSAGEN K LALERT","OCCURW   IIRONSN   KGILDS","P  F IDIOMN  R C  T HAREM","CLEFTA  A CRACKA  E OUTDO","CAVEDO I EZ X UE E CNONCE","M B GY A RT Y IH O ESNUFF","BEARSR    ALLOTT    SONNY","T E AHEALSU T SM E EBANDS","C   OOUGHTU   HP   ESEVER","R R OAWARDP B DI B LDRILY","WITCHR   AOVERTN   EGLUED","Q L RU O IAEGISL I EMANOR","T S IANTICC A IK I LSANDY","S  T LIGHTU  Y M  M PANEL","DEARSA F OU F UN I NTAXED","PLUMER N AIDIOTS O EMINOR","MAGICU A RS M EI M ACHARM","S G PHORSER O NU W NBONNY","U H WN E RT L II L TELOPE","GIDDYR  U ADEPTS  E PALSY","F G SLOYALO P AA S VTHYME","HUMIDA  V VIZORO  R CALYX","NIECEA  O V  P A  S LAYER","S  D IDLEDN  V E  I WILLS","C  G IVORYV  A I  I CLANK","T V SO E HNERVEI V ECLEFT","ADOPTD  R IDEALE  T ULCER","SACKST R TERASEE W EPALED","LOONSI    FRIEDT    SLUNK","MINERI  V LEMONC  K HARES","SMASHT   EINTERN   OGROWN","MOISTA   HNURSEG   MAISLE","QUOTHU  O O  W T  E APART","A   CMILCHO   AN   RGAUNT","DUCHYE    BEFITU    TRACE","S S SPALSYO Y NO L OKEYED","WICKSH  N EQUIPE  F LAYER","RATESI A  PLUMBE N  RATIO","P O EANNULP I OE O PRANGE","L F FO I UWINDSE D EROSES","LAITYO M  OPALSP G  SHELF","SOLOSL   HEVERYE   LTALLY","C  G LADLEI  O N  B GIBES","CUFFSR O TIGLOOB I ISTOIC","IDEASD E EI R AO I MTIERS","LOCALL    AMITYM    ABOVE","R H MU O ALAMEDE E LRISKY","Q   CULTRAO   BT   LABUSE","KNACKE D IEXISTL E ESTUDS","T P AOCEANN N GI C LCREPE","C M  ROOFSU U  M N  BATCH","DIMESR E UI R PP G ESHEAR","BEARDA   ARAVENB   CSNORE","CAMPSL    IRONYM    BULBS","C H NL E UIDLEDM L GBROKE","DRAGSY  O IRONSN  N GREAT","HATERY   EDIMESR   EAGENT","OCEAN L  EPOKES D  TASSES"," M I DINGY L L  C O THROB","NABOB D  ALIVID E  LMUDDY","OPALS A  PDRAMA K  NWANTS","ACORN R O GIPSY M I OPINE"," A A QUICK G O  U R DRINK"," G  C E  U N  B I  EFIFES","KNEAD I B SCULL H E GEARS","ASHEN N T BATHE I I FLOCK","BACON L   WIGHT B   NIECE"," B  SLAUGH Y  A O  DJUICY"," U  EFLAPS T  S R  AMANGY"," R U FALSE T I  I N FORGO","ASSET H  R E  U A  MTROOP","SKINS H  EWANED K  GSIEGE","ABODE A E  Y A  O L QUOTE"," P  B R  ATURNS N  IDEVIL","POEMS U   ATOMS D   JOYED"," M  DRADII M  G M  IVAULT","OBESE U W EGGED L P CENTS","SCRIP A C ADMIT R N WEIGH"," B S SAUCY N O  A F FLUFF"," O  POFFAL T  A E  CKNAVE","EQUAL U  UFOODS T  TFARES"," B C NABOB Y N  O I LURCH","SQUAW U  EGAMMA S  RDINGY"," I  OSNIFF U  F R  AREBEL"," M G WAVER K N  E I TRAIN","TORTS B  LHELLO S  TFETCH","BOXED L  IUDDER E  GTRIBE"," S C  H Y FETCH E L ARMED"," K  C I  AINNER D  GSALVO","ACTOR A  EABODE L  KNEEDS"," F  ABELOW V  F E  UTRAIL"," G V LOGES T N  T U HAZEL"," S  C T  UROVER O  LCLASS","ABHOR A V TYPED O R LUSTY"," D  GGRUEL A  O M  RSALTY"," L  TSOUGH Y  I A  NFLASK"," C C  A R EMAIL E S HOOPS"," R  PMANGA T  R I  TBOUTS","OFTEN A  OGULFS N  EHALED"," F  A O  CWRATH G  EWOUND"," K P FIVES N A  D C RAZED","AVERS I  TSPOOR E  IDROOP","ACHED O  RAMAZE M  ADATUM"," L  CPIANO B  U E  CSLASH","AMONG A  AENNUI G  NNOOKS"," M  W E  OODIUM I  ECABIN"," G P EERIE N E  I C DICED"," B  DTABOO Y  O O  MHUMPS"," M  CAUGUR L  I T  EPILLS"," G A POUND T V  T I TABLE","MALES D  LBILLY E  LMUSTY"," A  SIDIOT O  I R  LDELVE"," M  HGAUDY N  D I  RMAMMA"," F  PMAJOR U  A N  TLARGE","CAUSE G A VIALS L V HERON","GLOSS A  K Y  I E  FGRIEF"," B   SLIMY A    S   STACK","SCENE O  LSCALD O  ECAPER","TRUST A T IDIOT I I MILCH"," W  OLINED D  D E  ETRUER","ACUTE A H URGED G F HOOTS","SHRED Y  IDEARS N  CFARMS"," C  ECRISP I  O S  CEPOCH","SKIMS H  ASAINT K  YWIDER","SMILE A I SNEER N G NAMES","VESTS X  HSTEER O  EBLEED"," K  TINANE E  R E  MCLAWS","USAGE A O BLEAT V L COAST"," C P WHIST U H  R A FLOWN"," T P FEWER M A  P S BONED","AFOOT U  IUNDER G  EBIPED","ABATE A   ISLET S   LOOPS","MAIDS D O LIEGE E M AURAS"," D  GFREER O  I L  NGLOSS"," O  KQUEEN T  O D  WCOLON","FAWNS G  AWAGON P  DTEARS"," C S SHOWS E O  A R SPINS","EVENT O  H D  O K  RSATIN","EGGED O  A N  M N  ELAIRS","STANK H   AUNTS M   ABHOR"," K D CHIRP A E  K A FILMS"," M F TOTAL L B  A L DRIER"," E A ANIME N O  U N DIRGE","SPELL L   HATCH Z   FASTS","SLATS E  IEVENT E  EFERNS"," P  CPUNCH R  I E  NCROCK","SPITS A  ISTUNG I  HCOOLS"," G  B U  OPSALM T  BNOSES","SWEEP O A BRIGS S E STARK"," Z C  E L ABBOT R S CARES"," R S MASTS B O  B O WISPS","WANDS D W FIXES E L LULLS","SCARS R   MIGHT M   SPARE","STATE O O CRANE C I THICK"," A  AEMITS I  H G  EMONKS","SPEAR O  OBLUES K  EPALMS"," Z W SEDAN B V  R E YARDS","  P ASORES  O H  S EAREAS","PADRES E  HILTSA T  WRATH","S E VPIQUEE U XE I EDUPED","O S SPAPALE E IR A MARRAY","BOWEDU A UISSUEL T LTEENS","T T SH R TRAISEE T AWREAK","S S BW T AOVENSO A EPUMPS","I S ADICESE R TA I ELEPER","PUSSY  I  BUGGY  M  CLAIM","VISIT  H OCARGO  E LPAWNS","PREYS  A  PATCH  E  MANGO","S A AP L UE A DL R ITEMPO","  C JSPACE  C E  A RBOORS","PEARSE B  ALLAYC E  HAREM","LASTSY T TI R ON A NGIPSY","E D MD E UGENTSE S EDREAD","  U AFUSES  A H  G EBLESS","T R SHEARTR D YO I LBRIBE","TASTEU P ANOOKSI O ECAKES","TOQUE  U XFRANC  S ETRILL","HEWED  A UMAXIM  E PHONEY","BIBLE  A  MANGY  A  VOLTS","P M II A SVENTSO I UTRACE","S G UTEENSI N AN I GGUISE","S T TP U II L LL I ETAPES","B B DAWAREY Y VO O IUSUAL","C C IODIUMU R PC C LHEAVY","DUSTYR K  O U  O L  POLAR","  V AGROOM  W I  E SCULTS","  D DJUROR  A A  P MHYENA","OXIDEP M NE A DN G ESPEND","FITLY  O  PIPED  A  OOZES","GLADE  D  JUDGE  E  HERDS","F O PL U RU T OF D UFLOOD","B T PE R OFLAGSI I ETENOR","S F AYOURSR N SU G EPRINT","  C KKNOWN  W O  E WDARTS","LIARS  C L  H O  E TWIDTH","QUAKEU L  IMPLYL H  LEAPS","RUFFS  L  QUICK  N  FIGHT","  L AFOAMS  R S  V EGIANT","GUANO  M PGRIPE  G NBROWS","P Q CROUGHO A IO S LFRIED","CLASHU B EBLOODI U GTITHE","S T CC H OR O UE N NWIGHT","TOQUEH U DR E GE E EWORLD","C P BRARERU I IM C SBLEAK","C S ARITESU E SS E ETAPES","WHACK  N  LIGHT  E  JERKY","O A EPINEDA G GL L ESTEED","SEVENT I OINLETF E EFIRED","  S CLOATH  L I  V NQUOTA","TABBYE O IPROVEI S LDATED","SECTSH I QR V UU I ABELOW","S T TPRIORO T AO H SLEECH","A A SBEGINH I OO N RRIGHT","G P AUSINGE O OS U NTASTY","L M AU O UCADETI E ODOMES","C F HH U OA N BM G BPRIVY","BASESO M  WRACKL L  SILKY","W T BR I AO B RN I OGRAIN","  S UWALLS  A H  N ECIGAR","OASESM C  IDIOTT O  SANDY","DEBAR  O IHARPS  A EFIXER","MAJORA U  LUNARE T  SPAKE","N B MADOREB R NO A UBOXES","ROMAN  O I  D G  E HGAMUT","APART  T OOTTER  A CMYRRH","  F  PLUCK  N    G  FLING","HEATS  D  QUILL  E  PLUMB","RECUR  R  THIRD  M  HOPED","FALLSL A IISSUEN S VGROVE","E M SAMIGOG M OE I TROCKY","G W  LOONSE U  A L  MEDIA","DUPESR A  ANGRYM A  AUNTS","A L HSLILYI G ED H NEXTRA","SELLST O WR W AE E YWIRES","GRUFF  N IRIDER  E MBARDS","D R SWEAVEE D DL I GTRICE","SPASM  L OFATES  A SMARRY","LOCKS  U  WIRES  E  FADED","TOPICH A OR T RO I KBLOWS","S B DNOOSEU R BF A AFIXER","WIVES  I INOTED  A EVALID","B B IACREST A LH V ESPORT","POPESI R CAMIGON D ROCEAN","W B UHOURSE R UL R APROWL","E S BB I EBONDSE G ODREAM","UNCLE  L  BRUIN  M  MOPED","VALID  L WBLAZE  M LEXACT","QUEERU M AIDIOTE T ETASKS","  S P  I UCIGAR  M EFLAIR","A Q SVAUNTE A UR S DSPICY","RESTSE P NBORNEU I ETIGER","ALTER  H OCRUMB  M IRIPEN","A A APEDALI I IN E VGAUGE","S P CTOOTHI P IN P NTHANK","V G SA E LN N AE I BSTIRS","O L ELYINGD L GE A ERACED","COMBS  O  LAMES  M  QUAKE","DRIPS I A  F Y  L E WEARS"," R A CABBY N L  C E CHART"," F W  L I WANDS I O CRAWL","SERFS A O STORK E G ONION"," H V BEGIN A Z  T O SHORT","   N SQUAD   B    O HERBS","WRISTI  T NOMADG  L STALK","CHARY   H GREYS   M MANES","FLOCKO  R REPAYM  V SLEEK","OTHER R L LEAFY A I STUNG","HANDS   I SOLVE   A GOING","PINCH M A  B B  U I JEANS","POLAR   L SHOON   N FLAGS","J  B A  O CRESTK  O SHAMS","BRAVOE  I SINCEE  E TIPSY","MADAMI  D MAJORI  R CHANT","SIGHTT  A AGATEB  E SHORT","NICHE   A CHART   E FILMS","C  S OFFALM  L I  V CAKED","TORTSI  O LOCKSE  E DRINK","SPECK O R OWNER E E GRAPH","STATE H E LIONS E S AFTER","BASTEL  A U  P F  E FJORD"," A W ELFIN I N  B C WIPED","REARSE  E LYNCHI  U CHURN","QUERYU  U ADEPTL  E MUSED","L  S EBONYV  I E  P RULED"," F P  A U BURLY N S DAMES","MULESU  T SIGHSI  I CROCK","PONDSA  I SMITET  T ENJOY","W  K OATHSR  A D  K SKEIN","FIRST   P DEBUT   R WITTY","I  S CLUMPI  A N  R GUSTS"," F Q  U U SNEAK G S VIVID"," B D SATIN Y R  O G SURER"," M Q  O U CUBIT R L KNITS","GLOSS   K QUEUE   L LOWLY","ABHORN  P TASTEI  I CLOCK","ABASE A H  Y A  O K RUNES","P  T APRONT  P I  I OUNCE","O  S SMITHI  A E  F RUFFS","HUSKYA  N RAVEDE  L MEALY"," S O  C C MOTES W A BLEND","   A ABAFT   I    R WANES","P  A AUNTSN  T I  I CIRCA"," F B VENOM V R  E A PROXY","SWISHI  P DREADE  R DOVES","PRICEA  O PRIZEA  E LEANS","C  P LULLSI  A M  N BOOTS","   A SLIDE   I    E BOGUS","AGLOW R A LARKS I U ANIME","ABUSE U A BRUNT R E POURS"," V D LIVID D G  E I VOLTS","GRADEE  E REAMSM  U SHORN","CHUNK Y O ADMIT R S BAKER","CIRCAA  H RACERD  A SKIPS"," F P FURRY N O  G V GIVEN"," G M  U O JAUNT N K HOIST","STIFFN  O UNDIDF  S FATTY","ARSONM  O BLAZEE  E ROUSE","SKATE H H GAYER K M MINED","CHEST Y P BESOM N O RAINY","B  A ROWDYO  I O  E MUCUS","   Q    U HUMID   C LOOKS","LAMBSY  I I  D N  E GLOSS","GRAMSU  A A  Y R  B DUNES","HORSE   A DRAWS   E GOODY","TASTE B I CHUMP O I PRIDE","CRAFTA  R SOFAST  N EPICS","I  E SPUNKL  N E  U TEPID","GAMMA   A PEERS   T CRUST"," S M THEIR O M  R I KNOCK"," C B SOLAR B S  R I DANCE"," C U DRANK E T  D I LOWLY","ELEGY   R DUCAT   I PLANE","I  R DINESO  V L  E SMELL","TABBY R U WEEDS N G PALED","AVERS I I  D S  E E BOONS","APPLE A A USURY H V SAGAS","NERVE L O ABATE O E TWIRL","DROPS A R ODIUM I D LINED"," P L BASIL N N  I G SCION","PASTYA  H PUPILE  E RUFFS","CARGO M U LIVID G L POWER","T  A HOODSI  D E  E FOODS","TORTSI  A ADOPTR  E AZURE","SWAYSI  E GLEAMN  R SUNNY"," Z W FERAL B I  R S BAITS","T  S HASTER  U O  F BLUFF","DRUMSU  A PENNYE  G DECOY"," S A SCORE A I  L S SPEED","ABASEX  W IDEALO  I MEANS","COMBS   R RAJAH   I CRONY"," C C  R H GIVES E S BRUTE","SNIFF   L UNTIE   N ROUGE"," B W  E A DRIFT G E USERS","O  S MIMICI  G T  H SMITH","B  P EQUALI  D N  R GATES","ASSAY   N FORKS   L WAFER","DRAWSU  A SKIFFK  E YEARS"," H  BVERSE L  R L  TFORTH","P S CHATERI E OA E SLORDS","S S FCREDOR W AU E MBIRDS"," K  MCHINA A  G K  ICIVIC","S T MC A OA L OR O DFINNY","THROW O  EAROMA S  VLEVEE","R P MADIEUD L SI O IOPTIC","  A VCOPRA  I U  N LANGST","PROOFA   INOUNSI   HCRAZY","AGINGN M IT A VI G ECLEAN","CITED  U WCURVE  N LBASAL"," L  QBAYOU T  E C  LCHILL","USINGN N RD F AI E TDIRGE","S E ITAXEDA T OG R LSWAYS","STRAPT   EEXTRAR   RNAVAL"," V  WTIARA S  N T  DRACES"," P  ADOING D  A I  TBASTE","  F ODELTA  Y T  E HGERMS","FORUM    APLAIN    GBANJO","  C RGRAZE  R P  O ASILKY","B M JLOOSEU U TF R TFANCY","FLUFFU   OSIGMAE   MDEITY"," A  W D  IRIVEN E  GDUELS"," A  P B  UJOKER D  GGEESE"," P  RHELLO A  C S  KSEALS"," T  V I  AIDEAL A  VSLIDE","BONUS P  NTEMPO R  BJACKS","SORES  A LPODIA  I ITHORN","SCREW I  ECRAVE C  KHALLS","QUOTA    MAROMA    ZBLARE","MERIT  A R  D U  I CWHISK","S A TCACAOO T XW O ILYRIC"," B  CMAYOR S  O A  OCLACK","S R ETWAINA D JG I OSLILY","SELLS M  HSIGMA T  MASIDE"," R  Q I  U V  A A  CCLANK","  K KFUNGI  E C  L KPULLS","B B QA A UY Y IO O LUSUAL","T   MRADIOE   MS   MSIGMA","TOMBSI   TBAYOUI   NAPING","TENDSH   QR   UO   ABEGAT","HIRED    IWALTZ    ZABBEY"," F  S I  POXIDE E  RGROOM","B A BOFFALN I ED R SSWEAT","PLAYS A  TOPERA S  GGERMS","L U PE S IASHENS E KHEROS","  I MFUNGI  L M  E IATTIC","STAYSH D UR I PU E EBLUER"," D  BDUNNO N  R N  EJOYED","V P GIGLOOS U NI M NTIBIA","PSHAWS O HALIBIL S RMETER"," J  LMULTI N  C T  KHALLS","S S ACRUMBU I BL N OLIGHT","CREAMR A II V LM E EPESOS"," B  P A  LHYENA O  NQUART"," E  SSNORT N  E U  EMINER","N S GABLERB E OO E IBATON","F   PO   HCOPRAU   SSHINE"," T  Q U  UALIBI I  LSPOUT","ARROWM I HBUDGEE G RREEVE","BEING L  IMOTIF P  TSEEKS","L B CA A RR R OV G WAHEAD","P G OI R VPLAZAE I LDENTS","E B WQUASIU S LI S LPEONS","ASSET  L OCHINA  C SBLENT","T   MIGLOOL   VE   EDIVER","LLAMAI L SL I HA K ECLEAN","S A KHUMANE I OA G TFOODS","BESOMA   OSUGARA   ELINKS","P S BO W ADYINGI R GALLAY","SCORN R  AGENII D  LMOATS","MIDSTO   AMIENSM   TAFIRE"," N  DRAZOR I  A V  WVESTS","SCARF O  RBRAVO A  ZPLATE","GUANO  L PCRIME  B NPAINS","E A AT D MH I UI E SCHUTE"," V  JTITHE D  W E  EVOCAL","POUND    ISPAWN    ELOVED","PSHAWO   OSUGART   DSIXTY","SHRUB    OSHREW    EALTER"," R  MBAYOU B  M B  MDIZZY","S B DE A RA Y OL O LSCULL","LYRIC  E A  S V  I EPANTS","G S GR P REVOKEA O ETIRED","SCOFFA   RFOLIOE   SRIGHT","TOPIC  H LQUOTA  T SBLOTS","CLING A  EBRUIN G  UDOOMS","C   WRABBIA   PZ   EYELLS"," K  RKHAKI A  V K  ECIDER","O A VC N IC G VU E IRILED","KEYEDH   UALIENK   NIGLOO","SCRUB A  O T  I E  LBRIMS","P L CALIBIT L GI A AOCCUR","MUSIC  C HQUOTA  F IDEFER","C P MO O AMIDSTE I CSLASH"," H  CHYDRA D  K R  EYARDS","SLOOP L  RPATIO M  SBAGGY","CUBITU A HBAYOUI O MCRUMB","OPALS  D OADIEU  E TPOUCH","SWANS I  T T  A C  LWHISK"];zS.split(/\r?\n/).map(i=>i.trim()).filter(Boolean);function KS(){if(Ys.length===0)throw new Error("No puzzles available — run build-puzzles first.");return Ys[Math.floor(Math.random()*Ys.length)]}const Ml={type:"change"},ro={type:"start"},xc={type:"end"},Vr=new ja,Il=new kn,XS=Math.cos(70*Du.DEG2RAD),_t=new V,wt=2*Math.PI,st={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},zs=1e-6;class qS extends jh{constructor(e,t=null){super(e,t),this.state=st.NONE,this.target=new V,this.cursor=new V,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Oi.ROTATE,MIDDLE:Oi.DOLLY,RIGHT:Oi.PAN},this.touches={ONE:yi.ROTATE,TWO:yi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new V,this._lastQuaternion=new Nn,this._lastTargetPosition=new V,this._quat=new Nn().setFromUnitVectors(e.up,new V(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Zo,this._sphericalDelta=new Zo,this._scale=1,this._panOffset=new V,this._rotateStart=new oe,this._rotateEnd=new oe,this._rotateDelta=new oe,this._panStart=new oe,this._panEnd=new oe,this._panDelta=new oe,this._dollyStart=new oe,this._dollyEnd=new oe,this._dollyDelta=new oe,this._dollyDirection=new V,this._mouse=new oe,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=JS.bind(this),this._onPointerDown=ZS.bind(this),this._onPointerUp=jS.bind(this),this._onContextMenu=rm.bind(this),this._onMouseWheel=em.bind(this),this._onKeyDown=tm.bind(this),this._onTouchStart=nm.bind(this),this._onTouchMove=im.bind(this),this._onMouseDown=QS.bind(this),this._onMouseMove=$S.bind(this),this._interceptControlDown=sm.bind(this),this._interceptControlUp=am.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Ml),this.update(),this.state=st.NONE}update(e=null){const t=this.object.position;_t.copy(t).sub(this.target),_t.applyQuaternion(this._quat),this._spherical.setFromVector3(_t),this.autoRotate&&this.state===st.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,r=this.maxAzimuthAngle;isFinite(n)&&isFinite(r)&&(n<-Math.PI?n+=wt:n>Math.PI&&(n-=wt),r<-Math.PI?r+=wt:r>Math.PI&&(r-=wt),n<=r?this._spherical.theta=Math.max(n,Math.min(r,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+r)/2?Math.max(n,this._spherical.theta):Math.min(r,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=o!=this._spherical.radius}if(_t.setFromSpherical(this._spherical),_t.applyQuaternion(this._quatInverse),t.copy(this.target).add(_t),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const c=_t.length();o=this._clampDistance(c*this._scale);const d=c-o;this.object.position.addScaledVector(this._dollyDirection,d),this.object.updateMatrixWorld(),s=!!d}else if(this.object.isOrthographicCamera){const c=new V(this._mouse.x,this._mouse.y,0);c.unproject(this.object);const d=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=d!==this.object.zoom;const h=new V(this._mouse.x,this._mouse.y,0);h.unproject(this.object),this.object.position.sub(h).add(c),this.object.updateMatrixWorld(),o=_t.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(Vr.origin.copy(this.object.position),Vr.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Vr.direction))<XS?this.object.lookAt(this.target):(Il.setFromNormalAndCoplanarPoint(this.object.up,this.target),Vr.intersectPlane(Il,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),s=!0)}return this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>zs||8*(1-this._lastQuaternion.dot(this.object.quaternion))>zs||this._lastTargetPosition.distanceToSquared(this.target)>zs?(this.dispatchEvent(Ml),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?wt/60*this.autoRotateSpeed*e:wt/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){_t.setFromMatrixColumn(t,0),_t.multiplyScalar(-e),this._panOffset.add(_t)}_panUp(e,t){this.screenSpacePanning===!0?_t.setFromMatrixColumn(t,1):(_t.setFromMatrixColumn(t,0),_t.crossVectors(this.object.up,_t)),_t.multiplyScalar(e),this._panOffset.add(_t)}_pan(e,t){const n=this.domElement;if(this.object.isPerspectiveCamera){const r=this.object.position;_t.copy(r).sub(this.target);let s=_t.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*s/n.clientHeight,this.object.matrix),this._panUp(2*t*s/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),r=e-n.left,s=t-n.top,o=n.width,c=n.height;this._mouse.x=r/o*2-1,this._mouse.y=-(s/c)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(wt*this._rotateDelta.x/t.clientHeight),this._rotateUp(wt*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(wt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-wt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(wt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-wt*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._rotateStart.set(n,r)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panStart.set(n,r)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,r=e.pageY-t.y,s=Math.sqrt(n*n+r*r);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const n=this._getSecondPointerPosition(e),r=.5*(e.pageX+n.x),s=.5*(e.pageY+n.y);this._rotateEnd.set(r,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(wt*this._rotateDelta.x/t.clientHeight),this._rotateUp(wt*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panEnd.set(n,r)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,r=e.pageY-t.y,s=Math.sqrt(n*n+r*r);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,c=(e.pageY+t.y)*.5;this._updateZoomParameters(o,c)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new oe,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function ZS(i){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(i.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(i)&&(this._addPointer(i),i.pointerType==="touch"?this._onTouchStart(i):this._onMouseDown(i)))}function JS(i){this.enabled!==!1&&(i.pointerType==="touch"?this._onTouchMove(i):this._onMouseMove(i))}function jS(i){switch(this._removePointer(i),this._pointers.length){case 0:this.domElement.releasePointerCapture(i.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(xc),this.state=st.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function QS(i){let e;switch(i.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Oi.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(i),this.state=st.DOLLY;break;case Oi.ROTATE:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=st.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=st.ROTATE}break;case Oi.PAN:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=st.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=st.PAN}break;default:this.state=st.NONE}this.state!==st.NONE&&this.dispatchEvent(ro)}function $S(i){switch(this.state){case st.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(i);break;case st.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(i);break;case st.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(i);break}}function em(i){this.enabled===!1||this.enableZoom===!1||this.state!==st.NONE||(i.preventDefault(),this.dispatchEvent(ro),this._handleMouseWheel(this._customWheelEvent(i)),this.dispatchEvent(xc))}function tm(i){this.enabled!==!1&&this._handleKeyDown(i)}function nm(i){switch(this._trackPointer(i),this._pointers.length){case 1:switch(this.touches.ONE){case yi.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(i),this.state=st.TOUCH_ROTATE;break;case yi.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(i),this.state=st.TOUCH_PAN;break;default:this.state=st.NONE}break;case 2:switch(this.touches.TWO){case yi.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(i),this.state=st.TOUCH_DOLLY_PAN;break;case yi.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(i),this.state=st.TOUCH_DOLLY_ROTATE;break;default:this.state=st.NONE}break;default:this.state=st.NONE}this.state!==st.NONE&&this.dispatchEvent(ro)}function im(i){switch(this._trackPointer(i),this.state){case st.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(i),this.update();break;case st.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(i),this.update();break;case st.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(i),this.update();break;case st.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(i),this.update();break;default:this.state=st.NONE}}function rm(i){this.enabled!==!1&&i.preventDefault()}function sm(i){i.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function am(i){i.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}var so=`precision mediump float;

uniform vec3 uPalette0;
uniform vec3 uPalette1;
uniform vec3 uPalette2;
uniform vec3 uPalette3;
uniform vec3 prev_uPalette0;
uniform vec3 prev_uPalette1;
uniform vec3 prev_uPalette2;
uniform vec3 prev_uPalette3;

uniform float uPaletteTransition; 
uniform vec2 uResolution;
uniform float uSweepType; 

uniform vec3 uWorldSweepStart;
uniform vec3 uWorldSweepEnd;

varying vec3 vWorldNormal;
varying float vInstanceParity;
varying vec3 vWorldPosition;

vec3 paletteColorBlended(float index, float t, bool reverse) {
  vec3 prev0 = prev_uPalette0;
  vec3 prev1 = prev_uPalette1;
  vec3 prev2 = prev_uPalette2;
  vec3 prev3 = prev_uPalette3;

  vec3 curr0 = uPalette0;
  vec3 curr1 = uPalette1;
  vec3 curr2 = uPalette2;
  vec3 curr3 = uPalette3;

  if (reverse) {
    index = 3.0 - index;
  } else {

    prev1 = prev0;
    prev2 = prev3;
    curr1 = curr0;
    curr2 = curr3;
  }
  vec3 c0 = (index < 0.5) ? prev0 : (index < 1.5) ? prev1 : (index < 2.5) ? prev2 : prev3;
  vec3 c1 = (index < 0.5) ? curr0 : (index < 1.5) ? curr1 : (index < 2.5) ? curr2 : curr3;
  return mix(c0, c1, t);
}

void main() {
  vec3 worldNormal = normalize(vWorldNormal);
  vec3 orientationAxis = normalize(vec3(-0.35, 0.9, 0.28));

  float orientationShade = dot(worldNormal, orientationAxis) * 0.5 + 0.5;
  float upwardBias = worldNormal.y * 0.5 + 0.5;
  float shade = mix(upwardBias, orientationShade, 0.45);
  shade = clamp(shade, 0.0, 0.9999);

  float posterizedIndex = floor(shade * 4.0);

  
  float sweepNorm = 0.0;
  if (uSweepType < 0.5) {
    
    sweepNorm = gl_FragCoord.x / uResolution.x;
  } else if (uSweepType < 1.5) {
    
    sweepNorm = gl_FragCoord.y / uResolution.y;
  } else if (uSweepType < 2.5) {
    
    sweepNorm = (gl_FragCoord.x + gl_FragCoord.y) / (uResolution.x + uResolution.y);
  } else if (uSweepType < 3.5) {
    
    vec2 center = uResolution * 0.5;
    float dist = distance(gl_FragCoord.xy, center);
    float maxDist = length(uResolution * 0.5);
    sweepNorm = dist / maxDist;
  } else if (uSweepType < 4.5) {
    
    vec3 start = uWorldSweepStart;
    vec3 end = uWorldSweepEnd;
    vec3 dir = normalize(end - start);
    float len = length(end - start);
    float proj = dot(vWorldPosition - start, dir);
    sweepNorm = clamp(proj / len, 0.0, 1.0);
  }
  float t = step(sweepNorm, uPaletteTransition);
  bool reverse = (vInstanceParity == 0.0);
  gl_FragColor = vec4(paletteColorBlended(posterizedIndex, t, reverse), 1.0);
}`,ao=`precision mediump float;

attribute float instanceParity;
varying float vInstanceParity;

varying vec3 vWorldNormal;
varying vec3 vWorldPosition;

void main() {
  mat4 model = modelMatrix;
#ifdef USE_INSTANCING
  model = modelMatrix * instanceMatrix;
#endif

  vInstanceParity = instanceParity;

  vWorldNormal = normalize(mat3(model) * normal);
  vWorldPosition = (model * vec4(position, 1.0)).xyz;

#ifdef USE_INSTANCING
  gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4( position, 1.0 );
#else
  gl_Position = projectionMatrix * viewMatrix * model * vec4(position, 1.0);
#endif
}`;const an=[{id:"1-A",colors:[13421772,8947848,12303291,16777215]}];function om(i){return"#"+i.toString(16).padStart(6,"0")}const lm="1-A";let pn=an.findIndex(({id:i})=>i===lm);for(let i=0;i<4;i++)om(an[pn].colors[i]);function Gn(i){return new tt(i).convertLinearToSRGB()}function cm(i,e){hm.uniforms.uResolution.value.set(i,e)}const um={value:1},oo={uPalette0:{value:Gn(an[pn].colors[0])},uPalette1:{value:Gn(an[pn].colors[1])},uPalette2:{value:Gn(an[pn].colors[2])},uPalette3:{value:Gn(an[pn].colors[3])},prev_uPalette0:{value:Gn(an[pn].colors[0])},prev_uPalette1:{value:Gn(an[pn].colors[1])},prev_uPalette2:{value:Gn(an[pn].colors[2])},prev_uPalette3:{value:Gn(an[pn].colors[3])},uPaletteTransition:um,uResolution:{value:new oe(1,1)},uSweepType:{value:0},uWorldSweepStart:{value:new V(-1e3,0,0)},uWorldSweepEnd:{value:new V(1e3,0,0)}};new en({name:"vehicleMaterial",fragmentShader:so,vertexShader:ao,lights:!1,uniforms:oo,side:Kt,depthTest:!1,depthWrite:!1});const hm=new en({name:"TrackPosterizedMaterial",fragmentShader:so,vertexShader:ao,lights:!1,uniforms:oo,side:Kt});new en({name:"BackgroundPosterizedMaterial",fragmentShader:so,vertexShader:ao,lights:!1,uniforms:oo,side:Kt,depthTest:!1,depthWrite:!1});function dm(){return an[pn].colors}class _c{constructor(e){ye(this,"_canvas");ye(this,"_renderer");ye(this,"_camera");this.app=e,this._canvas=e._canvas,this._renderer=e._renderer,this._camera=e._camera}}class fm extends _c{constructor(){super(...arguments);ye(this,"_pix",1);ye(this,"_renderSize",new oe)}onResize(){this._camera.aspect=window.innerWidth/window.innerHeight,this._camera.updateProjectionMatrix(),this._applyRendererResolution()}_applyRendererResolution(){const n=(window.devicePixelRatio||1)/this.app._renderPixelScale;this._pix=n,this._renderer.setPixelRatio(n),this._renderer.setSize(window.innerWidth,window.innerHeight);const r=this._renderer.getSize(this._renderSize).multiplyScalar(this._renderer.getPixelRatio());cm(r.x,r.y),this._positionControlOverlays()}_positionControlOverlays(){const t=document.getElementById("overlay-canvas");this._setupPixelPerfectOverlay(t)}_setupPixelPerfectOverlay(t){const n=t.getContext("2d");t.width=this._renderSize.x,t.height=this._renderSize.y,n.imageSmoothingEnabled=!1}}const fr=.88,pm=.12,Vn=5,Yn=1,on=.2,gc=.3,Em=.15,En=Yn+on,lt=Vn*En+on,ct=gc,Wt=gc-Em;function Zt(i,e,t,n,r,s){const o=i.length/3;i.push(...t,...n,...r,...s),e.push(o,o+1,o+2,o,o+2,o+3)}function Ll(i,e){const t=new gt;return t.setAttribute("position",new xt(i,3)),t.setIndex(e),t.computeVertexNormals(),t}function Sm(){const i=[],e=[],t=[],n=[];for(let h=0;h<=Vn;h++){const p=h*En,a=p+on;Zt(i,e,[0,ct,p],[lt,ct,p],[lt,ct,a],[0,ct,a])}for(let h=0;h<=Vn;h++){const p=h*En,a=p+on;for(let l=0;l<Vn;l++){const u=l*En+on,E=u+Yn;Zt(i,e,[p,ct,u],[a,ct,u],[a,ct,E],[p,ct,E])}}for(let h=0;h<Vn;h++)for(let p=0;p<Vn;p++){const a=p*En+on,l=a+Yn,u=h*En+on,E=u+Yn;Zt(i,e,[a,Wt,u],[l,Wt,u],[l,Wt,E],[a,Wt,E])}Zt(t,n,[lt,0,0],[0,0,0],[0,ct,0],[lt,ct,0]),Zt(t,n,[0,0,lt],[lt,0,lt],[lt,ct,lt],[0,ct,lt]),Zt(t,n,[0,0,0],[0,0,lt],[0,ct,lt],[0,ct,0]),Zt(t,n,[lt,0,lt],[lt,0,0],[lt,ct,0],[lt,ct,lt]),Zt(t,n,[0,0,0],[lt,0,0],[lt,0,lt],[0,0,lt]);for(let h=0;h<Vn;h++)for(let p=0;p<Vn;p++){const a=p*En+on,l=a+Yn,u=h*En+on,E=u+Yn;Zt(t,n,[l,Wt,u],[a,Wt,u],[a,ct,u],[l,ct,u]),Zt(t,n,[a,Wt,E],[l,Wt,E],[l,ct,E],[a,ct,E]),Zt(t,n,[a,Wt,u],[a,Wt,E],[a,ct,E],[a,ct,u]),Zt(t,n,[l,Wt,E],[l,Wt,u],[l,ct,u],[l,ct,E])}const r=new Qt({color:13421772,side:It}),s=new Qt({color:0,side:It}),o=new Mt(Ll(i,e),r),c=new Mt(Ll(t,n),s),d=new zn;return d.add(o,c),d.position.set(-lt/2,0,-lt/2-1),d}function mm(i,e){const t=e*En+on+Yn/2-fr/2,n=i*En+on+Yn/2-fr/2;return new V(t,Wt,n)}const Tc=5,es=fr,pr=.15,Rc=es+pr,vc=Tc*Rc+pr,Mc=es+pr*2,Ic=.18,Am=.28,xm=.18;function Jt(i,e,t,n,r,s){const o=i.length/3;i.push(...t,...n,...r,...s),e.push(o,o+1,o+2,o,o+2,o+3)}function yl(i,e){const t=new gt;return t.setAttribute("position",new xt(i,3)),t.setIndex(e),t.computeVertexNormals(),t}function _m(){const i=[],e=[],t=[],n=[],r=vc,s=Mc,o=Ic,c=o+Am,d=xm;Jt(i,e,[0,o,0],[r,o,0],[r,o,s],[0,o,s]),Jt(t,n,[0,0,0],[r,0,0],[r,0,s],[0,0,s]),Jt(t,n,[r,0,0],[0,0,0],[0,o,0],[r,o,0]),Jt(t,n,[0,0,s],[r,0,s],[r,o,s],[0,o,s]),Jt(t,n,[0,0,0],[0,0,s],[0,o,s],[0,o,0]),Jt(t,n,[r,0,s],[r,0,0],[r,o,0],[r,o,s]),Jt(i,e,[0,c,s],[r,c,s],[r,c,s+d],[0,c,s+d]),Jt(t,n,[0,0,s],[r,0,s],[r,0,s+d],[0,0,s+d]),Jt(t,n,[r,o,s],[0,o,s],[0,c,s],[r,c,s]),Jt(t,n,[0,0,s+d],[r,0,s+d],[r,c,s+d],[0,c,s+d]),Jt(t,n,[0,0,s],[0,0,s+d],[0,c,s+d],[0,c,s]),Jt(t,n,[r,0,s+d],[r,0,s],[r,c,s],[r,c,s+d]);const h=new Qt({color:13421772,side:ln}),p=new Qt({color:0,side:ln}),a=new Mt(yl(i,e),h);a.geometry.translate(-r/2,0,0);const l=new Mt(yl(t,n),p);l.geometry.translate(-r/2,0,0);const u=new zn;return u.add(a,l),u}function gm(i){const e=i*Rc+pr+es/2,t=pr+es/2;return new V(e-vc/2-.42,Ic,t-Mc/2+.3)}function bl(i){const e=window.innerWidth,t=window.innerHeight,n=new Zn(e,t);n.texture.colorSpace=Ft,i._renderer.setRenderTarget(n),i._renderer.render(i._scene,i._camera),i._renderer.setRenderTarget(null);const r=new Uint8Array(e*t*4);i._renderer.readRenderTargetPixels(n,0,0,e,t,r),n.dispose();const s=new Uint8ClampedArray(e*t*4);for(let a=0;a<t;a++){const l=(t-1-a)*e*4,u=a*e*4;s.set(r.subarray(l,l+e*4),u)}const o=document.getElementById("buffer-canvas");o.width=e,o.height=t,o.getContext("2d").putImageData(new ImageData(s,e,t),0,0);const c=new Set;for(let a=0;a<s.length;a+=4)s[a]>150||c.add(s[a]<<16|s[a+1]<<8|s[a+2]);if(c.size>5)throw new Error(`Expected ≤5 unique colors, got ${c.size}`);i._regionMasks=[];const d=new hc,h=new oe,p=[...c];for(let a=0;a<p.length;a++){const l=p[a],u=Er._MASK_FILTER_COLORS[a%Er._MASK_FILTER_COLORS.length];parseInt(u.slice(1,3),16),parseInt(u.slice(3,5),16),parseInt(u.slice(5,7),16);const m=new ImageData(e,t).data;for(let R=0;R<s.length;R+=4)(s[R]<<16|s[R+1]<<8|s[R+2])===l&&(m[R]=s[R],m[R+1]=s[R+1],m[R+2]=s[R+2],m[R+3]=255);const S=new Int32Array(e*t).fill(-1),f=[],v=[],A=[];for(let R=0;R<e*t;R++){if(m[R*4+3]===0||S[R]!==-1)continue;const C=f.length;f.push({minX:e,maxX:-1,minY:t,maxY:-1});const y=f[C];A.length=0,A.push(R),S[R]=C;let N=0;for(;N<A.length;){const _=A[N++],P=_%e,G=_/e|0;P<y.minX&&(y.minX=P),P>y.maxX&&(y.maxX=P),G<y.minY&&(y.minY=G),G>y.maxY&&(y.maxY=G),P>0&&S[_-1]===-1&&m[(_-1)*4+3]>0&&(S[_-1]=C,A.push(_-1)),P<e-1&&S[_+1]===-1&&m[(_+1)*4+3]>0&&(S[_+1]=C,A.push(_+1)),G>0&&S[_-e]===-1&&m[(_-e)*4+3]>0&&(S[_-e]=C,A.push(_-e)),G<t-1&&S[_+e]===-1&&m[(_+e)*4+3]>0&&(S[_+e]=C,A.push(_+e))}const w=[],I=Math.max(1,Math.floor(A.length/5));for(let _=0;_<A.length&&w.length<5;_+=I)w.push(A[_]);v.push(w)}for(let R=0;R<f.length;R++){const C=f[R],y=C.maxX-C.minX+1,N=C.maxY-C.minY+1;if(y===e&&N===t)continue;const w=new OffscreenCanvas(y,N),I=w.getContext("2d"),_=I.createImageData(y,N),P=_.data;for(let le=C.minY;le<=C.maxY;le++)for(let _e=C.minX;_e<=C.maxX;_e++)if(S[le*e+_e]===R){const Ue=((le-C.minY)*y+(_e-C.minX))*4,He=(le*e+_e)*4;P[Ue]=m[He],P[Ue+1]=m[He+1],P[Ue+2]=m[He+2],P[Ue+3]=m[He+3]}I.putImageData(_,0,0);const G=v[R],Z=new V;let j=0;for(const le of G){const _e=le%e,Ue=le/e|0;h.set(_e/e*2-1,-(Ue/t)*2+1),d.setFromCamera(h,i._camera);const He=d.intersectObjects(i._scene.children,!0);He.length>0&&(Z.add(He[0].point),j++)}const $=j>0?Z.divideScalar(j):null;let ie=0,Q=0,B=0,pe=0;if($){const le=$.clone().project(i._camera),_e=(le.x+1)/2*e,Ue=(1-le.y)/2*t;ie=C.minX-(_e-w.width/2),Q=C.minY-(Ue-w.height/2);const He=(C.minX+C.maxX)/2,X=(C.minY+C.maxY)/2,U=He-e/2,M=X-t/2,g=2*Math.hypot(U,M)+Math.random()*100,z=Math.atan2(M,U);B=g*Math.cos(z),pe=g*Math.sin(z)}i._regionMasks.length>=100||i._regionMasks.push({filterColor:u,canvas:w,x:C.minX,y:C.minY,worldPos:$,restOffsetX:ie,restOffsetY:Q,restOffsetX1:B,restOffsetY1:pe,restAngle:-Math.PI+2*Math.random()*Math.PI})}}}const Ol=["KeyA","ArrowLeft","KeyD","ArrowRight","Space"];class Tm extends _c{constructor(){super(...arguments);ye(this,"_cpDummy",[0,0])}wireUiInput(){const t=this.app._canvas;window.addEventListener("keydown",n=>{Ol.includes(n.code)&&this._routeKeyDown(n.code)&&(n.preventDefault(),n.stopPropagation())}),window.addEventListener("keyup",n=>{Ol.includes(n.code)&&this._routeKeyUp(n.code)&&(n.preventDefault(),n.stopPropagation())}),t.addEventListener("mousedown",n=>{const r=this._toCanvasPoint(t,n);r&&this._routePointerDown("mouse",r[0],r[1])&&(n.preventDefault(),n.stopPropagation())}),t.addEventListener("mousemove",n=>{const r=this._toCanvasPoint(t,n);r&&this._routePointerMove("mouse",r[0],r[1])}),t.addEventListener("mouseup",n=>{const r=this._toCanvasPoint(t,n);r&&this._routePointerUp("mouse",r[0],r[1])&&(n.preventDefault(),n.stopPropagation())}),t.addEventListener("mouseleave",n=>{this._routePointerLeave("mouse")}),t.addEventListener("touchstart",n=>{for(const r of Array.from(n.changedTouches)){const s=this._toCanvasPoint(t,r);if(!s)return;this._routePointerDown(r.identifier,s[0],s[1])}n.preventDefault()},{passive:!1}),t.addEventListener("touchmove",n=>{for(const r of Array.from(n.changedTouches)){const s=this._toCanvasPoint(t,r);if(!s)return;this._routePointerMove(r.identifier,s[0],s[1])}n.preventDefault()},{passive:!1}),t.addEventListener("touchend",n=>{for(const r of Array.from(n.changedTouches)){const s=this._toCanvasPoint(t,r);if(!s)return;this._routePointerUp(r.identifier,s[0],s[1])}n.preventDefault()},{passive:!1}),t.addEventListener("touchcancel",n=>{for(const r of Array.from(n.changedTouches))this._routePointerLeave(r.identifier);n.preventDefault()},{passive:!1})}_toCanvasPoint(t,n){const r=t.getBoundingClientRect();return r.width<=0||r.height<=0?null:(this._cpDummy[0]=(n.clientX-r.left)*(t.width/r.width),this._cpDummy[1]=(n.clientY-r.top)*(t.height/r.height),this._cpDummy)}_routePointerMove(t,n,r){this.app.mouseMove(n,r)}_routeKeyDown(t){return!1}_routeKeyUp(t){return!1}_routePointerDown(t,n,r){return this.app.mouseMove(n,r),this.app.mouseDown(),!1}_routePointerUp(t,n,r){return!1}_routePointerLeave(t){document.documentElement.style.cursor="default"}}function kr(i,e,t){return(1-t)*i+t*e}const Rm=Ft;class ts extends io{constructor(e){super(e),this.defaultDPI=90,this.defaultUnit="px"}load(e,t,n,r){const s=this,o=new Xh(s.manager);o.setPath(s.path),o.setRequestHeader(s.requestHeader),o.setWithCredentials(s.withCredentials),o.load(e,function(c){try{t(s.parse(c))}catch(d){r?r(d):console.error(d),s.manager.itemError(e)}},n,r)}parse(e){const t=this;function n(X,U){if(X.nodeType!==1)return;const M=R(X);let g=!1,z=null;switch(X.nodeName){case"svg":U=E(X,U);break;case"style":s(X);break;case"g":U=E(X,U);break;case"path":U=E(X,U),X.hasAttribute("d")&&(z=r(X));break;case"rect":U=E(X,U),z=d(X);break;case"polygon":U=E(X,U),z=h(X);break;case"polyline":U=E(X,U),z=p(X);break;case"circle":U=E(X,U),z=a(X);break;case"ellipse":U=E(X,U),z=l(X);break;case"line":U=E(X,U),z=u(X);break;case"defs":g=!0;break;case"use":U=E(X,U);const ue=(X.getAttributeNS("http://www.w3.org/1999/xlink","href")||"").substring(1),me=X.viewportElement.getElementById(ue);me?n(me,U):console.warn("SVGLoader: 'use node' references non-existent node id: "+ue);break}z&&(U.fill!==void 0&&U.fill!=="none"&&z.color.setStyle(U.fill,Rm),y(z,_e),G.push(z),z.userData={node:X,style:U});const se=X.childNodes;for(let k=0;k<se.length;k++){const ue=se[k];g&&ue.nodeName!=="style"&&ue.nodeName!=="defs"||n(ue,U)}M&&(j.pop(),j.length>0?_e.copy(j[j.length-1]):_e.identity())}function r(X){const U=new ni,M=new oe,g=new oe,z=new oe;let se=!0,k=!1;const ue=X.getAttribute("d");if(ue===""||ue==="none")return null;const me=ue.match(/[a-df-z][^a-df-z]*/ig);for(let he=0,H=me.length;he<H;he++){const T=me[he],q=T.charAt(0),J=T.slice(1).trim();se===!0&&(k=!0,se=!1);let D;switch(q){case"M":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2)M.x=D[b+0],M.y=D[b+1],g.x=M.x,g.y=M.y,b===0?U.moveTo(M.x,M.y):U.lineTo(M.x,M.y),b===0&&z.copy(M);break;case"H":D=S(J);for(let b=0,ae=D.length;b<ae;b++)M.x=D[b],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"V":D=S(J);for(let b=0,ae=D.length;b<ae;b++)M.y=D[b],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"L":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2)M.x=D[b+0],M.y=D[b+1],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"C":D=S(J);for(let b=0,ae=D.length;b<ae;b+=6)U.bezierCurveTo(D[b+0],D[b+1],D[b+2],D[b+3],D[b+4],D[b+5]),g.x=D[b+2],g.y=D[b+3],M.x=D[b+4],M.y=D[b+5],b===0&&k===!0&&z.copy(M);break;case"S":D=S(J);for(let b=0,ae=D.length;b<ae;b+=4)U.bezierCurveTo(m(M.x,g.x),m(M.y,g.y),D[b+0],D[b+1],D[b+2],D[b+3]),g.x=D[b+0],g.y=D[b+1],M.x=D[b+2],M.y=D[b+3],b===0&&k===!0&&z.copy(M);break;case"Q":D=S(J);for(let b=0,ae=D.length;b<ae;b+=4)U.quadraticCurveTo(D[b+0],D[b+1],D[b+2],D[b+3]),g.x=D[b+0],g.y=D[b+1],M.x=D[b+2],M.y=D[b+3],b===0&&k===!0&&z.copy(M);break;case"T":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2){const ce=m(M.x,g.x),Te=m(M.y,g.y);U.quadraticCurveTo(ce,Te,D[b+0],D[b+1]),g.x=ce,g.y=Te,M.x=D[b+0],M.y=D[b+1],b===0&&k===!0&&z.copy(M)}break;case"A":D=S(J,[3,4],7);for(let b=0,ae=D.length;b<ae;b+=7){if(D[b+5]==M.x&&D[b+6]==M.y)continue;const ce=M.clone();M.x=D[b+5],M.y=D[b+6],g.x=M.x,g.y=M.y,o(U,D[b],D[b+1],D[b+2],D[b+3],D[b+4],ce,M),b===0&&k===!0&&z.copy(M)}break;case"m":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2)M.x+=D[b+0],M.y+=D[b+1],g.x=M.x,g.y=M.y,b===0?U.moveTo(M.x,M.y):U.lineTo(M.x,M.y),b===0&&z.copy(M);break;case"h":D=S(J);for(let b=0,ae=D.length;b<ae;b++)M.x+=D[b],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"v":D=S(J);for(let b=0,ae=D.length;b<ae;b++)M.y+=D[b],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"l":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2)M.x+=D[b+0],M.y+=D[b+1],g.x=M.x,g.y=M.y,U.lineTo(M.x,M.y),b===0&&k===!0&&z.copy(M);break;case"c":D=S(J);for(let b=0,ae=D.length;b<ae;b+=6)U.bezierCurveTo(M.x+D[b+0],M.y+D[b+1],M.x+D[b+2],M.y+D[b+3],M.x+D[b+4],M.y+D[b+5]),g.x=M.x+D[b+2],g.y=M.y+D[b+3],M.x+=D[b+4],M.y+=D[b+5],b===0&&k===!0&&z.copy(M);break;case"s":D=S(J);for(let b=0,ae=D.length;b<ae;b+=4)U.bezierCurveTo(m(M.x,g.x),m(M.y,g.y),M.x+D[b+0],M.y+D[b+1],M.x+D[b+2],M.y+D[b+3]),g.x=M.x+D[b+0],g.y=M.y+D[b+1],M.x+=D[b+2],M.y+=D[b+3],b===0&&k===!0&&z.copy(M);break;case"q":D=S(J);for(let b=0,ae=D.length;b<ae;b+=4)U.quadraticCurveTo(M.x+D[b+0],M.y+D[b+1],M.x+D[b+2],M.y+D[b+3]),g.x=M.x+D[b+0],g.y=M.y+D[b+1],M.x+=D[b+2],M.y+=D[b+3],b===0&&k===!0&&z.copy(M);break;case"t":D=S(J);for(let b=0,ae=D.length;b<ae;b+=2){const ce=m(M.x,g.x),Te=m(M.y,g.y);U.quadraticCurveTo(ce,Te,M.x+D[b+0],M.y+D[b+1]),g.x=ce,g.y=Te,M.x=M.x+D[b+0],M.y=M.y+D[b+1],b===0&&k===!0&&z.copy(M)}break;case"a":D=S(J,[3,4],7);for(let b=0,ae=D.length;b<ae;b+=7){if(D[b+5]==0&&D[b+6]==0)continue;const ce=M.clone();M.x+=D[b+5],M.y+=D[b+6],g.x=M.x,g.y=M.y,o(U,D[b],D[b+1],D[b+2],D[b+3],D[b+4],ce,M),b===0&&k===!0&&z.copy(M)}break;case"Z":case"z":U.currentPath.autoClose=!0,U.currentPath.curves.length>0&&(M.copy(z),U.currentPath.currentPoint.copy(M),se=!0);break;default:console.warn(T)}k=!1}return U}function s(X){if(!(!X.sheet||!X.sheet.cssRules||!X.sheet.cssRules.length))for(let U=0;U<X.sheet.cssRules.length;U++){const M=X.sheet.cssRules[U];if(M.type!==1)continue;const g=M.selectorText.split(/,/gm).filter(Boolean).map(z=>z.trim());for(let z=0;z<g.length;z++){const se=Object.fromEntries(Object.entries(M.style).filter(([,k])=>k!==""));Z[g[z]]=Object.assign(Z[g[z]]||{},se)}}}function o(X,U,M,g,z,se,k,ue){if(U==0||M==0){X.lineTo(ue.x,ue.y);return}g=g*Math.PI/180,U=Math.abs(U),M=Math.abs(M);const me=(k.x-ue.x)/2,he=(k.y-ue.y)/2,H=Math.cos(g)*me+Math.sin(g)*he,T=-Math.sin(g)*me+Math.cos(g)*he;let q=U*U,J=M*M;const D=H*H,b=T*T,ae=D/q+b/J;if(ae>1){const ge=Math.sqrt(ae);U=ge*U,M=ge*M,q=U*U,J=M*M}const ce=q*b+J*D,Te=(q*J-ce)/ce;let O=Math.sqrt(Math.max(0,Te));z===se&&(O=-O);const x=O*U*T/M,W=-O*M*H/U,re=Math.cos(g)*x-Math.sin(g)*W+(k.x+ue.x)/2,fe=Math.sin(g)*x+Math.cos(g)*W+(k.y+ue.y)/2,ne=c(1,0,(H-x)/U,(T-W)/M),Ne=c((H-x)/U,(T-W)/M,(-H-x)/U,(-T-W)/M)%(Math.PI*2);X.currentPath.absellipse(re,fe,U,M,ne,ne+Ne,se===0,g)}function c(X,U,M,g){const z=X*M+U*g,se=Math.sqrt(X*X+U*U)*Math.sqrt(M*M+g*g);let k=Math.acos(Math.max(-1,Math.min(1,z/se)));return X*g-U*M<0&&(k=-k),k}function d(X){const U=A(X.getAttribute("x")||0),M=A(X.getAttribute("y")||0),g=A(X.getAttribute("rx")||X.getAttribute("ry")||0),z=A(X.getAttribute("ry")||X.getAttribute("rx")||0),se=A(X.getAttribute("width")),k=A(X.getAttribute("height")),ue=1-.551915024494,me=new ni;return me.moveTo(U+g,M),me.lineTo(U+se-g,M),(g!==0||z!==0)&&me.bezierCurveTo(U+se-g*ue,M,U+se,M+z*ue,U+se,M+z),me.lineTo(U+se,M+k-z),(g!==0||z!==0)&&me.bezierCurveTo(U+se,M+k-z*ue,U+se-g*ue,M+k,U+se-g,M+k),me.lineTo(U+g,M+k),(g!==0||z!==0)&&me.bezierCurveTo(U+g*ue,M+k,U,M+k-z*ue,U,M+k-z),me.lineTo(U,M+z),(g!==0||z!==0)&&me.bezierCurveTo(U,M+z*ue,U+g*ue,M,U+g,M),me}function h(X){function U(se,k,ue){const me=A(k),he=A(ue);z===0?g.moveTo(me,he):g.lineTo(me,he),z++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new ni;let z=0;return X.getAttribute("points").replace(M,U),g.currentPath.autoClose=!0,g}function p(X){function U(se,k,ue){const me=A(k),he=A(ue);z===0?g.moveTo(me,he):g.lineTo(me,he),z++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new ni;let z=0;return X.getAttribute("points").replace(M,U),g.currentPath.autoClose=!1,g}function a(X){const U=A(X.getAttribute("cx")||0),M=A(X.getAttribute("cy")||0),g=A(X.getAttribute("r")||0),z=new li;z.absarc(U,M,g,0,Math.PI*2);const se=new ni;return se.subPaths.push(z),se}function l(X){const U=A(X.getAttribute("cx")||0),M=A(X.getAttribute("cy")||0),g=A(X.getAttribute("rx")||0),z=A(X.getAttribute("ry")||0),se=new li;se.absellipse(U,M,g,z,0,Math.PI*2);const k=new ni;return k.subPaths.push(se),k}function u(X){const U=A(X.getAttribute("x1")||0),M=A(X.getAttribute("y1")||0),g=A(X.getAttribute("x2")||0),z=A(X.getAttribute("y2")||0),se=new ni;return se.moveTo(U,M),se.lineTo(g,z),se.currentPath.autoClose=!1,se}function E(X,U){U=Object.assign({},U);let M={};if(X.hasAttribute("class")){const k=X.getAttribute("class").split(/\s/).filter(Boolean).map(ue=>ue.trim());for(let ue=0;ue<k.length;ue++)M=Object.assign(M,Z["."+k[ue]])}X.hasAttribute("id")&&(M=Object.assign(M,Z["#"+X.getAttribute("id")]));function g(k,ue,me){me===void 0&&(me=function(H){return H.startsWith("url")&&console.warn("SVGLoader: url access in attributes is not implemented."),H}),X.hasAttribute(k)&&(U[ue]=me(X.getAttribute(k))),M[k]&&(U[ue]=me(M[k])),X.style&&X.style[k]!==""&&(U[ue]=me(X.style[k]))}function z(k){return Math.max(0,Math.min(1,A(k)))}function se(k){return Math.max(0,A(k))}return g("fill","fill"),g("fill-opacity","fillOpacity",z),g("fill-rule","fillRule"),g("opacity","opacity",z),g("stroke","stroke"),g("stroke-opacity","strokeOpacity",z),g("stroke-width","strokeWidth",se),g("stroke-linejoin","strokeLineJoin"),g("stroke-linecap","strokeLineCap"),g("stroke-miterlimit","strokeMiterLimit",se),g("visibility","visibility"),U}function m(X,U){return X-(U-X)}function S(X,U,M){if(typeof X!="string")throw new TypeError("Invalid input: "+typeof X);const g={WHITESPACE:/[ \t\r\n]/,DIGIT:/[\d]/,SIGN:/[-+]/,POINT:/\./,COMMA:/,/,EXP:/e/i,FLAGS:/[01]/},z=0,se=1,k=2,ue=3;let me=z,he=!0,H="",T="";const q=[];function J(ce,Te,O){const x=new SyntaxError('Unexpected character "'+ce+'" at index '+Te+".");throw x.partial=O,x}function D(){H!==""&&(T===""?q.push(Number(H)):q.push(Number(H)*Math.pow(10,Number(T)))),H="",T=""}let b;const ae=X.length;for(let ce=0;ce<ae;ce++){if(b=X[ce],Array.isArray(U)&&U.includes(q.length%M)&&g.FLAGS.test(b)){me=se,H=b,D();continue}if(me===z){if(g.WHITESPACE.test(b))continue;if(g.DIGIT.test(b)||g.SIGN.test(b)){me=se,H=b;continue}if(g.POINT.test(b)){me=k,H=b;continue}g.COMMA.test(b)&&(he&&J(b,ce,q),he=!0)}if(me===se){if(g.DIGIT.test(b)){H+=b;continue}if(g.POINT.test(b)){H+=b,me=k;continue}if(g.EXP.test(b)){me=ue;continue}g.SIGN.test(b)&&H.length===1&&g.SIGN.test(H[0])&&J(b,ce,q)}if(me===k){if(g.DIGIT.test(b)){H+=b;continue}if(g.EXP.test(b)){me=ue;continue}g.POINT.test(b)&&H[H.length-1]==="."&&J(b,ce,q)}if(me===ue){if(g.DIGIT.test(b)){T+=b;continue}if(g.SIGN.test(b)){if(T===""){T+=b;continue}T.length===1&&g.SIGN.test(T)&&J(b,ce,q)}}g.WHITESPACE.test(b)?(D(),me=z,he=!1):g.COMMA.test(b)?(D(),me=z,he=!0):g.SIGN.test(b)?(D(),me=se,H=b):g.POINT.test(b)?(D(),me=k,H=b):J(b,ce,q)}return D(),q}const f=["mm","cm","in","pt","pc","px"],v={mm:{mm:1,cm:.1,in:1/25.4,pt:72/25.4,pc:6/25.4,px:-1},cm:{mm:10,cm:1,in:1/2.54,pt:72/2.54,pc:6/2.54,px:-1},in:{mm:25.4,cm:2.54,in:1,pt:72,pc:6,px:-1},pt:{mm:25.4/72,cm:2.54/72,in:1/72,pt:1,pc:6/72,px:-1},pc:{mm:25.4/6,cm:2.54/6,in:1/6,pt:72/6,pc:1,px:-1},px:{px:1}};function A(X){let U="px";if(typeof X=="string"||X instanceof String)for(let g=0,z=f.length;g<z;g++){const se=f[g];if(X.endsWith(se)){U=se,X=X.substring(0,X.length-se.length);break}}let M;return U==="px"&&t.defaultUnit!=="px"?M=v.in[t.defaultUnit]/t.defaultDPI:(M=v[U][t.defaultUnit],M<0&&(M=v[U].in*t.defaultDPI)),M*parseFloat(X)}function R(X){if(!(X.hasAttribute("transform")||X.nodeName==="use"&&(X.hasAttribute("x")||X.hasAttribute("y"))))return null;const U=C(X);return j.length>0&&U.premultiply(j[j.length-1]),_e.copy(U),j.push(U),U}function C(X){const U=new Ye,M=$;if(X.nodeName==="use"&&(X.hasAttribute("x")||X.hasAttribute("y"))){const g=A(X.getAttribute("x")||0),z=A(X.getAttribute("y")||0);U.translate(g,z)}if(X.hasAttribute("transform")){const g=X.getAttribute("transform").split(")");for(let z=g.length-1;z>=0;z--){const se=g[z].trim();if(se==="")continue;const k=se.indexOf("("),ue=se.length;if(k>0&&k<ue){const me=se.slice(0,k),he=S(se.slice(k+1));switch(M.identity(),me){case"translate":if(he.length>=1){const H=he[0];let T=0;he.length>=2&&(T=he[1]),M.translate(H,T)}break;case"rotate":if(he.length>=1){let H=0,T=0,q=0;H=he[0]*Math.PI/180,he.length>=3&&(T=he[1],q=he[2]),ie.makeTranslation(-T,-q),Q.makeRotation(H),B.multiplyMatrices(Q,ie),ie.makeTranslation(T,q),M.multiplyMatrices(ie,B)}break;case"scale":if(he.length>=1){const H=he[0];let T=H;he.length>=2&&(T=he[1]),M.scale(H,T)}break;case"skewX":he.length===1&&M.set(1,Math.tan(he[0]*Math.PI/180),0,0,1,0,0,0,1);break;case"skewY":he.length===1&&M.set(1,0,0,Math.tan(he[0]*Math.PI/180),1,0,0,0,1);break;case"matrix":he.length===6&&M.set(he[0],he[2],he[4],he[1],he[3],he[5],0,0,1);break}}U.premultiply(M)}}return U}function y(X,U){function M(k){le.set(k.x,k.y,1).applyMatrix3(U),k.set(le.x,le.y)}function g(k){const ue=k.xRadius,me=k.yRadius,he=Math.cos(k.aRotation),H=Math.sin(k.aRotation),T=new V(ue*he,ue*H,0),q=new V(-me*H,me*he,0),J=T.applyMatrix3(U),D=q.applyMatrix3(U),b=$.set(J.x,D.x,0,J.y,D.y,0,0,0,1),ae=ie.copy(b).invert(),O=Q.copy(ae).transpose().multiply(ae).elements,x=P(O[0],O[1],O[4]),W=Math.sqrt(x.rt1),re=Math.sqrt(x.rt2);if(k.xRadius=1/W,k.yRadius=1/re,k.aRotation=Math.atan2(x.sn,x.cs),!((k.aEndAngle-k.aStartAngle)%(2*Math.PI)<Number.EPSILON)){const ne=ie.set(W,0,0,0,re,0,0,0,1),Ne=Q.set(x.cs,x.sn,0,-x.sn,x.cs,0,0,0,1),ge=ne.multiply(Ne).multiply(b),we=Ce=>{const{x:Ee,y:Ae}=new V(Math.cos(Ce),Math.sin(Ce),0).applyMatrix3(ge);return Math.atan2(Ae,Ee)};k.aStartAngle=we(k.aStartAngle),k.aEndAngle=we(k.aEndAngle),N(U)&&(k.aClockwise=!k.aClockwise)}}function z(k){const ue=I(U),me=_(U);k.xRadius*=ue,k.yRadius*=me;const he=ue>Number.EPSILON?Math.atan2(U.elements[1],U.elements[0]):Math.atan2(-U.elements[3],U.elements[4]);k.aRotation+=he,N(U)&&(k.aStartAngle*=-1,k.aEndAngle*=-1,k.aClockwise=!k.aClockwise)}const se=X.subPaths;for(let k=0,ue=se.length;k<ue;k++){const he=se[k].curves;for(let H=0;H<he.length;H++){const T=he[H];T.isLineCurve?(M(T.v1),M(T.v2)):T.isCubicBezierCurve?(M(T.v0),M(T.v1),M(T.v2),M(T.v3)):T.isQuadraticBezierCurve?(M(T.v0),M(T.v1),M(T.v2)):T.isEllipseCurve&&(pe.set(T.aX,T.aY),M(pe),T.aX=pe.x,T.aY=pe.y,w(U)?g(T):z(T))}}}function N(X){const U=X.elements;return U[0]*U[4]-U[1]*U[3]<0}function w(X){const U=X.elements,M=U[0]*U[3]+U[1]*U[4];if(M===0)return!1;const g=I(X),z=_(X);return Math.abs(M/(g*z))>Number.EPSILON}function I(X){const U=X.elements;return Math.sqrt(U[0]*U[0]+U[1]*U[1])}function _(X){const U=X.elements;return Math.sqrt(U[3]*U[3]+U[4]*U[4])}function P(X,U,M){let g,z,se,k,ue;const me=X+M,he=X-M,H=Math.sqrt(he*he+4*U*U);return me>0?(g=.5*(me+H),ue=1/g,z=X*ue*M-U*ue*U):me<0?z=.5*(me-H):(g=.5*H,z=-.5*H),he>0?se=he+H:se=he-H,Math.abs(se)>2*Math.abs(U)?(ue=-2*U/se,k=1/Math.sqrt(1+ue*ue),se=ue*k):Math.abs(U)===0?(se=1,k=0):(ue=-.5*se/U,se=1/Math.sqrt(1+ue*ue),k=ue*se),he>0&&(ue=se,se=-k,k=ue),{rt1:g,rt2:z,cs:se,sn:k}}const G=[],Z={},j=[],$=new Ye,ie=new Ye,Q=new Ye,B=new Ye,pe=new oe,le=new V,_e=new Ye,Ue=new DOMParser().parseFromString(e,"image/svg+xml");return n(Ue.documentElement,{fill:"#000",fillOpacity:1,strokeOpacity:1,strokeWidth:1,strokeLineJoin:"miter",strokeLineCap:"butt",strokeMiterLimit:4}),{paths:G,xml:Ue.documentElement}}static createShapes(e){const n={ORIGIN:0,DESTINATION:1,BETWEEN:2,LEFT:3,RIGHT:4,BEHIND:5,BEYOND:6},r={loc:n.ORIGIN,t:0};function s(m,S,f,v){const A=m.x,R=S.x,C=f.x,y=v.x,N=m.y,w=S.y,I=f.y,_=v.y,P=(y-C)*(N-I)-(_-I)*(A-C),G=(R-A)*(N-I)-(w-N)*(A-C),Z=(_-I)*(R-A)-(y-C)*(w-N),j=P/Z,$=G/Z;if(Z===0&&P!==0||j<=0||j>=1||$<0||$>1)return null;if(P===0&&Z===0){for(let ie=0;ie<2;ie++)if(o(ie===0?f:v,m,S),r.loc==n.ORIGIN){const Q=ie===0?f:v;return{x:Q.x,y:Q.y,t:r.t}}else if(r.loc==n.BETWEEN){const Q=+(A+r.t*(R-A)).toPrecision(10),B=+(N+r.t*(w-N)).toPrecision(10);return{x:Q,y:B,t:r.t}}return null}else{for(let B=0;B<2;B++)if(o(B===0?f:v,m,S),r.loc==n.ORIGIN){const pe=B===0?f:v;return{x:pe.x,y:pe.y,t:r.t}}const ie=+(A+j*(R-A)).toPrecision(10),Q=+(N+j*(w-N)).toPrecision(10);return{x:ie,y:Q,t:j}}}function o(m,S,f){const v=f.x-S.x,A=f.y-S.y,R=m.x-S.x,C=m.y-S.y,y=v*C-R*A;if(m.x===S.x&&m.y===S.y){r.loc=n.ORIGIN,r.t=0;return}if(m.x===f.x&&m.y===f.y){r.loc=n.DESTINATION,r.t=1;return}if(y<-Number.EPSILON){r.loc=n.LEFT;return}if(y>Number.EPSILON){r.loc=n.RIGHT;return}if(v*R<0||A*C<0){r.loc=n.BEHIND;return}if(Math.sqrt(v*v+A*A)<Math.sqrt(R*R+C*C)){r.loc=n.BEYOND;return}let N;v!==0?N=R/v:N=C/A,r.loc=n.BETWEEN,r.t=N}function c(m,S){const f=[],v=[];for(let A=1;A<m.length;A++){const R=m[A-1],C=m[A];for(let y=1;y<S.length;y++){const N=S[y-1],w=S[y],I=s(R,C,N,w);I!==null&&f.find(_=>_.t<=I.t+Number.EPSILON&&_.t>=I.t-Number.EPSILON)===void 0&&(f.push(I),v.push(new oe(I.x,I.y)))}}return v}function d(m,S,f){const v=new oe;S.getCenter(v);const A=[];return f.forEach(R=>{R.boundingBox.containsPoint(v)&&c(m,R.points).forEach(y=>{A.push({identifier:R.identifier,isCW:R.isCW,point:y})})}),A.sort((R,C)=>R.point.x-C.point.x),A}function h(m,S,f,v,A){(A==null||A==="")&&(A="nonzero");const R=new oe;m.boundingBox.getCenter(R);const C=[new oe(f,R.y),new oe(v,R.y)],y=d(C,m.boundingBox,S);y.sort((G,Z)=>G.point.x-Z.point.x);const N=[],w=[];y.forEach(G=>{G.identifier===m.identifier?N.push(G):w.push(G)});const I=N[0].point.x,_=[];let P=0;for(;P<w.length&&w[P].point.x<I;)_.length>0&&_[_.length-1]===w[P].identifier?_.pop():_.push(w[P].identifier),P++;if(_.push(m.identifier),A==="evenodd"){const G=_.length%2===0,Z=_[_.length-2];return{identifier:m.identifier,isHole:G,for:Z}}else if(A==="nonzero"){let G=!0,Z=null,j=null;for(let $=0;$<_.length;$++){const ie=_[$];G?(j=S[ie].isCW,G=!1,Z=ie):j!==S[ie].isCW&&(j=S[ie].isCW,G=!0)}return{identifier:m.identifier,isHole:G,for:Z}}else console.warn('fill-rule: "'+A+'" is currently not implemented.')}let p=999999999,a=-999999999,l=e.subPaths.map(m=>{const S=m.getPoints();let f=-999999999,v=999999999,A=-999999999,R=999999999;for(let C=0;C<S.length;C++){const y=S[C];y.y>f&&(f=y.y),y.y<v&&(v=y.y),y.x>A&&(A=y.x),y.x<R&&(R=y.x)}return a<=A&&(a=A+1),p>=R&&(p=R-1),{curves:m.curves,points:S,isCW:hn.isClockWise(S),identifier:-1,boundingBox:new Jh(new oe(R,v),new oe(A,f))}});l=l.filter(m=>m.points.length>1);for(let m=0;m<l.length;m++)l[m].identifier=m;const u=l.map(m=>h(m,l,p,a,e.userData?e.userData.style.fillRule:void 0)),E=[];return l.forEach(m=>{if(!u[m.identifier].isHole){const f=new qn;f.curves=m.curves,u.filter(A=>A.isHole&&A.for===m.identifier).forEach(A=>{const R=l[A.identifier],C=new li;C.curves=R.curves,f.holes.push(C)}),E.push(f)}}),E}static getStrokeStyle(e,t,n,r,s){return e=e!==void 0?e:1,t=t!==void 0?t:"#000",n=n!==void 0?n:"miter",r=r!==void 0?r:"butt",s=s!==void 0?s:4,{strokeColor:t,strokeWidth:e,strokeLineJoin:n,strokeLineCap:r,strokeMiterLimit:s}}static pointsToStroke(e,t,n,r){const s=[],o=[],c=[];if(ts.pointsToStrokeWithBuffers(e,t,n,r,s,o,c)===0)return null;const d=new gt;return d.setAttribute("position",new xt(s,3)),d.setAttribute("normal",new xt(o,3)),d.setAttribute("uv",new xt(c,2)),d}static pointsToStrokeWithBuffers(e,t,n,r,s,o,c,d){const h=new oe,p=new oe,a=new oe,l=new oe,u=new oe,E=new oe,m=new oe,S=new oe,f=new oe,v=new oe,A=new oe,R=new oe,C=new oe,y=new oe,N=new oe,w=new oe,I=new oe;n=n!==void 0?n:12,r=r!==void 0?r:.001,d=d!==void 0?d:0,e=he(e);const _=e.length;if(_<2)return 0;const P=e[0].equals(e[_-1]);let G,Z=e[0],j;const $=t.strokeWidth/2,ie=1/(_-1);let Q=0,B,pe,le,_e,Ue=!1,He=0,X=d*3,U=d*2;M(e[0],e[1],h).multiplyScalar($),S.copy(e[0]).sub(h),f.copy(e[0]).add(h),v.copy(S),A.copy(f);for(let H=1;H<_;H++){G=e[H],H===_-1?P?j=e[1]:j=void 0:j=e[H+1];const T=h;if(M(Z,G,T),a.copy(T).multiplyScalar($),R.copy(G).sub(a),C.copy(G).add(a),B=Q+ie,pe=!1,j!==void 0){M(G,j,p),a.copy(p).multiplyScalar($),y.copy(G).sub(a),N.copy(G).add(a),le=!0,a.subVectors(j,Z),T.dot(a)<0&&(le=!1),H===1&&(Ue=le),a.subVectors(j,G),a.normalize();const q=Math.abs(T.dot(a));if(q>Number.EPSILON){const J=$/q;a.multiplyScalar(-J),l.subVectors(G,Z),u.copy(l).setLength(J).add(a),w.copy(u).negate();const D=u.length(),b=l.length();l.divideScalar(b),E.subVectors(j,G);const ae=E.length();switch(E.divideScalar(ae),l.dot(w)<b&&E.dot(w)<ae&&(pe=!0),I.copy(u).add(G),w.add(G),_e=!1,pe?le?(N.copy(w),C.copy(w)):(y.copy(w),R.copy(w)):se(),t.strokeLineJoin){case"bevel":k(le,pe,B);break;case"round":ue(le,pe),le?z(G,R,y,B,0):z(G,N,C,B,1);break;case"miter":case"miter-clip":default:const ce=$*t.strokeMiterLimit/D;if(ce<1)if(t.strokeLineJoin!=="miter-clip"){k(le,pe,B);break}else ue(le,pe),le?(E.subVectors(I,R).multiplyScalar(ce).add(R),m.subVectors(I,y).multiplyScalar(ce).add(y),g(R,B,0),g(E,B,0),g(G,B,.5),g(G,B,.5),g(E,B,0),g(m,B,0),g(G,B,.5),g(m,B,0),g(y,B,0)):(E.subVectors(I,C).multiplyScalar(ce).add(C),m.subVectors(I,N).multiplyScalar(ce).add(N),g(C,B,1),g(E,B,1),g(G,B,.5),g(G,B,.5),g(E,B,1),g(m,B,1),g(G,B,.5),g(m,B,1),g(N,B,1));else pe?(le?(g(f,Q,1),g(S,Q,0),g(I,B,0),g(f,Q,1),g(I,B,0),g(w,B,1)):(g(f,Q,1),g(S,Q,0),g(I,B,1),g(S,Q,0),g(w,B,0),g(I,B,1)),le?y.copy(I):N.copy(I)):le?(g(R,B,0),g(I,B,0),g(G,B,.5),g(G,B,.5),g(I,B,0),g(y,B,0)):(g(C,B,1),g(I,B,1),g(G,B,.5),g(G,B,.5),g(I,B,1),g(N,B,1)),_e=!0;break}}else se()}else se();!P&&H===_-1&&me(e[0],v,A,le,!0,Q),Q=B,Z=G,S.copy(y),f.copy(N)}if(!P)me(G,R,C,le,!1,B);else if(pe&&s){let H=I,T=w;Ue!==le&&(H=w,T=I),le?(_e||Ue)&&(T.toArray(s,0),T.toArray(s,9),_e&&H.toArray(s,3)):(_e||!Ue)&&(T.toArray(s,3),T.toArray(s,9),_e&&H.toArray(s,0))}return He;function M(H,T,q){return q.subVectors(T,H),q.set(-q.y,q.x).normalize()}function g(H,T,q){s&&(s[X]=H.x,s[X+1]=H.y,s[X+2]=0,o&&(o[X]=0,o[X+1]=0,o[X+2]=1),X+=3,c&&(c[U]=T,c[U+1]=q,U+=2)),He+=3}function z(H,T,q,J,D){h.copy(T).sub(H).normalize(),p.copy(q).sub(H).normalize();let b=Math.PI;const ae=h.dot(p);Math.abs(ae)<1&&(b=Math.abs(Math.acos(ae))),b/=n,a.copy(T);for(let ce=0,Te=n-1;ce<Te;ce++)l.copy(a).rotateAround(H,b),g(a,J,D),g(l,J,D),g(H,J,.5),a.copy(l);g(l,J,D),g(q,J,D),g(H,J,.5)}function se(){g(f,Q,1),g(S,Q,0),g(R,B,0),g(f,Q,1),g(R,B,0),g(C,B,1)}function k(H,T,q){T?H?(g(f,Q,1),g(S,Q,0),g(R,B,0),g(f,Q,1),g(R,B,0),g(w,B,1),g(R,q,0),g(y,q,0),g(w,q,.5)):(g(f,Q,1),g(S,Q,0),g(C,B,1),g(S,Q,0),g(w,B,0),g(C,B,1),g(C,q,1),g(w,q,0),g(N,q,1)):H?(g(R,q,0),g(y,q,0),g(G,q,.5)):(g(C,q,1),g(N,q,0),g(G,q,.5))}function ue(H,T){T&&(H?(g(f,Q,1),g(S,Q,0),g(R,B,0),g(f,Q,1),g(R,B,0),g(w,B,1),g(R,Q,0),g(G,B,.5),g(w,B,1),g(G,B,.5),g(y,Q,0),g(w,B,1)):(g(f,Q,1),g(S,Q,0),g(C,B,1),g(S,Q,0),g(w,B,0),g(C,B,1),g(C,Q,1),g(w,B,0),g(G,B,.5),g(G,B,.5),g(w,B,0),g(N,Q,1)))}function me(H,T,q,J,D,b){switch(t.strokeLineCap){case"round":D?z(H,q,T,b,.5):z(H,T,q,b,.5);break;case"square":if(D)h.subVectors(T,H),p.set(h.y,-h.x),a.addVectors(h,p).add(H),l.subVectors(p,h).add(H),J?(a.toArray(s,3),l.toArray(s,0),l.toArray(s,9)):(a.toArray(s,3),c[7]===1?l.toArray(s,9):a.toArray(s,9),l.toArray(s,0));else{h.subVectors(q,H),p.set(h.y,-h.x),a.addVectors(h,p).add(H),l.subVectors(p,h).add(H);const ae=s.length;J?(a.toArray(s,ae-3),l.toArray(s,ae-6),l.toArray(s,ae-12)):(l.toArray(s,ae-6),a.toArray(s,ae-3),l.toArray(s,ae-12))}break}}function he(H){let T=!1;for(let J=1,D=H.length-1;J<D;J++)if(H[J].distanceTo(H[J+1])<r){T=!0;break}if(!T)return H;const q=[];q.push(H[0]);for(let J=1,D=H.length-1;J<D;J++)H[J].distanceTo(H[J+1])>=r&&q.push(H[J]);return q.push(H[H.length-1]),q}}}function vm(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),r=new Set(Object.keys(i[0].morphAttributes)),s={},o={},c=i[0].morphTargetsRelative,d=new gt;let h=0;for(let p=0;p<i.length;++p){const a=i[p];let l=0;if(t!==(a.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const u in a.attributes){if(!n.has(u))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+'. All geometries must have compatible attributes; make sure "'+u+'" attribute exists among all geometries, or in none of them.'),null;s[u]===void 0&&(s[u]=[]),s[u].push(a.attributes[u]),l++}if(l!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". Make sure all geometries have the same number of attributes."),null;if(c!==a.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const u in a.morphAttributes){if(!r.has(u))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+".  .morphAttributes must be consistent throughout all geometries."),null;o[u]===void 0&&(o[u]=[]),o[u].push(a.morphAttributes[u])}if(e){let u;if(t)u=a.index.count;else if(a.attributes.position!==void 0)u=a.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". The geometry must have either an index or a position attribute"),null;d.addGroup(h,u,p),h+=u}}if(t){let p=0;const a=[];for(let l=0;l<i.length;++l){const u=i[l].index;for(let E=0;E<u.count;++E)a.push(u.getX(E)+p);p+=i[l].attributes.position.count}d.setIndex(a)}for(const p in s){const a=Cl(s[p]);if(!a)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" attribute."),null;d.setAttribute(p,a)}for(const p in o){const a=o[p][0].length;if(a===0)break;d.morphAttributes=d.morphAttributes||{},d.morphAttributes[p]=[];for(let l=0;l<a;++l){const u=[];for(let m=0;m<o[p].length;++m)u.push(o[p][m][l]);const E=Cl(u);if(!E)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" morphAttribute."),null;d.morphAttributes[p].push(E)}}return d}function Cl(i){let e,t,n,r=-1,s=0;for(let h=0;h<i.length;++h){const p=i[h];if(e===void 0&&(e=p.array.constructor),e!==p.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=p.itemSize),t!==p.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=p.normalized),n!==p.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(r===-1&&(r=p.gpuType),r!==p.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=p.count*t}const o=new e(s),c=new dn(o,t,n);let d=0;for(let h=0;h<i.length;++h){const p=i[h];if(p.isInterleavedBufferAttribute){const a=d/t;for(let l=0,u=p.count;l<u;l++)for(let E=0;E<t;E++){const m=p.getComponent(l,E);c.setComponent(l+a,E,m)}}else o.set(p.array,d);d+=p.count*t}return r!==void 0&&(c.gpuType=r),c}const Mm={A:{horizAdvX:1325,d:"M1108 0l-162 435h-573l-160 -435h-213l558 1468h210l555 -1468h-215zM889 613l-154 431q-7 22 -21.5 66t-29 91t-23.5 78q-10 -41 -23 -86.5t-25.5 -85t-20.5 -63.5l-156 -431h453z"},B:{horizAdvX:1336,d:"M196 1462h424q279 0 420 -82t141 -281q0 -85 -31 -152t-90 -111t-145 -60v-10q90 -15 160 -54t110.5 -110.5t40.5 -183.5q0 -134 -63 -227.5t-178.5 -142t-274.5 -48.5h-514v1462zM401 847h255q177 0 245 58t68 169q0 115 -81 165.5t-257 50.5h-230v-443zM401 678v-505 h279q181 0 255.5 71t74.5 191q0 76 -33.5 130.5t-108.5 83.5t-202 29h-265z"},C:{horizAdvX:1294,d:"M820 1306q-113 0 -202.5 -39.5t-151.5 -115t-95 -181.5t-33 -239q0 -177 52.5 -306t158.5 -199t267 -70q96 0 183.5 17.5t174.5 45.5v-176q-84 -32 -173.5 -47.5t-209.5 -15.5q-224 0 -372.5 93t-221.5 261.5t-73 397.5q0 166 46 303.5t135 238t218.5 155t298.5 54.5 q110 0 214.5 -23.5t192.5 -65.5l-76 -171q-73 33 -156.5 58t-176.5 25z"},D:{horizAdvX:1494,d:"M1370 745q0 -247 -91 -412.5t-263.5 -249t-418.5 -83.5h-401v1462h446q224 0 387 -81.5t252 -241t89 -394.5zM1155 739q0 188 -61 310t-179 181.5t-289 59.5h-225v-1116h189q283 0 424 142t141 423z"},E:{horizAdvX:1140,d:"M1017 0h-821v1462h821v-176h-616v-435h579v-174h-579v-500h616v-177z"},F:{horizAdvX:1074,d:"M400 0h-204v1462h820v-176h-616v-496h578v-175h-578v-615z"},G:{horizAdvX:1488,d:"M804 780h528v-721q-115 -39 -237 -59t-274 -20q-226 0 -381 90t-235.5 258t-80.5 404q0 227 89 396t259 262t410 93q120 0 230.5 -23t203.5 -64l-74 -173q-78 35 -172.5 59.5t-195.5 24.5q-168 0 -288.5 -71t-185 -200t-64.5 -306q0 -173 54 -302t169 -201t296 -72 q91 0 155.5 10t118.5 24v412h-325v179z"},H:{horizAdvX:1524,d:"M1327 0h-205v675h-721v-675h-205v1462h205v-610h721v610h205v-1462z"},I:{horizAdvX:599,d:"M196 0v1462h205v-1462h-205z"},J:{horizAdvX:582,d:"M0 -396q-53 0 -93 7t-68 18v173q32 -9 69 -15t79 -6q56 0 102 22t73 76t27 150v1433h206v-1423q0 -149 -48.5 -245.5t-137.5 -143t-209 -46.5z"},K:{horizAdvX:1281,d:"M1281 0h-239l-491 687l-150 -128v-559h-205v1462h205v-714q51 60 103.5 119t104.5 119l419 476h235l-564 -637z"},L:{horizAdvX:1091,d:"M196 0v1462h205v-1284h635v-178h-840z"},M:{horizAdvX:1864,d:"M833 0l-456 1257h-8q3 -41 6.5 -105.5t6 -140t2.5 -148.5v-863h-188v1462h295l433 -1191h7l444 1191h293v-1462h-198v875q0 66 2 137.5t5.5 136t6.5 106.5h-9l-467 -1255h-175z"},N:{horizAdvX:1573,d:"M1378 0h-246l-757 1198h-8q3 -54 7 -118.5t6.5 -135t3.5 -142.5v-802h-188v1462h244l754 -1192h7q-2 44 -5 109t-5.5 137.5t-2.5 137.5v808h190v-1462z"},O:{horizAdvX:1602,d:"M1479 733q0 -169 -43 -307.5t-127.5 -238t-211 -153.5t-295.5 -54q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5t152 -200t261.5 -70.5q161 0 263 70.5 t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},P:{horizAdvX:1246,d:"M599 1462q283 0 413.5 -113t130.5 -321q0 -94 -30 -178.5t-97.5 -149t-177.5 -102t-270 -37.5h-167v-561h-205v1462h403zM583 1290h-182v-556h145q127 0 213 28.5t130 91.5t44 166q0 136 -85 203t-265 67z"},Q:{horizAdvX:1602,d:"M1479 733q0 -176 -46.5 -319t-139 -243.5t-230.5 -149.5l346 -369h-282l-279 330q-12 0 -23 -1t-23 -1q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5 t152 -200t261.5 -70.5q161 0 263 70.5t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},R:{horizAdvX:1286,d:"M599 1462q185 0 305.5 -45.5t179.5 -138t59 -234.5q0 -112 -41 -189t-107.5 -126t-142.5 -77l409 -652h-235l-356 598h-269v-598h-205v1462h403zM586 1288h-185v-519h199q173 0 253 67.5t80 199.5q0 137 -85 194.5t-262 57.5z"},S:{horizAdvX:1124,d:"M1031 393q0 -130 -64.5 -222.5t-181.5 -141.5t-278 -49q-81 0 -154.5 8.5t-136.5 24.5t-114 40v194q83 -34 192 -63.5t225 -29.5q101 0 169.5 27.5t103.5 77.5t35 120t-34 117.5t-107.5 87.5t-192.5 85q-83 30 -151 68.5t-117.5 88.5t-76.5 117.5t-27 155.5 q0 121 59.5 207t166.5 131.5t248 45.5q116 0 216.5 -23t191.5 -63l-65 -170q-85 35 -171 57t-178 22q-85 0 -143.5 -25t-89 -71t-30.5 -109q0 -71 32 -118t101 -85t180 -81q125 -48 212.5 -102t133.5 -130t46 -192z"},T:{horizAdvX:1143,d:"M674 0h-206v1285h-444v177h1093v-177h-443v-1285z"},U:{horizAdvX:1507,d:"M1323 1462v-946q0 -154 -63.5 -275t-191.5 -191t-322 -70q-275 0 -419.5 147.5t-144.5 392.5v942h206v-934q0 -185 92.5 -279t275.5 -94q126 0 206 45.5t118.5 129t38.5 198.5v934h204z"},V:{horizAdvX:1249,d:"M1249 1462l-518 -1462h-213l-518 1462h212l325 -940q18 -49 34 -103.5t30 -108.5t23 -99q9 45 22.5 99t30.5 109.5t34 105.5l324 937h214z"},W:{horizAdvX:1913,d:"M1891 1462l-386 -1462h-217l-267 930q-11 37 -22 80t-21.5 85.5t-17.5 76.5t-10 52q-2 -18 -8.5 -51.5t-15.5 -75.5t-20 -85.5t-22 -82.5l-261 -929h-216l-384 1462h209l223 -887q11 -44 21.5 -89.5t19.5 -91t16 -88t13 -80.5q5 39 13 83.5t17.5 90.5t20.5 91t23 86 l250 885h205l259 -890q12 -42 23.5 -88t21 -92t17 -88t13.5 -78q7 50 17.5 108t24.5 120t28 122l223 886h210z"},X:{horizAdvX:1229,d:"M1224 0h-234l-381 621l-386 -621h-218l486 760l-453 702h227l353 -569l352 569h219l-454 -704z"},Y:{horizAdvX:1178,d:"M590 762l368 700h220l-486 -894v-568h-205v559l-487 903h224z"},Z:{horizAdvX:1176,d:"M1104 0h-1033v146l765 1138h-740v178h988v-146l-766 -1138h786v-178z"}},ns=3e3,Jr=new Map;Ac("tile-glyph-geometries",Im);async function Im(){Jr.clear(),Jr.set(" ",{side:new gt,back:new gt});for(const[i,e]of Object.entries(Mm)){const t=Lm(ym(e.d,e.horizAdvX));Jr.set(i,t)}}function Nl(i){const e=i.toUpperCase();if(e!==" "&&!/^[A-Z]$/.test(e))return null;const t=Jr.get(e);if(!t)throw new Error(`Tile symbol geometry not preloaded for letter: ${e}`);return t}function Lm(i){const t=new ts().parse(i),n=[],r=[],s=new qn;s.moveTo(0,0),s.lineTo(24,0),s.lineTo(24,24),s.lineTo(0,24),s.closePath(),t.paths.forEach(E=>{ts.createShapes(E).forEach(S=>{const f=new to(S,{depth:.1*ns,bevelEnabled:!1}),{side:v,back:A}=bm(f);n.push(v),r.push(A),s.holes.push(new li(S.getPoints(12))),S.holes.forEach(R=>{const C=new qn(R.getPoints(12));new no(C).translate(0,0,2)})})});const o=Dl(n,"side"),c=Dl(r,"back"),d=fr/ns;o.scale(d,-d,d),c.scale(d,-d,d),o.rotateX(Math.PI/2),c.rotateX(Math.PI/2),o.computeBoundingBox();const h=o.boundingBox;if(!h)throw new Error("Failed to compute symbol bounds");const p=new V;h.getCenter(p);const a=-p.x,l=-h.max.y,u=-p.z;return o.translate(a,l,u),c.translate(a,l,u),{side:o,back:c}}function ym(i,e){return`
<svg width="800px" height="800px" viewBox="0 0 ${ns} ${ns}" 
version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <title>font_fill</title>
    <g fill-rule="evenodd">
        <path d="
                ${i} ">
       /path>
    </g>
</svg>
`}function bm(i){const t=i.toNonIndexed().getAttribute("position"),n=[],r=[],s=new V,o=new V,c=new V,d=new V,h=new V,p=new V;let a=-1/0;for(let E=0;E<t.count;E+=1)a=Math.max(a,t.getZ(E));for(let E=0;E<t.count;E+=3){if(s.fromBufferAttribute(t,E),o.fromBufferAttribute(t,E+1),c.fromBufferAttribute(t,E+2),d.subVectors(o,s),h.subVectors(c,s),p.crossVectors(d,h).normalize(),!(Math.abs(p.z)>.9)){n.push(s.x,s.y,s.z,o.x,o.y,o.z,c.x,c.y,c.z);continue}const S=(s.z+o.z+c.z)/3;Math.abs(S-a)<=.001&&r.push(s.x,s.y,s.z,o.x,o.y,o.z,c.x,c.y,c.z)}const l=new gt;l.setAttribute("position",new xt(n,3)),l.computeVertexNormals();const u=new gt;return u.setAttribute("position",new xt(r,3)),u.computeVertexNormals(),{side:l,back:u}}function Dl(i,e){const t=vm(i);if(!t)throw new Error(`Failed to merge ${e} SVG geometries`);return t}const et=fr,Ct=pm;function Wi(i,e,t,n,r,s){const o=i.length/3;i.push(...t,...n,...r,...s),e.push(o,o+1,o+2,o,o+2,o+3)}function Lc(i,e){const t=new gt;return t.setAttribute("position",new xt(i,3)),t.setIndex(e),t.computeVertexNormals(),t}const yc=[],bc=[],Yi=[],zi=[];Wi(yc,bc,[0,Ct,0],[et,Ct,0],[et,Ct,et],[0,Ct,et]);Wi(Yi,zi,[et,0,0],[0,0,0],[0,Ct,0],[et,Ct,0]);Wi(Yi,zi,[0,0,et],[et,0,et],[et,Ct,et],[0,Ct,et]);Wi(Yi,zi,[0,0,0],[0,0,et],[0,Ct,et],[0,Ct,0]);Wi(Yi,zi,[et,0,et],[et,0,0],[et,Ct,0],[et,Ct,et]);Wi(Yi,zi,[0,0,0],[et,0,0],[et,0,et],[0,0,et]);const Om=Lc(yc,bc),Cm=Lc(Yi,zi),Ks=.08,Oc=new di(et+Ks*2,Ct+Ks*2,et+Ks*2);Oc.translate(et/2,Ct/2,et/2);const rr=class rr{constructor(e){ye(this,"group");ye(this,"pickableMesh");ye(this,"_symbolSideMesh");ye(this,"_symbolBackMesh");ye(this,"_isVisible",!1);ye(this,"animOffset",0);this.glyph=e;const t=new Qt({color:11184810,side:It,depthTest:!1,depthWrite:!1}),n=new Qt({color:0,depthTest:!1,depthWrite:!1}),r=new Qt({color:0,depthTest:!1,depthWrite:!1,side:Kt}),s=new Qt({color:5592405,depthTest:!1,depthWrite:!1,side:Kt}),o=new Mt(Om,t);o.renderOrder=10;const c=new Mt(Cm,n);c.renderOrder=9;const d=Nl(e),h=new Mt(d.side,r);h.renderOrder=11;const p=new Mt(d.back,s);p.renderOrder=12;const a=new zn;a.add(p,h),a.position.set(et/2,Ct+1e-4,et/2);const l=new Qt({color:16777215,depthTest:!1,depthWrite:!1,visible:!1}),u=new Mt(Oc,l);u.userData.glyph=e,u.renderOrder=8;const E=new zn;E.add(o,c,a,u),E.position.set(-et/2,0,-et/2);const m=!1;for(const S of[o,c,a])S.visible=m;this.group=E,this._symbolSideMesh=h,this._symbolBackMesh=p,this.pickableMesh=u,this.pickableMesh.userData["scrabble-tile"]=this}randomizeLetter(){const e=rr._LETTERS[Math.floor(Math.random()*rr._LETTERS.length)],t=Nl(e);if(!t)return;this._symbolSideMesh.geometry=t.side,this._symbolBackMesh.geometry=t.back;const n=e!==" ";for(const r of this.group.children)r.visible=n;this.pickableMesh.visible=!1}get isVisible(){return this._isVisible}set isVisible(e){this._isVisible=e;for(const t of this.group.children)t.visible=e}toggle(){this._isVisible?this.hide():this.show()}hide(){this.isVisible=!1}show(){this.isVisible=!0}set anim(e){e+=this.animOffset;const t=-.3;e=t+e*(1-2*t),e=Math.max(0,Math.min(1,e));const n=(1-e)*30;this.group.position.y=n+.18}};ye(rr,"_LETTERS","ABCDEFGHIJKLMNOPQRSTUVWXYZ");let is=rr;const Wr=Math.PI*2;function kt(i){const e=Math.sin(i*127.1+311.7)*43758.5453123;return e-Math.floor(e)}function Pl(i,e,t){return Math.max(e,Math.min(t,i))}const bi=class bi{constructor(){ye(this,"_seeds",[]);ye(this,"_timeMs",0);ye(this,"_blend",1)}update(e,t,n){if(this._ensureMaskSeeds(n),this._timeMs+=e,t){this._blend=Math.min(1,this._blend+e/bi._BLEND_IN_DURATION);return}this._blend=Math.max(0,this._blend-e/bi._BLEND_OUT_DURATION)}getBlend(){return this._blend}getMaskPose(e,t,n,r,s){const o=this._seeds[e];if(!o||t<=0||n<=0)return{x:0,y:0,angle:0};const c=this._timeMs*1e-4,d=o.anchorXNorm*t+Math.sin(c*o.freqX+o.phaseX)*o.ampXNorm*t+Math.sin(c*o.driftFreq+o.driftPhase)*.03*t,h=o.anchorYNorm*n+Math.cos(c*o.freqY+o.phaseY)*o.ampYNorm*n+Math.cos(c*(o.driftFreq*.73)+o.driftPhase)*.025*n,p=r*.5,a=s*.5,l=8,u=Pl(d,p+l,t-p-l),E=Pl(h,a+l,n-a-l),m=Math.sin(c*o.spinFreq+o.spinPhase)*o.spinAmpRad;return{x:u-p,y:E-a,angle:m}}_ensureMaskSeeds(e){for(let t=this._seeds.length;t<e;t+=1)this._seeds.push(this._buildSeed(t))}_buildSeed(e){const t=(e+1)*17*Math.random();return{anchorXNorm:.2+kt(t+1)*.6,anchorYNorm:.2+kt(t+2)*.6,ampXNorm:.05+kt(t+3)*.1,ampYNorm:.04+kt(t+4)*.09,freqX:.45+kt(t+5)*.95,freqY:.4+kt(t+6)*.85,phaseX:kt(t+7)*Wr,phaseY:kt(t+8)*Wr,driftFreq:.15+kt(t+9)*.35,driftPhase:kt(t+10)*Wr,spinFreq:.55+kt(t+11)*.8,spinPhase:kt(t+12)*Wr,spinAmpRad:.18+kt(t+13)*.36}}};ye(bi,"_BLEND_IN_DURATION",350),ye(bi,"_BLEND_OUT_DURATION",2e3);let Ga=bi;const qe=class qe{constructor(){ye(this,"gameState","loading");ye(this,"_appGfx");ye(this,"_canvas");ye(this,"_renderer");ye(this,"_scene");ye(this,"_frontScene",new Vo);ye(this,"_boardGroup");ye(this,"_trayGroup");ye(this,"_scrabbleTiles",[]);ye(this,"_pickableMeshes",[]);ye(this,"_raycaster",new hc);ye(this,"_pointer",new oe);ye(this,"_hoveredPickable",null);ye(this,"_camera");ye(this,"_controls");ye(this,"_renderPixelScale",1);ye(this,"_regionMasks",[]);ye(this,"_animVec",new V);ye(this,"_trayVisibilityBounds",new Vi(qe._TRAY_VISIBILITY_BOX_MIN.clone(),qe._TRAY_VISIBILITY_BOX_MAX.clone()));ye(this,"_trayCorner",new V);ye(this,"_cameraOffset",new V);ye(this,"_trayBoundsDebugMesh");ye(this,"_focusTargetPos",new V);ye(this,"_titleScreenDance",new Ga);ye(this,"_animT",0);ye(this,"_camT",0);ye(this,"_tileT",0);ye(this,"_focusTimeMs",0);ye(this,"_focusedTile",null);ye(this,"_returningTiles",[]);ye(this,"_returnWorldPos",new V);ye(this,"_returnWorldQuat",new Nn);ye(this,"_parentWorldQuat",new Nn);ye(this,"dt",0);ye(this,"_didFinishEntrance",!1);const e=document.getElementById("app-canvas");if(!e)throw new Error("Missing #app-canvas");this._canvas=e,this._renderer=new HS({canvas:e,antialias:!1}),this._renderer.autoClear=!1,this._renderer.setSize(window.innerWidth,window.innerHeight),this._renderer.shadowMap.enabled=!1,this._canvas.style.imageRendering="crisp-edges",this._canvas.style.imageRendering="pixelated",this._scene=new Vo;const t=dm();this._scene.background=new tt(t[0]),this._camera=new jt(60,window.innerWidth/window.innerHeight,.1,1e6),this._camera.position.copy(qe._CAM_START),this._camera.lookAt(0,0,0),this._controls=new qS(this._camera,this._canvas),this._controls.enableDamping=!0,this._controls.dampingFactor=.08,this._controls.maxPolarAngle=Math.PI*.48,this._controls.target.set(0,0,0),this._controls.enabled=!1,this._appGfx=new fm(this),this._appGfx.onResize(),this._boardGroup=Sm(),this._trayGroup=_m(),this._trayGroup.position.set(0,.5,3),this._trayGroup.rotateX(.4);const n=new V().subVectors(qe._TRAY_VISIBILITY_BOX_MAX,qe._TRAY_VISIBILITY_BOX_MIN),r=new V().addVectors(qe._TRAY_VISIBILITY_BOX_MIN,qe._TRAY_VISIBILITY_BOX_MAX).multiplyScalar(.5);this._trayBoundsDebugMesh=new Mt(new di(n.x,n.y,n.z),new Qt({color:3388927,transparent:!0,opacity:.18,depthWrite:!1,visible:!1})),this._trayBoundsDebugMesh.position.copy(r);const s=KS();for(let o=0;o<Tc;o++){const c=new is(s[o]??" ");c.animOffset=o*.1,this._scrabbleTiles.push(c);const d=gm(o);c.group.position.copy(d),this._trayGroup.add(c.group),this._pickableMeshes.push(c.pickableMesh)}for(let o=0;o<5;o++)for(let c=0;c<5;c++){const d=s[o*5+c]??" ",h=new is(d);h.animOffset=(o+c)*.1,this._scrabbleTiles.push(h);const p=mm(o,c);h.group.position.copy(p),this._boardGroup.add(h.group),this._pickableMeshes.push(h.pickableMesh)}}mouseDown(){if(this.gameState==="title-screen"){this.gameState="playing";return}if(this._hoveredPickable){const e=this._hoveredPickable.userData["scrabble-tile"];e&&this._focusTile(e)}else this._queueReturnFocusedTile()}_focusTile(e){var s;if(((s=this._focusedTile)==null?void 0:s.tile)===e){this._queueReturnFocusedTile();return}this._queueReturnFocusedTile();const t=this._returningTiles.findIndex(o=>o.tile===e),n=t>=0?this._returningTiles[t]:null;t>=0&&this._returningTiles.splice(t,1);const r=(n==null?void 0:n.parent)??e.group.parent;r&&(this._focusedTile={tile:e,parent:r,position:((n==null?void 0:n.position)??e.group.position).clone(),quaternion:((n==null?void 0:n.quaternion)??e.group.quaternion).clone(),scale:((n==null?void 0:n.scale)??e.group.scale).clone()},this._scene.attach(e.group),this._focusTimeMs=0)}_queueReturnFocusedTile(){if(!this._focusedTile)return;const e=this._focusedTile;e.parent.updateMatrixWorld(!0),this._returnWorldPos.copy(e.position),e.parent.localToWorld(this._returnWorldPos),e.parent.getWorldQuaternion(this._parentWorldQuat),this._returnWorldQuat.multiplyQuaternions(this._parentWorldQuat,e.quaternion),this._returningTiles.push({tile:e.tile,parent:e.parent,position:e.position,quaternion:e.quaternion,scale:e.scale,worldPos:this._returnWorldPos.clone(),worldQuat:this._returnWorldQuat.clone()}),this._focusedTile=null}_updateFocusedTile(e){if(this._focusedTile){this._focusTimeMs+=e;const t=Math.sin(this._focusTimeMs*qe._FOCUS_OSC_SPEED)*qe._FOCUS_OSC_AMP;this._focusTargetPos.copy(qe._FOCUS_POS),this._focusTargetPos.y+=t,this._focusedTile.tile.group.position.lerp(this._focusTargetPos,qe._FOCUS_LERP_ALPHA)}for(let t=this._returningTiles.length-1;t>=0;t-=1){const n=this._returningTiles[t];n.tile.group.position.lerp(n.worldPos,qe._FOCUS_LERP_ALPHA),n.tile.group.quaternion.slerp(n.worldQuat,qe._FOCUS_LERP_ALPHA);const r=n.tile.group.position.distanceToSquared(n.worldPos)<1e-4,s=Math.abs(n.tile.group.quaternion.dot(n.worldQuat))>.999;!r||!s||(n.parent.attach(n.tile.group),n.tile.group.position.copy(n.position),n.tile.group.quaternion.copy(n.quaternion),n.tile.group.scale.copy(n.scale),this._returningTiles.splice(t,1))}}mouseMove(e,t){if(document.documentElement.style.cursor="default",!this._didFinishEntrance)return;let n=null;if(e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.intersectObjects(this._pickableMeshes,!1);r.length>0&&(n=r[0].object)}if(n&&n.userData.glyph===" "){this._hoveredPickable&&(this._hoveredPickable.material.visible=!1),this._hoveredPickable=null;return}n&&(document.documentElement.style.cursor="pointer"),n!==this._hoveredPickable&&(this._hoveredPickable&&(this._hoveredPickable.material.visible=!1),this._hoveredPickable=n,n&&(n.material.visible=!0))}async init(){this._scene.add(this._boardGroup),this._scene.add(this._trayGroup),this._scene.add(this._trayBoundsDebugMesh),this.gameState="title-screen",bl(this),new Tm(this).wireUiInput()}onResize(){this._appGfx.onResize(),this._animT<1&&(this._boardGroup.visible=!0,this._trayGroup.visible=!0,bl(this),this._animT=0)}cycleRenderPixelScale(){this.setRenderPixelScale(this._renderPixelScale%6+1)}getRenderPixelScale(){return this._renderPixelScale}setRenderPixelScale(e){this._renderPixelScale!==e&&(this._renderPixelScale=e,this._appGfx.onResize())}static _logistic(e,t=10){const n=1/(1+Math.exp(t*.5)),r=1/(1+Math.exp(-t*.5));return(1/(1+Math.exp(-t*(e-.5)))-n)/(r-n)}_isTrayFullyVisible(){if(this._trayVisibilityBounds.isEmpty())return!0;const{min:e,max:t}=this._trayVisibilityBounds,n=qe._TRAY_VISIBILITY_NDC_LIMIT;for(const r of[e.x,t.x])for(const s of[e.y,t.y])for(const o of[e.z,t.z])if(this._trayCorner.set(r,s,o).project(this._camera),!Number.isFinite(this._trayCorner.x)||!Number.isFinite(this._trayCorner.y)||!Number.isFinite(this._trayCorner.z)||Math.abs(this._trayCorner.x)>n||Math.abs(this._trayCorner.y)>n||this._trayCorner.z<-1||this._trayCorner.z>1)return!1;return!0}_ensureTrayVisibility(e){if(this._camT<1||this._isTrayFullyVisible())return;this._cameraOffset.copy(this._camera.position).sub(this._controls.target);const t=this._cameraOffset.length();if(t===0||t>=qe._POST_ENTRANCE_MAX_CAMERA_DISTANCE)return;this._cameraOffset.divideScalar(t);const n=qe._POST_ENTRANCE_ZOOM_OUT_SPEED*e,r=qe._POST_ENTRANCE_MAX_CAMERA_DISTANCE-t;this._camera.position.addScaledVector(this._cameraOffset,Math.min(n,r))}update(e){this.dt=e;const t=this.gameState==="title-screen";if(this._titleScreenDance.update(e,t,this._regionMasks.length),t||(this._animT=Math.min(1,this._animT+e/qe._ANIM_DURATION)),this._animT>=1&&this._camT<1){this._camT=Math.min(1,this._camT+e/qe._CAM_DURATION);const u=qe._logistic(this._camT,10);this._camera.position.lerpVectors(qe._CAM_START,qe._CAM_END,u)}if(this._animT>=1&&this._camT>=1&&this._tileT<1){this._tileT=Math.min(1,this._tileT+e/qe._TILE_DURATION);for(const u of this._scrabbleTiles)u.glyph!==" "&&u.show(),u.anim=this._tileT}if(!this._didFinishEntrance&&this._tileT>=1){this._didFinishEntrance=!0;for(const u of this._scrabbleTiles)u.glyph!==" "&&u.show(),u.anim=1}this._updateFocusedTile(e),this._ensureTrayVisibility(e),this._controls.update();const n=this._animT===1;this._boardGroup.visible=n,this._trayGroup.visible=n,this._focusedTile&&this._frontScene.add(this._focusedTile.tile.group),this._renderer.render(this._scene,this._camera),this._focusedTile&&(this._renderer.render(this._frontScene,this._camera),this._scene.add(this._focusedTile.tile.group));const r=document.getElementById("overlay-canvas");(r.width!==window.innerWidth||r.height!==window.innerHeight)&&(r.width=window.innerWidth,r.height=window.innerHeight);const s=r.getContext("2d");if(s.clearRect(0,0,r.width,r.height),s.globalAlpha=1,this._animT===1)return;const o=r.width,c=r.height,d=qe._logistic(this._animT,5),h=(1-d)*qe._ANIM_MAX_ROTATION,p=Math.cos(h),a=Math.sin(h),l=this._titleScreenDance.getBlend();s.globalAlpha=1;for(let u=0;u<this._regionMasks.length;u+=1){const E=this._regionMasks[u];let m=E.x,S=E.y;if(E.worldPos){this._animVec.set(E.worldPos.x*p+E.worldPos.z*a,E.worldPos.y,-E.worldPos.x*a+E.worldPos.z*p).project(this._camera);const v=(this._animVec.x+1)/2*o,A=(1-this._animVec.y)/2*c;m=v-E.canvas.width/2+E.restOffsetX+E.restOffsetX1*(1-this._animT),S=A-E.canvas.height/2+E.restOffsetY+E.restOffsetY1*(1-this._animT)}let f=kr(E.restAngle,0,d);if(l>0){const v=this._titleScreenDance.getMaskPose(u,o,c,E.canvas.width,E.canvas.height);m=kr(m,v.x,l),S=kr(S,v.y,l),f=kr(f,v.angle,l)}s.save(),s.translate(m+E.canvas.width/2,S+E.canvas.height/2),s.rotate(f),s.drawImage(E.canvas,-E.canvas.width/2,-E.canvas.height/2),s.restore()}}};ye(qe,"_ANIM_MAX_ROTATION",Math.PI*.4),ye(qe,"_ANIM_DURATION",2e3),ye(qe,"_CAM_DURATION",2e3),ye(qe,"_TILE_DURATION",800),ye(qe,"_CAM_START",new V(3,.8,0).lerp(new V(-6,3,6),Math.random())),ye(qe,"_CAM_END",new V(0,8,4)),ye(qe,"_FOCUS_POS",new V(0,3.1,3)),ye(qe,"_FOCUS_LERP_ALPHA",.12),ye(qe,"_FOCUS_OSC_AMP",.07),ye(qe,"_FOCUS_OSC_SPEED",.006),ye(qe,"_POST_ENTRANCE_ZOOM_OUT_SPEED",.0055),ye(qe,"_POST_ENTRANCE_MAX_CAMERA_DISTANCE",30),ye(qe,"_TRAY_VISIBILITY_NDC_LIMIT",.98),ye(qe,"_TRAY_VISIBILITY_BOX_MIN",new V(-2.4,0,3)),ye(qe,"_TRAY_VISIBILITY_BOX_MAX",new V(2.4,1,4.5)),ye(qe,"_MASK_FILTER_COLORS",["#ff4466","#44ffaa","#4488ff","#ffcc00","#cc44ff"]);let Er=qe;async function Nm(){const i=document.getElementById("startup-loading-label"),e=document.getElementById("startup-loading-screen");await WS(s=>{i&&(i.innerHTML=`LOADING (${s}%)`)});const t=new Er;await t.init(),e==null||e.classList.add("hidden"),window.addEventListener("resize",()=>t.onResize());let n=performance.now();const r=()=>{requestAnimationFrame(r);const s=performance.now(),o=Math.min(30,s-n);n=s,t.update(o)};requestAnimationFrame(r)}Nm();
