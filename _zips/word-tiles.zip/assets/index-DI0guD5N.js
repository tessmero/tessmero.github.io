var Ru=Object.defineProperty;var vu=(n,e,t)=>e in n?Ru(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var fe=(n,e,t)=>vu(n,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();function Mu(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}function Iu(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}globalThis.__trackObject=Mu;globalThis.__trackArray=Iu;/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const po="181",Hi={ROTATE:0,DOLLY:1,PAN:2},Fi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Lu=0,Yo=1,yu=2,dc=1,Ou=2,yn=3,_n=0,Lt=1,on=2,Nn=0,Gi=1,Wo=2,zo=3,Ko=4,bu=5,ui=100,Cu=101,Du=102,Nu=103,Pu=104,Uu=200,wu=201,Fu=202,Bu=203,Aa=204,_a=205,Hu=206,Gu=207,Vu=208,ku=209,Yu=210,Wu=211,zu=212,Ku=213,Xu=214,xa=0,ga=1,Ta=2,ki=3,Ra=4,va=5,Ma=6,Ia=7,fc=0,qu=1,Zu=2,Jn=0,Ju=1,Qu=2,$u=3,ju=4,eh=5,th=6,nh=7,pc=300,Yi=301,Wi=302,La=303,ya=304,gr=306,Oa=1e3,Cn=1001,ba=1002,qt=1003,ih=1004,Cs=1005,en=1006,Dr=1007,di=1008,Un=1009,Ec=1010,mc=1011,As=1012,Eo=1013,pi=1014,Dn=1015,Zi=1016,mo=1017,So=1018,_s=1020,Sc=35902,Ac=35899,_c=1021,xc=1022,cn=1023,xs=1026,gs=1027,gc=1028,Ao=1029,_o=1030,xo=1031,go=1033,sr=33776,rr=33777,ar=33778,or=33779,Ca=35840,Da=35841,Na=35842,Pa=35843,Ua=36196,wa=37492,Fa=37496,Ba=37808,Ha=37809,Ga=37810,Va=37811,ka=37812,Ya=37813,Wa=37814,za=37815,Ka=37816,Xa=37817,qa=37818,Za=37819,Ja=37820,Qa=37821,$a=36492,ja=36494,eo=36495,to=36283,no=36284,io=36285,so=36286,sh=3200,rh=3201,ah=0,oh=1,qn="",Gt="srgb",zi="srgb-linear",hr="linear",st="srgb",xi=7680,Xo=519,lh=512,ch=513,uh=514,Tc=515,hh=516,dh=517,fh=518,ph=519,qo=35044,Zo="300 es",Sn=2e3,dr=2001;function Rc(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function fr(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function Eh(){const n=fr("canvas");return n.style.display="block",n}const Jo={};function Qo(...n){const e="THREE."+n.shift();console.log(e,...n)}function ze(...n){const e="THREE."+n.shift();console.warn(e,...n)}function ft(...n){const e="THREE."+n.shift();console.error(e,...n)}function Ts(...n){const e=n.join(" ");e in Jo||(Jo[e]=!0,ze(...n))}function mh(n,e,t){return new Promise(function(i,s){function r(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:s();break;case n.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:i()}}setTimeout(r,t)})}class mi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){const i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){const i=this._listeners;if(i===void 0)return;const s=i[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const i=t[e.type];if(i!==void 0){e.target=this;const s=i.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const yt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],lr=Math.PI/180,ro=180/Math.PI;function Ji(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(yt[n&255]+yt[n>>8&255]+yt[n>>16&255]+yt[n>>24&255]+"-"+yt[e&255]+yt[e>>8&255]+"-"+yt[e>>16&15|64]+yt[e>>24&255]+"-"+yt[t&63|128]+yt[t>>8&255]+"-"+yt[t>>16&255]+yt[t>>24&255]+yt[i&255]+yt[i>>8&255]+yt[i>>16&255]+yt[i>>24&255]).toLowerCase()}function Ze(n,e,t){return Math.max(e,Math.min(t,n))}function Sh(n,e){return(n%e+e)%e}function Nr(n,e,t){return(1-t)*n+t*e}function is(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function Bt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}const Ah={DEG2RAD:lr};class oe{constructor(e=0,t=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6],this.y=s[1]*t+s[4]*i+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*i-o*s+e.x,this.y=r*s+o*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class wn{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=s}static slerpFlat(e,t,i,s,r,o,c){let d=i[s+0],u=i[s+1],p=i[s+2],a=i[s+3],l=r[o+0],h=r[o+1],m=r[o+2],S=r[o+3];if(c<=0){e[t+0]=d,e[t+1]=u,e[t+2]=p,e[t+3]=a;return}if(c>=1){e[t+0]=l,e[t+1]=h,e[t+2]=m,e[t+3]=S;return}if(a!==S||d!==l||u!==h||p!==m){let E=d*l+u*h+p*m+a*S;E<0&&(l=-l,h=-h,m=-m,S=-S,E=-E);let f=1-c;if(E<.9995){const T=Math.acos(E),A=Math.sin(T);f=Math.sin(f*T)/A,c=Math.sin(c*T)/A,d=d*f+l*c,u=u*f+h*c,p=p*f+m*c,a=a*f+S*c}else{d=d*f+l*c,u=u*f+h*c,p=p*f+m*c,a=a*f+S*c;const T=1/Math.sqrt(d*d+u*u+p*p+a*a);d*=T,u*=T,p*=T,a*=T}}e[t]=d,e[t+1]=u,e[t+2]=p,e[t+3]=a}static multiplyQuaternionsFlat(e,t,i,s,r,o){const c=i[s],d=i[s+1],u=i[s+2],p=i[s+3],a=r[o],l=r[o+1],h=r[o+2],m=r[o+3];return e[t]=c*m+p*a+d*h-u*l,e[t+1]=d*m+p*l+u*a-c*h,e[t+2]=u*m+p*h+c*l-d*a,e[t+3]=p*m-c*a-d*l-u*h,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,s){return this._x=e,this._y=t,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,s=e._y,r=e._z,o=e._order,c=Math.cos,d=Math.sin,u=c(i/2),p=c(s/2),a=c(r/2),l=d(i/2),h=d(s/2),m=d(r/2);switch(o){case"XYZ":this._x=l*p*a+u*h*m,this._y=u*h*a-l*p*m,this._z=u*p*m+l*h*a,this._w=u*p*a-l*h*m;break;case"YXZ":this._x=l*p*a+u*h*m,this._y=u*h*a-l*p*m,this._z=u*p*m-l*h*a,this._w=u*p*a+l*h*m;break;case"ZXY":this._x=l*p*a-u*h*m,this._y=u*h*a+l*p*m,this._z=u*p*m+l*h*a,this._w=u*p*a-l*h*m;break;case"ZYX":this._x=l*p*a-u*h*m,this._y=u*h*a+l*p*m,this._z=u*p*m-l*h*a,this._w=u*p*a+l*h*m;break;case"YZX":this._x=l*p*a+u*h*m,this._y=u*h*a+l*p*m,this._z=u*p*m-l*h*a,this._w=u*p*a-l*h*m;break;case"XZY":this._x=l*p*a-u*h*m,this._y=u*h*a-l*p*m,this._z=u*p*m+l*h*a,this._w=u*p*a+l*h*m;break;default:ze("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,s=Math.sin(i);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],s=t[4],r=t[8],o=t[1],c=t[5],d=t[9],u=t[2],p=t[6],a=t[10],l=i+c+a;if(l>0){const h=.5/Math.sqrt(l+1);this._w=.25/h,this._x=(p-d)*h,this._y=(r-u)*h,this._z=(o-s)*h}else if(i>c&&i>a){const h=2*Math.sqrt(1+i-c-a);this._w=(p-d)/h,this._x=.25*h,this._y=(s+o)/h,this._z=(r+u)/h}else if(c>a){const h=2*Math.sqrt(1+c-i-a);this._w=(r-u)/h,this._x=(s+o)/h,this._y=.25*h,this._z=(d+p)/h}else{const h=2*Math.sqrt(1+a-i-c);this._w=(o-s)/h,this._x=(r+u)/h,this._y=(d+p)/h,this._z=.25*h}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ze(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const s=Math.min(1,t/i);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,s=e._y,r=e._z,o=e._w,c=t._x,d=t._y,u=t._z,p=t._w;return this._x=i*p+o*c+s*u-r*d,this._y=s*p+o*d+r*c-i*u,this._z=r*p+o*u+i*d-s*c,this._w=o*p-i*c-s*d-r*u,this._onChangeCallback(),this}slerp(e,t){if(t<=0)return this;if(t>=1)return this.copy(e);let i=e._x,s=e._y,r=e._z,o=e._w,c=this.dot(e);c<0&&(i=-i,s=-s,r=-r,o=-o,c=-c);let d=1-t;if(c<.9995){const u=Math.acos(c),p=Math.sin(u);d=Math.sin(d*u)/p,t=Math.sin(t*u)/p,this._x=this._x*d+i*t,this._y=this._y*d+s*t,this._z=this._z*d+r*t,this._w=this._w*d+o*t,this._onChangeCallback()}else this._x=this._x*d+i*t,this._y=this._y*d+s*t,this._z=this._z*d+r*t,this._w=this._w*d+o*t,this.normalize();return this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class G{constructor(e=0,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),G.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion($o.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion($o.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6]*s,this.y=r[1]*t+r[4]*i+r[7]*s,this.z=r[2]*t+r[5]*i+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*i+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*i+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*i+r[10]*s+r[14])*o,this}applyQuaternion(e){const t=this.x,i=this.y,s=this.z,r=e.x,o=e.y,c=e.z,d=e.w,u=2*(o*s-c*i),p=2*(c*t-r*s),a=2*(r*i-o*t);return this.x=t+d*u+o*a-c*p,this.y=i+d*p+c*u-r*a,this.z=s+d*a+r*p-o*u,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*i+r[8]*s,this.y=r[1]*t+r[5]*i+r[9]*s,this.z=r[2]*t+r[6]*i+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,s=e.y,r=e.z,o=t.x,c=t.y,d=t.z;return this.x=s*d-r*c,this.y=r*o-i*d,this.z=i*c-s*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Pr.copy(this).projectOnVector(e),this.sub(Pr)}reflect(e){return this.sub(Pr.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,s=this.z-e.z;return t*t+i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const s=Math.sin(t)*e;return this.x=s*Math.sin(i),this.y=Math.cos(t)*e,this.z=s*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Pr=new G,$o=new wn;class Ye{constructor(e,t,i,s,r,o,c,d,u){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),Ye.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,o,c,d,u)}set(e,t,i,s,r,o,c,d,u){const p=this.elements;return p[0]=e,p[1]=s,p[2]=c,p[3]=t,p[4]=r,p[5]=d,p[6]=i,p[7]=o,p[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,o=i[0],c=i[3],d=i[6],u=i[1],p=i[4],a=i[7],l=i[2],h=i[5],m=i[8],S=s[0],E=s[3],f=s[6],T=s[1],A=s[4],I=s[7],D=s[2],O=s[5],C=s[8];return r[0]=o*S+c*T+d*D,r[3]=o*E+c*A+d*O,r[6]=o*f+c*I+d*C,r[1]=u*S+p*T+a*D,r[4]=u*E+p*A+a*O,r[7]=u*f+p*I+a*C,r[2]=l*S+h*T+m*D,r[5]=l*E+h*A+m*O,r[8]=l*f+h*I+m*C,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],d=e[6],u=e[7],p=e[8];return t*o*p-t*c*u-i*r*p+i*c*d+s*r*u-s*o*d}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],d=e[6],u=e[7],p=e[8],a=p*o-c*u,l=c*d-p*r,h=u*r-o*d,m=t*a+i*l+s*h;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);const S=1/m;return e[0]=a*S,e[1]=(s*u-p*i)*S,e[2]=(c*i-s*o)*S,e[3]=l*S,e[4]=(p*t-s*d)*S,e[5]=(s*r-c*t)*S,e[6]=h*S,e[7]=(i*d-u*t)*S,e[8]=(o*t-i*r)*S,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,s,r,o,c){const d=Math.cos(r),u=Math.sin(r);return this.set(i*d,i*u,-i*(d*o+u*c)+o+e,-s*u,s*d,-s*(-u*o+d*c)+c+t,0,0,1),this}scale(e,t){return this.premultiply(Ur.makeScale(e,t)),this}rotate(e){return this.premultiply(Ur.makeRotation(-e)),this}translate(e,t){return this.premultiply(Ur.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<9;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Ur=new Ye,jo=new Ye().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),el=new Ye().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function _h(){const n={enabled:!0,workingColorSpace:zi,spaces:{},convert:function(s,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===st&&(s.r=Pn(s.r),s.g=Pn(s.g),s.b=Pn(s.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===st&&(s.r=Vi(s.r),s.g=Vi(s.g),s.b=Vi(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===qn?hr:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return Ts("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),n.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return Ts("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),n.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],i=[.3127,.329];return n.define({[zi]:{primaries:e,whitePoint:i,transfer:hr,toXYZ:jo,fromXYZ:el,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Gt},outputColorSpaceConfig:{drawingBufferColorSpace:Gt}},[Gt]:{primaries:e,whitePoint:i,transfer:st,toXYZ:jo,fromXYZ:el,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Gt}}}),n}const je=_h();function Pn(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Vi(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let gi;class xh{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{gi===void 0&&(gi=fr("canvas")),gi.width=e.width,gi.height=e.height;const s=gi.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),i=gi}return i.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=fr("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const s=i.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Pn(r[o]/255)*255;return i.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Pn(t[i]/255)*255):t[i]=Pn(t[i]);return{data:t,width:e.width,height:e.height}}else return ze("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let gh=0;class To{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:gh++}),this.uuid=Ji(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,c=s.length;o<c;o++)s[o].isDataTexture?r.push(wr(s[o].image)):r.push(wr(s[o]))}else r=wr(s);i.url=r}return t||(e.images[this.uuid]=i),i}}function wr(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?xh.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(ze("Texture: Unable to serialize Texture."),{})}let Th=0;const Fr=new G;class Pt extends mi{constructor(e=Pt.DEFAULT_IMAGE,t=Pt.DEFAULT_MAPPING,i=Cn,s=Cn,r=en,o=di,c=cn,d=Un,u=Pt.DEFAULT_ANISOTROPY,p=qn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Th++}),this.uuid=Ji(),this.name="",this.source=new To(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=u,this.format=c,this.internalFormat=null,this.type=d,this.offset=new oe(0,0),this.repeat=new oe(1,1),this.center=new oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Ye,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=p,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Fr).x}get height(){return this.source.getSize(Fr).y}get depth(){return this.source.getSize(Fr).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const i=e[t];if(i===void 0){ze(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){ze(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&i&&s.isVector2&&i.isVector2||s&&i&&s.isVector3&&i.isVector3||s&&i&&s.isMatrix3&&i.isMatrix3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==pc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Oa:e.x=e.x-Math.floor(e.x);break;case Cn:e.x=e.x<0?0:1;break;case ba:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Oa:e.y=e.y-Math.floor(e.y);break;case Cn:e.y=e.y<0?0:1;break;case ba:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Pt.DEFAULT_IMAGE=null;Pt.DEFAULT_MAPPING=pc;Pt.DEFAULT_ANISOTROPY=1;class St{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),St.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,s){return this.x=e,this.y=t,this.z=i,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*i+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*i+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*i+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*i+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,s,r;const d=e.elements,u=d[0],p=d[4],a=d[8],l=d[1],h=d[5],m=d[9],S=d[2],E=d[6],f=d[10];if(Math.abs(p-l)<.01&&Math.abs(a-S)<.01&&Math.abs(m-E)<.01){if(Math.abs(p+l)<.1&&Math.abs(a+S)<.1&&Math.abs(m+E)<.1&&Math.abs(u+h+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const A=(u+1)/2,I=(h+1)/2,D=(f+1)/2,O=(p+l)/4,C=(a+S)/4,U=(m+E)/4;return A>I&&A>D?A<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(A),s=O/i,r=C/i):I>D?I<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(I),i=O/s,r=U/s):D<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(D),i=C/r,s=U/r),this.set(i,s,r,t),this}let T=Math.sqrt((E-m)*(E-m)+(a-S)*(a-S)+(l-p)*(l-p));return Math.abs(T)<.001&&(T=1),this.x=(E-m)/T,this.y=(a-S)/T,this.z=(l-p)/T,this.w=Math.acos((u+h+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this.w=Ze(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this.w=Ze(this.w,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Rh extends mi{constructor(e=1,t=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:en,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},i),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=i.depth,this.scissor=new St(0,0,e,t),this.scissorTest=!1,this.viewport=new St(0,0,e,t);const s={width:e,height:t,depth:i.depth},r=new Pt(s);this.textures=[];const o=i.count;for(let c=0;c<o;c++)this.textures[c]=r.clone(),this.textures[c].isRenderTargetTexture=!0,this.textures[c].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview}_setTextureOptions(e={}){const t={minFilter:en,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=i,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,i=e.textures.length;t<i;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new To(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ei extends Rh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class vc extends Pt{constructor(e=null,t=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=qt,this.minFilter=qt,this.wrapR=Cn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class vh extends Pt{constructor(e=null,t=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=qt,this.minFilter=qt,this.wrapR=Cn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Qi{constructor(e=new G(1/0,1/0,1/0),t=new G(-1/0,-1/0,-1/0)){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(sn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(sn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=sn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const r=i.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,c=r.count;o<c;o++)e.isMesh===!0?e.getVertexPosition(o,sn):sn.fromBufferAttribute(r,o),sn.applyMatrix4(e.matrixWorld),this.expandByPoint(sn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Ds.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Ds.copy(i.boundingBox)),Ds.applyMatrix4(e.matrixWorld),this.union(Ds)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,sn),sn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ss),Ns.subVectors(this.max,ss),Ti.subVectors(e.a,ss),Ri.subVectors(e.b,ss),vi.subVectors(e.c,ss),Gn.subVectors(Ri,Ti),Vn.subVectors(vi,Ri),ii.subVectors(Ti,vi);let t=[0,-Gn.z,Gn.y,0,-Vn.z,Vn.y,0,-ii.z,ii.y,Gn.z,0,-Gn.x,Vn.z,0,-Vn.x,ii.z,0,-ii.x,-Gn.y,Gn.x,0,-Vn.y,Vn.x,0,-ii.y,ii.x,0];return!Br(t,Ti,Ri,vi,Ns)||(t=[1,0,0,0,1,0,0,0,1],!Br(t,Ti,Ri,vi,Ns))?!1:(Ps.crossVectors(Gn,Vn),t=[Ps.x,Ps.y,Ps.z],Br(t,Ti,Ri,vi,Ns))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,sn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(sn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(gn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),gn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),gn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),gn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),gn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),gn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),gn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),gn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(gn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const gn=[new G,new G,new G,new G,new G,new G,new G,new G],sn=new G,Ds=new Qi,Ti=new G,Ri=new G,vi=new G,Gn=new G,Vn=new G,ii=new G,ss=new G,Ns=new G,Ps=new G,si=new G;function Br(n,e,t,i,s){for(let r=0,o=n.length-3;r<=o;r+=3){si.fromArray(n,r);const c=s.x*Math.abs(si.x)+s.y*Math.abs(si.y)+s.z*Math.abs(si.z),d=e.dot(si),u=t.dot(si),p=i.dot(si);if(Math.max(-Math.max(d,u,p),Math.min(d,u,p))>c)return!1}return!0}const Mh=new Qi,rs=new G,Hr=new G;class Ro{constructor(e=new G,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Mh.setFromPoints(e).getCenter(i);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;rs.subVectors(e,this.center);const t=rs.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),s=(i-this.radius)*.5;this.center.addScaledVector(rs,s/i),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Hr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(rs.copy(e.center).add(Hr)),this.expandByPoint(rs.copy(e.center).sub(Hr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const Tn=new G,Gr=new G,Us=new G,kn=new G,Vr=new G,ws=new G,kr=new G;class vo{constructor(e=new G,t=new G(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Tn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Tn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Tn.copy(this.origin).addScaledVector(this.direction,t),Tn.distanceToSquared(e))}distanceSqToSegment(e,t,i,s){Gr.copy(e).add(t).multiplyScalar(.5),Us.copy(t).sub(e).normalize(),kn.copy(this.origin).sub(Gr);const r=e.distanceTo(t)*.5,o=-this.direction.dot(Us),c=kn.dot(this.direction),d=-kn.dot(Us),u=kn.lengthSq(),p=Math.abs(1-o*o);let a,l,h,m;if(p>0)if(a=o*d-c,l=o*c-d,m=r*p,a>=0)if(l>=-m)if(l<=m){const S=1/p;a*=S,l*=S,h=a*(a+o*l+2*c)+l*(o*a+l+2*d)+u}else l=r,a=Math.max(0,-(o*l+c)),h=-a*a+l*(l+2*d)+u;else l=-r,a=Math.max(0,-(o*l+c)),h=-a*a+l*(l+2*d)+u;else l<=-m?(a=Math.max(0,-(-o*r+c)),l=a>0?-r:Math.min(Math.max(-r,-d),r),h=-a*a+l*(l+2*d)+u):l<=m?(a=0,l=Math.min(Math.max(-r,-d),r),h=l*(l+2*d)+u):(a=Math.max(0,-(o*r+c)),l=a>0?r:Math.min(Math.max(-r,-d),r),h=-a*a+l*(l+2*d)+u);else l=o>0?-r:r,a=Math.max(0,-(o*l+c)),h=-a*a+l*(l+2*d)+u;return i&&i.copy(this.origin).addScaledVector(this.direction,a),s&&s.copy(Gr).addScaledVector(Us,l),h}intersectSphere(e,t){Tn.subVectors(e.center,this.origin);const i=Tn.dot(this.direction),s=Tn.dot(Tn)-i*i,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),c=i-o,d=i+o;return d<0?null:c<0?this.at(d,t):this.at(c,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,s,r,o,c,d;const u=1/this.direction.x,p=1/this.direction.y,a=1/this.direction.z,l=this.origin;return u>=0?(i=(e.min.x-l.x)*u,s=(e.max.x-l.x)*u):(i=(e.max.x-l.x)*u,s=(e.min.x-l.x)*u),p>=0?(r=(e.min.y-l.y)*p,o=(e.max.y-l.y)*p):(r=(e.max.y-l.y)*p,o=(e.min.y-l.y)*p),i>o||r>s||((r>i||isNaN(i))&&(i=r),(o<s||isNaN(s))&&(s=o),a>=0?(c=(e.min.z-l.z)*a,d=(e.max.z-l.z)*a):(c=(e.max.z-l.z)*a,d=(e.min.z-l.z)*a),i>d||c>s)||((c>i||i!==i)&&(i=c),(d<s||s!==s)&&(s=d),s<0)?null:this.at(i>=0?i:s,t)}intersectsBox(e){return this.intersectBox(e,Tn)!==null}intersectTriangle(e,t,i,s,r){Vr.subVectors(t,e),ws.subVectors(i,e),kr.crossVectors(Vr,ws);let o=this.direction.dot(kr),c;if(o>0){if(s)return null;c=1}else if(o<0)c=-1,o=-o;else return null;kn.subVectors(this.origin,e);const d=c*this.direction.dot(ws.crossVectors(kn,ws));if(d<0)return null;const u=c*this.direction.dot(Vr.cross(kn));if(u<0||d+u>o)return null;const p=-c*kn.dot(kr);return p<0?null:this.at(p/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class _t{constructor(e,t,i,s,r,o,c,d,u,p,a,l,h,m,S,E){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),_t.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,o,c,d,u,p,a,l,h,m,S,E)}set(e,t,i,s,r,o,c,d,u,p,a,l,h,m,S,E){const f=this.elements;return f[0]=e,f[4]=t,f[8]=i,f[12]=s,f[1]=r,f[5]=o,f[9]=c,f[13]=d,f[2]=u,f[6]=p,f[10]=a,f[14]=l,f[3]=h,f[7]=m,f[11]=S,f[15]=E,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new _t().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,s=1/Mi.setFromMatrixColumn(e,0).length(),r=1/Mi.setFromMatrixColumn(e,1).length(),o=1/Mi.setFromMatrixColumn(e,2).length();return t[0]=i[0]*s,t[1]=i[1]*s,t[2]=i[2]*s,t[3]=0,t[4]=i[4]*r,t[5]=i[5]*r,t[6]=i[6]*r,t[7]=0,t[8]=i[8]*o,t[9]=i[9]*o,t[10]=i[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,s=e.y,r=e.z,o=Math.cos(i),c=Math.sin(i),d=Math.cos(s),u=Math.sin(s),p=Math.cos(r),a=Math.sin(r);if(e.order==="XYZ"){const l=o*p,h=o*a,m=c*p,S=c*a;t[0]=d*p,t[4]=-d*a,t[8]=u,t[1]=h+m*u,t[5]=l-S*u,t[9]=-c*d,t[2]=S-l*u,t[6]=m+h*u,t[10]=o*d}else if(e.order==="YXZ"){const l=d*p,h=d*a,m=u*p,S=u*a;t[0]=l+S*c,t[4]=m*c-h,t[8]=o*u,t[1]=o*a,t[5]=o*p,t[9]=-c,t[2]=h*c-m,t[6]=S+l*c,t[10]=o*d}else if(e.order==="ZXY"){const l=d*p,h=d*a,m=u*p,S=u*a;t[0]=l-S*c,t[4]=-o*a,t[8]=m+h*c,t[1]=h+m*c,t[5]=o*p,t[9]=S-l*c,t[2]=-o*u,t[6]=c,t[10]=o*d}else if(e.order==="ZYX"){const l=o*p,h=o*a,m=c*p,S=c*a;t[0]=d*p,t[4]=m*u-h,t[8]=l*u+S,t[1]=d*a,t[5]=S*u+l,t[9]=h*u-m,t[2]=-u,t[6]=c*d,t[10]=o*d}else if(e.order==="YZX"){const l=o*d,h=o*u,m=c*d,S=c*u;t[0]=d*p,t[4]=S-l*a,t[8]=m*a+h,t[1]=a,t[5]=o*p,t[9]=-c*p,t[2]=-u*p,t[6]=h*a+m,t[10]=l-S*a}else if(e.order==="XZY"){const l=o*d,h=o*u,m=c*d,S=c*u;t[0]=d*p,t[4]=-a,t[8]=u*p,t[1]=l*a+S,t[5]=o*p,t[9]=h*a-m,t[2]=m*a-h,t[6]=c*p,t[10]=S*a+l}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Ih,e,Lh)}lookAt(e,t,i){const s=this.elements;return Yt.subVectors(e,t),Yt.lengthSq()===0&&(Yt.z=1),Yt.normalize(),Yn.crossVectors(i,Yt),Yn.lengthSq()===0&&(Math.abs(i.z)===1?Yt.x+=1e-4:Yt.z+=1e-4,Yt.normalize(),Yn.crossVectors(i,Yt)),Yn.normalize(),Fs.crossVectors(Yt,Yn),s[0]=Yn.x,s[4]=Fs.x,s[8]=Yt.x,s[1]=Yn.y,s[5]=Fs.y,s[9]=Yt.y,s[2]=Yn.z,s[6]=Fs.z,s[10]=Yt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,o=i[0],c=i[4],d=i[8],u=i[12],p=i[1],a=i[5],l=i[9],h=i[13],m=i[2],S=i[6],E=i[10],f=i[14],T=i[3],A=i[7],I=i[11],D=i[15],O=s[0],C=s[4],U=s[8],v=s[12],R=s[1],P=s[5],V=s[9],Z=s[13],J=s[2],$=s[6],ie=s[10],j=s[14],B=s[3],pe=s[7],Ee=s[11],Le=s[15];return r[0]=o*O+c*R+d*J+u*B,r[4]=o*C+c*P+d*$+u*pe,r[8]=o*U+c*V+d*ie+u*Ee,r[12]=o*v+c*Z+d*j+u*Le,r[1]=p*O+a*R+l*J+h*B,r[5]=p*C+a*P+l*$+h*pe,r[9]=p*U+a*V+l*ie+h*Ee,r[13]=p*v+a*Z+l*j+h*Le,r[2]=m*O+S*R+E*J+f*B,r[6]=m*C+S*P+E*$+f*pe,r[10]=m*U+S*V+E*ie+f*Ee,r[14]=m*v+S*Z+E*j+f*Le,r[3]=T*O+A*R+I*J+D*B,r[7]=T*C+A*P+I*$+D*pe,r[11]=T*U+A*V+I*ie+D*Ee,r[15]=T*v+A*Z+I*j+D*Le,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],s=e[8],r=e[12],o=e[1],c=e[5],d=e[9],u=e[13],p=e[2],a=e[6],l=e[10],h=e[14],m=e[3],S=e[7],E=e[11],f=e[15];return m*(+r*d*a-s*u*a-r*c*l+i*u*l+s*c*h-i*d*h)+S*(+t*d*h-t*u*l+r*o*l-s*o*h+s*u*p-r*d*p)+E*(+t*u*a-t*c*h-r*o*a+i*o*h+r*c*p-i*u*p)+f*(-s*c*p-t*d*a+t*c*l+s*o*a-i*o*l+i*d*p)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],d=e[6],u=e[7],p=e[8],a=e[9],l=e[10],h=e[11],m=e[12],S=e[13],E=e[14],f=e[15],T=a*E*u-S*l*u+S*d*h-c*E*h-a*d*f+c*l*f,A=m*l*u-p*E*u-m*d*h+o*E*h+p*d*f-o*l*f,I=p*S*u-m*a*u+m*c*h-o*S*h-p*c*f+o*a*f,D=m*a*d-p*S*d-m*c*l+o*S*l+p*c*E-o*a*E,O=t*T+i*A+s*I+r*D;if(O===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/O;return e[0]=T*C,e[1]=(S*l*r-a*E*r-S*s*h+i*E*h+a*s*f-i*l*f)*C,e[2]=(c*E*r-S*d*r+S*s*u-i*E*u-c*s*f+i*d*f)*C,e[3]=(a*d*r-c*l*r-a*s*u+i*l*u+c*s*h-i*d*h)*C,e[4]=A*C,e[5]=(p*E*r-m*l*r+m*s*h-t*E*h-p*s*f+t*l*f)*C,e[6]=(m*d*r-o*E*r-m*s*u+t*E*u+o*s*f-t*d*f)*C,e[7]=(o*l*r-p*d*r+p*s*u-t*l*u-o*s*h+t*d*h)*C,e[8]=I*C,e[9]=(m*a*r-p*S*r-m*i*h+t*S*h+p*i*f-t*a*f)*C,e[10]=(o*S*r-m*c*r+m*i*u-t*S*u-o*i*f+t*c*f)*C,e[11]=(p*c*r-o*a*r-p*i*u+t*a*u+o*i*h-t*c*h)*C,e[12]=D*C,e[13]=(p*S*s-m*a*s+m*i*l-t*S*l-p*i*E+t*a*E)*C,e[14]=(m*c*s-o*S*s-m*i*d+t*S*d+o*i*E-t*c*E)*C,e[15]=(o*a*s-p*c*s+p*i*d-t*a*d-o*i*l+t*c*l)*C,this}scale(e){const t=this.elements,i=e.x,s=e.y,r=e.z;return t[0]*=i,t[4]*=s,t[8]*=r,t[1]*=i,t[5]*=s,t[9]*=r,t[2]*=i,t[6]*=s,t[10]*=r,t[3]*=i,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,s))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),s=Math.sin(t),r=1-i,o=e.x,c=e.y,d=e.z,u=r*o,p=r*c;return this.set(u*o+i,u*c-s*d,u*d+s*c,0,u*c+s*d,p*c+i,p*d-s*o,0,u*d-s*c,p*d+s*o,r*d*d+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,s,r,o){return this.set(1,i,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,i){const s=this.elements,r=t._x,o=t._y,c=t._z,d=t._w,u=r+r,p=o+o,a=c+c,l=r*u,h=r*p,m=r*a,S=o*p,E=o*a,f=c*a,T=d*u,A=d*p,I=d*a,D=i.x,O=i.y,C=i.z;return s[0]=(1-(S+f))*D,s[1]=(h+I)*D,s[2]=(m-A)*D,s[3]=0,s[4]=(h-I)*O,s[5]=(1-(l+f))*O,s[6]=(E+T)*O,s[7]=0,s[8]=(m+A)*C,s[9]=(E-T)*C,s[10]=(1-(l+S))*C,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,i){const s=this.elements;let r=Mi.set(s[0],s[1],s[2]).length();const o=Mi.set(s[4],s[5],s[6]).length(),c=Mi.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],rn.copy(this);const u=1/r,p=1/o,a=1/c;return rn.elements[0]*=u,rn.elements[1]*=u,rn.elements[2]*=u,rn.elements[4]*=p,rn.elements[5]*=p,rn.elements[6]*=p,rn.elements[8]*=a,rn.elements[9]*=a,rn.elements[10]*=a,t.setFromRotationMatrix(rn),i.x=r,i.y=o,i.z=c,this}makePerspective(e,t,i,s,r,o,c=Sn,d=!1){const u=this.elements,p=2*r/(t-e),a=2*r/(i-s),l=(t+e)/(t-e),h=(i+s)/(i-s);let m,S;if(d)m=r/(o-r),S=o*r/(o-r);else if(c===Sn)m=-(o+r)/(o-r),S=-2*o*r/(o-r);else if(c===dr)m=-o/(o-r),S=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+c);return u[0]=p,u[4]=0,u[8]=l,u[12]=0,u[1]=0,u[5]=a,u[9]=h,u[13]=0,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=-1,u[15]=0,this}makeOrthographic(e,t,i,s,r,o,c=Sn,d=!1){const u=this.elements,p=2/(t-e),a=2/(i-s),l=-(t+e)/(t-e),h=-(i+s)/(i-s);let m,S;if(d)m=1/(o-r),S=o/(o-r);else if(c===Sn)m=-2/(o-r),S=-(o+r)/(o-r);else if(c===dr)m=-1/(o-r),S=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+c);return u[0]=p,u[4]=0,u[8]=0,u[12]=l,u[1]=0,u[5]=a,u[9]=0,u[13]=h,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=0,u[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<16;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const Mi=new G,rn=new _t,Ih=new G(0,0,0),Lh=new G(1,1,1),Yn=new G,Fs=new G,Yt=new G,tl=new _t,nl=new wn;class Fn{constructor(e=0,t=0,i=0,s=Fn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,s=this._order){return this._x=e,this._y=t,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const s=e.elements,r=s[0],o=s[4],c=s[8],d=s[1],u=s[5],p=s[9],a=s[2],l=s[6],h=s[10];switch(t){case"XYZ":this._y=Math.asin(Ze(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-p,h),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(l,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Ze(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(c,h),this._z=Math.atan2(d,u)):(this._y=Math.atan2(-a,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ze(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(-a,h),this._z=Math.atan2(-o,u)):(this._y=0,this._z=Math.atan2(d,r));break;case"ZYX":this._y=Math.asin(-Ze(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(l,h),this._z=Math.atan2(d,r)):(this._x=0,this._z=Math.atan2(-o,u));break;case"YZX":this._z=Math.asin(Ze(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-p,u),this._y=Math.atan2(-a,r)):(this._x=0,this._y=Math.atan2(c,h));break;case"XZY":this._z=Math.asin(-Ze(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(l,u),this._y=Math.atan2(c,r)):(this._x=Math.atan2(-p,h),this._y=0);break;default:ze("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return tl.makeRotationFromQuaternion(e),this.setFromRotationMatrix(tl,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return nl.setFromEuler(this),this.setFromQuaternion(nl,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Fn.DEFAULT_ORDER="XYZ";class Mo{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let yh=0;const il=new G,Ii=new wn,Rn=new _t,Bs=new G,as=new G,Oh=new G,bh=new wn,sl=new G(1,0,0),rl=new G(0,1,0),al=new G(0,0,1),ol={type:"added"},Ch={type:"removed"},Li={type:"childadded",child:null},Yr={type:"childremoved",child:null};class Zt extends mi{constructor(){super(),this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isObject3D=!0,Object.defineProperty(this,"id",{value:yh++}),this.uuid=Ji(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Zt.DEFAULT_UP.clone();const e=new G,t=new Fn,i=new wn,s=new G(1,1,1);function r(){i.setFromEuler(t,!1)}function o(){t.setFromQuaternion(i,void 0,!1)}t._onChange(r),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new _t},normalMatrix:{value:new Ye}}),this.matrix=new _t,this.matrixWorld=new _t,this.matrixAutoUpdate=Zt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Zt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Mo,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ii.setFromAxisAngle(e,t),this.quaternion.multiply(Ii),this}rotateOnWorldAxis(e,t){return Ii.setFromAxisAngle(e,t),this.quaternion.premultiply(Ii),this}rotateX(e){return this.rotateOnAxis(sl,e)}rotateY(e){return this.rotateOnAxis(rl,e)}rotateZ(e){return this.rotateOnAxis(al,e)}translateOnAxis(e,t){return il.copy(e).applyQuaternion(this.quaternion),this.position.add(il.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(sl,e)}translateY(e){return this.translateOnAxis(rl,e)}translateZ(e){return this.translateOnAxis(al,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Rn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Bs.copy(e):Bs.set(e,t,i);const s=this.parent;this.updateWorldMatrix(!0,!1),as.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Rn.lookAt(as,Bs,this.up):Rn.lookAt(Bs,as,this.up),this.quaternion.setFromRotationMatrix(Rn),s&&(Rn.extractRotation(s.matrixWorld),Ii.setFromRotationMatrix(Rn),this.quaternion.premultiply(Ii.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(ft("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(ol),Li.child=e,this.dispatchEvent(Li),Li.child=null):ft("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Ch),Yr.child=e,this.dispatchEvent(Yr),Yr.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Rn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Rn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Rn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(ol),Li.child=e,this.dispatchEvent(Li),Li.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,s=this.children.length;i<s;i++){const o=this.children[i].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(as,e,Oh),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(as,bh,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(c=>({...c,boundingBox:c.boundingBox?c.boundingBox.toJSON():void 0,boundingSphere:c.boundingSphere?c.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(c=>({...c})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(c,d){return c[d.uuid]===void 0&&(c[d.uuid]=d.toJSON(e)),d.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const c=this.geometry.parameters;if(c!==void 0&&c.shapes!==void 0){const d=c.shapes;if(Array.isArray(d))for(let u=0,p=d.length;u<p;u++){const a=d[u];r(e.shapes,a)}else r(e.shapes,d)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const c=[];for(let d=0,u=this.material.length;d<u;d++)c.push(r(e.materials,this.material[d]));s.material=c}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let c=0;c<this.children.length;c++)s.children.push(this.children[c].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let c=0;c<this.animations.length;c++){const d=this.animations[c];s.animations.push(r(e.animations,d))}}if(t){const c=o(e.geometries),d=o(e.materials),u=o(e.textures),p=o(e.images),a=o(e.shapes),l=o(e.skeletons),h=o(e.animations),m=o(e.nodes);c.length>0&&(i.geometries=c),d.length>0&&(i.materials=d),u.length>0&&(i.textures=u),p.length>0&&(i.images=p),a.length>0&&(i.shapes=a),l.length>0&&(i.skeletons=l),h.length>0&&(i.animations=h),m.length>0&&(i.nodes=m)}return i.object=s,i;function o(c){const d=[];for(const u in c){const p=c[u];delete p.metadata,d.push(p)}return d}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const s=e.children[i];this.add(s.clone())}return this}}Zt.DEFAULT_UP=new G(0,1,0);Zt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Zt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const an=new G,vn=new G,Wr=new G,Mn=new G,yi=new G,Oi=new G,ll=new G,zr=new G,Kr=new G,Xr=new G,qr=new St,Zr=new St,Jr=new St;class ln{constructor(e=new G,t=new G,i=new G){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,s){s.subVectors(i,t),an.subVectors(e,t),s.cross(an);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,i,s,r){an.subVectors(s,t),vn.subVectors(i,t),Wr.subVectors(e,t);const o=an.dot(an),c=an.dot(vn),d=an.dot(Wr),u=vn.dot(vn),p=vn.dot(Wr),a=o*u-c*c;if(a===0)return r.set(0,0,0),null;const l=1/a,h=(u*d-c*p)*l,m=(o*p-c*d)*l;return r.set(1-h-m,m,h)}static containsPoint(e,t,i,s){return this.getBarycoord(e,t,i,s,Mn)===null?!1:Mn.x>=0&&Mn.y>=0&&Mn.x+Mn.y<=1}static getInterpolation(e,t,i,s,r,o,c,d){return this.getBarycoord(e,t,i,s,Mn)===null?(d.x=0,d.y=0,"z"in d&&(d.z=0),"w"in d&&(d.w=0),null):(d.setScalar(0),d.addScaledVector(r,Mn.x),d.addScaledVector(o,Mn.y),d.addScaledVector(c,Mn.z),d)}static getInterpolatedAttribute(e,t,i,s,r,o){return qr.setScalar(0),Zr.setScalar(0),Jr.setScalar(0),qr.fromBufferAttribute(e,t),Zr.fromBufferAttribute(e,i),Jr.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(qr,r.x),o.addScaledVector(Zr,r.y),o.addScaledVector(Jr,r.z),o}static isFrontFacing(e,t,i,s){return an.subVectors(i,t),vn.subVectors(e,t),an.cross(vn).dot(s)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,s){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,i,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return an.subVectors(this.c,this.b),vn.subVectors(this.a,this.b),an.cross(vn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return ln.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return ln.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,s,r){return ln.getInterpolation(e,this.a,this.b,this.c,t,i,s,r)}containsPoint(e){return ln.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return ln.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,s=this.b,r=this.c;let o,c;yi.subVectors(s,i),Oi.subVectors(r,i),zr.subVectors(e,i);const d=yi.dot(zr),u=Oi.dot(zr);if(d<=0&&u<=0)return t.copy(i);Kr.subVectors(e,s);const p=yi.dot(Kr),a=Oi.dot(Kr);if(p>=0&&a<=p)return t.copy(s);const l=d*a-p*u;if(l<=0&&d>=0&&p<=0)return o=d/(d-p),t.copy(i).addScaledVector(yi,o);Xr.subVectors(e,r);const h=yi.dot(Xr),m=Oi.dot(Xr);if(m>=0&&h<=m)return t.copy(r);const S=h*u-d*m;if(S<=0&&u>=0&&m<=0)return c=u/(u-m),t.copy(i).addScaledVector(Oi,c);const E=p*m-h*a;if(E<=0&&a-p>=0&&h-m>=0)return ll.subVectors(r,s),c=(a-p)/(a-p+(h-m)),t.copy(s).addScaledVector(ll,c);const f=1/(E+S+l);return o=S*f,c=l*f,t.copy(i).addScaledVector(yi,o).addScaledVector(Oi,c)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Mc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Wn={h:0,s:0,l:0},Hs={h:0,s:0,l:0};function Qr(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Qe{constructor(e,t,i){return this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Gt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,je.colorSpaceToWorking(this,t),this}setRGB(e,t,i,s=je.workingColorSpace){return this.r=e,this.g=t,this.b=i,je.colorSpaceToWorking(this,s),this}setHSL(e,t,i,s=je.workingColorSpace){if(e=Sh(e,1),t=Ze(t,0,1),i=Ze(i,0,1),t===0)this.r=this.g=this.b=i;else{const r=i<=.5?i*(1+t):i+t-i*t,o=2*i-r;this.r=Qr(o,r,e+1/3),this.g=Qr(o,r,e),this.b=Qr(o,r,e-1/3)}return je.colorSpaceToWorking(this,s),this}setStyle(e,t=Gt){function i(r){r!==void 0&&parseFloat(r)<1&&ze("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],c=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:ze("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);ze("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Gt){const i=Mc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):ze("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Pn(e.r),this.g=Pn(e.g),this.b=Pn(e.b),this}copyLinearToSRGB(e){return this.r=Vi(e.r),this.g=Vi(e.g),this.b=Vi(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Gt){return je.workingToColorSpace(Ot.copy(this),e),Math.round(Ze(Ot.r*255,0,255))*65536+Math.round(Ze(Ot.g*255,0,255))*256+Math.round(Ze(Ot.b*255,0,255))}getHexString(e=Gt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=je.workingColorSpace){je.workingToColorSpace(Ot.copy(this),t);const i=Ot.r,s=Ot.g,r=Ot.b,o=Math.max(i,s,r),c=Math.min(i,s,r);let d,u;const p=(c+o)/2;if(c===o)d=0,u=0;else{const a=o-c;switch(u=p<=.5?a/(o+c):a/(2-o-c),o){case i:d=(s-r)/a+(s<r?6:0);break;case s:d=(r-i)/a+2;break;case r:d=(i-s)/a+4;break}d/=6}return e.h=d,e.s=u,e.l=p,e}getRGB(e,t=je.workingColorSpace){return je.workingToColorSpace(Ot.copy(this),t),e.r=Ot.r,e.g=Ot.g,e.b=Ot.b,e}getStyle(e=Gt){je.workingToColorSpace(Ot.copy(this),e);const t=Ot.r,i=Ot.g,s=Ot.b;return e!==Gt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(e,t,i){return this.getHSL(Wn),this.setHSL(Wn.h+e,Wn.s+t,Wn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Wn),e.getHSL(Hs);const i=Nr(Wn.h,Hs.h,t),s=Nr(Wn.s,Hs.s,t),r=Nr(Wn.l,Hs.l,t);return this.setHSL(i,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*i+r[6]*s,this.g=r[1]*t+r[4]*i+r[7]*s,this.b=r[2]*t+r[5]*i+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ot=new Qe;Qe.NAMES=Mc;let Dh=0;class Tr extends mi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Dh++}),this.uuid=Ji(),this.name="",this.type="Material",this.blending=Gi,this.side=_n,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Aa,this.blendDst=_a,this.blendEquation=ui,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Qe(0,0,0),this.blendAlpha=0,this.depthFunc=ki,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Xo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=xi,this.stencilZFail=xi,this.stencilZPass=xi,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){ze(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){ze(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Gi&&(i.blending=this.blending),this.side!==_n&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Aa&&(i.blendSrc=this.blendSrc),this.blendDst!==_a&&(i.blendDst=this.blendDst),this.blendEquation!==ui&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==ki&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Xo&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==xi&&(i.stencilFail=this.stencilFail),this.stencilZFail!==xi&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==xi&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){const o=[];for(const c in r){const d=r[c];delete d.metadata,o.push(d)}return o}if(t){const r=s(e.textures),o=s(e.images);r.length>0&&(i.textures=r),o.length>0&&(i.images=o)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const s=t.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=t[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ut extends Tr{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Fn,this.combine=fc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Tt=new G,Gs=new oe;let Nh=0;class hn{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Nh++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=qo,this.updateRanges=[],this.gpuType=Dn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[i+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Gs.fromBufferAttribute(this,t),Gs.applyMatrix3(e),this.setXY(t,Gs.x,Gs.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)Tt.fromBufferAttribute(this,t),Tt.applyMatrix3(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)Tt.fromBufferAttribute(this,t),Tt.applyMatrix4(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Tt.fromBufferAttribute(this,t),Tt.applyNormalMatrix(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Tt.fromBufferAttribute(this,t),Tt.transformDirection(e),this.setXYZ(t,Tt.x,Tt.y,Tt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=is(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Bt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=is(t,this.array)),t}setX(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=is(t,this.array)),t}setY(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=is(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=is(t,this.array)),t}setW(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,s){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this}setXYZW(e,t,i,s,r){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array),r=Bt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==qo&&(e.usage=this.usage),e}}class Ic extends hn{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class Lc extends hn{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class xt extends hn{constructor(e,t,i){super(new Float32Array(e),t,i)}}let Ph=0;const Qt=new _t,$r=new Zt,bi=new G,Wt=new Qi,os=new Qi,It=new G;class gt extends mi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Ph++}),this.uuid=Ji(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Rc(e)?Lc:Ic)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const r=new Ye().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Qt.makeRotationFromQuaternion(e),this.applyMatrix4(Qt),this}rotateX(e){return Qt.makeRotationX(e),this.applyMatrix4(Qt),this}rotateY(e){return Qt.makeRotationY(e),this.applyMatrix4(Qt),this}rotateZ(e){return Qt.makeRotationZ(e),this.applyMatrix4(Qt),this}translate(e,t,i){return Qt.makeTranslation(e,t,i),this.applyMatrix4(Qt),this}scale(e,t,i){return Qt.makeScale(e,t,i),this.applyMatrix4(Qt),this}lookAt(e){return $r.lookAt(e),$r.updateMatrix(),this.applyMatrix4($r.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(bi).negate(),this.translate(bi.x,bi.y,bi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const i=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new xt(i,3))}else{const i=Math.min(e.length,t.count);for(let s=0;s<i;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&ze("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Qi);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){ft("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new G(-1/0,-1/0,-1/0),new G(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,s=t.length;i<s;i++){const r=t[i];Wt.setFromBufferAttribute(r),this.morphTargetsRelative?(It.addVectors(this.boundingBox.min,Wt.min),this.boundingBox.expandByPoint(It),It.addVectors(this.boundingBox.max,Wt.max),this.boundingBox.expandByPoint(It)):(this.boundingBox.expandByPoint(Wt.min),this.boundingBox.expandByPoint(Wt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&ft('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ro);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){ft("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new G,1/0);return}if(e){const i=this.boundingSphere.center;if(Wt.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const c=t[r];os.setFromBufferAttribute(c),this.morphTargetsRelative?(It.addVectors(Wt.min,os.min),Wt.expandByPoint(It),It.addVectors(Wt.max,os.max),Wt.expandByPoint(It)):(Wt.expandByPoint(os.min),Wt.expandByPoint(os.max))}Wt.getCenter(i);let s=0;for(let r=0,o=e.count;r<o;r++)It.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(It));if(t)for(let r=0,o=t.length;r<o;r++){const c=t[r],d=this.morphTargetsRelative;for(let u=0,p=c.count;u<p;u++)It.fromBufferAttribute(c,u),d&&(bi.fromBufferAttribute(e,u),It.add(bi)),s=Math.max(s,i.distanceToSquared(It))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&ft('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){ft("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new hn(new Float32Array(4*i.count),4));const o=this.getAttribute("tangent"),c=[],d=[];for(let U=0;U<i.count;U++)c[U]=new G,d[U]=new G;const u=new G,p=new G,a=new G,l=new oe,h=new oe,m=new oe,S=new G,E=new G;function f(U,v,R){u.fromBufferAttribute(i,U),p.fromBufferAttribute(i,v),a.fromBufferAttribute(i,R),l.fromBufferAttribute(r,U),h.fromBufferAttribute(r,v),m.fromBufferAttribute(r,R),p.sub(u),a.sub(u),h.sub(l),m.sub(l);const P=1/(h.x*m.y-m.x*h.y);isFinite(P)&&(S.copy(p).multiplyScalar(m.y).addScaledVector(a,-h.y).multiplyScalar(P),E.copy(a).multiplyScalar(h.x).addScaledVector(p,-m.x).multiplyScalar(P),c[U].add(S),c[v].add(S),c[R].add(S),d[U].add(E),d[v].add(E),d[R].add(E))}let T=this.groups;T.length===0&&(T=[{start:0,count:e.count}]);for(let U=0,v=T.length;U<v;++U){const R=T[U],P=R.start,V=R.count;for(let Z=P,J=P+V;Z<J;Z+=3)f(e.getX(Z+0),e.getX(Z+1),e.getX(Z+2))}const A=new G,I=new G,D=new G,O=new G;function C(U){D.fromBufferAttribute(s,U),O.copy(D);const v=c[U];A.copy(v),A.sub(D.multiplyScalar(D.dot(v))).normalize(),I.crossVectors(O,v);const P=I.dot(d[U])<0?-1:1;o.setXYZW(U,A.x,A.y,A.z,P)}for(let U=0,v=T.length;U<v;++U){const R=T[U],P=R.start,V=R.count;for(let Z=P,J=P+V;Z<J;Z+=3)C(e.getX(Z+0)),C(e.getX(Z+1)),C(e.getX(Z+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new hn(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let l=0,h=i.count;l<h;l++)i.setXYZ(l,0,0,0);const s=new G,r=new G,o=new G,c=new G,d=new G,u=new G,p=new G,a=new G;if(e)for(let l=0,h=e.count;l<h;l+=3){const m=e.getX(l+0),S=e.getX(l+1),E=e.getX(l+2);s.fromBufferAttribute(t,m),r.fromBufferAttribute(t,S),o.fromBufferAttribute(t,E),p.subVectors(o,r),a.subVectors(s,r),p.cross(a),c.fromBufferAttribute(i,m),d.fromBufferAttribute(i,S),u.fromBufferAttribute(i,E),c.add(p),d.add(p),u.add(p),i.setXYZ(m,c.x,c.y,c.z),i.setXYZ(S,d.x,d.y,d.z),i.setXYZ(E,u.x,u.y,u.z)}else for(let l=0,h=t.count;l<h;l+=3)s.fromBufferAttribute(t,l+0),r.fromBufferAttribute(t,l+1),o.fromBufferAttribute(t,l+2),p.subVectors(o,r),a.subVectors(s,r),p.cross(a),i.setXYZ(l+0,p.x,p.y,p.z),i.setXYZ(l+1,p.x,p.y,p.z),i.setXYZ(l+2,p.x,p.y,p.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)It.fromBufferAttribute(e,t),It.normalize(),e.setXYZ(t,It.x,It.y,It.z)}toNonIndexed(){function e(c,d){const u=c.array,p=c.itemSize,a=c.normalized,l=new u.constructor(d.length*p);let h=0,m=0;for(let S=0,E=d.length;S<E;S++){c.isInterleavedBufferAttribute?h=d[S]*c.data.stride+c.offset:h=d[S]*p;for(let f=0;f<p;f++)l[m++]=u[h++]}return new hn(l,p,a)}if(this.index===null)return ze("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new gt,i=this.index.array,s=this.attributes;for(const c in s){const d=s[c],u=e(d,i);t.setAttribute(c,u)}const r=this.morphAttributes;for(const c in r){const d=[],u=r[c];for(let p=0,a=u.length;p<a;p++){const l=u[p],h=e(l,i);d.push(h)}t.morphAttributes[c]=d}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let c=0,d=o.length;c<d;c++){const u=o[c];t.addGroup(u.start,u.count,u.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const d=this.parameters;for(const u in d)d[u]!==void 0&&(e[u]=d[u]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const d in i){const u=i[d];e.data.attributes[d]=u.toJSON(e.data)}const s={};let r=!1;for(const d in this.morphAttributes){const u=this.morphAttributes[d],p=[];for(let a=0,l=u.length;a<l;a++){const h=u[a];p.push(h.toJSON(e.data))}p.length>0&&(s[d]=p,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const c=this.boundingSphere;return c!==null&&(e.data.boundingSphere=c.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone());const s=e.attributes;for(const u in s){const p=s[u];this.setAttribute(u,p.clone(t))}const r=e.morphAttributes;for(const u in r){const p=[],a=r[u];for(let l=0,h=a.length;l<h;l++)p.push(a[l].clone(t));this.morphAttributes[u]=p}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let u=0,p=o.length;u<p;u++){const a=o[u];this.addGroup(a.start,a.count,a.materialIndex)}const c=e.boundingBox;c!==null&&(this.boundingBox=c.clone());const d=e.boundingSphere;return d!==null&&(this.boundingSphere=d.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const cl=new _t,ri=new vo,Vs=new Ro,ul=new G,ks=new G,Ys=new G,Ws=new G,jr=new G,zs=new G,hl=new G,Ks=new G;class At extends Zt{constructor(e=new gt,t=new Ut){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const s=t[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const c=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[c]=r}}}}getVertexPosition(e,t){const i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,o=i.morphTargetsRelative;t.fromBufferAttribute(s,e);const c=this.morphTargetInfluences;if(r&&c){zs.set(0,0,0);for(let d=0,u=r.length;d<u;d++){const p=c[d],a=r[d];p!==0&&(jr.fromBufferAttribute(a,e),o?zs.addScaledVector(jr,p):zs.addScaledVector(jr.sub(t),p))}t.add(zs)}return t}raycast(e,t){const i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Vs.copy(i.boundingSphere),Vs.applyMatrix4(r),ri.copy(e.ray).recast(e.near),!(Vs.containsPoint(ri.origin)===!1&&(ri.intersectSphere(Vs,ul)===null||ri.origin.distanceToSquared(ul)>(e.far-e.near)**2))&&(cl.copy(r).invert(),ri.copy(e.ray).applyMatrix4(cl),!(i.boundingBox!==null&&ri.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,ri)))}_computeIntersections(e,t,i){let s;const r=this.geometry,o=this.material,c=r.index,d=r.attributes.position,u=r.attributes.uv,p=r.attributes.uv1,a=r.attributes.normal,l=r.groups,h=r.drawRange;if(c!==null)if(Array.isArray(o))for(let m=0,S=l.length;m<S;m++){const E=l[m],f=o[E.materialIndex],T=Math.max(E.start,h.start),A=Math.min(c.count,Math.min(E.start+E.count,h.start+h.count));for(let I=T,D=A;I<D;I+=3){const O=c.getX(I),C=c.getX(I+1),U=c.getX(I+2);s=Xs(this,f,e,i,u,p,a,O,C,U),s&&(s.faceIndex=Math.floor(I/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,h.start),S=Math.min(c.count,h.start+h.count);for(let E=m,f=S;E<f;E+=3){const T=c.getX(E),A=c.getX(E+1),I=c.getX(E+2);s=Xs(this,o,e,i,u,p,a,T,A,I),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}else if(d!==void 0)if(Array.isArray(o))for(let m=0,S=l.length;m<S;m++){const E=l[m],f=o[E.materialIndex],T=Math.max(E.start,h.start),A=Math.min(d.count,Math.min(E.start+E.count,h.start+h.count));for(let I=T,D=A;I<D;I+=3){const O=I,C=I+1,U=I+2;s=Xs(this,f,e,i,u,p,a,O,C,U),s&&(s.faceIndex=Math.floor(I/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,h.start),S=Math.min(d.count,h.start+h.count);for(let E=m,f=S;E<f;E+=3){const T=E,A=E+1,I=E+2;s=Xs(this,o,e,i,u,p,a,T,A,I),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}}}function Uh(n,e,t,i,s,r,o,c){let d;if(e.side===Lt?d=i.intersectTriangle(o,r,s,!0,c):d=i.intersectTriangle(s,r,o,e.side===_n,c),d===null)return null;Ks.copy(c),Ks.applyMatrix4(n.matrixWorld);const u=t.ray.origin.distanceTo(Ks);return u<t.near||u>t.far?null:{distance:u,point:Ks.clone(),object:n}}function Xs(n,e,t,i,s,r,o,c,d,u){n.getVertexPosition(c,ks),n.getVertexPosition(d,Ys),n.getVertexPosition(u,Ws);const p=Uh(n,e,t,i,ks,Ys,Ws,hl);if(p){const a=new G;ln.getBarycoord(hl,ks,Ys,Ws,a),s&&(p.uv=ln.getInterpolatedAttribute(s,c,d,u,a,new oe)),r&&(p.uv1=ln.getInterpolatedAttribute(r,c,d,u,a,new oe)),o&&(p.normal=ln.getInterpolatedAttribute(o,c,d,u,a,new G),p.normal.dot(i.direction)>0&&p.normal.multiplyScalar(-1));const l={a:c,b:d,c:u,normal:new G,materialIndex:0};ln.getNormal(ks,Ys,Ws,l.normal),p.face=l,p.barycoord=a}return p}class Si extends gt{constructor(e=1,t=1,i=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:s,heightSegments:r,depthSegments:o};const c=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const d=[],u=[],p=[],a=[];let l=0,h=0;m("z","y","x",-1,-1,i,t,e,o,r,0),m("z","y","x",1,-1,i,t,-e,o,r,1),m("x","z","y",1,1,e,i,t,s,o,2),m("x","z","y",1,-1,e,i,-t,s,o,3),m("x","y","z",1,-1,e,t,i,s,r,4),m("x","y","z",-1,-1,e,t,-i,s,r,5),this.setIndex(d),this.setAttribute("position",new xt(u,3)),this.setAttribute("normal",new xt(p,3)),this.setAttribute("uv",new xt(a,2));function m(S,E,f,T,A,I,D,O,C,U,v){const R=I/C,P=D/U,V=I/2,Z=D/2,J=O/2,$=C+1,ie=U+1;let j=0,B=0;const pe=new G;for(let Ee=0;Ee<ie;Ee++){const Le=Ee*P-Z;for(let Ve=0;Ve<$;Ve++){const Xe=Ve*R-V;pe[S]=Xe*T,pe[E]=Le*A,pe[f]=J,u.push(pe.x,pe.y,pe.z),pe[S]=0,pe[E]=0,pe[f]=O>0?1:-1,p.push(pe.x,pe.y,pe.z),a.push(Ve/C),a.push(1-Ee/U),j+=1}}for(let Ee=0;Ee<U;Ee++)for(let Le=0;Le<C;Le++){const Ve=l+Le+$*Ee,Xe=l+Le+$*(Ee+1),X=l+(Le+1)+$*(Ee+1),w=l+(Le+1)+$*Ee;d.push(Ve,Xe,w),d.push(Xe,X,w),B+=6}c.addGroup(h,B,v),h+=B,l+=j}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Si(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Ki(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const s=n[t][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(ze("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=s.clone():Array.isArray(s)?e[t][i]=s.slice():e[t][i]=s}}return e}function Ct(n){const e={};for(let t=0;t<n.length;t++){const i=Ki(n[t]);for(const s in i)e[s]=i[s]}return e}function wh(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function yc(n){const e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:je.workingColorSpace}const Fh={clone:Ki,merge:Ct};var Bh=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Hh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Bn extends Tr{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Bh,this.fragmentShader=Hh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ki(e.uniforms),this.uniformsGroups=wh(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class Oc extends Zt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _t,this.projectionMatrix=new _t,this.projectionMatrixInverse=new _t,this.coordinateSystem=Sn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const zn=new G,dl=new oe,fl=new oe;class Xt extends Oc{constructor(e=50,t=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=ro*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(lr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ro*2*Math.atan(Math.tan(lr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){zn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(zn.x,zn.y).multiplyScalar(-e/zn.z),zn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(zn.x,zn.y).multiplyScalar(-e/zn.z)}getViewSize(e,t){return this.getViewBounds(e,dl,fl),t.subVectors(fl,dl)}setViewOffset(e,t,i,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(lr*.5*this.fov)/this.zoom,i=2*t,s=this.aspect*i,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const d=o.fullWidth,u=o.fullHeight;r+=o.offsetX*s/d,t-=o.offsetY*i/u,s*=o.width/d,i*=o.height/u}const c=this.filmOffset;c!==0&&(r+=e*c/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Ci=-90,Di=1;class Gh extends Zt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Xt(Ci,Di,e,t);s.layers=this.layers,this.add(s);const r=new Xt(Ci,Di,e,t);r.layers=this.layers,this.add(r);const o=new Xt(Ci,Di,e,t);o.layers=this.layers,this.add(o);const c=new Xt(Ci,Di,e,t);c.layers=this.layers,this.add(c);const d=new Xt(Ci,Di,e,t);d.layers=this.layers,this.add(d);const u=new Xt(Ci,Di,e,t);u.layers=this.layers,this.add(u)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,s,r,o,c,d]=t;for(const u of t)this.remove(u);if(e===Sn)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),c.up.set(0,1,0),c.lookAt(0,0,1),d.up.set(0,1,0),d.lookAt(0,0,-1);else if(e===dr)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),c.up.set(0,-1,0),c.lookAt(0,0,1),d.up.set(0,-1,0),d.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const u of t)this.add(u),u.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,c,d,u,p]=this.children,a=e.getRenderTarget(),l=e.getActiveCubeFace(),h=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;const S=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,s),e.render(t,r),e.setRenderTarget(i,1,s),e.render(t,o),e.setRenderTarget(i,2,s),e.render(t,c),e.setRenderTarget(i,3,s),e.render(t,d),e.setRenderTarget(i,4,s),e.render(t,u),i.texture.generateMipmaps=S,e.setRenderTarget(i,5,s),e.render(t,p),e.setRenderTarget(a,l,h),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}}class bc extends Pt{constructor(e=[],t=Yi,i,s,r,o,c,d,u,p){super(e,t,i,s,r,o,c,d,u,p),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Vh extends ei{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},s=[i,i,i,i,i,i];this.texture=new bc(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Si(5,5,5),r=new Bn({name:"CubemapFromEquirect",uniforms:Ki(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Lt,blending:Nn});r.uniforms.tEquirect.value=t;const o=new At(s,r),c=t.minFilter;return t.minFilter===di&&(t.minFilter=en),new Gh(1,10,this).update(e,o),t.minFilter=c,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,i=!0,s=!0){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,i,s);e.setRenderTarget(r)}}class tn extends Zt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const kh={type:"move"};class ea{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new tn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new tn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new G,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new G),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new tn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new G,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new G),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let s=null,r=null,o=null;const c=this._targetRay,d=this._grip,u=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(u&&e.hand){o=!0;for(const S of e.hand.values()){const E=t.getJointPose(S,i),f=this._getHandJoint(u,S);E!==null&&(f.matrix.fromArray(E.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=E.radius),f.visible=E!==null}const p=u.joints["index-finger-tip"],a=u.joints["thumb-tip"],l=p.position.distanceTo(a.position),h=.02,m=.005;u.inputState.pinching&&l>h+m?(u.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!u.inputState.pinching&&l<=h-m&&(u.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else d!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,i),r!==null&&(d.matrix.fromArray(r.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,r.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(r.linearVelocity)):d.hasLinearVelocity=!1,r.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(r.angularVelocity)):d.hasAngularVelocity=!1));c!==null&&(s=t.getPose(e.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1,this.dispatchEvent(kh)))}return c!==null&&(c.visible=s!==null),d!==null&&(d.visible=r!==null),u!==null&&(u.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new tn;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class Yh extends Zt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Fn,this.environmentIntensity=1,this.environmentRotation=new Fn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class Wh extends Pt{constructor(e=null,t=1,i=1,s,r,o,c,d,u=qt,p=qt,a,l){super(null,o,c,d,u,p,s,r,a,l),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const ta=new G,zh=new G,Kh=new Ye;class On{constructor(e=new G(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,s){return this.normal.set(e,t,i),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const s=ta.subVectors(i,t).cross(zh.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(ta),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||Kh.getNormalMatrix(e),s=this.coplanarPoint(ta).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ai=new Ro,Xh=new oe(.5,.5),qs=new G;class Cc{constructor(e=new On,t=new On,i=new On,s=new On,r=new On,o=new On){this.planes=[e,t,i,s,r,o]}set(e,t,i,s,r,o){const c=this.planes;return c[0].copy(e),c[1].copy(t),c[2].copy(i),c[3].copy(s),c[4].copy(r),c[5].copy(o),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=Sn,i=!1){const s=this.planes,r=e.elements,o=r[0],c=r[1],d=r[2],u=r[3],p=r[4],a=r[5],l=r[6],h=r[7],m=r[8],S=r[9],E=r[10],f=r[11],T=r[12],A=r[13],I=r[14],D=r[15];if(s[0].setComponents(u-o,h-p,f-m,D-T).normalize(),s[1].setComponents(u+o,h+p,f+m,D+T).normalize(),s[2].setComponents(u+c,h+a,f+S,D+A).normalize(),s[3].setComponents(u-c,h-a,f-S,D-A).normalize(),i)s[4].setComponents(d,l,E,I).normalize(),s[5].setComponents(u-d,h-l,f-E,D-I).normalize();else if(s[4].setComponents(u-d,h-l,f-E,D-I).normalize(),t===Sn)s[5].setComponents(u+d,h+l,f+E,D+I).normalize();else if(t===dr)s[5].setComponents(d,l,E,I).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ai.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ai.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ai)}intersectsSprite(e){ai.center.set(0,0,0);const t=Xh.distanceTo(e.center);return ai.radius=.7071067811865476+t,ai.applyMatrix4(e.matrixWorld),this.intersectsSphere(ai)}intersectsSphere(e){const t=this.planes,i=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const s=t[i];if(qs.x=s.normal.x>0?e.max.x:e.min.x,qs.y=s.normal.y>0?e.max.y:e.min.y,qs.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(qs)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Dc extends Pt{constructor(e,t,i=pi,s,r,o,c=qt,d=qt,u,p=xs,a=1){if(p!==xs&&p!==gs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const l={width:e,height:t,depth:a};super(l,s,r,o,c,d,p,i,u),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new To(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Nc extends Pt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class xn{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){ze("Curve: .getPoint() not implemented.")}getPointAt(e,t){const i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let i,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)i=this.getPoint(o/e),r+=i.distanceTo(s),t.push(r),s=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const i=this.getLengths();let s=0;const r=i.length;let o;t?o=t:o=e*i[r-1];let c=0,d=r-1,u;for(;c<=d;)if(s=Math.floor(c+(d-c)/2),u=i[s]-o,u<0)c=s+1;else if(u>0)d=s-1;else{d=s;break}if(s=d,i[s]===o)return s/(r-1);const p=i[s],l=i[s+1]-p,h=(o-p)/l;return(s+h)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const o=this.getPoint(s),c=this.getPoint(r),d=t||(o.isVector2?new oe:new G);return d.copy(c).sub(o).normalize(),d}getTangentAt(e,t){const i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t=!1){const i=new G,s=[],r=[],o=[],c=new G,d=new _t;for(let h=0;h<=e;h++){const m=h/e;s[h]=this.getTangentAt(m,new G)}r[0]=new G,o[0]=new G;let u=Number.MAX_VALUE;const p=Math.abs(s[0].x),a=Math.abs(s[0].y),l=Math.abs(s[0].z);p<=u&&(u=p,i.set(1,0,0)),a<=u&&(u=a,i.set(0,1,0)),l<=u&&i.set(0,0,1),c.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],c),o[0].crossVectors(s[0],r[0]);for(let h=1;h<=e;h++){if(r[h]=r[h-1].clone(),o[h]=o[h-1].clone(),c.crossVectors(s[h-1],s[h]),c.length()>Number.EPSILON){c.normalize();const m=Math.acos(Ze(s[h-1].dot(s[h]),-1,1));r[h].applyMatrix4(d.makeRotationAxis(c,m))}o[h].crossVectors(s[h],r[h])}if(t===!0){let h=Math.acos(Ze(r[0].dot(r[e]),-1,1));h/=e,s[0].dot(c.crossVectors(r[0],r[e]))>0&&(h=-h);for(let m=1;m<=e;m++)r[m].applyMatrix4(d.makeRotationAxis(s[m],h*m)),o[m].crossVectors(s[m],r[m])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Io extends xn{constructor(e=0,t=0,i=1,s=1,r=0,o=Math.PI*2,c=!1,d=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=c,this.aRotation=d}getPoint(e,t=new oe){const i=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);const c=this.aStartAngle+e*r;let d=this.aX+this.xRadius*Math.cos(c),u=this.aY+this.yRadius*Math.sin(c);if(this.aRotation!==0){const p=Math.cos(this.aRotation),a=Math.sin(this.aRotation),l=d-this.aX,h=u-this.aY;d=l*p-h*a+this.aX,u=l*a+h*p+this.aY}return i.set(d,u)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class qh extends Io{constructor(e,t,i,s,r,o){super(e,t,i,i,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}}function Lo(){let n=0,e=0,t=0,i=0;function s(r,o,c,d){n=r,e=c,t=-3*r+3*o-2*c-d,i=2*r-2*o+c+d}return{initCatmullRom:function(r,o,c,d,u){s(o,c,u*(c-r),u*(d-o))},initNonuniformCatmullRom:function(r,o,c,d,u,p,a){let l=(o-r)/u-(c-r)/(u+p)+(c-o)/p,h=(c-o)/p-(d-o)/(p+a)+(d-c)/a;l*=p,h*=p,s(o,c,l,h)},calc:function(r){const o=r*r,c=o*r;return n+e*r+t*o+i*c}}}const Zs=new G,na=new Lo,ia=new Lo,sa=new Lo;class Zh extends xn{constructor(e=[],t=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=s}getPoint(e,t=new G){const i=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e;let c=Math.floor(o),d=o-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/r)+1)*r:d===0&&c===r-1&&(c=r-2,d=1);let u,p;this.closed||c>0?u=s[(c-1)%r]:(Zs.subVectors(s[0],s[1]).add(s[0]),u=Zs);const a=s[c%r],l=s[(c+1)%r];if(this.closed||c+2<r?p=s[(c+2)%r]:(Zs.subVectors(s[r-1],s[r-2]).add(s[r-1]),p=Zs),this.curveType==="centripetal"||this.curveType==="chordal"){const h=this.curveType==="chordal"?.5:.25;let m=Math.pow(u.distanceToSquared(a),h),S=Math.pow(a.distanceToSquared(l),h),E=Math.pow(l.distanceToSquared(p),h);S<1e-4&&(S=1),m<1e-4&&(m=S),E<1e-4&&(E=S),na.initNonuniformCatmullRom(u.x,a.x,l.x,p.x,m,S,E),ia.initNonuniformCatmullRom(u.y,a.y,l.y,p.y,m,S,E),sa.initNonuniformCatmullRom(u.z,a.z,l.z,p.z,m,S,E)}else this.curveType==="catmullrom"&&(na.initCatmullRom(u.x,a.x,l.x,p.x,this.tension),ia.initCatmullRom(u.y,a.y,l.y,p.y,this.tension),sa.initCatmullRom(u.z,a.z,l.z,p.z,this.tension));return i.set(na.calc(d),ia.calc(d),sa.calc(d)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new G().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function pl(n,e,t,i,s){const r=(i-e)*.5,o=(s-t)*.5,c=n*n,d=n*c;return(2*t-2*i+r+o)*d+(-3*t+3*i-2*r-o)*c+r*n+t}function Jh(n,e){const t=1-n;return t*t*e}function Qh(n,e){return 2*(1-n)*n*e}function $h(n,e){return n*n*e}function fs(n,e,t,i){return Jh(n,e)+Qh(n,t)+$h(n,i)}function jh(n,e){const t=1-n;return t*t*t*e}function ed(n,e){const t=1-n;return 3*t*t*n*e}function td(n,e){return 3*(1-n)*n*n*e}function nd(n,e){return n*n*n*e}function ps(n,e,t,i,s){return jh(n,e)+ed(n,t)+td(n,i)+nd(n,s)}class Pc extends xn{constructor(e=new oe,t=new oe,i=new oe,s=new oe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new oe){const i=t,s=this.v0,r=this.v1,o=this.v2,c=this.v3;return i.set(ps(e,s.x,r.x,o.x,c.x),ps(e,s.y,r.y,o.y,c.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class id extends xn{constructor(e=new G,t=new G,i=new G,s=new G){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new G){const i=t,s=this.v0,r=this.v1,o=this.v2,c=this.v3;return i.set(ps(e,s.x,r.x,o.x,c.x),ps(e,s.y,r.y,o.y,c.y),ps(e,s.z,r.z,o.z,c.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Uc extends xn{constructor(e=new oe,t=new oe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new oe){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new oe){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class sd extends xn{constructor(e=new G,t=new G){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new G){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new G){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class wc extends xn{constructor(e=new oe,t=new oe,i=new oe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new oe){const i=t,s=this.v0,r=this.v1,o=this.v2;return i.set(fs(e,s.x,r.x,o.x),fs(e,s.y,r.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class rd extends xn{constructor(e=new G,t=new G,i=new G){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new G){const i=t,s=this.v0,r=this.v1,o=this.v2;return i.set(fs(e,s.x,r.x,o.x),fs(e,s.y,r.y,o.y),fs(e,s.z,r.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Fc extends xn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new oe){const i=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),c=r-o,d=s[o===0?o:o-1],u=s[o],p=s[o>s.length-2?s.length-1:o+1],a=s[o>s.length-3?s.length-1:o+2];return i.set(pl(c,d.x,u.x,p.x,a.x),pl(c,d.y,u.y,p.y,a.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new oe().fromArray(s))}return this}}var ao=Object.freeze({__proto__:null,ArcCurve:qh,CatmullRomCurve3:Zh,CubicBezierCurve:Pc,CubicBezierCurve3:id,EllipseCurve:Io,LineCurve:Uc,LineCurve3:sd,QuadraticBezierCurve:wc,QuadraticBezierCurve3:rd,SplineCurve:Fc});class ad extends xn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new ao[i](t,e))}return this}getPoint(e,t){const i=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=i){const o=s[r]-i,c=this.curves[r],d=c.getLength(),u=d===0?0:1-o/d;return c.getPointAt(u,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let i=0,s=this.curves.length;i<s;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let i;for(let s=0,r=this.curves;s<r.length;s++){const o=r[s],c=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,d=o.getPoints(c);for(let u=0;u<d.length;u++){const p=d[u];i&&i.equals(p)||(t.push(p),i=p)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(new ao[s.type]().fromJSON(s))}return this}}class fi extends ad{constructor(e){super(),this.type="Path",this.currentPoint=new oe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const i=new Uc(this.currentPoint.clone(),new oe(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,s){const r=new wc(this.currentPoint.clone(),new oe(e,t),new oe(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(e,t,i,s,r,o){const c=new Pc(this.currentPoint.clone(),new oe(e,t),new oe(i,s),new oe(r,o));return this.curves.push(c),this.currentPoint.set(r,o),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),i=new Fc(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,s,r,o){const c=this.currentPoint.x,d=this.currentPoint.y;return this.absarc(e+c,t+d,i,s,r,o),this}absarc(e,t,i,s,r,o){return this.absellipse(e,t,i,i,s,r,o),this}ellipse(e,t,i,s,r,o,c,d){const u=this.currentPoint.x,p=this.currentPoint.y;return this.absellipse(e+u,t+p,i,s,r,o,c,d),this}absellipse(e,t,i,s,r,o,c,d){const u=new Io(e,t,i,s,r,o,c,d);if(this.curves.length>0){const a=u.getPoint(0);a.equals(this.currentPoint)||this.lineTo(a.x,a.y)}this.curves.push(u);const p=u.getPoint(1);return this.currentPoint.copy(p),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Qn extends fi{constructor(e){super(e),this.uuid=Ji(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let i=0,s=this.holes.length;i<s;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(new fi().fromJSON(s))}return this}}function od(n,e,t=2){const i=e&&e.length,s=i?e[0]*t:n.length;let r=Bc(n,0,s,t,!0);const o=[];if(!r||r.next===r.prev)return o;let c,d,u;if(i&&(r=dd(n,e,r,t)),n.length>80*t){c=n[0],d=n[1];let p=c,a=d;for(let l=t;l<s;l+=t){const h=n[l],m=n[l+1];h<c&&(c=h),m<d&&(d=m),h>p&&(p=h),m>a&&(a=m)}u=Math.max(p-c,a-d),u=u!==0?32767/u:0}return Rs(r,o,t,c,d,u,0),o}function Bc(n,e,t,i,s){let r;if(s===Rd(n,e,t,i)>0)for(let o=e;o<t;o+=i)r=El(o/i|0,n[o],n[o+1],r);else for(let o=t-i;o>=e;o-=i)r=El(o/i|0,n[o],n[o+1],r);return r&&Xi(r,r.next)&&(Ms(r),r=r.next),r}function Ei(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(Xi(t,t.next)||pt(t.prev,t,t.next)===0)){if(Ms(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function Rs(n,e,t,i,s,r,o){if(!n)return;!o&&r&&Sd(n,i,s,r);let c=n;for(;n.prev!==n.next;){const d=n.prev,u=n.next;if(r?cd(n,i,s,r):ld(n)){e.push(d.i,n.i,u.i),Ms(n),n=u.next,c=u.next;continue}if(n=u,n===c){o?o===1?(n=ud(Ei(n),e),Rs(n,e,t,i,s,r,2)):o===2&&hd(n,e,t,i,s,r):Rs(Ei(n),e,t,i,s,r,1);break}}}function ld(n){const e=n.prev,t=n,i=n.next;if(pt(e,t,i)>=0)return!1;const s=e.x,r=t.x,o=i.x,c=e.y,d=t.y,u=i.y,p=Math.min(s,r,o),a=Math.min(c,d,u),l=Math.max(s,r,o),h=Math.max(c,d,u);let m=i.next;for(;m!==e;){if(m.x>=p&&m.x<=l&&m.y>=a&&m.y<=h&&hs(s,c,r,d,o,u,m.x,m.y)&&pt(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function cd(n,e,t,i){const s=n.prev,r=n,o=n.next;if(pt(s,r,o)>=0)return!1;const c=s.x,d=r.x,u=o.x,p=s.y,a=r.y,l=o.y,h=Math.min(c,d,u),m=Math.min(p,a,l),S=Math.max(c,d,u),E=Math.max(p,a,l),f=oo(h,m,e,t,i),T=oo(S,E,e,t,i);let A=n.prevZ,I=n.nextZ;for(;A&&A.z>=f&&I&&I.z<=T;){if(A.x>=h&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==o&&hs(c,p,d,a,u,l,A.x,A.y)&&pt(A.prev,A,A.next)>=0||(A=A.prevZ,I.x>=h&&I.x<=S&&I.y>=m&&I.y<=E&&I!==s&&I!==o&&hs(c,p,d,a,u,l,I.x,I.y)&&pt(I.prev,I,I.next)>=0))return!1;I=I.nextZ}for(;A&&A.z>=f;){if(A.x>=h&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==o&&hs(c,p,d,a,u,l,A.x,A.y)&&pt(A.prev,A,A.next)>=0)return!1;A=A.prevZ}for(;I&&I.z<=T;){if(I.x>=h&&I.x<=S&&I.y>=m&&I.y<=E&&I!==s&&I!==o&&hs(c,p,d,a,u,l,I.x,I.y)&&pt(I.prev,I,I.next)>=0)return!1;I=I.nextZ}return!0}function ud(n,e){let t=n;do{const i=t.prev,s=t.next.next;!Xi(i,s)&&Gc(i,t,t.next,s)&&vs(i,s)&&vs(s,i)&&(e.push(i.i,t.i,s.i),Ms(t),Ms(t.next),t=n=s),t=t.next}while(t!==n);return Ei(t)}function hd(n,e,t,i,s,r){let o=n;do{let c=o.next.next;for(;c!==o.prev;){if(o.i!==c.i&&xd(o,c)){let d=Vc(o,c);o=Ei(o,o.next),d=Ei(d,d.next),Rs(o,e,t,i,s,r,0),Rs(d,e,t,i,s,r,0);return}c=c.next}o=o.next}while(o!==n)}function dd(n,e,t,i){const s=[];for(let r=0,o=e.length;r<o;r++){const c=e[r]*i,d=r<o-1?e[r+1]*i:n.length,u=Bc(n,c,d,i,!1);u===u.next&&(u.steiner=!0),s.push(_d(u))}s.sort(fd);for(let r=0;r<s.length;r++)t=pd(s[r],t);return t}function fd(n,e){let t=n.x-e.x;if(t===0&&(t=n.y-e.y,t===0)){const i=(n.next.y-n.y)/(n.next.x-n.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=i-s}return t}function pd(n,e){const t=Ed(n,e);if(!t)return e;const i=Vc(t,n);return Ei(i,i.next),Ei(t,t.next)}function Ed(n,e){let t=e;const i=n.x,s=n.y;let r=-1/0,o;if(Xi(n,t))return t;do{if(Xi(n,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const a=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(a<=i&&a>r&&(r=a,o=t.x<t.next.x?t:t.next,a===i))return o}t=t.next}while(t!==e);if(!o)return null;const c=o,d=o.x,u=o.y;let p=1/0;t=o;do{if(i>=t.x&&t.x>=d&&i!==t.x&&Hc(s<u?i:r,s,d,u,s<u?r:i,s,t.x,t.y)){const a=Math.abs(s-t.y)/(i-t.x);vs(t,n)&&(a<p||a===p&&(t.x>o.x||t.x===o.x&&md(o,t)))&&(o=t,p=a)}t=t.next}while(t!==c);return o}function md(n,e){return pt(n.prev,n,e.prev)<0&&pt(e.next,n,n.next)<0}function Sd(n,e,t,i){let s=n;do s.z===0&&(s.z=oo(s.x,s.y,e,t,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,Ad(s)}function Ad(n){let e,t=1;do{let i=n,s;n=null;let r=null;for(e=0;i;){e++;let o=i,c=0;for(let u=0;u<t&&(c++,o=o.nextZ,!!o);u++);let d=t;for(;c>0||d>0&&o;)c!==0&&(d===0||!o||i.z<=o.z)?(s=i,i=i.nextZ,c--):(s=o,o=o.nextZ,d--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;i=o}r.nextZ=null,t*=2}while(e>1);return n}function oo(n,e,t,i,s){return n=(n-t)*s|0,e=(e-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function _d(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function Hc(n,e,t,i,s,r,o,c){return(s-o)*(e-c)>=(n-o)*(r-c)&&(n-o)*(i-c)>=(t-o)*(e-c)&&(t-o)*(r-c)>=(s-o)*(i-c)}function hs(n,e,t,i,s,r,o,c){return!(n===o&&e===c)&&Hc(n,e,t,i,s,r,o,c)}function xd(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!gd(n,e)&&(vs(n,e)&&vs(e,n)&&Td(n,e)&&(pt(n.prev,n,e.prev)||pt(n,e.prev,e))||Xi(n,e)&&pt(n.prev,n,n.next)>0&&pt(e.prev,e,e.next)>0)}function pt(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function Xi(n,e){return n.x===e.x&&n.y===e.y}function Gc(n,e,t,i){const s=Qs(pt(n,e,t)),r=Qs(pt(n,e,i)),o=Qs(pt(t,i,n)),c=Qs(pt(t,i,e));return!!(s!==r&&o!==c||s===0&&Js(n,t,e)||r===0&&Js(n,i,e)||o===0&&Js(t,n,i)||c===0&&Js(t,e,i))}function Js(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function Qs(n){return n>0?1:n<0?-1:0}function gd(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&Gc(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function vs(n,e){return pt(n.prev,n,n.next)<0?pt(n,e,n.next)>=0&&pt(n,n.prev,e)>=0:pt(n,e,n.prev)<0||pt(n,n.next,e)<0}function Td(n,e){let t=n,i=!1;const s=(n.x+e.x)/2,r=(n.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function Vc(n,e){const t=lo(n.i,n.x,n.y),i=lo(e.i,e.x,e.y),s=n.next,r=e.prev;return n.next=e,e.prev=n,t.next=s,s.prev=t,i.next=t,t.prev=i,r.next=i,i.prev=r,i}function El(n,e,t,i){const s=lo(n,e,t);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function Ms(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function lo(n,e,t){return{i:n,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Rd(n,e,t,i){let s=0;for(let r=e,o=t-i;r<t;r+=i)s+=(n[o]-n[r])*(n[r+1]+n[o+1]),o=r;return s}class vd{static triangulate(e,t,i=2){return od(e,t,i)}}class un{static area(e){const t=e.length;let i=0;for(let s=t-1,r=0;r<t;s=r++)i+=e[s].x*e[r].y-e[r].x*e[s].y;return i*.5}static isClockWise(e){return un.area(e)<0}static triangulateShape(e,t){const i=[],s=[],r=[];ml(e),Sl(i,e);let o=e.length;t.forEach(ml);for(let d=0;d<t.length;d++)s.push(o),o+=t[d].length,Sl(i,t[d]);const c=vd.triangulate(i,s);for(let d=0;d<c.length;d+=3)r.push(c.slice(d,d+3));return r}}function ml(n){const e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function Sl(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}class yo extends gt{constructor(e=new Qn([new oe(.5,.5),new oe(-.5,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const i=this,s=[],r=[];for(let c=0,d=e.length;c<d;c++){const u=e[c];o(u)}this.setAttribute("position",new xt(s,3)),this.setAttribute("uv",new xt(r,2)),this.computeVertexNormals();function o(c){const d=[],u=t.curveSegments!==void 0?t.curveSegments:12,p=t.steps!==void 0?t.steps:1,a=t.depth!==void 0?t.depth:1;let l=t.bevelEnabled!==void 0?t.bevelEnabled:!0,h=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:h-.1,S=t.bevelOffset!==void 0?t.bevelOffset:0,E=t.bevelSegments!==void 0?t.bevelSegments:3;const f=t.extrudePath,T=t.UVGenerator!==void 0?t.UVGenerator:Md;let A,I=!1,D,O,C,U;f&&(A=f.getSpacedPoints(p),I=!0,l=!1,D=f.computeFrenetFrames(p,!1),O=new G,C=new G,U=new G),l||(E=0,h=0,m=0,S=0);const v=c.extractPoints(u);let R=v.shape;const P=v.holes;if(!un.isClockWise(R)){R=R.reverse();for(let H=0,x=P.length;H<x;H++){const q=P[H];un.isClockWise(q)&&(P[H]=q.reverse())}}function Z(H){const q=10000000000000001e-36;let Q=H[0];for(let N=1;N<=H.length;N++){const y=N%H.length,ae=H[y],le=ae.x-Q.x,Te=ae.y-Q.y,b=le*le+Te*Te,_=Math.max(Math.abs(ae.x),Math.abs(ae.y),Math.abs(Q.x),Math.abs(Q.y)),Y=q*_*_;if(b<=Y){H.splice(y,1),N--;continue}Q=ae}}Z(R),P.forEach(Z);const J=P.length,$=R;for(let H=0;H<J;H++){const x=P[H];R=R.concat(x)}function ie(H,x,q){return x||ft("ExtrudeGeometry: vec does not exist"),H.clone().addScaledVector(x,q)}const j=R.length;function B(H,x,q){let Q,N,y;const ae=H.x-x.x,le=H.y-x.y,Te=q.x-H.x,b=q.y-H.y,_=ae*ae+le*le,Y=ae*b-le*Te;if(Math.abs(Y)>Number.EPSILON){const se=Math.sqrt(_),de=Math.sqrt(Te*Te+b*b),ne=x.x-le/se,De=x.y+ae/se,ge=q.x-b/de,Ue=q.y+Te/de,Ce=((ge-ne)*b-(Ue-De)*Te)/(ae*b-le*Te);Q=ne+ae*Ce-H.x,N=De+le*Ce-H.y;const me=Q*Q+N*N;if(me<=2)return new oe(Q,N);y=Math.sqrt(me/2)}else{let se=!1;ae>Number.EPSILON?Te>Number.EPSILON&&(se=!0):ae<-Number.EPSILON?Te<-Number.EPSILON&&(se=!0):Math.sign(le)===Math.sign(b)&&(se=!0),se?(Q=-le,N=ae,y=Math.sqrt(_)):(Q=ae,N=le,y=Math.sqrt(_/2))}return new oe(Q/y,N/y)}const pe=[];for(let H=0,x=$.length,q=x-1,Q=H+1;H<x;H++,q++,Q++)q===x&&(q=0),Q===x&&(Q=0),pe[H]=B($[H],$[q],$[Q]);const Ee=[];let Le,Ve=pe.concat();for(let H=0,x=J;H<x;H++){const q=P[H];Le=[];for(let Q=0,N=q.length,y=N-1,ae=Q+1;Q<N;Q++,y++,ae++)y===N&&(y=0),ae===N&&(ae=0),Le[Q]=B(q[Q],q[y],q[ae]);Ee.push(Le),Ve=Ve.concat(Le)}let Xe;if(E===0)Xe=un.triangulateShape($,P);else{const H=[],x=[];for(let q=0;q<E;q++){const Q=q/E,N=h*Math.cos(Q*Math.PI/2),y=m*Math.sin(Q*Math.PI/2)+S;for(let ae=0,le=$.length;ae<le;ae++){const Te=ie($[ae],pe[ae],y);re(Te.x,Te.y,-N),Q===0&&H.push(Te)}for(let ae=0,le=J;ae<le;ae++){const Te=P[ae];Le=Ee[ae];const b=[];for(let _=0,Y=Te.length;_<Y;_++){const se=ie(Te[_],Le[_],y);re(se.x,se.y,-N),Q===0&&b.push(se)}Q===0&&x.push(b)}}Xe=un.triangulateShape(H,x)}const X=Xe.length,w=m+S;for(let H=0;H<j;H++){const x=l?ie(R[H],Ve[H],w):R[H];I?(C.copy(D.normals[0]).multiplyScalar(x.x),O.copy(D.binormals[0]).multiplyScalar(x.y),U.copy(A[0]).add(C).add(O),re(U.x,U.y,U.z)):re(x.x,x.y,0)}for(let H=1;H<=p;H++)for(let x=0;x<j;x++){const q=l?ie(R[x],Ve[x],w):R[x];I?(C.copy(D.normals[H]).multiplyScalar(q.x),O.copy(D.binormals[H]).multiplyScalar(q.y),U.copy(A[H]).add(C).add(O),re(U.x,U.y,U.z)):re(q.x,q.y,a/p*H)}for(let H=E-1;H>=0;H--){const x=H/E,q=h*Math.cos(x*Math.PI/2),Q=m*Math.sin(x*Math.PI/2)+S;for(let N=0,y=$.length;N<y;N++){const ae=ie($[N],pe[N],Q);re(ae.x,ae.y,a+q)}for(let N=0,y=P.length;N<y;N++){const ae=P[N];Le=Ee[N];for(let le=0,Te=ae.length;le<Te;le++){const b=ie(ae[le],Le[le],Q);I?re(b.x,b.y+A[p-1].y,A[p-1].x+q):re(b.x,b.y,a+q)}}}M(),g();function M(){const H=s.length/3;if(l){let x=0,q=j*x;for(let Q=0;Q<X;Q++){const N=Xe[Q];k(N[2]+q,N[1]+q,N[0]+q)}x=p+E*2,q=j*x;for(let Q=0;Q<X;Q++){const N=Xe[Q];k(N[0]+q,N[1]+q,N[2]+q)}}else{for(let x=0;x<X;x++){const q=Xe[x];k(q[2],q[1],q[0])}for(let x=0;x<X;x++){const q=Xe[x];k(q[0]+j*p,q[1]+j*p,q[2]+j*p)}}i.addGroup(H,s.length/3-H,0)}function g(){const H=s.length/3;let x=0;K($,x),x+=$.length;for(let q=0,Q=P.length;q<Q;q++){const N=P[q];K(N,x),x+=N.length}i.addGroup(H,s.length/3-H,1)}function K(H,x){let q=H.length;for(;--q>=0;){const Q=q;let N=q-1;N<0&&(N=H.length-1);for(let y=0,ae=p+E*2;y<ae;y++){const le=j*y,Te=j*(y+1),b=x+Q+le,_=x+N+le,Y=x+N+Te,se=x+Q+Te;ce(b,_,Y,se)}}}function re(H,x,q){d.push(H),d.push(x),d.push(q)}function k(H,x,q){Ae(H),Ae(x),Ae(q);const Q=s.length/3,N=T.generateTopUV(i,s,Q-3,Q-2,Q-1);ue(N[0]),ue(N[1]),ue(N[2])}function ce(H,x,q,Q){Ae(H),Ae(x),Ae(Q),Ae(x),Ae(q),Ae(Q);const N=s.length/3,y=T.generateSideWallUV(i,s,N-6,N-3,N-2,N-1);ue(y[0]),ue(y[1]),ue(y[3]),ue(y[1]),ue(y[2]),ue(y[3])}function Ae(H){s.push(d[H*3+0]),s.push(d[H*3+1]),s.push(d[H*3+2])}function ue(H){r.push(H.x),r.push(H.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,i=this.parameters.options;return Id(t,i,e)}static fromJSON(e,t){const i=[];for(let r=0,o=e.shapes.length;r<o;r++){const c=t[e.shapes[r]];i.push(c)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new ao[s.type]().fromJSON(s)),new yo(i,e.options)}}const Md={generateTopUV:function(n,e,t,i,s){const r=e[t*3],o=e[t*3+1],c=e[i*3],d=e[i*3+1],u=e[s*3],p=e[s*3+1];return[new oe(r,o),new oe(c,d),new oe(u,p)]},generateSideWallUV:function(n,e,t,i,s,r){const o=e[t*3],c=e[t*3+1],d=e[t*3+2],u=e[i*3],p=e[i*3+1],a=e[i*3+2],l=e[s*3],h=e[s*3+1],m=e[s*3+2],S=e[r*3],E=e[r*3+1],f=e[r*3+2];return Math.abs(c-p)<Math.abs(o-u)?[new oe(o,1-d),new oe(u,1-a),new oe(l,1-m),new oe(S,1-f)]:[new oe(c,1-d),new oe(p,1-a),new oe(h,1-m),new oe(E,1-f)]}};function Id(n,e,t){if(t.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){const r=n[i];t.shapes.push(r.uuid)}else t.shapes.push(n.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class Ai extends gt{constructor(e=1,t=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:s};const r=e/2,o=t/2,c=Math.floor(i),d=Math.floor(s),u=c+1,p=d+1,a=e/c,l=t/d,h=[],m=[],S=[],E=[];for(let f=0;f<p;f++){const T=f*l-o;for(let A=0;A<u;A++){const I=A*a-r;m.push(I,-T,0),S.push(0,0,1),E.push(A/c),E.push(1-f/d)}}for(let f=0;f<d;f++)for(let T=0;T<c;T++){const A=T+u*f,I=T+u*(f+1),D=T+1+u*(f+1),O=T+1+u*f;h.push(A,I,O),h.push(I,D,O)}this.setIndex(h),this.setAttribute("position",new xt(m,3)),this.setAttribute("normal",new xt(S,3)),this.setAttribute("uv",new xt(E,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ai(e.width,e.height,e.widthSegments,e.heightSegments)}}class Oo extends gt{constructor(e=new Qn([new oe(0,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const i=[],s=[],r=[],o=[];let c=0,d=0;if(Array.isArray(e)===!1)u(e);else for(let p=0;p<e.length;p++)u(e[p]),this.addGroup(c,d,p),c+=d,d=0;this.setIndex(i),this.setAttribute("position",new xt(s,3)),this.setAttribute("normal",new xt(r,3)),this.setAttribute("uv",new xt(o,2));function u(p){const a=s.length/3,l=p.extractPoints(t);let h=l.shape;const m=l.holes;un.isClockWise(h)===!1&&(h=h.reverse());for(let E=0,f=m.length;E<f;E++){const T=m[E];un.isClockWise(T)===!0&&(m[E]=T.reverse())}const S=un.triangulateShape(h,m);for(let E=0,f=m.length;E<f;E++){const T=m[E];h=h.concat(T)}for(let E=0,f=h.length;E<f;E++){const T=h[E];s.push(T.x,T.y,0),r.push(0,0,1),o.push(T.x,T.y)}for(let E=0,f=S.length;E<f;E++){const T=S[E],A=T[0]+a,I=T[1]+a,D=T[2]+a;i.push(A,I,D),d+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Ld(t,e)}static fromJSON(e,t){const i=[];for(let s=0,r=e.shapes.length;s<r;s++){const o=t[e.shapes[s]];i.push(o)}return new Oo(i,e.curveSegments)}}function Ld(n,e){if(e.shapes=[],Array.isArray(n))for(let t=0,i=n.length;t<i;t++){const s=n[t];e.shapes.push(s.uuid)}else e.shapes.push(n.uuid);return e}class yd extends Tr{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=sh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Od extends Tr{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Al={enabled:!1,files:{},add:function(n,e){this.enabled!==!1&&(this.files[n]=e)},get:function(n){if(this.enabled!==!1)return this.files[n]},remove:function(n){delete this.files[n]},clear:function(){this.files={}}};class bd{constructor(e,t,i){const s=this;let r=!1,o=0,c=0,d;const u=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this._abortController=null,this.itemStart=function(p){c++,r===!1&&s.onStart!==void 0&&s.onStart(p,o,c),r=!0},this.itemEnd=function(p){o++,s.onProgress!==void 0&&s.onProgress(p,o,c),o===c&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(p){s.onError!==void 0&&s.onError(p)},this.resolveURL=function(p){return d?d(p):p},this.setURLModifier=function(p){return d=p,this},this.addHandler=function(p,a){return u.push(p,a),this},this.removeHandler=function(p){const a=u.indexOf(p);return a!==-1&&u.splice(a,2),this},this.getHandler=function(p){for(let a=0,l=u.length;a<l;a+=2){const h=u[a],m=u[a+1];if(h.global&&(h.lastIndex=0),h.test(p))return m}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const Cd=new bd;class bo{constructor(e){this.manager=e!==void 0?e:Cd,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const i=this;return new Promise(function(s,r){i.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}bo.DEFAULT_MATERIAL_NAME="__DEFAULT";const In={};class Dd extends Error{constructor(e,t){super(e),this.response=t}}class Nd extends bo{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,i,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=Al.get(`file:${e}`);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(In[e]!==void 0){In[e].push({onLoad:t,onProgress:i,onError:s});return}In[e]=[],In[e].push({onLoad:t,onProgress:i,onError:s});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),c=this.mimeType,d=this.responseType;fetch(o).then(u=>{if(u.status===200||u.status===0){if(u.status===0&&ze("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||u.body===void 0||u.body.getReader===void 0)return u;const p=In[e],a=u.body.getReader(),l=u.headers.get("X-File-Size")||u.headers.get("Content-Length"),h=l?parseInt(l):0,m=h!==0;let S=0;const E=new ReadableStream({start(f){T();function T(){a.read().then(({done:A,value:I})=>{if(A)f.close();else{S+=I.byteLength;const D=new ProgressEvent("progress",{lengthComputable:m,loaded:S,total:h});for(let O=0,C=p.length;O<C;O++){const U=p[O];U.onProgress&&U.onProgress(D)}f.enqueue(I),T()}},A=>{f.error(A)})}}});return new Response(E)}else throw new Dd(`fetch for "${u.url}" responded with ${u.status}: ${u.statusText}`,u)}).then(u=>{switch(d){case"arraybuffer":return u.arrayBuffer();case"blob":return u.blob();case"document":return u.text().then(p=>new DOMParser().parseFromString(p,c));case"json":return u.json();default:if(c==="")return u.text();{const a=/charset="?([^;"\s]*)"?/i.exec(c),l=a&&a[1]?a[1].toLowerCase():void 0,h=new TextDecoder(l);return u.arrayBuffer().then(m=>h.decode(m))}}}).then(u=>{Al.add(`file:${e}`,u);const p=In[e];delete In[e];for(let a=0,l=p.length;a<l;a++){const h=p[a];h.onLoad&&h.onLoad(u)}}).catch(u=>{const p=In[e];if(p===void 0)throw this.manager.itemError(e),u;delete In[e];for(let a=0,l=p.length;a<l;a++){const h=p[a];h.onError&&h.onError(u)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class Pd extends Oc{constructor(e=-1,t=1,i=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=i-e,o=i+e,c=s+t,d=s-t;if(this.view!==null&&this.view.enabled){const u=(this.right-this.left)/this.view.fullWidth/this.zoom,p=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=u*this.view.offsetX,o=r+u*this.view.width,c-=p*this.view.offsetY,d=c-p*this.view.height}this.projectionMatrix.makeOrthographic(r,o,c,d,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Ud extends Xt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const _l=new _t;class kc{constructor(e,t,i=0,s=1/0){this.ray=new vo(e,t),this.near=i,this.far=s,this.camera=null,this.layers=new Mo,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):ft("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return _l.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(_l),this}intersectObject(e,t=!0,i=[]){return co(e,this,i,t),i.sort(xl),i}intersectObjects(e,t=!0,i=[]){for(let s=0,r=e.length;s<r;s++)co(e[s],this,i,t);return i.sort(xl),i}}function xl(n,e){return n.distance-e.distance}function co(n,e,t,i){let s=!0;if(n.layers.test(e.layers)&&n.raycast(e,t)===!1&&(s=!1),s===!0&&i===!0){const r=n.children;for(let o=0,c=r.length;o<c;o++)co(r[o],e,t,!0)}}class gl{constructor(e=1,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.radius=e,this.phi=t,this.theta=i}set(e,t,i){return this.radius=e,this.phi=t,this.theta=i,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Ze(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,i){return this.radius=Math.sqrt(e*e+t*t+i*i),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,i),this.phi=Math.acos(Ze(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const Tl=new oe;class wd{constructor(e=new oe(1/0,1/0),t=new oe(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=Tl.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Tl).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}class oi{constructor(){this.type="ShapePath",this.color=new Qe,this.subPaths=[],this.currentPath=null}moveTo(e,t){return this.currentPath=new fi,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,i,s){return this.currentPath.quadraticCurveTo(e,t,i,s),this}bezierCurveTo(e,t,i,s,r,o){return this.currentPath.bezierCurveTo(e,t,i,s,r,o),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(e){function t(f){const T=[];for(let A=0,I=f.length;A<I;A++){const D=f[A],O=new Qn;O.curves=D.curves,T.push(O)}return T}function i(f,T){const A=T.length;let I=!1;for(let D=A-1,O=0;O<A;D=O++){let C=T[D],U=T[O],v=U.x-C.x,R=U.y-C.y;if(Math.abs(R)>Number.EPSILON){if(R<0&&(C=T[O],v=-v,U=T[D],R=-R),f.y<C.y||f.y>U.y)continue;if(f.y===C.y){if(f.x===C.x)return!0}else{const P=R*(f.x-C.x)-v*(f.y-C.y);if(P===0)return!0;if(P<0)continue;I=!I}}else{if(f.y!==C.y)continue;if(U.x<=f.x&&f.x<=C.x||C.x<=f.x&&f.x<=U.x)return!0}}return I}const s=un.isClockWise,r=this.subPaths;if(r.length===0)return[];let o,c,d;const u=[];if(r.length===1)return c=r[0],d=new Qn,d.curves=c.curves,u.push(d),u;let p=!s(r[0].getPoints());p=e?!p:p;const a=[],l=[];let h=[],m=0,S;l[m]=void 0,h[m]=[];for(let f=0,T=r.length;f<T;f++)c=r[f],S=c.getPoints(),o=s(S),o=e?!o:o,o?(!p&&l[m]&&m++,l[m]={s:new Qn,p:S},l[m].s.curves=c.curves,p&&m++,h[m]=[]):h[m].push({h:c,p:S[0]});if(!l[0])return t(r);if(l.length>1){let f=!1,T=0;for(let A=0,I=l.length;A<I;A++)a[A]=[];for(let A=0,I=l.length;A<I;A++){const D=h[A];for(let O=0;O<D.length;O++){const C=D[O];let U=!0;for(let v=0;v<l.length;v++)i(C.p,l[v].p)&&(A!==v&&T++,U?(U=!1,a[v].push(C)):f=!0);U&&a[A].push(C)}}T>0&&f===!1&&(h=a)}let E;for(let f=0,T=l.length;f<T;f++){d=l[f].s,u.push(d),E=h[f];for(let A=0,I=E.length;A<I;A++)d.holes.push(E[A].h)}return u}}class Fd extends mi{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){ze("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function Rl(n,e,t,i){const s=Bd(i);switch(t){case _c:return n*e;case gc:return n*e/s.components*s.byteLength;case Ao:return n*e/s.components*s.byteLength;case _o:return n*e*2/s.components*s.byteLength;case xo:return n*e*2/s.components*s.byteLength;case xc:return n*e*3/s.components*s.byteLength;case cn:return n*e*4/s.components*s.byteLength;case go:return n*e*4/s.components*s.byteLength;case sr:case rr:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case ar:case or:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Da:case Pa:return Math.max(n,16)*Math.max(e,8)/4;case Ca:case Na:return Math.max(n,8)*Math.max(e,8)/2;case Ua:case wa:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case Fa:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Ba:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Ha:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case Ga:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case Va:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case ka:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case Ya:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case Wa:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case za:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case Ka:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case Xa:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case qa:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case Za:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case Ja:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case Qa:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case $a:case ja:case eo:return Math.ceil(n/4)*Math.ceil(e/4)*16;case to:case no:return Math.ceil(n/4)*Math.ceil(e/4)*8;case io:case so:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Bd(n){switch(n){case Un:case Ec:return{byteLength:1,components:1};case As:case mc:case Zi:return{byteLength:2,components:1};case mo:case So:return{byteLength:2,components:4};case pi:case Eo:case Dn:return{byteLength:4,components:1};case Sc:case Ac:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${n}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:po}}));typeof window<"u"&&(window.__THREE__?ze("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=po);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Yc(){let n=null,e=!1,t=null,i=null;function s(r,o){t(r,o),i=n.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(s),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){n=r}}}function Hd(n){const e=new WeakMap;function t(c,d){const u=c.array,p=c.usage,a=u.byteLength,l=n.createBuffer();n.bindBuffer(d,l),n.bufferData(d,u,p),c.onUploadCallback();let h;if(u instanceof Float32Array)h=n.FLOAT;else if(typeof Float16Array<"u"&&u instanceof Float16Array)h=n.HALF_FLOAT;else if(u instanceof Uint16Array)c.isFloat16BufferAttribute?h=n.HALF_FLOAT:h=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)h=n.SHORT;else if(u instanceof Uint32Array)h=n.UNSIGNED_INT;else if(u instanceof Int32Array)h=n.INT;else if(u instanceof Int8Array)h=n.BYTE;else if(u instanceof Uint8Array)h=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)h=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:l,type:h,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:a}}function i(c,d,u){const p=d.array,a=d.updateRanges;if(n.bindBuffer(u,c),a.length===0)n.bufferSubData(u,0,p);else{a.sort((h,m)=>h.start-m.start);let l=0;for(let h=1;h<a.length;h++){const m=a[l],S=a[h];S.start<=m.start+m.count+1?m.count=Math.max(m.count,S.start+S.count-m.start):(++l,a[l]=S)}a.length=l+1;for(let h=0,m=a.length;h<m;h++){const S=a[h];n.bufferSubData(u,S.start*p.BYTES_PER_ELEMENT,p,S.start,S.count)}d.clearUpdateRanges()}d.onUploadCallback()}function s(c){return c.isInterleavedBufferAttribute&&(c=c.data),e.get(c)}function r(c){c.isInterleavedBufferAttribute&&(c=c.data);const d=e.get(c);d&&(n.deleteBuffer(d.buffer),e.delete(c))}function o(c,d){if(c.isInterleavedBufferAttribute&&(c=c.data),c.isGLBufferAttribute){const p=e.get(c);(!p||p.version<c.version)&&e.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}const u=e.get(c);if(u===void 0)e.set(c,t(c,d));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(u.buffer,c,d),u.version=c.version}}return{get:s,remove:r,update:o}}var Gd=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Vd=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,kd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Yd=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Wd=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,zd=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Kd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Xd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,qd=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Zd=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Jd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Qd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,$d=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,jd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,ef=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,tf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,nf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,sf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,rf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,af=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,of=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,lf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,cf=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,uf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,hf=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,df=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,ff=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,pf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Ef=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,mf=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Sf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Af=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,_f=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,xf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,gf=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Tf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Rf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,vf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Mf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,If=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Lf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,yf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Of=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,bf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Cf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Df=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Nf=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Pf=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Uf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,wf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ff=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Bf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Hf=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Gf=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Vf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,kf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Yf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Wf=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,zf=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Kf=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Xf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,qf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Zf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Jf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Qf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,$f=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,jf=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,ep=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,tp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,np=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,ip=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,sp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,rp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,ap=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,op=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,lp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,cp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,up=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,hp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,dp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,fp=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,pp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Ep=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,mp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Sp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Ap=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,_p=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,xp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,gp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Tp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Rp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,vp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Mp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Ip=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Lp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,yp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Op=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,bp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Cp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Dp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Np=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Pp=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Up=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,wp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Fp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Bp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Hp=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Gp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Vp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Yp=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Wp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zp=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Kp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Xp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,qp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Zp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Jp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Qp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$p=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,jp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,eE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,tE=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,iE=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,rE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,aE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,oE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,lE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,cE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,uE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,hE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,pE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,EE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,SE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,AE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,_E=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:Gd,alphahash_pars_fragment:Vd,alphamap_fragment:kd,alphamap_pars_fragment:Yd,alphatest_fragment:Wd,alphatest_pars_fragment:zd,aomap_fragment:Kd,aomap_pars_fragment:Xd,batching_pars_vertex:qd,batching_vertex:Zd,begin_vertex:Jd,beginnormal_vertex:Qd,bsdfs:$d,iridescence_fragment:jd,bumpmap_pars_fragment:ef,clipping_planes_fragment:tf,clipping_planes_pars_fragment:nf,clipping_planes_pars_vertex:sf,clipping_planes_vertex:rf,color_fragment:af,color_pars_fragment:of,color_pars_vertex:lf,color_vertex:cf,common:uf,cube_uv_reflection_fragment:hf,defaultnormal_vertex:df,displacementmap_pars_vertex:ff,displacementmap_vertex:pf,emissivemap_fragment:Ef,emissivemap_pars_fragment:mf,colorspace_fragment:Sf,colorspace_pars_fragment:Af,envmap_fragment:_f,envmap_common_pars_fragment:xf,envmap_pars_fragment:gf,envmap_pars_vertex:Tf,envmap_physical_pars_fragment:Nf,envmap_vertex:Rf,fog_vertex:vf,fog_pars_vertex:Mf,fog_fragment:If,fog_pars_fragment:Lf,gradientmap_pars_fragment:yf,lightmap_pars_fragment:Of,lights_lambert_fragment:bf,lights_lambert_pars_fragment:Cf,lights_pars_begin:Df,lights_toon_fragment:Pf,lights_toon_pars_fragment:Uf,lights_phong_fragment:wf,lights_phong_pars_fragment:Ff,lights_physical_fragment:Bf,lights_physical_pars_fragment:Hf,lights_fragment_begin:Gf,lights_fragment_maps:Vf,lights_fragment_end:kf,logdepthbuf_fragment:Yf,logdepthbuf_pars_fragment:Wf,logdepthbuf_pars_vertex:zf,logdepthbuf_vertex:Kf,map_fragment:Xf,map_pars_fragment:qf,map_particle_fragment:Zf,map_particle_pars_fragment:Jf,metalnessmap_fragment:Qf,metalnessmap_pars_fragment:$f,morphinstance_vertex:jf,morphcolor_vertex:ep,morphnormal_vertex:tp,morphtarget_pars_vertex:np,morphtarget_vertex:ip,normal_fragment_begin:sp,normal_fragment_maps:rp,normal_pars_fragment:ap,normal_pars_vertex:op,normal_vertex:lp,normalmap_pars_fragment:cp,clearcoat_normal_fragment_begin:up,clearcoat_normal_fragment_maps:hp,clearcoat_pars_fragment:dp,iridescence_pars_fragment:fp,opaque_fragment:pp,packing:Ep,premultiplied_alpha_fragment:mp,project_vertex:Sp,dithering_fragment:Ap,dithering_pars_fragment:_p,roughnessmap_fragment:xp,roughnessmap_pars_fragment:gp,shadowmap_pars_fragment:Tp,shadowmap_pars_vertex:Rp,shadowmap_vertex:vp,shadowmask_pars_fragment:Mp,skinbase_vertex:Ip,skinning_pars_vertex:Lp,skinning_vertex:yp,skinnormal_vertex:Op,specularmap_fragment:bp,specularmap_pars_fragment:Cp,tonemapping_fragment:Dp,tonemapping_pars_fragment:Np,transmission_fragment:Pp,transmission_pars_fragment:Up,uv_pars_fragment:wp,uv_pars_vertex:Fp,uv_vertex:Bp,worldpos_vertex:Hp,background_vert:Gp,background_frag:Vp,backgroundCube_vert:kp,backgroundCube_frag:Yp,cube_vert:Wp,cube_frag:zp,depth_vert:Kp,depth_frag:Xp,distanceRGBA_vert:qp,distanceRGBA_frag:Zp,equirect_vert:Jp,equirect_frag:Qp,linedashed_vert:$p,linedashed_frag:jp,meshbasic_vert:eE,meshbasic_frag:tE,meshlambert_vert:nE,meshlambert_frag:iE,meshmatcap_vert:sE,meshmatcap_frag:rE,meshnormal_vert:aE,meshnormal_frag:oE,meshphong_vert:lE,meshphong_frag:cE,meshphysical_vert:uE,meshphysical_frag:hE,meshtoon_vert:dE,meshtoon_frag:fE,points_vert:pE,points_frag:EE,shadow_vert:mE,shadow_frag:SE,sprite_vert:AE,sprite_frag:_E},Me={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Ye}},envmap:{envMap:{value:null},envMapRotation:{value:new Ye},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Ye}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Ye}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Ye},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Ye},normalScale:{value:new oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Ye},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Ye}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Ye}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Ye}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0},uvTransform:{value:new Ye}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Ye},alphaMap:{value:null},alphaMapTransform:{value:new Ye},alphaTest:{value:0}}},mn={basic:{uniforms:Ct([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:Ct([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,Me.lights,{emissive:{value:new Qe(0)}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:Ct([Me.common,Me.specularmap,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,Me.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:Ct([Me.common,Me.envmap,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.roughnessmap,Me.metalnessmap,Me.fog,Me.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:Ct([Me.common,Me.aomap,Me.lightmap,Me.emissivemap,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.gradientmap,Me.fog,Me.lights,{emissive:{value:new Qe(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:Ct([Me.common,Me.bumpmap,Me.normalmap,Me.displacementmap,Me.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:Ct([Me.points,Me.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:Ct([Me.common,Me.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:Ct([Me.common,Me.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:Ct([Me.common,Me.bumpmap,Me.normalmap,Me.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:Ct([Me.sprite,Me.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new Ye},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Ye}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distanceRGBA:{uniforms:Ct([Me.common,Me.displacementmap,{referencePosition:{value:new G},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distanceRGBA_vert,fragmentShader:qe.distanceRGBA_frag},shadow:{uniforms:Ct([Me.lights,Me.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};mn.physical={uniforms:Ct([mn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Ye},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Ye},clearcoatNormalScale:{value:new oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Ye},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Ye},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Ye},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Ye},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Ye},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Ye},transmissionSamplerSize:{value:new oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Ye},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Ye},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Ye},anisotropyVector:{value:new oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Ye}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const $s={r:0,b:0,g:0},li=new Fn,xE=new _t;function gE(n,e,t,i,s,r,o){const c=new Qe(0);let d=r===!0?0:1,u,p,a=null,l=0,h=null;function m(A){let I=A.isScene===!0?A.background:null;return I&&I.isTexture&&(I=(A.backgroundBlurriness>0?t:e).get(I)),I}function S(A){let I=!1;const D=m(A);D===null?f(c,d):D&&D.isColor&&(f(D,1),I=!0);const O=n.xr.getEnvironmentBlendMode();O==="additive"?i.buffers.color.setClear(0,0,0,1,o):O==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,o),(n.autoClear||I)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function E(A,I){const D=m(I);D&&(D.isCubeTexture||D.mapping===gr)?(p===void 0&&(p=new At(new Si(1,1,1),new Bn({name:"BackgroundCubeMaterial",uniforms:Ki(mn.backgroundCube.uniforms),vertexShader:mn.backgroundCube.vertexShader,fragmentShader:mn.backgroundCube.fragmentShader,side:Lt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(O,C,U){this.matrixWorld.copyPosition(U.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(p)),li.copy(I.backgroundRotation),li.x*=-1,li.y*=-1,li.z*=-1,D.isCubeTexture&&D.isRenderTargetTexture===!1&&(li.y*=-1,li.z*=-1),p.material.uniforms.envMap.value=D,p.material.uniforms.flipEnvMap.value=D.isCubeTexture&&D.isRenderTargetTexture===!1?-1:1,p.material.uniforms.backgroundBlurriness.value=I.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(xE.makeRotationFromEuler(li)),p.material.toneMapped=je.getTransfer(D.colorSpace)!==st,(a!==D||l!==D.version||h!==n.toneMapping)&&(p.material.needsUpdate=!0,a=D,l=D.version,h=n.toneMapping),p.layers.enableAll(),A.unshift(p,p.geometry,p.material,0,0,null)):D&&D.isTexture&&(u===void 0&&(u=new At(new Ai(2,2),new Bn({name:"BackgroundMaterial",uniforms:Ki(mn.background.uniforms),vertexShader:mn.background.vertexShader,fragmentShader:mn.background.fragmentShader,side:_n,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(u)),u.material.uniforms.t2D.value=D,u.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,u.material.toneMapped=je.getTransfer(D.colorSpace)!==st,D.matrixAutoUpdate===!0&&D.updateMatrix(),u.material.uniforms.uvTransform.value.copy(D.matrix),(a!==D||l!==D.version||h!==n.toneMapping)&&(u.material.needsUpdate=!0,a=D,l=D.version,h=n.toneMapping),u.layers.enableAll(),A.unshift(u,u.geometry,u.material,0,0,null))}function f(A,I){A.getRGB($s,yc(n)),i.buffers.color.setClear($s.r,$s.g,$s.b,I,o)}function T(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0)}return{getClearColor:function(){return c},setClearColor:function(A,I=1){c.set(A),d=I,f(c,d)},getClearAlpha:function(){return d},setClearAlpha:function(A){d=A,f(c,d)},render:S,addToRenderList:E,dispose:T}}function TE(n,e){const t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},s=l(null);let r=s,o=!1;function c(R,P,V,Z,J){let $=!1;const ie=a(Z,V,P);r!==ie&&(r=ie,u(r.object)),$=h(R,Z,V,J),$&&m(R,Z,V,J),J!==null&&e.update(J,n.ELEMENT_ARRAY_BUFFER),($||o)&&(o=!1,I(R,P,V,Z),J!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(J).buffer))}function d(){return n.createVertexArray()}function u(R){return n.bindVertexArray(R)}function p(R){return n.deleteVertexArray(R)}function a(R,P,V){const Z=V.wireframe===!0;let J=i[R.id];J===void 0&&(J={},i[R.id]=J);let $=J[P.id];$===void 0&&($={},J[P.id]=$);let ie=$[Z];return ie===void 0&&(ie=l(d()),$[Z]=ie),ie}function l(R){const P=[],V=[],Z=[];for(let J=0;J<t;J++)P[J]=0,V[J]=0,Z[J]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:V,attributeDivisors:Z,object:R,attributes:{},index:null}}function h(R,P,V,Z){const J=r.attributes,$=P.attributes;let ie=0;const j=V.getAttributes();for(const B in j)if(j[B].location>=0){const Ee=J[B];let Le=$[B];if(Le===void 0&&(B==="instanceMatrix"&&R.instanceMatrix&&(Le=R.instanceMatrix),B==="instanceColor"&&R.instanceColor&&(Le=R.instanceColor)),Ee===void 0||Ee.attribute!==Le||Le&&Ee.data!==Le.data)return!0;ie++}return r.attributesNum!==ie||r.index!==Z}function m(R,P,V,Z){const J={},$=P.attributes;let ie=0;const j=V.getAttributes();for(const B in j)if(j[B].location>=0){let Ee=$[B];Ee===void 0&&(B==="instanceMatrix"&&R.instanceMatrix&&(Ee=R.instanceMatrix),B==="instanceColor"&&R.instanceColor&&(Ee=R.instanceColor));const Le={};Le.attribute=Ee,Ee&&Ee.data&&(Le.data=Ee.data),J[B]=Le,ie++}r.attributes=J,r.attributesNum=ie,r.index=Z}function S(){const R=r.newAttributes;for(let P=0,V=R.length;P<V;P++)R[P]=0}function E(R){f(R,0)}function f(R,P){const V=r.newAttributes,Z=r.enabledAttributes,J=r.attributeDivisors;V[R]=1,Z[R]===0&&(n.enableVertexAttribArray(R),Z[R]=1),J[R]!==P&&(n.vertexAttribDivisor(R,P),J[R]=P)}function T(){const R=r.newAttributes,P=r.enabledAttributes;for(let V=0,Z=P.length;V<Z;V++)P[V]!==R[V]&&(n.disableVertexAttribArray(V),P[V]=0)}function A(R,P,V,Z,J,$,ie){ie===!0?n.vertexAttribIPointer(R,P,V,J,$):n.vertexAttribPointer(R,P,V,Z,J,$)}function I(R,P,V,Z){S();const J=Z.attributes,$=V.getAttributes(),ie=P.defaultAttributeValues;for(const j in $){const B=$[j];if(B.location>=0){let pe=J[j];if(pe===void 0&&(j==="instanceMatrix"&&R.instanceMatrix&&(pe=R.instanceMatrix),j==="instanceColor"&&R.instanceColor&&(pe=R.instanceColor)),pe!==void 0){const Ee=pe.normalized,Le=pe.itemSize,Ve=e.get(pe);if(Ve===void 0)continue;const Xe=Ve.buffer,X=Ve.type,w=Ve.bytesPerElement,M=X===n.INT||X===n.UNSIGNED_INT||pe.gpuType===Eo;if(pe.isInterleavedBufferAttribute){const g=pe.data,K=g.stride,re=pe.offset;if(g.isInstancedInterleavedBuffer){for(let k=0;k<B.locationSize;k++)f(B.location+k,g.meshPerAttribute);R.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=g.meshPerAttribute*g.count)}else for(let k=0;k<B.locationSize;k++)E(B.location+k);n.bindBuffer(n.ARRAY_BUFFER,Xe);for(let k=0;k<B.locationSize;k++)A(B.location+k,Le/B.locationSize,X,Ee,K*w,(re+Le/B.locationSize*k)*w,M)}else{if(pe.isInstancedBufferAttribute){for(let g=0;g<B.locationSize;g++)f(B.location+g,pe.meshPerAttribute);R.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=pe.meshPerAttribute*pe.count)}else for(let g=0;g<B.locationSize;g++)E(B.location+g);n.bindBuffer(n.ARRAY_BUFFER,Xe);for(let g=0;g<B.locationSize;g++)A(B.location+g,Le/B.locationSize,X,Ee,Le*w,Le/B.locationSize*g*w,M)}}else if(ie!==void 0){const Ee=ie[j];if(Ee!==void 0)switch(Ee.length){case 2:n.vertexAttrib2fv(B.location,Ee);break;case 3:n.vertexAttrib3fv(B.location,Ee);break;case 4:n.vertexAttrib4fv(B.location,Ee);break;default:n.vertexAttrib1fv(B.location,Ee)}}}}T()}function D(){U();for(const R in i){const P=i[R];for(const V in P){const Z=P[V];for(const J in Z)p(Z[J].object),delete Z[J];delete P[V]}delete i[R]}}function O(R){if(i[R.id]===void 0)return;const P=i[R.id];for(const V in P){const Z=P[V];for(const J in Z)p(Z[J].object),delete Z[J];delete P[V]}delete i[R.id]}function C(R){for(const P in i){const V=i[P];if(V[R.id]===void 0)continue;const Z=V[R.id];for(const J in Z)p(Z[J].object),delete Z[J];delete V[R.id]}}function U(){v(),o=!0,r!==s&&(r=s,u(r.object))}function v(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:c,reset:U,resetDefaultState:v,dispose:D,releaseStatesOfGeometry:O,releaseStatesOfProgram:C,initAttributes:S,enableAttribute:E,disableUnusedAttributes:T}}function RE(n,e,t){let i;function s(u){i=u}function r(u,p){n.drawArrays(i,u,p),t.update(p,i,1)}function o(u,p,a){a!==0&&(n.drawArraysInstanced(i,u,p,a),t.update(p,i,a))}function c(u,p,a){if(a===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,u,0,p,0,a);let h=0;for(let m=0;m<a;m++)h+=p[m];t.update(h,i,1)}function d(u,p,a,l){if(a===0)return;const h=e.get("WEBGL_multi_draw");if(h===null)for(let m=0;m<u.length;m++)o(u[m],p[m],l[m]);else{h.multiDrawArraysInstancedWEBGL(i,u,0,p,0,l,0,a);let m=0;for(let S=0;S<a;S++)m+=p[S]*l[S];t.update(m,i,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=c,this.renderMultiDrawInstances=d}function vE(n,e,t,i){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const C=e.get("EXT_texture_filter_anisotropic");s=n.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(C){return!(C!==cn&&i.convert(C)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function c(C){const U=C===Zi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(C!==Un&&i.convert(C)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE)&&C!==Dn&&!U)}function d(C){if(C==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=t.precision!==void 0?t.precision:"highp";const p=d(u);p!==u&&(ze("WebGLRenderer:",u,"not supported, using",p,"instead."),u=p);const a=t.logarithmicDepthBuffer===!0,l=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),h=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),S=n.getParameter(n.MAX_TEXTURE_SIZE),E=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),f=n.getParameter(n.MAX_VERTEX_ATTRIBS),T=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),A=n.getParameter(n.MAX_VARYING_VECTORS),I=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),D=m>0,O=n.getParameter(n.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:d,textureFormatReadable:o,textureTypeReadable:c,precision:u,logarithmicDepthBuffer:a,reversedDepthBuffer:l,maxTextures:h,maxVertexTextures:m,maxTextureSize:S,maxCubemapSize:E,maxAttributes:f,maxVertexUniforms:T,maxVaryings:A,maxFragmentUniforms:I,vertexTextures:D,maxSamples:O}}function ME(n){const e=this;let t=null,i=0,s=!1,r=!1;const o=new On,c=new Ye,d={value:null,needsUpdate:!1};this.uniform=d,this.numPlanes=0,this.numIntersection=0,this.init=function(a,l){const h=a.length!==0||l||i!==0||s;return s=l,i=a.length,h},this.beginShadows=function(){r=!0,p(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(a,l){t=p(a,l,0)},this.setState=function(a,l,h){const m=a.clippingPlanes,S=a.clipIntersection,E=a.clipShadows,f=n.get(a);if(!s||m===null||m.length===0||r&&!E)r?p(null):u();else{const T=r?0:i,A=T*4;let I=f.clippingState||null;d.value=I,I=p(m,l,A,h);for(let D=0;D!==A;++D)I[D]=t[D];f.clippingState=I,this.numIntersection=S?this.numPlanes:0,this.numPlanes+=T}};function u(){d.value!==t&&(d.value=t,d.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function p(a,l,h,m){const S=a!==null?a.length:0;let E=null;if(S!==0){if(E=d.value,m!==!0||E===null){const f=h+S*4,T=l.matrixWorldInverse;c.getNormalMatrix(T),(E===null||E.length<f)&&(E=new Float32Array(f));for(let A=0,I=h;A!==S;++A,I+=4)o.copy(a[A]).applyMatrix4(T,c),o.normal.toArray(E,I),E[I+3]=o.constant}d.value=E,d.needsUpdate=!0}return e.numPlanes=S,e.numIntersection=0,E}}function IE(n){let e=new WeakMap;function t(o,c){return c===La?o.mapping=Yi:c===ya&&(o.mapping=Wi),o}function i(o){if(o&&o.isTexture){const c=o.mapping;if(c===La||c===ya)if(e.has(o)){const d=e.get(o).texture;return t(d,o.mapping)}else{const d=o.image;if(d&&d.height>0){const u=new Vh(d.height);return u.fromEquirectangularTexture(n,o),e.set(o,u),o.addEventListener("dispose",s),t(u.texture,o.mapping)}else return null}}return o}function s(o){const c=o.target;c.removeEventListener("dispose",s);const d=e.get(c);d!==void 0&&(e.delete(c),d.dispose())}function r(){e=new WeakMap}return{get:i,dispose:r}}const Zn=4,vl=[.125,.215,.35,.446,.526,.582],hi=20,LE=256,ls=new Pd,Ml=new Qe;let ra=null,aa=0,oa=0,la=!1;const yE=new G;class Il{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,i=.1,s=100,r={}){const{size:o=256,position:c=yE}=r;ra=this._renderer.getRenderTarget(),aa=this._renderer.getActiveCubeFace(),oa=this._renderer.getActiveMipmapLevel(),la=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const d=this._allocateTargets();return d.depthBuffer=!0,this._sceneToCubeUV(e,i,s,d,c),t>0&&this._blur(d,0,0,t),this._applyPMREM(d),this._cleanup(d),d}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Ol(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=yl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(ra,aa,oa),this._renderer.xr.enabled=la,e.scissorTest=!1,Ni(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Yi||e.mapping===Wi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ra=this._renderer.getRenderTarget(),aa=this._renderer.getActiveCubeFace(),oa=this._renderer.getActiveMipmapLevel(),la=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:en,minFilter:en,generateMipmaps:!1,type:Zi,format:cn,colorSpace:zi,depthBuffer:!1},s=Ll(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Ll(e,t,i);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=OE(r)),this._blurMaterial=CE(r,e,t),this._ggxMaterial=bE(r,e,t)}return s}_compileMaterial(e){const t=new At(new gt,e);this._renderer.compile(t,ls)}_sceneToCubeUV(e,t,i,s,r){const d=new Xt(90,1,t,i),u=[1,-1,1,1,1,1],p=[1,1,1,-1,-1,-1],a=this._renderer,l=a.autoClear,h=a.toneMapping;a.getClearColor(Ml),a.toneMapping=Jn,a.autoClear=!1,a.state.buffers.depth.getReversed()&&(a.setRenderTarget(s),a.clearDepth(),a.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new At(new Si,new Ut({name:"PMREM.Background",side:Lt,depthWrite:!1,depthTest:!1})));const S=this._backgroundBox,E=S.material;let f=!1;const T=e.background;T?T.isColor&&(E.color.copy(T),e.background=null,f=!0):(E.color.copy(Ml),f=!0);for(let A=0;A<6;A++){const I=A%3;I===0?(d.up.set(0,u[A],0),d.position.set(r.x,r.y,r.z),d.lookAt(r.x+p[A],r.y,r.z)):I===1?(d.up.set(0,0,u[A]),d.position.set(r.x,r.y,r.z),d.lookAt(r.x,r.y+p[A],r.z)):(d.up.set(0,u[A],0),d.position.set(r.x,r.y,r.z),d.lookAt(r.x,r.y,r.z+p[A]));const D=this._cubeSize;Ni(s,I*D,A>2?D:0,D,D),a.setRenderTarget(s),f&&a.render(S,d),a.render(e,d)}a.toneMapping=h,a.autoClear=l,e.background=T}_textureToCubeUV(e,t){const i=this._renderer,s=e.mapping===Yi||e.mapping===Wi;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Ol()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=yl());const r=s?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=r;const c=r.uniforms;c.envMap.value=e;const d=this._cubeSize;Ni(t,0,0,3*d,2*d),i.setRenderTarget(t),i.render(o,ls)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const s=this._lodMeshes.length;for(let r=1;r<s;r++)this._applyGGXFilter(e,r-1,r);t.autoClear=i}_applyGGXFilter(e,t,i){const s=this._renderer,r=this._pingPongRenderTarget,o=this._ggxMaterial,c=this._lodMeshes[i];c.material=o;const d=o.uniforms,u=i/(this._lodMeshes.length-1),p=t/(this._lodMeshes.length-1),a=Math.sqrt(u*u-p*p),l=.05+u*.95,h=a*l,{_lodMax:m}=this,S=this._sizeLods[i],E=3*S*(i>m-Zn?i-m+Zn:0),f=4*(this._cubeSize-S);d.envMap.value=e.texture,d.roughness.value=h,d.mipInt.value=m-t,Ni(r,E,f,3*S,2*S),s.setRenderTarget(r),s.render(c,ls),d.envMap.value=r.texture,d.roughness.value=0,d.mipInt.value=m-i,Ni(e,E,f,3*S,2*S),s.setRenderTarget(e),s.render(c,ls)}_blur(e,t,i,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,i,s,"latitudinal",r),this._halfBlur(o,e,i,i,s,"longitudinal",r)}_halfBlur(e,t,i,s,r,o,c){const d=this._renderer,u=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&ft("blur direction must be either latitudinal or longitudinal!");const p=3,a=this._lodMeshes[s];a.material=u;const l=u.uniforms,h=this._sizeLods[i]-1,m=isFinite(r)?Math.PI/(2*h):2*Math.PI/(2*hi-1),S=r/m,E=isFinite(r)?1+Math.floor(p*S):hi;E>hi&&ze(`sigmaRadians, ${r}, is too large and will clip, as it requested ${E} samples when the maximum is set to ${hi}`);const f=[];let T=0;for(let C=0;C<hi;++C){const U=C/S,v=Math.exp(-U*U/2);f.push(v),C===0?T+=v:C<E&&(T+=2*v)}for(let C=0;C<f.length;C++)f[C]=f[C]/T;l.envMap.value=e.texture,l.samples.value=E,l.weights.value=f,l.latitudinal.value=o==="latitudinal",c&&(l.poleAxis.value=c);const{_lodMax:A}=this;l.dTheta.value=m,l.mipInt.value=A-i;const I=this._sizeLods[s],D=3*I*(s>A-Zn?s-A+Zn:0),O=4*(this._cubeSize-I);Ni(t,D,O,3*I,2*I),d.setRenderTarget(t),d.render(a,ls)}}function OE(n){const e=[],t=[],i=[];let s=n;const r=n-Zn+1+vl.length;for(let o=0;o<r;o++){const c=Math.pow(2,s);e.push(c);let d=1/c;o>n-Zn?d=vl[o-n+Zn-1]:o===0&&(d=0),t.push(d);const u=1/(c-2),p=-u,a=1+u,l=[p,p,a,p,a,a,p,p,a,a,p,a],h=6,m=6,S=3,E=2,f=1,T=new Float32Array(S*m*h),A=new Float32Array(E*m*h),I=new Float32Array(f*m*h);for(let O=0;O<h;O++){const C=O%3*2/3-1,U=O>2?0:-1,v=[C,U,0,C+2/3,U,0,C+2/3,U+1,0,C,U,0,C+2/3,U+1,0,C,U+1,0];T.set(v,S*m*O),A.set(l,E*m*O);const R=[O,O,O,O,O,O];I.set(R,f*m*O)}const D=new gt;D.setAttribute("position",new hn(T,S)),D.setAttribute("uv",new hn(A,E)),D.setAttribute("faceIndex",new hn(I,f)),i.push(new At(D,null)),s>Zn&&s--}return{lodMeshes:i,sizeLods:e,sigmas:t}}function Ll(n,e,t){const i=new ei(n,e,t);return i.texture.mapping=gr,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Ni(n,e,t,i,s){n.viewport.set(e,t,i,s),n.scissor.set(e,t,i,s)}function bE(n,e,t){return new Bn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:LE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Rr(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Nn,depthTest:!1,depthWrite:!1})}function CE(n,e,t){const i=new Float32Array(hi),s=new G(0,1,0);return new Bn({name:"SphericalGaussianBlur",defines:{n:hi,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Rr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Nn,depthTest:!1,depthWrite:!1})}function yl(){return new Bn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Rr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Nn,depthTest:!1,depthWrite:!1})}function Ol(){return new Bn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Rr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Nn,depthTest:!1,depthWrite:!1})}function Rr(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function DE(n){let e=new WeakMap,t=null;function i(c){if(c&&c.isTexture){const d=c.mapping,u=d===La||d===ya,p=d===Yi||d===Wi;if(u||p){let a=e.get(c);const l=a!==void 0?a.texture.pmremVersion:0;if(c.isRenderTargetTexture&&c.pmremVersion!==l)return t===null&&(t=new Il(n)),a=u?t.fromEquirectangular(c,a):t.fromCubemap(c,a),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),a.texture;if(a!==void 0)return a.texture;{const h=c.image;return u&&h&&h.height>0||p&&h&&s(h)?(t===null&&(t=new Il(n)),a=u?t.fromEquirectangular(c):t.fromCubemap(c),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),c.addEventListener("dispose",r),a.texture):null}}}return c}function s(c){let d=0;const u=6;for(let p=0;p<u;p++)c[p]!==void 0&&d++;return d===u}function r(c){const d=c.target;d.removeEventListener("dispose",r);const u=e.get(d);u!==void 0&&(e.delete(d),u.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:o}}function NE(n){const e={};function t(i){if(e[i]!==void 0)return e[i];const s=n.getExtension(i);return e[i]=s,s}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const s=t(i);return s===null&&Ts("WebGLRenderer: "+i+" extension not supported."),s}}}function PE(n,e,t,i){const s={},r=new WeakMap;function o(a){const l=a.target;l.index!==null&&e.remove(l.index);for(const m in l.attributes)e.remove(l.attributes[m]);l.removeEventListener("dispose",o),delete s[l.id];const h=r.get(l);h&&(e.remove(h),r.delete(l)),i.releaseStatesOfGeometry(l),l.isInstancedBufferGeometry===!0&&delete l._maxInstanceCount,t.memory.geometries--}function c(a,l){return s[l.id]===!0||(l.addEventListener("dispose",o),s[l.id]=!0,t.memory.geometries++),l}function d(a){const l=a.attributes;for(const h in l)e.update(l[h],n.ARRAY_BUFFER)}function u(a){const l=[],h=a.index,m=a.attributes.position;let S=0;if(h!==null){const T=h.array;S=h.version;for(let A=0,I=T.length;A<I;A+=3){const D=T[A+0],O=T[A+1],C=T[A+2];l.push(D,O,O,C,C,D)}}else if(m!==void 0){const T=m.array;S=m.version;for(let A=0,I=T.length/3-1;A<I;A+=3){const D=A+0,O=A+1,C=A+2;l.push(D,O,O,C,C,D)}}else return;const E=new(Rc(l)?Lc:Ic)(l,1);E.version=S;const f=r.get(a);f&&e.remove(f),r.set(a,E)}function p(a){const l=r.get(a);if(l){const h=a.index;h!==null&&l.version<h.version&&u(a)}else u(a);return r.get(a)}return{get:c,update:d,getWireframeAttribute:p}}function UE(n,e,t){let i;function s(l){i=l}let r,o;function c(l){r=l.type,o=l.bytesPerElement}function d(l,h){n.drawElements(i,h,r,l*o),t.update(h,i,1)}function u(l,h,m){m!==0&&(n.drawElementsInstanced(i,h,r,l*o,m),t.update(h,i,m))}function p(l,h,m){if(m===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,r,l,0,m);let E=0;for(let f=0;f<m;f++)E+=h[f];t.update(E,i,1)}function a(l,h,m,S){if(m===0)return;const E=e.get("WEBGL_multi_draw");if(E===null)for(let f=0;f<l.length;f++)u(l[f]/o,h[f],S[f]);else{E.multiDrawElementsInstancedWEBGL(i,h,0,r,l,0,S,0,m);let f=0;for(let T=0;T<m;T++)f+=h[T]*S[T];t.update(f,i,1)}}this.setMode=s,this.setIndex=c,this.render=d,this.renderInstances=u,this.renderMultiDraw=p,this.renderMultiDrawInstances=a}function wE(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,o,c){switch(t.calls++,o){case n.TRIANGLES:t.triangles+=c*(r/3);break;case n.LINES:t.lines+=c*(r/2);break;case n.LINE_STRIP:t.lines+=c*(r-1);break;case n.LINE_LOOP:t.lines+=c*r;break;case n.POINTS:t.points+=c*r;break;default:ft("WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:i}}function FE(n,e,t){const i=new WeakMap,s=new St;function r(o,c,d){const u=o.morphTargetInfluences,p=c.morphAttributes.position||c.morphAttributes.normal||c.morphAttributes.color,a=p!==void 0?p.length:0;let l=i.get(c);if(l===void 0||l.count!==a){let R=function(){U.dispose(),i.delete(c),c.removeEventListener("dispose",R)};var h=R;l!==void 0&&l.texture.dispose();const m=c.morphAttributes.position!==void 0,S=c.morphAttributes.normal!==void 0,E=c.morphAttributes.color!==void 0,f=c.morphAttributes.position||[],T=c.morphAttributes.normal||[],A=c.morphAttributes.color||[];let I=0;m===!0&&(I=1),S===!0&&(I=2),E===!0&&(I=3);let D=c.attributes.position.count*I,O=1;D>e.maxTextureSize&&(O=Math.ceil(D/e.maxTextureSize),D=e.maxTextureSize);const C=new Float32Array(D*O*4*a),U=new vc(C,D,O,a);U.type=Dn,U.needsUpdate=!0;const v=I*4;for(let P=0;P<a;P++){const V=f[P],Z=T[P],J=A[P],$=D*O*4*P;for(let ie=0;ie<V.count;ie++){const j=ie*v;m===!0&&(s.fromBufferAttribute(V,ie),C[$+j+0]=s.x,C[$+j+1]=s.y,C[$+j+2]=s.z,C[$+j+3]=0),S===!0&&(s.fromBufferAttribute(Z,ie),C[$+j+4]=s.x,C[$+j+5]=s.y,C[$+j+6]=s.z,C[$+j+7]=0),E===!0&&(s.fromBufferAttribute(J,ie),C[$+j+8]=s.x,C[$+j+9]=s.y,C[$+j+10]=s.z,C[$+j+11]=J.itemSize===4?s.w:1)}}l={count:a,texture:U,size:new oe(D,O)},i.set(c,l),c.addEventListener("dispose",R)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)d.getUniforms().setValue(n,"morphTexture",o.morphTexture,t);else{let m=0;for(let E=0;E<u.length;E++)m+=u[E];const S=c.morphTargetsRelative?1:1-m;d.getUniforms().setValue(n,"morphTargetBaseInfluence",S),d.getUniforms().setValue(n,"morphTargetInfluences",u)}d.getUniforms().setValue(n,"morphTargetsTexture",l.texture,t),d.getUniforms().setValue(n,"morphTargetsTextureSize",l.size)}return{update:r}}function BE(n,e,t,i){let s=new WeakMap;function r(d){const u=i.render.frame,p=d.geometry,a=e.get(d,p);if(s.get(a)!==u&&(e.update(a),s.set(a,u)),d.isInstancedMesh&&(d.hasEventListener("dispose",c)===!1&&d.addEventListener("dispose",c),s.get(d)!==u&&(t.update(d.instanceMatrix,n.ARRAY_BUFFER),d.instanceColor!==null&&t.update(d.instanceColor,n.ARRAY_BUFFER),s.set(d,u))),d.isSkinnedMesh){const l=d.skeleton;s.get(l)!==u&&(l.update(),s.set(l,u))}return a}function o(){s=new WeakMap}function c(d){const u=d.target;u.removeEventListener("dispose",c),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:r,dispose:o}}const Wc=new Pt,bl=new Dc(1,1),zc=new vc,Kc=new vh,Xc=new bc,Cl=[],Dl=[],Nl=new Float32Array(16),Pl=new Float32Array(9),Ul=new Float32Array(4);function $i(n,e,t){const i=n[0];if(i<=0||i>0)return n;const s=e*t;let r=Cl[s];if(r===void 0&&(r=new Float32Array(s),Cl[s]=r),e!==0){i.toArray(r,0);for(let o=1,c=0;o!==e;++o)c+=t,n[o].toArray(r,c)}return r}function vt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function Mt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function vr(n,e){let t=Dl[e];t===void 0&&(t=new Int32Array(e),Dl[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function HE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function GE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2fv(this.addr,e),Mt(t,e)}}function VE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(vt(t,e))return;n.uniform3fv(this.addr,e),Mt(t,e)}}function kE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4fv(this.addr,e),Mt(t,e)}}function YE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;Ul.set(i),n.uniformMatrix2fv(this.addr,!1,Ul),Mt(t,i)}}function WE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;Pl.set(i),n.uniformMatrix3fv(this.addr,!1,Pl),Mt(t,i)}}function zE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;Nl.set(i),n.uniformMatrix4fv(this.addr,!1,Nl),Mt(t,i)}}function KE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function XE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2iv(this.addr,e),Mt(t,e)}}function qE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(vt(t,e))return;n.uniform3iv(this.addr,e),Mt(t,e)}}function ZE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4iv(this.addr,e),Mt(t,e)}}function JE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function QE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2uiv(this.addr,e),Mt(t,e)}}function $E(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(vt(t,e))return;n.uniform3uiv(this.addr,e),Mt(t,e)}}function jE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4uiv(this.addr,e),Mt(t,e)}}function em(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r;this.type===n.SAMPLER_2D_SHADOW?(bl.compareFunction=Tc,r=bl):r=Wc,t.setTexture2D(e||r,s)}function tm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture3D(e||Kc,s)}function nm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTextureCube(e||Xc,s)}function im(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture2DArray(e||zc,s)}function sm(n){switch(n){case 5126:return HE;case 35664:return GE;case 35665:return VE;case 35666:return kE;case 35674:return YE;case 35675:return WE;case 35676:return zE;case 5124:case 35670:return KE;case 35667:case 35671:return XE;case 35668:case 35672:return qE;case 35669:case 35673:return ZE;case 5125:return JE;case 36294:return QE;case 36295:return $E;case 36296:return jE;case 35678:case 36198:case 36298:case 36306:case 35682:return em;case 35679:case 36299:case 36307:return tm;case 35680:case 36300:case 36308:case 36293:return nm;case 36289:case 36303:case 36311:case 36292:return im}}function rm(n,e){n.uniform1fv(this.addr,e)}function am(n,e){const t=$i(e,this.size,2);n.uniform2fv(this.addr,t)}function om(n,e){const t=$i(e,this.size,3);n.uniform3fv(this.addr,t)}function lm(n,e){const t=$i(e,this.size,4);n.uniform4fv(this.addr,t)}function cm(n,e){const t=$i(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function um(n,e){const t=$i(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function hm(n,e){const t=$i(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function dm(n,e){n.uniform1iv(this.addr,e)}function fm(n,e){n.uniform2iv(this.addr,e)}function pm(n,e){n.uniform3iv(this.addr,e)}function Em(n,e){n.uniform4iv(this.addr,e)}function mm(n,e){n.uniform1uiv(this.addr,e)}function Sm(n,e){n.uniform2uiv(this.addr,e)}function Am(n,e){n.uniform3uiv(this.addr,e)}function _m(n,e){n.uniform4uiv(this.addr,e)}function xm(n,e,t){const i=this.cache,s=e.length,r=vr(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||Wc,r[o])}function gm(n,e,t){const i=this.cache,s=e.length,r=vr(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Kc,r[o])}function Tm(n,e,t){const i=this.cache,s=e.length,r=vr(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Xc,r[o])}function Rm(n,e,t){const i=this.cache,s=e.length,r=vr(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||zc,r[o])}function vm(n){switch(n){case 5126:return rm;case 35664:return am;case 35665:return om;case 35666:return lm;case 35674:return cm;case 35675:return um;case 35676:return hm;case 5124:case 35670:return dm;case 35667:case 35671:return fm;case 35668:case 35672:return pm;case 35669:case 35673:return Em;case 5125:return mm;case 36294:return Sm;case 36295:return Am;case 36296:return _m;case 35678:case 36198:case 36298:case 36306:case 35682:return xm;case 35679:case 36299:case 36307:return gm;case 35680:case 36300:case 36308:case 36293:return Tm;case 36289:case 36303:case 36311:case 36292:return Rm}}class Mm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=sm(t.type)}}class Im{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=vm(t.type)}}class Lm{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const c=s[r];c.setValue(e,t[c.id],i)}}}const ca=/(\w+)(\])?(\[|\.)?/g;function wl(n,e){n.seq.push(e),n.map[e.id]=e}function ym(n,e,t){const i=n.name,s=i.length;for(ca.lastIndex=0;;){const r=ca.exec(i),o=ca.lastIndex;let c=r[1];const d=r[2]==="]",u=r[3];if(d&&(c=c|0),u===void 0||u==="["&&o+2===s){wl(t,u===void 0?new Mm(c,n,e):new Im(c,n,e));break}else{let a=t.map[c];a===void 0&&(a=new Lm(c),wl(t,a)),t=a}}}class cr{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);ym(r,o,this)}}setValue(e,t,i,s){const r=this.map[t];r!==void 0&&r.setValue(e,i,s)}setOptional(e,t,i){const s=t[i];s!==void 0&&this.setValue(e,i,s)}static upload(e,t,i,s){for(let r=0,o=t.length;r!==o;++r){const c=t[r],d=i[c.id];d.needsUpdate!==!1&&c.setValue(e,d.value,s)}}static seqWithValue(e,t){const i=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in t&&i.push(o)}return i}}function Fl(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const Om=37297;let bm=0;function Cm(n,e){const t=n.split(`
`),i=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){const c=o+1;i.push(`${c===e?">":" "} ${c}: ${t[o]}`)}return i.join(`
`)}const Bl=new Ye;function Dm(n){je._getMatrix(Bl,je.workingColorSpace,n);const e=`mat3( ${Bl.elements.map(t=>t.toFixed(4))} )`;switch(je.getTransfer(n)){case hr:return[e,"LinearTransferOETF"];case st:return[e,"sRGBTransferOETF"];default:return ze("WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function Hl(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=(n.getShaderInfoLog(e)||"").trim();if(i&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const c=parseInt(o[1]);return t.toUpperCase()+`

`+r+`

`+Cm(n.getShaderSource(e),c)}else return r}function Nm(n,e){const t=Dm(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function Pm(n,e){let t;switch(e){case Ju:t="Linear";break;case Qu:t="Reinhard";break;case $u:t="Cineon";break;case ju:t="ACESFilmic";break;case th:t="AgX";break;case nh:t="Neutral";break;case eh:t="Custom";break;default:ze("WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const js=new G;function Um(){je.getLuminanceCoefficients(js);const n=js.x.toFixed(4),e=js.y.toFixed(4),t=js.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function wm(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ds).join(`
`)}function Fm(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function Bm(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){const r=n.getActiveAttrib(e,s),o=r.name;let c=1;r.type===n.FLOAT_MAT2&&(c=2),r.type===n.FLOAT_MAT3&&(c=3),r.type===n.FLOAT_MAT4&&(c=4),t[o]={type:r.type,location:n.getAttribLocation(e,o),locationSize:c}}return t}function ds(n){return n!==""}function Gl(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Vl(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Hm=/^[ \t]*#include +<([\w\d./]+)>/gm;function uo(n){return n.replace(Hm,Vm)}const Gm=new Map;function Vm(n,e){let t=qe[e];if(t===void 0){const i=Gm.get(e);if(i!==void 0)t=qe[i],ze('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return uo(t)}const km=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function kl(n){return n.replace(km,Ym)}function Ym(n,e,t,i){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Yl(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Wm(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===dc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===Ou?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===yn&&(e="SHADOWMAP_TYPE_VSM"),e}function zm(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Yi:case Wi:e="ENVMAP_TYPE_CUBE";break;case gr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Km(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Wi:e="ENVMAP_MODE_REFRACTION";break}return e}function Xm(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case fc:e="ENVMAP_BLENDING_MULTIPLY";break;case qu:e="ENVMAP_BLENDING_MIX";break;case Zu:e="ENVMAP_BLENDING_ADD";break}return e}function qm(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Zm(n,e,t,i){const s=n.getContext(),r=t.defines;let o=t.vertexShader,c=t.fragmentShader;const d=Wm(t),u=zm(t),p=Km(t),a=Xm(t),l=qm(t),h=wm(t),m=Fm(r),S=s.createProgram();let E,f,T=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(E=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ds).join(`
`),E.length>0&&(E+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ds).join(`
`),f.length>0&&(f+=`
`)):(E=[Yl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+p:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ds).join(`
`),f=[Yl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.envMap?"#define "+p:"",t.envMap?"#define "+a:"",l?"#define CUBEUV_TEXEL_WIDTH "+l.texelWidth:"",l?"#define CUBEUV_TEXEL_HEIGHT "+l.texelHeight:"",l?"#define CUBEUV_MAX_MIP "+l.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Jn?"#define TONE_MAPPING":"",t.toneMapping!==Jn?qe.tonemapping_pars_fragment:"",t.toneMapping!==Jn?Pm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,Nm("linearToOutputTexel",t.outputColorSpace),Um(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(ds).join(`
`)),o=uo(o),o=Gl(o,t),o=Vl(o,t),c=uo(c),c=Gl(c,t),c=Vl(c,t),o=kl(o),c=kl(c),t.isRawShaderMaterial!==!0&&(T=`#version 300 es
`,E=[h,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+E,f=["#define varying in",t.glslVersion===Zo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const A=T+E+o,I=T+f+c,D=Fl(s,s.VERTEX_SHADER,A),O=Fl(s,s.FRAGMENT_SHADER,I);s.attachShader(S,D),s.attachShader(S,O),t.index0AttributeName!==void 0?s.bindAttribLocation(S,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(S,0,"position"),s.linkProgram(S);function C(P){if(n.debug.checkShaderErrors){const V=s.getProgramInfoLog(S)||"",Z=s.getShaderInfoLog(D)||"",J=s.getShaderInfoLog(O)||"",$=V.trim(),ie=Z.trim(),j=J.trim();let B=!0,pe=!0;if(s.getProgramParameter(S,s.LINK_STATUS)===!1)if(B=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,S,D,O);else{const Ee=Hl(s,D,"vertex"),Le=Hl(s,O,"fragment");ft("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(S,s.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+$+`
`+Ee+`
`+Le)}else $!==""?ze("WebGLProgram: Program Info Log:",$):(ie===""||j==="")&&(pe=!1);pe&&(P.diagnostics={runnable:B,programLog:$,vertexShader:{log:ie,prefix:E},fragmentShader:{log:j,prefix:f}})}s.deleteShader(D),s.deleteShader(O),U=new cr(s,S),v=Bm(s,S)}let U;this.getUniforms=function(){return U===void 0&&C(this),U};let v;this.getAttributes=function(){return v===void 0&&C(this),v};let R=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return R===!1&&(R=s.getProgramParameter(S,Om)),R},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(S),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=bm++,this.cacheKey=e,this.usedTimes=1,this.program=S,this.vertexShader=D,this.fragmentShader=O,this}let Jm=0;class Qm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(i),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new $m(e),t.set(e,i)),i}}class $m{constructor(e){this.id=Jm++,this.code=e,this.usedTimes=0}}function jm(n,e,t,i,s,r,o){const c=new Mo,d=new Qm,u=new Set,p=[],a=s.logarithmicDepthBuffer,l=s.vertexTextures;let h=s.precision;const m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function S(v){return u.add(v),v===0?"uv":`uv${v}`}function E(v,R,P,V,Z){const J=V.fog,$=Z.geometry,ie=v.isMeshStandardMaterial?V.environment:null,j=(v.isMeshStandardMaterial?t:e).get(v.envMap||ie),B=j&&j.mapping===gr?j.image.height:null,pe=m[v.type];v.precision!==null&&(h=s.getMaxPrecision(v.precision),h!==v.precision&&ze("WebGLProgram.getParameters:",v.precision,"not supported, using",h,"instead."));const Ee=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,Le=Ee!==void 0?Ee.length:0;let Ve=0;$.morphAttributes.position!==void 0&&(Ve=1),$.morphAttributes.normal!==void 0&&(Ve=2),$.morphAttributes.color!==void 0&&(Ve=3);let Xe,X,w,M;if(pe){const nt=mn[pe];Xe=nt.vertexShader,X=nt.fragmentShader}else Xe=v.vertexShader,X=v.fragmentShader,d.update(v),w=d.getVertexShaderID(v),M=d.getFragmentShaderID(v);const g=n.getRenderTarget(),K=n.state.buffers.depth.getReversed(),re=Z.isInstancedMesh===!0,k=Z.isBatchedMesh===!0,ce=!!v.map,Ae=!!v.matcap,ue=!!j,H=!!v.aoMap,x=!!v.lightMap,q=!!v.bumpMap,Q=!!v.normalMap,N=!!v.displacementMap,y=!!v.emissiveMap,ae=!!v.metalnessMap,le=!!v.roughnessMap,Te=v.anisotropy>0,b=v.clearcoat>0,_=v.dispersion>0,Y=v.iridescence>0,se=v.sheen>0,de=v.transmission>0,ne=Te&&!!v.anisotropyMap,De=b&&!!v.clearcoatMap,ge=b&&!!v.clearcoatNormalMap,Ue=b&&!!v.clearcoatRoughnessMap,Ce=Y&&!!v.iridescenceMap,me=Y&&!!v.iridescenceThicknessMap,_e=se&&!!v.sheenColorMap,Ge=se&&!!v.sheenRoughnessMap,Be=!!v.specularMap,Oe=!!v.specularColorMap,We=!!v.specularIntensityMap,F=de&&!!v.transmissionMap,Ie=de&&!!v.thicknessMap,Re=!!v.gradientMap,ve=!!v.alphaMap,Se=v.alphaTest>0,he=!!v.alphaHash,Ne=!!v.extensions;let Ke=Jn;v.toneMapped&&(g===null||g.isXRRenderTarget===!0)&&(Ke=n.toneMapping);const ct={shaderID:pe,shaderType:v.type,shaderName:v.name,vertexShader:Xe,fragmentShader:X,defines:v.defines,customVertexShaderID:w,customFragmentShaderID:M,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:h,batching:k,batchingColor:k&&Z._colorsTexture!==null,instancing:re,instancingColor:re&&Z.instanceColor!==null,instancingMorph:re&&Z.morphTexture!==null,supportsVertexTextures:l,outputColorSpace:g===null?n.outputColorSpace:g.isXRRenderTarget===!0?g.texture.colorSpace:zi,alphaToCoverage:!!v.alphaToCoverage,map:ce,matcap:Ae,envMap:ue,envMapMode:ue&&j.mapping,envMapCubeUVHeight:B,aoMap:H,lightMap:x,bumpMap:q,normalMap:Q,displacementMap:l&&N,emissiveMap:y,normalMapObjectSpace:Q&&v.normalMapType===oh,normalMapTangentSpace:Q&&v.normalMapType===ah,metalnessMap:ae,roughnessMap:le,anisotropy:Te,anisotropyMap:ne,clearcoat:b,clearcoatMap:De,clearcoatNormalMap:ge,clearcoatRoughnessMap:Ue,dispersion:_,iridescence:Y,iridescenceMap:Ce,iridescenceThicknessMap:me,sheen:se,sheenColorMap:_e,sheenRoughnessMap:Ge,specularMap:Be,specularColorMap:Oe,specularIntensityMap:We,transmission:de,transmissionMap:F,thicknessMap:Ie,gradientMap:Re,opaque:v.transparent===!1&&v.blending===Gi&&v.alphaToCoverage===!1,alphaMap:ve,alphaTest:Se,alphaHash:he,combine:v.combine,mapUv:ce&&S(v.map.channel),aoMapUv:H&&S(v.aoMap.channel),lightMapUv:x&&S(v.lightMap.channel),bumpMapUv:q&&S(v.bumpMap.channel),normalMapUv:Q&&S(v.normalMap.channel),displacementMapUv:N&&S(v.displacementMap.channel),emissiveMapUv:y&&S(v.emissiveMap.channel),metalnessMapUv:ae&&S(v.metalnessMap.channel),roughnessMapUv:le&&S(v.roughnessMap.channel),anisotropyMapUv:ne&&S(v.anisotropyMap.channel),clearcoatMapUv:De&&S(v.clearcoatMap.channel),clearcoatNormalMapUv:ge&&S(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&S(v.clearcoatRoughnessMap.channel),iridescenceMapUv:Ce&&S(v.iridescenceMap.channel),iridescenceThicknessMapUv:me&&S(v.iridescenceThicknessMap.channel),sheenColorMapUv:_e&&S(v.sheenColorMap.channel),sheenRoughnessMapUv:Ge&&S(v.sheenRoughnessMap.channel),specularMapUv:Be&&S(v.specularMap.channel),specularColorMapUv:Oe&&S(v.specularColorMap.channel),specularIntensityMapUv:We&&S(v.specularIntensityMap.channel),transmissionMapUv:F&&S(v.transmissionMap.channel),thicknessMapUv:Ie&&S(v.thicknessMap.channel),alphaMapUv:ve&&S(v.alphaMap.channel),vertexTangents:!!$.attributes.tangent&&(Q||Te),vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,pointsUvs:Z.isPoints===!0&&!!$.attributes.uv&&(ce||ve),fog:!!J,useFog:v.fog===!0,fogExp2:!!J&&J.isFogExp2,flatShading:v.flatShading===!0&&v.wireframe===!1,sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:a,reversedDepthBuffer:K,skinning:Z.isSkinnedMesh===!0,morphTargets:$.morphAttributes.position!==void 0,morphNormals:$.morphAttributes.normal!==void 0,morphColors:$.morphAttributes.color!==void 0,morphTargetsCount:Le,morphTextureStride:Ve,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:v.dithering,shadowMapEnabled:n.shadowMap.enabled&&P.length>0,shadowMapType:n.shadowMap.type,toneMapping:Ke,decodeVideoTexture:ce&&v.map.isVideoTexture===!0&&je.getTransfer(v.map.colorSpace)===st,decodeVideoTextureEmissive:y&&v.emissiveMap.isVideoTexture===!0&&je.getTransfer(v.emissiveMap.colorSpace)===st,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===on,flipSided:v.side===Lt,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:Ne&&v.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ne&&v.extensions.multiDraw===!0||k)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return ct.vertexUv1s=u.has(1),ct.vertexUv2s=u.has(2),ct.vertexUv3s=u.has(3),u.clear(),ct}function f(v){const R=[];if(v.shaderID?R.push(v.shaderID):(R.push(v.customVertexShaderID),R.push(v.customFragmentShaderID)),v.defines!==void 0)for(const P in v.defines)R.push(P),R.push(v.defines[P]);return v.isRawShaderMaterial===!1&&(T(R,v),A(R,v),R.push(n.outputColorSpace)),R.push(v.customProgramCacheKey),R.join()}function T(v,R){v.push(R.precision),v.push(R.outputColorSpace),v.push(R.envMapMode),v.push(R.envMapCubeUVHeight),v.push(R.mapUv),v.push(R.alphaMapUv),v.push(R.lightMapUv),v.push(R.aoMapUv),v.push(R.bumpMapUv),v.push(R.normalMapUv),v.push(R.displacementMapUv),v.push(R.emissiveMapUv),v.push(R.metalnessMapUv),v.push(R.roughnessMapUv),v.push(R.anisotropyMapUv),v.push(R.clearcoatMapUv),v.push(R.clearcoatNormalMapUv),v.push(R.clearcoatRoughnessMapUv),v.push(R.iridescenceMapUv),v.push(R.iridescenceThicknessMapUv),v.push(R.sheenColorMapUv),v.push(R.sheenRoughnessMapUv),v.push(R.specularMapUv),v.push(R.specularColorMapUv),v.push(R.specularIntensityMapUv),v.push(R.transmissionMapUv),v.push(R.thicknessMapUv),v.push(R.combine),v.push(R.fogExp2),v.push(R.sizeAttenuation),v.push(R.morphTargetsCount),v.push(R.morphAttributeCount),v.push(R.numDirLights),v.push(R.numPointLights),v.push(R.numSpotLights),v.push(R.numSpotLightMaps),v.push(R.numHemiLights),v.push(R.numRectAreaLights),v.push(R.numDirLightShadows),v.push(R.numPointLightShadows),v.push(R.numSpotLightShadows),v.push(R.numSpotLightShadowsWithMaps),v.push(R.numLightProbes),v.push(R.shadowMapType),v.push(R.toneMapping),v.push(R.numClippingPlanes),v.push(R.numClipIntersection),v.push(R.depthPacking)}function A(v,R){c.disableAll(),R.supportsVertexTextures&&c.enable(0),R.instancing&&c.enable(1),R.instancingColor&&c.enable(2),R.instancingMorph&&c.enable(3),R.matcap&&c.enable(4),R.envMap&&c.enable(5),R.normalMapObjectSpace&&c.enable(6),R.normalMapTangentSpace&&c.enable(7),R.clearcoat&&c.enable(8),R.iridescence&&c.enable(9),R.alphaTest&&c.enable(10),R.vertexColors&&c.enable(11),R.vertexAlphas&&c.enable(12),R.vertexUv1s&&c.enable(13),R.vertexUv2s&&c.enable(14),R.vertexUv3s&&c.enable(15),R.vertexTangents&&c.enable(16),R.anisotropy&&c.enable(17),R.alphaHash&&c.enable(18),R.batching&&c.enable(19),R.dispersion&&c.enable(20),R.batchingColor&&c.enable(21),R.gradientMap&&c.enable(22),v.push(c.mask),c.disableAll(),R.fog&&c.enable(0),R.useFog&&c.enable(1),R.flatShading&&c.enable(2),R.logarithmicDepthBuffer&&c.enable(3),R.reversedDepthBuffer&&c.enable(4),R.skinning&&c.enable(5),R.morphTargets&&c.enable(6),R.morphNormals&&c.enable(7),R.morphColors&&c.enable(8),R.premultipliedAlpha&&c.enable(9),R.shadowMapEnabled&&c.enable(10),R.doubleSided&&c.enable(11),R.flipSided&&c.enable(12),R.useDepthPacking&&c.enable(13),R.dithering&&c.enable(14),R.transmission&&c.enable(15),R.sheen&&c.enable(16),R.opaque&&c.enable(17),R.pointsUvs&&c.enable(18),R.decodeVideoTexture&&c.enable(19),R.decodeVideoTextureEmissive&&c.enable(20),R.alphaToCoverage&&c.enable(21),v.push(c.mask)}function I(v){const R=m[v.type];let P;if(R){const V=mn[R];P=Fh.clone(V.uniforms)}else P=v.uniforms;return P}function D(v,R){let P;for(let V=0,Z=p.length;V<Z;V++){const J=p[V];if(J.cacheKey===R){P=J,++P.usedTimes;break}}return P===void 0&&(P=new Zm(n,R,v,r),p.push(P)),P}function O(v){if(--v.usedTimes===0){const R=p.indexOf(v);p[R]=p[p.length-1],p.pop(),v.destroy()}}function C(v){d.remove(v)}function U(){d.dispose()}return{getParameters:E,getProgramCacheKey:f,getUniforms:I,acquireProgram:D,releaseProgram:O,releaseShaderCache:C,programs:p,dispose:U}}function eS(){let n=new WeakMap;function e(o){return n.has(o)}function t(o){let c=n.get(o);return c===void 0&&(c={},n.set(o,c)),c}function i(o){n.delete(o)}function s(o,c,d){n.get(o)[c]=d}function r(){n=new WeakMap}return{has:e,get:t,remove:i,update:s,dispose:r}}function tS(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Wl(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function zl(){const n=[];let e=0;const t=[],i=[],s=[];function r(){e=0,t.length=0,i.length=0,s.length=0}function o(a,l,h,m,S,E){let f=n[e];return f===void 0?(f={id:a.id,object:a,geometry:l,material:h,groupOrder:m,renderOrder:a.renderOrder,z:S,group:E},n[e]=f):(f.id=a.id,f.object=a,f.geometry=l,f.material=h,f.groupOrder=m,f.renderOrder=a.renderOrder,f.z=S,f.group=E),e++,f}function c(a,l,h,m,S,E){const f=o(a,l,h,m,S,E);h.transmission>0?i.push(f):h.transparent===!0?s.push(f):t.push(f)}function d(a,l,h,m,S,E){const f=o(a,l,h,m,S,E);h.transmission>0?i.unshift(f):h.transparent===!0?s.unshift(f):t.unshift(f)}function u(a,l){t.length>1&&t.sort(a||tS),i.length>1&&i.sort(l||Wl),s.length>1&&s.sort(l||Wl)}function p(){for(let a=e,l=n.length;a<l;a++){const h=n[a];if(h.id===null)break;h.id=null,h.object=null,h.geometry=null,h.material=null,h.group=null}}return{opaque:t,transmissive:i,transparent:s,init:r,push:c,unshift:d,finish:p,sort:u}}function nS(){let n=new WeakMap;function e(i,s){const r=n.get(i);let o;return r===void 0?(o=new zl,n.set(i,[o])):s>=r.length?(o=new zl,r.push(o)):o=r[s],o}function t(){n=new WeakMap}return{get:e,dispose:t}}function iS(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new G,color:new Qe};break;case"SpotLight":t={position:new G,direction:new G,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new G,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new G,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":t={color:new Qe,position:new G,halfWidth:new G,halfHeight:new G};break}return n[e.id]=t,t}}}function sS(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let rS=0;function aS(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function oS(n){const e=new iS,t=sS(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)i.probe.push(new G);const s=new G,r=new _t,o=new _t;function c(u){let p=0,a=0,l=0;for(let v=0;v<9;v++)i.probe[v].set(0,0,0);let h=0,m=0,S=0,E=0,f=0,T=0,A=0,I=0,D=0,O=0,C=0;u.sort(aS);for(let v=0,R=u.length;v<R;v++){const P=u[v],V=P.color,Z=P.intensity,J=P.distance,$=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)p+=V.r*Z,a+=V.g*Z,l+=V.b*Z;else if(P.isLightProbe){for(let ie=0;ie<9;ie++)i.probe[ie].addScaledVector(P.sh.coefficients[ie],Z);C++}else if(P.isDirectionalLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){const j=P.shadow,B=t.get(P);B.shadowIntensity=j.intensity,B.shadowBias=j.bias,B.shadowNormalBias=j.normalBias,B.shadowRadius=j.radius,B.shadowMapSize=j.mapSize,i.directionalShadow[h]=B,i.directionalShadowMap[h]=$,i.directionalShadowMatrix[h]=P.shadow.matrix,T++}i.directional[h]=ie,h++}else if(P.isSpotLight){const ie=e.get(P);ie.position.setFromMatrixPosition(P.matrixWorld),ie.color.copy(V).multiplyScalar(Z),ie.distance=J,ie.coneCos=Math.cos(P.angle),ie.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),ie.decay=P.decay,i.spot[S]=ie;const j=P.shadow;if(P.map&&(i.spotLightMap[D]=P.map,D++,j.updateMatrices(P),P.castShadow&&O++),i.spotLightMatrix[S]=j.matrix,P.castShadow){const B=t.get(P);B.shadowIntensity=j.intensity,B.shadowBias=j.bias,B.shadowNormalBias=j.normalBias,B.shadowRadius=j.radius,B.shadowMapSize=j.mapSize,i.spotShadow[S]=B,i.spotShadowMap[S]=$,I++}S++}else if(P.isRectAreaLight){const ie=e.get(P);ie.color.copy(V).multiplyScalar(Z),ie.halfWidth.set(P.width*.5,0,0),ie.halfHeight.set(0,P.height*.5,0),i.rectArea[E]=ie,E++}else if(P.isPointLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),ie.distance=P.distance,ie.decay=P.decay,P.castShadow){const j=P.shadow,B=t.get(P);B.shadowIntensity=j.intensity,B.shadowBias=j.bias,B.shadowNormalBias=j.normalBias,B.shadowRadius=j.radius,B.shadowMapSize=j.mapSize,B.shadowCameraNear=j.camera.near,B.shadowCameraFar=j.camera.far,i.pointShadow[m]=B,i.pointShadowMap[m]=$,i.pointShadowMatrix[m]=P.shadow.matrix,A++}i.point[m]=ie,m++}else if(P.isHemisphereLight){const ie=e.get(P);ie.skyColor.copy(P.color).multiplyScalar(Z),ie.groundColor.copy(P.groundColor).multiplyScalar(Z),i.hemi[f]=ie,f++}}E>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=Me.LTC_FLOAT_1,i.rectAreaLTC2=Me.LTC_FLOAT_2):(i.rectAreaLTC1=Me.LTC_HALF_1,i.rectAreaLTC2=Me.LTC_HALF_2)),i.ambient[0]=p,i.ambient[1]=a,i.ambient[2]=l;const U=i.hash;(U.directionalLength!==h||U.pointLength!==m||U.spotLength!==S||U.rectAreaLength!==E||U.hemiLength!==f||U.numDirectionalShadows!==T||U.numPointShadows!==A||U.numSpotShadows!==I||U.numSpotMaps!==D||U.numLightProbes!==C)&&(i.directional.length=h,i.spot.length=S,i.rectArea.length=E,i.point.length=m,i.hemi.length=f,i.directionalShadow.length=T,i.directionalShadowMap.length=T,i.pointShadow.length=A,i.pointShadowMap.length=A,i.spotShadow.length=I,i.spotShadowMap.length=I,i.directionalShadowMatrix.length=T,i.pointShadowMatrix.length=A,i.spotLightMatrix.length=I+D-O,i.spotLightMap.length=D,i.numSpotLightShadowsWithMaps=O,i.numLightProbes=C,U.directionalLength=h,U.pointLength=m,U.spotLength=S,U.rectAreaLength=E,U.hemiLength=f,U.numDirectionalShadows=T,U.numPointShadows=A,U.numSpotShadows=I,U.numSpotMaps=D,U.numLightProbes=C,i.version=rS++)}function d(u,p){let a=0,l=0,h=0,m=0,S=0;const E=p.matrixWorldInverse;for(let f=0,T=u.length;f<T;f++){const A=u[f];if(A.isDirectionalLight){const I=i.directional[a];I.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),I.direction.sub(s),I.direction.transformDirection(E),a++}else if(A.isSpotLight){const I=i.spot[h];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),I.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),I.direction.sub(s),I.direction.transformDirection(E),h++}else if(A.isRectAreaLight){const I=i.rectArea[m];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),o.identity(),r.copy(A.matrixWorld),r.premultiply(E),o.extractRotation(r),I.halfWidth.set(A.width*.5,0,0),I.halfHeight.set(0,A.height*.5,0),I.halfWidth.applyMatrix4(o),I.halfHeight.applyMatrix4(o),m++}else if(A.isPointLight){const I=i.point[l];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),l++}else if(A.isHemisphereLight){const I=i.hemi[S];I.direction.setFromMatrixPosition(A.matrixWorld),I.direction.transformDirection(E),S++}}}return{setup:c,setupView:d,state:i}}function Kl(n){const e=new oS(n),t=[],i=[];function s(p){u.camera=p,t.length=0,i.length=0}function r(p){t.push(p)}function o(p){i.push(p)}function c(){e.setup(t)}function d(p){e.setupView(t,p)}const u={lightsArray:t,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:u,setupLights:c,setupLightsView:d,pushLight:r,pushShadow:o}}function lS(n){let e=new WeakMap;function t(s,r=0){const o=e.get(s);let c;return o===void 0?(c=new Kl(n),e.set(s,[c])):r>=o.length?(c=new Kl(n),o.push(c)):c=o[r],c}function i(){e=new WeakMap}return{get:t,dispose:i}}const cS=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,uS=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function hS(n,e,t){let i=new Cc;const s=new oe,r=new oe,o=new St,c=new yd({depthPacking:rh}),d=new Od,u={},p=t.maxTextureSize,a={[_n]:Lt,[Lt]:_n,[on]:on},l=new Bn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new oe},radius:{value:4}},vertexShader:cS,fragmentShader:uS}),h=l.clone();h.defines.HORIZONTAL_PASS=1;const m=new gt;m.setAttribute("position",new hn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const S=new At(m,l),E=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=dc;let f=this.type;this.render=function(O,C,U){if(E.enabled===!1||E.autoUpdate===!1&&E.needsUpdate===!1||O.length===0)return;const v=n.getRenderTarget(),R=n.getActiveCubeFace(),P=n.getActiveMipmapLevel(),V=n.state;V.setBlending(Nn),V.buffers.depth.getReversed()===!0?V.buffers.color.setClear(0,0,0,0):V.buffers.color.setClear(1,1,1,1),V.buffers.depth.setTest(!0),V.setScissorTest(!1);const Z=f!==yn&&this.type===yn,J=f===yn&&this.type!==yn;for(let $=0,ie=O.length;$<ie;$++){const j=O[$],B=j.shadow;if(B===void 0){ze("WebGLShadowMap:",j,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;s.copy(B.mapSize);const pe=B.getFrameExtents();if(s.multiply(pe),r.copy(B.mapSize),(s.x>p||s.y>p)&&(s.x>p&&(r.x=Math.floor(p/pe.x),s.x=r.x*pe.x,B.mapSize.x=r.x),s.y>p&&(r.y=Math.floor(p/pe.y),s.y=r.y*pe.y,B.mapSize.y=r.y)),B.map===null||Z===!0||J===!0){const Le=this.type!==yn?{minFilter:qt,magFilter:qt}:{};B.map!==null&&B.map.dispose(),B.map=new ei(s.x,s.y,Le),B.map.texture.name=j.name+".shadowMap",B.camera.updateProjectionMatrix()}n.setRenderTarget(B.map),n.clear();const Ee=B.getViewportCount();for(let Le=0;Le<Ee;Le++){const Ve=B.getViewport(Le);o.set(r.x*Ve.x,r.y*Ve.y,r.x*Ve.z,r.y*Ve.w),V.viewport(o),B.updateMatrices(j,Le),i=B.getFrustum(),I(C,U,B.camera,j,this.type)}B.isPointLightShadow!==!0&&this.type===yn&&T(B,U),B.needsUpdate=!1}f=this.type,E.needsUpdate=!1,n.setRenderTarget(v,R,P)};function T(O,C){const U=e.update(S);l.defines.VSM_SAMPLES!==O.blurSamples&&(l.defines.VSM_SAMPLES=O.blurSamples,h.defines.VSM_SAMPLES=O.blurSamples,l.needsUpdate=!0,h.needsUpdate=!0),O.mapPass===null&&(O.mapPass=new ei(s.x,s.y)),l.uniforms.shadow_pass.value=O.map.texture,l.uniforms.resolution.value=O.mapSize,l.uniforms.radius.value=O.radius,n.setRenderTarget(O.mapPass),n.clear(),n.renderBufferDirect(C,null,U,l,S,null),h.uniforms.shadow_pass.value=O.mapPass.texture,h.uniforms.resolution.value=O.mapSize,h.uniforms.radius.value=O.radius,n.setRenderTarget(O.map),n.clear(),n.renderBufferDirect(C,null,U,h,S,null)}function A(O,C,U,v){let R=null;const P=U.isPointLight===!0?O.customDistanceMaterial:O.customDepthMaterial;if(P!==void 0)R=P;else if(R=U.isPointLight===!0?d:c,n.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0||C.alphaToCoverage===!0){const V=R.uuid,Z=C.uuid;let J=u[V];J===void 0&&(J={},u[V]=J);let $=J[Z];$===void 0&&($=R.clone(),J[Z]=$,C.addEventListener("dispose",D)),R=$}if(R.visible=C.visible,R.wireframe=C.wireframe,v===yn?R.side=C.shadowSide!==null?C.shadowSide:C.side:R.side=C.shadowSide!==null?C.shadowSide:a[C.side],R.alphaMap=C.alphaMap,R.alphaTest=C.alphaToCoverage===!0?.5:C.alphaTest,R.map=C.map,R.clipShadows=C.clipShadows,R.clippingPlanes=C.clippingPlanes,R.clipIntersection=C.clipIntersection,R.displacementMap=C.displacementMap,R.displacementScale=C.displacementScale,R.displacementBias=C.displacementBias,R.wireframeLinewidth=C.wireframeLinewidth,R.linewidth=C.linewidth,U.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const V=n.properties.get(R);V.light=U}return R}function I(O,C,U,v,R){if(O.visible===!1)return;if(O.layers.test(C.layers)&&(O.isMesh||O.isLine||O.isPoints)&&(O.castShadow||O.receiveShadow&&R===yn)&&(!O.frustumCulled||i.intersectsObject(O))){O.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,O.matrixWorld);const Z=e.update(O),J=O.material;if(Array.isArray(J)){const $=Z.groups;for(let ie=0,j=$.length;ie<j;ie++){const B=$[ie],pe=J[B.materialIndex];if(pe&&pe.visible){const Ee=A(O,pe,v,R);O.onBeforeShadow(n,O,C,U,Z,Ee,B),n.renderBufferDirect(U,null,Z,Ee,O,B),O.onAfterShadow(n,O,C,U,Z,Ee,B)}}}else if(J.visible){const $=A(O,J,v,R);O.onBeforeShadow(n,O,C,U,Z,$,null),n.renderBufferDirect(U,null,Z,$,O,null),O.onAfterShadow(n,O,C,U,Z,$,null)}}const V=O.children;for(let Z=0,J=V.length;Z<J;Z++)I(V[Z],C,U,v,R)}function D(O){O.target.removeEventListener("dispose",D);for(const U in u){const v=u[U],R=O.target.uuid;R in v&&(v[R].dispose(),delete v[R])}}}const dS={[xa]:ga,[Ta]:Ma,[Ra]:Ia,[ki]:va,[ga]:xa,[Ma]:Ta,[Ia]:Ra,[va]:ki};function fS(n,e){function t(){let F=!1;const Ie=new St;let Re=null;const ve=new St(0,0,0,0);return{setMask:function(Se){Re!==Se&&!F&&(n.colorMask(Se,Se,Se,Se),Re=Se)},setLocked:function(Se){F=Se},setClear:function(Se,he,Ne,Ke,ct){ct===!0&&(Se*=Ke,he*=Ke,Ne*=Ke),Ie.set(Se,he,Ne,Ke),ve.equals(Ie)===!1&&(n.clearColor(Se,he,Ne,Ke),ve.copy(Ie))},reset:function(){F=!1,Re=null,ve.set(-1,0,0,0)}}}function i(){let F=!1,Ie=!1,Re=null,ve=null,Se=null;return{setReversed:function(he){if(Ie!==he){const Ne=e.get("EXT_clip_control");he?Ne.clipControlEXT(Ne.LOWER_LEFT_EXT,Ne.ZERO_TO_ONE_EXT):Ne.clipControlEXT(Ne.LOWER_LEFT_EXT,Ne.NEGATIVE_ONE_TO_ONE_EXT),Ie=he;const Ke=Se;Se=null,this.setClear(Ke)}},getReversed:function(){return Ie},setTest:function(he){he?g(n.DEPTH_TEST):K(n.DEPTH_TEST)},setMask:function(he){Re!==he&&!F&&(n.depthMask(he),Re=he)},setFunc:function(he){if(Ie&&(he=dS[he]),ve!==he){switch(he){case xa:n.depthFunc(n.NEVER);break;case ga:n.depthFunc(n.ALWAYS);break;case Ta:n.depthFunc(n.LESS);break;case ki:n.depthFunc(n.LEQUAL);break;case Ra:n.depthFunc(n.EQUAL);break;case va:n.depthFunc(n.GEQUAL);break;case Ma:n.depthFunc(n.GREATER);break;case Ia:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}ve=he}},setLocked:function(he){F=he},setClear:function(he){Se!==he&&(Ie&&(he=1-he),n.clearDepth(he),Se=he)},reset:function(){F=!1,Re=null,ve=null,Se=null,Ie=!1}}}function s(){let F=!1,Ie=null,Re=null,ve=null,Se=null,he=null,Ne=null,Ke=null,ct=null;return{setTest:function(nt){F||(nt?g(n.STENCIL_TEST):K(n.STENCIL_TEST))},setMask:function(nt){Ie!==nt&&!F&&(n.stencilMask(nt),Ie=nt)},setFunc:function(nt,dn,nn){(Re!==nt||ve!==dn||Se!==nn)&&(n.stencilFunc(nt,dn,nn),Re=nt,ve=dn,Se=nn)},setOp:function(nt,dn,nn){(he!==nt||Ne!==dn||Ke!==nn)&&(n.stencilOp(nt,dn,nn),he=nt,Ne=dn,Ke=nn)},setLocked:function(nt){F=nt},setClear:function(nt){ct!==nt&&(n.clearStencil(nt),ct=nt)},reset:function(){F=!1,Ie=null,Re=null,ve=null,Se=null,he=null,Ne=null,Ke=null,ct=null}}}const r=new t,o=new i,c=new s,d=new WeakMap,u=new WeakMap;let p={},a={},l=new WeakMap,h=[],m=null,S=!1,E=null,f=null,T=null,A=null,I=null,D=null,O=null,C=new Qe(0,0,0),U=0,v=!1,R=null,P=null,V=null,Z=null,J=null;const $=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let ie=!1,j=0;const B=n.getParameter(n.VERSION);B.indexOf("WebGL")!==-1?(j=parseFloat(/^WebGL (\d)/.exec(B)[1]),ie=j>=1):B.indexOf("OpenGL ES")!==-1&&(j=parseFloat(/^OpenGL ES (\d)/.exec(B)[1]),ie=j>=2);let pe=null,Ee={};const Le=n.getParameter(n.SCISSOR_BOX),Ve=n.getParameter(n.VIEWPORT),Xe=new St().fromArray(Le),X=new St().fromArray(Ve);function w(F,Ie,Re,ve){const Se=new Uint8Array(4),he=n.createTexture();n.bindTexture(F,he),n.texParameteri(F,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(F,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Ne=0;Ne<Re;Ne++)F===n.TEXTURE_3D||F===n.TEXTURE_2D_ARRAY?n.texImage3D(Ie,0,n.RGBA,1,1,ve,0,n.RGBA,n.UNSIGNED_BYTE,Se):n.texImage2D(Ie+Ne,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Se);return he}const M={};M[n.TEXTURE_2D]=w(n.TEXTURE_2D,n.TEXTURE_2D,1),M[n.TEXTURE_CUBE_MAP]=w(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),M[n.TEXTURE_2D_ARRAY]=w(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),M[n.TEXTURE_3D]=w(n.TEXTURE_3D,n.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),c.setClear(0),g(n.DEPTH_TEST),o.setFunc(ki),q(!1),Q(Yo),g(n.CULL_FACE),H(Nn);function g(F){p[F]!==!0&&(n.enable(F),p[F]=!0)}function K(F){p[F]!==!1&&(n.disable(F),p[F]=!1)}function re(F,Ie){return a[F]!==Ie?(n.bindFramebuffer(F,Ie),a[F]=Ie,F===n.DRAW_FRAMEBUFFER&&(a[n.FRAMEBUFFER]=Ie),F===n.FRAMEBUFFER&&(a[n.DRAW_FRAMEBUFFER]=Ie),!0):!1}function k(F,Ie){let Re=h,ve=!1;if(F){Re=l.get(Ie),Re===void 0&&(Re=[],l.set(Ie,Re));const Se=F.textures;if(Re.length!==Se.length||Re[0]!==n.COLOR_ATTACHMENT0){for(let he=0,Ne=Se.length;he<Ne;he++)Re[he]=n.COLOR_ATTACHMENT0+he;Re.length=Se.length,ve=!0}}else Re[0]!==n.BACK&&(Re[0]=n.BACK,ve=!0);ve&&n.drawBuffers(Re)}function ce(F){return m!==F?(n.useProgram(F),m=F,!0):!1}const Ae={[ui]:n.FUNC_ADD,[Cu]:n.FUNC_SUBTRACT,[Du]:n.FUNC_REVERSE_SUBTRACT};Ae[Nu]=n.MIN,Ae[Pu]=n.MAX;const ue={[Uu]:n.ZERO,[wu]:n.ONE,[Fu]:n.SRC_COLOR,[Aa]:n.SRC_ALPHA,[Yu]:n.SRC_ALPHA_SATURATE,[Vu]:n.DST_COLOR,[Hu]:n.DST_ALPHA,[Bu]:n.ONE_MINUS_SRC_COLOR,[_a]:n.ONE_MINUS_SRC_ALPHA,[ku]:n.ONE_MINUS_DST_COLOR,[Gu]:n.ONE_MINUS_DST_ALPHA,[Wu]:n.CONSTANT_COLOR,[zu]:n.ONE_MINUS_CONSTANT_COLOR,[Ku]:n.CONSTANT_ALPHA,[Xu]:n.ONE_MINUS_CONSTANT_ALPHA};function H(F,Ie,Re,ve,Se,he,Ne,Ke,ct,nt){if(F===Nn){S===!0&&(K(n.BLEND),S=!1);return}if(S===!1&&(g(n.BLEND),S=!0),F!==bu){if(F!==E||nt!==v){if((f!==ui||I!==ui)&&(n.blendEquation(n.FUNC_ADD),f=ui,I=ui),nt)switch(F){case Gi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Wo:n.blendFunc(n.ONE,n.ONE);break;case zo:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ko:n.blendFuncSeparate(n.DST_COLOR,n.ONE_MINUS_SRC_ALPHA,n.ZERO,n.ONE);break;default:ft("WebGLState: Invalid blending: ",F);break}else switch(F){case Gi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Wo:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE,n.ONE,n.ONE);break;case zo:ft("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Ko:ft("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:ft("WebGLState: Invalid blending: ",F);break}T=null,A=null,D=null,O=null,C.set(0,0,0),U=0,E=F,v=nt}return}Se=Se||Ie,he=he||Re,Ne=Ne||ve,(Ie!==f||Se!==I)&&(n.blendEquationSeparate(Ae[Ie],Ae[Se]),f=Ie,I=Se),(Re!==T||ve!==A||he!==D||Ne!==O)&&(n.blendFuncSeparate(ue[Re],ue[ve],ue[he],ue[Ne]),T=Re,A=ve,D=he,O=Ne),(Ke.equals(C)===!1||ct!==U)&&(n.blendColor(Ke.r,Ke.g,Ke.b,ct),C.copy(Ke),U=ct),E=F,v=!1}function x(F,Ie){F.side===on?K(n.CULL_FACE):g(n.CULL_FACE);let Re=F.side===Lt;Ie&&(Re=!Re),q(Re),F.blending===Gi&&F.transparent===!1?H(Nn):H(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.blendColor,F.blendAlpha,F.premultipliedAlpha),o.setFunc(F.depthFunc),o.setTest(F.depthTest),o.setMask(F.depthWrite),r.setMask(F.colorWrite);const ve=F.stencilWrite;c.setTest(ve),ve&&(c.setMask(F.stencilWriteMask),c.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),c.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),y(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?g(n.SAMPLE_ALPHA_TO_COVERAGE):K(n.SAMPLE_ALPHA_TO_COVERAGE)}function q(F){R!==F&&(F?n.frontFace(n.CW):n.frontFace(n.CCW),R=F)}function Q(F){F!==Lu?(g(n.CULL_FACE),F!==P&&(F===Yo?n.cullFace(n.BACK):F===yu?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):K(n.CULL_FACE),P=F}function N(F){F!==V&&(ie&&n.lineWidth(F),V=F)}function y(F,Ie,Re){F?(g(n.POLYGON_OFFSET_FILL),(Z!==Ie||J!==Re)&&(n.polygonOffset(Ie,Re),Z=Ie,J=Re)):K(n.POLYGON_OFFSET_FILL)}function ae(F){F?g(n.SCISSOR_TEST):K(n.SCISSOR_TEST)}function le(F){F===void 0&&(F=n.TEXTURE0+$-1),pe!==F&&(n.activeTexture(F),pe=F)}function Te(F,Ie,Re){Re===void 0&&(pe===null?Re=n.TEXTURE0+$-1:Re=pe);let ve=Ee[Re];ve===void 0&&(ve={type:void 0,texture:void 0},Ee[Re]=ve),(ve.type!==F||ve.texture!==Ie)&&(pe!==Re&&(n.activeTexture(Re),pe=Re),n.bindTexture(F,Ie||M[F]),ve.type=F,ve.texture=Ie)}function b(){const F=Ee[pe];F!==void 0&&F.type!==void 0&&(n.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function _(){try{n.compressedTexImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Y(){try{n.compressedTexImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function se(){try{n.texSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function de(){try{n.texSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ne(){try{n.compressedTexSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function De(){try{n.compressedTexSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ge(){try{n.texStorage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Ue(){try{n.texStorage3D(...arguments)}catch(F){F("WebGLState:",F)}}function Ce(){try{n.texImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function me(){try{n.texImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function _e(F){Xe.equals(F)===!1&&(n.scissor(F.x,F.y,F.z,F.w),Xe.copy(F))}function Ge(F){X.equals(F)===!1&&(n.viewport(F.x,F.y,F.z,F.w),X.copy(F))}function Be(F,Ie){let Re=u.get(Ie);Re===void 0&&(Re=new WeakMap,u.set(Ie,Re));let ve=Re.get(F);ve===void 0&&(ve=n.getUniformBlockIndex(Ie,F.name),Re.set(F,ve))}function Oe(F,Ie){const ve=u.get(Ie).get(F);d.get(Ie)!==ve&&(n.uniformBlockBinding(Ie,ve,F.__bindingPointIndex),d.set(Ie,ve))}function We(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),o.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),p={},pe=null,Ee={},a={},l=new WeakMap,h=[],m=null,S=!1,E=null,f=null,T=null,A=null,I=null,D=null,O=null,C=new Qe(0,0,0),U=0,v=!1,R=null,P=null,V=null,Z=null,J=null,Xe.set(0,0,n.canvas.width,n.canvas.height),X.set(0,0,n.canvas.width,n.canvas.height),r.reset(),o.reset(),c.reset()}return{buffers:{color:r,depth:o,stencil:c},enable:g,disable:K,bindFramebuffer:re,drawBuffers:k,useProgram:ce,setBlending:H,setMaterial:x,setFlipSided:q,setCullFace:Q,setLineWidth:N,setPolygonOffset:y,setScissorTest:ae,activeTexture:le,bindTexture:Te,unbindTexture:b,compressedTexImage2D:_,compressedTexImage3D:Y,texImage2D:Ce,texImage3D:me,updateUBOMapping:Be,uniformBlockBinding:Oe,texStorage2D:ge,texStorage3D:Ue,texSubImage2D:se,texSubImage3D:de,compressedTexSubImage2D:ne,compressedTexSubImage3D:De,scissor:_e,viewport:Ge,reset:We}}function pS(n,e,t,i,s,r,o){const c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,d=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new oe,p=new WeakMap;let a;const l=new WeakMap;let h=!1;try{h=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(b,_){return h?new OffscreenCanvas(b,_):fr("canvas")}function S(b,_,Y){let se=1;const de=Te(b);if((de.width>Y||de.height>Y)&&(se=Y/Math.max(de.width,de.height)),se<1)if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&b instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&b instanceof ImageBitmap||typeof VideoFrame<"u"&&b instanceof VideoFrame){const ne=Math.floor(se*de.width),De=Math.floor(se*de.height);a===void 0&&(a=m(ne,De));const ge=_?m(ne,De):a;return ge.width=ne,ge.height=De,ge.getContext("2d").drawImage(b,0,0,ne,De),ze("WebGLRenderer: Texture has been resized from ("+de.width+"x"+de.height+") to ("+ne+"x"+De+")."),ge}else return"data"in b&&ze("WebGLRenderer: Image in DataTexture is too big ("+de.width+"x"+de.height+")."),b;return b}function E(b){return b.generateMipmaps}function f(b){n.generateMipmap(b)}function T(b){return b.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:b.isWebGL3DRenderTarget?n.TEXTURE_3D:b.isWebGLArrayRenderTarget||b.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function A(b,_,Y,se,de=!1){if(b!==null){if(n[b]!==void 0)return n[b];ze("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+b+"'")}let ne=_;if(_===n.RED&&(Y===n.FLOAT&&(ne=n.R32F),Y===n.HALF_FLOAT&&(ne=n.R16F),Y===n.UNSIGNED_BYTE&&(ne=n.R8)),_===n.RED_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.R8UI),Y===n.UNSIGNED_SHORT&&(ne=n.R16UI),Y===n.UNSIGNED_INT&&(ne=n.R32UI),Y===n.BYTE&&(ne=n.R8I),Y===n.SHORT&&(ne=n.R16I),Y===n.INT&&(ne=n.R32I)),_===n.RG&&(Y===n.FLOAT&&(ne=n.RG32F),Y===n.HALF_FLOAT&&(ne=n.RG16F),Y===n.UNSIGNED_BYTE&&(ne=n.RG8)),_===n.RG_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RG8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RG16UI),Y===n.UNSIGNED_INT&&(ne=n.RG32UI),Y===n.BYTE&&(ne=n.RG8I),Y===n.SHORT&&(ne=n.RG16I),Y===n.INT&&(ne=n.RG32I)),_===n.RGB_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RGB8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RGB16UI),Y===n.UNSIGNED_INT&&(ne=n.RGB32UI),Y===n.BYTE&&(ne=n.RGB8I),Y===n.SHORT&&(ne=n.RGB16I),Y===n.INT&&(ne=n.RGB32I)),_===n.RGBA_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RGBA8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RGBA16UI),Y===n.UNSIGNED_INT&&(ne=n.RGBA32UI),Y===n.BYTE&&(ne=n.RGBA8I),Y===n.SHORT&&(ne=n.RGBA16I),Y===n.INT&&(ne=n.RGBA32I)),_===n.RGB&&(Y===n.UNSIGNED_INT_5_9_9_9_REV&&(ne=n.RGB9_E5),Y===n.UNSIGNED_INT_10F_11F_11F_REV&&(ne=n.R11F_G11F_B10F)),_===n.RGBA){const De=de?hr:je.getTransfer(se);Y===n.FLOAT&&(ne=n.RGBA32F),Y===n.HALF_FLOAT&&(ne=n.RGBA16F),Y===n.UNSIGNED_BYTE&&(ne=De===st?n.SRGB8_ALPHA8:n.RGBA8),Y===n.UNSIGNED_SHORT_4_4_4_4&&(ne=n.RGBA4),Y===n.UNSIGNED_SHORT_5_5_5_1&&(ne=n.RGB5_A1)}return(ne===n.R16F||ne===n.R32F||ne===n.RG16F||ne===n.RG32F||ne===n.RGBA16F||ne===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function I(b,_){let Y;return b?_===null||_===pi||_===_s?Y=n.DEPTH24_STENCIL8:_===Dn?Y=n.DEPTH32F_STENCIL8:_===As&&(Y=n.DEPTH24_STENCIL8,ze("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===pi||_===_s?Y=n.DEPTH_COMPONENT24:_===Dn?Y=n.DEPTH_COMPONENT32F:_===As&&(Y=n.DEPTH_COMPONENT16),Y}function D(b,_){return E(b)===!0||b.isFramebufferTexture&&b.minFilter!==qt&&b.minFilter!==en?Math.log2(Math.max(_.width,_.height))+1:b.mipmaps!==void 0&&b.mipmaps.length>0?b.mipmaps.length:b.isCompressedTexture&&Array.isArray(b.image)?_.mipmaps.length:1}function O(b){const _=b.target;_.removeEventListener("dispose",O),U(_),_.isVideoTexture&&p.delete(_)}function C(b){const _=b.target;_.removeEventListener("dispose",C),R(_)}function U(b){const _=i.get(b);if(_.__webglInit===void 0)return;const Y=b.source,se=l.get(Y);if(se){const de=se[_.__cacheKey];de.usedTimes--,de.usedTimes===0&&v(b),Object.keys(se).length===0&&l.delete(Y)}i.remove(b)}function v(b){const _=i.get(b);n.deleteTexture(_.__webglTexture);const Y=b.source,se=l.get(Y);delete se[_.__cacheKey],o.memory.textures--}function R(b){const _=i.get(b);if(b.depthTexture&&(b.depthTexture.dispose(),i.remove(b.depthTexture)),b.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(_.__webglFramebuffer[se]))for(let de=0;de<_.__webglFramebuffer[se].length;de++)n.deleteFramebuffer(_.__webglFramebuffer[se][de]);else n.deleteFramebuffer(_.__webglFramebuffer[se]);_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer[se])}else{if(Array.isArray(_.__webglFramebuffer))for(let se=0;se<_.__webglFramebuffer.length;se++)n.deleteFramebuffer(_.__webglFramebuffer[se]);else n.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&n.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let se=0;se<_.__webglColorRenderbuffer.length;se++)_.__webglColorRenderbuffer[se]&&n.deleteRenderbuffer(_.__webglColorRenderbuffer[se]);_.__webglDepthRenderbuffer&&n.deleteRenderbuffer(_.__webglDepthRenderbuffer)}const Y=b.textures;for(let se=0,de=Y.length;se<de;se++){const ne=i.get(Y[se]);ne.__webglTexture&&(n.deleteTexture(ne.__webglTexture),o.memory.textures--),i.remove(Y[se])}i.remove(b)}let P=0;function V(){P=0}function Z(){const b=P;return b>=s.maxTextures&&ze("WebGLTextures: Trying to use "+b+" texture units while this GPU supports only "+s.maxTextures),P+=1,b}function J(b){const _=[];return _.push(b.wrapS),_.push(b.wrapT),_.push(b.wrapR||0),_.push(b.magFilter),_.push(b.minFilter),_.push(b.anisotropy),_.push(b.internalFormat),_.push(b.format),_.push(b.type),_.push(b.generateMipmaps),_.push(b.premultiplyAlpha),_.push(b.flipY),_.push(b.unpackAlignment),_.push(b.colorSpace),_.join()}function $(b,_){const Y=i.get(b);if(b.isVideoTexture&&ae(b),b.isRenderTargetTexture===!1&&b.isExternalTexture!==!0&&b.version>0&&Y.__version!==b.version){const se=b.image;if(se===null)ze("WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)ze("WebGLRenderer: Texture marked for update but image is incomplete");else{M(Y,b,_);return}}else b.isExternalTexture&&(Y.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D,Y.__webglTexture,n.TEXTURE0+_)}function ie(b,_){const Y=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Y.__version!==b.version){M(Y,b,_);return}else b.isExternalTexture&&(Y.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D_ARRAY,Y.__webglTexture,n.TEXTURE0+_)}function j(b,_){const Y=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Y.__version!==b.version){M(Y,b,_);return}t.bindTexture(n.TEXTURE_3D,Y.__webglTexture,n.TEXTURE0+_)}function B(b,_){const Y=i.get(b);if(b.version>0&&Y.__version!==b.version){g(Y,b,_);return}t.bindTexture(n.TEXTURE_CUBE_MAP,Y.__webglTexture,n.TEXTURE0+_)}const pe={[Oa]:n.REPEAT,[Cn]:n.CLAMP_TO_EDGE,[ba]:n.MIRRORED_REPEAT},Ee={[qt]:n.NEAREST,[ih]:n.NEAREST_MIPMAP_NEAREST,[Cs]:n.NEAREST_MIPMAP_LINEAR,[en]:n.LINEAR,[Dr]:n.LINEAR_MIPMAP_NEAREST,[di]:n.LINEAR_MIPMAP_LINEAR},Le={[lh]:n.NEVER,[ph]:n.ALWAYS,[ch]:n.LESS,[Tc]:n.LEQUAL,[uh]:n.EQUAL,[fh]:n.GEQUAL,[hh]:n.GREATER,[dh]:n.NOTEQUAL};function Ve(b,_){if(_.type===Dn&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===en||_.magFilter===Dr||_.magFilter===Cs||_.magFilter===di||_.minFilter===en||_.minFilter===Dr||_.minFilter===Cs||_.minFilter===di)&&ze("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(b,n.TEXTURE_WRAP_S,pe[_.wrapS]),n.texParameteri(b,n.TEXTURE_WRAP_T,pe[_.wrapT]),(b===n.TEXTURE_3D||b===n.TEXTURE_2D_ARRAY)&&n.texParameteri(b,n.TEXTURE_WRAP_R,pe[_.wrapR]),n.texParameteri(b,n.TEXTURE_MAG_FILTER,Ee[_.magFilter]),n.texParameteri(b,n.TEXTURE_MIN_FILTER,Ee[_.minFilter]),_.compareFunction&&(n.texParameteri(b,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(b,n.TEXTURE_COMPARE_FUNC,Le[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===qt||_.minFilter!==Cs&&_.minFilter!==di||_.type===Dn&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||i.get(_).__currentAnisotropy){const Y=e.get("EXT_texture_filter_anisotropic");n.texParameterf(b,Y.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,s.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy}}}function Xe(b,_){let Y=!1;b.__webglInit===void 0&&(b.__webglInit=!0,_.addEventListener("dispose",O));const se=_.source;let de=l.get(se);de===void 0&&(de={},l.set(se,de));const ne=J(_);if(ne!==b.__cacheKey){de[ne]===void 0&&(de[ne]={texture:n.createTexture(),usedTimes:0},o.memory.textures++,Y=!0),de[ne].usedTimes++;const De=de[b.__cacheKey];De!==void 0&&(de[b.__cacheKey].usedTimes--,De.usedTimes===0&&v(_)),b.__cacheKey=ne,b.__webglTexture=de[ne].texture}return Y}function X(b,_,Y){return Math.floor(Math.floor(b/Y)/_)}function w(b,_,Y,se){const ne=b.updateRanges;if(ne.length===0)t.texSubImage2D(n.TEXTURE_2D,0,0,0,_.width,_.height,Y,se,_.data);else{ne.sort((me,_e)=>me.start-_e.start);let De=0;for(let me=1;me<ne.length;me++){const _e=ne[De],Ge=ne[me],Be=_e.start+_e.count,Oe=X(Ge.start,_.width,4),We=X(_e.start,_.width,4);Ge.start<=Be+1&&Oe===We&&X(Ge.start+Ge.count-1,_.width,4)===Oe?_e.count=Math.max(_e.count,Ge.start+Ge.count-_e.start):(++De,ne[De]=Ge)}ne.length=De+1;const ge=n.getParameter(n.UNPACK_ROW_LENGTH),Ue=n.getParameter(n.UNPACK_SKIP_PIXELS),Ce=n.getParameter(n.UNPACK_SKIP_ROWS);n.pixelStorei(n.UNPACK_ROW_LENGTH,_.width);for(let me=0,_e=ne.length;me<_e;me++){const Ge=ne[me],Be=Math.floor(Ge.start/4),Oe=Math.ceil(Ge.count/4),We=Be%_.width,F=Math.floor(Be/_.width),Ie=Oe,Re=1;n.pixelStorei(n.UNPACK_SKIP_PIXELS,We),n.pixelStorei(n.UNPACK_SKIP_ROWS,F),t.texSubImage2D(n.TEXTURE_2D,0,We,F,Ie,Re,Y,se,_.data)}b.clearUpdateRanges(),n.pixelStorei(n.UNPACK_ROW_LENGTH,ge),n.pixelStorei(n.UNPACK_SKIP_PIXELS,Ue),n.pixelStorei(n.UNPACK_SKIP_ROWS,Ce)}}function M(b,_,Y){let se=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(se=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(se=n.TEXTURE_3D);const de=Xe(b,_),ne=_.source;t.bindTexture(se,b.__webglTexture,n.TEXTURE0+Y);const De=i.get(ne);if(ne.version!==De.__version||de===!0){t.activeTexture(n.TEXTURE0+Y);const ge=je.getPrimaries(je.workingColorSpace),Ue=_.colorSpace===qn?null:je.getPrimaries(_.colorSpace),Ce=_.colorSpace===qn||ge===Ue?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ce);let me=S(_.image,!1,s.maxTextureSize);me=le(_,me);const _e=r.convert(_.format,_.colorSpace),Ge=r.convert(_.type);let Be=A(_.internalFormat,_e,Ge,_.colorSpace,_.isVideoTexture);Ve(se,_);let Oe;const We=_.mipmaps,F=_.isVideoTexture!==!0,Ie=De.__version===void 0||de===!0,Re=ne.dataReady,ve=D(_,me);if(_.isDepthTexture)Be=I(_.format===gs,_.type),Ie&&(F?t.texStorage2D(n.TEXTURE_2D,1,Be,me.width,me.height):t.texImage2D(n.TEXTURE_2D,0,Be,me.width,me.height,0,_e,Ge,null));else if(_.isDataTexture)if(We.length>0){F&&Ie&&t.texStorage2D(n.TEXTURE_2D,ve,Be,We[0].width,We[0].height);for(let Se=0,he=We.length;Se<he;Se++)Oe=We[Se],F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,Ge,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,Be,Oe.width,Oe.height,0,_e,Ge,Oe.data);_.generateMipmaps=!1}else F?(Ie&&t.texStorage2D(n.TEXTURE_2D,ve,Be,me.width,me.height),Re&&w(_,me,_e,Ge)):t.texImage2D(n.TEXTURE_2D,0,Be,me.width,me.height,0,_e,Ge,me.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){F&&Ie&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,Be,We[0].width,We[0].height,me.depth);for(let Se=0,he=We.length;Se<he;Se++)if(Oe=We[Se],_.format!==cn)if(_e!==null)if(F){if(Re)if(_.layerUpdates.size>0){const Ne=Rl(Oe.width,Oe.height,_.format,_.type);for(const Ke of _.layerUpdates){const ct=Oe.data.subarray(Ke*Ne/Oe.data.BYTES_PER_ELEMENT,(Ke+1)*Ne/Oe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,Ke,Oe.width,Oe.height,1,_e,ct)}_.clearLayerUpdates()}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,me.depth,_e,Oe.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Se,Be,Oe.width,Oe.height,me.depth,0,Oe.data,0,0);else ze("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else F?Re&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,me.depth,_e,Ge,Oe.data):t.texImage3D(n.TEXTURE_2D_ARRAY,Se,Be,Oe.width,Oe.height,me.depth,0,_e,Ge,Oe.data)}else{F&&Ie&&t.texStorage2D(n.TEXTURE_2D,ve,Be,We[0].width,We[0].height);for(let Se=0,he=We.length;Se<he;Se++)Oe=We[Se],_.format!==cn?_e!==null?F?Re&&t.compressedTexSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,Oe.data):t.compressedTexImage2D(n.TEXTURE_2D,Se,Be,Oe.width,Oe.height,0,Oe.data):ze("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,Ge,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,Be,Oe.width,Oe.height,0,_e,Ge,Oe.data)}else if(_.isDataArrayTexture)if(F){if(Ie&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,Be,me.width,me.height,me.depth),Re)if(_.layerUpdates.size>0){const Se=Rl(me.width,me.height,_.format,_.type);for(const he of _.layerUpdates){const Ne=me.data.subarray(he*Se/me.data.BYTES_PER_ELEMENT,(he+1)*Se/me.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,he,me.width,me.height,1,_e,Ge,Ne)}_.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,me.width,me.height,me.depth,_e,Ge,me.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,Be,me.width,me.height,me.depth,0,_e,Ge,me.data);else if(_.isData3DTexture)F?(Ie&&t.texStorage3D(n.TEXTURE_3D,ve,Be,me.width,me.height,me.depth),Re&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,me.width,me.height,me.depth,_e,Ge,me.data)):t.texImage3D(n.TEXTURE_3D,0,Be,me.width,me.height,me.depth,0,_e,Ge,me.data);else if(_.isFramebufferTexture){if(Ie)if(F)t.texStorage2D(n.TEXTURE_2D,ve,Be,me.width,me.height);else{let Se=me.width,he=me.height;for(let Ne=0;Ne<ve;Ne++)t.texImage2D(n.TEXTURE_2D,Ne,Be,Se,he,0,_e,Ge,null),Se>>=1,he>>=1}}else if(We.length>0){if(F&&Ie){const Se=Te(We[0]);t.texStorage2D(n.TEXTURE_2D,ve,Be,Se.width,Se.height)}for(let Se=0,he=We.length;Se<he;Se++)Oe=We[Se],F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,_e,Ge,Oe):t.texImage2D(n.TEXTURE_2D,Se,Be,_e,Ge,Oe);_.generateMipmaps=!1}else if(F){if(Ie){const Se=Te(me);t.texStorage2D(n.TEXTURE_2D,ve,Be,Se.width,Se.height)}Re&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,_e,Ge,me)}else t.texImage2D(n.TEXTURE_2D,0,Be,_e,Ge,me);E(_)&&f(se),De.__version=ne.version,_.onUpdate&&_.onUpdate(_)}b.__version=_.version}function g(b,_,Y){if(_.image.length!==6)return;const se=Xe(b,_),de=_.source;t.bindTexture(n.TEXTURE_CUBE_MAP,b.__webglTexture,n.TEXTURE0+Y);const ne=i.get(de);if(de.version!==ne.__version||se===!0){t.activeTexture(n.TEXTURE0+Y);const De=je.getPrimaries(je.workingColorSpace),ge=_.colorSpace===qn?null:je.getPrimaries(_.colorSpace),Ue=_.colorSpace===qn||De===ge?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ue);const Ce=_.isCompressedTexture||_.image[0].isCompressedTexture,me=_.image[0]&&_.image[0].isDataTexture,_e=[];for(let he=0;he<6;he++)!Ce&&!me?_e[he]=S(_.image[he],!0,s.maxCubemapSize):_e[he]=me?_.image[he].image:_.image[he],_e[he]=le(_,_e[he]);const Ge=_e[0],Be=r.convert(_.format,_.colorSpace),Oe=r.convert(_.type),We=A(_.internalFormat,Be,Oe,_.colorSpace),F=_.isVideoTexture!==!0,Ie=ne.__version===void 0||se===!0,Re=de.dataReady;let ve=D(_,Ge);Ve(n.TEXTURE_CUBE_MAP,_);let Se;if(Ce){F&&Ie&&t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,We,Ge.width,Ge.height);for(let he=0;he<6;he++){Se=_e[he].mipmaps;for(let Ne=0;Ne<Se.length;Ne++){const Ke=Se[Ne];_.format!==cn?Be!==null?F?Re&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne,0,0,Ke.width,Ke.height,Be,Ke.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne,We,Ke.width,Ke.height,0,Ke.data):ze("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne,0,0,Ke.width,Ke.height,Be,Oe,Ke.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne,We,Ke.width,Ke.height,0,Be,Oe,Ke.data)}}}else{if(Se=_.mipmaps,F&&Ie){Se.length>0&&ve++;const he=Te(_e[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,We,he.width,he.height)}for(let he=0;he<6;he++)if(me){F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,0,0,_e[he].width,_e[he].height,Be,Oe,_e[he].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,We,_e[he].width,_e[he].height,0,Be,Oe,_e[he].data);for(let Ne=0;Ne<Se.length;Ne++){const ct=Se[Ne].image[he].image;F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne+1,0,0,ct.width,ct.height,Be,Oe,ct.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne+1,We,ct.width,ct.height,0,Be,Oe,ct.data)}}else{F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,0,0,Be,Oe,_e[he]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,We,Be,Oe,_e[he]);for(let Ne=0;Ne<Se.length;Ne++){const Ke=Se[Ne];F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne+1,0,0,Be,Oe,Ke.image[he]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Ne+1,We,Be,Oe,Ke.image[he])}}}E(_)&&f(n.TEXTURE_CUBE_MAP),ne.__version=de.version,_.onUpdate&&_.onUpdate(_)}b.__version=_.version}function K(b,_,Y,se,de,ne){const De=r.convert(Y.format,Y.colorSpace),ge=r.convert(Y.type),Ue=A(Y.internalFormat,De,ge,Y.colorSpace),Ce=i.get(_),me=i.get(Y);if(me.__renderTarget=_,!Ce.__hasExternalTextures){const _e=Math.max(1,_.width>>ne),Ge=Math.max(1,_.height>>ne);de===n.TEXTURE_3D||de===n.TEXTURE_2D_ARRAY?t.texImage3D(de,ne,Ue,_e,Ge,_.depth,0,De,ge,null):t.texImage2D(de,ne,Ue,_e,Ge,0,De,ge,null)}t.bindFramebuffer(n.FRAMEBUFFER,b),y(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,se,de,me.__webglTexture,0,N(_)):(de===n.TEXTURE_2D||de>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&de<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,se,de,me.__webglTexture,ne),t.bindFramebuffer(n.FRAMEBUFFER,null)}function re(b,_,Y){if(n.bindRenderbuffer(n.RENDERBUFFER,b),_.depthBuffer){const se=_.depthTexture,de=se&&se.isDepthTexture?se.type:null,ne=I(_.stencilBuffer,de),De=_.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ge=N(_);y(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ge,ne,_.width,_.height):Y?n.renderbufferStorageMultisample(n.RENDERBUFFER,ge,ne,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,ne,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,De,n.RENDERBUFFER,b)}else{const se=_.textures;for(let de=0;de<se.length;de++){const ne=se[de],De=r.convert(ne.format,ne.colorSpace),ge=r.convert(ne.type),Ue=A(ne.internalFormat,De,ge,ne.colorSpace),Ce=N(_);Y&&y(_)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ce,Ue,_.width,_.height):y(_)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ce,Ue,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,Ue,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function k(b,_){if(_&&_.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,b),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const se=i.get(_.depthTexture);se.__renderTarget=_,(!se.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),$(_.depthTexture,0);const de=se.__webglTexture,ne=N(_);if(_.depthTexture.format===xs)y(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,de,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,de,0);else if(_.depthTexture.format===gs)y(_)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,de,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,de,0);else throw new Error("Unknown depthTexture format")}function ce(b){const _=i.get(b),Y=b.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==b.depthTexture){const se=b.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),se){const de=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,se.removeEventListener("dispose",de)};se.addEventListener("dispose",de),_.__depthDisposeCallback=de}_.__boundDepthTexture=se}if(b.depthTexture&&!_.__autoAllocateDepthBuffer){if(Y)throw new Error("target.depthTexture not supported in Cube render targets");const se=b.texture.mipmaps;se&&se.length>0?k(_.__webglFramebuffer[0],b):k(_.__webglFramebuffer,b)}else if(Y){_.__webglDepthbuffer=[];for(let se=0;se<6;se++)if(t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[se]),_.__webglDepthbuffer[se]===void 0)_.__webglDepthbuffer[se]=n.createRenderbuffer(),re(_.__webglDepthbuffer[se],b,!1);else{const de=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=_.__webglDepthbuffer[se];n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,de,n.RENDERBUFFER,ne)}}else{const se=b.texture.mipmaps;if(se&&se.length>0?t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[0]):t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=n.createRenderbuffer(),re(_.__webglDepthbuffer,b,!1);else{const de=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=_.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,de,n.RENDERBUFFER,ne)}}t.bindFramebuffer(n.FRAMEBUFFER,null)}function Ae(b,_,Y){const se=i.get(b);_!==void 0&&K(se.__webglFramebuffer,b,b.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),Y!==void 0&&ce(b)}function ue(b){const _=b.texture,Y=i.get(b),se=i.get(_);b.addEventListener("dispose",C);const de=b.textures,ne=b.isWebGLCubeRenderTarget===!0,De=de.length>1;if(De||(se.__webglTexture===void 0&&(se.__webglTexture=n.createTexture()),se.__version=_.version,o.memory.textures++),ne){Y.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(_.mipmaps&&_.mipmaps.length>0){Y.__webglFramebuffer[ge]=[];for(let Ue=0;Ue<_.mipmaps.length;Ue++)Y.__webglFramebuffer[ge][Ue]=n.createFramebuffer()}else Y.__webglFramebuffer[ge]=n.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){Y.__webglFramebuffer=[];for(let ge=0;ge<_.mipmaps.length;ge++)Y.__webglFramebuffer[ge]=n.createFramebuffer()}else Y.__webglFramebuffer=n.createFramebuffer();if(De)for(let ge=0,Ue=de.length;ge<Ue;ge++){const Ce=i.get(de[ge]);Ce.__webglTexture===void 0&&(Ce.__webglTexture=n.createTexture(),o.memory.textures++)}if(b.samples>0&&y(b)===!1){Y.__webglMultisampledFramebuffer=n.createFramebuffer(),Y.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,Y.__webglMultisampledFramebuffer);for(let ge=0;ge<de.length;ge++){const Ue=de[ge];Y.__webglColorRenderbuffer[ge]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,Y.__webglColorRenderbuffer[ge]);const Ce=r.convert(Ue.format,Ue.colorSpace),me=r.convert(Ue.type),_e=A(Ue.internalFormat,Ce,me,Ue.colorSpace,b.isXRRenderTarget===!0),Ge=N(b);n.renderbufferStorageMultisample(n.RENDERBUFFER,Ge,_e,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ge,n.RENDERBUFFER,Y.__webglColorRenderbuffer[ge])}n.bindRenderbuffer(n.RENDERBUFFER,null),b.depthBuffer&&(Y.__webglDepthRenderbuffer=n.createRenderbuffer(),re(Y.__webglDepthRenderbuffer,b,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(ne){t.bindTexture(n.TEXTURE_CUBE_MAP,se.__webglTexture),Ve(n.TEXTURE_CUBE_MAP,_);for(let ge=0;ge<6;ge++)if(_.mipmaps&&_.mipmaps.length>0)for(let Ue=0;Ue<_.mipmaps.length;Ue++)K(Y.__webglFramebuffer[ge][Ue],b,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,Ue);else K(Y.__webglFramebuffer[ge],b,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);E(_)&&f(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(De){for(let ge=0,Ue=de.length;ge<Ue;ge++){const Ce=de[ge],me=i.get(Ce);let _e=n.TEXTURE_2D;(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(_e=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(_e,me.__webglTexture),Ve(_e,Ce),K(Y.__webglFramebuffer,b,Ce,n.COLOR_ATTACHMENT0+ge,_e,0),E(Ce)&&f(_e)}t.unbindTexture()}else{let ge=n.TEXTURE_2D;if((b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(ge=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(ge,se.__webglTexture),Ve(ge,_),_.mipmaps&&_.mipmaps.length>0)for(let Ue=0;Ue<_.mipmaps.length;Ue++)K(Y.__webglFramebuffer[Ue],b,_,n.COLOR_ATTACHMENT0,ge,Ue);else K(Y.__webglFramebuffer,b,_,n.COLOR_ATTACHMENT0,ge,0);E(_)&&f(ge),t.unbindTexture()}b.depthBuffer&&ce(b)}function H(b){const _=b.textures;for(let Y=0,se=_.length;Y<se;Y++){const de=_[Y];if(E(de)){const ne=T(b),De=i.get(de).__webglTexture;t.bindTexture(ne,De),f(ne),t.unbindTexture()}}}const x=[],q=[];function Q(b){if(b.samples>0){if(y(b)===!1){const _=b.textures,Y=b.width,se=b.height;let de=n.COLOR_BUFFER_BIT;const ne=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,De=i.get(b),ge=_.length>1;if(ge)for(let Ce=0;Ce<_.length;Ce++)t.bindFramebuffer(n.FRAMEBUFFER,De.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,De.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,De.__webglMultisampledFramebuffer);const Ue=b.texture.mipmaps;Ue&&Ue.length>0?t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglFramebuffer[0]):t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglFramebuffer);for(let Ce=0;Ce<_.length;Ce++){if(b.resolveDepthBuffer&&(b.depthBuffer&&(de|=n.DEPTH_BUFFER_BIT),b.stencilBuffer&&b.resolveStencilBuffer&&(de|=n.STENCIL_BUFFER_BIT)),ge){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,De.__webglColorRenderbuffer[Ce]);const me=i.get(_[Ce]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,me,0)}n.blitFramebuffer(0,0,Y,se,0,0,Y,se,de,n.NEAREST),d===!0&&(x.length=0,q.length=0,x.push(n.COLOR_ATTACHMENT0+Ce),b.depthBuffer&&b.resolveDepthBuffer===!1&&(x.push(ne),q.push(ne),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,q)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,x))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),ge)for(let Ce=0;Ce<_.length;Ce++){t.bindFramebuffer(n.FRAMEBUFFER,De.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.RENDERBUFFER,De.__webglColorRenderbuffer[Ce]);const me=i.get(_[Ce]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,De.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.TEXTURE_2D,me,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglMultisampledFramebuffer)}else if(b.depthBuffer&&b.resolveDepthBuffer===!1&&d){const _=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[_])}}}function N(b){return Math.min(s.maxSamples,b.samples)}function y(b){const _=i.get(b);return b.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function ae(b){const _=o.render.frame;p.get(b)!==_&&(p.set(b,_),b.update())}function le(b,_){const Y=b.colorSpace,se=b.format,de=b.type;return b.isCompressedTexture===!0||b.isVideoTexture===!0||Y!==zi&&Y!==qn&&(je.getTransfer(Y)===st?(se!==cn||de!==Un)&&ze("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):ft("WebGLTextures: Unsupported texture color space:",Y)),_}function Te(b){return typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement?(u.width=b.naturalWidth||b.width,u.height=b.naturalHeight||b.height):typeof VideoFrame<"u"&&b instanceof VideoFrame?(u.width=b.displayWidth,u.height=b.displayHeight):(u.width=b.width,u.height=b.height),u}this.allocateTextureUnit=Z,this.resetTextureUnits=V,this.setTexture2D=$,this.setTexture2DArray=ie,this.setTexture3D=j,this.setTextureCube=B,this.rebindTextures=Ae,this.setupRenderTarget=ue,this.updateRenderTargetMipmap=H,this.updateMultisampleRenderTarget=Q,this.setupDepthRenderbuffer=ce,this.setupFrameBufferTexture=K,this.useMultisampledRTT=y}function ES(n,e){function t(i,s=qn){let r;const o=je.getTransfer(s);if(i===Un)return n.UNSIGNED_BYTE;if(i===mo)return n.UNSIGNED_SHORT_4_4_4_4;if(i===So)return n.UNSIGNED_SHORT_5_5_5_1;if(i===Sc)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===Ac)return n.UNSIGNED_INT_10F_11F_11F_REV;if(i===Ec)return n.BYTE;if(i===mc)return n.SHORT;if(i===As)return n.UNSIGNED_SHORT;if(i===Eo)return n.INT;if(i===pi)return n.UNSIGNED_INT;if(i===Dn)return n.FLOAT;if(i===Zi)return n.HALF_FLOAT;if(i===_c)return n.ALPHA;if(i===xc)return n.RGB;if(i===cn)return n.RGBA;if(i===xs)return n.DEPTH_COMPONENT;if(i===gs)return n.DEPTH_STENCIL;if(i===gc)return n.RED;if(i===Ao)return n.RED_INTEGER;if(i===_o)return n.RG;if(i===xo)return n.RG_INTEGER;if(i===go)return n.RGBA_INTEGER;if(i===sr||i===rr||i===ar||i===or)if(o===st)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===sr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===rr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===ar)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===or)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===sr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===rr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===ar)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===or)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===Ca||i===Da||i===Na||i===Pa)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===Ca)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Da)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Na)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===Pa)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===Ua||i===wa||i===Fa)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(i===Ua||i===wa)return o===st?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===Fa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===Ba||i===Ha||i===Ga||i===Va||i===ka||i===Ya||i===Wa||i===za||i===Ka||i===Xa||i===qa||i===Za||i===Ja||i===Qa)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(i===Ba)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Ha)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===Ga)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Va)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===ka)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===Ya)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===Wa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===za)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Ka)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Xa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===qa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===Za)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Ja)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Qa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===$a||i===ja||i===eo)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(i===$a)return o===st?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===ja)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===eo)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===to||i===no||i===io||i===so)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(i===to)return r.COMPRESSED_RED_RGTC1_EXT;if(i===no)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===io)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===so)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===_s?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}const mS=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,SS=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class AS{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const i=new Nc(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,i=new Bn({vertexShader:mS,fragmentShader:SS,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new At(new Ai(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class _S extends mi{constructor(e,t){super();const i=this;let s=null,r=1,o=null,c="local-floor",d=1,u=null,p=null,a=null,l=null,h=null,m=null;const S=typeof XRWebGLBinding<"u",E=new AS,f={},T=t.getContextAttributes();let A=null,I=null;const D=[],O=[],C=new oe;let U=null;const v=new Xt;v.viewport=new St;const R=new Xt;R.viewport=new St;const P=[v,R],V=new Ud;let Z=null,J=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(M){let g=D[M];return g===void 0&&(g=new ea,D[M]=g),g.getTargetRaySpace()},this.getControllerGrip=function(M){let g=D[M];return g===void 0&&(g=new ea,D[M]=g),g.getGripSpace()},this.getHand=function(M){let g=D[M];return g===void 0&&(g=new ea,D[M]=g),g.getHandSpace()};function $(M){const g=O.indexOf(M.inputSource);if(g===-1)return;const K=D[g];K!==void 0&&(K.update(M.inputSource,M.frame,u||o),K.dispatchEvent({type:M.type,data:M.inputSource}))}function ie(){s.removeEventListener("select",$),s.removeEventListener("selectstart",$),s.removeEventListener("selectend",$),s.removeEventListener("squeeze",$),s.removeEventListener("squeezestart",$),s.removeEventListener("squeezeend",$),s.removeEventListener("end",ie),s.removeEventListener("inputsourceschange",j);for(let M=0;M<D.length;M++){const g=O[M];g!==null&&(O[M]=null,D[M].disconnect(g))}Z=null,J=null,E.reset();for(const M in f)delete f[M];e.setRenderTarget(A),h=null,l=null,a=null,s=null,I=null,w.stop(),i.isPresenting=!1,e.setPixelRatio(U),e.setSize(C.width,C.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(M){r=M,i.isPresenting===!0&&ze("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(M){c=M,i.isPresenting===!0&&ze("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return u||o},this.setReferenceSpace=function(M){u=M},this.getBaseLayer=function(){return l!==null?l:h},this.getBinding=function(){return a===null&&S&&(a=new XRWebGLBinding(s,t)),a},this.getFrame=function(){return m},this.getSession=function(){return s},this.setSession=async function(M){if(s=M,s!==null){if(A=e.getRenderTarget(),s.addEventListener("select",$),s.addEventListener("selectstart",$),s.addEventListener("selectend",$),s.addEventListener("squeeze",$),s.addEventListener("squeezestart",$),s.addEventListener("squeezeend",$),s.addEventListener("end",ie),s.addEventListener("inputsourceschange",j),T.xrCompatible!==!0&&await t.makeXRCompatible(),U=e.getPixelRatio(),e.getSize(C),S&&"createProjectionLayer"in XRWebGLBinding.prototype){let K=null,re=null,k=null;T.depth&&(k=T.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,K=T.stencil?gs:xs,re=T.stencil?_s:pi);const ce={colorFormat:t.RGBA8,depthFormat:k,scaleFactor:r};a=this.getBinding(),l=a.createProjectionLayer(ce),s.updateRenderState({layers:[l]}),e.setPixelRatio(1),e.setSize(l.textureWidth,l.textureHeight,!1),I=new ei(l.textureWidth,l.textureHeight,{format:cn,type:Un,depthTexture:new Dc(l.textureWidth,l.textureHeight,re,void 0,void 0,void 0,void 0,void 0,void 0,K),stencilBuffer:T.stencil,colorSpace:e.outputColorSpace,samples:T.antialias?4:0,resolveDepthBuffer:l.ignoreDepthValues===!1,resolveStencilBuffer:l.ignoreDepthValues===!1})}else{const K={antialias:T.antialias,alpha:!0,depth:T.depth,stencil:T.stencil,framebufferScaleFactor:r};h=new XRWebGLLayer(s,t,K),s.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),I=new ei(h.framebufferWidth,h.framebufferHeight,{format:cn,type:Un,colorSpace:e.outputColorSpace,stencilBuffer:T.stencil,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}I.isXRRenderTarget=!0,this.setFoveation(d),u=null,o=await s.requestReferenceSpace(c),w.setContext(s),w.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return E.getDepthTexture()};function j(M){for(let g=0;g<M.removed.length;g++){const K=M.removed[g],re=O.indexOf(K);re>=0&&(O[re]=null,D[re].disconnect(K))}for(let g=0;g<M.added.length;g++){const K=M.added[g];let re=O.indexOf(K);if(re===-1){for(let ce=0;ce<D.length;ce++)if(ce>=O.length){O.push(K),re=ce;break}else if(O[ce]===null){O[ce]=K,re=ce;break}if(re===-1)break}const k=D[re];k&&k.connect(K)}}const B=new G,pe=new G;function Ee(M,g,K){B.setFromMatrixPosition(g.matrixWorld),pe.setFromMatrixPosition(K.matrixWorld);const re=B.distanceTo(pe),k=g.projectionMatrix.elements,ce=K.projectionMatrix.elements,Ae=k[14]/(k[10]-1),ue=k[14]/(k[10]+1),H=(k[9]+1)/k[5],x=(k[9]-1)/k[5],q=(k[8]-1)/k[0],Q=(ce[8]+1)/ce[0],N=Ae*q,y=Ae*Q,ae=re/(-q+Q),le=ae*-q;if(g.matrixWorld.decompose(M.position,M.quaternion,M.scale),M.translateX(le),M.translateZ(ae),M.matrixWorld.compose(M.position,M.quaternion,M.scale),M.matrixWorldInverse.copy(M.matrixWorld).invert(),k[10]===-1)M.projectionMatrix.copy(g.projectionMatrix),M.projectionMatrixInverse.copy(g.projectionMatrixInverse);else{const Te=Ae+ae,b=ue+ae,_=N-le,Y=y+(re-le),se=H*ue/b*Te,de=x*ue/b*Te;M.projectionMatrix.makePerspective(_,Y,se,de,Te,b),M.projectionMatrixInverse.copy(M.projectionMatrix).invert()}}function Le(M,g){g===null?M.matrixWorld.copy(M.matrix):M.matrixWorld.multiplyMatrices(g.matrixWorld,M.matrix),M.matrixWorldInverse.copy(M.matrixWorld).invert()}this.updateCamera=function(M){if(s===null)return;let g=M.near,K=M.far;E.texture!==null&&(E.depthNear>0&&(g=E.depthNear),E.depthFar>0&&(K=E.depthFar)),V.near=R.near=v.near=g,V.far=R.far=v.far=K,(Z!==V.near||J!==V.far)&&(s.updateRenderState({depthNear:V.near,depthFar:V.far}),Z=V.near,J=V.far),V.layers.mask=M.layers.mask|6,v.layers.mask=V.layers.mask&3,R.layers.mask=V.layers.mask&5;const re=M.parent,k=V.cameras;Le(V,re);for(let ce=0;ce<k.length;ce++)Le(k[ce],re);k.length===2?Ee(V,v,R):V.projectionMatrix.copy(v.projectionMatrix),Ve(M,V,re)};function Ve(M,g,K){K===null?M.matrix.copy(g.matrixWorld):(M.matrix.copy(K.matrixWorld),M.matrix.invert(),M.matrix.multiply(g.matrixWorld)),M.matrix.decompose(M.position,M.quaternion,M.scale),M.updateMatrixWorld(!0),M.projectionMatrix.copy(g.projectionMatrix),M.projectionMatrixInverse.copy(g.projectionMatrixInverse),M.isPerspectiveCamera&&(M.fov=ro*2*Math.atan(1/M.projectionMatrix.elements[5]),M.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(l===null&&h===null))return d},this.setFoveation=function(M){d=M,l!==null&&(l.fixedFoveation=M),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=M)},this.hasDepthSensing=function(){return E.texture!==null},this.getDepthSensingMesh=function(){return E.getMesh(V)},this.getCameraTexture=function(M){return f[M]};let Xe=null;function X(M,g){if(p=g.getViewerPose(u||o),m=g,p!==null){const K=p.views;h!==null&&(e.setRenderTargetFramebuffer(I,h.framebuffer),e.setRenderTarget(I));let re=!1;K.length!==V.cameras.length&&(V.cameras.length=0,re=!0);for(let ue=0;ue<K.length;ue++){const H=K[ue];let x=null;if(h!==null)x=h.getViewport(H);else{const Q=a.getViewSubImage(l,H);x=Q.viewport,ue===0&&(e.setRenderTargetTextures(I,Q.colorTexture,Q.depthStencilTexture),e.setRenderTarget(I))}let q=P[ue];q===void 0&&(q=new Xt,q.layers.enable(ue),q.viewport=new St,P[ue]=q),q.matrix.fromArray(H.transform.matrix),q.matrix.decompose(q.position,q.quaternion,q.scale),q.projectionMatrix.fromArray(H.projectionMatrix),q.projectionMatrixInverse.copy(q.projectionMatrix).invert(),q.viewport.set(x.x,x.y,x.width,x.height),ue===0&&(V.matrix.copy(q.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),re===!0&&V.cameras.push(q)}const k=s.enabledFeatures;if(k&&k.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&S){a=i.getBinding();const ue=a.getDepthInformation(K[0]);ue&&ue.isValid&&ue.texture&&E.init(ue,s.renderState)}if(k&&k.includes("camera-access")&&S){e.state.unbindTexture(),a=i.getBinding();for(let ue=0;ue<K.length;ue++){const H=K[ue].camera;if(H){let x=f[H];x||(x=new Nc,f[H]=x);const q=a.getCameraImage(H);x.sourceTexture=q}}}}for(let K=0;K<D.length;K++){const re=O[K],k=D[K];re!==null&&k!==void 0&&k.update(re,g,u||o)}Xe&&Xe(M,g),g.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:g}),m=null}const w=new Yc;w.setAnimationLoop(X),this.setAnimationLoop=function(M){Xe=M},this.dispose=function(){}}}const ci=new Fn,xS=new _t;function gS(n,e){function t(E,f){E.matrixAutoUpdate===!0&&E.updateMatrix(),f.value.copy(E.matrix)}function i(E,f){f.color.getRGB(E.fogColor.value,yc(n)),f.isFog?(E.fogNear.value=f.near,E.fogFar.value=f.far):f.isFogExp2&&(E.fogDensity.value=f.density)}function s(E,f,T,A,I){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(E,f):f.isMeshToonMaterial?(r(E,f),a(E,f)):f.isMeshPhongMaterial?(r(E,f),p(E,f)):f.isMeshStandardMaterial?(r(E,f),l(E,f),f.isMeshPhysicalMaterial&&h(E,f,I)):f.isMeshMatcapMaterial?(r(E,f),m(E,f)):f.isMeshDepthMaterial?r(E,f):f.isMeshDistanceMaterial?(r(E,f),S(E,f)):f.isMeshNormalMaterial?r(E,f):f.isLineBasicMaterial?(o(E,f),f.isLineDashedMaterial&&c(E,f)):f.isPointsMaterial?d(E,f,T,A):f.isSpriteMaterial?u(E,f):f.isShadowMaterial?(E.color.value.copy(f.color),E.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(E,f){E.opacity.value=f.opacity,f.color&&E.diffuse.value.copy(f.color),f.emissive&&E.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(E.map.value=f.map,t(f.map,E.mapTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.bumpMap&&(E.bumpMap.value=f.bumpMap,t(f.bumpMap,E.bumpMapTransform),E.bumpScale.value=f.bumpScale,f.side===Lt&&(E.bumpScale.value*=-1)),f.normalMap&&(E.normalMap.value=f.normalMap,t(f.normalMap,E.normalMapTransform),E.normalScale.value.copy(f.normalScale),f.side===Lt&&E.normalScale.value.negate()),f.displacementMap&&(E.displacementMap.value=f.displacementMap,t(f.displacementMap,E.displacementMapTransform),E.displacementScale.value=f.displacementScale,E.displacementBias.value=f.displacementBias),f.emissiveMap&&(E.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,E.emissiveMapTransform)),f.specularMap&&(E.specularMap.value=f.specularMap,t(f.specularMap,E.specularMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest);const T=e.get(f),A=T.envMap,I=T.envMapRotation;A&&(E.envMap.value=A,ci.copy(I),ci.x*=-1,ci.y*=-1,ci.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(ci.y*=-1,ci.z*=-1),E.envMapRotation.value.setFromMatrix4(xS.makeRotationFromEuler(ci)),E.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,E.reflectivity.value=f.reflectivity,E.ior.value=f.ior,E.refractionRatio.value=f.refractionRatio),f.lightMap&&(E.lightMap.value=f.lightMap,E.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,E.lightMapTransform)),f.aoMap&&(E.aoMap.value=f.aoMap,E.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,E.aoMapTransform))}function o(E,f){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,f.map&&(E.map.value=f.map,t(f.map,E.mapTransform))}function c(E,f){E.dashSize.value=f.dashSize,E.totalSize.value=f.dashSize+f.gapSize,E.scale.value=f.scale}function d(E,f,T,A){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,E.size.value=f.size*T,E.scale.value=A*.5,f.map&&(E.map.value=f.map,t(f.map,E.uvTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest)}function u(E,f){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,E.rotation.value=f.rotation,f.map&&(E.map.value=f.map,t(f.map,E.mapTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest)}function p(E,f){E.specular.value.copy(f.specular),E.shininess.value=Math.max(f.shininess,1e-4)}function a(E,f){f.gradientMap&&(E.gradientMap.value=f.gradientMap)}function l(E,f){E.metalness.value=f.metalness,f.metalnessMap&&(E.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,E.metalnessMapTransform)),E.roughness.value=f.roughness,f.roughnessMap&&(E.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,E.roughnessMapTransform)),f.envMap&&(E.envMapIntensity.value=f.envMapIntensity)}function h(E,f,T){E.ior.value=f.ior,f.sheen>0&&(E.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),E.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(E.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,E.sheenColorMapTransform)),f.sheenRoughnessMap&&(E.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,E.sheenRoughnessMapTransform))),f.clearcoat>0&&(E.clearcoat.value=f.clearcoat,E.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(E.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,E.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(E.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,E.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(E.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,E.clearcoatNormalMapTransform),E.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Lt&&E.clearcoatNormalScale.value.negate())),f.dispersion>0&&(E.dispersion.value=f.dispersion),f.iridescence>0&&(E.iridescence.value=f.iridescence,E.iridescenceIOR.value=f.iridescenceIOR,E.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],E.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(E.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,E.iridescenceMapTransform)),f.iridescenceThicknessMap&&(E.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,E.iridescenceThicknessMapTransform))),f.transmission>0&&(E.transmission.value=f.transmission,E.transmissionSamplerMap.value=T.texture,E.transmissionSamplerSize.value.set(T.width,T.height),f.transmissionMap&&(E.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,E.transmissionMapTransform)),E.thickness.value=f.thickness,f.thicknessMap&&(E.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,E.thicknessMapTransform)),E.attenuationDistance.value=f.attenuationDistance,E.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(E.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(E.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,E.anisotropyMapTransform))),E.specularIntensity.value=f.specularIntensity,E.specularColor.value.copy(f.specularColor),f.specularColorMap&&(E.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,E.specularColorMapTransform)),f.specularIntensityMap&&(E.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,E.specularIntensityMapTransform))}function m(E,f){f.matcap&&(E.matcap.value=f.matcap)}function S(E,f){const T=e.get(f).light;E.referencePosition.value.setFromMatrixPosition(T.matrixWorld),E.nearDistance.value=T.shadow.camera.near,E.farDistance.value=T.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function TS(n,e,t,i){let s={},r={},o=[];const c=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function d(T,A){const I=A.program;i.uniformBlockBinding(T,I)}function u(T,A){let I=s[T.id];I===void 0&&(m(T),I=p(T),s[T.id]=I,T.addEventListener("dispose",E));const D=A.program;i.updateUBOMapping(T,D);const O=e.render.frame;r[T.id]!==O&&(l(T),r[T.id]=O)}function p(T){const A=a();T.__bindingPointIndex=A;const I=n.createBuffer(),D=T.__size,O=T.usage;return n.bindBuffer(n.UNIFORM_BUFFER,I),n.bufferData(n.UNIFORM_BUFFER,D,O),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,A,I),I}function a(){for(let T=0;T<c;T++)if(o.indexOf(T)===-1)return o.push(T),T;return ft("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function l(T){const A=s[T.id],I=T.uniforms,D=T.__cache;n.bindBuffer(n.UNIFORM_BUFFER,A);for(let O=0,C=I.length;O<C;O++){const U=Array.isArray(I[O])?I[O]:[I[O]];for(let v=0,R=U.length;v<R;v++){const P=U[v];if(h(P,O,v,D)===!0){const V=P.__offset,Z=Array.isArray(P.value)?P.value:[P.value];let J=0;for(let $=0;$<Z.length;$++){const ie=Z[$],j=S(ie);typeof ie=="number"||typeof ie=="boolean"?(P.__data[0]=ie,n.bufferSubData(n.UNIFORM_BUFFER,V+J,P.__data)):ie.isMatrix3?(P.__data[0]=ie.elements[0],P.__data[1]=ie.elements[1],P.__data[2]=ie.elements[2],P.__data[3]=0,P.__data[4]=ie.elements[3],P.__data[5]=ie.elements[4],P.__data[6]=ie.elements[5],P.__data[7]=0,P.__data[8]=ie.elements[6],P.__data[9]=ie.elements[7],P.__data[10]=ie.elements[8],P.__data[11]=0):(ie.toArray(P.__data,J),J+=j.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,V,P.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function h(T,A,I,D){const O=T.value,C=A+"_"+I;if(D[C]===void 0)return typeof O=="number"||typeof O=="boolean"?D[C]=O:D[C]=O.clone(),!0;{const U=D[C];if(typeof O=="number"||typeof O=="boolean"){if(U!==O)return D[C]=O,!0}else if(U.equals(O)===!1)return U.copy(O),!0}return!1}function m(T){const A=T.uniforms;let I=0;const D=16;for(let C=0,U=A.length;C<U;C++){const v=Array.isArray(A[C])?A[C]:[A[C]];for(let R=0,P=v.length;R<P;R++){const V=v[R],Z=Array.isArray(V.value)?V.value:[V.value];for(let J=0,$=Z.length;J<$;J++){const ie=Z[J],j=S(ie),B=I%D,pe=B%j.boundary,Ee=B+pe;I+=pe,Ee!==0&&D-Ee<j.storage&&(I+=D-Ee),V.__data=new Float32Array(j.storage/Float32Array.BYTES_PER_ELEMENT),V.__offset=I,I+=j.storage}}}const O=I%D;return O>0&&(I+=D-O),T.__size=I,T.__cache={},this}function S(T){const A={boundary:0,storage:0};return typeof T=="number"||typeof T=="boolean"?(A.boundary=4,A.storage=4):T.isVector2?(A.boundary=8,A.storage=8):T.isVector3||T.isColor?(A.boundary=16,A.storage=12):T.isVector4?(A.boundary=16,A.storage=16):T.isMatrix3?(A.boundary=48,A.storage=48):T.isMatrix4?(A.boundary=64,A.storage=64):T.isTexture?ze("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ze("WebGLRenderer: Unsupported uniform value type.",T),A}function E(T){const A=T.target;A.removeEventListener("dispose",E);const I=o.indexOf(A.__bindingPointIndex);o.splice(I,1),n.deleteBuffer(s[A.id]),delete s[A.id],delete r[A.id]}function f(){for(const T in s)n.deleteBuffer(s[T]);o=[],s={},r={}}return{bind:d,update:u,dispose:f}}const RS=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let Ln=null;function vS(){return Ln===null&&(Ln=new Wh(RS,32,32,_o,Zi),Ln.minFilter=en,Ln.magFilter=en,Ln.wrapS=Cn,Ln.wrapT=Cn,Ln.generateMipmaps=!1,Ln.needsUpdate=!0),Ln}class MS{constructor(e={}){const{canvas:t=Eh(),context:i=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:c=!1,premultipliedAlpha:d=!0,preserveDrawingBuffer:u=!1,powerPreference:p="default",failIfMajorPerformanceCaveat:a=!1,reversedDepthBuffer:l=!1}=e;this.isWebGLRenderer=!0;let h;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");h=i.getContextAttributes().alpha}else h=o;const m=new Set([go,xo,Ao]),S=new Set([Un,pi,As,_s,mo,So]),E=new Uint32Array(4),f=new Int32Array(4);let T=null,A=null;const I=[],D=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Jn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const O=this;let C=!1;this._outputColorSpace=Gt;let U=0,v=0,R=null,P=-1,V=null;const Z=new St,J=new St;let $=null;const ie=new Qe(0);let j=0,B=t.width,pe=t.height,Ee=1,Le=null,Ve=null;const Xe=new St(0,0,B,pe),X=new St(0,0,B,pe);let w=!1;const M=new Cc;let g=!1,K=!1;const re=new _t,k=new G,ce=new St,Ae={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ue=!1;function H(){return R===null?Ee:1}let x=i;function q(L,W){return t.getContext(L,W)}try{const L={alpha:!0,depth:s,stencil:r,antialias:c,premultipliedAlpha:d,preserveDrawingBuffer:u,powerPreference:p,failIfMajorPerformanceCaveat:a};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${po}`),t.addEventListener("webglcontextlost",Se,!1),t.addEventListener("webglcontextrestored",he,!1),t.addEventListener("webglcontextcreationerror",Ne,!1),x===null){const W="webgl2";if(x=q(W,L),x===null)throw q(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(L){throw L("WebGLRenderer: "+L.message),L}let Q,N,y,ae,le,Te,b,_,Y,se,de,ne,De,ge,Ue,Ce,me,_e,Ge,Be,Oe,We,F,Ie;function Re(){Q=new NE(x),Q.init(),We=new ES(x,Q),N=new vE(x,Q,e,We),y=new fS(x,Q),N.reversedDepthBuffer&&l&&y.buffers.depth.setReversed(!0),ae=new wE(x),le=new eS,Te=new pS(x,Q,y,le,N,We,ae),b=new IE(O),_=new DE(O),Y=new Hd(x),F=new TE(x,Y),se=new PE(x,Y,ae,F),de=new BE(x,se,Y,ae),Ge=new FE(x,N,Te),Ce=new ME(le),ne=new jm(O,b,_,Q,N,F,Ce),De=new gS(O,le),ge=new nS,Ue=new lS(Q),_e=new gE(O,b,_,y,de,h,d),me=new hS(O,de,N),Ie=new TS(x,ae,N,y),Be=new RE(x,Q,ae),Oe=new UE(x,Q,ae),ae.programs=ne.programs,O.capabilities=N,O.extensions=Q,O.properties=le,O.renderLists=ge,O.shadowMap=me,O.state=y,O.info=ae}Re();const ve=new _S(O,x);this.xr=ve,this.getContext=function(){return x},this.getContextAttributes=function(){return x.getContextAttributes()},this.forceContextLoss=function(){const L=Q.get("WEBGL_lose_context");L&&L.loseContext()},this.forceContextRestore=function(){const L=Q.get("WEBGL_lose_context");L&&L.restoreContext()},this.getPixelRatio=function(){return Ee},this.setPixelRatio=function(L){L!==void 0&&(Ee=L,this.setSize(B,pe,!1))},this.getSize=function(L){return L.set(B,pe)},this.setSize=function(L,W,ee=!0){if(ve.isPresenting){ze("WebGLRenderer: Can't change size while VR device is presenting.");return}B=L,pe=W,t.width=Math.floor(L*Ee),t.height=Math.floor(W*Ee),ee===!0&&(t.style.width=L+"px",t.style.height=W+"px"),this.setViewport(0,0,L,W)},this.getDrawingBufferSize=function(L){return L.set(B*Ee,pe*Ee).floor()},this.setDrawingBufferSize=function(L,W,ee){B=L,pe=W,Ee=ee,t.width=Math.floor(L*ee),t.height=Math.floor(W*ee),this.setViewport(0,0,L,W)},this.getCurrentViewport=function(L){return L.copy(Z)},this.getViewport=function(L){return L.copy(Xe)},this.setViewport=function(L,W,ee,te){L.isVector4?Xe.set(L.x,L.y,L.z,L.w):Xe.set(L,W,ee,te),y.viewport(Z.copy(Xe).multiplyScalar(Ee).round())},this.getScissor=function(L){return L.copy(X)},this.setScissor=function(L,W,ee,te){L.isVector4?X.set(L.x,L.y,L.z,L.w):X.set(L,W,ee,te),y.scissor(J.copy(X).multiplyScalar(Ee).round())},this.getScissorTest=function(){return w},this.setScissorTest=function(L){y.setScissorTest(w=L)},this.setOpaqueSort=function(L){Le=L},this.setTransparentSort=function(L){Ve=L},this.getClearColor=function(L){return L.copy(_e.getClearColor())},this.setClearColor=function(){_e.setClearColor(...arguments)},this.getClearAlpha=function(){return _e.getClearAlpha()},this.setClearAlpha=function(){_e.setClearAlpha(...arguments)},this.clear=function(L=!0,W=!0,ee=!0){let te=0;if(L){let z=!1;if(R!==null){const xe=R.texture.format;z=m.has(xe)}if(z){const xe=R.texture.type,ye=S.has(xe),Pe=_e.getClearColor(),be=_e.getClearAlpha(),He=Pe.r,ke=Pe.g,we=Pe.b;ye?(E[0]=He,E[1]=ke,E[2]=we,E[3]=be,x.clearBufferuiv(x.COLOR,0,E)):(f[0]=He,f[1]=ke,f[2]=we,f[3]=be,x.clearBufferiv(x.COLOR,0,f))}else te|=x.COLOR_BUFFER_BIT}W&&(te|=x.DEPTH_BUFFER_BIT),ee&&(te|=x.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),x.clear(te)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Se,!1),t.removeEventListener("webglcontextrestored",he,!1),t.removeEventListener("webglcontextcreationerror",Ne,!1),_e.dispose(),ge.dispose(),Ue.dispose(),le.dispose(),b.dispose(),_.dispose(),de.dispose(),F.dispose(),Ie.dispose(),ne.dispose(),ve.dispose(),ve.removeEventListener("sessionstart",wo),ve.removeEventListener("sessionend",Fo),ti.stop()};function Se(L){L.preventDefault(),Qo("WebGLRenderer: Context Lost."),C=!0}function he(){Qo("WebGLRenderer: Context Restored."),C=!1;const L=ae.autoReset,W=me.enabled,ee=me.autoUpdate,te=me.needsUpdate,z=me.type;Re(),ae.autoReset=L,me.enabled=W,me.autoUpdate=ee,me.needsUpdate=te,me.type=z}function Ne(L){ft("WebGLRenderer: A WebGL context could not be created. Reason: ",L.statusMessage)}function Ke(L){const W=L.target;W.removeEventListener("dispose",Ke),ct(W)}function ct(L){nt(L),le.remove(L)}function nt(L){const W=le.get(L).programs;W!==void 0&&(W.forEach(function(ee){ne.releaseProgram(ee)}),L.isShaderMaterial&&ne.releaseShaderCache(L))}this.renderBufferDirect=function(L,W,ee,te,z,xe){W===null&&(W=Ae);const ye=z.isMesh&&z.matrixWorld.determinant()<0,Pe=Su(L,W,ee,te,z);y.setMaterial(te,ye);let be=ee.index,He=1;if(te.wireframe===!0){if(be=se.getWireframeAttribute(ee),be===void 0)return;He=2}const ke=ee.drawRange,we=ee.attributes.position;let Je=ke.start*He,it=(ke.start+ke.count)*He;xe!==null&&(Je=Math.max(Je,xe.start*He),it=Math.min(it,(xe.start+xe.count)*He)),be!==null?(Je=Math.max(Je,0),it=Math.min(it,be.count)):we!=null&&(Je=Math.max(Je,0),it=Math.min(it,we.count));const Et=it-Je;if(Et<0||Et===1/0)return;F.setup(z,te,Pe,ee,be);let mt,at=Be;if(be!==null&&(mt=Y.get(be),at=Oe,at.setIndex(mt)),z.isMesh)te.wireframe===!0?(y.setLineWidth(te.wireframeLinewidth*H()),at.setMode(x.LINES)):at.setMode(x.TRIANGLES);else if(z.isLine){let Fe=te.linewidth;Fe===void 0&&(Fe=1),y.setLineWidth(Fe*H()),z.isLineSegments?at.setMode(x.LINES):z.isLineLoop?at.setMode(x.LINE_LOOP):at.setMode(x.LINE_STRIP)}else z.isPoints?at.setMode(x.POINTS):z.isSprite&&at.setMode(x.TRIANGLES);if(z.isBatchedMesh)if(z._multiDrawInstances!==null)Ts("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),at.renderMultiDrawInstances(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount,z._multiDrawInstances);else if(Q.get("WEBGL_multi_draw"))at.renderMultiDraw(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount);else{const Fe=z._multiDrawStarts,ht=z._multiDrawCounts,$e=z._multiDrawCount,Vt=be?Y.get(be).bytesPerElement:1,_i=le.get(te).currentProgram.getUniforms();for(let kt=0;kt<$e;kt++)_i.setValue(x,"_gl_DrawID",kt),at.render(Fe[kt]/Vt,ht[kt])}else if(z.isInstancedMesh)at.renderInstances(Je,Et,z.count);else if(ee.isInstancedBufferGeometry){const Fe=ee._maxInstanceCount!==void 0?ee._maxInstanceCount:1/0,ht=Math.min(ee.instanceCount,Fe);at.renderInstances(Je,Et,ht)}else at.render(Je,Et)};function dn(L,W,ee){L.transparent===!0&&L.side===on&&L.forceSinglePass===!1?(L.side=Lt,L.needsUpdate=!0,bs(L,W,ee),L.side=_n,L.needsUpdate=!0,bs(L,W,ee),L.side=on):bs(L,W,ee)}this.compile=function(L,W,ee=null){ee===null&&(ee=L),A=Ue.get(ee),A.init(W),D.push(A),ee.traverseVisible(function(z){z.isLight&&z.layers.test(W.layers)&&(A.pushLight(z),z.castShadow&&A.pushShadow(z))}),L!==ee&&L.traverseVisible(function(z){z.isLight&&z.layers.test(W.layers)&&(A.pushLight(z),z.castShadow&&A.pushShadow(z))}),A.setupLights();const te=new Set;return L.traverse(function(z){if(!(z.isMesh||z.isPoints||z.isLine||z.isSprite))return;const xe=z.material;if(xe)if(Array.isArray(xe))for(let ye=0;ye<xe.length;ye++){const Pe=xe[ye];dn(Pe,ee,z),te.add(Pe)}else dn(xe,ee,z),te.add(xe)}),A=D.pop(),te},this.compileAsync=function(L,W,ee=null){const te=this.compile(L,W,ee);return new Promise(z=>{function xe(){if(te.forEach(function(ye){le.get(ye).currentProgram.isReady()&&te.delete(ye)}),te.size===0){z(L);return}setTimeout(xe,10)}Q.get("KHR_parallel_shader_compile")!==null?xe():setTimeout(xe,10)})};let nn=null;function mu(L){nn&&nn(L)}function wo(){ti.stop()}function Fo(){ti.start()}const ti=new Yc;ti.setAnimationLoop(mu),typeof self<"u"&&ti.setContext(self),this.setAnimationLoop=function(L){nn=L,ve.setAnimationLoop(L),L===null?ti.stop():ti.start()},ve.addEventListener("sessionstart",wo),ve.addEventListener("sessionend",Fo),this.render=function(L,W){if(W!==void 0&&W.isCamera!==!0){ft("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(C===!0)return;if(L.matrixWorldAutoUpdate===!0&&L.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),ve.enabled===!0&&ve.isPresenting===!0&&(ve.cameraAutoUpdate===!0&&ve.updateCamera(W),W=ve.getCamera()),L.isScene===!0&&L.onBeforeRender(O,L,W,R),A=Ue.get(L,D.length),A.init(W),D.push(A),re.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),M.setFromProjectionMatrix(re,Sn,W.reversedDepth),K=this.localClippingEnabled,g=Ce.init(this.clippingPlanes,K),T=ge.get(L,I.length),T.init(),I.push(T),ve.enabled===!0&&ve.isPresenting===!0){const xe=O.xr.getDepthSensingMesh();xe!==null&&br(xe,W,-1/0,O.sortObjects)}br(L,W,0,O.sortObjects),T.finish(),O.sortObjects===!0&&T.sort(Le,Ve),ue=ve.enabled===!1||ve.isPresenting===!1||ve.hasDepthSensing()===!1,ue&&_e.addToRenderList(T,L),this.info.render.frame++,g===!0&&Ce.beginShadows();const ee=A.state.shadowsArray;me.render(ee,L,W),g===!0&&Ce.endShadows(),this.info.autoReset===!0&&this.info.reset();const te=T.opaque,z=T.transmissive;if(A.setupLights(),W.isArrayCamera){const xe=W.cameras;if(z.length>0)for(let ye=0,Pe=xe.length;ye<Pe;ye++){const be=xe[ye];Ho(te,z,L,be)}ue&&_e.render(L);for(let ye=0,Pe=xe.length;ye<Pe;ye++){const be=xe[ye];Bo(T,L,be,be.viewport)}}else z.length>0&&Ho(te,z,L,W),ue&&_e.render(L),Bo(T,L,W);R!==null&&v===0&&(Te.updateMultisampleRenderTarget(R),Te.updateRenderTargetMipmap(R)),L.isScene===!0&&L.onAfterRender(O,L,W),F.resetDefaultState(),P=-1,V=null,D.pop(),D.length>0?(A=D[D.length-1],g===!0&&Ce.setGlobalState(O.clippingPlanes,A.state.camera)):A=null,I.pop(),I.length>0?T=I[I.length-1]:T=null};function br(L,W,ee,te){if(L.visible===!1)return;if(L.layers.test(W.layers)){if(L.isGroup)ee=L.renderOrder;else if(L.isLOD)L.autoUpdate===!0&&L.update(W);else if(L.isLight)A.pushLight(L),L.castShadow&&A.pushShadow(L);else if(L.isSprite){if(!L.frustumCulled||M.intersectsSprite(L)){te&&ce.setFromMatrixPosition(L.matrixWorld).applyMatrix4(re);const ye=de.update(L),Pe=L.material;Pe.visible&&T.push(L,ye,Pe,ee,ce.z,null)}}else if((L.isMesh||L.isLine||L.isPoints)&&(!L.frustumCulled||M.intersectsObject(L))){const ye=de.update(L),Pe=L.material;if(te&&(L.boundingSphere!==void 0?(L.boundingSphere===null&&L.computeBoundingSphere(),ce.copy(L.boundingSphere.center)):(ye.boundingSphere===null&&ye.computeBoundingSphere(),ce.copy(ye.boundingSphere.center)),ce.applyMatrix4(L.matrixWorld).applyMatrix4(re)),Array.isArray(Pe)){const be=ye.groups;for(let He=0,ke=be.length;He<ke;He++){const we=be[He],Je=Pe[we.materialIndex];Je&&Je.visible&&T.push(L,ye,Je,ee,ce.z,we)}}else Pe.visible&&T.push(L,ye,Pe,ee,ce.z,null)}}const xe=L.children;for(let ye=0,Pe=xe.length;ye<Pe;ye++)br(xe[ye],W,ee,te)}function Bo(L,W,ee,te){const{opaque:z,transmissive:xe,transparent:ye}=L;A.setupLightsView(ee),g===!0&&Ce.setGlobalState(O.clippingPlanes,ee),te&&y.viewport(Z.copy(te)),z.length>0&&Os(z,W,ee),xe.length>0&&Os(xe,W,ee),ye.length>0&&Os(ye,W,ee),y.buffers.depth.setTest(!0),y.buffers.depth.setMask(!0),y.buffers.color.setMask(!0),y.setPolygonOffset(!1)}function Ho(L,W,ee,te){if((ee.isScene===!0?ee.overrideMaterial:null)!==null)return;A.state.transmissionRenderTarget[te.id]===void 0&&(A.state.transmissionRenderTarget[te.id]=new ei(1,1,{generateMipmaps:!0,type:Q.has("EXT_color_buffer_half_float")||Q.has("EXT_color_buffer_float")?Zi:Un,minFilter:di,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:je.workingColorSpace}));const xe=A.state.transmissionRenderTarget[te.id],ye=te.viewport||Z;xe.setSize(ye.z*O.transmissionResolutionScale,ye.w*O.transmissionResolutionScale);const Pe=O.getRenderTarget(),be=O.getActiveCubeFace(),He=O.getActiveMipmapLevel();O.setRenderTarget(xe),O.getClearColor(ie),j=O.getClearAlpha(),j<1&&O.setClearColor(16777215,.5),O.clear(),ue&&_e.render(ee);const ke=O.toneMapping;O.toneMapping=Jn;const we=te.viewport;if(te.viewport!==void 0&&(te.viewport=void 0),A.setupLightsView(te),g===!0&&Ce.setGlobalState(O.clippingPlanes,te),Os(L,ee,te),Te.updateMultisampleRenderTarget(xe),Te.updateRenderTargetMipmap(xe),Q.has("WEBGL_multisampled_render_to_texture")===!1){let Je=!1;for(let it=0,Et=W.length;it<Et;it++){const mt=W[it],{object:at,geometry:Fe,material:ht,group:$e}=mt;if(ht.side===on&&at.layers.test(te.layers)){const Vt=ht.side;ht.side=Lt,ht.needsUpdate=!0,Go(at,ee,te,Fe,ht,$e),ht.side=Vt,ht.needsUpdate=!0,Je=!0}}Je===!0&&(Te.updateMultisampleRenderTarget(xe),Te.updateRenderTargetMipmap(xe))}O.setRenderTarget(Pe,be,He),O.setClearColor(ie,j),we!==void 0&&(te.viewport=we),O.toneMapping=ke}function Os(L,W,ee){const te=W.isScene===!0?W.overrideMaterial:null;for(let z=0,xe=L.length;z<xe;z++){const ye=L[z],{object:Pe,geometry:be,group:He}=ye;let ke=ye.material;ke.allowOverride===!0&&te!==null&&(ke=te),Pe.layers.test(ee.layers)&&Go(Pe,W,ee,be,ke,He)}}function Go(L,W,ee,te,z,xe){L.onBeforeRender(O,W,ee,te,z,xe),L.modelViewMatrix.multiplyMatrices(ee.matrixWorldInverse,L.matrixWorld),L.normalMatrix.getNormalMatrix(L.modelViewMatrix),z.onBeforeRender(O,W,ee,te,L,xe),z.transparent===!0&&z.side===on&&z.forceSinglePass===!1?(z.side=Lt,z.needsUpdate=!0,O.renderBufferDirect(ee,W,te,z,L,xe),z.side=_n,z.needsUpdate=!0,O.renderBufferDirect(ee,W,te,z,L,xe),z.side=on):O.renderBufferDirect(ee,W,te,z,L,xe),L.onAfterRender(O,W,ee,te,z,xe)}function bs(L,W,ee){W.isScene!==!0&&(W=Ae);const te=le.get(L),z=A.state.lights,xe=A.state.shadowsArray,ye=z.state.version,Pe=ne.getParameters(L,z.state,xe,W,ee),be=ne.getProgramCacheKey(Pe);let He=te.programs;te.environment=L.isMeshStandardMaterial?W.environment:null,te.fog=W.fog,te.envMap=(L.isMeshStandardMaterial?_:b).get(L.envMap||te.environment),te.envMapRotation=te.environment!==null&&L.envMap===null?W.environmentRotation:L.envMapRotation,He===void 0&&(L.addEventListener("dispose",Ke),He=new Map,te.programs=He);let ke=He.get(be);if(ke!==void 0){if(te.currentProgram===ke&&te.lightsStateVersion===ye)return ko(L,Pe),ke}else Pe.uniforms=ne.getUniforms(L),L.onBeforeCompile(Pe,O),ke=ne.acquireProgram(Pe,be),He.set(be,ke),te.uniforms=Pe.uniforms;const we=te.uniforms;return(!L.isShaderMaterial&&!L.isRawShaderMaterial||L.clipping===!0)&&(we.clippingPlanes=Ce.uniform),ko(L,Pe),te.needsLights=_u(L),te.lightsStateVersion=ye,te.needsLights&&(we.ambientLightColor.value=z.state.ambient,we.lightProbe.value=z.state.probe,we.directionalLights.value=z.state.directional,we.directionalLightShadows.value=z.state.directionalShadow,we.spotLights.value=z.state.spot,we.spotLightShadows.value=z.state.spotShadow,we.rectAreaLights.value=z.state.rectArea,we.ltc_1.value=z.state.rectAreaLTC1,we.ltc_2.value=z.state.rectAreaLTC2,we.pointLights.value=z.state.point,we.pointLightShadows.value=z.state.pointShadow,we.hemisphereLights.value=z.state.hemi,we.directionalShadowMap.value=z.state.directionalShadowMap,we.directionalShadowMatrix.value=z.state.directionalShadowMatrix,we.spotShadowMap.value=z.state.spotShadowMap,we.spotLightMatrix.value=z.state.spotLightMatrix,we.spotLightMap.value=z.state.spotLightMap,we.pointShadowMap.value=z.state.pointShadowMap,we.pointShadowMatrix.value=z.state.pointShadowMatrix),te.currentProgram=ke,te.uniformsList=null,ke}function Vo(L){if(L.uniformsList===null){const W=L.currentProgram.getUniforms();L.uniformsList=cr.seqWithValue(W.seq,L.uniforms)}return L.uniformsList}function ko(L,W){const ee=le.get(L);ee.outputColorSpace=W.outputColorSpace,ee.batching=W.batching,ee.batchingColor=W.batchingColor,ee.instancing=W.instancing,ee.instancingColor=W.instancingColor,ee.instancingMorph=W.instancingMorph,ee.skinning=W.skinning,ee.morphTargets=W.morphTargets,ee.morphNormals=W.morphNormals,ee.morphColors=W.morphColors,ee.morphTargetsCount=W.morphTargetsCount,ee.numClippingPlanes=W.numClippingPlanes,ee.numIntersection=W.numClipIntersection,ee.vertexAlphas=W.vertexAlphas,ee.vertexTangents=W.vertexTangents,ee.toneMapping=W.toneMapping}function Su(L,W,ee,te,z){W.isScene!==!0&&(W=Ae),Te.resetTextureUnits();const xe=W.fog,ye=te.isMeshStandardMaterial?W.environment:null,Pe=R===null?O.outputColorSpace:R.isXRRenderTarget===!0?R.texture.colorSpace:zi,be=(te.isMeshStandardMaterial?_:b).get(te.envMap||ye),He=te.vertexColors===!0&&!!ee.attributes.color&&ee.attributes.color.itemSize===4,ke=!!ee.attributes.tangent&&(!!te.normalMap||te.anisotropy>0),we=!!ee.morphAttributes.position,Je=!!ee.morphAttributes.normal,it=!!ee.morphAttributes.color;let Et=Jn;te.toneMapped&&(R===null||R.isXRRenderTarget===!0)&&(Et=O.toneMapping);const mt=ee.morphAttributes.position||ee.morphAttributes.normal||ee.morphAttributes.color,at=mt!==void 0?mt.length:0,Fe=le.get(te),ht=A.state.lights;if(g===!0&&(K===!0||L!==V)){const bt=L===V&&te.id===P;Ce.setState(te,L,bt)}let $e=!1;te.version===Fe.__version?(Fe.needsLights&&Fe.lightsStateVersion!==ht.state.version||Fe.outputColorSpace!==Pe||z.isBatchedMesh&&Fe.batching===!1||!z.isBatchedMesh&&Fe.batching===!0||z.isBatchedMesh&&Fe.batchingColor===!0&&z.colorTexture===null||z.isBatchedMesh&&Fe.batchingColor===!1&&z.colorTexture!==null||z.isInstancedMesh&&Fe.instancing===!1||!z.isInstancedMesh&&Fe.instancing===!0||z.isSkinnedMesh&&Fe.skinning===!1||!z.isSkinnedMesh&&Fe.skinning===!0||z.isInstancedMesh&&Fe.instancingColor===!0&&z.instanceColor===null||z.isInstancedMesh&&Fe.instancingColor===!1&&z.instanceColor!==null||z.isInstancedMesh&&Fe.instancingMorph===!0&&z.morphTexture===null||z.isInstancedMesh&&Fe.instancingMorph===!1&&z.morphTexture!==null||Fe.envMap!==be||te.fog===!0&&Fe.fog!==xe||Fe.numClippingPlanes!==void 0&&(Fe.numClippingPlanes!==Ce.numPlanes||Fe.numIntersection!==Ce.numIntersection)||Fe.vertexAlphas!==He||Fe.vertexTangents!==ke||Fe.morphTargets!==we||Fe.morphNormals!==Je||Fe.morphColors!==it||Fe.toneMapping!==Et||Fe.morphTargetsCount!==at)&&($e=!0):($e=!0,Fe.__version=te.version);let Vt=Fe.currentProgram;$e===!0&&(Vt=bs(te,W,z));let _i=!1,kt=!1,ns=!1;const dt=Vt.getUniforms(),wt=Fe.uniforms;if(y.useProgram(Vt.program)&&(_i=!0,kt=!0,ns=!0),te.id!==P&&(P=te.id,kt=!0),_i||V!==L){y.buffers.depth.getReversed()&&L.reversedDepth!==!0&&(L._reversedDepth=!0,L.updateProjectionMatrix()),dt.setValue(x,"projectionMatrix",L.projectionMatrix),dt.setValue(x,"viewMatrix",L.matrixWorldInverse);const Ft=dt.map.cameraPosition;Ft!==void 0&&Ft.setValue(x,k.setFromMatrixPosition(L.matrixWorld)),N.logarithmicDepthBuffer&&dt.setValue(x,"logDepthBufFC",2/(Math.log(L.far+1)/Math.LN2)),(te.isMeshPhongMaterial||te.isMeshToonMaterial||te.isMeshLambertMaterial||te.isMeshBasicMaterial||te.isMeshStandardMaterial||te.isShaderMaterial)&&dt.setValue(x,"isOrthographic",L.isOrthographicCamera===!0),V!==L&&(V=L,kt=!0,ns=!0)}if(z.isSkinnedMesh){dt.setOptional(x,z,"bindMatrix"),dt.setOptional(x,z,"bindMatrixInverse");const bt=z.skeleton;bt&&(bt.boneTexture===null&&bt.computeBoneTexture(),dt.setValue(x,"boneTexture",bt.boneTexture,Te))}z.isBatchedMesh&&(dt.setOptional(x,z,"batchingTexture"),dt.setValue(x,"batchingTexture",z._matricesTexture,Te),dt.setOptional(x,z,"batchingIdTexture"),dt.setValue(x,"batchingIdTexture",z._indirectTexture,Te),dt.setOptional(x,z,"batchingColorTexture"),z._colorsTexture!==null&&dt.setValue(x,"batchingColorTexture",z._colorsTexture,Te));const Jt=ee.morphAttributes;if((Jt.position!==void 0||Jt.normal!==void 0||Jt.color!==void 0)&&Ge.update(z,ee,Vt),(kt||Fe.receiveShadow!==z.receiveShadow)&&(Fe.receiveShadow=z.receiveShadow,dt.setValue(x,"receiveShadow",z.receiveShadow)),te.isMeshGouraudMaterial&&te.envMap!==null&&(wt.envMap.value=be,wt.flipEnvMap.value=be.isCubeTexture&&be.isRenderTargetTexture===!1?-1:1),te.isMeshStandardMaterial&&te.envMap===null&&W.environment!==null&&(wt.envMapIntensity.value=W.environmentIntensity),wt.dfgLUT!==void 0&&(wt.dfgLUT.value=vS()),kt&&(dt.setValue(x,"toneMappingExposure",O.toneMappingExposure),Fe.needsLights&&Au(wt,ns),xe&&te.fog===!0&&De.refreshFogUniforms(wt,xe),De.refreshMaterialUniforms(wt,te,Ee,pe,A.state.transmissionRenderTarget[L.id]),cr.upload(x,Vo(Fe),wt,Te)),te.isShaderMaterial&&te.uniformsNeedUpdate===!0&&(cr.upload(x,Vo(Fe),wt,Te),te.uniformsNeedUpdate=!1),te.isSpriteMaterial&&dt.setValue(x,"center",z.center),dt.setValue(x,"modelViewMatrix",z.modelViewMatrix),dt.setValue(x,"normalMatrix",z.normalMatrix),dt.setValue(x,"modelMatrix",z.matrixWorld),te.isShaderMaterial||te.isRawShaderMaterial){const bt=te.uniformsGroups;for(let Ft=0,Cr=bt.length;Ft<Cr;Ft++){const ni=bt[Ft];Ie.update(ni,Vt),Ie.bind(ni,Vt)}}return Vt}function Au(L,W){L.ambientLightColor.needsUpdate=W,L.lightProbe.needsUpdate=W,L.directionalLights.needsUpdate=W,L.directionalLightShadows.needsUpdate=W,L.pointLights.needsUpdate=W,L.pointLightShadows.needsUpdate=W,L.spotLights.needsUpdate=W,L.spotLightShadows.needsUpdate=W,L.rectAreaLights.needsUpdate=W,L.hemisphereLights.needsUpdate=W}function _u(L){return L.isMeshLambertMaterial||L.isMeshToonMaterial||L.isMeshPhongMaterial||L.isMeshStandardMaterial||L.isShadowMaterial||L.isShaderMaterial&&L.lights===!0}this.getActiveCubeFace=function(){return U},this.getActiveMipmapLevel=function(){return v},this.getRenderTarget=function(){return R},this.setRenderTargetTextures=function(L,W,ee){const te=le.get(L);te.__autoAllocateDepthBuffer=L.resolveDepthBuffer===!1,te.__autoAllocateDepthBuffer===!1&&(te.__useRenderToTexture=!1),le.get(L.texture).__webglTexture=W,le.get(L.depthTexture).__webglTexture=te.__autoAllocateDepthBuffer?void 0:ee,te.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(L,W){const ee=le.get(L);ee.__webglFramebuffer=W,ee.__useDefaultFramebuffer=W===void 0};const xu=x.createFramebuffer();this.setRenderTarget=function(L,W=0,ee=0){R=L,U=W,v=ee;let te=!0,z=null,xe=!1,ye=!1;if(L){const be=le.get(L);if(be.__useDefaultFramebuffer!==void 0)y.bindFramebuffer(x.FRAMEBUFFER,null),te=!1;else if(be.__webglFramebuffer===void 0)Te.setupRenderTarget(L);else if(be.__hasExternalTextures)Te.rebindTextures(L,le.get(L.texture).__webglTexture,le.get(L.depthTexture).__webglTexture);else if(L.depthBuffer){const we=L.depthTexture;if(be.__boundDepthTexture!==we){if(we!==null&&le.has(we)&&(L.width!==we.image.width||L.height!==we.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Te.setupDepthRenderbuffer(L)}}const He=L.texture;(He.isData3DTexture||He.isDataArrayTexture||He.isCompressedArrayTexture)&&(ye=!0);const ke=le.get(L).__webglFramebuffer;L.isWebGLCubeRenderTarget?(Array.isArray(ke[W])?z=ke[W][ee]:z=ke[W],xe=!0):L.samples>0&&Te.useMultisampledRTT(L)===!1?z=le.get(L).__webglMultisampledFramebuffer:Array.isArray(ke)?z=ke[ee]:z=ke,Z.copy(L.viewport),J.copy(L.scissor),$=L.scissorTest}else Z.copy(Xe).multiplyScalar(Ee).floor(),J.copy(X).multiplyScalar(Ee).floor(),$=w;if(ee!==0&&(z=xu),y.bindFramebuffer(x.FRAMEBUFFER,z)&&te&&y.drawBuffers(L,z),y.viewport(Z),y.scissor(J),y.setScissorTest($),xe){const be=le.get(L.texture);x.framebufferTexture2D(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_CUBE_MAP_POSITIVE_X+W,be.__webglTexture,ee)}else if(ye){const be=W;for(let He=0;He<L.textures.length;He++){const ke=le.get(L.textures[He]);x.framebufferTextureLayer(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0+He,ke.__webglTexture,ee,be)}}else if(L!==null&&ee!==0){const be=le.get(L.texture);x.framebufferTexture2D(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,be.__webglTexture,ee)}P=-1},this.readRenderTargetPixels=function(L,W,ee,te,z,xe,ye,Pe=0){if(!(L&&L.isWebGLRenderTarget)){ft("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=le.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&ye!==void 0&&(be=be[ye]),be){y.bindFramebuffer(x.FRAMEBUFFER,be);try{const He=L.textures[Pe],ke=He.format,we=He.type;if(!N.textureFormatReadable(ke)){ft("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!N.textureTypeReadable(we)){ft("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=L.width-te&&ee>=0&&ee<=L.height-z&&(L.textures.length>1&&x.readBuffer(x.COLOR_ATTACHMENT0+Pe),x.readPixels(W,ee,te,z,We.convert(ke),We.convert(we),xe))}finally{const He=R!==null?le.get(R).__webglFramebuffer:null;y.bindFramebuffer(x.FRAMEBUFFER,He)}}},this.readRenderTargetPixelsAsync=async function(L,W,ee,te,z,xe,ye,Pe=0){if(!(L&&L.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=le.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&ye!==void 0&&(be=be[ye]),be)if(W>=0&&W<=L.width-te&&ee>=0&&ee<=L.height-z){y.bindFramebuffer(x.FRAMEBUFFER,be);const He=L.textures[Pe],ke=He.format,we=He.type;if(!N.textureFormatReadable(ke))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!N.textureTypeReadable(we))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Je=x.createBuffer();x.bindBuffer(x.PIXEL_PACK_BUFFER,Je),x.bufferData(x.PIXEL_PACK_BUFFER,xe.byteLength,x.STREAM_READ),L.textures.length>1&&x.readBuffer(x.COLOR_ATTACHMENT0+Pe),x.readPixels(W,ee,te,z,We.convert(ke),We.convert(we),0);const it=R!==null?le.get(R).__webglFramebuffer:null;y.bindFramebuffer(x.FRAMEBUFFER,it);const Et=x.fenceSync(x.SYNC_GPU_COMMANDS_COMPLETE,0);return x.flush(),await mh(x,Et,4),x.bindBuffer(x.PIXEL_PACK_BUFFER,Je),x.getBufferSubData(x.PIXEL_PACK_BUFFER,0,xe),x.deleteBuffer(Je),x.deleteSync(Et),xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(L,W=null,ee=0){const te=Math.pow(2,-ee),z=Math.floor(L.image.width*te),xe=Math.floor(L.image.height*te),ye=W!==null?W.x:0,Pe=W!==null?W.y:0;Te.setTexture2D(L,0),x.copyTexSubImage2D(x.TEXTURE_2D,ee,0,0,ye,Pe,z,xe),y.unbindTexture()};const gu=x.createFramebuffer(),Tu=x.createFramebuffer();this.copyTextureToTexture=function(L,W,ee=null,te=null,z=0,xe=null){xe===null&&(z!==0?(Ts("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),xe=z,z=0):xe=0);let ye,Pe,be,He,ke,we,Je,it,Et;const mt=L.isCompressedTexture?L.mipmaps[xe]:L.image;if(ee!==null)ye=ee.max.x-ee.min.x,Pe=ee.max.y-ee.min.y,be=ee.isBox3?ee.max.z-ee.min.z:1,He=ee.min.x,ke=ee.min.y,we=ee.isBox3?ee.min.z:0;else{const Jt=Math.pow(2,-z);ye=Math.floor(mt.width*Jt),Pe=Math.floor(mt.height*Jt),L.isDataArrayTexture?be=mt.depth:L.isData3DTexture?be=Math.floor(mt.depth*Jt):be=1,He=0,ke=0,we=0}te!==null?(Je=te.x,it=te.y,Et=te.z):(Je=0,it=0,Et=0);const at=We.convert(W.format),Fe=We.convert(W.type);let ht;W.isData3DTexture?(Te.setTexture3D(W,0),ht=x.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(Te.setTexture2DArray(W,0),ht=x.TEXTURE_2D_ARRAY):(Te.setTexture2D(W,0),ht=x.TEXTURE_2D),x.pixelStorei(x.UNPACK_FLIP_Y_WEBGL,W.flipY),x.pixelStorei(x.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),x.pixelStorei(x.UNPACK_ALIGNMENT,W.unpackAlignment);const $e=x.getParameter(x.UNPACK_ROW_LENGTH),Vt=x.getParameter(x.UNPACK_IMAGE_HEIGHT),_i=x.getParameter(x.UNPACK_SKIP_PIXELS),kt=x.getParameter(x.UNPACK_SKIP_ROWS),ns=x.getParameter(x.UNPACK_SKIP_IMAGES);x.pixelStorei(x.UNPACK_ROW_LENGTH,mt.width),x.pixelStorei(x.UNPACK_IMAGE_HEIGHT,mt.height),x.pixelStorei(x.UNPACK_SKIP_PIXELS,He),x.pixelStorei(x.UNPACK_SKIP_ROWS,ke),x.pixelStorei(x.UNPACK_SKIP_IMAGES,we);const dt=L.isDataArrayTexture||L.isData3DTexture,wt=W.isDataArrayTexture||W.isData3DTexture;if(L.isDepthTexture){const Jt=le.get(L),bt=le.get(W),Ft=le.get(Jt.__renderTarget),Cr=le.get(bt.__renderTarget);y.bindFramebuffer(x.READ_FRAMEBUFFER,Ft.__webglFramebuffer),y.bindFramebuffer(x.DRAW_FRAMEBUFFER,Cr.__webglFramebuffer);for(let ni=0;ni<be;ni++)dt&&(x.framebufferTextureLayer(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,le.get(L).__webglTexture,z,we+ni),x.framebufferTextureLayer(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,le.get(W).__webglTexture,xe,Et+ni)),x.blitFramebuffer(He,ke,ye,Pe,Je,it,ye,Pe,x.DEPTH_BUFFER_BIT,x.NEAREST);y.bindFramebuffer(x.READ_FRAMEBUFFER,null),y.bindFramebuffer(x.DRAW_FRAMEBUFFER,null)}else if(z!==0||L.isRenderTargetTexture||le.has(L)){const Jt=le.get(L),bt=le.get(W);y.bindFramebuffer(x.READ_FRAMEBUFFER,gu),y.bindFramebuffer(x.DRAW_FRAMEBUFFER,Tu);for(let Ft=0;Ft<be;Ft++)dt?x.framebufferTextureLayer(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,Jt.__webglTexture,z,we+Ft):x.framebufferTexture2D(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,Jt.__webglTexture,z),wt?x.framebufferTextureLayer(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,bt.__webglTexture,xe,Et+Ft):x.framebufferTexture2D(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,bt.__webglTexture,xe),z!==0?x.blitFramebuffer(He,ke,ye,Pe,Je,it,ye,Pe,x.COLOR_BUFFER_BIT,x.NEAREST):wt?x.copyTexSubImage3D(ht,xe,Je,it,Et+Ft,He,ke,ye,Pe):x.copyTexSubImage2D(ht,xe,Je,it,He,ke,ye,Pe);y.bindFramebuffer(x.READ_FRAMEBUFFER,null),y.bindFramebuffer(x.DRAW_FRAMEBUFFER,null)}else wt?L.isDataTexture||L.isData3DTexture?x.texSubImage3D(ht,xe,Je,it,Et,ye,Pe,be,at,Fe,mt.data):W.isCompressedArrayTexture?x.compressedTexSubImage3D(ht,xe,Je,it,Et,ye,Pe,be,at,mt.data):x.texSubImage3D(ht,xe,Je,it,Et,ye,Pe,be,at,Fe,mt):L.isDataTexture?x.texSubImage2D(x.TEXTURE_2D,xe,Je,it,ye,Pe,at,Fe,mt.data):L.isCompressedTexture?x.compressedTexSubImage2D(x.TEXTURE_2D,xe,Je,it,mt.width,mt.height,at,mt.data):x.texSubImage2D(x.TEXTURE_2D,xe,Je,it,ye,Pe,at,Fe,mt);x.pixelStorei(x.UNPACK_ROW_LENGTH,$e),x.pixelStorei(x.UNPACK_IMAGE_HEIGHT,Vt),x.pixelStorei(x.UNPACK_SKIP_PIXELS,_i),x.pixelStorei(x.UNPACK_SKIP_ROWS,kt),x.pixelStorei(x.UNPACK_SKIP_IMAGES,ns),xe===0&&W.generateMipmaps&&x.generateMipmap(ht),y.unbindTexture()},this.initRenderTarget=function(L){le.get(L).__webglFramebuffer===void 0&&Te.setupRenderTarget(L)},this.initTexture=function(L){L.isCubeTexture?Te.setTextureCube(L,0):L.isData3DTexture?Te.setTexture3D(L,0):L.isDataArrayTexture||L.isCompressedArrayTexture?Te.setTexture2DArray(L,0):Te.setTexture2D(L,0),y.unbindTexture()},this.resetState=function(){U=0,v=0,R=null,y.reset(),F.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Sn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=je._getDrawingBufferColorSpace(e),t.unpackColorSpace=je._getUnpackColorSpace()}}var cs=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},ua={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var Xl;function IS(){return Xl||(Xl=1,(function(n){(function(){var e=function(){this.init()};e.prototype={init:function(){var a=this||t;return a._counter=1e3,a._html5AudioPool=[],a.html5PoolSize=10,a._codecs={},a._howls=[],a._muted=!1,a._volume=1,a._canPlayEvent="canplaythrough",a._navigator=typeof window<"u"&&window.navigator?window.navigator:null,a.masterGain=null,a.noAudio=!1,a.usingWebAudio=!0,a.autoSuspend=!0,a.ctx=null,a.autoUnlock=!0,a._setup(),a},volume:function(a){var l=this||t;if(a=parseFloat(a),l.ctx||p(),typeof a<"u"&&a>=0&&a<=1){if(l._volume=a,l._muted)return l;l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a,t.ctx.currentTime);for(var h=0;h<l._howls.length;h++)if(!l._howls[h]._webAudio)for(var m=l._howls[h]._getSoundIds(),S=0;S<m.length;S++){var E=l._howls[h]._soundById(m[S]);E&&E._node&&(E._node.volume=E._volume*a)}return l}return l._volume},mute:function(a){var l=this||t;l.ctx||p(),l._muted=a,l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a?0:l._volume,t.ctx.currentTime);for(var h=0;h<l._howls.length;h++)if(!l._howls[h]._webAudio)for(var m=l._howls[h]._getSoundIds(),S=0;S<m.length;S++){var E=l._howls[h]._soundById(m[S]);E&&E._node&&(E._node.muted=a?!0:E._muted)}return l},stop:function(){for(var a=this||t,l=0;l<a._howls.length;l++)a._howls[l].stop();return a},unload:function(){for(var a=this||t,l=a._howls.length-1;l>=0;l--)a._howls[l].unload();return a.usingWebAudio&&a.ctx&&typeof a.ctx.close<"u"&&(a.ctx.close(),a.ctx=null,p()),a},codecs:function(a){return(this||t)._codecs[a.replace(/^x-/,"")]},_setup:function(){var a=this||t;if(a.state=a.ctx&&a.ctx.state||"suspended",a._autoSuspend(),!a.usingWebAudio)if(typeof Audio<"u")try{var l=new Audio;typeof l.oncanplaythrough>"u"&&(a._canPlayEvent="canplay")}catch{a.noAudio=!0}else a.noAudio=!0;try{var l=new Audio;l.muted&&(a.noAudio=!0)}catch{}return a.noAudio||a._setupCodecs(),a},_setupCodecs:function(){var a=this||t,l=null;try{l=typeof Audio<"u"?new Audio:null}catch{return a}if(!l||typeof l.canPlayType!="function")return a;var h=l.canPlayType("audio/mpeg;").replace(/^no$/,""),m=a._navigator?a._navigator.userAgent:"",S=m.match(/OPR\/(\d+)/g),E=S&&parseInt(S[0].split("/")[1],10)<33,f=m.indexOf("Safari")!==-1&&m.indexOf("Chrome")===-1,T=m.match(/Version\/(.*?) /),A=f&&T&&parseInt(T[1],10)<15;return a._codecs={mp3:!!(!E&&(h||l.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!h,opus:!!l.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(l.canPlayType('audio/wav; codecs="1"')||l.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!l.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!l.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(l.canPlayType("audio/x-m4a;")||l.canPlayType("audio/m4a;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(l.canPlayType("audio/x-m4b;")||l.canPlayType("audio/m4b;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(l.canPlayType("audio/x-mp4;")||l.canPlayType("audio/mp4;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!l.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(l.canPlayType("audio/x-flac;")||l.canPlayType("audio/flac;")).replace(/^no$/,"")},a},_unlockAudio:function(){var a=this||t;if(!(a._audioUnlocked||!a.ctx)){a._audioUnlocked=!1,a.autoUnlock=!1,!a._mobileUnloaded&&a.ctx.sampleRate!==44100&&(a._mobileUnloaded=!0,a.unload()),a._scratchBuffer=a.ctx.createBuffer(1,1,22050);var l=function(h){for(;a._html5AudioPool.length<a.html5PoolSize;)try{var m=new Audio;m._unlocked=!0,a._releaseHtml5Audio(m)}catch{a.noAudio=!0;break}for(var S=0;S<a._howls.length;S++)if(!a._howls[S]._webAudio)for(var E=a._howls[S]._getSoundIds(),f=0;f<E.length;f++){var T=a._howls[S]._soundById(E[f]);T&&T._node&&!T._node._unlocked&&(T._node._unlocked=!0,T._node.load())}a._autoResume();var A=a.ctx.createBufferSource();A.buffer=a._scratchBuffer,A.connect(a.ctx.destination),typeof A.start>"u"?A.noteOn(0):A.start(0),typeof a.ctx.resume=="function"&&a.ctx.resume(),A.onended=function(){A.disconnect(0),a._audioUnlocked=!0,document.removeEventListener("touchstart",l,!0),document.removeEventListener("touchend",l,!0),document.removeEventListener("click",l,!0),document.removeEventListener("keydown",l,!0);for(var I=0;I<a._howls.length;I++)a._howls[I]._emit("unlock")}};return document.addEventListener("touchstart",l,!0),document.addEventListener("touchend",l,!0),document.addEventListener("click",l,!0),document.addEventListener("keydown",l,!0),a}},_obtainHtml5Audio:function(){var a=this||t;if(a._html5AudioPool.length)return a._html5AudioPool.pop();var l=new Audio().play();return l&&typeof Promise<"u"&&(l instanceof Promise||typeof l.then=="function")&&l.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(a){var l=this||t;return a._unlocked&&l._html5AudioPool.push(a),l},_autoSuspend:function(){var a=this;if(!(!a.autoSuspend||!a.ctx||typeof a.ctx.suspend>"u"||!t.usingWebAudio)){for(var l=0;l<a._howls.length;l++)if(a._howls[l]._webAudio){for(var h=0;h<a._howls[l]._sounds.length;h++)if(!a._howls[l]._sounds[h]._paused)return a}return a._suspendTimer&&clearTimeout(a._suspendTimer),a._suspendTimer=setTimeout(function(){if(a.autoSuspend){a._suspendTimer=null,a.state="suspending";var m=function(){a.state="suspended",a._resumeAfterSuspend&&(delete a._resumeAfterSuspend,a._autoResume())};a.ctx.suspend().then(m,m)}},3e4),a}},_autoResume:function(){var a=this;if(!(!a.ctx||typeof a.ctx.resume>"u"||!t.usingWebAudio))return a.state==="running"&&a.ctx.state!=="interrupted"&&a._suspendTimer?(clearTimeout(a._suspendTimer),a._suspendTimer=null):a.state==="suspended"||a.state==="running"&&a.ctx.state==="interrupted"?(a.ctx.resume().then(function(){a.state="running";for(var l=0;l<a._howls.length;l++)a._howls[l]._emit("resume")}),a._suspendTimer&&(clearTimeout(a._suspendTimer),a._suspendTimer=null)):a.state==="suspending"&&(a._resumeAfterSuspend=!0),a}};var t=new e,i=function(a){var l=this;if(!a.src||a.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}l.init(a)};i.prototype={init:function(a){var l=this;return t.ctx||p(),l._autoplay=a.autoplay||!1,l._format=typeof a.format!="string"?a.format:[a.format],l._html5=a.html5||!1,l._muted=a.mute||!1,l._loop=a.loop||!1,l._pool=a.pool||5,l._preload=typeof a.preload=="boolean"||a.preload==="metadata"?a.preload:!0,l._rate=a.rate||1,l._sprite=a.sprite||{},l._src=typeof a.src!="string"?a.src:[a.src],l._volume=a.volume!==void 0?a.volume:1,l._xhr={method:a.xhr&&a.xhr.method?a.xhr.method:"GET",headers:a.xhr&&a.xhr.headers?a.xhr.headers:null,withCredentials:a.xhr&&a.xhr.withCredentials?a.xhr.withCredentials:!1},l._duration=0,l._state="unloaded",l._sounds=[],l._endTimers={},l._queue=[],l._playLock=!1,l._onend=a.onend?[{fn:a.onend}]:[],l._onfade=a.onfade?[{fn:a.onfade}]:[],l._onload=a.onload?[{fn:a.onload}]:[],l._onloaderror=a.onloaderror?[{fn:a.onloaderror}]:[],l._onplayerror=a.onplayerror?[{fn:a.onplayerror}]:[],l._onpause=a.onpause?[{fn:a.onpause}]:[],l._onplay=a.onplay?[{fn:a.onplay}]:[],l._onstop=a.onstop?[{fn:a.onstop}]:[],l._onmute=a.onmute?[{fn:a.onmute}]:[],l._onvolume=a.onvolume?[{fn:a.onvolume}]:[],l._onrate=a.onrate?[{fn:a.onrate}]:[],l._onseek=a.onseek?[{fn:a.onseek}]:[],l._onunlock=a.onunlock?[{fn:a.onunlock}]:[],l._onresume=[],l._webAudio=t.usingWebAudio&&!l._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(l),l._autoplay&&l._queue.push({event:"play",action:function(){l.play()}}),l._preload&&l._preload!=="none"&&l.load(),l},load:function(){var a=this,l=null;if(t.noAudio){a._emit("loaderror",null,"No audio support.");return}typeof a._src=="string"&&(a._src=[a._src]);for(var h=0;h<a._src.length;h++){var m,S;if(a._format&&a._format[h])m=a._format[h];else{if(S=a._src[h],typeof S!="string"){a._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}m=/^data:audio\/([^;,]+);/i.exec(S),m||(m=/\.([^.]+)$/.exec(S.split("?",1)[0])),m&&(m=m[1].toLowerCase())}if(m||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),m&&t.codecs(m)){l=a._src[h];break}}if(!l){a._emit("loaderror",null,"No codec support for selected audio sources.");return}return a._src=l,a._state="loading",window.location.protocol==="https:"&&l.slice(0,5)==="http:"&&(a._html5=!0,a._webAudio=!1),new s(a),a._webAudio&&o(a),a},play:function(a,l){var h=this,m=null;if(typeof a=="number")m=a,a=null;else{if(typeof a=="string"&&h._state==="loaded"&&!h._sprite[a])return null;if(typeof a>"u"&&(a="__default",!h._playLock)){for(var S=0,E=0;E<h._sounds.length;E++)h._sounds[E]._paused&&!h._sounds[E]._ended&&(S++,m=h._sounds[E]._id);S===1?a=null:m=null}}var f=m?h._soundById(m):h._inactiveSound();if(!f)return null;if(m&&!a&&(a=f._sprite||"__default"),h._state!=="loaded"){f._sprite=a,f._ended=!1;var T=f._id;return h._queue.push({event:"play",action:function(){h.play(T)}}),T}if(m&&!f._paused)return l||h._loadQueue("play"),f._id;h._webAudio&&t._autoResume();var A=Math.max(0,f._seek>0?f._seek:h._sprite[a][0]/1e3),I=Math.max(0,(h._sprite[a][0]+h._sprite[a][1])/1e3-A),D=I*1e3/Math.abs(f._rate),O=h._sprite[a][0]/1e3,C=(h._sprite[a][0]+h._sprite[a][1])/1e3;f._sprite=a,f._ended=!1;var U=function(){f._paused=!1,f._seek=A,f._start=O,f._stop=C,f._loop=!!(f._loop||h._sprite[a][2])};if(A>=C){h._ended(f);return}var v=f._node;if(h._webAudio){var R=function(){h._playLock=!1,U(),h._refreshBuffer(f);var J=f._muted||h._muted?0:f._volume;v.gain.setValueAtTime(J,t.ctx.currentTime),f._playStart=t.ctx.currentTime,typeof v.bufferSource.start>"u"?f._loop?v.bufferSource.noteGrainOn(0,A,86400):v.bufferSource.noteGrainOn(0,A,I):f._loop?v.bufferSource.start(0,A,86400):v.bufferSource.start(0,A,I),D!==1/0&&(h._endTimers[f._id]=setTimeout(h._ended.bind(h,f),D)),l||setTimeout(function(){h._emit("play",f._id),h._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?R():(h._playLock=!0,h.once("resume",R),h._clearTimer(f._id))}else{var P=function(){v.currentTime=A,v.muted=f._muted||h._muted||t._muted||v.muted,v.volume=f._volume*t.volume(),v.playbackRate=f._rate;try{var J=v.play();if(J&&typeof Promise<"u"&&(J instanceof Promise||typeof J.then=="function")?(h._playLock=!0,U(),J.then(function(){h._playLock=!1,v._unlocked=!0,l?h._loadQueue():h._emit("play",f._id)}).catch(function(){h._playLock=!1,h._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),f._ended=!0,f._paused=!0})):l||(h._playLock=!1,U(),h._emit("play",f._id)),v.playbackRate=f._rate,v.paused){h._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}a!=="__default"||f._loop?h._endTimers[f._id]=setTimeout(h._ended.bind(h,f),D):(h._endTimers[f._id]=function(){h._ended(f),v.removeEventListener("ended",h._endTimers[f._id],!1)},v.addEventListener("ended",h._endTimers[f._id],!1))}catch($){h._emit("playerror",f._id,$)}};v.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(v.src=h._src,v.load());var V=window&&window.ejecta||!v.readyState&&t._navigator.isCocoonJS;if(v.readyState>=3||V)P();else{h._playLock=!0,h._state="loading";var Z=function(){h._state="loaded",P(),v.removeEventListener(t._canPlayEvent,Z,!1)};v.addEventListener(t._canPlayEvent,Z,!1),h._clearTimer(f._id)}}return f._id},pause:function(a){var l=this;if(l._state!=="loaded"||l._playLock)return l._queue.push({event:"pause",action:function(){l.pause(a)}}),l;for(var h=l._getSoundIds(a),m=0;m<h.length;m++){l._clearTimer(h[m]);var S=l._soundById(h[m]);if(S&&!S._paused&&(S._seek=l.seek(h[m]),S._rateSeek=0,S._paused=!0,l._stopFade(h[m]),S._node))if(l._webAudio){if(!S._node.bufferSource)continue;typeof S._node.bufferSource.stop>"u"?S._node.bufferSource.noteOff(0):S._node.bufferSource.stop(0),l._cleanBuffer(S._node)}else(!isNaN(S._node.duration)||S._node.duration===1/0)&&S._node.pause();arguments[1]||l._emit("pause",S?S._id:null)}return l},stop:function(a,l){var h=this;if(h._state!=="loaded"||h._playLock)return h._queue.push({event:"stop",action:function(){h.stop(a)}}),h;for(var m=h._getSoundIds(a),S=0;S<m.length;S++){h._clearTimer(m[S]);var E=h._soundById(m[S]);E&&(E._seek=E._start||0,E._rateSeek=0,E._paused=!0,E._ended=!0,h._stopFade(m[S]),E._node&&(h._webAudio?E._node.bufferSource&&(typeof E._node.bufferSource.stop>"u"?E._node.bufferSource.noteOff(0):E._node.bufferSource.stop(0),h._cleanBuffer(E._node)):(!isNaN(E._node.duration)||E._node.duration===1/0)&&(E._node.currentTime=E._start||0,E._node.pause(),E._node.duration===1/0&&h._clearSound(E._node))),l||h._emit("stop",E._id))}return h},mute:function(a,l){var h=this;if(h._state!=="loaded"||h._playLock)return h._queue.push({event:"mute",action:function(){h.mute(a,l)}}),h;if(typeof l>"u")if(typeof a=="boolean")h._muted=a;else return h._muted;for(var m=h._getSoundIds(l),S=0;S<m.length;S++){var E=h._soundById(m[S]);E&&(E._muted=a,E._interval&&h._stopFade(E._id),h._webAudio&&E._node?E._node.gain.setValueAtTime(a?0:E._volume,t.ctx.currentTime):E._node&&(E._node.muted=t._muted?!0:a),h._emit("mute",E._id))}return h},volume:function(){var a=this,l=arguments,h,m;if(l.length===0)return a._volume;if(l.length===1||l.length===2&&typeof l[1]>"u"){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):h=parseFloat(l[0])}else l.length>=2&&(h=parseFloat(l[0]),m=parseInt(l[1],10));var f;if(typeof h<"u"&&h>=0&&h<=1){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"volume",action:function(){a.volume.apply(a,l)}}),a;typeof m>"u"&&(a._volume=h),m=a._getSoundIds(m);for(var T=0;T<m.length;T++)f=a._soundById(m[T]),f&&(f._volume=h,l[2]||a._stopFade(m[T]),a._webAudio&&f._node&&!f._muted?f._node.gain.setValueAtTime(h,t.ctx.currentTime):f._node&&!f._muted&&(f._node.volume=h*t.volume()),a._emit("volume",f._id))}else return f=m?a._soundById(m):a._sounds[0],f?f._volume:0;return a},fade:function(a,l,h,m){var S=this;if(S._state!=="loaded"||S._playLock)return S._queue.push({event:"fade",action:function(){S.fade(a,l,h,m)}}),S;a=Math.min(Math.max(0,parseFloat(a)),1),l=Math.min(Math.max(0,parseFloat(l)),1),h=parseFloat(h),S.volume(a,m);for(var E=S._getSoundIds(m),f=0;f<E.length;f++){var T=S._soundById(E[f]);if(T){if(m||S._stopFade(E[f]),S._webAudio&&!T._muted){var A=t.ctx.currentTime,I=A+h/1e3;T._volume=a,T._node.gain.setValueAtTime(a,A),T._node.gain.linearRampToValueAtTime(l,I)}S._startFadeInterval(T,a,l,h,E[f],typeof m>"u")}}return S},_startFadeInterval:function(a,l,h,m,S,E){var f=this,T=l,A=h-l,I=Math.abs(A/.01),D=Math.max(4,I>0?m/I:m),O=Date.now();a._fadeTo=h,a._interval=setInterval(function(){var C=(Date.now()-O)/m;O=Date.now(),T+=A*C,T=Math.round(T*100)/100,A<0?T=Math.max(h,T):T=Math.min(h,T),f._webAudio?a._volume=T:f.volume(T,a._id,!0),E&&(f._volume=T),(h<l&&T<=h||h>l&&T>=h)&&(clearInterval(a._interval),a._interval=null,a._fadeTo=null,f.volume(h,a._id),f._emit("fade",a._id))},D)},_stopFade:function(a){var l=this,h=l._soundById(a);return h&&h._interval&&(l._webAudio&&h._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(h._interval),h._interval=null,l.volume(h._fadeTo,a),h._fadeTo=null,l._emit("fade",a)),l},loop:function(){var a=this,l=arguments,h,m,S;if(l.length===0)return a._loop;if(l.length===1)if(typeof l[0]=="boolean")h=l[0],a._loop=h;else return S=a._soundById(parseInt(l[0],10)),S?S._loop:!1;else l.length===2&&(h=l[0],m=parseInt(l[1],10));for(var E=a._getSoundIds(m),f=0;f<E.length;f++)S=a._soundById(E[f]),S&&(S._loop=h,a._webAudio&&S._node&&S._node.bufferSource&&(S._node.bufferSource.loop=h,h&&(S._node.bufferSource.loopStart=S._start||0,S._node.bufferSource.loopEnd=S._stop,a.playing(E[f])&&(a.pause(E[f],!0),a.play(E[f],!0)))));return a},rate:function(){var a=this,l=arguments,h,m;if(l.length===0)m=a._sounds[0]._id;else if(l.length===1){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):h=parseFloat(l[0])}else l.length===2&&(h=parseFloat(l[0]),m=parseInt(l[1],10));var f;if(typeof h=="number"){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"rate",action:function(){a.rate.apply(a,l)}}),a;typeof m>"u"&&(a._rate=h),m=a._getSoundIds(m);for(var T=0;T<m.length;T++)if(f=a._soundById(m[T]),f){a.playing(m[T])&&(f._rateSeek=a.seek(m[T]),f._playStart=a._webAudio?t.ctx.currentTime:f._playStart),f._rate=h,a._webAudio&&f._node&&f._node.bufferSource?f._node.bufferSource.playbackRate.setValueAtTime(h,t.ctx.currentTime):f._node&&(f._node.playbackRate=h);var A=a.seek(m[T]),I=(a._sprite[f._sprite][0]+a._sprite[f._sprite][1])/1e3-A,D=I*1e3/Math.abs(f._rate);(a._endTimers[m[T]]||!f._paused)&&(a._clearTimer(m[T]),a._endTimers[m[T]]=setTimeout(a._ended.bind(a,f),D)),a._emit("rate",f._id)}}else return f=a._soundById(m),f?f._rate:a._rate;return a},seek:function(){var a=this,l=arguments,h,m;if(l.length===0)a._sounds.length&&(m=a._sounds[0]._id);else if(l.length===1){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):a._sounds.length&&(m=a._sounds[0]._id,h=parseFloat(l[0]))}else l.length===2&&(h=parseFloat(l[0]),m=parseInt(l[1],10));if(typeof m>"u")return 0;if(typeof h=="number"&&(a._state!=="loaded"||a._playLock))return a._queue.push({event:"seek",action:function(){a.seek.apply(a,l)}}),a;var f=a._soundById(m);if(f)if(typeof h=="number"&&h>=0){var T=a.playing(m);T&&a.pause(m,!0),f._seek=h,f._ended=!1,a._clearTimer(m),!a._webAudio&&f._node&&!isNaN(f._node.duration)&&(f._node.currentTime=h);var A=function(){T&&a.play(m,!0),a._emit("seek",m)};if(T&&!a._webAudio){var I=function(){a._playLock?setTimeout(I,0):A()};setTimeout(I,0)}else A()}else if(a._webAudio){var D=a.playing(m)?t.ctx.currentTime-f._playStart:0,O=f._rateSeek?f._rateSeek-f._seek:0;return f._seek+(O+D*Math.abs(f._rate))}else return f._node.currentTime;return a},playing:function(a){var l=this;if(typeof a=="number"){var h=l._soundById(a);return h?!h._paused:!1}for(var m=0;m<l._sounds.length;m++)if(!l._sounds[m]._paused)return!0;return!1},duration:function(a){var l=this,h=l._duration,m=l._soundById(a);return m&&(h=l._sprite[m._sprite][1]/1e3),h},state:function(){return this._state},unload:function(){for(var a=this,l=a._sounds,h=0;h<l.length;h++)l[h]._paused||a.stop(l[h]._id),a._webAudio||(a._clearSound(l[h]._node),l[h]._node.removeEventListener("error",l[h]._errorFn,!1),l[h]._node.removeEventListener(t._canPlayEvent,l[h]._loadFn,!1),l[h]._node.removeEventListener("ended",l[h]._endFn,!1),t._releaseHtml5Audio(l[h]._node)),delete l[h]._node,a._clearTimer(l[h]._id);var m=t._howls.indexOf(a);m>=0&&t._howls.splice(m,1);var S=!0;for(h=0;h<t._howls.length;h++)if(t._howls[h]._src===a._src||a._src.indexOf(t._howls[h]._src)>=0){S=!1;break}return r&&S&&delete r[a._src],t.noAudio=!1,a._state="unloaded",a._sounds=[],a=null,null},on:function(a,l,h,m){var S=this,E=S["_on"+a];return typeof l=="function"&&E.push(m?{id:h,fn:l,once:m}:{id:h,fn:l}),S},off:function(a,l,h){var m=this,S=m["_on"+a],E=0;if(typeof l=="number"&&(h=l,l=null),l||h)for(E=0;E<S.length;E++){var f=h===S[E].id;if(l===S[E].fn&&f||!l&&f){S.splice(E,1);break}}else if(a)m["_on"+a]=[];else{var T=Object.keys(m);for(E=0;E<T.length;E++)T[E].indexOf("_on")===0&&Array.isArray(m[T[E]])&&(m[T[E]]=[])}return m},once:function(a,l,h){var m=this;return m.on(a,l,h,1),m},_emit:function(a,l,h){for(var m=this,S=m["_on"+a],E=S.length-1;E>=0;E--)(!S[E].id||S[E].id===l||a==="load")&&(setTimeout((function(f){f.call(this,l,h)}).bind(m,S[E].fn),0),S[E].once&&m.off(a,S[E].fn,S[E].id));return m._loadQueue(a),m},_loadQueue:function(a){var l=this;if(l._queue.length>0){var h=l._queue[0];h.event===a&&(l._queue.shift(),l._loadQueue()),a||h.action()}return l},_ended:function(a){var l=this,h=a._sprite;if(!l._webAudio&&a._node&&!a._node.paused&&!a._node.ended&&a._node.currentTime<a._stop)return setTimeout(l._ended.bind(l,a),100),l;var m=!!(a._loop||l._sprite[h][2]);if(l._emit("end",a._id),!l._webAudio&&m&&l.stop(a._id,!0).play(a._id),l._webAudio&&m){l._emit("play",a._id),a._seek=a._start||0,a._rateSeek=0,a._playStart=t.ctx.currentTime;var S=(a._stop-a._start)*1e3/Math.abs(a._rate);l._endTimers[a._id]=setTimeout(l._ended.bind(l,a),S)}return l._webAudio&&!m&&(a._paused=!0,a._ended=!0,a._seek=a._start||0,a._rateSeek=0,l._clearTimer(a._id),l._cleanBuffer(a._node),t._autoSuspend()),!l._webAudio&&!m&&l.stop(a._id,!0),l},_clearTimer:function(a){var l=this;if(l._endTimers[a]){if(typeof l._endTimers[a]!="function")clearTimeout(l._endTimers[a]);else{var h=l._soundById(a);h&&h._node&&h._node.removeEventListener("ended",l._endTimers[a],!1)}delete l._endTimers[a]}return l},_soundById:function(a){for(var l=this,h=0;h<l._sounds.length;h++)if(a===l._sounds[h]._id)return l._sounds[h];return null},_inactiveSound:function(){var a=this;a._drain();for(var l=0;l<a._sounds.length;l++)if(a._sounds[l]._ended)return a._sounds[l].reset();return new s(a)},_drain:function(){var a=this,l=a._pool,h=0,m=0;if(!(a._sounds.length<l)){for(m=0;m<a._sounds.length;m++)a._sounds[m]._ended&&h++;for(m=a._sounds.length-1;m>=0;m--){if(h<=l)return;a._sounds[m]._ended&&(a._webAudio&&a._sounds[m]._node&&a._sounds[m]._node.disconnect(0),a._sounds.splice(m,1),h--)}}},_getSoundIds:function(a){var l=this;if(typeof a>"u"){for(var h=[],m=0;m<l._sounds.length;m++)h.push(l._sounds[m]._id);return h}else return[a]},_refreshBuffer:function(a){var l=this;return a._node.bufferSource=t.ctx.createBufferSource(),a._node.bufferSource.buffer=r[l._src],a._panner?a._node.bufferSource.connect(a._panner):a._node.bufferSource.connect(a._node),a._node.bufferSource.loop=a._loop,a._loop&&(a._node.bufferSource.loopStart=a._start||0,a._node.bufferSource.loopEnd=a._stop||0),a._node.bufferSource.playbackRate.setValueAtTime(a._rate,t.ctx.currentTime),l},_cleanBuffer:function(a){var l=this,h=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!a.bufferSource)return l;if(t._scratchBuffer&&a.bufferSource&&(a.bufferSource.onended=null,a.bufferSource.disconnect(0),h))try{a.bufferSource.buffer=t._scratchBuffer}catch{}return a.bufferSource=null,l},_clearSound:function(a){var l=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);l||(a.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var s=function(a){this._parent=a,this.init()};s.prototype={init:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,l._sounds.push(a),a.create(),a},create:function(){var a=this,l=a._parent,h=t._muted||a._muted||a._parent._muted?0:a._volume;return l._webAudio?(a._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),a._node.gain.setValueAtTime(h,t.ctx.currentTime),a._node.paused=!0,a._node.connect(t.masterGain)):t.noAudio||(a._node=t._obtainHtml5Audio(),a._errorFn=a._errorListener.bind(a),a._node.addEventListener("error",a._errorFn,!1),a._loadFn=a._loadListener.bind(a),a._node.addEventListener(t._canPlayEvent,a._loadFn,!1),a._endFn=a._endListener.bind(a),a._node.addEventListener("ended",a._endFn,!1),a._node.src=l._src,a._node.preload=l._preload===!0?"auto":l._preload,a._node.volume=h*t.volume(),a._node.load()),a},reset:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._rateSeek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,a},_errorListener:function(){var a=this;a._parent._emit("loaderror",a._id,a._node.error?a._node.error.code:0),a._node.removeEventListener("error",a._errorFn,!1)},_loadListener:function(){var a=this,l=a._parent;l._duration=Math.ceil(a._node.duration*10)/10,Object.keys(l._sprite).length===0&&(l._sprite={__default:[0,l._duration*1e3]}),l._state!=="loaded"&&(l._state="loaded",l._emit("load"),l._loadQueue()),a._node.removeEventListener(t._canPlayEvent,a._loadFn,!1)},_endListener:function(){var a=this,l=a._parent;l._duration===1/0&&(l._duration=Math.ceil(a._node.duration*10)/10,l._sprite.__default[1]===1/0&&(l._sprite.__default[1]=l._duration*1e3),l._ended(a)),a._node.removeEventListener("ended",a._endFn,!1)}};var r={},o=function(a){var l=a._src;if(r[l]){a._duration=r[l].duration,u(a);return}if(/^data:[^;]+;base64,/.test(l)){for(var h=atob(l.split(",")[1]),m=new Uint8Array(h.length),S=0;S<h.length;++S)m[S]=h.charCodeAt(S);d(m.buffer,a)}else{var E=new XMLHttpRequest;E.open(a._xhr.method,l,!0),E.withCredentials=a._xhr.withCredentials,E.responseType="arraybuffer",a._xhr.headers&&Object.keys(a._xhr.headers).forEach(function(f){E.setRequestHeader(f,a._xhr.headers[f])}),E.onload=function(){var f=(E.status+"")[0];if(f!=="0"&&f!=="2"&&f!=="3"){a._emit("loaderror",null,"Failed loading audio file with status: "+E.status+".");return}d(E.response,a)},E.onerror=function(){a._webAudio&&(a._html5=!0,a._webAudio=!1,a._sounds=[],delete r[l],a.load())},c(E)}},c=function(a){try{a.send()}catch{a.onerror()}},d=function(a,l){var h=function(){l._emit("loaderror",null,"Decoding audio data failed.")},m=function(S){S&&l._sounds.length>0?(r[l._src]=S,u(l,S)):h()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(a).then(m).catch(h):t.ctx.decodeAudioData(a,m,h)},u=function(a,l){l&&!a._duration&&(a._duration=l.duration),Object.keys(a._sprite).length===0&&(a._sprite={__default:[0,a._duration*1e3]}),a._state!=="loaded"&&(a._state="loaded",a._emit("load"),a._loadQueue())},p=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var a=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),l=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),h=l?parseInt(l[1],10):null;if(a&&h&&h<9){var m=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!m&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};n.Howler=t,n.Howl=i,typeof cs<"u"?(cs.HowlerGlobal=e,cs.Howler=t,cs.Howl=i,cs.Sound=s):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=i,window.Sound=s)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var i=this;if(!i.ctx||!i.ctx.listener)return i;for(var s=i._howls.length-1;s>=0;s--)i._howls[s].stereo(t);return i},HowlerGlobal.prototype.pos=function(t,i,s){var r=this;if(!r.ctx||!r.ctx.listener)return r;if(i=typeof i!="number"?r._pos[1]:i,s=typeof s!="number"?r._pos[2]:s,typeof t=="number")r._pos=[t,i,s],typeof r.ctx.listener.positionX<"u"?(r.ctx.listener.positionX.setTargetAtTime(r._pos[0],Howler.ctx.currentTime,.1),r.ctx.listener.positionY.setTargetAtTime(r._pos[1],Howler.ctx.currentTime,.1),r.ctx.listener.positionZ.setTargetAtTime(r._pos[2],Howler.ctx.currentTime,.1)):r.ctx.listener.setPosition(r._pos[0],r._pos[1],r._pos[2]);else return r._pos;return r},HowlerGlobal.prototype.orientation=function(t,i,s,r,o,c){var d=this;if(!d.ctx||!d.ctx.listener)return d;var u=d._orientation;if(i=typeof i!="number"?u[1]:i,s=typeof s!="number"?u[2]:s,r=typeof r!="number"?u[3]:r,o=typeof o!="number"?u[4]:o,c=typeof c!="number"?u[5]:c,typeof t=="number")d._orientation=[t,i,s,r,o,c],typeof d.ctx.listener.forwardX<"u"?(d.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),d.ctx.listener.forwardY.setTargetAtTime(i,Howler.ctx.currentTime,.1),d.ctx.listener.forwardZ.setTargetAtTime(s,Howler.ctx.currentTime,.1),d.ctx.listener.upX.setTargetAtTime(r,Howler.ctx.currentTime,.1),d.ctx.listener.upY.setTargetAtTime(o,Howler.ctx.currentTime,.1),d.ctx.listener.upZ.setTargetAtTime(c,Howler.ctx.currentTime,.1)):d.ctx.listener.setOrientation(t,i,s,r,o,c);else return u;return d},Howl.prototype.init=(function(t){return function(i){var s=this;return s._orientation=i.orientation||[1,0,0],s._stereo=i.stereo||null,s._pos=i.pos||null,s._pannerAttr={coneInnerAngle:typeof i.coneInnerAngle<"u"?i.coneInnerAngle:360,coneOuterAngle:typeof i.coneOuterAngle<"u"?i.coneOuterAngle:360,coneOuterGain:typeof i.coneOuterGain<"u"?i.coneOuterGain:0,distanceModel:typeof i.distanceModel<"u"?i.distanceModel:"inverse",maxDistance:typeof i.maxDistance<"u"?i.maxDistance:1e4,panningModel:typeof i.panningModel<"u"?i.panningModel:"HRTF",refDistance:typeof i.refDistance<"u"?i.refDistance:1,rolloffFactor:typeof i.rolloffFactor<"u"?i.rolloffFactor:1},s._onstereo=i.onstereo?[{fn:i.onstereo}]:[],s._onpos=i.onpos?[{fn:i.onpos}]:[],s._onorientation=i.onorientation?[{fn:i.onorientation}]:[],t.call(this,i)}})(Howl.prototype.init),Howl.prototype.stereo=function(t,i){var s=this;if(!s._webAudio)return s;if(s._state!=="loaded")return s._queue.push({event:"stereo",action:function(){s.stereo(t,i)}}),s;var r=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof i>"u")if(typeof t=="number")s._stereo=t,s._pos=[t,0,0];else return s._stereo;for(var o=s._getSoundIds(i),c=0;c<o.length;c++){var d=s._soundById(o[c]);if(d)if(typeof t=="number")d._stereo=t,d._pos=[t,0,0],d._node&&(d._pannerAttr.panningModel="equalpower",(!d._panner||!d._panner.pan)&&e(d,r),r==="spatial"?typeof d._panner.positionX<"u"?(d._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),d._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),d._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):d._panner.setPosition(t,0,0):d._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),s._emit("stereo",d._id);else return d._stereo}return s},Howl.prototype.pos=function(t,i,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"pos",action:function(){o.pos(t,i,s,r)}}),o;if(i=typeof i!="number"?0:i,s=typeof s!="number"?-.5:s,typeof r>"u")if(typeof t=="number")o._pos=[t,i,s];else return o._pos;for(var c=o._getSoundIds(r),d=0;d<c.length;d++){var u=o._soundById(c[d]);if(u)if(typeof t=="number")u._pos=[t,i,s],u._node&&((!u._panner||u._panner.pan)&&e(u,"spatial"),typeof u._panner.positionX<"u"?(u._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.positionY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.positionZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setPosition(t,i,s)),o._emit("pos",u._id);else return u._pos}return o},Howl.prototype.orientation=function(t,i,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"orientation",action:function(){o.orientation(t,i,s,r)}}),o;if(i=typeof i!="number"?o._orientation[1]:i,s=typeof s!="number"?o._orientation[2]:s,typeof r>"u")if(typeof t=="number")o._orientation=[t,i,s];else return o._orientation;for(var c=o._getSoundIds(r),d=0;d<c.length;d++){var u=o._soundById(c[d]);if(u)if(typeof t=="number")u._orientation=[t,i,s],u._node&&(u._panner||(u._pos||(u._pos=o._pos||[0,0,-.5]),e(u,"spatial")),typeof u._panner.orientationX<"u"?(u._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.orientationY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.orientationZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setOrientation(t,i,s)),o._emit("orientation",u._id);else return u._orientation}return o},Howl.prototype.pannerAttr=function(){var t=this,i=arguments,s,r,o;if(!t._webAudio)return t;if(i.length===0)return t._pannerAttr;if(i.length===1)if(typeof i[0]=="object")s=i[0],typeof r>"u"&&(s.pannerAttr||(s.pannerAttr={coneInnerAngle:s.coneInnerAngle,coneOuterAngle:s.coneOuterAngle,coneOuterGain:s.coneOuterGain,distanceModel:s.distanceModel,maxDistance:s.maxDistance,refDistance:s.refDistance,rolloffFactor:s.rolloffFactor,panningModel:s.panningModel}),t._pannerAttr={coneInnerAngle:typeof s.pannerAttr.coneInnerAngle<"u"?s.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof s.pannerAttr.coneOuterAngle<"u"?s.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof s.pannerAttr.coneOuterGain<"u"?s.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof s.pannerAttr.distanceModel<"u"?s.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof s.pannerAttr.maxDistance<"u"?s.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof s.pannerAttr.refDistance<"u"?s.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof s.pannerAttr.rolloffFactor<"u"?s.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof s.pannerAttr.panningModel<"u"?s.pannerAttr.panningModel:t._panningModel});else return o=t._soundById(parseInt(i[0],10)),o?o._pannerAttr:t._pannerAttr;else i.length===2&&(s=i[0],r=parseInt(i[1],10));for(var c=t._getSoundIds(r),d=0;d<c.length;d++)if(o=t._soundById(c[d]),o){var u=o._pannerAttr;u={coneInnerAngle:typeof s.coneInnerAngle<"u"?s.coneInnerAngle:u.coneInnerAngle,coneOuterAngle:typeof s.coneOuterAngle<"u"?s.coneOuterAngle:u.coneOuterAngle,coneOuterGain:typeof s.coneOuterGain<"u"?s.coneOuterGain:u.coneOuterGain,distanceModel:typeof s.distanceModel<"u"?s.distanceModel:u.distanceModel,maxDistance:typeof s.maxDistance<"u"?s.maxDistance:u.maxDistance,refDistance:typeof s.refDistance<"u"?s.refDistance:u.refDistance,rolloffFactor:typeof s.rolloffFactor<"u"?s.rolloffFactor:u.rolloffFactor,panningModel:typeof s.panningModel<"u"?s.panningModel:u.panningModel};var p=o._panner;p||(o._pos||(o._pos=t._pos||[0,0,-.5]),e(o,"spatial"),p=o._panner),p.coneInnerAngle=u.coneInnerAngle,p.coneOuterAngle=u.coneOuterAngle,p.coneOuterGain=u.coneOuterGain,p.distanceModel=u.distanceModel,p.maxDistance=u.maxDistance,p.refDistance=u.refDistance,p.rolloffFactor=u.rolloffFactor,p.panningModel=u.panningModel}return t},Sound.prototype.init=(function(t){return function(){var i=this,s=i._parent;i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,t.call(this),i._stereo?s.stereo(i._stereo):i._pos&&s.pos(i._pos[0],i._pos[1],i._pos[2],i._id)}})(Sound.prototype.init),Sound.prototype.reset=(function(t){return function(){var i=this,s=i._parent;return i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,i._stereo?s.stereo(i._stereo):i._pos?s.pos(i._pos[0],i._pos[1],i._pos[2],i._id):i._panner&&(i._panner.disconnect(0),i._panner=void 0,s._refreshBuffer(i)),t.call(this)}})(Sound.prototype.reset);var e=function(t,i){i=i||"spatial",i==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()})(ua)),ua}var LS=IS();function pr(n){return n[Math.floor(Math.random()*n.length)]}function qc(n,e=10){const t=1/(1+Math.exp(e*.5)),i=1/(1+Math.exp(-e*.5));return(1/(1+Math.exp(-e*(n-.5)))-t)/(i-t)}function yS(n){let e=n.length,t;for(;e>0;)t=Math.floor(Math.random()*e),e--,[n[e],n[t]]=[n[t],n[e]];return n}const OS=["click_002.ogg"],ql=["spinner","sound-effects","tile-glyph-geometries","title-image","title-base-layer","title-side-layer","title-dilate-0","title-dilate-1","title-dilate-2","title-dilate-3","title-dilate-4","title-dilate-5","title-dilate-6","title-dilate-7","title-dilate-8","title-dilate-9","title-top-layer","title-finalize"],Zl={spinner:0,"sound-effects":10,"tile-glyph-geometries":204,"title-image":6,"title-base-layer":437,"title-side-layer":408,"title-dilate-0":16,"title-dilate-1":20,"title-dilate-2":20,"title-dilate-3":18,"title-dilate-4":17,"title-dilate-5":13,"title-dilate-6":13,"title-dilate-7":12,"title-dilate-8":12,"title-dilate-9":13,"title-top-layer":427,"title-finalize":4},Zc=new Map;function Jl(){return new Promise(n=>{requestAnimationFrame(()=>n())})}function Hn(n,e){Zc.set(n,e)}async function bS(n){const e=ql.reduce((s,r)=>s+(Zl[r]??0),0);let t=0;const i=new Map;for(const s of ql){const r=Zc.get(s),o=performance.now();r&&await r();const c=performance.now()-o;i.set(s,Math.round(c)),t+=Zl[s]??c,e>0&&(n(Math.round(100*t/e)),await Jl())}n(100),await Jl()}const Ql=new Map;Hn("sound-effects",CS);async function CS(){OS.map(async n=>{Ql.set(n,new LS.Howl({src:[`sounds/${n}`],format:["ogg"]}))}),await Promise.all(Object.values(Ql).map(n=>new Promise((e,t)=>{const i=n;i.once("load",e),i.once("loaderror",()=>{t()})})))}const DS=`aback
abaft
abase
abate
abbey
abbot
abhor
abide
abler
abode
about
above
abuse
abyss
ached
aches
acids
acorn
acres
acrid
acted
actor
acute
adage
adapt
added
adder
adept
adieu
admit
adobe
adopt
adore
adorn
adult
aegis
aeons
affix
afire
afoot
after
again
agape
agate
agent
agile
aging
aglow
agony
agree
ahead
aided
aides
ailed
aimed
aired
aisle
alarm
album
alder
alert
alias
alibi
alien
alike
alive
allay
alley
allot
allow
alloy
aloes
aloft
alone
along
aloof
aloud
alpha
altar
alter
altos
amass
amaze
amber
amble
amend
amigo
amiss
amity
among
amour
ample
amply
amuse
angel
anger
angle
angry
angst
anime
ankle
annex
annoy
annul
antes
antic
anvil
apace
apart
aping
appal
apple
apply
apron
aptly
areas
arena
argue
arise
armed
aroma
arose
array
arrow
arson
ashen
ashes
aside
asked
askew
aspen
assay
asses
asset
atlas
atoll
atoms
atone
attic
audio
audit
auger
aught
augur
aunts
auras
autos
avail
avert
avoid
avows
await
awake
award
aware
awful
awoke
axiom
axles
azure
babel
babes
backs
bacon
badge
badly
baggy
baits
baize
baked
baker
bales
balls
balmy
banal
bands
bandy
bangs
banjo
banks
barbs
bards
bared
barge
barks
barns
baron
basal
based
baser
bases
basic
basil
basin
basis
baste
batch
bated
bathe
baths
baton
bayou
beach
beads
beady
beaks
beams
beans
beard
bears
beast
beaux
beech
beets
befit
began
begat
beget
begin
begot
begun
being
belie
belle
bells
belly
below
belts
bench
bends
bergs
berry
berth
beryl
beset
bevel
bible
bides
bight
bigot
bilge
bills
billy
binds
biped
birch
birds
birth
bison
bites
black
blade
blame
bland
blank
blare
blast
blaze
bleak
bleat
bleed
blend
bless
blest
blind
blink
bliss
block
blond
blood
bloom
blots
blown
blows
bluer
blues
bluff
blunt
blurt
blush
board
boars
boast
boats
boded
bodes
boggy
bogus
boils
boles
bolts
bombs
bonds
boned
bones
bonny
bonus
booby
books
booms
boons
boors
boost
booth
boots
booty
booze
borax
bored
bores
bosom
bough
bound
bouts
bowed
bowel
bower
bowls
boxed
boxer
boxes
brace
brags
braid
brain
brake
brand
brass
brats
brave
bravo
brawl
brawn
bread
break
breed
briar
bribe
brick
bride
brief
brier
brigs
brims
brine
bring
brink
briny
brisk
broad
broil
broke
brood
brook
broom
broth
brown
brows
bruin
brunt
brush
brute
bucks
budge
buggy
bugle
build
built
bulbs
bulge
bulks
bulky
bulls
bully
bumps
bunch
bunks
buoys
burly
burns
burnt
burrs
burst
bushy
busts
butte
butts
buxom
buyer
cabal
cabby
cabin
cable
cacao
cache
cadet
cadre
caged
cages
cairn
caked
cakes
calls
calms
calyx
camel
cameo
camps
canal
candy
canes
canny
canoe
canon
canto
caper
capes
capon
cards
cared
cares
cargo
carol
carry
carts
carve
cased
cases
casks
caste
casts
catch
cater
cause
caved
caves
cavil
cease
cedar
ceded
cells
cents
chafe
chaff
chain
chair
chalk
champ
chant
chaos
chaps
charm
chart
chary
chase
chasm
chats
cheap
cheat
check
cheek
cheer
chefs
chess
chest
chick
chide
chief
child
chill
chime
china
chink
chins
chips
chirp
choir
choke
chops
chord
chose
chuck
chump
chums
chunk
churn
chute
cider
cigar
cinch
circa
cited
cites
civic
civil
clack
claim
clamp
clams
clang
clank
clans
claps
clash
clasp
class
claws
clean
clear
clefs
cleft
clerk
clews
click
cliff
climb
clime
cling
clink
clips
cloak
clock
clods
clogs
close
cloth
cloud
clout
clove
clown
clubs
cluck
clues
clump
clung
coach
coals
coast
coats
cobra
cocks
cocoa
codes
coils
coins
colds
colic
colon
colts
combs
comer
comes
comet
comic
comma
conch
cones
conic
cooed
cooks
cools
copra
copse
coral
cords
cores
corks
corns
corps
costs
cotes
couch
cough
could
count
coupe
coups
court
cover
coves
covet
covey
cowed
cower
coyly
cozen
crabs
crack
craft
crags
cramp
crane
crank
crape
crash
crass
crate
crave
crawl
craze
crazy
creak
cream
credo
creed
creek
creep
crepe
crept
cress
crest
crews
cribs
crick
cried
crier
cries
crime
crimp
crisp
croak
crock
crone
crony
crook
crops
cross
croup
crowd
crown
crows
crude
cruel
crumb
crush
crust
crypt
cubes
cubic
cubit
cuffs
cults
curds
cured
cures
curls
curly
curry
curse
curve
cycle
cynic
daddy
daily
dairy
daisy
dales
dally
dames
damps
dance
dandy
dared
dares
darts
dated
dates
datum
daubs
daunt
dawns
dazed
deals
dealt
deans
dears
death
debar
debit
debts
debut
decay
decks
decoy
decry
deeds
deems
deeps
defer
deign
deity
delay
dells
delta
delve
demon
demur
dense
dents
depot
depth
derby
desks
deter
deuce
devil
diary
diced
dices
dicta
diets
digit
dikes
dimes
dimly
dined
diner
dines
dingy
dirge
dirty
disks
ditch
ditto
ditty
divan
dived
diver
dives
dizzy
docks
dodge
doers
dogma
doing
doled
dolls
domed
domes
donor
dooms
doors
dosed
doses
doted
dotes
doubt
dough
doves
downs
downy
dowry
dozed
dozen
draft
drags
drain
drake
drama
drams
drank
drape
drawl
drawn
draws
dread
dream
dregs
dress
dried
drier
dries
drift
drill
drily
drink
drips
drive
droll
drone
droop
drops
dross
drove
drown
drugs
drums
drunk
dryly
ducal
ducat
ducks
ducts
duels
duets
dukes
dully
dummy
dumps
dumpy
dunce
dunes
duped
dupes
dusky
dusty
dwarf
dwell
dwelt
dying
dykes
eager
eagle
earls
early
earns
earth
eased
easel
eases
eaten
eater
eaves
ebbed
ebony
edged
edges
edict
edify
eerie
egged
eight
eject
elate
elbow
elder
elect
elegy
elfin
elite
elope
elude
elves
email
emits
empty
enact
ended
endow
enemy
enjoy
ensue
enter
entry
envoy
epics
epoch
equal
equip
erase
erect
erred
error
essay
ether
ethic
evade
event
every
evils
evoke
exact
exalt
excel
exert
exile
exist
exits
expel
extol
extra
exult
eying
fable
faced
faces
facts
faded
fades
fails
faint
fairs
fairy
faith
falls
false
famed
fancy
fangs
farce
fared
fares
farms
fasts
fatal
fated
fates
fatty
fault
fauna
fauns
fawns
fears
feast
feats
feeds
feels
feign
feint
fells
felon
fence
feral
ferns
ferry
fetch
fetid
fetus
feuds
fever
fewer
fiefs
field
fiend
fiery
fifes
fifth
fifty
fight
filch
filed
files
filet
fills
filly
films
filmy
filth
final
finch
finds
fined
finer
fines
fired
fires
firms
first
fishy
fists
fitly
fives
fixed
fixer
fixes
fjord
flags
flail
flair
flake
flaky
flame
flank
flaps
flare
flash
flask
flats
flaws
fleas
fleck
flees
fleet
flesh
flick
flier
flies
fling
flint
flirt
flits
float
flock
floes
flood
floor
flora
floss
flour
flout
flown
flows
flues
fluff
fluid
fluke
flume
flung
flush
flute
flyer
foams
foamy
focal
focus
foggy
foils
foist
folds
folio
folks
folly
foods
fools
foray
force
fords
forge
forgo
forks
forms
forte
forth
forts
forty
forum
found
fount
fours
fowls
foxes
foyer
frail
frame
franc
frank
fraud
freak
freed
freer
frees
fresh
frets
friar
fried
frill
frisk
frock
frogs
frond
front
frost
froth
frown
froze
fruit
fudge
fuels
fugue
fully
fumed
fumes
funds
fungi
funny
furry
furze
fused
fuses
fussy
fuzzy
gable
gaily
gains
gales
galls
games
gamin
gamma
gamut
gangs
gaped
gapes
gases
gasps
gates
gaudy
gauge
gaunt
gauze
gauzy
gavel
gawky
gayer
gayly
gazed
gazer
gazes
gears
geese
genie
genre
gents
genus
germs
ghost
giant
gibes
giddy
gifts
gilds
gills
gimme
gipsy
girds
girls
girth
given
gives
glade
gland
glare
glass
glaze
gleam
glean
glens
glide
glint
gloat
globe
gloom
glory
gloss
glove
glows
glued
gnash
gnats
gnaws
gnome
goads
goals
goats
godly
going
golly
gongs
gonna
goods
goody
goose
gored
gorge
gorse
gotta
gouge
gourd
gouty
gowns
grabs
grace
grade
graft
grain
grams
grand
grant
grape
graph
grasp
grass
grate
grave
gravy
graze
great
greed
green
greet
greys
grief
grill
grime
grimy
grind
grins
gripe
grips
grist
groan
groin
groom
grope
gross
group
grove
growl
grown
grows
grubs
gruel
gruff
grunt
guano
guard
guess
guest
guide
guild
guile
guilt
guise
gulch
gulfs
gulls
gully
gummy
gusto
gusts
gusty
habit
hacks
hails
hairs
hairy
haled
halls
halts
halve
hands
handy
hangs
happy
hardy
harem
hares
harms
harps
harpy
harry
harsh
harts
haste
hasty
hatch
hated
hater
hauls
haven
havoc
hawks
hazel
heads
heady
heals
heaps
heard
hears
heart
heath
heats
heave
heavy
hedge
heeds
heels
heirs
helix
hello
helms
helps
hence
herbs
herds
heron
heros
hewed
hides
hills
hilly
hilts
hinds
hinge
hints
hired
hires
hitch
hives
hoard
hoary
hobby
hoist
holds
holes
holly
homes
honey
hoods
hoofs
hooks
hoops
hoots
hoped
hopes
horde
horns
horny
horse
hosts
hotel
hotly
hound
hours
house
hovel
hover
howls
hulks
hulls
human
humid
humps
humus
hunch
hunts
hurls
hurry
hurts
husks
husky
hussy
hydra
hyena
hymns
icily
icing
ideal
ideas
idiom
idiot
idled
idler
idols
idyll
igloo
image
imbue
impel
imply
inane
incur
index
inept
inert
infer
ingot
inlet
inner
inter
inure
irate
irked
irons
irony
isles
islet
issue
items
ivory
jacks
jaded
jails
jaunt
jeans
jeers
jelly
jerks
jerky
jests
jetty
jewel
jiffy
joins
joint
joked
joker
jokes
jolly
joust
joyed
judge
juice
juicy
jumps
junks
junta
juror
karma
keels
keeps
ketch
keyed
khaki
kicks
kills
kinda
kinds
kings
kiosk
kites
knack
knave
knead
kneel
knees
knell
knelt
knife
knits
knobs
knock
knoll
knots
known
knows
label
laced
laces
lacks
laden
ladle
lager
lairs
laity
lakes
lambs
lamed
lames
lamps
lance
lands
lanes
lanky
lapel
lapse
larch
large
largo
larks
larva
lasso
lasts
latch
later
lathe
laugh
lawns
layer
leads
leafy
leaks
leaky
leans
leaps
leapt
learn
lease
leash
least
leave
ledge
leech
leeks
legal
lemme
lemon
lends
leper
levee
level
lever
liars
libel
licks
liege
liens
lifts
light
liked
liken
liker
likes
lilac
limbo
limbs
limes
limit
lined
linen
liner
lines
lingo
links
lions
lists
lithe
lived
liver
lives
livid
llama
loads
loamy
loans
loath
lobby
lobes
local
locks
locus
lodge
lofty
logic
login
loins
longs
looks
looms
loons
loops
loose
lords
loser
loses
lotus
louse
lousy
loved
lover
loves
lowed
lower
lowly
loyal
lucid
lucky
lulls
lumps
lumpy
lunar
lunch
lunge
lungs
lurch
lured
lures
lurid
lurks
lusts
lusty
lutes
lying
lymph
lynch
lyric
maces
madam
madly
magic
maids
mails
maize
major
maker
makes
males
mamma
manes
manga
mange
mango
mangy
mania
manly
manor
maple
march
mares
marks
marry
marsh
marts
masks
mason
masts
match
mated
mates
mauve
maxim
maybe
mayor
mazes
meals
mealy
means
meant
meats
medal
media
meets
melon
melts
memes
mends
menus
mercy
meres
merge
merit
merry
mesas
metal
meted
meter
mewed
midst
miens
might
milch
miles
milky
mills
mimes
mimic
mince
minds
mined
miner
mines
minor
mints
minus
mirth
miser
mists
mites
mixed
mixes
moans
moats
mocks
model
modem
modes
moist
molar
moles
momma
money
monks
month
moods
moody
moons
moors
moose
moped
moral
mores
mossy
motes
moths
motif
motor
motto
mound
mount
mourn
mouse
mouth
moved
mover
moves
movie
mowed
mower
mucus
muddy
mules
mummy
mumps
munch
mural
murky
mused
muses
music
musky
musty
muted
mutes
myrrh
myths
nails
naive
naked
named
names
nasal
nasty
natal
natty
naval
navel
naves
nears
necks
needs
needy
neigh
nerve
nests
never
newer
newly
nicer
niche
niece
night
ninny
noble
nobly
noise
noisy
nomad
nonce
nooks
noose
north
nosed
noses
notch
noted
notes
nouns
novel
nudge
nurse
nymph
oaken
oases
oasis
oaten
oaths
obese
obeys
occur
ocean
ochre
odder
oddly
odium
offer
often
oiled
olden
older
omens
omits
onion
onset
oozed
oozes
opals
opens
opera
opine
opium
optic
orbit
order
organ
other
otter
ought
ounce
outdo
outer
ovals
ovary
ovens
overt
owing
owned
owner
oxide
ozone
paces
packs
paddy
padre
pagan
pages
pails
pains
paint
pairs
paled
paler
pales
palms
palmy
palsy
panel
panes
pangs
panic
pansy
pants
papal
papas
paper
pared
parka
parks
parry
parse
parts
party
pasha
paste
pasty
patch
pates
paths
patio
pause
paved
pawed
pawns
payed
payer
peace
peach
peaks
peals
pearl
pears
pease
pecks
pedal
peeps
peers
pelts
penal
pence
penny
peons
perch
peril
pesky
pesos
pests
petal
petty
phase
phial
phone
photo
piano
picks
piece
piers
piety
pigmy
pikes
piled
piles
pills
pilot
pinch
pined
pines
pinks
pinto
pints
pious
piped
piper
pipes
pique
pitch
pithy
pivot
place
plaid
plain
plait
plane
plank
plans
plant
plate
plays
plaza
plead
pleas
plied
plies
plots
pluck
plugs
plumb
plume
plums
plush
podia
poems
poesy
poets
point
poise
poked
poker
pokes
polar
poles
polka
polls
ponds
pools
popes
poppa
poppy
porch
pored
pores
ports
posed
poser
poses
posse
posts
pouch
pound
pours
power
prank
prate
prays
press
preys
price
prick
pride
pried
pries
prime
print
prior
prism
privy
prize
probe
prone
proof
props
prose
prosy
proud
prove
prowl
prows
proxy
prude
prune
psalm
pshaw
pudgy
puffs
puffy
pulls
pulpy
pulse
pumps
punch
pupil
puppy
puree
purer
purge
purse
pussy
putty
quack
quaff
quail
quake
qualm
quart
quasi
quays
queen
queer
quell
query
quest
queue
quick
quiet
quill
quilt
quips
quire
quite
quits
quota
quote
quoth
rabbi
rabid
raced
racer
races
racks
radii
radio
rafts
raged
rages
raids
rails
rains
rainy
raise
rajah
raked
rakes
rally
ranch
range
ranks
rapid
rarer
rares
rated
rates
ratio
raved
raven
raves
rayon
razed
razor
reach
react
reads
ready
realm
reals
reams
reaps
rears
rebel
rebus
rebut
recur
reeds
reedy
reefs
reeks
reels
reeve
refer
refit
regal
reign
reins
relax
relay
relic
remit
rends
renew
rents
repay
repel
reply
reset
resin
rests
revel
rhyme
rider
rides
ridge
rifle
rifts
right
rigid
riled
rimes
rings
rinse
riots
ripen
riper
risen
riser
rises
risks
risky
rites
rival
riven
river
rivet
roads
roams
roars
roast
robed
robes
robin
rocks
rocky
rogue
roles
rolls
roman
roofs
rooks
rooms
roomy
roost
roots
roped
ropes
roses
rosin
rouge
rough
round
rouse
route
routs
roved
rover
rowdy
rowed
royal
ruder
ruins
ruled
ruler
rules
runes
rungs
rupee
rural
ruses
sable
sabre
sacks
sadly
safer
sagas
sages
sails
saint
salad
sales
sally
salon
salsa
salts
salty
salve
salvo
sands
sandy
saner
sated
satin
satyr
sauce
saucy
saved
saves
sawed
scald
scale
scalp
scaly
scans
scant
scare
scarf
scars
scene
scent
scion
scoff
scold
scoop
scope
score
scorn
scour
scout
scowl
scrap
screw
scrip
scrub
scull
seals
seams
seamy
seats
sects
seeds
seedy
seeks
seems
seers
seize
sells
sends
sense
serfs
serum
serve
seven
sever
sewed
sewer
sexes
shack
shade
shady
shaft
shake
shaky
shale
shall
shalt
shame
shams
shank
shape
share
shark
sharp
shave
shawl
sheaf
shear
sheds
sheen
sheep
sheer
sheet
sheik
shelf
shell
shied
shift
shine
shins
shiny
ships
shire
shirk
shirt
shoal
shock
shoes
shone
shook
shoon
shoot
shops
shore
shorn
short
shots
shout
shove
shown
shows
showy
shred
shrew
shrub
shrug
shuns
shuts
shyly
sided
sides
siege
sieve
sighs
sight
sigma
signs
silks
silky
sills
silly
since
sinew
singe
sings
sinks
siren
sires
sites
sixes
sixth
sixty
sized
sizes
skate
skies
skiff
skill
skims
skins
skips
skirt
skulk
skull
skunk
slabs
slack
slags
slain
slang
slant
slaps
slash
slate
slats
slave
slays
sleds
sleek
sleep
sleet
slept
slice
slick
slide
slime
slimy
sling
slink
slips
slits
slope
sloth
slugs
slump
slums
slung
slush
slyly
smack
small
smart
smash
smear
smell
smelt
smile
smirk
smite
smith
smock
smoke
smoky
smote
snack
snags
snail
snake
snaky
snaps
snare
snarl
sneak
sneer
sniff
snipe
snobs
snore
snort
snout
snows
snowy
soapy
soars
sober
socks
sofas
soggy
soils
solar
soles
solid
solos
solve
songs
sonny
sooth
sooty
sores
sorry
sorts
souls
sound
soups
south
sowed
sower
space
spade
spake
spank
spans
spare
spark
spars
spasm
spawn
speak
spear
speck
speed
spell
spelt
spend
spent
sperm
spice
spicy
spied
spies
spike
spill
spilt
spine
spins
spiny
spire
spite
spits
split
spoil
spoke
spook
spool
spoon
spoor
spore
sport
spots
spout
spray
spree
sprig
spunk
spurn
spurs
spurt
squad
squat
squaw
stabs
stack
staff
stage
stags
staid
stain
stair
stake
stale
stalk
stall
stamp
stand
stank
stare
stark
stars
start
state
stave
stays
stead
steak
steal
steam
steed
steel
steep
steer
stems
steps
stern
stews
stick
stiff
stile
still
sting
stink
stint
stirs
stock
stoic
stole
stone
stony
stood
stool
stoop
stops
store
stork
storm
story
stout
stove
strap
straw
stray
strew
strip
strut
stuck
studs
study
stuff
stump
stung
stunt
style
suave
sucks
sugar
suing
suite
suits
sulks
sulky
sully
sunny
super
surer
surge
surly
swain
swamp
swans
sward
swarm
sways
swear
sweat
sweep
sweet
swell
swept
swift
swill
swims
swine
swing
swirl
swish
swoon
swoop
sword
swore
sworn
swung
syrup
tabby
table
taboo
tacit
tacks
tails
taint
taken
takes
tales
talks
tally
talon
tamed
tamer
tanks
taper
tapes
tardy
tarry
tarts
tasks
taste
tasty
taunt
tawny
taxed
taxes
teach
teams
tears
tease
teems
teens
teeth
tells
tempo
tends
tenet
tenor
tense
tenth
tents
tepid
terms
terse
tests
testy
texts
thank
theft
their
theme
there
these
thick
thief
thigh
thine
thing
think
third
thong
thorn
those
three
threw
throb
throe
throw
thumb
thump
thyme
tiara
tibia
ticks
tidal
tides
tiers
tiger
tight
tilde
tiled
tiles
tills
tilts
timed
times
timid
tinge
tints
tipsy
tired
tires
tithe
title
toads
toast
today
toddy
toils
token
tolls
tombs
tomes
toned
tones
tongs
tonic
tools
tooth
topaz
topic
torch
torso
total
totem
touch
tough
tours
towed
towel
tower
towns
toxic
toyed
trace
track
tract
trade
trail
train
trait
tramp
trams
traps
trash
trays
tread
treat
treed
trees
trend
tress
triad
trial
tribe
trice
trick
tried
tries
trill
tripe
trips
trite
troll
troop
troth
trots
trout
truce
truck
truer
truly
trump
trunk
truss
trust
truth
tryst
tubes
tufts
tulip
tulle
tuned
tunes
tunic
turns
tusks
tutor
twain
twang
tweed
twice
twigs
twine
twins
twirl
twist
tying
typed
types
udder
ulcer
ultra
uncle
uncut
under
undid
undue
unfit
union
unite
units
unity
unsay
untie
until
upper
upset
urban
urged
urges
urine
usage
users
usher
using
usual
usurp
utter
vague
vales
valet
valid
value
valve
vanes
vapid
vases
vault
vaunt
veils
veins
veldt
venal
venom
vents
venue
verbs
verge
verse
verve
vests
vexed
vexes
vials
vicar
vices
video
views
vigil
viler
villa
vines
viola
viper
virus
visit
visor
vista
vital
vivid
vixen
vizor
vocal
vodka
vogue
voice
voile
volts
vomit
voted
voter
votes
vouch
vowed
vowel
vying
waded
wafer
wafts
waged
wager
wages
wagon
waifs
wails
waist
waits
waive
waked
waken
wakes
walks
walls
waltz
wands
waned
wanes
wants
wards
wares
warms
warns
warts
wasps
waste
watch
water
waved
waver
waves
waxed
waxen
waxes
wears
weary
weave
wedge
weeds
weedy
weeks
weeps
weigh
weird
welch
wells
wench
whack
whale
wharf
wheat
wheel
whelp
where
which
whiff
while
whims
whine
whips
whirl
whisk
white
whole
whoop
whose
wicks
widen
wider
widow
width
wield
wight
wilds
wiles
wills
wince
winch
winds
windy
wines
wings
winks
wiped
wipes
wired
wires
wiser
wisps
witch
witty
wives
woman
women
woods
woody
wooed
wooer
words
wordy
works
world
worms
worry
worse
worst
worth
would
wound
wrack
wraps
wrapt
wrath
wreak
wreck
wrest
wring
wrist
write
writs
wrong
wrote
wroth
yacht
yards
yarns
yawns
yearn
years
yeast
yells
yelps
yield
yoked
yokes
yolks
young
yours
youth
zebra
zones`,ha=["BOWEDL H RUNITYF F LFIFTY","GHOSTU Z  AROMAR N  DREAM","MOVIEA I XN D UE E LSHOOT","OILEDP E ET A LIMPELC T S","FROZEA    TOWELE    DIZZY","TAKENI E OT T IHACKSE H Y","SNAREI B SGRASSN C AS K Y","GASESI  A FLASHT  E SLIDE","STOVEW  I E  Z E  O PADRE","SLEETI V UN E NK N ESATED","TONICA   HMOUSEE   CDRINK","DENSEU I AMACESP H EYIELD","MERCYA A OZ B UE B NSWING","WOOEDR  N A  E TRAMSH  Y ","VALESI I  LONGSL G  AWOKE","DULLYR I OANNULW G KSHOES","DOLLSR   OINFERN   EKNITS","SPAREL    AHEADV    EAVES","DUPESE U OB R AT E PSEEDY","RANGEA O MY O PO K TNASTY","MUTESO I UO B LD I LSCALY","POSTSU U PLARGEL G ASTEER","SNACKI M NG A OHAZELT E L","BATCHA O AR T RGLASSE L H","DUPEDI  A C  S EDGESD  L ","CABALL A AU Y NE O KSTUDY","TEAMSR R LATONEM M DSTAGS","FABLER   AOTHERW   TNORTH","OLDEND  N I  D UNIONM  W ","AGONYS R OK B LE I KW T S","REVELI  X DIRTYG  R ESSAY","HOLLYE  A R  T OUNCES  H ","FLUKEE   LR   BAUDIOL   W","FASTSL  E INANET  O SPARK","FEIGNE   UASKEDS   GTINGE","DOZENU  N K  J ELBOWS  Y ","CROAKL  B E  A WHIFFS  T ","VIXENE   UROVEDB   GSMILE","TENSER   XO   UUSUALT   T","TILEDW  Q I  U NATALE  L ","IMBUEM   APILLSE   ELACED","CLASSL  U INERTM  G BABES","FLOCKR  O E  U EXILED  D ","BOXESU   LR   AL   TYOURS","WIGHTA E UKINGSE R KNEEDS","TWISTW S HISSUER U RLIEGE","TIREDU  X LOYALL  C EMITS","GLOATA   UVOWELE   LLITHE","DINESA  R LUNARE  S SAVED","SOGGYU  A RIFTSL  E YEAST","BLUNTL S RE I ESINKSS G S","APACEH G NE A AATTICD E T","WIDENR U OE C BS K LTASTY","PILLSO A IUNDIDR L ESTEED","JESTSU   PNEVERK   ISUING","ABODED    ENTRYP    THEIR","REARSA  O C  U ELEGYD  H ","FIRSTU E  M E  ENDOWS Y  ","BRISKR N EA E YNURSED T D","FEARSJ   EOBESER   DDOWRY","LOVERU I ICITESK A KYELLS","ULTRAN E PC E PUNTILT H Y","SAGESN  X OTTERW  R SIXTY","CURLSH  Y AFFIXP  N SURGE","SAVESH A PAZUREP L AENTER","FLOWNE R ILOGINL A NSONNY","PUPPYO U ILAPSEE P LS Y D","FIXEDR  V ALTARI  D LIKER","SCREWL  Q Y  U L  I YELPS","UNSAYL  G CURRYE  E RIMES","DENTSA O CU R ONATALT H D","GROOMU R AS G STRACTO N S","FILCHU  H LUCIDL  P YEAST","SOUTHT L  ACTORN R  DWARF","CHESTR A RE G AD E PO R S","LINGOI  A NATTYE  E NOISY","BASESU T HI A ILAGERT E K","PUDGYI R  NOUNST M  ONSET","ARGUEB U NO S TVOTERE S Y","LATCHI R  EXILEG B  EJECT","EASESB U LB C UE K MD S P","WAVESA   MX   IETHERS   K","YOKESO E MK Y OE E KDODGE","PINESR  D AMIGOY  E SHADE","OPIUMA  R S  B IDEALS  N ","JEERSA  I D  V ETHERD  T ","WAKEDI   RN   OE   OSTRIP","BAIZEE S MS L IEVENTT S S","APPLYR  A E  U AMIGOS  H ","TWANGR  O Y  O S  K TRESS","PALESE  R T  R APRONL  R ","WHEELI  N PRESSE  U DINES","AMUSED N LO I BB T OE Y W","BASISA W LR O AD R CSLEEK","SHOESH O AA Z TLIEGET D D","COLTSU I HB E AI G RCHEAP","BRIBEO M AWRAPSE G ER E L","WARNSI O  NOOKSG T  S S  ","GAUGEE    NONCEI    EXITS","PANELR  A I  S V  E YIELD","RENDS J  P E  I C  NSTRAY","BEGET N  YSTRIP R  EMYTHS","ASHEN O   HAULS P   LYRIC","ALLOT U W  R I AEONS S G ","CROWS A O VIRUS N N  Y D ","YOUNG A  R S  I E  NASKED","CHINK O A VIVID S V ETHER","FRONT O Y  A M ADEPT S H ","ALOES O  AAVERT E  IADORN","PULSE R  JABIDE A  CINGOT","CURED N  EIDEAS U  KMENDS","SAVED U X STOPS O E PSALM","RISKS D   TEENS A   PLUMB","DOUGH R A  B U DIZZY T Y ","ROBED V N  E J ANNOY S Y ","OMENS I  H N  ACOOED R  E","BRINY O O BOARD S T  T H ","WIGHT N   STRAP E   BRAWL","BOXED V L REFIT N T ASKEW","SMACK A A WINKS D E  S S ","GLOVE A  N I  JCREDO S  Y","ELVES O  EROGUE N  RASHES","SECTS A R AGAIN L C DEFER","CHEST E  R E  YGLASS S  T","WAVED L R STORK E O  R R ","OPERA L  IWAKED N  ESKIPS","PARSE R  AGENTS N  ENATAL","TEACH R  I R  LREFIT D  S","RIDGE D  PALIBI E  CDRESS","LIKED N N  G A  O C STATE","RAVEN B  E I  EADDED E  Y","BRIAR O  E L  FALIBI S  T","SHALT E O ELUDE M G ASPEN","FOLIO V  CMARSH R  RCYCLE","MINUS C R  I G FLEET Y S ","STANK H   JERKS F   OTTER","BIRDS R  HSOBER N  E Y  W","CORPS F  P F  A E  WARSON","DUCAT N G  C A PUPIL T N ","FLESH A O ADOBE E E SNORE","FOLIO P  NLIONS N  EHEART","PULPY N  EKINDA T  RRESIN","FORKS O  HAZURE E  EASPEN","POUCH D I SIEVE U I AMPLY","PRIVY E O  V T  E E ELUDE","HERON Y W  I N KNEEL G R ","ANNOY A R LIMBS V I RENTS","FLUNG E   PALMY V   LEEKS","SIGNS N I  L E WENCH T E ","FOILS V  W A  EFLAIL S  L","CLANG A  A M  POPINE S  S","CAKES G  EGROAN E  DBEETS","PIGMY M U OBESE U E DEEDS","HEAVY X A  I U STING S T ","FOLLY W  O N  KBELIE R  S","RIVEN N  O T  IFELLS R  Y","MOTES F A STORY E T  N H ","SWIMS I  NDELTA L  RADAGE","DAMPS M  AMOIST U  ITRAIN","SACKS F  M F  AKICKS X  H","AMOUR A N  S T  O I KNELT","RAILS M  O O  OCUBIT R  H","WANES W X  A A TROLL D T ","WATER M  ARELIC N  KEDGES","AGONY R   CABBY D   WENCH","TENET L  E V  P E  IASKED","DUSTY N  O I  U O  RSNAGS","RACER L X  I I OVALS E E ","CURED N  O F  WRISER T  Y","COOED V M  A P PLOTS S Y ","OBEYS R O  E U BEANS D G ","ROYAL A H  K E LEGAL N D ","AMBER A Y  R I PRANK Y G ","SPANK L  IRISEN E  D D  A","VOLTS M  A I  TSTORE S  D","COPSE A L  K U LEAST N H ","LOVES L L  D V  E E CRISP","EYING E A PARSE R T  S Y ","SLICE I  Q G  UKHAKI T  P","DIRTY D R ALIAS E M DRAPE","PAIRS E  TFORGO N  R S  K","SPILT I O  O N PUDGY S S ","VENOM A  O T  SSEATS R  Y","ALARM U A  R V MEMES S D ","LACKS X N  I O TORCH M K ","FURRY R O  G M  E A USING","BASIN B N ABOUT O R OTHER","FLIES U  EDRAPE C  DCHATS","FATTY F E UTTER E M GROSS","VOILE P I PIPES U G AMBER","DAUBS W E SAGAS R D  D S ","DETER M  ISPIED T  GCYCLE","TORCH W U INURE E S TRUER","QUIPS N   OFTEN I   STANK","SLUMS O  EAGLOW I  EANGER","WAGES T  T O  OAMOUR S  K","FLUME O O EBONY B T MYTHS","REAPS X  ASTUNG O  AFLATS","PARRY I I  L S LEAKS D Y ","MATED G   FLOSS O   AWOKE","EQUAL  S EUNION  N DBOGUS","ROPES  R TFLORA  S NBREAK","DRANKR D NI O EVERSEE E L","MEETS  N ICITED  E ELURES","LITHEY R RN A ACRIESH L E","JACKSU O HI R ICLEANE S S","LOONS  W ILINEN  E ETHROW","DRAWLI V AT E SCURDSH T O","BOWED  A IWILES  L KHUSKS","ABAFTT M RT O AI N MCAGES","DEEMSR L OELFING I GSINKS","TARTSA O IR U LR T KY S S","APPAL  O  SOLID  L  POSTS","EXULTT N OH I UI T GC S H","DEMURR A AI Y RPROBES R R","MISERA K IGRUBSI L EC K R","BEANS  B HQUOTA  U R  T K","OPERA  X UHOUND  L IPATIO","TINTSE O LR R ASATINE H T","LOFTYO A AV I RE N NSITES","DELAYE A AR C RBAKEDY S S","TRICEO N TWITCHE E ERARER","WILLS  U IBACON  I CBUDGE","SEVENO I OL P BIDEALD R Y","KEYED  O ALIKED  E DPUSSY","SHAMST L  ROPESU H  TRACK","DRAWSO L ASCOUTE F YDETER","UNITE  C X  I IPOLLS  Y T","GRIPEO M NRAPIDS E EE L D","ROOMYA P OBLEAKI R EDEANS","GLOOMI T AF T RTEENSS R H","BROILA D OTODDYC L AH Y L","AIMEDM U UEASELN T LDRYLY","BATHE  R L  E I  A TJUDGE","SIRENP E EOPALST R TS S S","ODDER  O ADOZEN  E KBONUS","PRATEH L AO T TTHOSEO S R","PAGESU O HFORGOF G RSIEVE","FEASTU D IDEMONG I TE T S","QUERY  P  DOORS  C  USHER","TREES  V ADREAD  R LDRYLY","USUAL  D E  D ACLEFS  R T","BELLEA I XG N CGEESEY S L","HARPS  A CFURZE  E NBASTE","SNEERH A OA R WDINEDY S Y","LANDS  A T  V IQUEER  L S","CRANEO U DP N IR T FASSAY","GLINTR D HI O IPALERE S D","JELLY  O  WISPS  E  JUROR","STOOP  F ADEFER  E SCURSE","ORGAN  R  HEALS  I  LINER","BOUGHA R OSAGASI E TCOSTS","FROTHL M AI E TCONICK S H","GNAWSR R EA O IS M ZPLANE","FIELDL Q EA U ISTARTH L Y","MELTS  E ONOVEL  E ITREAD","GIPSYR U EE T AENTERT Y S","PLEASR N LENJOYS O LSHYLY","MOLESE O HAGATEN M IT Y K","FEELS  X HINANE  L EWATER","REBUTE U RE L IV K TENSUE","OXIDEP N  TONEDI E  CARGO","PROUD  D UAXIOM  U PGUMMY","JACKSU U PI R ICOLONE Y S","HORSEI E AREAPSE M ES S L","MENUSA O TY N IBACONE E K","NAKED  N ESTOIC  W RHANDY","CEDEDO E RU P IC T VH H E","UPSETN U AD L BU K LE Y E","EVILS  D H  I ABROOM  M E","RIDERE I OA T ORACESS H T","DUNESW E AA W NR L EFOYER","KINDS  O TJUNTA  C MSTEEP","CRANKO S  CHINAK D  SWEET","SPERMT X EUNCLEN E TTILLS","SHIRE  N APALMS  E ECITES","IRONYN P  EXACTR L  TASTY","FIEFSI R TE R AREEDYY D S","ALIENM D AI I SSNOUTS T Y","MINUSA U AI D VD G ESTEED","BATEDO E ASTAIRO M TMUSES","SHORN  O ODOZEN  E CISSUE","URBANP O UPROUDE R GR S E","STUNG  N ADECOY  L LELEGY","CHECKH X NE U OF L TSITES","UDDERS A EA M EGAPEDE S Y","CLAPSL M CAMIGON G WGROWL","PLUMER R RO I AVINESE E E","SEVENH A IARSONC E NK S Y","TEEMSE X  EXITST S  HATED","DRINKI D NTULLET E LO R L","HERON  O APACKS  K AIDYLL","BUGGYA L  YEARSO N  UNDUE","HUMIDE I WAGREEP T LS H T","SAGAST O WU U AFOGGYF E S","KNAVEI I NLODGEL E MSADLY","GRIST  G  DULLY  O  TOOTH","CAGESR U HOPERAW S LNASAL","EXTRA  I SSEATS  R ECHART","PROOFI M UNAILST T EOASES","AMPLY A I  R L TREAT Y C ","EMPTYD  R INNERF  A YARDS","RULED S L  U I TROTS P E ","WHALER  I A  B POKEST  L ","ZEBRA E A  R I MILLS E S ","FLAREL  O A  A SLUSHH  T ","USAGE T U PORED R S SENSE","GREENU  A L  R FAILSS  Y ","UNCLE O E SNAPS C E GENRE","SWANS   U YARDS   G CREEK","TONES   X LOSER   R QUITE","SPICYU  O PRIVYE  E R  Y ","BRIDE A I  K M VEILS D Y ","FIELDL  E EQUALE  P TARTS","AREAS   P LUMPS   L BUOYS","PACKSA  A LAIRSE  M SHOAL","RAVESA  N TAMEDI  M OBEYS","ADDER U N KNAVE E O  S Y ","ROAMSI  U G  S HACKST  Y ","PLANSO  I DATEDI  C ABBEY","TIMES N A  E S SPIED T L ","VALETE  M REAPSG  T E  Y ","PASTY M I  B L  E E CRESS","CUBIC   D ORBIT   O GIMME","AROMAX  O LEMONE  D SLASH","COUPS   A PRAYS   E BEARS","HORSEE  P R  O BRUTES  S ","FRISKA  L LOCALS  C EVOKE","BILLSL  O E  V ADIEUK  S ","GRACE   H LILAC   R BUOYS","EPICS A R  L E FEVER D K ","CHAFF A O  L C ALOUD S S ","ACORN A A  N K DOSED N D ","FRESHL  T A  O GRAPHS  S ","KEEPSN  A O  T TORCHS  H ","CURDSH  O E  L FAREDS  D ","RUNGS L L STRUT R E SANDY","TREATR  S I  I E  D SOWER","FIXED M L  P O SLIPS Y E ","ENACTX  O TRICER  O ASSAY","BLEAK U N EMAIL P M TYPES","IDEAL E D  C M TRAIT Y T ","GUILD N U  C M HUMPS T Y ","YAWNS   I OUTER   C RITES","DICTA N I KARMA N I TENDS","FILLSL  O ALLAYI  D ROAST","HARSH I O  D W  E E ADORE","POEMS   A QUART   S SIGHS","KNOWN   O ALOOF   E DEARS","GROAN A X  T L CEDED S S ","YELPS X L  T O FORTH L S ","SATIN P D SATYR C L SELLS","PONDS D E ADDED L D  Y S ","WAFTSA  O T  X C  I HUNCH","BIRCHR  U AFIREI  S DOVES","TACIT B N  O E EVERY E T ","WAFTS D E  O N EBBED E T ","SNEER O A SUITE N E USERS","PUFFS N I  F S GIFTS T S ","INLET E N  A E TRUMP S Y ","RACED   A STATE   E OPENS","SNEER I X  G E WHERE T T ","WEARY   A CRAZY   O LAIRS","EASEL   D CAVIL   F QUAYS","PEERSL  A U  I GLENSS  Y ","JOKES C R  E R RAKES N D ","WOODY M R  I E STRAW S D ","BURNT N E  D W BELLY R Y ","VILER N X  E T SPOOR T L ","SHYLY E L IDEAS G M FERAL","NIGHT N O  D R HEADS X E ","GOTTAO  R O  O DEMURY  T ","FROGS A R TRAIT E E  S F ","TWINER  O ALIBIC  L K  Y ","CLAWS O H IDLER G L LEAPS","STOLE R O  A V WILES T S ","COYLYR  I U  N SLEETT  S ","TRIESI  A L  T DOTEDE  N ","POKEDU  L PILOTI  P LIKED","CRIBS O L  A U WRIST S H ","RURAL   D CHAOS   P WANTS","GANGS L L BLOOM O B STEER","FRESHI  A LOINSE  D SATYR","SPIEDH  A ALIVEL  E TRESS","FRIAR   C ENTRY   I BLADE","GOODSU  A M  R MOTESY  D ","BEADSR  E A  E WINDYN  S ","FOLLY V I  A K GREED Y R ","MOVED U L STUDY D E COURT","CAMEOR  N EXISTE  U POLES","REEVE   E DEBIT   N CURSE","HOIST U M STOIC D R LOCKS","AWOKER  A SWORNO  M NATAL","BREADL  S U  S F  E FLOSS","SHONE U A  M K RACER N D ","SUITET  W A  I BIRCHS  E ","BOARDA  E CAPESO  F NOISE","INANE   O PRISM   E WORDY","PILOTE  A S  S TOXICS  S ","BRISKR  H INUREE  E FLAWS","WROTEH B AE E SRHYMEE S L","DEMURY   UIDYLLN   EGRASS","REBELE O IE O MFUNGIS S T","MOUSE A  AITEMS H  EISLES","TIARA D  G E  I A  NFLUNG","LASTS Z  CAUDIO R  UDEPOT","PELTSU E HR M ASTOICE N K","SCOWL  R O  B FJOINT  T Y","CREDOR Q BO U EOVARYK L S","MOTIFI O UN D SERASED Y S","CORALL O IU O TM K HPASTE","CLIFFL M EI A NMAGICE E E","BLOCK O  N B  A E  VASIDE","INFER  U E  M NKNEAD  S S","ALONEX   XLARVAE   CSQUAT","YIELD  X AKHAKI  C SFITLY","SAVEDH O IEYINGE C IP E T","BRISKA N NN G EDROLLY T T","RIGIDE O UACUTEL T TM Y S","DESKS T  I H  Z E  EIRKED","SHAME    SSTEMS    AREEDY","DRAFTE   OFUNGIE   LRUNES","SHEENT   UOWNERR   SKNAVE","GOOSE P  D I  GSURGE M  D","RACKS G  THEAVE N  RSTERN","SHAKYO D AL D RE E DSIDES","AGINGB   RA   ICHIRPK   E","LOUSE U  X G  I H  SSTINT","STEPS H  HAUDIO M  OSPURT","RAYONA E ON L IC P SHUSSY","MILLS    HMOSSY    LLANKY","SPIEDA D RBAYOUR L GE L S","ATONEP T XA H ER E RT R T","CORALY I AN V MI E ECARED","PLAZA A  WKINDA R  RASKED","COOED U  USTAGS D  KWORDY","STACKA I NVIDEOE E WDESKS","LOWERI I OE N VG G EE S R","BLANDO   EMAXIMB   OSPAWN","LEVEEU   XSTOICT   ESHELL","VOTEDE U URELICB L ASWEAT","FRISKI S IX S LE U LREELS","NIGHTE I AE L MDODGEY S D","HINTSY E TE C ON K IA S C","MANES X  A I  B O  LSMOTE","HIRED R  RRADII T  LBEADY","HEAPS    TRADII    CCHALK","MOVES A  K S  I I  F S  F","PLANE    TLOATH    IMAGIC","MORALA A IN D GI I HAFOOT","CHAFF E  APLUMB L  LVOICE","POLKA U  L G  TCHAFE T  R","COURT A  O S  DAIRED S  Y","KEEPS  V EAROMA  K TFIEFS","DRAKE U  X L  ARELIC D  T","HORSE  O GSTUNG  G EBLEED","HOOTSY   HMAIZEN   LSNIFF","CASED R  ELOGIC M  ORALLY","DOTEDE W EALIBIL N GT S N","AWARE A  B D  OFELON D  Y","WINCHA   EGOTTAE   RDROPS","DOINGU S IE L LL E LS S S","PEDALU E AD E SGAPESY S O","SLYLY I  ISCENE K  LASKED","SHANKH G NI I OP L TSTEPS","BRINK O  NCYCLE A  LFLAIL","SHOWNA R UWAGEDE A GDANCE","GOINGE D RE I ESMOKEE T T","GAMES T  NGOTTA L  KFLUTE","BAYOUI   NNOTEDD   USHAPE","PAREDI E IV B KOBESET L S","TWIGSR D PI L ABLEEDE D E","CHIPSA   NGONNAE   RSTAVE","CHINKO N NDITTOE E BSERFS","ADOPTN A II S LMAIZEE S D","RUSES    HPODIA    FGRUNT","HURLS L  H C  O E  OBRAIN","SIRENO U EU D AT E RHORNS","SONNYP O EEQUALN N PTASKS","BATHSL   WA   ONEVERD   D","SCRAPN A AE B IALIENK D T","SPIED A  U N  PMINCE C  D","WENCH I  A G  RSHEEP T  Y","CRASH I  A V  N E  GPROPS","WHEAT E  H R  IADORN S  K","PEACEE B RA L AR E SSURGE","SNAREH R DE R GLOOSEL W S","FIFTY    IPARSE    LFRIED","ISSUE K  G I  G E  EASKED","PIPESE O NLARVAT E RS D L","YELLSO A WKARMAE C IS H N","EYINGL M RV B EE U YSHEDS","DARTSE I OLASSOT K TA Y H","CINCH N  A N  NMETED R  Y","PLUMSH S IO E LN R KESSAY","MIXED S  WFLORA E  RSTUFF","TRILLO   OTIARAA   DLORDS","EARNS R  OSMELL E  OIDOLS","QUALM S  E H  ABEGUN R  T","FAUNA N  T N  OMETAL X  L","B  A APINGN  G GODLYS  E ","F  W ACTORB  U L  N EVADE","A S OFETIDF A II T UX E M","S  S KNOCKI  A R  L TAMED","S T IHARMSR E LU N EB D T","S  O PORTSO  H U  E TIERS","C   ARIMESI   KM   EPAVED","A  O FLUFFF  T IDLERX  N ","F   WINFERV   IE   TSLAVE","H E HENVOYE A ELADENS E A","A A USIDESH E EE P RNOTES","L U SASSETM A OEAGERD E K","S B RWEAVEO Y BR O UDAUNT","S A ATUFTSO I SV R AEVERY","S C STROOPU C RN O EGRATE","S   APACKSO   HR   ETHORN","B S DULCERR E OS N NTHERE","A I BGIMMEA P AIDLEDN Y Y","C P MHOLLYA U RINCURR K H","G   CREEDYA   NP   IHAVOC","K W VNURSEI I XF N EEGGED","O  S BURNSE  A SWARME  L ","A B TFREERI L ER L AE E D","A D STHESET F NI E DCARES","A C AFILESO U KO M ETYPED","S T UTWIGSA T IFELONF E G","L   SUNTILR   II   NDOING","E C SDROOPG P IE R RSLAVE","A   AMASONB   GL   LELUDE","A  R DECOYO  A R  S NESTS","A O UBABESH E IO S NR E G","D T NWORDYA A MR D PFLESH","F   ALACKSE   PC   EKNOWN","O  G VAULTE  I R  N TOOTH","L A SADULTR G OC U RHAREM","S L CTHIGHO E ERINSEE S R","E F RAROMAR W ITALESH S E","A I AFANGSO G KOZONET T W","R K SEXISTP O AA S GYOKES","I C ODAREDL I IE M UD P M","T  I RAINSI  N E  E DECRY","I C IMELONB U AURBANE S E","A S IFAWNSF E LINANEX R S","O   MVODKAA   XL   ISWARM","A F  POEMSP I  LIGHTE N  ","S S ANAMESO O KU T ETWEED","C  V REMITE  L EXULTK  A ","E  E LOOMSF  A I  I NAILS","A  K FRANKI  E R  E ERASE","A F  SORRYK A  E U  WIDER","T A AHILLSI I SNIECEE N T","E D  BRINGB T  EXTRAD O  ","S F  MOISTA R  L M  LASSO","A M AFRONDO W OO E BTHREE","T L IOBEYSR A LCURVEH N S","O  T COBRAH  O ROOTSE  S ","A   EFRAUDI   GR   EEBBED","C  P ROVERI  R EMAILS  L ","L  P ARISEN  H D  A SNOWY","S  E LANDSA  I GULFSS  Y ","C  M ADDEDD  A EYINGT  S ","A D PFEWERO E UOILEDT T E","C   SLODGEA   EMODEMP   S","S  S PICKSI  U E  N DUSKY","U  C NEARST  E I  D ERROR","A L YGRADEO S AN T RY S N","A L  SLICKH G  E H  SATYR","A W AFLIRTI T TR C IETHIC","T U AWASPSI U SNURSEE P S","P  I OMENSR  D ELVESS  X ","S P SQUALMU L IA E LTERSE","S C MPARKAE O TA N EKEYED","P T SEDICTN R RN E IY S P","S O PTABOOO E SU Y ET S R","D T DREADYI P IP E NS S G","U L SSNEAKU M AREMITP E E","W P CIDLERD A OE Z CN A K","C M FADOBED W AR E REARLS","S S CLOCALI A EMOLARE Y K","N  V AIDESS  R TONGSY  E ","S   STRICKA   IR   MTAILS","R  Y EASESA  L COOLSH  S ","A  I GRATEI  E N  M GRASS","C E CHOVERA A EF D PEVENT","A  A COLDSH  O E  B DIVES","S  T TIARAE  A E  P PAUSE","P S ULAMESA O EY K RSEEMS","S  T COWEDA  A LOUSYP  E ","A  T SHARKI  I DREADE  D ","S  A TRUMPE  B MOVEDS  R ","E  G SWIRLS  A AGATEY  E ","C G UATLASN O UNEWERY S P","A H DCRAPEU S CT T AEVERY","A V ASTEPSP R IEBBEDN S E","S  W PAVEDI  I E  R SHEDS","S R BTHEMEI E RF K YF S L","S A SCOMETI U OO S RNEEDY","I A FVIGILO I IR L TY E S","G  G LAIRSO  O O  A MOUND","S C  TRULYA B  NAILSD C  "," B S FIRES G A POEMS T S "," C R VASES R S  R I HYENA"," S C TODAY W M HEAPS R S "," S P SKULK I A  E I ASIDE"," F R SITES F I WEDGE S N "," W  EBORAX O  IIDYLL Y  E"," P A GOALS L L ELBOW S W "," G K FUNNY M E SMEAR Y D "," T L POKES K A DENSE N T "," D R MERIT I V  T E HYMNS"," F  UDIVED S  D T  EUSHER"," R I CURSE R L  A E FLOSS"," T  ADROSS E  I A  DADOBE"," N C KILLS E A  C M CEASE"," U   GRUBS I   SNOBS E   "," F S YOLKS U I GRIMY S S "," R A FEIGN S A STATE S E "," C  CYOUTH A  ASTOOL S  K"," M  BNOISE L  N A  CTRASH"," H  SRESET A  OOPTIC S  K"," S  AOPTIC A  H R  ESKIES"," S D SCARE O I TULLE R Y "," B P WAKES R T GOATS N Y "," S  CTHIGH A  UCLEAR L  N"," S  LSHADY O  N W  CLYMPH"," B C MISER S D COVES N D "," V  ABOARS D  I K  DGAUZE"," H  EVYING D  GGRADE A  D"," J G YEARN L U CLEFS Y F "," R  TBOOTH B  IBEING D  H"," K  AANTIC E  UBLEST T  E"," C A LUNGS R I OVALS E E "," J  PROSES Y  A E  LODIUM"," P S MOCKS I A  N T OTTER"," B  KBROWN I  O C  CSKULK"," O  SHUNCH T  RLEASE R  W"," W S PIGMY S O LEAKS R Y "," L  AWINGS S  I T  DASIDE"," P  DMOLAR L  A E  IASPEN"," M L HAZEL I G  L A PSALM"," M S NATTY J O  O R GRIEF"," B S DELTA R O  Y R PLAYS"," S R SPIED A A  W L ENEMY"," S E SPOTS R H DINES G R "," C  RPLACE A  A N  DAGONY"," A  SSTAMP L  UBASER S  T"," W  USAVES L  UFLORA S  L"," L  ADOTED G  OFINER C  N"," R  LTEASE I  A G  KKNOTS"," W  IHOODS M  L A  EANTES"," T R BOGUS D N HATED Y S "," T  SDOUBT N  A G  RASHES"," E E SQUAT U G DIKES P R "," G O MENDS N D STYLE S Y "," G T COPRA N U  G M  S P "," L U YOUNG U D ASKEW E R "," B  BROGUE A  R S  YSTOOL"," S  BSPOIL A  U N  FSKIFF"," B R CAGED I S  Z T BEAST"," S  SSCARE O  I U  ZSTALE"," F  AFLOOD A  O T  RASPEN"," E I OVENS E N  R E HYDRA"," B A TRAMP A P AGILE S E "," T T CHEAP O W USING E Y "," G  SCRUST O  ASPOUT E  E"," W N TONES R V FLYER D R "," C M CHIEF O W USHER E D "," H  SLYMPH E  IENTER A  E"," A  ISWARD A  E K  AAEGIS"," C  UDUCTS R  UALDER Y  P"," G L EASEL L D  L G ASSET"," Q  ULURKS A  U R  ASTALL"," C  PTROTS E  A E  LODIUM"," T F LIMIT L L GERMS S Y "," B O FROZE E O  A N EDGED"," F  KNEIGH A  AWRACK S  I"," F  BVOICE R  G G  AYEARN"," P U DOWNS L C ALOUD S T "," F  IFILED X  OPERIL D  S"," I G IMBUE A I AGILE E T "," G  APROOF O  IOWNER S  E"," W  TFRIAR E  APSALM T  P"," B  CTOTAL A  A R  MIDOLS"," L I WINDY T I SHOOK E M "," S L BAKED N M  E O CRONY"," G  UKINGS B  A E  GISSUE"," B  ABUCKS L  KABOVE S  D"," C A TRUSS A S  T E DENSE"," K P SNARL I O  F X BERYL"," O  BEVOKE E  L N  LESSAY"," P  ABROAD O  ESWEEP L  T"," I F GROAN O L  N S ISLES"," T T LITHE N E  T S ISLET"," E T AVOWS I I CLUCK S E "," S  TCOYLY A  PSPIKE Y  D"," P T FIERY L O BEAUX S T "," S  SSHOOK Y  UCLEAN Y  K"," P I GIDDY N I HEROS D M "," S F BEGAT R I GUILT M S "," F B VENUE R N CRICK Y H ","C T AHEELSI R HD S EE E N","  S PSPORE  L ACREWS  S E","E T  VAULTO B  KEELSE S  ","A T  STUNGS F  ALTARY S  ","S I GMOVIEO O ECURLSK Y E","C H CABATES T LEXCELD H S","P S KEATEND O OA R BLIMES","A M BSPOKEH P AE E NSIDES","  P APEARS  I K  N EBASED","A T ADOWNSO I SR C AENEMY","  U TFUDGE  D A  E SPURSE","  S  RALLY  I    P  UNSAY","P H AUSERSF A IFETIDS S E","S E SCABALI B OOVERTN D H","S A  KINGSI K  F L  FLESH","U S  NOMADC A  UNSAYT H  ","U D ASPARSH I PE R ERAYON","S S  WELLSO I  RINGSN K  ","H L EAREASW A SK P AS T Y","A R TSIEVEI M NDRIEDE T S","S A  TOLLSE L  WREAKS Y  ","  D SDOUGH  C ISTAIR  T K","S A  WAFTSA I  Y R  SPECK","A C PGIRLSO U HN M AY B W","  R TSEEDY  A IBARON  S G","  A SDEBUT  A A  C RJOKES","E V ADYINGI E IC W LTASTE","  B GSWILL  R O  T WASHES","F F  LEAKYO C  ULTRAT S  ","  P ASKIPS  N H  C EASHEN","S R STEACHE T OA I WDOOMS","A L TSHADYS S PE T ES S S","A I EBASALY S FS U ISTERN","M S CAPPLYL R NE A IS Y C","S R  POOLSI U  EIGHTS H  ","  O GDIVER  A ITULIP  S E","  F AMIENS  L S  O EWINKS","  M KCHAIN  K O  E BMUSES","S S GPOWERI I AN L TY L E","  R SFRISK  T USTERN  S K","C O COFFERU T EREEVET N P","  P IGULFS  U L  G EVESTS","S R SWHOOPA W IM E KPADRE","S R WQUITEU D IA G RWIELD","S R  HEEDSI A  FOLDST S  ","A L SCLOCKH C UE K NS S K","F U  RUNGSA D  NEEDYK R  ","T O SUNFITN F UE E DDERBY","S C  TILESI O  FOCUSF K  ","  M  FLICK  X    E  VISOR","C P PATOLLR S AGUESTO D E","D F BURINEL R RLUSTYY T L","  C AHURLS  U S  D AQUERY","  U  CANNY  S    A  IDYLL","A A ABOSOMA H IFLEAST N S","P J SSTOUTH U AA S FW T F","G B UREEFSE G HE U EDINER","  S SMILCH  E A  E VANKLE","B T ARARESO A SALPHAD S Y","A I  CANDYT N  OMENSR R  ","S U CCINCHU S IL A LLOYAL","  A BMAPLE  A R  R TBATCH","A M SSHIRTI T AD E RENSUE","A T MBLAMEO R AVITALE S Y","U F ASLAYSH R SE E ERISES","S L  TRAMSI G  N E  TORCH","E O USORESS D EA E RYARNS","I L SSMOCKL A UE N NS S K","S D HPARRYO O ER O NT P A","  S CGULLY  A C  N LLITHE","S I EPINESI T ST E ASTRAY","F A ALINENA G KKNELLE L E","E M SGROOMG O IE D TD Y E","  E FGAYER  I E  N ELAGER","S F IPALEDA E LSIEGEM S D","  F  GUILD  V  HEEDS  S  ","O I SMUSICI S OT U USWEAR","  B HMOUSE  N ABAKER  S D","  E AZONES  V PABOVE  Y N","A G ESANDSS O SA M AY E Y","A V TSPICEH S EEATENS A S","  B OWHELP  E EBATON  S S","W E AHEARDI R DT L EEASED","O E UPINKST A UINCURC T P","  T PBEADS  L HPOLKA  Y W","F A RISSUEF S AT E CH S T","S C AMILLSI A IT W DHASTE","A V IGNAWSR L LELUDEE E S","  M VGLOVE  U X  S EKNEAD","S O WHYDRAI I IE U TDOMES","F S TJETTYO E PR A EDOLED","  P SSCREW  I I  Z SBEECH","S S WMANIAA I TL P CLEECH","A W GBRAKEA X NC E UKINGS","T G  EARNSP E  IDEASD D  ","U M PSPAREU I SR D KPUSSY","  I  FUSSY  L  TREED  S  ","T B FHORSER A EEDGEDW S S","  T  SPILT  N  FATES  S  ","A A  BOGUSA O  FANGST Y  ","F  E LOINSI  D C  E KINDS","B  S LIFTSA  A SNOBST  S ","C  E HINDSI  G P  E SPADE"," R M HALED T A  I T COAST"," D S NEVER F X  E E PROSE"," M I PADDY D O  A L AMUSE","E  S DUNCEI  O FIELDY  D ","S  S KHAKIU  U LULLSL  L "," C A BOONS C I ROAMS A E "," E S TABOO R L STRAP H R "," W S BROWN E A SCARE K D "," R F PILES D A  G S HEATH","A  S CRAMPH  E E  L STATE"," R B FUGUE D L  E L PREYS"," S S WHIMS I A TRICK T K "," R A HATCH Y O HOARD N N "," C F NAKED N T  T I LORDS","T  U USINGT  D OPIUMR  E ","P  S SCIONA  L L  I MUDDY","A  W RIMESE  L N  C ALPHA","A  A CROPSO  P RAILSN  Y ","P  V AVOIDN  O SCALDY  A ","S  S CRAWLI  I O  M NOISE","C  U LOOSEU  E N  R GIPSY"," V F TABLE L U GULFS E F "," S B STRAP U T KNOCK T H "," C S SAUCE M R  E I SOAPY","   A WHISK   S    A BUOYS"," C P EAVES N A  A L CLASP","P  S RACKSO  I O  M FRISK"," B S WROTH A E  V P NOISE","G  G REPAYA  L VINESY  S "," S R TOTAL U C SLEET S D "," R P MEALY S U SINGE N S ","S  S CANTOO  E W  R LOANS"," V P BOARS U O  C O WHIFF"," W F MOLAR R I BRINK Y T "," A A SLABS I A  V S REVEL","A  P BRASSI  A D  L ENEMY"," A S SPINS P A SLUGS Y S "," V R FINAL C C SEWED S R "," F S LUCKY S U USING Y K ","S  V TENETA  S GRATEE  S "," P S SOLOS U C SNAKY D S "," S E SMEAR A R ICING K S "," C D LOVES A C  S K  T S "," N S LICKS E U  C L BELLS"," L B COYLY C A CALMS L E ","C  W HOARDE  O SOOTHT  E ","S  A PANGSA  A DIRTYE  E ","A  R SLEETH  N E  E SHOWS","A  Y DUPESD  A E  R DROSS","A  H STRIPK  N E  D DRESS","F  S EDICTU  A D  R SWEET"," L D BITES A B AREAS S R ","I  S SPOTSL  E E  E SWEPT","W  P AVOIDI  Q FOCUSS  E "," Q S QUACK O U  T L HALLS","S  M PSHAWI  N N  O STIRS","L  S UPSETS  N T  D SMASH"," L S SAUCY N A  D N  S T ","F  T LIGHTO  Y SLUMPS  E ","S  A CHEFSO  T U  E TWIRL"," V W SIXES S E FOLDS R S "," S Q SCOUR R E FETUS W E ","U  S SULKYU  I A  F LEAFY"," M H FOLIO U L STALK H Y ","S  K PERILI  C LARKSL  S ","I  A DIRTYY  O L  N LEVEL","   P SCALP   E    A OUTDO","W  A ROUGEO  R T  E EXCEL"," C S PARKS C U  H L LEAKY","D  D EVERYI  E G  G NURSE"," S G SKULK I U  P E ASIDE"," T I GRIMY E B  E U ADDER"," B J ALBUM I M  S P  S S "," S V LIKEN N X AGREE S D "," J A HERDS S O STORE S N "," P A TAXED I G UNFIT S S "," R S TEMPO P A HARDY Y E ","O  A CLUBSE  L ACHESN  R ","E  P SHARKS  O APRONY  F ","A  A BRIGSA  A FRETST  E ","U  I SHONEA  A GIANTE  E ","O  S FLUKET  A EXITSN  E "," A K AMONG B O  E W ARENA","S  S TRUCKU  U NEWLYT  L "," M S MOANS T O COMBS R S ","A  S MISTSI  A G  R OMITS","F  A LARGOA  E MIENSE  T "," T M CONES N N BEADY D S ","   S JUMPS   E SWARD   M ","A  A BOUGHH  L ONIONR  W "," C P FAULT P A  E I BROTH","A  B BULLYB  E ORGANT  K ","C  T HOARYE  O ABATEP  S ","S  S TWICEE  R M  U STABS"," M S HALTS G A LIMBS C S "," H A BADGE R A WRAPT Y E ","P  I STAVEH  O APARTW  Y ","A G MFORCEO A AO V NTEEMS"," G  LMANIA L  BGEESE S  L"," C  SFINAL G  UHAREM R  S","T F MHOLLYO A RRISERN H H"," H  SCUBIT R  ECREEP Y  S","R E MIGLOOV B VE O ETOWNS"," T  SPRINT E  ATAMER D  K"," G  HWHERE O  AASKED T  S"," G  UBASES M  UMINER N  P","S M SCLANKA Y AN B TSIEVE","I C ACLODSI R SN A EGILDS"," S  CNEIGH X  ADEPOT S  S"," G  UVICES V  A E  GSNORE","P L ASHEDSA A PLUNGEM S N","E O ABUCKSO C KN U EY R W"," U  SONSET I  AATOLL E  K","I D ICLUNGI C LN T OGUSTO","S S UKINGSI A UPAPERS S P","W C SEXULTN B ICAIRNH T K","A   UFISTST   EENTERR   S","  S UBELLS  I H  C EJOKER","A E ALEVELT A OAUDIOR E F"," S  SELBOW A  I G  S S  H"," S  MAPPLY L  RDINER T  H"," T  TTRASH O  EQUASI T  R","M W HEVADER I ARISERY T D","M P EUNSAYM A IMELONY M G"," W  PPONDS R  H S  ARENEW","L S PYOURSI L HN K AG Y W","I A EVINESO V SR I AY L Y"," H  CTENTH A  I V  MGENRE"," G  TJUNTA S  KSTATE O  N","A Y EBREEDA L ICOLICK S T","S C APALMSO A KU W ET S D"," P  UDUMPS P  I I  NFLUNG","M H AYOUNGT N IH T NS S G","C D EYIELDC F IL E FEARLY","I D SMOUNTP E AL L RY S E"," P  UFLOES A  AVYING S  E","S T STAWNYA I RR G UE S P"," P  FNAIVE R  W K  EWAFER","F C MREEVEA D NN E DCODES","M   AEASELT   IE   KRAISE","C D CHARSHA A AO W LS L K","S S GTOTALR E AA A ZPULSE"," S  AWHERE E  O A  NPROPS"," T  SWHOOP O  I R  TUNITE","S U ICASESR I LI N EPAGES"," G  AFLOWS A  KADOBE E  D","A S ACOTESU A PTRIPEE R N","N A POWNERT N ICRUDEH L D"," Y  IHARPS R  SADIEU S  E","D F SWORSTE E RL E ETHREW"," N  ATELLS W  HCLOSE Y  N","L   SORBITA   ITWIRLH   E","  L TBLUSH  N EKHAKI  R R"," Q  RNUDGE E  E E  KDRUMS","E E IDOSEDI S EF A AY Y L"," A  SABBOT B  AREALM Y  P"," H  AMEWED E  DELATE S  R"," S  ATIRED G  USMALL A  T","A D UBLOTSA N UFLOORT R P"," T  EHEATS N  S T  AESSAY"," Q  AQUAYS E  K E  EKNEAD","A   UFIVESI   IR   NEYING","H H SADAPTB U YI L LTASTE","    AMOVES    S    EWIRES"," L  EHOARD O  I P  FESSAY","E B AGILLSG U SEERIED T S","P   SAVERTN   UI   NCLING","O T UFAREST A AEYINGN T E","  F ABIRDS  A SBRUTE  D S","  A CGAMMA  B L  L MREEFS"," T  EBROOD A  I M  CSPLIT","S C FQUITEU G EA A LWARNS","E C IDOLLSI O LCACHET K T","F S ILOCUSE O LE R ESPELT","E P ALOANSB Y HO E EWIRES","S T IPOEMSR N LA O EYARNS","S F GPOLARI I AL C ZT K E"," A  USILKS D  UZEBRA S  L"," S  AAMONG O  L T  OBELOW"," T  BCHAIR E  O I  IDRAWL","A S USKIPSI L AD K GE Y E"," L  ADEEDS D  H G  EFELLS"," R  SRAJAH B  O B  PFILLS","O P RPOISET L AI E CCADET"," A  AACTED I  OUDDER S  N"," C  CEARTH V  U I  MSLEEP","P U ILONGSE T SADIEUD L E","W P VADORER R RE T BS S S","T P FABOVER N ARIDERY S S"," M  PMAZES Y  HGOTTA R  W","I P ADOSEDY A DL L EL M R","Y W FOTHERU E OR E WSALON","S B UCLOGSO A UPOSERE T P","A A VBAGGYI A ID P NE E G","  C IGROAN  N F  E EPOSER"," G  PFILLS M  ASMALL E  M"," B  CGRUEL A  ODICTA D  K","S F DN A EEQUIPE N OREACT","ATONEM  O BRINYL  C EDGES","WHEREI  E SLEETP  V STEEL","V L HO I UMIMESI B STASTY","INDEXN O  FALLSE L  RISEN","TRULYE  A SHIPST  E YIELD","FUSEDI A ISALTSH S KYEARS","R P BI I AFINEST T ESPOOR","E E OA L CTRUTHE D RNIECE","STILLI  I GATESM  G ACTED","I C PN H ADYINGE N AX A N","WAFERI   IVEINSE   ESWORN","IDEASN L WCHOKEU P AR E R","UNFITN R ACROCKU G ETUSKS","REAPSA  I JAILSA  L HARSH","REBELI O OSPURTE T UNESTS","GAZERA   ESCARFE   ESCOUR","AFIREB N ABATHSE E EYARDS","ROOSTO   ACLANSK   KYOLKS","D N GA A ATWIRLE V ESLEDS","RISERE O EFELLSI O IT S N","N Q TE U HWHITEL L IY T R","G S CA O OYELPSL A TYARDS","DIGITR L  OMITSL D  LEECH","W S WI P ICHIPSK C PS Y S","N  M E  U WHIMSL  P YEAST","C S TO W UMAILSM L KAXLES","A T EL I ALACKSO K EWASPS","MODELE O URIVERE E ES S D","CHIDEA  O SYRUPK  G SIGHT","MIDSTA   UTEAMSE   KSIGHS","VESTSO T TWEAVEE G RD S N","R S WO H AALIBIR P TS S S","M B GO U ATROLLT Y EOASES","RABBIO  E GRUFFU  I EARTH","RENEWO   AMOLESA   TNURSE","S S RA N ILEAPST G EY S N","NEEDSE  E SHAMST  O STANK","GORGEU  U SKIMST  M STAYS","RURALI A  MATCHE E  SIDED","APPALL   ETHYMEA   KRAILS","PLEASU  R FANGSF  U YOKED","OVARYD  I DRONEE  S RAVED","A P DU H EGROUPH T TTROTH","VEXESI   USTEEPI   ETENOR","V V PA A ILILACE U KTEENS","TOXICY   APIPERE   OSCULL","JUMPSO  A KNELLE  M ROUSE","LIVERO  A WAFTSL  E YOUNG","GOOSER R XINGOTE A OFINAL","FISHYA  Y RATESM  N SQUAW","L H PE U OACRESK T TS S S","N L LO U UMANESA A TDARTS","SPAWNO  E FAREDA  D SALSA","I V  M I  PESKYE T  LEASH","SLIDEA    FOUNTE    RATIO","ABUSEC  T HERONE  I SHOCK","LIMITO  N CHATSU  E SHARP","M E MA B ODEBUTA E HMODES","SHOUTO M HWHINEE T SD S E","SLIDEA  O CORDSK  G STREW","PADDYI  R QUAYSU  L E  Y ","PADDYA  E RATIOT  G YAWNS","RAZORI  N TRASHE  E SUITS","SMASHL  H ASHESB  A SHORE","FRONDA   RCIRCAT   ISIREN","M B EA I NRIGIDK H ESATED","TABBYE  R MINESP  E OUTDO","DICTAE  H BEVELU  S TIRES","CANONO  F BIRTHR  E AGONY","R T CI R LSMILEK L AY L N","R F PE R IGUILTA A CLURCH","LOFTYO O  FIREST K  Y S  ","O G PL O ODROSSE D SN Y E","ADAPTC L EUNITET V NE E S","TRYSTR  T USERSM  I POPPY","C F LA A UPANGSO C TN Y S","M D RO E OTELLSH L ES S S","M N PA A OMOVEDM E IA S A","SALTYT I  REACTA R  WASTE","NERVEO O  BEVELL E  YARNS","LOYALI  I CHUMPK  E STUDY","BRUSHA S  SWISHI N  LOGIN","P K FA H UCHAIRE K ZSEIZE","AGATEW  E ANIMER  P ELBOW","MOODSO  U TEEMSO  M R  Y ","GIMMER A  AXIOMB Z  SEEKS","CHAIRA  N ROOFSE  E SHIRE","PEALSU  I MOCKSP  E SWING","LILACA  T WANTSN  I STICK","LLAMAE C GDITTOG O NEARLY","STEAMA   IBROWSR   EELDER","CLASPO   ACURDSK   TSALVE","OILEDC  A HOARYR  T EIGHT","LYNCHO  E WINDYE  A ROARS","AGINGC   AHERBSE   PSEAMS","W S BA E LSENSEP S ASPELT","PLUMBU   LPOSSEI   ELIKED","TOLLSW  A IRONSN  K E  Y ","INLETN A  FORGOE V  REALM"," S M  L A LEMME E M STEAL"," V  P I  RGRAZE U  YASHES"," F D  O I CARVE M A USING"," L  O O  CVOUCH N  RUSAGE","PSHAW P P GUARD R O INANE","SPADE L R SOLAR T K ASHES"," B  V A  IDRAWS E  OADDER","USURP T  IPOINT U  HSTORY"," T S  R L DOZEN U E STATE","SWAYS I   GREYS E   USING"," M  M E  AODIUM I  MMANGA","BLOOM I  AFLOWS A  TACIDS","CAUSE V   FAWNS I   PLUMB","SKULK I L STRAW E M USUAL"," P G  E O RECUR R R ASIDE","IDLER R L VASES W C SLITS","EBBED L  OWARNS N  E K  D","WHOSE O  ASLATS L  E Y  L","CHEAP U M ORBIT L G  S O ","STUDY U O FLATS L E LEAST"," K  U E  SLYNCH E  EUDDER","SPIED I  OEVENT O  ESTABS","CLAPS I O SKIPS E P  S Y "," Q G  U E FIXES L S STEER","ASIDE U A GIFTS T E LEAST"," B R  E I GRAND R S TYPES","ALOFT A I CRESS G T VERSE","ASKED T  ECORES O  KSPOTS","EATEN C   FOLLY R   SNOUT","NAILS R A SIXTH S H JEWEL","ABHOR L   DUMPS R   STAFF","SCOWL A  APRISM G  EFOXES"," S  F C  LDALLY L  E Y  R","GROWN E   DEANS D   PSHAW","SLINK O  NNONCE P  LASSET","ASKED L  OHIDES M  EHYMNS","VISOR D U TENTS A E BLURT","SLAGS I  TALTAR A  USCANT","ISSUE P   PINTS K   SERUM"," A W  L R SPOOL H N MANGY","WANTS I  AIDEAL E  VADOBE","MANLY D A NOUNS R C FEWER"," M F  U U ASIDE I G ACHES","PLUMB I  ANEEDS G  TCEASE","MOORS P E PEDAL R R PAUSE"," M  M O  AFUZZY T  BTHREE","ALTAR I N EVOKE E L ADIEU","CARVE V E WOUND W T  S S ","UPSET A V GREEN T R  Y Y "," O  V C  ASHOAL R  VDEUCE","CHIEF A A CRAGS D E MYRRH"," D S  R E HOMES N K PEASE","LIVES M B MAYBE G E WEEDS"," P M  O A CURSE N T  D S ","AGAIN R  ARACES N  AIDYLL"," C B  O A EBONY R A EARLS"," W  W H  IFIRED M  EUSHER"," L  Q I  ULEDGE N  EUSHER","FLING O  ESWAIN L  RCYCLE"," F  O L  CWATCH N  RSKATE"," F B  L U TABLE T G ASSES","TWINS H I FATES R C OFFER"," S  F T  ABOOKS V  TPESTS","SKATE N H CAGED V F PETTY","REINS X I SANER C C STREW"," T Q  I U UDDER E E USING","ABIDE O   WOMEN K   ASSAY"," C K  L N SOLES V L HEELS","OCEAN O M DRIPS D L ASHEN","AWAIT H   BENCH L   SPAWN"," F  P R  AWASPS U  TADOBE"," H B  A I DRUGS M H  S T ","WRAPT A  AGIRLS L  TUSAGE","THIEF O  LASSAY T  EUSHER","OCCUR O  ATWANG E  EEDGES","STEED E  ECAPES R  KASHES","OPALS U  UORDER E  EDEBAR","ASHES H  TGAYER R  ASPINY","ACRES O  IUNION I  CSCALE","ASSAY A G ALOES T N  Y T ","VANES G  TWEDGE N  RSTAIN"," B  L R  EFADED K  GVENUE","OFTEN L   DAISY G   USERS","SHEEN O S GROSS S A BERYL"," S B  A R ALLAY V V JOYED","ABODE L I ROOST T K  S S ","TENDS T E THOSE E K BRISK","EVADE I   PEAKS W   PSHAW","VAULT B I SHAVE O E PRISM"," C B  O U BUTTS N T OTTER"," M D  O E SABLE N V ASHES","ACRES H   BUGGY C   SKINS","DROPS E H AFOOT I T STOOP","ACIDS L I RIOTS F T AFOOT","WALKS C  WSHAPE E  AADAPT","YELPS R O PEARL C C  T H ","ADOBE U R SPEED E A ASIDE","SCALY L I KARMA S B CHEST"," O  K V  NMAUVE L  LASSET","IGLOO L  AVOTES B  IPEAKS","BATHS  O TROUSE  R EMISER","HIDES  R  LEAKS  K  AVERT","GIRDSU E EALIVEN N DOASIS","M R CO E HCOPSEK E CS L K","F S RI H ASNORTH C EYOKES","BASICA T ESMELLI R LSENDS","BEGINA I  TIPSYE S  DRYLY","F B RU I UGALLSU L EEASES","RUPEEO R  PRANKE T  SWEEP","SURGEP E SROBESA U AY S Y","O P LC I UHULKSR E TESSAY","F N FI E EFAINTT G IY H D","LOSER  N  BOOBY  W  BAYOU","DECOY  A  CASTS  E  PADRE","STOOLI W OGRIEFM N TANGRY","MILKY  O  COCKS  U  VISIT","VOCAL  I IRIVET  I HUNCLE","SCRIP  E IPENAL  D EBUSTS","COMETE U ADOCKSE U TDUSKY","ASSETL H ETHYMEO L MS Y S","TACKSE R ISPENTT A EYOKES","INFER  R  AGATE  U  VIDEO","P B PO R ISWOOPE K EREEDS","  G F  O LSORRY  E EUNDER","SIDED  O AMOVER  E EMESAS","GIVEN  E EQUIRE  L DFISTS","W B RI O EDAWNST E IHERON","SCOOP  U AENTRY  D EBROAD","DUSTYU N  SKIFFK F  Y F  ","FABLEE R XAPACES T RT S T","Q P CU O AEASESL E TLADLE","LADLEO E  STEEPE M  RESET","R C II O GGRUELI R ODITTO","N M TA I OVIXENA E EL S D","TOTEM  E USHAMS  R EFUSED","CABLEI O  VIXENI E  LARCH","F E CL D AEIGHTE E CS S H","BACON  L  CLOCK  S  OBESE","TICKS  U HFORTE  L EPAYER","ROMANA A ATAPESE L TD E Y","PSHAW  O  GUILE  S  EATER","BASES  I  PORTS  E  COSTS","DEBARA U  NAIVEC L  ENDOW","TOPIC  U  BULLS  L  BISON","ETHERL E ABOASTO R EW D S","RATEDI A EPARSEE D MR Y S","L A MO R OBLENDE N ESNARL","  G P  R ODRIED  S IGOTTA","  P P  U AHUSSY  S ETOYED","M C EU A NMILLSP L US S E","PUFFSU O TFERRYF D LS S E","WAFERA I OSWEEPP L ESIDES","ISLET  L AWRACK  M EGRAIN","CIGAR  R  GNASH  V  KEYED","T B PH L OREAMSO C EBAKER","PANSY  O  BUMPS  A  ENDOW","RATIO  E WSHEEN  N EWISER","C D CA E ORACKSR R TY Y S","NEWER  I ACOLIC  L EFISTS","ARSONI W ISHALEL Y CENSUE","PROBEA M NSWEETT N RY S Y","CABAL  U EPURGE  R KPOSES","DIGITU A  PAYERE E  SHRUG","LASSOI T PFLUKET N NSITES","PIQUEI U ALEAKSE K ESTEED","M P AA R CJOINTO O ER R D","WIDTH  A ALIMBS  P TBUSHY","LICKS  U LDERBY  L LDRYLY","TESTS  T HHOARY  F LLOFTY","NYMPH  A EJUNTA  I TTEAMS","  F A  R CDEATH  I EGALLS","L R PU A USIDEDT I GSTONY","PIPERU A ULINERS I AEXCEL","P C PA O ATIRESE K TS S Y","MUMMYO E AANTICT E HSTRUT","P E VO A OPOREDP L KA Y A","DUSTYR H  ELECTA E  DIRGE","INFER  E UMITES  U EVESTS","VICES  L UPEARL  I KMUMMY","EASED  I OEAGLE  H RRUSES","R P AO L GSPELLI A ON S W","  M F  O OMETAL  T IPHOTO","T P BA U APUFFSE F ES Y D","G C WU L IAMENDR A ED N N","F P SR U MEERIES G AH E R","T T TI A OMUSKYE T ESPEND","CURSEA O  LABELL I  SENSE","P G RA U IPALESE L ERAYON","VOCAL  O OBLUES  N EHATER","NOBLY  I  HELIX  L  BESET","POSED  T RGAUZY  D LBUSHY","C R PR E AAGENTC D EK S S","MOWER  I OWINDY  D ABASIL","FAWNSU H  STICKS P  Y S  ","FINCH  O EULTRA  E VMUDDY","LEMME  A  RAJAH  O  BARKS","D N OE O DBONEDT C ESMEAR","T G DU O ESQUATK G ESHEER","BISONA H  SHAPEE M  SMELT","GRASSA I  BUMPSL E  ELDER","AGATE R R DARES F N STUDY","ABIDE R I TILTS E T PRAYS","FATED   L ERRED   C QUOTH","SHOWS   A PINKS   E PAWNS","STABS E A AMUSE P I HOIST","U  V N  I FEEDSI  E THROE","LIMBO   U WAILS   K FUSSY","WREAKI  L EXTOLL  U DADDY","BUGGYA  I SHARPI  L COAST","DRIPS A I PINTS N C MYTHS","WHIPS   O FLOSS   T GUISE","STAGS   E MODEL   S FILED","JELLYU  A DITCHG  E EVADE","SKILLO  O CRAFTK  T SLAYS"," S Z  N O LOONS W E  S S ","SLEDSU  E GAUNTA  S REVEL","BRASSR  P AILEDG  E SPADE","FLEET A A DRAGS V L GAMES","PUFFY R I HINGE N H HEATS"," G A  A I BULLS Z E  Y D "," Q T  U I VELDT U A KEELS","STACKE  H ROBEDU  E MOCKS","STIRS   E SAGAS   C EIGHT","BENDS   A WAITS   E WILDS","CLODSA  O PERILE  N STAGS","CLAMPO  A PRISMR  O ARENA","BOASTA  P SCALYI  I SECTS","RABBIO  L BREEDI  S NORTH","FRIAR   D DRUMS   I TINTS","FIGHTA  U SCARST  L SALSA","BANJO   E CRASS   T BURST","O  B C  E HEDGER  E EARTH"," F T  L H BUOYS F M OFFER","SLOPEH  L UNTIET  E SHADY"," S W  E R TAPES M A  Y K ","PRATEU  W PLAIDP  S YOUTH","BRIMS O E DUCTS N E  D D ","N  J O  E BEETSL  T Y  Y ","GRAFT   U HOIST   E TOAST","SHAPE E R BATON T S SHRED","DULLY   A WICKS   E MOIST","BROWNO  O WEIRDL  S SHIED","TRIPER  I EXULTN  O DUSTY","STOOL H F PUFFY M E SPARK","BRIBE E O CELLS V T TENSE","SLITSI  O GROWNH  N TRESS","ROUGEI  O GIRDSH  L TRAYS","BLISSE  T LOVERL  E EXALT","GRAMS E A LEADS D L  S Y ","MOVED   L CUFFS   I NINNY","EDIFY R U PIPED E L  D S ","SANDY S E SKIPS E T  W H ","ALLOT   P SWEEP   R AHEAD","ADOBEN  I TRIBEE  L SAWED"," S I  O N TOYED T R WHITE","OCEAN H T GULLY R A ANGST","ENSUET  N HOLDSI  I COLDS"," S T  H E RACED R T  E H ","GLASS E O REINS C G CHASE","AMONG O E BRIER E D  S Y ","O  P N  I STEPSE  E TIPSY","PROBEA  U WINGSN  G SWAYS","SNACKA  A TACITE  R DOING","BURSTU  W DOMEDG  P EARTH","SMILE E A TRUTH I H STEED"," C Q  A U ANVIL N T TYPED"," D S  U I LENDS L E ASIDE"," T H  A O SKIMS E E ANGST"," Q V  U E MARRY I S GLUED"," B M  O A GULCH G E CHESS"," S F  W E HEWED A L CRASS"," C S  O T ALIAS T I USURP","SWISH H L RIPEN C D WHISK","MAYBE L L HERON R N STUDY"," K D  N U BIBLE T L  S Y ","CROWS   R MUSES   S GUSTY","HELMSE  O LOOPSP  E SEEDS","PUFFS S U CHART E R GREYS","CHOSEO  L MALESE  D TRYST","WAIFS M I OBESE E H GREYS"," F L  I A GRAMS E B  S S ","FILTHO  R LEVEED  S SMASH","PRIDEA  E TORCHI  R OBEYS","FIGHT   A CHIRP   R BUOYS"," C C  R H ROBIN U N SPOKE"," F B  L A FAIRY K E BEADY","LEASHA  E BOREDE  D L  Y ","FLAKYA  I CROOKE  S DRAKE","SCOWL L R MIXED C A  K K ","BANJOA  E SPERMI  K CHEST","BEAMSO  O SALVOO  I MUSES"," G H  I A TRACK T K THESE","BANJO   A INCUR   N COATS","FOISTU  O STOLEE  A DOERS","APTLY I I ENEMY E I  D T ","SOLVE X O HINTS D E BENDS"," H B  A I ARISE D O HYENA","FOILSR  O ARROWI  N LEASE","PORTSL  R INNERE  E SPADE"," F C  I O DEALT N O  D N ","D F AI L NVYINGE N ES T L","JOINTI   RFORTEF   NYIELD","OASES  N TFLAKY  R LBELIE"," G  P L  SCOUGH A  ASTRAW","TOPICI E HGRAZEE K FROSES","GROWL O  IABOUT E  HISSUE","THUMB E  USLIMY M  EUSHER","FATAL  W UQUILL  N LBUSTS","AFTER L  OBOARS R  IGAMIN","LOWER    EVIRUS    EADOPT"," C  U R  PCARDS Z  EMERIT","LARVAA   CPORCHS   EEVILS","ZEBRA  R CCLOTH  A ESIDES"," G  R L  AWOUND V  I E  I","P C WA H ISCIONH N CAPACE","CABAL  A UHOSTS  I TWALKS","MOTIFO I IASPENT S CS Y H","HOPEDA I AVENOMO E PCASES","RABIDA I ECARTSK T KS H S","R K FE I ICLOUTU S LR K Y","ACHES A  OGRIEF E  AUSERS","L L LA O ICLOCKE N EDOSED","RABBII O DVERVEE E ATIDAL","M B CA E ASILKST L ES S D","PAPAL  A ADAWNS  N SGUSTO","USHER H  OBABES D  IYEARN","MANGA R  BCOUCH M  OBAKER","ROOMSE A APETALA H SY S A","  C P  H OMAILS  N SGRAZE","THREWU E AROLESN A PSEXES"," S  C H  LSALVE M  FUSERS","ETHIC E  RGRATE S  E E  P","A D IN E DGOLLYS V LT E L"," A  V R  ETEENS N  TTACKS","EBBED L  EPEASE E  PIDOLS","HAVOC B  RGOOSE U  ESTEEP","USERS H  PWAGER R  ISPRIG","CHAFFO N UPAGESR L SA E Y","A G FS U ESTAIRE N ATROLL","JUNTA  O NBRICK  S LTHESE","DATUMO E ISLAPSE S ESWEAR","KINDA S  CFLASH E  EISLES","  T V  U IGANGS  E TMEDIA","TOPIC  I LSHAME  N WHOOPS","TOWERI   ODRILYA   ALOYAL","A C VP R IPRIEDA E ELASSO","D B VU U APARKSE L ES Y S","AWAITI H IDREADE A AD D L","DOLED    OSCREW    RTALLY","SERUM  E AGRABS  L TLIMBS","HOVELA   ASTALKT   EEAVES","U H SN O EDEUCEI R MDOSES","SKIFFE   AWORLDE   EDRIES","W S OI T AEARLSL I EDUPES","SPRIG R  UAEGIS Y  T S  O","AMBER  R EBOATS  V ESTOUT","SPRIG E  ULAMPS S  THELLO","D S TI W ECOINST F TAPTLY"," A  P S  ICHINK E  EKNITS","  J S  E HAGREE  K LBASAL","F S WI H RFLUKEE N AS S K","THUMB  N OSATIN  I UGULLS","ZEBRA A  LGRIST L  E Y  R","STEEP Y  AAPART E  C S  H","EGGEDX   ECRUMBE   ULIGHT","S L BI A ADESKSE S IDROWN","FORTH Z  APONDS N  TPEASE","BLOOM  P OYEARS  L SFUSSY","ROMANU A ILYRICE E ED S R","U   US   DHOARDE   ERAZOR","HILTS    OTHROW    ETRIAD","TRAMP  L ATAINT  B ETOILS","E G PA R OSHOCKE S EDOSED","ISLET M  EMOANS T  TMEALY","L P PI O OMUSEDB E IS R A","L F TA R USHOPSS Z KOBEYS","WRING A  ADIRTY L  EUSHER","SIGMAE   UADULTT   OSHOTS","RABID R  IBEAST N  THARRY","WIREDA I UDAMESE E TDUSTY","B C EO O RSTAIRO S EMUTED","  S F  P USTAYS  K SPOESY","BROWSO   HGORGEG   AY   R","SPELT  B AGIBES  E TMUDDY","VIOLA S  SSLOTH E  ESTERN","OPTICP I REMPTYN S PS Y T","BEFIT  I OBANDY  E EFUSED","S L FH O IABASEL D LL S D","VOUCHO   ETUNEDE   GDANCE","UNFIT  R ISPERM  T INOSED","TYPEDE A OSHIFTT N EY S S","N B PA E OSILKSA L EL E R","R P MU O OLILACE K KSLATS","P T MI U UVOLTSO I KTIPSY","N P NA U OSELLST S EYIELD","COMIC  O RDALLY  A PMERIT","C M FR E OALDERC I UK A M","AFOOT L  HRADII R  GFETCH","M F MO A APATHSE E OD S N","  T P  E OFUSES  T EMISER","C C SHAREMA I OFREAKF D Y","BALESA O NS C OTHUMBE S S","TOPAZO  B R  O STOUTO  T ","S A CH U UO D RWAILSY O E","S M  EDIFYR N  FADESS S  ","MOTORO  C T  H HURRYS  E ","M  D UNSAYR  M ADAPTL  S ","BUYERA   OT   OHUMPSE   T","W S PIGLOOT Y STILESY Y E","P F TREEVEE R MSHARPS L O","S F BKNIFEI N SPLANES L T","MOMMAA I BY N UBUOYSE R E","N G BOZONEN U RCARRYE D L","TRIALA  W R  O TANKSS  E ","FASTSE P WT E ECLASPH K T","J   GUNCLEI   NCOVETY   S","B  A OCHREA  R SHOOKT  W ","WOODYA  O K  W EARNSS  Y ","L E LISSUEG S AHEATST Y T","B L LU E AR A WSEVENT E S","F P BO E OR T OKNACKS L S","GRILLI M  P P  SALTYY Y  ","DICESE U AE R NDIVEDS E Y","WORDSR O WO U INOTESG S H","S  P KNOLLI  A FERNSF  K ","P F  RIOTSA O  YELPSS S  ","LADLEO  E R  A DECRYS  N ","BOWLSA  A N  T JADEDO  R ","HOOTSA M EN I NDATESS S E","T   AHARPSO   HNERVEG   S","G S BR L AA A NFLICKT N S","STOVEW  I I  S SCIONH  R ","USUALS   IU   MANKLEL   S","CYCLEH H XI I IDUCKSE K T","BRIERA D OT Y AHILTSE L T","T G BO R EI O RLOWLYS S L","NOISYA  K M  I EDIFYS  F ","ELATEX U VI G OSKUNKT R E","LAMBSE  A A  N FLEASY  L ","K F FI O RN C EGRABSS L H","G U ULOSESO U ESTAIRS L S","M  F OVARYD  E ERREDL  R ","METERO I AO N JSIGMAE E H","DEMONE E  A D  LOAMYT L  ","F  R ROYALA  C MOVERE  D ","WHARFA L RI I OTEAMSS S T","TIERSA N LR S OTRUMPS E E","ERREDD E AI G ICRASST L Y","D  W REPAYO  I WHIFFN  S ","H B SO R TU A ERIVERS O N","CHAOSL G WU I ABANDYS G S","S D ML O OI W OCORDSE Y E","B G PL R RO A OWAVESN E Y","PACKSU O MS A ASOLESY S H","A L ALYINGO M AFLINTT T E","D I PELDERE Y IDOLEDS L E","S S  HOPEDO O  WARNSY E  ","B M AACORNN V GJOINSO E T","GENUSR  T A  T SANERP  R ","B F SEQUIPA N ASIDEDT S E","N P NOCHREI I VSHAREE L R","SPILTH N EA E AWARDSL T E","BIPEDL L EU A EFATEDF E S","MOORSO  O I  A SCARST  S ","M F  OVARYD T  ENTRYL Y  ","G   ULOCKSA   URECURE   P","G T BR H EA R ABLOOMS E S","WRISTO   ER   ATICKSH   E","CLOSER  H O  A WHOLED  L ","WHACKI B NN A ECACHEH K L","B  H ARSONT  U HYDRAE  S ","L A WA T OM O RBINDSS E T","GAUGEU  I L  B FUMEDS  S ","FRONTL V  E A  AGLOWS S  ","M  P OPERAU  A SWAYSE  S ","FLAWSA C HN R OCREEPY S S","G H AEVENTN R OROBINE S E","INDEXD R  E O  APPALS S  ","VIDEOE E BR B ESTABSE R E","W S CHITCHE R ARUINSE P E","SOUNDH S AO I ITONESS G Y","GIANTO M EO O NSOUNDE R S","S H SH U TI L AFELONT S D","SHAFTO  R U  O POUCHS  K ","F G SENACTT I AISLETD Y E","T  D IDLEDA  M RAYONA  N ","MAMMAI  O N  O DOERSS  S ","J A SUNCUTM T EPROVES R L","S S MPOLKAI I TCONICE G H","SNIFFC D IO I GFROTHF T T","R W BAMIGON V LGREATE S S","WOOERH  Q I  U MEDIAS  P ","H D  ENEMYA A  PINESS S  ","C F FLARVAE E TAWAREN K S","SPOORN M OI E OPINKSE S T","T  H IRKEDG  A HEARDT  T ","THIEFR  A A  S PIPESS  L ","A T  BREEDO E  DOMESE S  ","R A GARSONB P ABLESTI N S","D A GOLDERG O AMARESA E S"," C  AFATES R  SMOVIE L  T"," C P TOPIC B O ARGUE A S "," B  PAUDIO O  RLYRIC S  H"," F F SLYLY O O BURST R S "," A  G B  U L  EFEARS R  T"," D A DRUMS A B DINES N R "," I  AIDEAS E  IEASED L  E"," J  CSALVO D  ZLEAVE D  N"," W M WISER L W LEVEL S D ","TONIC T  L T  ASERUM R  P","SWUNG E  R D  OAGLOW E  N","ARENA A  M Y  IHOPES N  S"," A B HURLS G O MERCY R K "," Y  WRECUR A  AWRAPT N  H"," F T SLEEP U A SMART E S "," S G THERE R I FUMES G F "," S T STRAP R M EASES P D ","SWIFT I  O P  UNEWER D  S"," M  WDEMUR S  ECARTS S  T"," M  FZEBRA T  TCACHE L  D"," O B OVALS A I BRINY Y K "," N  GPAPER I  ABLEST S  E"," D  SFILET C  ANEWER S  K"," V O ROGUE M G NIGHT T T ","FRETS E H  A R BLUES S W ","ASPEN A  O T  NCYNIC R  E"," G  TLAGER V  AWEARY L  S"," G  GCREDO E  TTAUNT T  A","FLITS I O  M X CIVIC T C ","EGGED R  A O  LCAMEL N  Y","ABBOT I  E S  NFOXES N  E","MAJOR P C  R E LOCAL N N ","SCORE A E  N B FORUM N T "," G T VIVID A E SNORT T S "," B V LADEN R N HOSTS N S "," D  TTEMPO P  UCONIC T  H"," R  LSALSA I  IODDER S  S","GOODY A R  K I DEEPS N S "," G   CROWD I   SPOTS S   ","ACTOR R  I O  NSNAGS E  E","USAGE P A  O U GONNA R T ","ACHED A N  D S FETUS T E "," G  NTEMPO A  IFRETS S  Y"," L T POURS O A SPECK S T "," B  CAROMA A  NFILED N  Y","ABATE U  X R  IFLATS Y  T"," S  F T  I O  XCRONE K  R"," R F LEMON G I FALSE L T ","AGAPE U  N I  DPLACE T  D"," G  SGROWL A  AEDIFY E  S","ABHOR L A  O S MOVED D S "," C H GLOOM O O LURKS T S ","ABAFT O  R N  ACURED S  E","EVILS I  K S  ASTUNT A  E"," G  F R  I U  RSNAGS T  T"," S S OWNED I A DRAMS L S ","SCALD H E  E M CAROL T N ","STAYS H  H I  IPRIDE D  D","STAND U O  T S TOMES R S "," R  YNOBLE S  ARIVER N  S"," S  AALBUM A  ISPILT S  Y","CHATS E A  A U GLENS S T "," G B LOCUS L R BLOND Y T ","SCRIP A  A C  LWHILE E  R"," S C STOOL O R OPENS S S "," P C GLEAM E G EATER S D ","PULLS N  C C  IAUDIO T  N","GUIDE S R  U A SATIN L N ","CHEER U  I M  GBIRCH D  T","USERS W  L A  UGIVES N  H","SPRAY O S  L K PANEL R D "," F P QUEST S A VEILS S M "," F F ELBOW O Y DOMED D R ","BLOND O E  O A ENTRY S S ","SERUM S  O S  LDANCE Y  S","ASKED L L  I A EMITS E E "," B  WLEVER L  EBLUES E  T"," G G DROOP I A SPADE E S ","FORTE A E  T A CHURN S S ","ABIDE R  T E  HBARGE K  R"," F  MPROSE U  SCIRCA T  S","EVENT E  E N  NHORSE M  T"," D  CDETER L  UDATES Y  T","USURP E  R R  AQUERY M  S","SPITS O R  L E FATAL R D "," D F LEARN A U UNTIE S T "," D M GROOM A N OWNER N Y ","RALLY B O  O G LUCID T C "," W L FILES D A MOCKS W Y "," D U RAINY I S ASSAY Y Y ","RABBI Z L  U U CRAFT E F "," H S COATS A E DROPS D S ","LEAFY N I  S L DUSTY E H "," S  FSWEAR O  OCREPT E  H","PADRE F E  O P COILS T Y "," C U TRESS O U SPURT S P "," S  PREFER E  ABROWN S  K"," R S PEEPS A E SLICK S K "," E  EANGER V  AMORES Y  E"," B  FLATER B  ODEEMS S  T","PUFFYA A ED R LDUCALY E S","B A IU N NN T ECHIRPH C T","A L BF U OT N NEGGEDR E S","DUMMYA A EU R ABORESS Y T","  J  BLUNT  N  LUTES  A  ","  B  STALE  T  WROTH  N  ","P M NA A UN R RGASPSS H E","  B  FORDS  I  DAMPS  S  ","B W CR H HO E AWHARFN T E","H A TELBOWA L IDEEDSY R T","FIGHTO R RR O ADOWRYS N S","S A CTAMERU A OCOZENK E E","S S  PANGSI O  NOBLYY S  ","HUMPSU A PL U ULIVERS E T","S A SLIMITI U EPOSERS E N","COMESR I HO N AWOULDN S Y","T W AASHENB O GBILLSY E T","RISENO A UU B RSELLSE E E","I F SSALONS O OULCERE K T","T S GH A AE L UFRAUDT D Y","REPLYA O EF P ATAPERS A N","PUSSYU H OF A KFORTEY P D","C B WR E II F SCRIMEK T R","S F WT I RU N EDEEMSS R T","LEPERE I OM P UOMENSN D E","ABASEU L XR L IALOESS T T","VITALE O LR D ASWARME Y A","F C RLOOSEU L EFADEDF S Y","C C TL H OA E WPLACES P R","  I  WORRY  K  DEEPS  D  ","POWERH A OO R ONAMESE S T","C D IHIREDO E OSMALLE D S","SAGASK R TI E UFRAUDF T S","ROAMSO W OO A LFORGOS E S","E S RL W OE O UGROSSY P E","T H SR U MA M ACHAPSK N H","W C  HILLYI O  LOCUSE K  ","  M  ALOFT  V  WHICH  E  ","  M SSCULL  R UHEAPS  L H","SECTSW O NE R ELLAMAL L K","S S AINCURG O OHEROST N E","W S KO W IR A OMARKSS D K","T Y YR O EI U ABERGSE S T","S T MTORSOA U UBASISS T E","  B  GLEAN  A  FLUID  X  ","H R POPERAO C TFLUSHS R S","  P PFAUNA  S LMESAS  Y Y","  R PSMEAR  I IBEGUN  N T","S P OP I BA L EWEEDYN D S","M S  ACHEDN R  GLUEDA B  ","O B ABLUESE C IYOKEDS S E","K P RN L IO A GWINCHS T T","BLURTU N WR T ISKINST L T","P M MR I OO N UWHEATS S H","FUMEDA A RR N ECOINSE A S","H U  ASSAYL U  LEAKSS L  ","C D BR W UA E SFILCHT T Y","P R CL E LU L ISWAMPH Y S","R T WAZUREN N ECRIMPH C S","PORESO A AL B TABBEYR I R","CUFFSO L TR A APRIVYS R S","PIPERU R OF O AFIXERY Y S","DITCHU E UC N NANTICT H H","TUBES  R L  A EWAGED  S S","S R CH U OA L OCLERKK S S","GOLLYR A  I I  SPRAYT S  ","SOCKSM A IA N GCRASHK L S","CLIMBL S UA S SCOUCHK E Y","S G BTWICEU D VDODGES Y L","DISKSA L WL A ILIVESY E H","  S LPOPPA  O PFIRMS  T E","W L SROUGHE N ICIGARK E K","LACKSO L AF E LTUFTSY S A","  S LGAMMA  E SSLAYS  R O","VESTS  T I  R XFEINT  P H","GOTTAR I ME D EYEARNS L D","DOGMAE R  B I  APPLYR E  ","  E TSONNY  V PSMOTE  Y D","I B IGUARDL T LOCHREO S R","CUBICR R AE O NPAWEDT N Y","A N ASWORNI T GDUCKSE H T","G H BOZONEL U SLUNGEY D T","U B  SHADEU N  RAJAHP O  ","S P GCHAIRR C OASKEWP S S","  T  ETHIC  R  WOODY  B  ","  M DSCARE  Y ESCOLD  R S","  W  BLEND  D  BAGGY  E  ","MOPEDA I IN Q VGAUGEY E R","BATHER E NO E TINTERL H Y","  P  MARKS  O  MAXIM  Y  ","T S DH P OI R ZNOISEK G N","T I PHENCEI G LGLOATH T S","B B URULESA A EVIZORE E S","ADDERP E OA C UROOMST Y E","A R CTOOTHO O INAMEDE Y E","GIBESL O EI O EDOZEDE E Y","T P PO R RM I ABOOBYS R S","G E PR T RO H OVEILSE C E","L F BO L ED O RGAUDYE R L","SABLEL E  O L  PALMYE S  ","L  T ESSAYA  P PRIEDT  R "," W F PILOT E R LLAMA D S ","STIFF R I  I T SCALP K Y ","AWARE H O  O P MOTES P D "," R B BERRY F U WIDTH T E "," B T ORBIT A C RISKS N S "," A E PROXY E A FARCE S T "," K Q RECUR Y E DETER D R ","TRIBEA  U I  R LOINSS  T "," L P MOVIE C P PAGES L D "," P S TRAPS U A ENTRY E K "," H T DETER A A GLORY S S "," F C SUGAR N B IDEAL S L "," H T RAZOR R T SPEAK Y L ","R  W OVERTA  E DUCATS  K "," N V REMIT S C STEAM S R "," S B SPIRE O A VOLTS N S "," S C FATAL L C ALPHA Y E "," C T MAJOR L W BLINK S S ","C  P RULEDU  A DOCKSE  S ","STIFF R R  O O CLACK L K ","FIEFSO  R A  I MEALSS  L ","SALSAE  P R  R VAPIDE  G ","W  C HARRYA  I COZENK  S ","G  F LYRICI  N DOTESE  R "," F B DAIRY I A GROWN Y N "," C H COVET M E ABODE S S "," P H CHEAT I R BATED L S ","FLASHL  H A  A SCOPEH  E "," N S BOOTS S U TEAMS D P ","CABBY L O  I O HEATH N H ","V  G IDEALR  Y USHERS  R "," M L NOMAD V D DIMLY E E ","CRAFT E O  A L APTLY S Y ","SWISHT  O A  W LIVEDE  R "," P F AREAS I U POINT R S ","DANCEI  R G  I ITEMST  E "," U E SLEDS T G IRKED A S "," D S REEKS M U QUELL R L "," R R MEDAL A P SPRIG S D ","CRESTO  T W  I EVENTR  G ","DESKSE  N R  O BLOWSY  S ","JESTS N R  S O DUCTS E S ","LIMBSE  L G  E ARISEL  T "," C F CHARM A I COVET S D "," T W SIGHT A I PROPS A S ","D  M REFITI  X FLEETT  D ","NAVALO  I B  D LEVERE  S "," M W MAGIC G N FILCH C E "," S A CHEFS O I SWARD N E ","FROTHI  W L  I MATCHY  E "," M M SALON R O PROSY Y E ","DOLLSR  I O  N SITESS  S "," B F GRAIN A R EGGED S D ","TRUSS A A  Y N HOODS N Y "," P L HEROS T S BATED L S "," J R BEGIN A L ENDED S D ","TEETHW  R I  U GUSTYS  H ","U  F SWEARE  C ROUTSS  S ","FROTHL  I U  A THORNE  A ","T  M OOZEDA  N STUDST  S "," A W  R H  R I CAMPS Y S "," B A CROWN O A HOURS D E "," T D BREAK A T FINER L D ","B  K UNFITG  L GOLLYY  S ","S  B HUMUSI  C PECKSS  S "," A T FLIES O N PURSE D E ","SIGHT D A  I R CORPS M Y "," F C MOTHS C U BUSTS S E "," P G PEONS E A PROWL S S ","LARGOO  U O  I PULLSS  D "," A C ANGLE N A NONCE Y K "," O B FLARE D A WEDGE N S ","HIVESE  N A  T ROARSS  Y "," P W LIGHT K I LEASE S K ","ARISEG  P A  I PINEDE  D ","D  A RAINYI  N FORUMT  L ","P  P REGALI  W CHINSE  S ","HELPS N O  V I JOINT Y T ","PUSSYO  T E  I STARSY  S ","B  B APTLYG  U GUANOY  T "," L H CANAL C T BESET D D "," S V SPEED O X BONED L D ","SIEGEA  L L  A SEEDSA  E ","KINGSN  O O  D BALLSS  Y ","S  R TROOPI  M NATALT  N ","K  B NEARSI  E FRIARE  K ","QUAYS N A  S C BATHE Y T "," A A SWINE F G HURLS L E ","B  S UNIONL  N BLANDS  Y ","M  S ENJOYW  B ETHERD  R ","SLASHH  H E  E LYRICL  K ","TOAST M E  I A ITEMS S Y ","HOODSO  U I  E SMELLT  S "," V A MENDS N M BASIL L T ","CRAFTH  L E  I SWARMT  T ","L  G INCURM  S BEETSS  Y "," A T SPOOK P A GAUDY L S ","TRAMSH  E E  A ICILYR  Y ","P  N LAYERU  W MUSESE  R ","BLUFF O  L G  ETIERS C  H","GRASP A  R Z  AJOLLY R  S","G I PN D IA I LTHOSES M S","PLUMBU S UF U NFLASKY L S","METALI R AG O SHOOPST P O","TRICKW D NI Y ACOLICE L K"," U  MENTRY D  TLURCH E  S"," G  CPASHA Z  UVENTS R  E"," S  FAMIGO E  IBARKS R  T","  U FKINDA  S IHEART  Y H","SLEEPO N EN E AGAMESS Y E","  C CCHINA  G SSTAGE  R D","USUAL N  I O  TGULCH T  E","T   FOFFERD   EAPARTY   S"," P  FGUSTO L  OSPEED Y  S"," R  BQUEER D  ULEAKS R  H","C G MA E OC N UHARESE E E","  P GSOLAR  A AQUITS  D S","S D ML E AY E KLAPSEY S S","P R TE U OA R NSTAVEE L S","  A WFUNGI  I NCOMIC  E E","T C PR L OA E ODRAWLE N S","TONICO O AM U NBONEDS S Y","LARGEA O XI B ITRIPSY N T","ASSES O  T W  OREFER D  E"," H  MLARGO V  UROAMS C  E"," S  BTHEIR A  IALIVE L  R","R S PALPHAB E TBEECHI D S","FUNGI N  N S  DRAISE Y  X","SALVOT A XI R IRAVEDS A E","ABHOR U  O S  OCHIEF Y  S","THROBU O UL O SLIMITE S S","E N SDROOPI B AFALLSY Y M","CLINGH D RA Y EFOLLYF L S","REBUT X  O T  KPRIME A  N","C A THYDRAI A SLIGHTD E E","W I TOLDERR I ULOOKSD M S","S V CCHEERO I UWINDSL S H","H F JAMIGOR X UREELSY D T","USURP T  A R  NWARDS P  Y","U K BN E AI E NOILEDN S S"," C  NPHOTO A  BTOWEL S  Y"," S  FKHAKI A  GBLUSH L  T"," S  MGLAZE A  MABOVE S  S","STOICC U UR G RACHESP T E","L B AI E NM G GBOATSS N T","T C LA A AX N SEXACTS L S","D K QR N UA E AMALESS L I"," A  Q G  U R  AJERKY E  S"," F  CZEBRA T  NLINED D  Y","  F RFOLIO  U ALIKED  E S","W R NABASES T WPRIDES O R","  A MDADDY  M TWEIGH  T S","C G BO L LU E ACHAINH N D","M F PAMOURR R ICEDEDH S E","LATERE R IA A VVOICEE N N","CLIFFL N EA L APLEASS T T"," S  BHOUSE U  RSPINY S  L","CRUMBY   RC   ILOSESE   K","DROWNR C UA C RFOURST R E","WEIGHH   OA   IRESTSF   T"," B  MTITHE G  DCHINA T  L","PLANEL L NU L TSLOPEH W R","P C GL O RA N ACOILSE C P","CHAFFR N RA N OSTUNGS L S","TONICE   AS   DTRUCEY   T"," B  TFUNGI X  PHOOFS M  Y","BURNSA A OS I OAUDITL S Y"," R  BLOSER Y  ICAKED L  E","B A VL B EI Y LNOSEDK S T","C F AL O TE U OFERALT S L","  L HPHOTO  U VHASTE  E L","J A AI L GF B AFRUITY M E","G G CRARERA A APAPASE H S","F S PO H OA A NMOVEDS E S","U T FSEWERA A EGUISEE N D","FLUNG  S O  U DBERYL  P Y","F D GADIEUN C SCHESTY S S"," S  C C  A O  LJOLLY P  X"," K  R N  O E  OLEADS L  T","P S OU T BS R ESLUMSY T E"," S  LKHAKI R  NQUOTE B  R","I O WS W HL N IERECTT D E","TENTH Q  A U  RBIPED P  Y","O P RBELLEE A NSINCEE T W","THUMBA N LL I IKNOWSS N S","F D HAMIGOR A IMARKSS Y T","CRUMB E  R A  OWRECK S  E","PROOFR P AO T TSLIDEE C D","P M CARENAG S BAVAILN S E","B C CL A LO V EWHIFFS L T","H S RE P AL O VPRIZES L S"," E  SSNAKE J  VWORSE Y  R","P L CU E OM A APOSTSS T T","S S HP W OI O RCAREDE E E","W P BHORDEO O RSIXTYE Y L","F F VAFIREI L RTICKSH H E","SCOOPT M RU I OMITESP S Y","S S EPOPPAA E SSCAREM R S","E A HDUNCEI G RCARGOT Y N","M  B OAKENA  I T  N SURGE","SCOFFT   LALPHAF   WFAUNS","E  B Y  E IMPLYN  I GAYER","TENTSH   WREEVEO   EBLUNT","WISPSA O ETIARAC R MHUSKS","F S BINTERE O IL R NDUMMY","C  R RAJAHU  D M  I BRUIN","K A OE D NE I IL E OSPURN","T H LOBESEI L EL L CSLOTH","MOISTO  A TOILSO  S RAJAH","C    HUSKSE    S    THICK","S R TIMAGEN B NE B SWHINE","PINTSL   OUNDERS   THANGS","A  A ROUGHE  I N  N AMIGO","ENDEDN U IDECKSO A CWELLS","DRIESI S IV S LE U LREEDY","P D TAMIGON R TI G ECREAM","B  K RIGHTI  A A  K ROBIN","L J CYOUTHR R AI O PCORKS","FARCER  L IDIOTL  C LACKS","S B HC A IA Y LR O LFLUES","G A DENDOWN I AT E RSTUFF","BEGATA  I NOISEJ  L OWNER","D V SREIGNA S OG T BSTABS","S G KKHAKII M NF I GFINES","HAVOCO E OVEILSE L TRUSES","R A IAIREDK E EE N ADEARS","SIREST   TEVOKEE   WDIKES","SPANSH  O REMITU  S BARED","S C SLARVAU A LS W LHILLY","P H SLEECHU L IM L NBOOBY","AMITYM  O O  K N  E GAUNT","M B LE R OAGONYN K ASHELL","CARGOR  O UNDUEM  T BERYL","DRAFTW  R AURASR  M FATES","SHRUBC   ORAKESI   OPSALM","T  S RARESI  N A  S LIKER","SCORNT T UETHERE E SPURGE","BACONO H ASWEATO E TMURKY","DRYLYA    RUNEST    SLAPS","PAGANR O OI T TN T CTEACH","SLACKC  H ROSINU  P BRUSH","TRIPER  R ARGUEM  N PILED","V R SAGAINL I AV L IEASEL","A U ARISKSR U HO A EWILES","CARRYR   OADIEUW   TLOATH","ALLEYV    ALOESI    LAUGH","T R IO A RO Z OL E NSADLY","CURLYY   ONAVELI   KCHEFS","R P TA L ICOASTK Z LSHAVE","TONESI    BERGSI    ACTOR","S   FHOVERR   OU   ZBRUTE","COACHH  O AMAZEF  E FLUNG","S   VT   II   PF   EFEVER","F O CREPAYA E CI R LLEAVE","M S SINERTN R AE U YRIMES","PROBER  L IGLOOE  W SLASH","G T CR E HI M EE P EFROCK","TROOPH C AI E CE A KFANGS","BUMPSR A IINNERN G EGOODS","SPELLH G  OUGHTR E  TODDY","R  U AMENDY  I O  O NOUNS","SNOWSI  A NUDGEE  E WINDY","V E DIMBUED B BE E AODDER","T S AU H LL O LI R APANSY","SHALLA  A LOBBYT  E STOLE","BASISO C TX O YE R LRANGE","CIVICA E RDUNCEE O STIMES","C O MI P IGREEDA R SROAST","S  B ORGANC  T K  O SPANK","P C CRURALO I UO M EFLEAS","FORKSR  N EDGEDE  E SPELL","CHORDI  E V  M I  I CANTO","SACKST   ERAYONA   DWARES","PAUSEL  A UNCLEM  V BROOK","ROCKYA R  VIOLAE U  DEPTH","G S GO T UTRUCET N SANGST","P A ESOLARH I AA B SWRITE","WINESH  V ASHENR  N FIFTH","TWEEDI  E CADREK  I SHRED","S  S TOPAZA  L N  V DAZED","C  O LOBBYI  E F  Y FIRST","A I HRADIOR L PO E EWADED","DWARFO   OGAZERM   TABODE","T A FRADIIO I XO E EPOURS","R R SADAPTT B EI B AOPIUM","V B OO A PM Y AI O LTOURS","PRISMA  C NATALI  L CARED","MOTORO R AVAUNTE N ERAKED","O A AP L BICILYU B SMAILS","PRINTL   EUNCLEM   TBENCH","C S DLOWERE O AA O PNONCE","STABSC   LRABBIU   MBUSHY","PASHAL T CU R HM A EBOWED","VISTAI C  LOOPSL R  ANNEX","C  A YAWNSN  T I  I CROCK","T  A HELLOR  I O  B BRAIN","WAKENH A OI R BR M LLOAMY","B  T UNCUTN  N C  I HATCH","NAVALE  L I  I G  B HELIX"," S D OWNER A M  M O SPENT"," T  FTHROE R  V O  ESWEAR"," B  UBACKS Y  U O  RTULIP"," B I CAUSE N L  J E WORTH","SCANS A   SCALY A   MOIST"," P  VPROVE U  N D  UDENSE"," S G DIARY G A  M D DARED","FRANC O  HCYCLE A  AGLINT","MELON A   STALK E   CRABS"," C S WRACK I O  M R APING"," U  TANGLE D  E E  NGRINS"," V S FISTS T A  A N ELUDE","ABLER R  ITOMES K  KMERCY","ERROR A A  D T  I E BOUND"," A W  D H CIDER E E BURLY"," R V CABAL D L  I U WIPED"," B  SHABIT Y  A O  RCURES"," V P  E A DROSS V T REFER","WEARS R  ACREPT O  YPRIOR","HARRY U E ODDER I V TOWEL"," A S ADOPT O A  B R PECKS"," S  ATHIRD R  O E  RTWAIN"," R  SREMIT B  A E  LALIVE"," C A COLDS N O  I R SCANS","THEFT A E STORE C A SHELF","SKATE N  JROUSE L  CSLEET","CRUST E A SCRIP U N TRUTH","SKUNK H   HARES K   SILKY"," C  FGRATE E  R D  NHOMES","ABUSE O K BRAIN A L EXILE","SQUAT U  U A  F S  TTINTS","IDLER O L SWIFT R I DYING","SKIES H  PBASTE K  NFIRED"," G  UCROWS A  E V  RFEUDS","FRAME A A  N D  G A GERMS","GLOVE I E AMONG B U CORES","MADAM D D GIDDY E E CURDS"," C M WOMAN P G  R I PATCH"," S C KNOLL O A  R I SEAMY","BLURT L A CANDY M I MAYOR","EBONY A  A Y  W O  NPUMPS"," A  BODDER I  U E  TFUDGE","LAMPS L E VICAR B S DINED"," P  UMISER L  G O  ESTAID","ADOBE R E NAIVE M E MADLY"," H H  Y E ODDLY R L CANOE","AGENT A  UQUEEN N  IETHIC"," C  K A  ASMEAR E  MPOPPA","SHINE E   CARRY T   CHILD"," R D EATEN B L  B T CIGAR","AMEND O   EDICT E   CLUCK","ADAPT E A CLOTH T H LAPSE"," I  ABRUSH A  E T  AFETID","FROCK A O ADOPT I S MISER"," S F  P I DECRY L M CLASS"," O  B C  AOCEAN U  JBRAVO"," L  VHYDRA R  U I  LSCOUT","SMEAR A  OHYENA B  DHERBS","GNASH A I OVENS E G FLYER","ASIDE P R MOLAR K M DELAY"," S Q ALOUD U A  M C SPIKE"," S Q  C U COLIC O R SPIES","AMISS A  I N  G G  HDAUBS","SPANS A  AUSUAL H  TCARES"," A  CRUDER D  I I  BLOOKS","ABACK E  NCRANE R  ATYPED"," V A  I F ALLOY E O WRATH"," P  ASHOAL O  O T  EBOATS","AVOID E  WSNAKE O  LSMELT"," P  NCOPSE L  W K  LGAYLY","GAMUT L N KINDA B U AIMED","VELDT X U STACK R A SALTY"," B  TORDER A  A I  CINLET"," S L PIOUS G R  H E STUDY"," T  OBASIC B  C O  UTOWER"," S S  C C COLON U O WRAPT","HEADS L   OBEYS O   SWOON"," V B VIXEN D F  E I FORTE","DRILY A Y  B I  B N KINGS","SCOFF L I DEARS A S TRUTH"," L  TWIDTH L  O A  RSCION","ASSES M  NRABBI L  PCLIME","BEACH N L STAID E M TRIBE","SMART O  ASTALL T  KBORES","IDIOT U  R C  I A  ABLOND","ASKED W  ECOMES R  KYELPS","AGONY A  IAMAZE M  LCASED","TRIPE A H IDIOM I N SIZES"," R L DONOR M G  A I ENACT","CRABS A I  B B  B L LIMES"," D  C R  USANER W  ESNOWS","ADORE I E  C V  T E CABLE","GLOWS I A SNAGS G O MOUND"," C J  R U BELIE D C MODEM","DREGS A  PABOVE B  AMINER","ACRES O  Y V  R E  USTOOP","OCEAN A U SNAGS T U DOORS","WAIFS D E FIFTH E C AUGHT"," F  AHEEDS R  S A  AELEGY","AMUSE A   KNACK G   BASAL","WORRY  A A  D C  I HQUILT","DOGMAE R  STANKK Z  SPELL","LYRIC  A LDODGE  I FFLINT","FETIDI H ELYRICT O AHOBBY","ENEMYA X OS T UE R RDEALS","GUSTO  A  TOILS  L  GUSTY","  D SGLOAT  D O  G PFIEFS","MUMMYA A OG N UI G TCLASH","CLANG  L RAMIGO  B WWAIFS","  D  BRIEF  N    E  BORES","S A BTIDALR I UU E STRUTH","E M RBRAVOB T LE E EDISKS","  B CFRAIL  Y A  O SFOURS","BLAND  R  REEKS  N  GLADE","COSTSH P TAMIGOI L IRELIC","RUPEE  O NCOPRA  P CADAPT","APPLY  E  TIRED  I  HELLO","E K ADYINGG N OE D NDIARY","V F BA U LU N EL G STAILS","SMELTP L OO B OI O LLAWNS","COVESA I  RELAYE L  SPARK","AFOOTL U  OUGHTO H  FETID","S H DTHYMEE D SW R KSTAYS","G S IRUNESU A LF R EFILMS","  D ATOURS  C S  A EBILLS","R T CE E OA M RP P ESNOBS","SCANSE F TRATIOU E NMERRY","D P BU O ISALEST K OYEARN","P G AREARSO M HU M EDEALS","F W GA I UCANOEE E SDOSES","PUPPY  E  HOTLY  A  BILLS","GRUNTU N ASATINT I KSELLS","TIBIAO R GPRIORI E ECURSE","LIFTSA U OCANALE G ESLITS","D C WA R AR E IT D LSPOTS","R F JI I EDINESE A TROLES","TOYED  E  STALE  R  VENUE","FIRSTA A ARABBIE B NDRIFT","THROBH E UI M RE I LFITLY","BEGIN  U  FLASK  R  BADGE","D F AWHIMSA X HR E EFORMS","  M RKHAKI  N S  G EBEAMS","WITTY  O  PARTY  S  CRONY","DIVERI E HSANDYK A MSOLVE","S P  MILKYA U  R C  TAKEN","S O UCUFFSO T UO E APENAL","  A RBIBLE  O F  U ECATER","ROSINI P ANOOKSG O TSULKY","CURLSR A IURBANM B CBRIBE","CUFFS  O  TILTS  I  PROWS","PERCH  A ULABEL  B KFLIES","PIQUE  U  EXALT  L  BUMPS","L R ALEANSA B IM B DALIVE","BACKSA R PS U OI M OCABAL","PESOS  E HMOVIE  E DCORKS","O P APILEDE A OR Z BAGAPE","T P AWILLSI U HR C ELIKEN","PIQUE  U  CHAIN  L  LEMME","JESTSE E  SHINYT Z  STEPS","  S ADECKS  R P  A EASPEN","C A AR S BEXPELD E EOWNER","S S SPSHAWA O AN W YKINGS","A H TMAYORB D AE R IREACT","SHOPS  P TSCENE  R ACRACK","EVERYA M  SLAPSE I  SILLS","PEALSR R PE O OY M KSTARE","RIGHTE R RA A UL F TMATCH","CABLEL E  AXLESM O  POWER","MASKSE E PSURGEA V RSPERM","W R RA A OT B LE B ERAIDS","L P MARENAT N LC A EHULLS","BIGHT  A  WIPED  E  VISOR","T T SR I TUSAGES R ASTARK","S W SCLOCKR R II S PPEERS","  F SGAUGE  N N  G SVOILE","RAJAHI O OS Y UE E NSIDED","SITESL A  ABBEYN O  GROOM","SACKSC O EURBANL R DLEANS","T S TH K AROUTSO L TBILLY","ESSAYL T  BRAINO L  WELCH","  R  BRAKE  D    I  CHIEF","REBUS  R  STAMP  V  FROTH","OPALS  R TDROVE  M ASNARL","O H FP E RT L AI L MCRONE","O B UBRAGSE Y UY O ASKULL","  R UNEEDS  A U  C AMETAL","RADIOE R NPOETSE A ELIMIT","BEVELO I IWHOSEL L NSEATS","ULCER  O ECOCOA  O RSTAYS","HELMS  A MCIRCA  G SFLESH","C C MI A UR P MC E MASSAY","DUSTYO T  GREEDM E  AMPLY","M B  I A  DIKESS E  THREW","WISPSA P HG O AE O DRELAY","  E AFINES  D H  O EFAWNS","RIFLEA U XN N IG G SEXIST","REBUS  A C  Y O  O WGRUEL","A R  SLAGSS B  E B  STICK","  A UWOMEN  O D  U IWIRED","SLACKC R EABODER M LFOAMS","MEDALA  N MAUVEM  I APPLY","B  F ERREDE  I C  G HYMNS"," O H SCOUT H M  R I HEADY","CLUBSA  E SNEAKE  S SHOTS","G  B ROGUEI  T E  T FADED","TILLSO  E MEDALB  S SLITS","CHAFF E E PLAIT L N BOATS","R  I AMIGOD  L I  O INGOT","RALLY R I  G M  U B HERON","SABLEO  A LANDSA  L RIVER","DEBARA  L THROWU  N MOWER","HEALS   E BORAX   S MISTS","KICKS N H STEAM E K GRAIN","SLACK A A ISSUE S S ROLES","SKIMS H A CADRE K E GIPSY","TABBYH  O ONIONN  N GRIST","MUDDY   U SPANK   E POSSE","MOSSYO  H DONORE  R MORES","FIEFSA  O SWORET  G STOOD","PAPAL   P CLEAR   R TENTS","POKESL  A USAGEM  E BEARS","TRICEW  R IDIOTS  O TALKS","ACIDS O A EMPTY E U DRUMS","A  B SWORNI  A D  W EBONY","LOGICA  N BADGEE  O LOATH"," C S  R P VEILS D I MOATS","O  P P  I EBONYR  T ALTOS","AMUSE O H SMEAR M V BAKED","I  B DATESI  E O  T MOSSY","CAROLU  A BROKEI  E CLINK","VOILE   O BILGE   I CLICK"," C T SALES R A  G S MOVED","S  A NEARSI  O F  S FLEES","VERBSI  A AROSEL  I SPUNK","MAMMA G A CLING O G SWOOP"," D M TROOP O I  L S FLATS","GROSS   P TALON   O BLURT","GLOVER  I U  P F  E FERRY","ATLAS I F  B I  I R PALED"," V C  I L APPAL E S DROPS","LOATH   I COMMA   I KINDA","LULLSO  A CHARTK  V SOLAR"," P T NIGHT N O  T R LOONS","BULLS   I QUELL   A TRUCE","D  A WEAVEA  A R  I FILLS","B  S ACUTEY  O O  L URGES","BROWS I I  D S  G E ZEBRA","F  F IDYLLT  U L  S YACHT","ABAFTN  A GOTTAS  E TRADE"," S O  T F PORTS O E CLANS","KNOTS   H DATED   M MATED","S  P TOPAZE  S E  H PEDAL","SCARFT  E AUGERY  V STEED","ACUTE A R BREAK G D OOZES","GUEST N Q STOUT I A BLADE","PAUSES  T HUMANA  R WAKED"," R T CACHE B I  B N LIEGE","SPEAR A D  S I  H E GAMUT","ESSAY O I  B L  E E BRIDE","UPSET E M TREAT C I WHALE"," Q F LUNAR A L  S S BIDES","CHOPSH  L IDEALE  I FEUDS"," M M  O A MUMMY S M LEGAL","AMIGO   R BASIL   E GRUFF","SWEARM  G ODDLYC  O KNOWN"," L F DIMLY M O  B A BOATS","T  P ERRORM  L P  K OCEAN","FUGUEU  S NICHEG  E INURE","S  M IMBUEN  S E  I WRACK","CHUMS Y O  D T  R T WAGON","DAUBSI  E CURLYE  O DRAWN","COULDO  E LARVAI  E CURRY","CLIPS A A KNELL C E TEARS"," J T  O W  K A  E I WRONG"," D S EIGHT N A  G R LYMPH","WHOSE Y H WEARY N U RABBI","SNIFF   E FETID   N HASTE","PANGS V U BASIS I D FLIER","AGLOW   B TILED   S OOZED","STARS H A VERBS I B GRAIN","STEMS   U LAPSE   I JUICE","BLESTA  O SCRUBI  L CLASS"," L R REBUS A R  V A DEALT"," O G QUIRE T A  D Z NOTES","APRON A R DRAGS R A HYENA","PANSY   T ALOUD   N PANGS","CRUSH   W PATIO   N BULGE"," K B ENDED E I  E N SLUGS","GRAPHR  R INGOTN  W DRILL","M  I ALONGG  U I  R COVET","STEWSH  I OUTDOR  E EXERT","C  S AGAPEM  I E  R OTHER","H  L URBANN  S C  S HERON"," C B GAMUT N X  T O FOAMS"," D W POURS G I  M N GANGS","BOLTSA  R SWOOPE  U DUCTS"," R A PAINS D I  I M LIMES","RIFTS G R SLEEP O E HOUSE","GUILT   A LUMPS   S LOVER","COULDU  O BUDGEI  I CHUCK","PLUMBI P RPOPPAE E IDARED","B V HR E AO N VO O OMIMIC"," A  P M  EVIZOR G  CNOTCH","STREWH A IOLDENT I KSLITS","ROOTS U  M T  A D  SPOUCH","RAKED  N AADOPT  L EPALED","CRISPH   OIRKEDE   IFLORA","T D NH E YU I MM G PBENCH","  S FJUNTA  O D  U EFETID","PEONS  W OADIEU  N PBOGUS","BRIER A  O B  B B  EFIEND","FLUFF O  RACUTE A  EFLOUR","AMOURN   ETONGSI   ECOURT","TOWNS  A ISEVEN  E ETHROW"," D  CPEARL M  I U  CTRICK","ALTOS  W HKHAKI  I NLENDS","TRAILR G UA I CM N KPIGMY","SAUCY D  ARIVER E  DMULES","S V CP I OE T OR A LMOLES","S S BT H LA A UM R EPAPER","  S V  P ECAIRN  R TWEEDS"," S  C H  OMANGO W  EPLEAD","K A PI D ON I ID E NADULT"," A  HIGLOO R  N E  EREPLY","RELIC N  L T  A E  SPROWS","WHIRL A  O V  B E  BENVOY","ABOUT R  RPATIO W  UUNCUT","A   SBIGOTY   ES   ESTRIP","TOPIC  U IJUROR  E CLARVA","G G FR A LO M UW M KSPAKE","S G IT I RAUDION D NDRYLY","L C FA H LKHAKIE F NSPENT","  R HPLAZA  B R  B EOPIUM","G N AEYINGE E ES C NEXERT","A N BDWELLO V UB E SEARTH","STAFFT L OEMAILE R ILIMBO","A S MCAMEOI O DD K ESTEAM","PLUMBI   IPLUMBE   LSCENE","OWNED  O ISPOOR  K TUNSAY","GROUPO   RN   ON   SAMPLY"," C  HDRAKE I  R E  OARSON","SUCKST L OO A LR S IMOPED","G T VALIBIV B CE I ELEAPS","G G RR U EAMAZES N KPLOTS","USING    OAUDIO    DSOOTY","S   UTENORE   GM   ESKIES","R U SEASELA H AL E VMERGE","CLAIM  N EKINDA  U NINLET","SWOOPT   OOTTERR   EMOPED","S K BC H LA A UN K FSNIFF","TUSKSR   HAMUSES   LHAZEL","PLOTS A  MCREDO C  CSHEIK","CRUMBR S EU H AM E UBORAX","B L QADIEUS V EE E ERARER","B A EOLDENA I DR E OSQUAW","VALES    WIGLOO    RAMEND","A R BGLAREA D GT I AEDICT","REBUTO   ROUTDOF   TSHUNS","BOOSTR L RI D IE E AFINED","BRAVO A  TSTRUT I  EPOSER","SHEAF    OBAYOU    NCAKED","FRANC    LBAYOU    CCREAK","  G HKHAKI  Y L  E TCORNS","OFFER U  EANGLE G  DPITHY","STING O  RARENA S  PCONCH","C R SLOATHA D AW I KSPIKE","Q B EUSUALA R UL L DMAYBE","S W FT H IO E XO L EPIPED","COLON    YCHARM    PRAJAH","OMITSP   PTEMPOI   TCLEFS","REEKS    NVILLA    KMOUSE","STUNG R  RCOCOA O  NSPIED","C G GHELLOU E LR A LNINNY","BELOW  O IJOYED  A OALLOW","FRANC A  O B  L B  ILILAC","BOSOM P  UFEAST R  ECASED","A A WULTRAN T GT I ESOCKS","C L GA I RCOBRAA E NOILED","O G CP I AI V CU E HMINCE","F   PLINGOU   RF   EFUMES","I S LCACHEI O EN U CGIRTH","SALSAH   DRADIIU   EBAYOU","ULTRA    USLING    ERECUR","TYINGW   NAUDION   MGRADE","C P FU O OBOWELI E ITORSO"," N  CSEWER R  O V  NPESKY","STOICA P AGREENE R ASMALL"," B  NRADIO Y  V O  EQUILL","PRISM O  O Y  V A  EGLAND"," A  F D  AFILMS E  TBUMPS","B J GU O AN Y NC E GHIDES","  C F  R EFAUNA  M SORBIT","CAVED U  AODIUM I  EMOLES","GAZERR   OATTICI   KNEEDS"," B  W A  IASPEN I  DFLIES","MOTIFO U EN T TT O UHURLS","HUSKSU W LSNOREK R ESHEEP","C H GU O EBRUINE S USEEMS","SCARFN L EAROMAC F RKITES"," L  CLASSO R  C G  KVERBS"],$n=.88,NS=.12,qi=5,Er=$n,Is=.15,Jc=Er+Is,Qc=qi*Jc+Is,$c=Er+Is*2,jc=.18,PS=.28,US=.18;function $t(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function $l(n,e){const t=new gt;return t.setAttribute("position",new xt(n,3)),t.setIndex(e),t.computeVertexNormals(),t}function wS(){const n=[],e=[],t=[],i=[],s=Qc,r=$c,o=jc,c=o+PS,d=US;$t(n,e,[0,o,0],[s,o,0],[s,o,r],[0,o,r]),$t(t,i,[0,0,0],[s,0,0],[s,0,r],[0,0,r]),$t(t,i,[s,0,0],[0,0,0],[0,o,0],[s,o,0]),$t(t,i,[0,0,r],[s,0,r],[s,o,r],[0,o,r]),$t(t,i,[0,0,0],[0,0,r],[0,o,r],[0,o,0]),$t(t,i,[s,0,r],[s,0,0],[s,o,0],[s,o,r]),$t(n,e,[0,c,r],[s,c,r],[s,c,r+d],[0,c,r+d]),$t(t,i,[0,0,r],[s,0,r],[s,0,r+d],[0,0,r+d]),$t(t,i,[s,o,r],[0,o,r],[0,c,r],[s,c,r]),$t(t,i,[0,0,r+d],[s,0,r+d],[s,c,r+d],[0,c,r+d]),$t(t,i,[0,0,r],[0,0,r+d],[0,c,r+d],[0,c,r]),$t(t,i,[s,0,r+d],[s,0,r],[s,c,r],[s,c,r+d]);const u=new Ut({color:13421772,side:on}),p=new Ut({color:0,side:on}),a=new At($l(n,e),u);a.geometry.translate(-s/2,0,0);const l=new At($l(t,i),p);l.geometry.translate(-s/2,0,0);const h=new tn;return h.add(a,l),h}function FS(n){const e=n*Jc+Is+Er/2,t=Is+Er/2;return new G(e-Qc/2-.42,jc,t-$c/2+.3)}const eu=DS.split(/\r?\n/).map(n=>n.trim()).filter(Boolean);function BS(){if(ha.length===0)throw new Error("No puzzles available — run build-puzzles first.");const n=[...ha[Math.floor(Math.random()*ha.length)]],e=[];for(let t=0;t<25;t++){const i=n[t];if(i===" ")continue;const s=HS(t);let r=0;for(const o of s)n[o]!==" "&&r++;if(r>2&&(e.push(i),n[t]=" ",e.length===qi))break}for(yS(e);e.length<qi;)Math.random()>.5?e.unshift(" "):e.push(" ");return[...e,...n].join("")}const Pi=[];function HS(n){Pi.length=0;const e=Math.floor(n/5),t=n%5;return t>0&&Pi.push(n-1),t<4&&Pi.push(n+1),e>0&&Pi.push(n-5),e<4&&Pi.push(n+5),Pi}function tu(n){let e=0;const t=BS();for(const i of n._scrabbleTiles)i.isHovered=!1,i.targetGlowing=!1,i.isGlowing=!1,i.slotPos=n.slotPos[e],i.slotQuat=n.slotQuat[e],i.group.position.copy(i.slotPos),i.group.quaternion.copy(i.slotQuat),i.setLetter(t[e++]);Co(n)}function Co(n){const e=new Set,t=n._scrabbleTiles.length;for(let i=0;i<t;i++){const s=n._scrabbleTiles[i];s.targetGlowing=!1,n._scrabbleTiles[i].glowDelay=i*10,s.glyph!==" "&&e.add(i)}for(let i=0;i<5;i++)if(GS(n,i))for(let s=0;s<5;s++){const r=mr(i,s);n._scrabbleTiles[r].targetGlowing=!0,n._scrabbleTiles[r].glowDelay=s*50,e.delete(r)}for(let i=0;i<5;i++)if(VS(n,i))for(let s=0;s<5;s++){const r=mr(s,i);n._scrabbleTiles[r].targetGlowing=!0,n._scrabbleTiles[r].glowDelay=s*50,e.delete(r)}return e.size===0}function mr(n,e){return qi+n*5+e}function GS(n,e){var s;const t=[];for(let r=0;r<5;r++){const o=n._scrabbleTiles[mr(e,r)],c=o===((s=n._focusedTile)==null?void 0:s.tile)?" ":o.glyph;if(c===" ")return!1;t.push(c)}const i=t.join("").toLowerCase();return eu.includes(i)}function VS(n,e){var s;const t=[];for(let r=0;r<5;r++){const o=n._scrabbleTiles[mr(r,e)],c=o===((s=n._focusedTile)==null?void 0:s.tile)?" ":o.glyph;if(c===" ")return!1;t.push(c)}const i=t.join("").toLowerCase();return eu.includes(i)}const Mr="#cccccc",jl=new Qe(0),ec=new Qe(5592405),kS=new Qe(4482696),YS=new Qe(14544639),WS=11184810,nu=0,Ui=[];function zS(n){return Ui.length=0,n<12&&Ui.push(n+4),n>4&&Ui.push(n-4),n%4>0&&Ui.push(n-1),n%4<3&&Ui.push(n+1),Ui}function KS(n){const e=[];let t=15;for(let i=0;i<n;i++){const s=zS(t);e.length>0&&s.includes(e.at(-1).to)&&s.splice(s.indexOf(e.at(-1).to),1);const r=pr(s);e.push({from:r,to:t}),t=r}for(const i of[...e].reverse())e.push({from:i.to,to:i.from});return e}function Ls(n){const e=document.getElementById(n);if(!e)throw new Error(`missing ${n} element`);return e}function XS(n,e,t){return new Promise(i=>{const s=n.getContext("2d"),r=new Image;r.onload=function(){const o=t,c=t;n.width=o,n.height=c,s.fillStyle="white",s.fillRect(0,0,o,c),s.drawImage(r,(o-r.width)/2,(c-r.height)/2),i()},r.src=e})}function qS(n,e=1){const t=n.getContext("2d"),{width:i,height:s}=n,o=t.getImageData(0,0,i,s).data,c=new Uint8ClampedArray(o),d=(u,p)=>(p*i+u)*4;for(let u=0;u<s;u++)for(let p=0;p<i;p++){let a=255;for(let h=-e;h<=e;h++)for(let m=-e;m<=e;m++){const S=p+m,E=u+h;if(S<0||E<0||S>=i||E>=s)continue;const f=o[d(S,E)];f<a&&(a=f)}const l=d(p,u);c[l]=a,c[l+1]=a,c[l+2]=a,c[l+3]=255}t.putImageData(new ImageData(c,i,s),0,0)}function ZS(n,e,t,i,s=0){const r=new Ai(t,t,i,i),o=r.getAttribute("position"),d=n.getContext("2d").getImageData(0,0,n.width,n.height).data;for(let u=0;u<o.count;u++){const p=o.getX(u)/t+.5,a=-o.getY(u)/t+.5,l=Math.round(p*n.width),h=Math.round(a*n.height);d[(h*n.width+l)*4]<100?o.setZ(u,e+s):o.setZ(u,s)}return JS(r)}function JS(n){const e=n.attributes.position,t=n.index;if(!e)throw new Error("PlaneGeometry must have a position attribute.");const i=[-1,0,1],s=[-1,0,1],r=[-1/0,...i,1/0],o=[-1/0,...s,1/0],c=Array.from({length:16},()=>new gt),d=Array.from({length:16},()=>new Map),u=Array.from({length:16},()=>[]),p=Array.from({length:16},()=>[]);function a(h,m){let S=0,E=0;for(;S<4&&h>=r[S+1];)S++;for(;E<4&&m>=o[E+1];)E++;return S>3&&(S=3),E>3&&(E=3),E*4+S}function l(h,m){const S=d[h];if(S.has(m))return S.get(m);const E=u[h].length/3;return u[h].push(e.getX(m),e.getY(m),e.getZ(m)),S.set(m,E),E}if(t)for(let h=0;h<t.count;h+=3){const m=t.getX(h),S=t.getX(h+1),E=t.getX(h+2),f=e.getX(m),T=e.getY(m),A=e.getX(S),I=e.getY(S),D=e.getX(E),O=e.getY(E),C=a((f+A+D)/3,(T+I+O)/3),U=l(C,m),v=l(C,S),R=l(C,E);p[C].push(U,v,R)}else for(let h=0;h<e.count;h+=3){const m=e.getX(h),S=e.getY(h),E=e.getX(h+1),f=e.getY(h+1),T=e.getX(h+2),A=e.getY(h+2),I=a((m+E+T)/3,(S+f+A)/3),D=l(I,h),O=l(I,h+1),C=l(I,h+2);p[I].push(D,O,C)}for(let h=0;h<16;h++){const m=new gt;m.setAttribute("position",new xt(u[h],3)),m.setIndex(p[h]),m.computeVertexNormals(),c[h]=m}return c}const jn=new tn,Ir=new tn;Ir.rotateX(-Math.PI/2);jn.add(Ir);const Do=new At(new Ai(10,10),new Ut({color:Mr}));Do.position.set(0,-.2,0);Do.rotateX(-Math.PI/2+.2);jn.add(Do);const Lr=new Xt;Lr.position.set(-2,5,5);Lr.lookAt(0,-1,0);let iu=!1,er=0;const QS=1e3;function $S(){iu=!0}let da=0,wi=0;const su=200,ru=50,tc=KS(ru),bn=Array.from({length:16},()=>new tn);Ir.add(...bn);const Sr=[],jS=650,e0=4,t0=200,ys="title-canvas",n0="images/title.png";function ho(n){if(iu&&(er=Math.min(1,er+n/QS),Ir.position.y=-er*1,er>=1))return!0;if(wi<1){const{from:e,to:t}=tc[da];if(wi=Math.min(1,wi+n/su),bn[e].position.copy(Sr[e]).lerp(Sr[t],wi),wi>=1){const s=bn[e];bn[e]=bn[t],bn[t]=s,da++,da<tc.length&&(wi=0)}}return!1}function i0(){return XS(Ls(ys),n0,jS)}function s0(){No(Ls(ys),0,Mr,.2)}function r0(){No(Ls(ys),.4,nu)}function a0(){const n=Ls(ys);qS(n,1)}function o0(){const n=Ls(ys);No(n,.3,7829367)}function l0(){Sr.length=0;for(const n of bn){const t=n.children[0].geometry.getAttribute("position"),i=t.getX(0),s=t.getY(0),r=t.getZ(0);for(const c of n.children)c.geometry.translate(-i,-s,-r);const o=new G(i,s,r);o.multiplyScalar(1.03),n.position.copy(o),Sr.push(o)}bn[15].visible=!1;for(let n=0;n<ru;n++)ho(2*su)}function No(n,e,t,i=0){const s=ZS(n,e,e0,t0,i),r=new Ut({color:t});for(let o=0;o<16;o++)bn[o].add(new At(s[o],r))}Hn("title-image",i0);Hn("title-base-layer",s0);Hn("title-side-layer",r0);for(let n=0;n<10;n++)Hn(`title-dilate-${n}`,a0);Hn("title-top-layer",o0);Hn("title-finalize",l0);const nc={type:"change"},Po={type:"start"},au={type:"end"},tr=new vo,ic=new On,c0=Math.cos(70*Ah.DEG2RAD),Rt=new G,Ht=2*Math.PI,rt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},fa=1e-6;class u0 extends Fd{constructor(e,t=null){super(e,t),this.state=rt.NONE,this.target=new G,this.cursor=new G,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Hi.ROTATE,MIDDLE:Hi.DOLLY,RIGHT:Hi.PAN},this.touches={ONE:Fi.ROTATE,TWO:Fi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new G,this._lastQuaternion=new wn,this._lastTargetPosition=new G,this._quat=new wn().setFromUnitVectors(e.up,new G(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new gl,this._sphericalDelta=new gl,this._scale=1,this._panOffset=new G,this._rotateStart=new oe,this._rotateEnd=new oe,this._rotateDelta=new oe,this._panStart=new oe,this._panEnd=new oe,this._panDelta=new oe,this._dollyStart=new oe,this._dollyEnd=new oe,this._dollyDelta=new oe,this._dollyDirection=new G,this._mouse=new oe,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=d0.bind(this),this._onPointerDown=h0.bind(this),this._onPointerUp=f0.bind(this),this._onContextMenu=x0.bind(this),this._onMouseWheel=m0.bind(this),this._onKeyDown=S0.bind(this),this._onTouchStart=A0.bind(this),this._onTouchMove=_0.bind(this),this._onMouseDown=p0.bind(this),this._onMouseMove=E0.bind(this),this._interceptControlDown=g0.bind(this),this._interceptControlUp=T0.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(nc),this.update(),this.state=rt.NONE}update(e=null){const t=this.object.position;Rt.copy(t).sub(this.target),Rt.applyQuaternion(this._quat),this._spherical.setFromVector3(Rt),this.autoRotate&&this.state===rt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(i)&&isFinite(s)&&(i<-Math.PI?i+=Ht:i>Math.PI&&(i-=Ht),s<-Math.PI?s+=Ht:s>Math.PI&&(s-=Ht),i<=s?this._spherical.theta=Math.max(i,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+s)/2?Math.max(i,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(Rt.setFromSpherical(this._spherical),Rt.applyQuaternion(this._quatInverse),t.copy(this.target).add(Rt),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const c=Rt.length();o=this._clampDistance(c*this._scale);const d=c-o;this.object.position.addScaledVector(this._dollyDirection,d),this.object.updateMatrixWorld(),r=!!d}else if(this.object.isOrthographicCamera){const c=new G(this._mouse.x,this._mouse.y,0);c.unproject(this.object);const d=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=d!==this.object.zoom;const u=new G(this._mouse.x,this._mouse.y,0);u.unproject(this.object),this.object.position.sub(u).add(c),this.object.updateMatrixWorld(),o=Rt.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(tr.origin.copy(this.object.position),tr.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(tr.direction))<c0?this.object.lookAt(this.target):(ic.setFromNormalAndCoplanarPoint(this.object.up,this.target),tr.intersectPlane(ic,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>fa||8*(1-this._lastQuaternion.dot(this.object.quaternion))>fa||this._lastTargetPosition.distanceToSquared(this.target)>fa?(this.dispatchEvent(nc),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?Ht/60*this.autoRotateSpeed*e:Ht/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){Rt.setFromMatrixColumn(t,0),Rt.multiplyScalar(-e),this._panOffset.add(Rt)}_panUp(e,t){this.screenSpacePanning===!0?Rt.setFromMatrixColumn(t,1):(Rt.setFromMatrixColumn(t,0),Rt.crossVectors(this.object.up,Rt)),Rt.multiplyScalar(e),this._panOffset.add(Rt)}_pan(e,t){const i=this.domElement;if(this.object.isPerspectiveCamera){const s=this.object.position;Rt.copy(s).sub(this.target);let r=Rt.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/i.clientHeight,this.object.matrix),this._panUp(2*t*r/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const i=this.domElement.getBoundingClientRect(),s=e-i.left,r=t-i.top,o=i.width,c=i.height;this._mouse.x=s/o*2-1,this._mouse.y=-(r/c)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._rotateStart.set(i,s)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panStart.set(i,s)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),r=.5*(e.pageY+i.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panEnd.set(i,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,c=(e.pageY+t.y)*.5;this._updateZoomParameters(o,c)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new oe,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,i={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}}function h0(n){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(n.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(n)&&(this._addPointer(n),n.pointerType==="touch"?this._onTouchStart(n):this._onMouseDown(n)))}function d0(n){this.enabled!==!1&&(n.pointerType==="touch"?this._onTouchMove(n):this._onMouseMove(n))}function f0(n){switch(this._removePointer(n),this._pointers.length){case 0:this.domElement.releasePointerCapture(n.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(au),this.state=rt.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function p0(n){let e;switch(n.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Hi.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(n),this.state=rt.DOLLY;break;case Hi.ROTATE:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}break;case Hi.PAN:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Po)}function E0(n){switch(this.state){case rt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(n);break;case rt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(n);break;case rt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(n);break}}function m0(n){this.enabled===!1||this.enableZoom===!1||this.state!==rt.NONE||(n.preventDefault(),this.dispatchEvent(Po),this._handleMouseWheel(this._customWheelEvent(n)),this.dispatchEvent(au))}function S0(n){this.enabled!==!1&&this._handleKeyDown(n)}function A0(n){switch(this._trackPointer(n),this._pointers.length){case 1:switch(this.touches.ONE){case Fi.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(n),this.state=rt.TOUCH_ROTATE;break;case Fi.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(n),this.state=rt.TOUCH_PAN;break;default:this.state=rt.NONE}break;case 2:switch(this.touches.TWO){case Fi.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(n),this.state=rt.TOUCH_DOLLY_PAN;break;case Fi.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(n),this.state=rt.TOUCH_DOLLY_ROTATE;break;default:this.state=rt.NONE}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Po)}function _0(n){switch(this._trackPointer(n),this.state){case rt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(n),this.update();break;case rt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(n),this.update();break;case rt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(n),this.update();break;case rt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(n),this.update();break;default:this.state=rt.NONE}}function x0(n){this.enabled!==!1&&n.preventDefault()}function g0(n){n.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function T0(n){n.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}class ou{constructor(e){fe(this,"_canvas");fe(this,"_renderer");fe(this,"_camera");this.app=e,this._canvas=e._canvas,this._renderer=e._renderer,this._camera=e._camera}}class R0 extends ou{constructor(){super(...arguments);fe(this,"_pix",1);fe(this,"_renderSize",new oe)}onResize(){this._updateCam(this._camera),this._updateCam(this.app._nextCamera),this._updateCam(Lr),this._applyRendererResolution()}_updateCam(t){t.aspect=window.innerWidth/window.innerHeight,t.updateProjectionMatrix()}_applyRendererResolution(){const i=(window.devicePixelRatio||1)/this.app._renderPixelScale;this._pix=i,this._renderer.setPixelRatio(i),this._renderer.setSize(window.innerWidth,window.innerHeight),this._positionControlOverlays()}_positionControlOverlays(){const t=document.getElementById("overlay-canvas"),i=t.getContext("2d");t.width=this._renderSize.x,t.height=this._renderSize.y,i.imageSmoothingEnabled=!1}}const fn=5,pn=1,Dt=.2,lu=.3,v0=.15,En=pn+Dt,ut=fn*En+Dt,ot=lu,Kt=lu-v0;function jt(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function sc(n,e){const t=new gt;return t.setAttribute("position",new xt(n,3)),t.setIndex(e),t.computeVertexNormals(),t}const M0=[],I0=[];function L0(){const n=[],e=[],t=[],i=[],s=-ut/2,r=-ut/2-1;for(let l=0;l<=fn;l++)for(let h=0;h<=fn;h++)M0.push(new G(s+Dt/2+h*(pn+Dt),ot,r+Dt/2+l*(pn+Dt)));const o=[2.5,3.5];I0.push(...o.map(l=>[new G(-3,ot,l),new G(3,ot,l)]));for(let l=0;l<=fn;l++){const h=l*En,m=h+Dt;jt(n,e,[0,ot,h],[ut,ot,h],[ut,ot,m],[0,ot,m])}for(let l=0;l<=fn;l++){const h=l*En,m=h+Dt;for(let S=0;S<fn;S++){const E=S*En+Dt,f=E+pn;jt(n,e,[h,ot,E],[m,ot,E],[m,ot,f],[h,ot,f])}}for(let l=0;l<fn;l++)for(let h=0;h<fn;h++){const m=h*En+Dt,S=m+pn,E=l*En+Dt,f=E+pn;jt(n,e,[m,Kt,E],[S,Kt,E],[S,Kt,f],[m,Kt,f])}jt(t,i,[ut,0,0],[0,0,0],[0,ot,0],[ut,ot,0]),jt(t,i,[0,0,ut],[ut,0,ut],[ut,ot,ut],[0,ot,ut]),jt(t,i,[0,0,0],[0,0,ut],[0,ot,ut],[0,ot,0]),jt(t,i,[ut,0,ut],[ut,0,0],[ut,ot,0],[ut,ot,ut]),jt(t,i,[0,0,0],[ut,0,0],[ut,0,ut],[0,0,ut]);for(let l=0;l<fn;l++)for(let h=0;h<fn;h++){const m=h*En+Dt,S=m+pn,E=l*En+Dt,f=E+pn;jt(t,i,[S,Kt,E],[m,Kt,E],[m,ot,E],[S,ot,E]),jt(t,i,[m,Kt,f],[S,Kt,f],[S,ot,f],[m,ot,f]),jt(t,i,[m,Kt,E],[m,Kt,f],[m,ot,f],[m,ot,E]),jt(t,i,[S,Kt,f],[S,Kt,E],[S,ot,E],[S,ot,f])}const c=new Ut({color:13421772,side:Lt}),d=new Ut({color:0,side:Lt}),u=new At(sc(n,e),c),p=new At(sc(t,i),d),a=new tn;return a.add(u,p),a.position.set(s,0,r),a}function y0(n,e){const t=e*En+Dt+pn/2-$n/2,i=n*En+Dt+pn/2-$n/2;return new G(t,Kt,i)}class cu{constructor(){fe(this,"duration",3e3);fe(this,"hasRenderedScene",!1);fe(this,"shouldSkipTileExit",!1)}getMaskCount(e){return this.getMasks(e).length}initMeshes(e){}updateMeshes(e,t){}cleanupMeshes(e){}}const Es={entrance:new WeakMap,exit:new WeakMap},Ar={entrance:new WeakSet,exit:new WeakSet},O0=new WeakMap,b0=new WeakMap;function yr(n){return n?"exit":"entrance"}function Or(n,e){const t=e==="exit"?b0:O0;let i=t.get(n);return i||(i=[],t.set(n,i)),i}function An(n){return Math.max(0,Math.min(1,n))}function C0(n){const e=An(n.startScanIndex/(n.w*n.h));if(n.activeCompId<0)return e;const t=An(n.bfsReadIndex/Math.max(1,n.bfsQueue.length));return An(e*.85+t*.15)}function D0(n){if(n.phase==="prepare-color")return 0;if(n.phase==="scan-color-mask")return An(n.maskScanIndex/Math.max(1,n.flipped.length)*.45);if(n.phase==="components")return An(.45+C0(n)*.4);if(n.phase==="build-regions"){const e=An(n.buildCompIndex/Math.max(1,n.compBounds.length));return An(.85+e*.15)}return 0}function N0(n){if(Or(n.app,n.kind).length>=100)return 100;const e=Math.max(1,n.flipped.length);if(n.phase==="render")return 1;if(n.phase==="flip")return 2+18*An(n.flipY/Math.max(1,n.h));if(n.phase==="collect-colors")return 20+15*An(n.colorScanIndex/e);if(n.phase==="done")return 100;const t=Math.max(1,n.colors.length,n.colorSet.size),i=65/t,s=Math.min(n.colorIndex,t)*i,r=D0(n)*i;return An((35+s+r)/100)*100}function P0(n,e){const t=window.innerWidth,i=window.innerHeight;return{app:n,kind:e,w:t,h:i,phase:"render",pixels:new Uint8Array(t*i*4),flipped:new Uint8ClampedArray(t*i*4),flipY:0,colorSet:new Set,colorScanIndex:0,colors:[],colorIndex:0,targetHex:0,filterColor:lt._MASK_FILTER_COLORS[0],maskData:null,md:null,maskScanIndex:0,componentMap:new Int32Array(t*i).fill(-1),compBounds:[],compSamples:[],startScanIndex:0,bfsQueue:[],bfsReadIndex:0,activeCompId:-1,activeBounds:null,buildCompIndex:0,raycaster:new kc,rayNdc:new oe}}function U0(n){const{w:e,h:t}=n;n.targetHex=n.colors[n.colorIndex],n.filterColor=lt._MASK_FILTER_COLORS[n.colorIndex%lt._MASK_FILTER_COLORS.length],n.maskData=new ImageData(e,t),n.md=n.maskData.data,n.maskScanIndex=0,n.componentMap.fill(-1),n.compBounds=[],n.compSamples=[],n.startScanIndex=0,n.bfsQueue.length=0,n.bfsReadIndex=0,n.activeCompId=-1,n.activeBounds=null,n.buildCompIndex=0}function w0(n,e){const{app:t,w:i,h:s,compBounds:r,componentMap:o,md:c,filterColor:d}=n,u=1.5*Math.hypot(i/2,s/2),p=Or(t,n.kind);if(!c)return;const a=r[e],l=a.maxX-a.minX+1,h=a.maxY-a.minY+1;if(l===i&&h===s)return;const m=new OffscreenCanvas(l,h),S=m.getContext("2d"),E=S.createImageData(l,h),f=E.data;for(let C=a.minY;C<=a.maxY;C++)for(let U=a.minX;U<=a.maxX;U++)if(o[C*i+U]===e){const v=((C-a.minY)*l+(U-a.minX))*4,R=(C*i+U)*4;f[v]=c[R],f[v+1]=c[R+1],f[v+2]=c[R+2],f[v+3]=c[R+3]}S.putImageData(E,0,0);const T=new G(0,0,0);let A=0,I=0,D=0,O=0;if(T){const C=T.clone().project(t._nextCamera),U=(C.x+1)/2*i,v=(1-C.y)/2*s;A=a.minX-(U-m.width/2),I=a.minY-(v-m.height/2);const R=(a.minX+a.maxX)/2,P=(a.minY+a.maxY)/2,V=R-i/2,Z=P-s/2;let J=2*Math.hypot(V,Z)+Math.random()*100;J=Math.max(J,u);const $=Math.atan2(Z,V);D=J*Math.cos($),O=J*Math.sin($)}p.length>=100||p.push({filterColor:d,canvas:m,x:a.minX,y:a.minY,worldPos:T,restOffsetX:A,restOffsetY:I,animOffsetX:D,animOffsetY:O,restAngle:-Math.PI+2*Math.random()*Math.PI})}function F0(n){const{app:e,w:t,h:i}=n,s=new ei(t,i);s.texture.colorSpace=Gt,e._renderer.setRenderTarget(s);const r=e._scrabbleTiles.some(o=>o.isVisible);if(r)for(const o of e._allTiles)o.hide();if(jn.visible=!1,e._renderer.render(e._scene,n.kind==="entrance"?e._nextCamera:e._camera),jn.visible=!0,r)for(const o of e._allTiles)o.show();e._renderer.setRenderTarget(null),e._renderer.readRenderTargetPixels(s,0,0,t,i,n.pixels),s.dispose(),n.phase="flip"}function B0(n,e){const{w:t,h:i}=n;for(;n.flipY<i;n.flipY++){const o=(i-1-n.flipY)*t*4,c=n.flipY*t*4;if(n.flipped.set(n.pixels.subarray(o,o+t*4),c),(n.flipY&31)===0&&performance.now()>=e)return!1}const s=document.getElementById("buffer-canvas");s.width=t,s.height=i;const r=Uint8ClampedArray.from(n.flipped);return s.getContext("2d").putImageData(new ImageData(r,t,i),0,0),n.phase="collect-colors",!0}function H0(n,e){for(;n.colorScanIndex<n.flipped.length;n.colorScanIndex+=4)if(!(n.flipped[n.colorScanIndex]>150)&&(n.colorSet.add(n.flipped[n.colorScanIndex]<<16|n.flipped[n.colorScanIndex+1]<<8|n.flipped[n.colorScanIndex+2]),(n.colorScanIndex&4095)===0&&performance.now()>=e))return!1;if(n.colorSet.size>5)throw new Error(`Expected ≤5 unique colors, got ${n.colorSet.size}`);return n.colors=[...n.colorSet],n.colorIndex=0,n.phase="prepare-color",!0}function G0(n,e){const t=n.md;if(!t)throw new Error("maskData not initialized");for(;n.maskScanIndex<n.flipped.length;n.maskScanIndex+=4)if((n.flipped[n.maskScanIndex]<<16|n.flipped[n.maskScanIndex+1]<<8|n.flipped[n.maskScanIndex+2])===n.targetHex&&(t[n.maskScanIndex]=n.flipped[n.maskScanIndex],t[n.maskScanIndex+1]=n.flipped[n.maskScanIndex+1],t[n.maskScanIndex+2]=n.flipped[n.maskScanIndex+2],t[n.maskScanIndex+3]=255),(n.maskScanIndex&4095)===0&&performance.now()>=e)return!1;return n.phase="components",!0}function V0(n,e){const{w:t,h:i}=n,s=n.md,r=n.activeBounds;if(!s)throw new Error("maskData not initialized");if(!r)throw new Error("active component bounds missing");let o=0;for(;n.bfsReadIndex<n.bfsQueue.length;){const u=n.bfsQueue[n.bfsReadIndex++],p=u%t,a=u/t|0;if(p<r.minX&&(r.minX=p),p>r.maxX&&(r.maxX=p),a<r.minY&&(r.minY=a),a>r.maxY&&(r.maxY=a),p>0&&n.componentMap[u-1]===-1&&s[(u-1)*4+3]>0&&(n.componentMap[u-1]=n.activeCompId,n.bfsQueue.push(u-1)),p<t-1&&n.componentMap[u+1]===-1&&s[(u+1)*4+3]>0&&(n.componentMap[u+1]=n.activeCompId,n.bfsQueue.push(u+1)),a>0&&n.componentMap[u-t]===-1&&s[(u-t)*4+3]>0&&(n.componentMap[u-t]=n.activeCompId,n.bfsQueue.push(u-t)),a<i-1&&n.componentMap[u+t]===-1&&s[(u+t)*4+3]>0&&(n.componentMap[u+t]=n.activeCompId,n.bfsQueue.push(u+t)),o++,(o&255)===0&&performance.now()>=e)return!1}const c=[],d=Math.max(1,Math.floor(n.bfsQueue.length/5));for(let u=0;u<n.bfsQueue.length&&c.length<5;u+=d)c.push(n.bfsQueue[u]);return n.compSamples.push(c),n.activeCompId=-1,n.activeBounds=null,n.bfsQueue.length=0,n.bfsReadIndex=0,!0}function k0(n,e){const{w:t,h:i}=n,s=n.md;if(!s)throw new Error("maskData not initialized");let r=-1;for(;n.startScanIndex<t*i;n.startScanIndex++){if(s[n.startScanIndex*4+3]>0&&n.componentMap[n.startScanIndex]===-1){r=n.startScanIndex,n.startScanIndex++;break}if((n.startScanIndex&1023)===0&&performance.now()>=e)return!1}if(r<0)return n.phase="build-regions",!0;const o=n.compBounds.length,c={minX:t,maxX:-1,minY:i,maxY:-1};return n.compBounds.push(c),n.activeCompId=o,n.activeBounds=c,n.bfsQueue.length=0,n.bfsReadIndex=0,n.bfsQueue.push(r),n.componentMap[r]=o,!0}function Y0(n,e){for(;performance.now()<e;){if(n.activeCompId>=0){if(!V0(n,e))return!1;continue}if(!k0(n,e))return!1;if(n.phase==="build-regions")return!0}return!1}function W0(n,e){for(;n.buildCompIndex<n.compBounds.length;){if(performance.now()>=e)return!1;w0(n,n.buildCompIndex),n.buildCompIndex++}return n.colorIndex++,n.phase="prepare-color",!0}function z0(n,e){for(;performance.now()<e;){if(n.phase==="render"){F0(n);continue}if(n.phase==="flip"){if(!B0(n,e))return!1;continue}if(n.phase==="collect-colors"){if(!H0(n,e))return!1;continue}if(n.phase==="prepare-color"){if(n.colorIndex>=n.colors.length){n.phase="done";continue}U0(n),n.phase="scan-color-mask";continue}if(n.phase==="scan-color-mask"){if(!G0(n,e))return!1;continue}if(n.phase==="components"){if(!Y0(n,e))return!1;continue}if(n.phase==="build-regions"){if(!W0(n,e))return!1;continue}if(n.phase==="done")return!0}return n.phase==="done"}function uu(n,e=!1){const t=yr(e);Or(n,t).length=0,Ar[t].delete(n),Es[t].set(n,P0(n,t))}function K0(n,e=5,t=!1){const i=yr(t);if(!Es[i].has(n)){if(Ar[i].has(n))return!0;uu(n,t)}const s=Es[i].get(n);if(!s)return!0;const r=Number.isFinite(e)?Math.max(0,e):Number.POSITIVE_INFINITY,o=performance.now()+r,c=z0(s,o);return c&&(Es[i].delete(n),Ar[i].add(n)),c}function X0(n,e=!1){const t=yr(e);if(Ar[t].has(n))return 100;const i=Es[t].get(n);if(!i)return 0;const s=N0(i);return Math.max(0,Math.min(100,s))}function q0(n,e=!1){return Or(n,yr(e))}class Z0 extends cu{constructor(e){super(),this._isExit=e}begin(e){uu(e,this._isExit)}incremental(e,t=5){return K0(e,t,this._isExit)}getPercentComplete(e){return X0(e,this._isExit)}getMasks(e){return q0(e,this._isExit)}}const rc=["KeyA","ArrowLeft","KeyD","ArrowRight","Space"];class J0 extends ou{constructor(){super(...arguments);fe(this,"_cpDummy",[0,0])}wireUiInput(){const t=this.app._canvas;window.addEventListener("keydown",i=>{rc.includes(i.code)&&this._routeKeyDown(i.code)&&(i.preventDefault(),i.stopPropagation())}),window.addEventListener("keyup",i=>{rc.includes(i.code)&&this._routeKeyUp(i.code)&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousedown",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerDown("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousemove",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerMove("mouse",s[0],s[1])}),t.addEventListener("mouseup",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerUp("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mouseleave",i=>{this._routePointerLeave("mouse")}),t.addEventListener("touchstart",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerDown(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchmove",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerMove(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchend",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerUp(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchcancel",i=>{for(const s of Array.from(i.changedTouches))this._routePointerLeave(s.identifier);i.preventDefault()},{passive:!1})}_toCanvasPoint(t,i){const s=t.getBoundingClientRect();return s.width<=0||s.height<=0?null:(this._cpDummy[0]=(i.clientX-s.left)*(t.width/s.width),this._cpDummy[1]=(i.clientY-s.top)*(t.height/s.height),this._cpDummy)}_routePointerMove(t,i,s){this.app.mouseMove(i,s)}_routeKeyDown(t){return!1}_routeKeyUp(t){return!1}_routePointerDown(t,i,s){return this.app.mouseMove(i,s),this.app.mouseDown(),!1}_routePointerUp(t,i,s){return this.app.mouseUp(),!1}_routePointerLeave(t){this.app.mouseUp(),document.documentElement.style.cursor="default"}}const Q0=Gt;class _r extends bo{constructor(e){super(e),this.defaultDPI=90,this.defaultUnit="px"}load(e,t,i,s){const r=this,o=new Nd(r.manager);o.setPath(r.path),o.setRequestHeader(r.requestHeader),o.setWithCredentials(r.withCredentials),o.load(e,function(c){try{t(r.parse(c))}catch(d){s?s(d):console.error(d),r.manager.itemError(e)}},i,s)}parse(e){const t=this;function i(X,w){if(X.nodeType!==1)return;const M=I(X);let g=!1,K=null;switch(X.nodeName){case"svg":w=m(X,w);break;case"style":r(X);break;case"g":w=m(X,w);break;case"path":w=m(X,w),X.hasAttribute("d")&&(K=s(X));break;case"rect":w=m(X,w),K=d(X);break;case"polygon":w=m(X,w),K=u(X);break;case"polyline":w=m(X,w),K=p(X);break;case"circle":w=m(X,w),K=a(X);break;case"ellipse":w=m(X,w),K=l(X);break;case"line":w=m(X,w),K=h(X);break;case"defs":g=!0;break;case"use":w=m(X,w);const ce=(X.getAttributeNS("http://www.w3.org/1999/xlink","href")||"").substring(1),Ae=X.viewportElement.getElementById(ce);Ae?i(Ae,w):console.warn("SVGLoader: 'use node' references non-existent node id: "+ce);break}K&&(w.fill!==void 0&&w.fill!=="none"&&K.color.setStyle(w.fill,Q0),O(K,Le),V.push(K),K.userData={node:X,style:w});const re=X.childNodes;for(let k=0;k<re.length;k++){const ce=re[k];g&&ce.nodeName!=="style"&&ce.nodeName!=="defs"||i(ce,w)}M&&(J.pop(),J.length>0?Le.copy(J[J.length-1]):Le.identity())}function s(X){const w=new oi,M=new oe,g=new oe,K=new oe;let re=!0,k=!1;const ce=X.getAttribute("d");if(ce===""||ce==="none")return null;const Ae=ce.match(/[a-df-z][^a-df-z]*/ig);for(let ue=0,H=Ae.length;ue<H;ue++){const x=Ae[ue],q=x.charAt(0),Q=x.slice(1).trim();re===!0&&(k=!0,re=!1);let N;switch(q){case"M":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2)M.x=N[y+0],M.y=N[y+1],g.x=M.x,g.y=M.y,y===0?w.moveTo(M.x,M.y):w.lineTo(M.x,M.y),y===0&&K.copy(M);break;case"H":N=E(Q);for(let y=0,ae=N.length;y<ae;y++)M.x=N[y],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"V":N=E(Q);for(let y=0,ae=N.length;y<ae;y++)M.y=N[y],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"L":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2)M.x=N[y+0],M.y=N[y+1],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"C":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=6)w.bezierCurveTo(N[y+0],N[y+1],N[y+2],N[y+3],N[y+4],N[y+5]),g.x=N[y+2],g.y=N[y+3],M.x=N[y+4],M.y=N[y+5],y===0&&k===!0&&K.copy(M);break;case"S":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=4)w.bezierCurveTo(S(M.x,g.x),S(M.y,g.y),N[y+0],N[y+1],N[y+2],N[y+3]),g.x=N[y+0],g.y=N[y+1],M.x=N[y+2],M.y=N[y+3],y===0&&k===!0&&K.copy(M);break;case"Q":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=4)w.quadraticCurveTo(N[y+0],N[y+1],N[y+2],N[y+3]),g.x=N[y+0],g.y=N[y+1],M.x=N[y+2],M.y=N[y+3],y===0&&k===!0&&K.copy(M);break;case"T":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2){const le=S(M.x,g.x),Te=S(M.y,g.y);w.quadraticCurveTo(le,Te,N[y+0],N[y+1]),g.x=le,g.y=Te,M.x=N[y+0],M.y=N[y+1],y===0&&k===!0&&K.copy(M)}break;case"A":N=E(Q,[3,4],7);for(let y=0,ae=N.length;y<ae;y+=7){if(N[y+5]==M.x&&N[y+6]==M.y)continue;const le=M.clone();M.x=N[y+5],M.y=N[y+6],g.x=M.x,g.y=M.y,o(w,N[y],N[y+1],N[y+2],N[y+3],N[y+4],le,M),y===0&&k===!0&&K.copy(M)}break;case"m":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2)M.x+=N[y+0],M.y+=N[y+1],g.x=M.x,g.y=M.y,y===0?w.moveTo(M.x,M.y):w.lineTo(M.x,M.y),y===0&&K.copy(M);break;case"h":N=E(Q);for(let y=0,ae=N.length;y<ae;y++)M.x+=N[y],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"v":N=E(Q);for(let y=0,ae=N.length;y<ae;y++)M.y+=N[y],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"l":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2)M.x+=N[y+0],M.y+=N[y+1],g.x=M.x,g.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&K.copy(M);break;case"c":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=6)w.bezierCurveTo(M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3],M.x+N[y+4],M.y+N[y+5]),g.x=M.x+N[y+2],g.y=M.y+N[y+3],M.x+=N[y+4],M.y+=N[y+5],y===0&&k===!0&&K.copy(M);break;case"s":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=4)w.bezierCurveTo(S(M.x,g.x),S(M.y,g.y),M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3]),g.x=M.x+N[y+0],g.y=M.y+N[y+1],M.x+=N[y+2],M.y+=N[y+3],y===0&&k===!0&&K.copy(M);break;case"q":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=4)w.quadraticCurveTo(M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3]),g.x=M.x+N[y+0],g.y=M.y+N[y+1],M.x+=N[y+2],M.y+=N[y+3],y===0&&k===!0&&K.copy(M);break;case"t":N=E(Q);for(let y=0,ae=N.length;y<ae;y+=2){const le=S(M.x,g.x),Te=S(M.y,g.y);w.quadraticCurveTo(le,Te,M.x+N[y+0],M.y+N[y+1]),g.x=le,g.y=Te,M.x=M.x+N[y+0],M.y=M.y+N[y+1],y===0&&k===!0&&K.copy(M)}break;case"a":N=E(Q,[3,4],7);for(let y=0,ae=N.length;y<ae;y+=7){if(N[y+5]==0&&N[y+6]==0)continue;const le=M.clone();M.x+=N[y+5],M.y+=N[y+6],g.x=M.x,g.y=M.y,o(w,N[y],N[y+1],N[y+2],N[y+3],N[y+4],le,M),y===0&&k===!0&&K.copy(M)}break;case"Z":case"z":w.currentPath.autoClose=!0,w.currentPath.curves.length>0&&(M.copy(K),w.currentPath.currentPoint.copy(M),re=!0);break;default:console.warn(x)}k=!1}return w}function r(X){if(!(!X.sheet||!X.sheet.cssRules||!X.sheet.cssRules.length))for(let w=0;w<X.sheet.cssRules.length;w++){const M=X.sheet.cssRules[w];if(M.type!==1)continue;const g=M.selectorText.split(/,/gm).filter(Boolean).map(K=>K.trim());for(let K=0;K<g.length;K++){const re=Object.fromEntries(Object.entries(M.style).filter(([,k])=>k!==""));Z[g[K]]=Object.assign(Z[g[K]]||{},re)}}}function o(X,w,M,g,K,re,k,ce){if(w==0||M==0){X.lineTo(ce.x,ce.y);return}g=g*Math.PI/180,w=Math.abs(w),M=Math.abs(M);const Ae=(k.x-ce.x)/2,ue=(k.y-ce.y)/2,H=Math.cos(g)*Ae+Math.sin(g)*ue,x=-Math.sin(g)*Ae+Math.cos(g)*ue;let q=w*w,Q=M*M;const N=H*H,y=x*x,ae=N/q+y/Q;if(ae>1){const ge=Math.sqrt(ae);w=ge*w,M=ge*M,q=w*w,Q=M*M}const le=q*y+Q*N,Te=(q*Q-le)/le;let b=Math.sqrt(Math.max(0,Te));K===re&&(b=-b);const _=b*w*x/M,Y=-b*M*H/w,se=Math.cos(g)*_-Math.sin(g)*Y+(k.x+ce.x)/2,de=Math.sin(g)*_+Math.cos(g)*Y+(k.y+ce.y)/2,ne=c(1,0,(H-_)/w,(x-Y)/M),De=c((H-_)/w,(x-Y)/M,(-H-_)/w,(-x-Y)/M)%(Math.PI*2);X.currentPath.absellipse(se,de,w,M,ne,ne+De,re===0,g)}function c(X,w,M,g){const K=X*M+w*g,re=Math.sqrt(X*X+w*w)*Math.sqrt(M*M+g*g);let k=Math.acos(Math.max(-1,Math.min(1,K/re)));return X*g-w*M<0&&(k=-k),k}function d(X){const w=A(X.getAttribute("x")||0),M=A(X.getAttribute("y")||0),g=A(X.getAttribute("rx")||X.getAttribute("ry")||0),K=A(X.getAttribute("ry")||X.getAttribute("rx")||0),re=A(X.getAttribute("width")),k=A(X.getAttribute("height")),ce=1-.551915024494,Ae=new oi;return Ae.moveTo(w+g,M),Ae.lineTo(w+re-g,M),(g!==0||K!==0)&&Ae.bezierCurveTo(w+re-g*ce,M,w+re,M+K*ce,w+re,M+K),Ae.lineTo(w+re,M+k-K),(g!==0||K!==0)&&Ae.bezierCurveTo(w+re,M+k-K*ce,w+re-g*ce,M+k,w+re-g,M+k),Ae.lineTo(w+g,M+k),(g!==0||K!==0)&&Ae.bezierCurveTo(w+g*ce,M+k,w,M+k-K*ce,w,M+k-K),Ae.lineTo(w,M+K),(g!==0||K!==0)&&Ae.bezierCurveTo(w,M+K*ce,w+g*ce,M,w+g,M),Ae}function u(X){function w(re,k,ce){const Ae=A(k),ue=A(ce);K===0?g.moveTo(Ae,ue):g.lineTo(Ae,ue),K++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new oi;let K=0;return X.getAttribute("points").replace(M,w),g.currentPath.autoClose=!0,g}function p(X){function w(re,k,ce){const Ae=A(k),ue=A(ce);K===0?g.moveTo(Ae,ue):g.lineTo(Ae,ue),K++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new oi;let K=0;return X.getAttribute("points").replace(M,w),g.currentPath.autoClose=!1,g}function a(X){const w=A(X.getAttribute("cx")||0),M=A(X.getAttribute("cy")||0),g=A(X.getAttribute("r")||0),K=new fi;K.absarc(w,M,g,0,Math.PI*2);const re=new oi;return re.subPaths.push(K),re}function l(X){const w=A(X.getAttribute("cx")||0),M=A(X.getAttribute("cy")||0),g=A(X.getAttribute("rx")||0),K=A(X.getAttribute("ry")||0),re=new fi;re.absellipse(w,M,g,K,0,Math.PI*2);const k=new oi;return k.subPaths.push(re),k}function h(X){const w=A(X.getAttribute("x1")||0),M=A(X.getAttribute("y1")||0),g=A(X.getAttribute("x2")||0),K=A(X.getAttribute("y2")||0),re=new oi;return re.moveTo(w,M),re.lineTo(g,K),re.currentPath.autoClose=!1,re}function m(X,w){w=Object.assign({},w);let M={};if(X.hasAttribute("class")){const k=X.getAttribute("class").split(/\s/).filter(Boolean).map(ce=>ce.trim());for(let ce=0;ce<k.length;ce++)M=Object.assign(M,Z["."+k[ce]])}X.hasAttribute("id")&&(M=Object.assign(M,Z["#"+X.getAttribute("id")]));function g(k,ce,Ae){Ae===void 0&&(Ae=function(H){return H.startsWith("url")&&console.warn("SVGLoader: url access in attributes is not implemented."),H}),X.hasAttribute(k)&&(w[ce]=Ae(X.getAttribute(k))),M[k]&&(w[ce]=Ae(M[k])),X.style&&X.style[k]!==""&&(w[ce]=Ae(X.style[k]))}function K(k){return Math.max(0,Math.min(1,A(k)))}function re(k){return Math.max(0,A(k))}return g("fill","fill"),g("fill-opacity","fillOpacity",K),g("fill-rule","fillRule"),g("opacity","opacity",K),g("stroke","stroke"),g("stroke-opacity","strokeOpacity",K),g("stroke-width","strokeWidth",re),g("stroke-linejoin","strokeLineJoin"),g("stroke-linecap","strokeLineCap"),g("stroke-miterlimit","strokeMiterLimit",re),g("visibility","visibility"),w}function S(X,w){return X-(w-X)}function E(X,w,M){if(typeof X!="string")throw new TypeError("Invalid input: "+typeof X);const g={WHITESPACE:/[ \t\r\n]/,DIGIT:/[\d]/,SIGN:/[-+]/,POINT:/\./,COMMA:/,/,EXP:/e/i,FLAGS:/[01]/},K=0,re=1,k=2,ce=3;let Ae=K,ue=!0,H="",x="";const q=[];function Q(le,Te,b){const _=new SyntaxError('Unexpected character "'+le+'" at index '+Te+".");throw _.partial=b,_}function N(){H!==""&&(x===""?q.push(Number(H)):q.push(Number(H)*Math.pow(10,Number(x)))),H="",x=""}let y;const ae=X.length;for(let le=0;le<ae;le++){if(y=X[le],Array.isArray(w)&&w.includes(q.length%M)&&g.FLAGS.test(y)){Ae=re,H=y,N();continue}if(Ae===K){if(g.WHITESPACE.test(y))continue;if(g.DIGIT.test(y)||g.SIGN.test(y)){Ae=re,H=y;continue}if(g.POINT.test(y)){Ae=k,H=y;continue}g.COMMA.test(y)&&(ue&&Q(y,le,q),ue=!0)}if(Ae===re){if(g.DIGIT.test(y)){H+=y;continue}if(g.POINT.test(y)){H+=y,Ae=k;continue}if(g.EXP.test(y)){Ae=ce;continue}g.SIGN.test(y)&&H.length===1&&g.SIGN.test(H[0])&&Q(y,le,q)}if(Ae===k){if(g.DIGIT.test(y)){H+=y;continue}if(g.EXP.test(y)){Ae=ce;continue}g.POINT.test(y)&&H[H.length-1]==="."&&Q(y,le,q)}if(Ae===ce){if(g.DIGIT.test(y)){x+=y;continue}if(g.SIGN.test(y)){if(x===""){x+=y;continue}x.length===1&&g.SIGN.test(x)&&Q(y,le,q)}}g.WHITESPACE.test(y)?(N(),Ae=K,ue=!1):g.COMMA.test(y)?(N(),Ae=K,ue=!0):g.SIGN.test(y)?(N(),Ae=re,H=y):g.POINT.test(y)?(N(),Ae=k,H=y):Q(y,le,q)}return N(),q}const f=["mm","cm","in","pt","pc","px"],T={mm:{mm:1,cm:.1,in:1/25.4,pt:72/25.4,pc:6/25.4,px:-1},cm:{mm:10,cm:1,in:1/2.54,pt:72/2.54,pc:6/2.54,px:-1},in:{mm:25.4,cm:2.54,in:1,pt:72,pc:6,px:-1},pt:{mm:25.4/72,cm:2.54/72,in:1/72,pt:1,pc:6/72,px:-1},pc:{mm:25.4/6,cm:2.54/6,in:1/6,pt:72/6,pc:1,px:-1},px:{px:1}};function A(X){let w="px";if(typeof X=="string"||X instanceof String)for(let g=0,K=f.length;g<K;g++){const re=f[g];if(X.endsWith(re)){w=re,X=X.substring(0,X.length-re.length);break}}let M;return w==="px"&&t.defaultUnit!=="px"?M=T.in[t.defaultUnit]/t.defaultDPI:(M=T[w][t.defaultUnit],M<0&&(M=T[w].in*t.defaultDPI)),M*parseFloat(X)}function I(X){if(!(X.hasAttribute("transform")||X.nodeName==="use"&&(X.hasAttribute("x")||X.hasAttribute("y"))))return null;const w=D(X);return J.length>0&&w.premultiply(J[J.length-1]),Le.copy(w),J.push(w),w}function D(X){const w=new Ye,M=$;if(X.nodeName==="use"&&(X.hasAttribute("x")||X.hasAttribute("y"))){const g=A(X.getAttribute("x")||0),K=A(X.getAttribute("y")||0);w.translate(g,K)}if(X.hasAttribute("transform")){const g=X.getAttribute("transform").split(")");for(let K=g.length-1;K>=0;K--){const re=g[K].trim();if(re==="")continue;const k=re.indexOf("("),ce=re.length;if(k>0&&k<ce){const Ae=re.slice(0,k),ue=E(re.slice(k+1));switch(M.identity(),Ae){case"translate":if(ue.length>=1){const H=ue[0];let x=0;ue.length>=2&&(x=ue[1]),M.translate(H,x)}break;case"rotate":if(ue.length>=1){let H=0,x=0,q=0;H=ue[0]*Math.PI/180,ue.length>=3&&(x=ue[1],q=ue[2]),ie.makeTranslation(-x,-q),j.makeRotation(H),B.multiplyMatrices(j,ie),ie.makeTranslation(x,q),M.multiplyMatrices(ie,B)}break;case"scale":if(ue.length>=1){const H=ue[0];let x=H;ue.length>=2&&(x=ue[1]),M.scale(H,x)}break;case"skewX":ue.length===1&&M.set(1,Math.tan(ue[0]*Math.PI/180),0,0,1,0,0,0,1);break;case"skewY":ue.length===1&&M.set(1,0,0,Math.tan(ue[0]*Math.PI/180),1,0,0,0,1);break;case"matrix":ue.length===6&&M.set(ue[0],ue[2],ue[4],ue[1],ue[3],ue[5],0,0,1);break}}w.premultiply(M)}}return w}function O(X,w){function M(k){Ee.set(k.x,k.y,1).applyMatrix3(w),k.set(Ee.x,Ee.y)}function g(k){const ce=k.xRadius,Ae=k.yRadius,ue=Math.cos(k.aRotation),H=Math.sin(k.aRotation),x=new G(ce*ue,ce*H,0),q=new G(-Ae*H,Ae*ue,0),Q=x.applyMatrix3(w),N=q.applyMatrix3(w),y=$.set(Q.x,N.x,0,Q.y,N.y,0,0,0,1),ae=ie.copy(y).invert(),b=j.copy(ae).transpose().multiply(ae).elements,_=P(b[0],b[1],b[4]),Y=Math.sqrt(_.rt1),se=Math.sqrt(_.rt2);if(k.xRadius=1/Y,k.yRadius=1/se,k.aRotation=Math.atan2(_.sn,_.cs),!((k.aEndAngle-k.aStartAngle)%(2*Math.PI)<Number.EPSILON)){const ne=ie.set(Y,0,0,0,se,0,0,0,1),De=j.set(_.cs,_.sn,0,-_.sn,_.cs,0,0,0,1),ge=ne.multiply(De).multiply(y),Ue=Ce=>{const{x:me,y:_e}=new G(Math.cos(Ce),Math.sin(Ce),0).applyMatrix3(ge);return Math.atan2(_e,me)};k.aStartAngle=Ue(k.aStartAngle),k.aEndAngle=Ue(k.aEndAngle),C(w)&&(k.aClockwise=!k.aClockwise)}}function K(k){const ce=v(w),Ae=R(w);k.xRadius*=ce,k.yRadius*=Ae;const ue=ce>Number.EPSILON?Math.atan2(w.elements[1],w.elements[0]):Math.atan2(-w.elements[3],w.elements[4]);k.aRotation+=ue,C(w)&&(k.aStartAngle*=-1,k.aEndAngle*=-1,k.aClockwise=!k.aClockwise)}const re=X.subPaths;for(let k=0,ce=re.length;k<ce;k++){const ue=re[k].curves;for(let H=0;H<ue.length;H++){const x=ue[H];x.isLineCurve?(M(x.v1),M(x.v2)):x.isCubicBezierCurve?(M(x.v0),M(x.v1),M(x.v2),M(x.v3)):x.isQuadraticBezierCurve?(M(x.v0),M(x.v1),M(x.v2)):x.isEllipseCurve&&(pe.set(x.aX,x.aY),M(pe),x.aX=pe.x,x.aY=pe.y,U(w)?g(x):K(x))}}}function C(X){const w=X.elements;return w[0]*w[4]-w[1]*w[3]<0}function U(X){const w=X.elements,M=w[0]*w[3]+w[1]*w[4];if(M===0)return!1;const g=v(X),K=R(X);return Math.abs(M/(g*K))>Number.EPSILON}function v(X){const w=X.elements;return Math.sqrt(w[0]*w[0]+w[1]*w[1])}function R(X){const w=X.elements;return Math.sqrt(w[3]*w[3]+w[4]*w[4])}function P(X,w,M){let g,K,re,k,ce;const Ae=X+M,ue=X-M,H=Math.sqrt(ue*ue+4*w*w);return Ae>0?(g=.5*(Ae+H),ce=1/g,K=X*ce*M-w*ce*w):Ae<0?K=.5*(Ae-H):(g=.5*H,K=-.5*H),ue>0?re=ue+H:re=ue-H,Math.abs(re)>2*Math.abs(w)?(ce=-2*w/re,k=1/Math.sqrt(1+ce*ce),re=ce*k):Math.abs(w)===0?(re=1,k=0):(ce=-.5*re/w,re=1/Math.sqrt(1+ce*ce),k=ce*re),ue>0&&(ce=re,re=-k,k=ce),{rt1:g,rt2:K,cs:re,sn:k}}const V=[],Z={},J=[],$=new Ye,ie=new Ye,j=new Ye,B=new Ye,pe=new oe,Ee=new G,Le=new Ye,Ve=new DOMParser().parseFromString(e,"image/svg+xml");return i(Ve.documentElement,{fill:"#000",fillOpacity:1,strokeOpacity:1,strokeWidth:1,strokeLineJoin:"miter",strokeLineCap:"butt",strokeMiterLimit:4}),{paths:V,xml:Ve.documentElement}}static createShapes(e){const i={ORIGIN:0,DESTINATION:1,BETWEEN:2,LEFT:3,RIGHT:4,BEHIND:5,BEYOND:6},s={loc:i.ORIGIN,t:0};function r(S,E,f,T){const A=S.x,I=E.x,D=f.x,O=T.x,C=S.y,U=E.y,v=f.y,R=T.y,P=(O-D)*(C-v)-(R-v)*(A-D),V=(I-A)*(C-v)-(U-C)*(A-D),Z=(R-v)*(I-A)-(O-D)*(U-C),J=P/Z,$=V/Z;if(Z===0&&P!==0||J<=0||J>=1||$<0||$>1)return null;if(P===0&&Z===0){for(let ie=0;ie<2;ie++)if(o(ie===0?f:T,S,E),s.loc==i.ORIGIN){const j=ie===0?f:T;return{x:j.x,y:j.y,t:s.t}}else if(s.loc==i.BETWEEN){const j=+(A+s.t*(I-A)).toPrecision(10),B=+(C+s.t*(U-C)).toPrecision(10);return{x:j,y:B,t:s.t}}return null}else{for(let B=0;B<2;B++)if(o(B===0?f:T,S,E),s.loc==i.ORIGIN){const pe=B===0?f:T;return{x:pe.x,y:pe.y,t:s.t}}const ie=+(A+J*(I-A)).toPrecision(10),j=+(C+J*(U-C)).toPrecision(10);return{x:ie,y:j,t:J}}}function o(S,E,f){const T=f.x-E.x,A=f.y-E.y,I=S.x-E.x,D=S.y-E.y,O=T*D-I*A;if(S.x===E.x&&S.y===E.y){s.loc=i.ORIGIN,s.t=0;return}if(S.x===f.x&&S.y===f.y){s.loc=i.DESTINATION,s.t=1;return}if(O<-Number.EPSILON){s.loc=i.LEFT;return}if(O>Number.EPSILON){s.loc=i.RIGHT;return}if(T*I<0||A*D<0){s.loc=i.BEHIND;return}if(Math.sqrt(T*T+A*A)<Math.sqrt(I*I+D*D)){s.loc=i.BEYOND;return}let C;T!==0?C=I/T:C=D/A,s.loc=i.BETWEEN,s.t=C}function c(S,E){const f=[],T=[];for(let A=1;A<S.length;A++){const I=S[A-1],D=S[A];for(let O=1;O<E.length;O++){const C=E[O-1],U=E[O],v=r(I,D,C,U);v!==null&&f.find(R=>R.t<=v.t+Number.EPSILON&&R.t>=v.t-Number.EPSILON)===void 0&&(f.push(v),T.push(new oe(v.x,v.y)))}}return T}function d(S,E,f){const T=new oe;E.getCenter(T);const A=[];return f.forEach(I=>{I.boundingBox.containsPoint(T)&&c(S,I.points).forEach(O=>{A.push({identifier:I.identifier,isCW:I.isCW,point:O})})}),A.sort((I,D)=>I.point.x-D.point.x),A}function u(S,E,f,T,A){(A==null||A==="")&&(A="nonzero");const I=new oe;S.boundingBox.getCenter(I);const D=[new oe(f,I.y),new oe(T,I.y)],O=d(D,S.boundingBox,E);O.sort((V,Z)=>V.point.x-Z.point.x);const C=[],U=[];O.forEach(V=>{V.identifier===S.identifier?C.push(V):U.push(V)});const v=C[0].point.x,R=[];let P=0;for(;P<U.length&&U[P].point.x<v;)R.length>0&&R[R.length-1]===U[P].identifier?R.pop():R.push(U[P].identifier),P++;if(R.push(S.identifier),A==="evenodd"){const V=R.length%2===0,Z=R[R.length-2];return{identifier:S.identifier,isHole:V,for:Z}}else if(A==="nonzero"){let V=!0,Z=null,J=null;for(let $=0;$<R.length;$++){const ie=R[$];V?(J=E[ie].isCW,V=!1,Z=ie):J!==E[ie].isCW&&(J=E[ie].isCW,V=!0)}return{identifier:S.identifier,isHole:V,for:Z}}else console.warn('fill-rule: "'+A+'" is currently not implemented.')}let p=999999999,a=-999999999,l=e.subPaths.map(S=>{const E=S.getPoints();let f=-999999999,T=999999999,A=-999999999,I=999999999;for(let D=0;D<E.length;D++){const O=E[D];O.y>f&&(f=O.y),O.y<T&&(T=O.y),O.x>A&&(A=O.x),O.x<I&&(I=O.x)}return a<=A&&(a=A+1),p>=I&&(p=I-1),{curves:S.curves,points:E,isCW:un.isClockWise(E),identifier:-1,boundingBox:new wd(new oe(I,T),new oe(A,f))}});l=l.filter(S=>S.points.length>1);for(let S=0;S<l.length;S++)l[S].identifier=S;const h=l.map(S=>u(S,l,p,a,e.userData?e.userData.style.fillRule:void 0)),m=[];return l.forEach(S=>{if(!h[S.identifier].isHole){const f=new Qn;f.curves=S.curves,h.filter(A=>A.isHole&&A.for===S.identifier).forEach(A=>{const I=l[A.identifier],D=new fi;D.curves=I.curves,f.holes.push(D)}),m.push(f)}}),m}static getStrokeStyle(e,t,i,s,r){return e=e!==void 0?e:1,t=t!==void 0?t:"#000",i=i!==void 0?i:"miter",s=s!==void 0?s:"butt",r=r!==void 0?r:4,{strokeColor:t,strokeWidth:e,strokeLineJoin:i,strokeLineCap:s,strokeMiterLimit:r}}static pointsToStroke(e,t,i,s){const r=[],o=[],c=[];if(_r.pointsToStrokeWithBuffers(e,t,i,s,r,o,c)===0)return null;const d=new gt;return d.setAttribute("position",new xt(r,3)),d.setAttribute("normal",new xt(o,3)),d.setAttribute("uv",new xt(c,2)),d}static pointsToStrokeWithBuffers(e,t,i,s,r,o,c,d){const u=new oe,p=new oe,a=new oe,l=new oe,h=new oe,m=new oe,S=new oe,E=new oe,f=new oe,T=new oe,A=new oe,I=new oe,D=new oe,O=new oe,C=new oe,U=new oe,v=new oe;i=i!==void 0?i:12,s=s!==void 0?s:.001,d=d!==void 0?d:0,e=ue(e);const R=e.length;if(R<2)return 0;const P=e[0].equals(e[R-1]);let V,Z=e[0],J;const $=t.strokeWidth/2,ie=1/(R-1);let j=0,B,pe,Ee,Le,Ve=!1,Xe=0,X=d*3,w=d*2;M(e[0],e[1],u).multiplyScalar($),E.copy(e[0]).sub(u),f.copy(e[0]).add(u),T.copy(E),A.copy(f);for(let H=1;H<R;H++){V=e[H],H===R-1?P?J=e[1]:J=void 0:J=e[H+1];const x=u;if(M(Z,V,x),a.copy(x).multiplyScalar($),I.copy(V).sub(a),D.copy(V).add(a),B=j+ie,pe=!1,J!==void 0){M(V,J,p),a.copy(p).multiplyScalar($),O.copy(V).sub(a),C.copy(V).add(a),Ee=!0,a.subVectors(J,Z),x.dot(a)<0&&(Ee=!1),H===1&&(Ve=Ee),a.subVectors(J,V),a.normalize();const q=Math.abs(x.dot(a));if(q>Number.EPSILON){const Q=$/q;a.multiplyScalar(-Q),l.subVectors(V,Z),h.copy(l).setLength(Q).add(a),U.copy(h).negate();const N=h.length(),y=l.length();l.divideScalar(y),m.subVectors(J,V);const ae=m.length();switch(m.divideScalar(ae),l.dot(U)<y&&m.dot(U)<ae&&(pe=!0),v.copy(h).add(V),U.add(V),Le=!1,pe?Ee?(C.copy(U),D.copy(U)):(O.copy(U),I.copy(U)):re(),t.strokeLineJoin){case"bevel":k(Ee,pe,B);break;case"round":ce(Ee,pe),Ee?K(V,I,O,B,0):K(V,C,D,B,1);break;case"miter":case"miter-clip":default:const le=$*t.strokeMiterLimit/N;if(le<1)if(t.strokeLineJoin!=="miter-clip"){k(Ee,pe,B);break}else ce(Ee,pe),Ee?(m.subVectors(v,I).multiplyScalar(le).add(I),S.subVectors(v,O).multiplyScalar(le).add(O),g(I,B,0),g(m,B,0),g(V,B,.5),g(V,B,.5),g(m,B,0),g(S,B,0),g(V,B,.5),g(S,B,0),g(O,B,0)):(m.subVectors(v,D).multiplyScalar(le).add(D),S.subVectors(v,C).multiplyScalar(le).add(C),g(D,B,1),g(m,B,1),g(V,B,.5),g(V,B,.5),g(m,B,1),g(S,B,1),g(V,B,.5),g(S,B,1),g(C,B,1));else pe?(Ee?(g(f,j,1),g(E,j,0),g(v,B,0),g(f,j,1),g(v,B,0),g(U,B,1)):(g(f,j,1),g(E,j,0),g(v,B,1),g(E,j,0),g(U,B,0),g(v,B,1)),Ee?O.copy(v):C.copy(v)):Ee?(g(I,B,0),g(v,B,0),g(V,B,.5),g(V,B,.5),g(v,B,0),g(O,B,0)):(g(D,B,1),g(v,B,1),g(V,B,.5),g(V,B,.5),g(v,B,1),g(C,B,1)),Le=!0;break}}else re()}else re();!P&&H===R-1&&Ae(e[0],T,A,Ee,!0,j),j=B,Z=V,E.copy(O),f.copy(C)}if(!P)Ae(V,I,D,Ee,!1,B);else if(pe&&r){let H=v,x=U;Ve!==Ee&&(H=U,x=v),Ee?(Le||Ve)&&(x.toArray(r,0),x.toArray(r,9),Le&&H.toArray(r,3)):(Le||!Ve)&&(x.toArray(r,3),x.toArray(r,9),Le&&H.toArray(r,0))}return Xe;function M(H,x,q){return q.subVectors(x,H),q.set(-q.y,q.x).normalize()}function g(H,x,q){r&&(r[X]=H.x,r[X+1]=H.y,r[X+2]=0,o&&(o[X]=0,o[X+1]=0,o[X+2]=1),X+=3,c&&(c[w]=x,c[w+1]=q,w+=2)),Xe+=3}function K(H,x,q,Q,N){u.copy(x).sub(H).normalize(),p.copy(q).sub(H).normalize();let y=Math.PI;const ae=u.dot(p);Math.abs(ae)<1&&(y=Math.abs(Math.acos(ae))),y/=i,a.copy(x);for(let le=0,Te=i-1;le<Te;le++)l.copy(a).rotateAround(H,y),g(a,Q,N),g(l,Q,N),g(H,Q,.5),a.copy(l);g(l,Q,N),g(q,Q,N),g(H,Q,.5)}function re(){g(f,j,1),g(E,j,0),g(I,B,0),g(f,j,1),g(I,B,0),g(D,B,1)}function k(H,x,q){x?H?(g(f,j,1),g(E,j,0),g(I,B,0),g(f,j,1),g(I,B,0),g(U,B,1),g(I,q,0),g(O,q,0),g(U,q,.5)):(g(f,j,1),g(E,j,0),g(D,B,1),g(E,j,0),g(U,B,0),g(D,B,1),g(D,q,1),g(U,q,0),g(C,q,1)):H?(g(I,q,0),g(O,q,0),g(V,q,.5)):(g(D,q,1),g(C,q,0),g(V,q,.5))}function ce(H,x){x&&(H?(g(f,j,1),g(E,j,0),g(I,B,0),g(f,j,1),g(I,B,0),g(U,B,1),g(I,j,0),g(V,B,.5),g(U,B,1),g(V,B,.5),g(O,j,0),g(U,B,1)):(g(f,j,1),g(E,j,0),g(D,B,1),g(E,j,0),g(U,B,0),g(D,B,1),g(D,j,1),g(U,B,0),g(V,B,.5),g(V,B,.5),g(U,B,0),g(C,j,1)))}function Ae(H,x,q,Q,N,y){switch(t.strokeLineCap){case"round":N?K(H,q,x,y,.5):K(H,x,q,y,.5);break;case"square":if(N)u.subVectors(x,H),p.set(u.y,-u.x),a.addVectors(u,p).add(H),l.subVectors(p,u).add(H),Q?(a.toArray(r,3),l.toArray(r,0),l.toArray(r,9)):(a.toArray(r,3),c[7]===1?l.toArray(r,9):a.toArray(r,9),l.toArray(r,0));else{u.subVectors(q,H),p.set(u.y,-u.x),a.addVectors(u,p).add(H),l.subVectors(p,u).add(H);const ae=r.length;Q?(a.toArray(r,ae-3),l.toArray(r,ae-6),l.toArray(r,ae-12)):(l.toArray(r,ae-6),a.toArray(r,ae-3),l.toArray(r,ae-12))}break}}function ue(H){let x=!1;for(let Q=1,N=H.length-1;Q<N;Q++)if(H[Q].distanceTo(H[Q+1])<s){x=!0;break}if(!x)return H;const q=[];q.push(H[0]);for(let Q=1,N=H.length-1;Q<N;Q++)H[Q].distanceTo(H[Q+1])>=s&&q.push(H[Q]);return q.push(H[H.length-1]),q}}}function $0(n,e=!1){const t=n[0].index!==null,i=new Set(Object.keys(n[0].attributes)),s=new Set(Object.keys(n[0].morphAttributes)),r={},o={},c=n[0].morphTargetsRelative,d=new gt;let u=0;for(let p=0;p<n.length;++p){const a=n[p];let l=0;if(t!==(a.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const h in a.attributes){if(!i.has(h))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+'. All geometries must have compatible attributes; make sure "'+h+'" attribute exists among all geometries, or in none of them.'),null;r[h]===void 0&&(r[h]=[]),r[h].push(a.attributes[h]),l++}if(l!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". Make sure all geometries have the same number of attributes."),null;if(c!==a.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const h in a.morphAttributes){if(!s.has(h))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+".  .morphAttributes must be consistent throughout all geometries."),null;o[h]===void 0&&(o[h]=[]),o[h].push(a.morphAttributes[h])}if(e){let h;if(t)h=a.index.count;else if(a.attributes.position!==void 0)h=a.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". The geometry must have either an index or a position attribute"),null;d.addGroup(u,h,p),u+=h}}if(t){let p=0;const a=[];for(let l=0;l<n.length;++l){const h=n[l].index;for(let m=0;m<h.count;++m)a.push(h.getX(m)+p);p+=n[l].attributes.position.count}d.setIndex(a)}for(const p in r){const a=ac(r[p]);if(!a)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" attribute."),null;d.setAttribute(p,a)}for(const p in o){const a=o[p][0].length;if(a===0)break;d.morphAttributes=d.morphAttributes||{},d.morphAttributes[p]=[];for(let l=0;l<a;++l){const h=[];for(let S=0;S<o[p].length;++S)h.push(o[p][S][l]);const m=ac(h);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" morphAttribute."),null;d.morphAttributes[p].push(m)}}return d}function ac(n){let e,t,i,s=-1,r=0;for(let u=0;u<n.length;++u){const p=n[u];if(e===void 0&&(e=p.array.constructor),e!==p.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=p.itemSize),t!==p.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=p.normalized),i!==p.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=p.gpuType),s!==p.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=p.count*t}const o=new e(r),c=new hn(o,t,i);let d=0;for(let u=0;u<n.length;++u){const p=n[u];if(p.isInterleavedBufferAttribute){const a=d/t;for(let l=0,h=p.count;l<h;l++)for(let m=0;m<t;m++){const S=p.getComponent(l,m);c.setComponent(l+a,m,S)}}else o.set(p.array,d);d+=p.count*t}return s!==void 0&&(c.gpuType=s),c}const j0={A:{horizAdvX:1325,d:"M1108 0l-162 435h-573l-160 -435h-213l558 1468h210l555 -1468h-215zM889 613l-154 431q-7 22 -21.5 66t-29 91t-23.5 78q-10 -41 -23 -86.5t-25.5 -85t-20.5 -63.5l-156 -431h453z"},B:{horizAdvX:1336,d:"M196 1462h424q279 0 420 -82t141 -281q0 -85 -31 -152t-90 -111t-145 -60v-10q90 -15 160 -54t110.5 -110.5t40.5 -183.5q0 -134 -63 -227.5t-178.5 -142t-274.5 -48.5h-514v1462zM401 847h255q177 0 245 58t68 169q0 115 -81 165.5t-257 50.5h-230v-443zM401 678v-505 h279q181 0 255.5 71t74.5 191q0 76 -33.5 130.5t-108.5 83.5t-202 29h-265z"},C:{horizAdvX:1294,d:"M820 1306q-113 0 -202.5 -39.5t-151.5 -115t-95 -181.5t-33 -239q0 -177 52.5 -306t158.5 -199t267 -70q96 0 183.5 17.5t174.5 45.5v-176q-84 -32 -173.5 -47.5t-209.5 -15.5q-224 0 -372.5 93t-221.5 261.5t-73 397.5q0 166 46 303.5t135 238t218.5 155t298.5 54.5 q110 0 214.5 -23.5t192.5 -65.5l-76 -171q-73 33 -156.5 58t-176.5 25z"},D:{horizAdvX:1494,d:"M1370 745q0 -247 -91 -412.5t-263.5 -249t-418.5 -83.5h-401v1462h446q224 0 387 -81.5t252 -241t89 -394.5zM1155 739q0 188 -61 310t-179 181.5t-289 59.5h-225v-1116h189q283 0 424 142t141 423z"},E:{horizAdvX:1140,d:"M1017 0h-821v1462h821v-176h-616v-435h579v-174h-579v-500h616v-177z"},F:{horizAdvX:1074,d:"M400 0h-204v1462h820v-176h-616v-496h578v-175h-578v-615z"},G:{horizAdvX:1488,d:"M804 780h528v-721q-115 -39 -237 -59t-274 -20q-226 0 -381 90t-235.5 258t-80.5 404q0 227 89 396t259 262t410 93q120 0 230.5 -23t203.5 -64l-74 -173q-78 35 -172.5 59.5t-195.5 24.5q-168 0 -288.5 -71t-185 -200t-64.5 -306q0 -173 54 -302t169 -201t296 -72 q91 0 155.5 10t118.5 24v412h-325v179z"},H:{horizAdvX:1524,d:"M1327 0h-205v675h-721v-675h-205v1462h205v-610h721v610h205v-1462z"},I:{horizAdvX:599,d:"M196 0v1462h205v-1462h-205z"},J:{horizAdvX:582,d:"M0 -396q-53 0 -93 7t-68 18v173q32 -9 69 -15t79 -6q56 0 102 22t73 76t27 150v1433h206v-1423q0 -149 -48.5 -245.5t-137.5 -143t-209 -46.5z"},K:{horizAdvX:1281,d:"M1281 0h-239l-491 687l-150 -128v-559h-205v1462h205v-714q51 60 103.5 119t104.5 119l419 476h235l-564 -637z"},L:{horizAdvX:1091,d:"M196 0v1462h205v-1284h635v-178h-840z"},M:{horizAdvX:1864,d:"M833 0l-456 1257h-8q3 -41 6.5 -105.5t6 -140t2.5 -148.5v-863h-188v1462h295l433 -1191h7l444 1191h293v-1462h-198v875q0 66 2 137.5t5.5 136t6.5 106.5h-9l-467 -1255h-175z"},N:{horizAdvX:1573,d:"M1378 0h-246l-757 1198h-8q3 -54 7 -118.5t6.5 -135t3.5 -142.5v-802h-188v1462h244l754 -1192h7q-2 44 -5 109t-5.5 137.5t-2.5 137.5v808h190v-1462z"},O:{horizAdvX:1602,d:"M1479 733q0 -169 -43 -307.5t-127.5 -238t-211 -153.5t-295.5 -54q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5t152 -200t261.5 -70.5q161 0 263 70.5 t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},P:{horizAdvX:1246,d:"M599 1462q283 0 413.5 -113t130.5 -321q0 -94 -30 -178.5t-97.5 -149t-177.5 -102t-270 -37.5h-167v-561h-205v1462h403zM583 1290h-182v-556h145q127 0 213 28.5t130 91.5t44 166q0 136 -85 203t-265 67z"},Q:{horizAdvX:1602,d:"M1479 733q0 -176 -46.5 -319t-139 -243.5t-230.5 -149.5l346 -369h-282l-279 330q-12 0 -23 -1t-23 -1q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5 t152 -200t261.5 -70.5q161 0 263 70.5t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},R:{horizAdvX:1286,d:"M599 1462q185 0 305.5 -45.5t179.5 -138t59 -234.5q0 -112 -41 -189t-107.5 -126t-142.5 -77l409 -652h-235l-356 598h-269v-598h-205v1462h403zM586 1288h-185v-519h199q173 0 253 67.5t80 199.5q0 137 -85 194.5t-262 57.5z"},S:{horizAdvX:1124,d:"M1031 393q0 -130 -64.5 -222.5t-181.5 -141.5t-278 -49q-81 0 -154.5 8.5t-136.5 24.5t-114 40v194q83 -34 192 -63.5t225 -29.5q101 0 169.5 27.5t103.5 77.5t35 120t-34 117.5t-107.5 87.5t-192.5 85q-83 30 -151 68.5t-117.5 88.5t-76.5 117.5t-27 155.5 q0 121 59.5 207t166.5 131.5t248 45.5q116 0 216.5 -23t191.5 -63l-65 -170q-85 35 -171 57t-178 22q-85 0 -143.5 -25t-89 -71t-30.5 -109q0 -71 32 -118t101 -85t180 -81q125 -48 212.5 -102t133.5 -130t46 -192z"},T:{horizAdvX:1143,d:"M674 0h-206v1285h-444v177h1093v-177h-443v-1285z"},U:{horizAdvX:1507,d:"M1323 1462v-946q0 -154 -63.5 -275t-191.5 -191t-322 -70q-275 0 -419.5 147.5t-144.5 392.5v942h206v-934q0 -185 92.5 -279t275.5 -94q126 0 206 45.5t118.5 129t38.5 198.5v934h204z"},V:{horizAdvX:1249,d:"M1249 1462l-518 -1462h-213l-518 1462h212l325 -940q18 -49 34 -103.5t30 -108.5t23 -99q9 45 22.5 99t30.5 109.5t34 105.5l324 937h214z"},W:{horizAdvX:1913,d:"M1891 1462l-386 -1462h-217l-267 930q-11 37 -22 80t-21.5 85.5t-17.5 76.5t-10 52q-2 -18 -8.5 -51.5t-15.5 -75.5t-20 -85.5t-22 -82.5l-261 -929h-216l-384 1462h209l223 -887q11 -44 21.5 -89.5t19.5 -91t16 -88t13 -80.5q5 39 13 83.5t17.5 90.5t20.5 91t23 86 l250 885h205l259 -890q12 -42 23.5 -88t21 -92t17 -88t13.5 -78q7 50 17.5 108t24.5 120t28 122l223 886h210z"},X:{horizAdvX:1229,d:"M1224 0h-234l-381 621l-386 -621h-218l486 760l-453 702h227l353 -569l352 569h219l-454 -704z"},Y:{horizAdvX:1178,d:"M590 762l368 700h220l-486 -894v-568h-205v559l-487 903h224z"},Z:{horizAdvX:1176,d:"M1104 0h-1033v146l765 1138h-740v178h988v-146l-766 -1138h786v-178z"},GREATER:{horizAdvX:1171,d:"M99 403l759 319l-759 357v171l970 -481v-107l-970 -429v170z"}},xr=3e3,ur=new Map;Hn("tile-glyph-geometries",eA);async function eA(){ur.clear(),ur.set(" ",{side:new gt,back:new gt});for(const[n,e]of Object.entries(j0)){const t=tA(nA(e.d,e.horizAdvX));ur.set(n,t)}}function oc(n){const e=n.toUpperCase(),t=ur.get(e);if(!t)throw new Error(`Tile symbol geometry not preloaded for letter: ${e}`);return t}function tA(n){const t=new _r().parse(n),i=[],s=[],r=new Qn;r.moveTo(0,0),r.lineTo(24,0),r.lineTo(24,24),r.lineTo(0,24),r.closePath(),t.paths.forEach(m=>{_r.createShapes(m).forEach(E=>{const f=new yo(E,{depth:.1*xr,bevelEnabled:!1}),{side:T,back:A}=iA(f);i.push(T),s.push(A),r.holes.push(new fi(E.getPoints(12))),E.holes.forEach(I=>{const D=new Qn(I.getPoints(12));new Oo(D).translate(0,0,2)})})});const o=lc(i,"side"),c=lc(s,"back"),d=$n/xr;o.scale(d,-d,d),c.scale(d,-d,d),o.rotateX(Math.PI/2),c.rotateX(Math.PI/2),o.computeBoundingBox();const u=o.boundingBox;if(!u)throw new Error("Failed to compute symbol bounds");const p=new G;u.getCenter(p);const a=-p.x,l=-u.max.y,h=-p.z;return o.translate(a,l,h),c.translate(a,l,h),{side:o,back:c}}function nA(n,e){return`
    <svg width="800px" height="800px" viewBox="0 0 ${xr} ${xr}" 
    version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <title>font_fill</title>
        <g fill-rule="evenodd">
            <path d="${n}">
          /path>
        </g>
    </svg>
  `}function iA(n){const t=n.toNonIndexed().getAttribute("position"),i=[],s=[],r=new G,o=new G,c=new G,d=new G,u=new G,p=new G;let a=-1/0;for(let m=0;m<t.count;m+=1)a=Math.max(a,t.getZ(m));for(let m=0;m<t.count;m+=3){if(r.fromBufferAttribute(t,m),o.fromBufferAttribute(t,m+1),c.fromBufferAttribute(t,m+2),d.subVectors(o,r),u.subVectors(c,r),p.crossVectors(d,u).normalize(),!(Math.abs(p.z)>.9)){i.push(r.x,r.y,r.z,o.x,o.y,o.z,c.x,c.y,c.z);continue}const E=(r.z+o.z+c.z)/3;Math.abs(E-a)<=.001&&s.push(r.x,r.y,r.z,o.x,o.y,o.z,c.x,c.y,c.z)}const l=new gt;l.setAttribute("position",new xt(i,3)),l.computeVertexNormals();const h=new gt;return h.setAttribute("position",new xt(s,3)),h.computeVertexNormals(),{side:l,back:h}}function lc(n,e){const t=$0(n);if(!t)throw new Error(`Failed to merge ${e} SVG geometries`);return t}const sA=new Ut({color:WS,side:Lt,depthTest:!1,depthWrite:!1}),rA=new Ut({color:nu,depthTest:!1,depthWrite:!1}),et=$n,Nt=NS;function ji(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function hu(n,e){const t=new gt;return t.setAttribute("position",new xt(n,3)),t.setIndex(e),t.computeVertexNormals(),t}const du=[],fu=[],es=[],ts=[];ji(du,fu,[0,Nt,0],[et,Nt,0],[et,Nt,et],[0,Nt,et]);ji(es,ts,[et,0,0],[0,0,0],[0,Nt,0],[et,Nt,0]);ji(es,ts,[0,0,et],[et,0,et],[et,Nt,et],[0,Nt,et]);ji(es,ts,[0,0,0],[0,0,et],[0,Nt,et],[0,Nt,0]);ji(es,ts,[et,0,et],[et,0,0],[et,Nt,0],[et,Nt,et]);ji(es,ts,[0,0,0],[et,0,0],[et,0,et],[0,0,et]);const aA=hu(du,fu),oA=hu(es,ts),pa=.08,pu=new Si(et+pa*2,Nt+pa*2,et+pa*2);pu.translate(et/2,Nt/2,et/2);const Ss=class Ss{constructor(e){fe(this,"group");fe(this,"pickableMesh");fe(this,"_topMesh");fe(this,"_sideMesh");fe(this,"_symbolSideMesh");fe(this,"_symbolBackMesh");fe(this,"_symbolGroup");fe(this,"slotPos");fe(this,"slotQuat");fe(this,"glowDelay",0);fe(this,"targetGlowing",!1);fe(this,"isGlowing",!1);fe(this,"_isVisible",!1);fe(this,"animOffset",0);this.glyph=e;const t=new Ut({color:jl,depthTest:!1,depthWrite:!1,side:_n}),i=new Ut({color:ec,depthTest:!1,depthWrite:!1,side:_n}),s=new At(aA,sA),r=new At(oA,rA),o=oc(e),c=new At(o.side,t),d=new At(o.back,i),u=new tn;u.add(d,c),u.position.set(et/2,Nt+1e-4,et/2),this._symbolGroup=u;const p=new Ut({color:16777215,depthTest:!1,depthWrite:!1,visible:!1}),a=new At(pu,p);a.userData.glyph=e;const l=new tn;l.add(s,r,u,a),l.position.set(-et/2,0,-et/2);const h=!1;for(const m of[s,r,u])m.visible=h;this.group=l,this._symbolSideMesh=c,this._symbolBackMesh=d,this._topMesh=s,this._sideMesh=r,this.pickableMesh=a,this.pickableMesh.userData["scrabble-tile"]=this,this.updateRenderOrder()}updateRenderOrder(e=0){this.pickableMesh.renderOrder=7,this._sideMesh.renderOrder=8+e,this._topMesh.renderOrder=9+e,this._symbolSideMesh.renderOrder=11+e,this._symbolBackMesh.renderOrder=12+e}updateGlow(e){if(this.glowDelay>0){this.glowDelay-=e;return}this.isGlowing=this.targetGlowing;const t=.02*e;this._symbolBackMesh.material.color.lerp(this.isGlowing?YS:ec,t),this._symbolSideMesh.material.color.lerp(this.isGlowing?kS:jl,t)}randomizeLetter(){const e=Ss._LETTERS[Math.floor(Math.random()*Ss._LETTERS.length)];this.setLetter(e)}setLetter(e){this.glyph=e,this.pickableMesh.userData.glyph=e;const t=oc(e);t&&(this._symbolSideMesh.geometry=t.side,this._symbolBackMesh.geometry=t.back)}get isVisible(){return this._isVisible}set isVisible(e){this._isVisible=e,this.glyph===" "&&(e=!1);for(const t of this.group.children)t.visible=e;this.pickableMesh.visible=!0}set isHovered(e){this.pickableMesh.material.visible=e}toggle(){this._isVisible?this.hide():this.show()}hide(){this.isVisible=!1}show(){this.isVisible=!0}set anim(e){e+=this.animOffset;const t=-.3;e=t+e*(1-2*t),e=Math.max(0,Math.min(1,e));const i=(1-e)*30,s=-(1-e)*30;this.group.position.y=this.slotPos.y+i,this.group.position.z=this.slotPos.z+s}};fe(Ss,"_LETTERS","ABCDEFGHIJKLMNOPQRSTUVWXYZ");let ms=Ss;const nr=Math.PI*2;function zt(n){const e=Math.sin(n*127.1+311.7)*43758.5453123;return e-Math.floor(e)}function cc(n,e,t){return Math.max(e,Math.min(t,n))}const Bi=class Bi{constructor(){fe(this,"_seeds",[]);fe(this,"_timeMs",0);fe(this,"_blend",1)}update(e,t,i){if(this._ensureMaskSeeds(i),this._timeMs+=e,t){this._blend=Math.min(1,this._blend+e/Bi._BLEND_IN_DURATION);return}this._blend=Math.max(0,this._blend-e/Bi._BLEND_OUT_DURATION)}getBlend(){return 0}getMaskPose(e,t,i,s,r){const o=this._seeds[e];if(!o||t<=0||i<=0)return{x:0,y:0,angle:0};const c=this._timeMs*1e-4,d=o.anchorXNorm*t+Math.sin(c*o.freqX+o.phaseX)*o.ampXNorm*t+Math.sin(c*o.driftFreq+o.driftPhase)*.03*t,u=o.anchorYNorm*i+Math.cos(c*o.freqY+o.phaseY)*o.ampYNorm*i+Math.cos(c*(o.driftFreq*.73)+o.driftPhase)*.025*i,p=s*.5,a=r*.5,l=8,h=cc(d,p+l,t-p-l),m=cc(u,a+l,i-a-l),S=Math.sin(c*o.spinFreq+o.spinPhase)*o.spinAmpRad;return{x:h-p,y:m-a,angle:S}}_ensureMaskSeeds(e){for(let t=this._seeds.length;t<e;t+=1)this._seeds.push(this._buildSeed(t))}_buildSeed(e){const t=(e+1)*17*Math.random();return{anchorXNorm:.2+zt(t+1)*.6,anchorYNorm:.2+zt(t+2)*.6,ampXNorm:.05+zt(t+3)*.1,ampYNorm:.04+zt(t+4)*.09,freqX:.45+zt(t+5)*.95,freqY:.4+zt(t+6)*.85,phaseX:zt(t+7)*nr,phaseY:zt(t+8)*nr,driftFreq:.15+zt(t+9)*.35,driftPhase:zt(t+10)*nr,spinFreq:.55+zt(t+11)*.8,spinPhase:zt(t+12)*nr,spinAmpRad:.18+zt(t+13)*.36}}};fe(Bi,"_BLEND_IN_DURATION",350),fe(Bi,"_BLEND_OUT_DURATION",2e3);let fo=Bi;const Uo=new Ai(10,10);Uo.rotateX(-Math.PI/2-.05);Uo.rotateZ(.01);const lA=new Ut({color:Mr}),us=new At(Uo,lA);class cA extends cu{constructor(){super();fe(this,"hasRenderedScene",!0);fe(this,"duration",500)}begin(t){}initMeshes(t){t._scene.add(us),us.visible=!1}updateMeshes(t,i){us.visible=!0,us.position.y=.6-i*1}cleanupMeshes(t){us.visible=!1}incremental(t,i){return!0}getPercentComplete(t){return 100}getMasks(t){return[]}}class uA{}class hA extends uA{update(e,t){let s=0;for(const r of e._scrabbleTiles){let o=t;o-=.43,o/=1-2*.43;const c=s-qi,d=Math.floor(c/5),u=c%5;o+=(4-d-u)*.3,o=Math.max(0,Math.min(1,o)),o=1-Math.cos(o*Math.PI*2),r.group.position.y=r.slotPos.y+o*.2,s++}}}const tt=class tt{constructor(){fe(this,"gameState","loading");fe(this,"_appGfx");fe(this,"_canvas");fe(this,"_renderer");fe(this,"_scene");fe(this,"_boardGroup");fe(this,"_trayGroup");fe(this,"_allTilesGroup");fe(this,"_uiTiles",[]);fe(this,"_scrabbleTiles",[]);fe(this,"_allTiles");fe(this,"_pickableMeshes",[]);fe(this,"_raycaster",new kc);fe(this,"_pointer",new oe);fe(this,"_hoveredPickable",null);fe(this,"_camera");fe(this,"_nextCamera");fe(this,"_controls");fe(this,"_renderPixelScale",1);fe(this,"_entranceMaskAnimation");fe(this,"_allCelebrations");fe(this,"_allExitAnimations");fe(this,"_celebration");fe(this,"_exitMaskAnimation");fe(this,"_animVec",new G);fe(this,"_trayVisibilityBounds",new Qi(tt._TRAY_VISIBILITY_BOX_MIN.clone(),tt._TRAY_VISIBILITY_BOX_MAX.clone()));fe(this,"_trayCorner",new G);fe(this,"_cameraOffset",new G);fe(this,"_trayBoundsDebugMesh");fe(this,"_focusTargetPos",new G);fe(this,"_titleScreenDance",new fo);fe(this,"_animT",0);fe(this,"_camT",0);fe(this,"_tileT",0);fe(this,"_nextEntranceT",0);fe(this,"_nextExitT",0);fe(this,"_tileCelebrationT",0);fe(this,"_tileExitT",1);fe(this,"_exitT",0);fe(this,"_canGotoNextLevel",!1);fe(this,"_isGotoNextLevelQueued",!1);fe(this,"_focusTimeMs",0);fe(this,"_focusedTile",null);fe(this,"_returningTiles",[]);fe(this,"slotPos");fe(this,"slotQuat");fe(this,"_dragStartTime",0);fe(this,"_dragStartPos",new oe);fe(this,"_isDragging",!1);fe(this,"_draggingPos",new G(0,0,0));fe(this,"_targetIntersection",new G);fe(this,"_dragPlane",new On(new G(0,-1,0),2));fe(this,"dt",0);fe(this,"_didFinishEntrance",!1);fe(this,"_didSolvePuzzle",!1);const e=document.getElementById("app-canvas");if(!e)throw new Error("Missing #app-canvas");this._canvas=e,this._renderer=new MS({canvas:e,antialias:!1}),this._renderer.setSize(window.innerWidth,window.innerHeight),this._canvas.style.imageRendering="crisp-edges",this._canvas.style.imageRendering="pixelated",this._scene=new Yh,this._scene.background=new Qe(Mr),this._camera=tt.newCamera(),this._camera.position.copy(tt._CAM_START),this._camera.lookAt(0,0,0),this._nextCamera=this._camera,this._controls=new u0(this._camera,this._canvas),this._controls.enableDamping=!0,this._controls.dampingFactor=.08,this._controls.maxPolarAngle=Math.PI*.48,this._controls.target.set(0,0,0),this._controls.enabled=!1,this._appGfx=new R0(this),this._appGfx.onResize(),this._boardGroup=L0(),this._trayGroup=wS(),this._trayGroup.position.set(0,.5,3),this._trayGroup.rotateX(.4),this._allTilesGroup=new tn,this._scene.add(this._allTilesGroup);const t=new G().subVectors(tt._TRAY_VISIBILITY_BOX_MAX,tt._TRAY_VISIBILITY_BOX_MIN),i=new G().addVectors(tt._TRAY_VISIBILITY_BOX_MIN,tt._TRAY_VISIBILITY_BOX_MAX).multiplyScalar(.5);this._trayBoundsDebugMesh=new At(new Si(t.x,t.y,t.z),new Ut({color:3388927,transparent:!0,opacity:.18,depthWrite:!1,visible:!1})),this._trayBoundsDebugMesh.position.copy(i);for(let d=0;d<qi;d++){const u=new ms(" ");u.animOffset=d*.1,this._scrabbleTiles.push(u);const p=FS(d);u.group.position.copy(p),this._trayGroup.add(u.group),this._pickableMeshes.push(u.pickableMesh)}for(let d=0;d<5;d++)for(let u=0;u<5;u++){const a=new ms(" ");a.animOffset=(d+u)*.1,this._scrabbleTiles.push(a);const l=y0(d,u);a.group.position.copy(l),this._boardGroup.add(a.group),this._pickableMeshes.push(a.pickableMesh)}const s=[],r=[];this.slotPos=s,this.slotQuat=r;for(const d of this._scrabbleTiles)s.push(d.group.getWorldPosition(new G)),r.push(d.group.getWorldQuaternion(new wn));for(const[d,u]of this._scrabbleTiles.entries())this._allTilesGroup.add(u.group),u.group.position.copy(s[d]),u.group.quaternion.copy(r[d]),u.slotPos=s[d],u.slotQuat=r[d],this._allTilesGroup.add(u.pickableMesh),u.pickableMesh.position.copy(s[d]),u.pickableMesh.quaternion.copy(r[d]);const o=new ms("GREATER");this._allTilesGroup.add(o.group),this._pickableMeshes.push(o.pickableMesh);const c=new G(-$n/2,0,-6);o.group.position.copy(c),o.slotPos=c,o.slotQuat=new wn,this._uiTiles.push(o),this._allTiles=[...this._scrabbleTiles,...this._uiTiles],tu(this),this._entranceMaskAnimation=new Z0(!1),this._entranceMaskAnimation.initMeshes(this),this._allExitAnimations=[new cA];for(const d of this._allExitAnimations)d.initMeshes(this);this._exitMaskAnimation=pr(this._allExitAnimations),this._allCelebrations=[new hA],this._celebration=pr(this._allCelebrations)}static randomCamStart(){return new G(3,.8,0).lerp(new G(-6,3,6),Math.random())}static newCamera(){return new Xt(60,window.innerWidth/window.innerHeight,.1,1e6)}mouseUp(){const e=performance.now()-this._dragStartTime<200,t=this._dragStartPos.distanceTo(this._pointer)<.01;if(e&&t){this._isDragging=!1;return}if(this._isDragging&&this._hoveredPickable&&this._hoveredPickable.userData["scrabble-tile"].glyph===" "){this.mouseDown(),this._isDragging=!1;return}this._isDragging=!1,this._queueReturnFocusedTile(),this.mouseMove(null,null)}mouseDown(){var e;if(this.gameState==="title-screen"){$S();return}if(this._hoveredPickable){const t=this._hoveredPickable.userData["scrabble-tile"];if(t&&t.glyph==="GREATER"){this._didSolvePuzzle=!0,this._isGotoNextLevelQueued=!0,this._tileCelebrationT=1;return}if(t&&t.glyph!==" ")this._focusedTile?((e=this._focusedTile)==null?void 0:e.tile)===t&&this._queueReturnFocusedTile():(this._focusTile(t),this._isDragging=!0,document.documentElement.style.cursor="grabbing",this._dragStartTime=performance.now(),this._dragStartPos.copy(this._pointer));else if(this._focusedTile&&t&&t.glyph===" "){const i=this._scrabbleTiles.indexOf(this._focusedTile.tile),s=this._scrabbleTiles.indexOf(t);this._scrabbleTiles[i]=t,this._scrabbleTiles[s]=this._focusedTile.tile,this._focusedTile.slotIndex=s,this._queueReturnFocusedTile(),this.mouseMove(null,null),t.group.position.copy(this.slotPos[i]),t.group.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[i].slotPos=this.slotPos[i],this._scrabbleTiles[i].slotQuat=this.slotQuat[i],this._scrabbleTiles[s].slotPos=this.slotPos[s],this._scrabbleTiles[s].slotQuat=this.slotQuat[s],this._scrabbleTiles[i].pickableMesh.position.copy(this.slotPos[i]),this._scrabbleTiles[i].pickableMesh.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[s].pickableMesh.position.copy(this.slotPos[s]),this._scrabbleTiles[s].pickableMesh.quaternion.copy(this.slotQuat[s])}}else this._queueReturnFocusedTile()}mouseMove(e,t){this._isDragging||(document.documentElement.style.cursor="default");const i=this._didFinishEntrance&&!this._didSolvePuzzle;let s=null;if(i&&e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.intersectObjects(this._pickableMeshes,!1);r.length>0&&(s=r[0].object)}if(s&&!this._focusedTile&&s.userData["scrabble-tile"].glyph===" "&&(s=null),s&&!this._isDragging&&(document.documentElement.style.cursor="pointer"),this._hoveredPickable&&(this._hoveredPickable.userData["scrabble-tile"].isHovered=!1),this._hoveredPickable=s,s&&(s.userData["scrabble-tile"].isHovered=!0),e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.ray.intersectPlane(this._dragPlane,this._targetIntersection);r&&(this._draggingPos.copy(r),this._draggingPos.x-=$n/2,this._draggingPos.z-=$n/2)}}_focusTile(e){var r;if(((r=this._focusedTile)==null?void 0:r.tile)===e){this._queueReturnFocusedTile();return}this._queueReturnFocusedTile();const t=this._returningTiles.findIndex(o=>o.tile===e),i=t>=0?this._returningTiles[t]:null;t>=0&&this._returningTiles.splice(t,1);const s=this._scrabbleTiles.indexOf(e);this._focusedTile={tile:e,position:((i==null?void 0:i.position)??e.group.position).clone(),quaternion:((i==null?void 0:i.quaternion)??e.group.quaternion).clone(),slotIndex:s},Co(this),e.updateRenderOrder(20),this._focusTimeMs=0}_queueReturnFocusedTile(){if(!this._focusedTile)return;const e=this._focusedTile;this._returningTiles.push({tile:e.tile,position:e.position,quaternion:e.quaternion,slotIndex:e.slotIndex}),e.tile.updateRenderOrder(10),this._focusedTile=null}async init(){this._scene.add(jn),this._scene.add(this._boardGroup),this._scene.add(this._trayGroup),this._scene.add(this._trayBoundsDebugMesh),this.gameState="title-screen",this._entranceMaskAnimation.begin(this),this._entranceMaskAnimation.incremental(this,Number.POSITIVE_INFINITY),new J0(this).wireUiInput()}onResize(){this._appGfx.onResize(),this.gameState!=="title-screen"&&(this._animT<1&&(this._boardGroup.visible=!0,this._trayGroup.visible=!0,this._entranceMaskAnimation.begin(this),this._entranceMaskAnimation.incremental(this,Number.POSITIVE_INFINITY),this._animT=0),this._exitT===0&&this._didFinishEntrance&&(this._entranceMaskAnimation.begin(this),this._exitMaskAnimation.begin(this),this._nextEntranceT=0,this._nextExitT=0))}cycleRenderPixelScale(){this.setRenderPixelScale(this._renderPixelScale%6+1)}getRenderPixelScale(){return this._renderPixelScale}setRenderPixelScale(e){this._renderPixelScale!==e&&(this._renderPixelScale=e,this._appGfx.onResize())}};fe(tt,"_ANIM_MAX_ROTATION",Math.PI*.4),fe(tt,"_ANIM_DURATION",2e3),fe(tt,"_CAM_DURATION",2e3),fe(tt,"_TILE_DURATION",800),fe(tt,"_TILE_CELEBRATION_DURATION",2e3),fe(tt,"_TILE_EXIT_DURATION",1e3),fe(tt,"_CAM_START",tt.randomCamStart()),fe(tt,"_CAM_END",new G(0,8,4)),fe(tt,"_FOCUS_POS",new G(0,3.1,3)),fe(tt,"_FOCUS_LERP_ALPHA",.4),fe(tt,"_FOCUS_OSC_AMP",.07),fe(tt,"_FOCUS_OSC_SPEED",.006),fe(tt,"_POST_ENTRANCE_ZOOM_OUT_SPEED",.0055),fe(tt,"_POST_ENTRANCE_MAX_CAMERA_DISTANCE",30),fe(tt,"_TRAY_VISIBILITY_NDC_LIMIT",.98),fe(tt,"_TRAY_VISIBILITY_BOX_MIN",new G(-2.4,0,3)),fe(tt,"_TRAY_VISIBILITY_BOX_MAX",new G(2.4,1,4.5)),fe(tt,"_MASK_FILTER_COLORS",["#ff4466","#44ffaa","#4488ff","#ffcc00","#cc44ff"]);let lt=tt;function ir(n,e,t){return(1-t)*n+t*e}const Xn=100,dA=40,Kn=50;let Eu,uc=0;const fA=.02;function pA(n,e){uc+=n.dt*fA;const t=window.innerWidth-Kn,i=window.innerHeight-Kn;e.save(),e.translate(t+Kn/2,i+Kn/2),e.rotate(uc),e.drawImage(Eu,0,0,Xn,Xn,-Kn/2,-Kn/2,Kn,Kn),e.restore()}async function EA(){const n=document.createElement("canvas"),e=n.getContext("2d");n.width=Xn,n.height=Xn,e.clearRect(0,0,Xn,Xn),e.fillStyle="black",e.beginPath(),e.arc(Xn/2,Xn/2,dA,0,Math.PI),e.closePath(),e.fill(),Eu=n}Hn("spinner",EA);function mA(n){if(SA(n),n.gameState==="title-screen")return;const e=document.getElementById("overlay-canvas");(e.width!==window.innerWidth||e.height!==window.innerHeight)&&(e.width=window.innerWidth,e.height=window.innerHeight);const t=e.getContext("2d");if(t.clearRect(0,0,e.width,e.height),n._animT<1){const i=n._animT;n._entranceMaskAnimation.updateMeshes(n,i),hc(n,t,e.width,e.height,i)}else if(n._exitT>0&&n._exitT<1){let i=1-n._exitT;n._exitMaskAnimation.updateMeshes(n,i),i=Math.pow(i,1/4),hc(n,t,e.width,e.height,i,!0)}(n._nextEntranceT>0&&n._nextEntranceT<1||n._nextExitT>0&&n._nextExitT<1)&&pA(n,t)}function SA(n){const e=n._animT===1&&(n._exitT===0||n._exitMaskAnimation.hasRenderedScene);n._boardGroup.visible=e,n._trayGroup.visible=e,n._allTilesGroup.visible=e;for(const i of n._scrabbleTiles)i.updateGlow(n.dt);const t=n.gameState==="title-screen";n._renderer.render(n._scene,t?Lr:n._camera)}function hc(n,e,t,i,s,r=!1){const o=t,c=i,d=qc(s,5),u=(1-d)*lt._ANIM_MAX_ROTATION,p=Math.cos(u),a=Math.sin(u),l=n._titleScreenDance.getBlend();e.globalAlpha=1;const h=r?n._exitMaskAnimation.getMasks(n):n._entranceMaskAnimation.getMasks(n);for(let m=0;m<h.length;m+=1){const S=h[m];let E=S.x,f=S.y;if(S.worldPos){n._animVec.set(S.worldPos.x*p+S.worldPos.z*a,S.worldPos.y,-S.worldPos.x*a+S.worldPos.z*p).project(n._camera);const A=(n._animVec.x+1)/2*o,I=(1-n._animVec.y)/2*c;E=A-S.canvas.width/2+S.restOffsetX+S.animOffsetX*(1-s),f=I-S.canvas.height/2+S.restOffsetY+S.animOffsetY*(1-s)}let T=ir(S.restAngle,0,d);if(l>0){const A=n._titleScreenDance.getMaskPose(m,o,c,S.canvas.width,S.canvas.height);E=ir(E,A.x,l),f=ir(f,A.y,l),T=ir(T,A.angle,l)}e.save(),e.translate(E+S.canvas.width/2,f+S.canvas.height/2),e.rotate(T),e.drawImage(S.canvas,-S.canvas.width/2,-S.canvas.height/2),e.restore()}}function AA(n,e){n.dt=e;const t=n.gameState==="title-screen";if(n._titleScreenDance.update(e,t,n._entranceMaskAnimation.getMaskCount(n)),ho(e)&&(n._scene.remove(jn),n.gameState="playing"),t){const s=performance.now();jn.rotateZ(Math.sin(s*5e-4)*.001),jn.rotateY(Math.sin(s*568164e-9)*.001)}else n._animT=Math.min(1,n._animT+e/lt._ANIM_DURATION),n._animT>=1&&n._entranceMaskAnimation.cleanupMeshes(n);if(n._animT>=1&&n._camT<1){n._camT=Math.min(1,n._camT+e/lt._CAM_DURATION);const s=qc(n._camT,10);n._camera.position.lerpVectors(lt._CAM_START,lt._CAM_END,s)}if(n._animT>=1&&n._camT>=1&&n._tileT<1){n._tileT=Math.min(1,n._tileT+e/lt._TILE_DURATION);for(const s of n._allTiles)s.show(),s.anim=n._tileT}const i=n._exitMaskAnimation.shouldSkipTileExit;if(!n._didFinishEntrance&&n._tileT>=1){n._didFinishEntrance=!0;for(const s of n._allTiles)s.show(),s.anim=1;n._nextCamera=lt.newCamera(),n._nextCamera.position.copy(lt.randomCamStart()),n._nextCamera.lookAt(0,0,0),n._entranceMaskAnimation.begin(n),n._nextEntranceT=0,n._nextExitT=0,n._tileCelebrationT=0,n._tileExitT=0,n._exitT=0}else if(n._didFinishEntrance&&n._nextEntranceT<1)n._entranceMaskAnimation.incremental(n),n._nextEntranceT=n._entranceMaskAnimation.getPercentComplete(n)/100;else if(n._didFinishEntrance&&n._nextExitT<1&&n._didSolvePuzzle)n._exitMaskAnimation.incremental(n,5),n._nextExitT=n._exitMaskAnimation.getPercentComplete(n)/100,n._nextExitT>=1&&(n._canGotoNextLevel=!0);else if(n._didSolvePuzzle&&n._tileCelebrationT<1)n._tileCelebrationT=Math.min(1,n._tileCelebrationT+e/lt._TILE_CELEBRATION_DURATION),n._celebration.update(n,n._tileCelebrationT);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._tileExitT<1&&!i&&n._isGotoNextLevelQueued&&n._tileCelebrationT===1)if(n._tileExitT=Math.min(1,n._tileExitT+e/lt._TILE_EXIT_DURATION),n._tileExitT>=1)for(const s of n._allTiles)s.hide();else for(const s of n._allTiles)s.anim=1-n._tileExitT;else if(n._nextEntranceT>=1&&n._nextExitT>=1&&(n._tileExitT>=1||i)&&n._exitT<1&&n._isGotoNextLevelQueued)n._exitT=Math.min(1,n._exitT+e/n._exitMaskAnimation.duration);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._exitT>=1){n._didFinishEntrance=!1,n._didSolvePuzzle=!1,n._canGotoNextLevel=!1,n._isGotoNextLevelQueued=!1,n._animT=0,n._camT=0,n._tileT=0,n._nextEntranceT=0,n._nextExitT=0,n._tileCelebrationT=0,n._tileExitT=0,n._exitT=0,lt._CAM_START.copy(n._nextCamera.position),n._camera.position.copy(n._nextCamera.position),n._camera.quaternion.copy(n._nextCamera.quaternion);for(const s of n._allTiles)s.hide();n._exitMaskAnimation.cleanupMeshes(n),n._exitMaskAnimation=pr(n._allExitAnimations),tu(n)}_A(n,e),gA(n,e),n._controls.update(),mA(n),ho(e)}function _A(n,e){if(n._focusedTile){n._focusTimeMs+=e;const t=Math.sin(n._focusTimeMs*lt._FOCUS_OSC_SPEED)*lt._FOCUS_OSC_AMP;n._focusTargetPos.copy(n._isDragging?n._draggingPos:lt._FOCUS_POS),n._focusTargetPos.y+=t,n._focusedTile.tile.group.position.lerp(n._focusTargetPos,lt._FOCUS_LERP_ALPHA)}for(let t=n._returningTiles.length-1;t>=0;t-=1){const i=n._returningTiles[t],s=n.slotPos[i.slotIndex],r=n.slotQuat[i.slotIndex];i.tile.group.position.lerp(s,lt._FOCUS_LERP_ALPHA),i.tile.group.quaternion.slerp(r,lt._FOCUS_LERP_ALPHA);const o=i.tile.group.position.distanceToSquared(s)<1e-4,c=Math.abs(i.tile.group.quaternion.dot(r))>.999;!o||!c||(i.tile.group.position.copy(s),i.tile.group.quaternion.copy(r),n._returningTiles.splice(t,1),i.tile.updateRenderOrder(),Co(n)&&(n._didSolvePuzzle=!0,n.mouseMove(null,null),n._tileCelebrationT=0,n._isGotoNextLevelQueued=!0,n._exitMaskAnimation.begin(n)))}}const Ea=[0,0],ma=[0,0],Sa=[0,0];function xA(n){if(n._trayVisibilityBounds.isEmpty())return!0;const{min:e,max:t}=n._trayVisibilityBounds,i=lt._TRAY_VISIBILITY_NDC_LIMIT;Ea[0]=e.x,Ea[1]=t.x,ma[0]=e.y,ma[1]=t.y,Sa[0]=e.z,Sa[1]=t.z;for(const s of Ea)for(const r of ma)for(const o of Sa)if(n._trayCorner.set(s,r,o).project(n._camera),!Number.isFinite(n._trayCorner.x)||!Number.isFinite(n._trayCorner.y)||!Number.isFinite(n._trayCorner.z)||Math.abs(n._trayCorner.x)>i||Math.abs(n._trayCorner.y)>i||n._trayCorner.z<-1||n._trayCorner.z>1)return!1;return!0}function gA(n,e){if(n._camT<1||xA(n))return;n._cameraOffset.copy(n._camera.position).sub(n._controls.target);const t=n._cameraOffset.length();if(t===0||t>=lt._POST_ENTRANCE_MAX_CAMERA_DISTANCE)return;n._cameraOffset.divideScalar(t);const i=lt._POST_ENTRANCE_ZOOM_OUT_SPEED*e,s=lt._POST_ENTRANCE_MAX_CAMERA_DISTANCE-t;n._camera.position.addScaledVector(n._cameraOffset,Math.min(i,s))}async function TA(){const n=document.getElementById("startup-loading-label"),e=document.getElementById("startup-loading-screen");await bS(r=>{n&&(n.innerHTML=`LOADING (${r}%)`)});const t=new lt;await t.init(),e==null||e.classList.add("hidden"),window.addEventListener("resize",()=>t.onResize());let i=performance.now();const s=()=>{requestAnimationFrame(s);const r=performance.now(),o=Math.min(30,r-i);i=r,AA(t,o)};requestAnimationFrame(s)}TA();
