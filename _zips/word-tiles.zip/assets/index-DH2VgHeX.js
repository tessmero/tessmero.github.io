var du=Object.defineProperty;var pu=(n,e,t)=>e in n?du(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var me=(n,e,t)=>pu(n,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();function Eu(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}function mu(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}globalThis.__trackObject=Eu;globalThis.__trackArray=mu;/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const ro="181",Pi={ROTATE:0,DOLLY:1,PAN:2},Di={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Su=0,wo=1,Au=2,sc=1,xu=2,Ln=3,An=0,Lt=1,an=2,Dn=0,Ui=1,Fo=2,Bo=3,Ho=4,_u=5,oi=100,gu=101,Tu=102,Ru=103,vu=104,Mu=200,Iu=201,Lu=202,yu=203,ha=204,fa=205,Ou=206,bu=207,Cu=208,Du=209,Nu=210,Pu=211,Uu=212,wu=213,Fu=214,da=0,pa=1,Ea=2,Fi=3,ma=4,Sa=5,Aa=6,xa=7,rc=0,Bu=1,Hu=2,Zn=0,Gu=1,Vu=2,ku=3,Yu=4,Wu=5,zu=6,Ku=7,ac=300,Bi=301,Hi=302,_a=303,ga=304,Sr=306,Ta=1e3,On=1001,Ra=1002,Xt=1003,Xu=1004,Os=1005,en=1006,Ir=1007,ui=1008,Pn=1009,oc=1010,lc=1011,ms=1012,ao=1013,fi=1014,bn=1015,Wi=1016,oo=1017,lo=1018,Ss=1020,cc=35902,uc=35899,hc=1021,fc=1022,ln=1023,As=1026,xs=1027,dc=1028,co=1029,uo=1030,ho=1031,fo=1033,tr=33776,nr=33777,ir=33778,sr=33779,va=35840,Ma=35841,Ia=35842,La=35843,ya=36196,Oa=37492,ba=37496,Ca=37808,Da=37809,Na=37810,Pa=37811,Ua=37812,wa=37813,Fa=37814,Ba=37815,Ha=37816,Ga=37817,Va=37818,ka=37819,Ya=37820,Wa=37821,za=36492,Ka=36494,Xa=36495,qa=36283,Za=36284,Qa=36285,Ja=36286,qu=3200,Zu=3201,Qu=0,Ju=1,Xn="",Nt="srgb",Gi="srgb-linear",lr="linear",st="srgb",Si=7680,Go=519,$u=512,ju=513,eh=514,pc=515,th=516,nh=517,ih=518,sh=519,Vo=35044,ko="300 es",mn=2e3,cr=2001;function Ec(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function ur(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function rh(){const n=ur("canvas");return n.style.display="block",n}const Yo={};function Wo(...n){const e="THREE."+n.shift();console.log(e,...n)}function Ke(...n){const e="THREE."+n.shift();console.warn(e,...n)}function dt(...n){const e="THREE."+n.shift();console.error(e,...n)}function _s(...n){const e=n.join(" ");e in Yo||(Yo[e]=!0,Ke(...n))}function ah(n,e,t){return new Promise(function(i,s){function r(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:s();break;case n.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:i()}}setTimeout(r,t)})}class pi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){const i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){const i=this._listeners;if(i===void 0)return;const s=i[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const i=t[e.type];if(i!==void 0){e.target=this;const s=i.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}}const yt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],rr=Math.PI/180,$a=180/Math.PI;function zi(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(yt[n&255]+yt[n>>8&255]+yt[n>>16&255]+yt[n>>24&255]+"-"+yt[e&255]+yt[e>>8&255]+"-"+yt[e>>16&15|64]+yt[e>>24&255]+"-"+yt[t&63|128]+yt[t>>8&255]+"-"+yt[t>>16&255]+yt[t>>24&255]+yt[i&255]+yt[i>>8&255]+yt[i>>16&255]+yt[i>>24&255]).toLowerCase()}function Ze(n,e,t){return Math.max(e,Math.min(t,n))}function oh(n,e){return(n%e+e)%e}function Lr(n,e,t){return(1-t)*n+t*e}function $i(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function Bt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}const lh={DEG2RAD:rr};class oe{constructor(e=0,t=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6],this.y=s[1]*t+s[4]*i+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*i-o*s+e.x,this.y=r*s+o*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Un{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=s}static slerpFlat(e,t,i,s,r,o,c){let h=i[s+0],u=i[s+1],p=i[s+2],a=i[s+3],l=r[o+0],f=r[o+1],m=r[o+2],S=r[o+3];if(c<=0){e[t+0]=h,e[t+1]=u,e[t+2]=p,e[t+3]=a;return}if(c>=1){e[t+0]=l,e[t+1]=f,e[t+2]=m,e[t+3]=S;return}if(a!==S||h!==l||u!==f||p!==m){let E=h*l+u*f+p*m+a*S;E<0&&(l=-l,f=-f,m=-m,S=-S,E=-E);let d=1-c;if(E<.9995){const g=Math.acos(E),A=Math.sin(g);d=Math.sin(d*g)/A,c=Math.sin(c*g)/A,h=h*d+l*c,u=u*d+f*c,p=p*d+m*c,a=a*d+S*c}else{h=h*d+l*c,u=u*d+f*c,p=p*d+m*c,a=a*d+S*c;const g=1/Math.sqrt(h*h+u*u+p*p+a*a);h*=g,u*=g,p*=g,a*=g}}e[t]=h,e[t+1]=u,e[t+2]=p,e[t+3]=a}static multiplyQuaternionsFlat(e,t,i,s,r,o){const c=i[s],h=i[s+1],u=i[s+2],p=i[s+3],a=r[o],l=r[o+1],f=r[o+2],m=r[o+3];return e[t]=c*m+p*a+h*f-u*l,e[t+1]=h*m+p*l+u*a-c*f,e[t+2]=u*m+p*f+c*l-h*a,e[t+3]=p*m-c*a-h*l-u*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,s){return this._x=e,this._y=t,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,s=e._y,r=e._z,o=e._order,c=Math.cos,h=Math.sin,u=c(i/2),p=c(s/2),a=c(r/2),l=h(i/2),f=h(s/2),m=h(r/2);switch(o){case"XYZ":this._x=l*p*a+u*f*m,this._y=u*f*a-l*p*m,this._z=u*p*m+l*f*a,this._w=u*p*a-l*f*m;break;case"YXZ":this._x=l*p*a+u*f*m,this._y=u*f*a-l*p*m,this._z=u*p*m-l*f*a,this._w=u*p*a+l*f*m;break;case"ZXY":this._x=l*p*a-u*f*m,this._y=u*f*a+l*p*m,this._z=u*p*m+l*f*a,this._w=u*p*a-l*f*m;break;case"ZYX":this._x=l*p*a-u*f*m,this._y=u*f*a+l*p*m,this._z=u*p*m-l*f*a,this._w=u*p*a+l*f*m;break;case"YZX":this._x=l*p*a+u*f*m,this._y=u*f*a+l*p*m,this._z=u*p*m-l*f*a,this._w=u*p*a-l*f*m;break;case"XZY":this._x=l*p*a-u*f*m,this._y=u*f*a-l*p*m,this._z=u*p*m+l*f*a,this._w=u*p*a+l*f*m;break;default:Ke("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,s=Math.sin(i);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],s=t[4],r=t[8],o=t[1],c=t[5],h=t[9],u=t[2],p=t[6],a=t[10],l=i+c+a;if(l>0){const f=.5/Math.sqrt(l+1);this._w=.25/f,this._x=(p-h)*f,this._y=(r-u)*f,this._z=(o-s)*f}else if(i>c&&i>a){const f=2*Math.sqrt(1+i-c-a);this._w=(p-h)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+u)/f}else if(c>a){const f=2*Math.sqrt(1+c-i-a);this._w=(r-u)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(h+p)/f}else{const f=2*Math.sqrt(1+a-i-c);this._w=(o-s)/f,this._x=(r+u)/f,this._y=(h+p)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ze(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const s=Math.min(1,t/i);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,s=e._y,r=e._z,o=e._w,c=t._x,h=t._y,u=t._z,p=t._w;return this._x=i*p+o*c+s*u-r*h,this._y=s*p+o*h+r*c-i*u,this._z=r*p+o*u+i*h-s*c,this._w=o*p-i*c-s*h-r*u,this._onChangeCallback(),this}slerp(e,t){if(t<=0)return this;if(t>=1)return this.copy(e);let i=e._x,s=e._y,r=e._z,o=e._w,c=this.dot(e);c<0&&(i=-i,s=-s,r=-r,o=-o,c=-c);let h=1-t;if(c<.9995){const u=Math.acos(c),p=Math.sin(u);h=Math.sin(h*u)/p,t=Math.sin(t*u)/p,this._x=this._x*h+i*t,this._y=this._y*h+s*t,this._z=this._z*h+r*t,this._w=this._w*h+o*t,this._onChangeCallback()}else this._x=this._x*h+i*t,this._y=this._y*h+s*t,this._z=this._z*h+r*t,this._w=this._w*h+o*t,this.normalize();return this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class G{constructor(e=0,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),G.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(zo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(zo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6]*s,this.y=r[1]*t+r[4]*i+r[7]*s,this.z=r[2]*t+r[5]*i+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*i+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*i+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*i+r[10]*s+r[14])*o,this}applyQuaternion(e){const t=this.x,i=this.y,s=this.z,r=e.x,o=e.y,c=e.z,h=e.w,u=2*(o*s-c*i),p=2*(c*t-r*s),a=2*(r*i-o*t);return this.x=t+h*u+o*a-c*p,this.y=i+h*p+c*u-r*a,this.z=s+h*a+r*p-o*u,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*i+r[8]*s,this.y=r[1]*t+r[5]*i+r[9]*s,this.z=r[2]*t+r[6]*i+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,s=e.y,r=e.z,o=t.x,c=t.y,h=t.z;return this.x=s*h-r*c,this.y=r*o-i*h,this.z=i*c-s*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return yr.copy(this).projectOnVector(e),this.sub(yr)}reflect(e){return this.sub(yr.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,s=this.z-e.z;return t*t+i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const s=Math.sin(t)*e;return this.x=s*Math.sin(i),this.y=Math.cos(t)*e,this.z=s*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const yr=new G,zo=new Un;class We{constructor(e,t,i,s,r,o,c,h,u){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),We.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,o,c,h,u)}set(e,t,i,s,r,o,c,h,u){const p=this.elements;return p[0]=e,p[1]=s,p[2]=c,p[3]=t,p[4]=r,p[5]=h,p[6]=i,p[7]=o,p[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,o=i[0],c=i[3],h=i[6],u=i[1],p=i[4],a=i[7],l=i[2],f=i[5],m=i[8],S=s[0],E=s[3],d=s[6],g=s[1],A=s[4],I=s[7],D=s[2],O=s[5],C=s[8];return r[0]=o*S+c*g+h*D,r[3]=o*E+c*A+h*O,r[6]=o*d+c*I+h*C,r[1]=u*S+p*g+a*D,r[4]=u*E+p*A+a*O,r[7]=u*d+p*I+a*C,r[2]=l*S+f*g+m*D,r[5]=l*E+f*A+m*O,r[8]=l*d+f*I+m*C,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],h=e[6],u=e[7],p=e[8];return t*o*p-t*c*u-i*r*p+i*c*h+s*r*u-s*o*h}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],h=e[6],u=e[7],p=e[8],a=p*o-c*u,l=c*h-p*r,f=u*r-o*h,m=t*a+i*l+s*f;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);const S=1/m;return e[0]=a*S,e[1]=(s*u-p*i)*S,e[2]=(c*i-s*o)*S,e[3]=l*S,e[4]=(p*t-s*h)*S,e[5]=(s*r-c*t)*S,e[6]=f*S,e[7]=(i*h-u*t)*S,e[8]=(o*t-i*r)*S,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,s,r,o,c){const h=Math.cos(r),u=Math.sin(r);return this.set(i*h,i*u,-i*(h*o+u*c)+o+e,-s*u,s*h,-s*(-u*o+h*c)+c+t,0,0,1),this}scale(e,t){return this.premultiply(Or.makeScale(e,t)),this}rotate(e){return this.premultiply(Or.makeRotation(-e)),this}translate(e,t){return this.premultiply(Or.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<9;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Or=new We,Ko=new We().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Xo=new We().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function ch(){const n={enabled:!0,workingColorSpace:Gi,spaces:{},convert:function(s,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===st&&(s.r=Nn(s.r),s.g=Nn(s.g),s.b=Nn(s.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===st&&(s.r=wi(s.r),s.g=wi(s.g),s.b=wi(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Xn?lr:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return _s("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),n.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return _s("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),n.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],i=[.3127,.329];return n.define({[Gi]:{primaries:e,whitePoint:i,transfer:lr,toXYZ:Ko,fromXYZ:Xo,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Nt},outputColorSpaceConfig:{drawingBufferColorSpace:Nt}},[Nt]:{primaries:e,whitePoint:i,transfer:st,toXYZ:Ko,fromXYZ:Xo,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Nt}}}),n}const $e=ch();function Nn(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function wi(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let Ai;class uh{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{Ai===void 0&&(Ai=ur("canvas")),Ai.width=e.width,Ai.height=e.height;const s=Ai.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),i=Ai}return i.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ur("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const s=i.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Nn(r[o]/255)*255;return i.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Nn(t[i]/255)*255):t[i]=Nn(t[i]);return{data:t,width:e.width,height:e.height}}else return Ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let hh=0;class po{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:hh++}),this.uuid=zi(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,c=s.length;o<c;o++)s[o].isDataTexture?r.push(br(s[o].image)):r.push(br(s[o]))}else r=br(s);i.url=r}return t||(e.images[this.uuid]=i),i}}function br(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?uh.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(Ke("Texture: Unable to serialize Texture."),{})}let fh=0;const Cr=new G;class Ut extends pi{constructor(e=Ut.DEFAULT_IMAGE,t=Ut.DEFAULT_MAPPING,i=On,s=On,r=en,o=ui,c=ln,h=Pn,u=Ut.DEFAULT_ANISOTROPY,p=Xn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:fh++}),this.uuid=zi(),this.name="",this.source=new po(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=u,this.format=c,this.internalFormat=null,this.type=h,this.offset=new oe(0,0),this.repeat=new oe(1,1),this.center=new oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new We,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=p,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Cr).x}get height(){return this.source.getSize(Cr).y}get depth(){return this.source.getSize(Cr).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const i=e[t];if(i===void 0){Ke(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ke(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&i&&s.isVector2&&i.isVector2||s&&i&&s.isVector3&&i.isVector3||s&&i&&s.isMatrix3&&i.isMatrix3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==ac)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ta:e.x=e.x-Math.floor(e.x);break;case On:e.x=e.x<0?0:1;break;case Ra:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Ta:e.y=e.y-Math.floor(e.y);break;case On:e.y=e.y<0?0:1;break;case Ra:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Ut.DEFAULT_IMAGE=null;Ut.DEFAULT_MAPPING=ac;Ut.DEFAULT_ANISOTROPY=1;class St{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),St.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,s){return this.x=e,this.y=t,this.z=i,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*i+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*i+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*i+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*i+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,s,r;const h=e.elements,u=h[0],p=h[4],a=h[8],l=h[1],f=h[5],m=h[9],S=h[2],E=h[6],d=h[10];if(Math.abs(p-l)<.01&&Math.abs(a-S)<.01&&Math.abs(m-E)<.01){if(Math.abs(p+l)<.1&&Math.abs(a+S)<.1&&Math.abs(m+E)<.1&&Math.abs(u+f+d-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const A=(u+1)/2,I=(f+1)/2,D=(d+1)/2,O=(p+l)/4,C=(a+S)/4,U=(m+E)/4;return A>I&&A>D?A<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(A),s=O/i,r=C/i):I>D?I<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(I),i=O/s,r=U/s):D<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(D),i=C/r,s=U/r),this.set(i,s,r,t),this}let g=Math.sqrt((E-m)*(E-m)+(a-S)*(a-S)+(l-p)*(l-p));return Math.abs(g)<.001&&(g=1),this.x=(E-m)/g,this.y=(a-S)/g,this.z=(l-p)/g,this.w=Math.acos((u+f+d-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this.w=Ze(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this.w=Ze(this.w,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class dh extends pi{constructor(e=1,t=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:en,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},i),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=i.depth,this.scissor=new St(0,0,e,t),this.scissorTest=!1,this.viewport=new St(0,0,e,t);const s={width:e,height:t,depth:i.depth},r=new Ut(s);this.textures=[];const o=i.count;for(let c=0;c<o;c++)this.textures[c]=r.clone(),this.textures[c].isRenderTargetTexture=!0,this.textures[c].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview}_setTextureOptions(e={}){const t={minFilter:en,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=i,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,i=e.textures.length;t<i;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new po(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class wn extends dh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class mc extends Ut{constructor(e=null,t=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Xt,this.minFilter=Xt,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class ph extends Ut{constructor(e=null,t=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Xt,this.minFilter=Xt,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Ki{constructor(e=new G(1/0,1/0,1/0),t=new G(-1/0,-1/0,-1/0)){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(nn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(nn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=nn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const r=i.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,c=r.count;o<c;o++)e.isMesh===!0?e.getVertexPosition(o,nn):nn.fromBufferAttribute(r,o),nn.applyMatrix4(e.matrixWorld),this.expandByPoint(nn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),bs.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),bs.copy(i.boundingBox)),bs.applyMatrix4(e.matrixWorld),this.union(bs)}const s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,nn),nn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ji),Cs.subVectors(this.max,ji),xi.subVectors(e.a,ji),_i.subVectors(e.b,ji),gi.subVectors(e.c,ji),Hn.subVectors(_i,xi),Gn.subVectors(gi,_i),ei.subVectors(xi,gi);let t=[0,-Hn.z,Hn.y,0,-Gn.z,Gn.y,0,-ei.z,ei.y,Hn.z,0,-Hn.x,Gn.z,0,-Gn.x,ei.z,0,-ei.x,-Hn.y,Hn.x,0,-Gn.y,Gn.x,0,-ei.y,ei.x,0];return!Dr(t,xi,_i,gi,Cs)||(t=[1,0,0,0,1,0,0,0,1],!Dr(t,xi,_i,gi,Cs))?!1:(Ds.crossVectors(Hn,Gn),t=[Ds.x,Ds.y,Ds.z],Dr(t,xi,_i,gi,Cs))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,nn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(nn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(_n[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),_n[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),_n[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),_n[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),_n[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),_n[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),_n[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),_n[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(_n),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const _n=[new G,new G,new G,new G,new G,new G,new G,new G],nn=new G,bs=new Ki,xi=new G,_i=new G,gi=new G,Hn=new G,Gn=new G,ei=new G,ji=new G,Cs=new G,Ds=new G,ti=new G;function Dr(n,e,t,i,s){for(let r=0,o=n.length-3;r<=o;r+=3){ti.fromArray(n,r);const c=s.x*Math.abs(ti.x)+s.y*Math.abs(ti.y)+s.z*Math.abs(ti.z),h=e.dot(ti),u=t.dot(ti),p=i.dot(ti);if(Math.max(-Math.max(h,u,p),Math.min(h,u,p))>c)return!1}return!0}const Eh=new Ki,es=new G,Nr=new G;class Eo{constructor(e=new G,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Eh.setFromPoints(e).getCenter(i);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;es.subVectors(e,this.center);const t=es.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),s=(i-this.radius)*.5;this.center.addScaledVector(es,s/i),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Nr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(es.copy(e.center).add(Nr)),this.expandByPoint(es.copy(e.center).sub(Nr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const gn=new G,Pr=new G,Ns=new G,Vn=new G,Ur=new G,Ps=new G,wr=new G;class mo{constructor(e=new G,t=new G(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,gn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=gn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(gn.copy(this.origin).addScaledVector(this.direction,t),gn.distanceToSquared(e))}distanceSqToSegment(e,t,i,s){Pr.copy(e).add(t).multiplyScalar(.5),Ns.copy(t).sub(e).normalize(),Vn.copy(this.origin).sub(Pr);const r=e.distanceTo(t)*.5,o=-this.direction.dot(Ns),c=Vn.dot(this.direction),h=-Vn.dot(Ns),u=Vn.lengthSq(),p=Math.abs(1-o*o);let a,l,f,m;if(p>0)if(a=o*h-c,l=o*c-h,m=r*p,a>=0)if(l>=-m)if(l<=m){const S=1/p;a*=S,l*=S,f=a*(a+o*l+2*c)+l*(o*a+l+2*h)+u}else l=r,a=Math.max(0,-(o*l+c)),f=-a*a+l*(l+2*h)+u;else l=-r,a=Math.max(0,-(o*l+c)),f=-a*a+l*(l+2*h)+u;else l<=-m?(a=Math.max(0,-(-o*r+c)),l=a>0?-r:Math.min(Math.max(-r,-h),r),f=-a*a+l*(l+2*h)+u):l<=m?(a=0,l=Math.min(Math.max(-r,-h),r),f=l*(l+2*h)+u):(a=Math.max(0,-(o*r+c)),l=a>0?r:Math.min(Math.max(-r,-h),r),f=-a*a+l*(l+2*h)+u);else l=o>0?-r:r,a=Math.max(0,-(o*l+c)),f=-a*a+l*(l+2*h)+u;return i&&i.copy(this.origin).addScaledVector(this.direction,a),s&&s.copy(Pr).addScaledVector(Ns,l),f}intersectSphere(e,t){gn.subVectors(e.center,this.origin);const i=gn.dot(this.direction),s=gn.dot(gn)-i*i,r=e.radius*e.radius;if(s>r)return null;const o=Math.sqrt(r-s),c=i-o,h=i+o;return h<0?null:c<0?this.at(h,t):this.at(c,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,s,r,o,c,h;const u=1/this.direction.x,p=1/this.direction.y,a=1/this.direction.z,l=this.origin;return u>=0?(i=(e.min.x-l.x)*u,s=(e.max.x-l.x)*u):(i=(e.max.x-l.x)*u,s=(e.min.x-l.x)*u),p>=0?(r=(e.min.y-l.y)*p,o=(e.max.y-l.y)*p):(r=(e.max.y-l.y)*p,o=(e.min.y-l.y)*p),i>o||r>s||((r>i||isNaN(i))&&(i=r),(o<s||isNaN(s))&&(s=o),a>=0?(c=(e.min.z-l.z)*a,h=(e.max.z-l.z)*a):(c=(e.max.z-l.z)*a,h=(e.min.z-l.z)*a),i>h||c>s)||((c>i||i!==i)&&(i=c),(h<s||s!==s)&&(s=h),s<0)?null:this.at(i>=0?i:s,t)}intersectsBox(e){return this.intersectBox(e,gn)!==null}intersectTriangle(e,t,i,s,r){Ur.subVectors(t,e),Ps.subVectors(i,e),wr.crossVectors(Ur,Ps);let o=this.direction.dot(wr),c;if(o>0){if(s)return null;c=1}else if(o<0)c=-1,o=-o;else return null;Vn.subVectors(this.origin,e);const h=c*this.direction.dot(Ps.crossVectors(Vn,Ps));if(h<0)return null;const u=c*this.direction.dot(Ur.cross(Vn));if(u<0||h+u>o)return null;const p=-c*Vn.dot(wr);return p<0?null:this.at(p/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class At{constructor(e,t,i,s,r,o,c,h,u,p,a,l,f,m,S,E){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),At.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,o,c,h,u,p,a,l,f,m,S,E)}set(e,t,i,s,r,o,c,h,u,p,a,l,f,m,S,E){const d=this.elements;return d[0]=e,d[4]=t,d[8]=i,d[12]=s,d[1]=r,d[5]=o,d[9]=c,d[13]=h,d[2]=u,d[6]=p,d[10]=a,d[14]=l,d[3]=f,d[7]=m,d[11]=S,d[15]=E,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new At().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,s=1/Ti.setFromMatrixColumn(e,0).length(),r=1/Ti.setFromMatrixColumn(e,1).length(),o=1/Ti.setFromMatrixColumn(e,2).length();return t[0]=i[0]*s,t[1]=i[1]*s,t[2]=i[2]*s,t[3]=0,t[4]=i[4]*r,t[5]=i[5]*r,t[6]=i[6]*r,t[7]=0,t[8]=i[8]*o,t[9]=i[9]*o,t[10]=i[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,s=e.y,r=e.z,o=Math.cos(i),c=Math.sin(i),h=Math.cos(s),u=Math.sin(s),p=Math.cos(r),a=Math.sin(r);if(e.order==="XYZ"){const l=o*p,f=o*a,m=c*p,S=c*a;t[0]=h*p,t[4]=-h*a,t[8]=u,t[1]=f+m*u,t[5]=l-S*u,t[9]=-c*h,t[2]=S-l*u,t[6]=m+f*u,t[10]=o*h}else if(e.order==="YXZ"){const l=h*p,f=h*a,m=u*p,S=u*a;t[0]=l+S*c,t[4]=m*c-f,t[8]=o*u,t[1]=o*a,t[5]=o*p,t[9]=-c,t[2]=f*c-m,t[6]=S+l*c,t[10]=o*h}else if(e.order==="ZXY"){const l=h*p,f=h*a,m=u*p,S=u*a;t[0]=l-S*c,t[4]=-o*a,t[8]=m+f*c,t[1]=f+m*c,t[5]=o*p,t[9]=S-l*c,t[2]=-o*u,t[6]=c,t[10]=o*h}else if(e.order==="ZYX"){const l=o*p,f=o*a,m=c*p,S=c*a;t[0]=h*p,t[4]=m*u-f,t[8]=l*u+S,t[1]=h*a,t[5]=S*u+l,t[9]=f*u-m,t[2]=-u,t[6]=c*h,t[10]=o*h}else if(e.order==="YZX"){const l=o*h,f=o*u,m=c*h,S=c*u;t[0]=h*p,t[4]=S-l*a,t[8]=m*a+f,t[1]=a,t[5]=o*p,t[9]=-c*p,t[2]=-u*p,t[6]=f*a+m,t[10]=l-S*a}else if(e.order==="XZY"){const l=o*h,f=o*u,m=c*h,S=c*u;t[0]=h*p,t[4]=-a,t[8]=u*p,t[1]=l*a+S,t[5]=o*p,t[9]=f*a-m,t[2]=m*a-f,t[6]=c*p,t[10]=S*a+l}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(mh,e,Sh)}lookAt(e,t,i){const s=this.elements;return kt.subVectors(e,t),kt.lengthSq()===0&&(kt.z=1),kt.normalize(),kn.crossVectors(i,kt),kn.lengthSq()===0&&(Math.abs(i.z)===1?kt.x+=1e-4:kt.z+=1e-4,kt.normalize(),kn.crossVectors(i,kt)),kn.normalize(),Us.crossVectors(kt,kn),s[0]=kn.x,s[4]=Us.x,s[8]=kt.x,s[1]=kn.y,s[5]=Us.y,s[9]=kt.y,s[2]=kn.z,s[6]=Us.z,s[10]=kt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,o=i[0],c=i[4],h=i[8],u=i[12],p=i[1],a=i[5],l=i[9],f=i[13],m=i[2],S=i[6],E=i[10],d=i[14],g=i[3],A=i[7],I=i[11],D=i[15],O=s[0],C=s[4],U=s[8],R=s[12],v=s[1],P=s[5],V=s[9],Z=s[13],Q=s[2],j=s[6],ie=s[10],J=s[14],B=s[3],de=s[7],pe=s[11],Me=s[15];return r[0]=o*O+c*v+h*Q+u*B,r[4]=o*C+c*P+h*j+u*de,r[8]=o*U+c*V+h*ie+u*pe,r[12]=o*R+c*Z+h*J+u*Me,r[1]=p*O+a*v+l*Q+f*B,r[5]=p*C+a*P+l*j+f*de,r[9]=p*U+a*V+l*ie+f*pe,r[13]=p*R+a*Z+l*J+f*Me,r[2]=m*O+S*v+E*Q+d*B,r[6]=m*C+S*P+E*j+d*de,r[10]=m*U+S*V+E*ie+d*pe,r[14]=m*R+S*Z+E*J+d*Me,r[3]=g*O+A*v+I*Q+D*B,r[7]=g*C+A*P+I*j+D*de,r[11]=g*U+A*V+I*ie+D*pe,r[15]=g*R+A*Z+I*J+D*Me,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],s=e[8],r=e[12],o=e[1],c=e[5],h=e[9],u=e[13],p=e[2],a=e[6],l=e[10],f=e[14],m=e[3],S=e[7],E=e[11],d=e[15];return m*(+r*h*a-s*u*a-r*c*l+i*u*l+s*c*f-i*h*f)+S*(+t*h*f-t*u*l+r*o*l-s*o*f+s*u*p-r*h*p)+E*(+t*u*a-t*c*f-r*o*a+i*o*f+r*c*p-i*u*p)+d*(-s*c*p-t*h*a+t*c*l+s*o*a-i*o*l+i*h*p)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],o=e[4],c=e[5],h=e[6],u=e[7],p=e[8],a=e[9],l=e[10],f=e[11],m=e[12],S=e[13],E=e[14],d=e[15],g=a*E*u-S*l*u+S*h*f-c*E*f-a*h*d+c*l*d,A=m*l*u-p*E*u-m*h*f+o*E*f+p*h*d-o*l*d,I=p*S*u-m*a*u+m*c*f-o*S*f-p*c*d+o*a*d,D=m*a*h-p*S*h-m*c*l+o*S*l+p*c*E-o*a*E,O=t*g+i*A+s*I+r*D;if(O===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/O;return e[0]=g*C,e[1]=(S*l*r-a*E*r-S*s*f+i*E*f+a*s*d-i*l*d)*C,e[2]=(c*E*r-S*h*r+S*s*u-i*E*u-c*s*d+i*h*d)*C,e[3]=(a*h*r-c*l*r-a*s*u+i*l*u+c*s*f-i*h*f)*C,e[4]=A*C,e[5]=(p*E*r-m*l*r+m*s*f-t*E*f-p*s*d+t*l*d)*C,e[6]=(m*h*r-o*E*r-m*s*u+t*E*u+o*s*d-t*h*d)*C,e[7]=(o*l*r-p*h*r+p*s*u-t*l*u-o*s*f+t*h*f)*C,e[8]=I*C,e[9]=(m*a*r-p*S*r-m*i*f+t*S*f+p*i*d-t*a*d)*C,e[10]=(o*S*r-m*c*r+m*i*u-t*S*u-o*i*d+t*c*d)*C,e[11]=(p*c*r-o*a*r-p*i*u+t*a*u+o*i*f-t*c*f)*C,e[12]=D*C,e[13]=(p*S*s-m*a*s+m*i*l-t*S*l-p*i*E+t*a*E)*C,e[14]=(m*c*s-o*S*s-m*i*h+t*S*h+o*i*E-t*c*E)*C,e[15]=(o*a*s-p*c*s+p*i*h-t*a*h-o*i*l+t*c*l)*C,this}scale(e){const t=this.elements,i=e.x,s=e.y,r=e.z;return t[0]*=i,t[4]*=s,t[8]*=r,t[1]*=i,t[5]*=s,t[9]*=r,t[2]*=i,t[6]*=s,t[10]*=r,t[3]*=i,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,s))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),s=Math.sin(t),r=1-i,o=e.x,c=e.y,h=e.z,u=r*o,p=r*c;return this.set(u*o+i,u*c-s*h,u*h+s*c,0,u*c+s*h,p*c+i,p*h-s*o,0,u*h-s*c,p*h+s*o,r*h*h+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,s,r,o){return this.set(1,i,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,i){const s=this.elements,r=t._x,o=t._y,c=t._z,h=t._w,u=r+r,p=o+o,a=c+c,l=r*u,f=r*p,m=r*a,S=o*p,E=o*a,d=c*a,g=h*u,A=h*p,I=h*a,D=i.x,O=i.y,C=i.z;return s[0]=(1-(S+d))*D,s[1]=(f+I)*D,s[2]=(m-A)*D,s[3]=0,s[4]=(f-I)*O,s[5]=(1-(l+d))*O,s[6]=(E+g)*O,s[7]=0,s[8]=(m+A)*C,s[9]=(E-g)*C,s[10]=(1-(l+S))*C,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,i){const s=this.elements;let r=Ti.set(s[0],s[1],s[2]).length();const o=Ti.set(s[4],s[5],s[6]).length(),c=Ti.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],sn.copy(this);const u=1/r,p=1/o,a=1/c;return sn.elements[0]*=u,sn.elements[1]*=u,sn.elements[2]*=u,sn.elements[4]*=p,sn.elements[5]*=p,sn.elements[6]*=p,sn.elements[8]*=a,sn.elements[9]*=a,sn.elements[10]*=a,t.setFromRotationMatrix(sn),i.x=r,i.y=o,i.z=c,this}makePerspective(e,t,i,s,r,o,c=mn,h=!1){const u=this.elements,p=2*r/(t-e),a=2*r/(i-s),l=(t+e)/(t-e),f=(i+s)/(i-s);let m,S;if(h)m=r/(o-r),S=o*r/(o-r);else if(c===mn)m=-(o+r)/(o-r),S=-2*o*r/(o-r);else if(c===cr)m=-o/(o-r),S=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+c);return u[0]=p,u[4]=0,u[8]=l,u[12]=0,u[1]=0,u[5]=a,u[9]=f,u[13]=0,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=-1,u[15]=0,this}makeOrthographic(e,t,i,s,r,o,c=mn,h=!1){const u=this.elements,p=2/(t-e),a=2/(i-s),l=-(t+e)/(t-e),f=-(i+s)/(i-s);let m,S;if(h)m=1/(o-r),S=o/(o-r);else if(c===mn)m=-2/(o-r),S=-(o+r)/(o-r);else if(c===cr)m=-1/(o-r),S=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+c);return u[0]=p,u[4]=0,u[8]=0,u[12]=l,u[1]=0,u[5]=a,u[9]=0,u[13]=f,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=0,u[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<16;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const Ti=new G,sn=new At,mh=new G(0,0,0),Sh=new G(1,1,1),kn=new G,Us=new G,kt=new G,qo=new At,Zo=new Un;class Fn{constructor(e=0,t=0,i=0,s=Fn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,s=this._order){return this._x=e,this._y=t,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const s=e.elements,r=s[0],o=s[4],c=s[8],h=s[1],u=s[5],p=s[9],a=s[2],l=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(Ze(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-p,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(l,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Ze(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(c,f),this._z=Math.atan2(h,u)):(this._y=Math.atan2(-a,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ze(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(-a,f),this._z=Math.atan2(-o,u)):(this._y=0,this._z=Math.atan2(h,r));break;case"ZYX":this._y=Math.asin(-Ze(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(l,f),this._z=Math.atan2(h,r)):(this._x=0,this._z=Math.atan2(-o,u));break;case"YZX":this._z=Math.asin(Ze(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(-p,u),this._y=Math.atan2(-a,r)):(this._x=0,this._y=Math.atan2(c,f));break;case"XZY":this._z=Math.asin(-Ze(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(l,u),this._y=Math.atan2(c,r)):(this._x=Math.atan2(-p,f),this._y=0);break;default:Ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return qo.makeRotationFromQuaternion(e),this.setFromRotationMatrix(qo,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Zo.setFromEuler(this),this.setFromQuaternion(Zo,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Fn.DEFAULT_ORDER="XYZ";class So{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Ah=0;const Qo=new G,Ri=new Un,Tn=new At,ws=new G,ts=new G,xh=new G,_h=new Un,Jo=new G(1,0,0),$o=new G(0,1,0),jo=new G(0,0,1),el={type:"added"},gh={type:"removed"},vi={type:"childadded",child:null},Fr={type:"childremoved",child:null};class qt extends pi{constructor(){super(),this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ah++}),this.uuid=zi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qt.DEFAULT_UP.clone();const e=new G,t=new Fn,i=new Un,s=new G(1,1,1);function r(){i.setFromEuler(t,!1)}function o(){t.setFromQuaternion(i,void 0,!1)}t._onChange(r),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new At},normalMatrix:{value:new We}}),this.matrix=new At,this.matrixWorld=new At,this.matrixAutoUpdate=qt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new So,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Ri.setFromAxisAngle(e,t),this.quaternion.multiply(Ri),this}rotateOnWorldAxis(e,t){return Ri.setFromAxisAngle(e,t),this.quaternion.premultiply(Ri),this}rotateX(e){return this.rotateOnAxis(Jo,e)}rotateY(e){return this.rotateOnAxis($o,e)}rotateZ(e){return this.rotateOnAxis(jo,e)}translateOnAxis(e,t){return Qo.copy(e).applyQuaternion(this.quaternion),this.position.add(Qo.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Jo,e)}translateY(e){return this.translateOnAxis($o,e)}translateZ(e){return this.translateOnAxis(jo,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Tn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?ws.copy(e):ws.set(e,t,i);const s=this.parent;this.updateWorldMatrix(!0,!1),ts.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Tn.lookAt(ts,ws,this.up):Tn.lookAt(ws,ts,this.up),this.quaternion.setFromRotationMatrix(Tn),s&&(Tn.extractRotation(s.matrixWorld),Ri.setFromRotationMatrix(Tn),this.quaternion.premultiply(Ri.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(dt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(el),vi.child=e,this.dispatchEvent(vi),vi.child=null):dt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(gh),Fr.child=e,this.dispatchEvent(Fr),Fr.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Tn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Tn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Tn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(el),vi.child=e,this.dispatchEvent(vi),vi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,s=this.children.length;i<s;i++){const o=this.children[i].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ts,e,xh),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ts,_h,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(c=>({...c,boundingBox:c.boundingBox?c.boundingBox.toJSON():void 0,boundingSphere:c.boundingSphere?c.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(c=>({...c})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(c,h){return c[h.uuid]===void 0&&(c[h.uuid]=h.toJSON(e)),h.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const c=this.geometry.parameters;if(c!==void 0&&c.shapes!==void 0){const h=c.shapes;if(Array.isArray(h))for(let u=0,p=h.length;u<p;u++){const a=h[u];r(e.shapes,a)}else r(e.shapes,h)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const c=[];for(let h=0,u=this.material.length;h<u;h++)c.push(r(e.materials,this.material[h]));s.material=c}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let c=0;c<this.children.length;c++)s.children.push(this.children[c].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let c=0;c<this.animations.length;c++){const h=this.animations[c];s.animations.push(r(e.animations,h))}}if(t){const c=o(e.geometries),h=o(e.materials),u=o(e.textures),p=o(e.images),a=o(e.shapes),l=o(e.skeletons),f=o(e.animations),m=o(e.nodes);c.length>0&&(i.geometries=c),h.length>0&&(i.materials=h),u.length>0&&(i.textures=u),p.length>0&&(i.images=p),a.length>0&&(i.shapes=a),l.length>0&&(i.skeletons=l),f.length>0&&(i.animations=f),m.length>0&&(i.nodes=m)}return i.object=s,i;function o(c){const h=[];for(const u in c){const p=c[u];delete p.metadata,h.push(p)}return h}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const s=e.children[i];this.add(s.clone())}return this}}qt.DEFAULT_UP=new G(0,1,0);qt.DEFAULT_MATRIX_AUTO_UPDATE=!0;qt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const rn=new G,Rn=new G,Br=new G,vn=new G,Mi=new G,Ii=new G,tl=new G,Hr=new G,Gr=new G,Vr=new G,kr=new St,Yr=new St,Wr=new St;class on{constructor(e=new G,t=new G,i=new G){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,s){s.subVectors(i,t),rn.subVectors(e,t),s.cross(rn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,i,s,r){rn.subVectors(s,t),Rn.subVectors(i,t),Br.subVectors(e,t);const o=rn.dot(rn),c=rn.dot(Rn),h=rn.dot(Br),u=Rn.dot(Rn),p=Rn.dot(Br),a=o*u-c*c;if(a===0)return r.set(0,0,0),null;const l=1/a,f=(u*h-c*p)*l,m=(o*p-c*h)*l;return r.set(1-f-m,m,f)}static containsPoint(e,t,i,s){return this.getBarycoord(e,t,i,s,vn)===null?!1:vn.x>=0&&vn.y>=0&&vn.x+vn.y<=1}static getInterpolation(e,t,i,s,r,o,c,h){return this.getBarycoord(e,t,i,s,vn)===null?(h.x=0,h.y=0,"z"in h&&(h.z=0),"w"in h&&(h.w=0),null):(h.setScalar(0),h.addScaledVector(r,vn.x),h.addScaledVector(o,vn.y),h.addScaledVector(c,vn.z),h)}static getInterpolatedAttribute(e,t,i,s,r,o){return kr.setScalar(0),Yr.setScalar(0),Wr.setScalar(0),kr.fromBufferAttribute(e,t),Yr.fromBufferAttribute(e,i),Wr.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(kr,r.x),o.addScaledVector(Yr,r.y),o.addScaledVector(Wr,r.z),o}static isFrontFacing(e,t,i,s){return rn.subVectors(i,t),Rn.subVectors(e,t),rn.cross(Rn).dot(s)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,s){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,i,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return rn.subVectors(this.c,this.b),Rn.subVectors(this.a,this.b),rn.cross(Rn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return on.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return on.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,s,r){return on.getInterpolation(e,this.a,this.b,this.c,t,i,s,r)}containsPoint(e){return on.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return on.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,s=this.b,r=this.c;let o,c;Mi.subVectors(s,i),Ii.subVectors(r,i),Hr.subVectors(e,i);const h=Mi.dot(Hr),u=Ii.dot(Hr);if(h<=0&&u<=0)return t.copy(i);Gr.subVectors(e,s);const p=Mi.dot(Gr),a=Ii.dot(Gr);if(p>=0&&a<=p)return t.copy(s);const l=h*a-p*u;if(l<=0&&h>=0&&p<=0)return o=h/(h-p),t.copy(i).addScaledVector(Mi,o);Vr.subVectors(e,r);const f=Mi.dot(Vr),m=Ii.dot(Vr);if(m>=0&&f<=m)return t.copy(r);const S=f*u-h*m;if(S<=0&&u>=0&&m<=0)return c=u/(u-m),t.copy(i).addScaledVector(Ii,c);const E=p*m-f*a;if(E<=0&&a-p>=0&&f-m>=0)return tl.subVectors(r,s),c=(a-p)/(a-p+(f-m)),t.copy(s).addScaledVector(tl,c);const d=1/(E+S+l);return o=S*d,c=l*d,t.copy(i).addScaledVector(Mi,o).addScaledVector(Ii,c)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Sc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Yn={h:0,s:0,l:0},Fs={h:0,s:0,l:0};function zr(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class et{constructor(e,t,i){return this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Nt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,$e.colorSpaceToWorking(this,t),this}setRGB(e,t,i,s=$e.workingColorSpace){return this.r=e,this.g=t,this.b=i,$e.colorSpaceToWorking(this,s),this}setHSL(e,t,i,s=$e.workingColorSpace){if(e=oh(e,1),t=Ze(t,0,1),i=Ze(i,0,1),t===0)this.r=this.g=this.b=i;else{const r=i<=.5?i*(1+t):i+t-i*t,o=2*i-r;this.r=zr(o,r,e+1/3),this.g=zr(o,r,e),this.b=zr(o,r,e-1/3)}return $e.colorSpaceToWorking(this,s),this}setStyle(e,t=Nt){function i(r){r!==void 0&&parseFloat(r)<1&&Ke("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const o=s[1],c=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(c))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:Ke("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);Ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Nt){const i=Sc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):Ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Nn(e.r),this.g=Nn(e.g),this.b=Nn(e.b),this}copyLinearToSRGB(e){return this.r=wi(e.r),this.g=wi(e.g),this.b=wi(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Nt){return $e.workingToColorSpace(Ot.copy(this),e),Math.round(Ze(Ot.r*255,0,255))*65536+Math.round(Ze(Ot.g*255,0,255))*256+Math.round(Ze(Ot.b*255,0,255))}getHexString(e=Nt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=$e.workingColorSpace){$e.workingToColorSpace(Ot.copy(this),t);const i=Ot.r,s=Ot.g,r=Ot.b,o=Math.max(i,s,r),c=Math.min(i,s,r);let h,u;const p=(c+o)/2;if(c===o)h=0,u=0;else{const a=o-c;switch(u=p<=.5?a/(o+c):a/(2-o-c),o){case i:h=(s-r)/a+(s<r?6:0);break;case s:h=(r-i)/a+2;break;case r:h=(i-s)/a+4;break}h/=6}return e.h=h,e.s=u,e.l=p,e}getRGB(e,t=$e.workingColorSpace){return $e.workingToColorSpace(Ot.copy(this),t),e.r=Ot.r,e.g=Ot.g,e.b=Ot.b,e}getStyle(e=Nt){$e.workingToColorSpace(Ot.copy(this),e);const t=Ot.r,i=Ot.g,s=Ot.b;return e!==Nt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(e,t,i){return this.getHSL(Yn),this.setHSL(Yn.h+e,Yn.s+t,Yn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Yn),e.getHSL(Fs);const i=Lr(Yn.h,Fs.h,t),s=Lr(Yn.s,Fs.s,t),r=Lr(Yn.l,Fs.l,t);return this.setHSL(i,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*i+r[6]*s,this.g=r[1]*t+r[4]*i+r[7]*s,this.b=r[2]*t+r[5]*i+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ot=new et;et.NAMES=Sc;let Th=0;class Ar extends pi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Th++}),this.uuid=zi(),this.name="",this.type="Material",this.blending=Ui,this.side=An,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ha,this.blendDst=fa,this.blendEquation=oi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new et(0,0,0),this.blendAlpha=0,this.depthFunc=Fi,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Go,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Si,this.stencilZFail=Si,this.stencilZPass=Si,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){Ke(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ke(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Ui&&(i.blending=this.blending),this.side!==An&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==ha&&(i.blendSrc=this.blendSrc),this.blendDst!==fa&&(i.blendDst=this.blendDst),this.blendEquation!==oi&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==Fi&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Go&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Si&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Si&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Si&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){const o=[];for(const c in r){const h=r[c];delete h.metadata,o.push(h)}return o}if(t){const r=s(e.textures),o=s(e.images);r.length>0&&(i.textures=r),o.length>0&&(i.images=o)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const s=t.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=t[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Kt extends Ar{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new et(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Fn,this.combine=rc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const xt=new G,Bs=new oe;let Rh=0;class un{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Rh++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Vo,this.updateRanges=[],this.gpuType=bn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[i+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Bs.fromBufferAttribute(this,t),Bs.applyMatrix3(e),this.setXY(t,Bs.x,Bs.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix3(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix4(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyNormalMatrix(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.transformDirection(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=$i(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Bt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=$i(t,this.array)),t}setX(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=$i(t,this.array)),t}setY(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=$i(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=$i(t,this.array)),t}setW(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,s){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this}setXYZW(e,t,i,s,r){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array),r=Bt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Vo&&(e.usage=this.usage),e}}class Ac extends un{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class xc extends un{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class _t extends un{constructor(e,t,i){super(new Float32Array(e),t,i)}}let vh=0;const Qt=new At,Kr=new qt,Li=new G,Yt=new Ki,ns=new Ki,It=new G;class Rt extends pi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:vh++}),this.uuid=zi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Ec(e)?xc:Ac)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const r=new We().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Qt.makeRotationFromQuaternion(e),this.applyMatrix4(Qt),this}rotateX(e){return Qt.makeRotationX(e),this.applyMatrix4(Qt),this}rotateY(e){return Qt.makeRotationY(e),this.applyMatrix4(Qt),this}rotateZ(e){return Qt.makeRotationZ(e),this.applyMatrix4(Qt),this}translate(e,t,i){return Qt.makeTranslation(e,t,i),this.applyMatrix4(Qt),this}scale(e,t,i){return Qt.makeScale(e,t,i),this.applyMatrix4(Qt),this}lookAt(e){return Kr.lookAt(e),Kr.updateMatrix(),this.applyMatrix4(Kr.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Li).negate(),this.translate(Li.x,Li.y,Li.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const i=[];for(let s=0,r=e.length;s<r;s++){const o=e[s];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new _t(i,3))}else{const i=Math.min(e.length,t.count);for(let s=0;s<i;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&Ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ki);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new G(-1/0,-1/0,-1/0),new G(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,s=t.length;i<s;i++){const r=t[i];Yt.setFromBufferAttribute(r),this.morphTargetsRelative?(It.addVectors(this.boundingBox.min,Yt.min),this.boundingBox.expandByPoint(It),It.addVectors(this.boundingBox.max,Yt.max),this.boundingBox.expandByPoint(It)):(this.boundingBox.expandByPoint(Yt.min),this.boundingBox.expandByPoint(Yt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&dt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Eo);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new G,1/0);return}if(e){const i=this.boundingSphere.center;if(Yt.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){const c=t[r];ns.setFromBufferAttribute(c),this.morphTargetsRelative?(It.addVectors(Yt.min,ns.min),Yt.expandByPoint(It),It.addVectors(Yt.max,ns.max),Yt.expandByPoint(It)):(Yt.expandByPoint(ns.min),Yt.expandByPoint(ns.max))}Yt.getCenter(i);let s=0;for(let r=0,o=e.count;r<o;r++)It.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(It));if(t)for(let r=0,o=t.length;r<o;r++){const c=t[r],h=this.morphTargetsRelative;for(let u=0,p=c.count;u<p;u++)It.fromBufferAttribute(c,u),h&&(Li.fromBufferAttribute(e,u),It.add(Li)),s=Math.max(s,i.distanceToSquared(It))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&dt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){dt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new un(new Float32Array(4*i.count),4));const o=this.getAttribute("tangent"),c=[],h=[];for(let U=0;U<i.count;U++)c[U]=new G,h[U]=new G;const u=new G,p=new G,a=new G,l=new oe,f=new oe,m=new oe,S=new G,E=new G;function d(U,R,v){u.fromBufferAttribute(i,U),p.fromBufferAttribute(i,R),a.fromBufferAttribute(i,v),l.fromBufferAttribute(r,U),f.fromBufferAttribute(r,R),m.fromBufferAttribute(r,v),p.sub(u),a.sub(u),f.sub(l),m.sub(l);const P=1/(f.x*m.y-m.x*f.y);isFinite(P)&&(S.copy(p).multiplyScalar(m.y).addScaledVector(a,-f.y).multiplyScalar(P),E.copy(a).multiplyScalar(f.x).addScaledVector(p,-m.x).multiplyScalar(P),c[U].add(S),c[R].add(S),c[v].add(S),h[U].add(E),h[R].add(E),h[v].add(E))}let g=this.groups;g.length===0&&(g=[{start:0,count:e.count}]);for(let U=0,R=g.length;U<R;++U){const v=g[U],P=v.start,V=v.count;for(let Z=P,Q=P+V;Z<Q;Z+=3)d(e.getX(Z+0),e.getX(Z+1),e.getX(Z+2))}const A=new G,I=new G,D=new G,O=new G;function C(U){D.fromBufferAttribute(s,U),O.copy(D);const R=c[U];A.copy(R),A.sub(D.multiplyScalar(D.dot(R))).normalize(),I.crossVectors(O,R);const P=I.dot(h[U])<0?-1:1;o.setXYZW(U,A.x,A.y,A.z,P)}for(let U=0,R=g.length;U<R;++U){const v=g[U],P=v.start,V=v.count;for(let Z=P,Q=P+V;Z<Q;Z+=3)C(e.getX(Z+0)),C(e.getX(Z+1)),C(e.getX(Z+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new un(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let l=0,f=i.count;l<f;l++)i.setXYZ(l,0,0,0);const s=new G,r=new G,o=new G,c=new G,h=new G,u=new G,p=new G,a=new G;if(e)for(let l=0,f=e.count;l<f;l+=3){const m=e.getX(l+0),S=e.getX(l+1),E=e.getX(l+2);s.fromBufferAttribute(t,m),r.fromBufferAttribute(t,S),o.fromBufferAttribute(t,E),p.subVectors(o,r),a.subVectors(s,r),p.cross(a),c.fromBufferAttribute(i,m),h.fromBufferAttribute(i,S),u.fromBufferAttribute(i,E),c.add(p),h.add(p),u.add(p),i.setXYZ(m,c.x,c.y,c.z),i.setXYZ(S,h.x,h.y,h.z),i.setXYZ(E,u.x,u.y,u.z)}else for(let l=0,f=t.count;l<f;l+=3)s.fromBufferAttribute(t,l+0),r.fromBufferAttribute(t,l+1),o.fromBufferAttribute(t,l+2),p.subVectors(o,r),a.subVectors(s,r),p.cross(a),i.setXYZ(l+0,p.x,p.y,p.z),i.setXYZ(l+1,p.x,p.y,p.z),i.setXYZ(l+2,p.x,p.y,p.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)It.fromBufferAttribute(e,t),It.normalize(),e.setXYZ(t,It.x,It.y,It.z)}toNonIndexed(){function e(c,h){const u=c.array,p=c.itemSize,a=c.normalized,l=new u.constructor(h.length*p);let f=0,m=0;for(let S=0,E=h.length;S<E;S++){c.isInterleavedBufferAttribute?f=h[S]*c.data.stride+c.offset:f=h[S]*p;for(let d=0;d<p;d++)l[m++]=u[f++]}return new un(l,p,a)}if(this.index===null)return Ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Rt,i=this.index.array,s=this.attributes;for(const c in s){const h=s[c],u=e(h,i);t.setAttribute(c,u)}const r=this.morphAttributes;for(const c in r){const h=[],u=r[c];for(let p=0,a=u.length;p<a;p++){const l=u[p],f=e(l,i);h.push(f)}t.morphAttributes[c]=h}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let c=0,h=o.length;c<h;c++){const u=o[c];t.addGroup(u.start,u.count,u.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const h=this.parameters;for(const u in h)h[u]!==void 0&&(e[u]=h[u]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const h in i){const u=i[h];e.data.attributes[h]=u.toJSON(e.data)}const s={};let r=!1;for(const h in this.morphAttributes){const u=this.morphAttributes[h],p=[];for(let a=0,l=u.length;a<l;a++){const f=u[a];p.push(f.toJSON(e.data))}p.length>0&&(s[h]=p,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const c=this.boundingSphere;return c!==null&&(e.data.boundingSphere=c.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone());const s=e.attributes;for(const u in s){const p=s[u];this.setAttribute(u,p.clone(t))}const r=e.morphAttributes;for(const u in r){const p=[],a=r[u];for(let l=0,f=a.length;l<f;l++)p.push(a[l].clone(t));this.morphAttributes[u]=p}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let u=0,p=o.length;u<p;u++){const a=o[u];this.addGroup(a.start,a.count,a.materialIndex)}const c=e.boundingBox;c!==null&&(this.boundingBox=c.clone());const h=e.boundingSphere;return h!==null&&(this.boundingSphere=h.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const nl=new At,ni=new mo,Hs=new Eo,il=new G,Gs=new G,Vs=new G,ks=new G,Xr=new G,Ys=new G,sl=new G,Ws=new G;class Tt extends qt{constructor(e=new Rt,t=new Kt){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const s=t[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){const c=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[c]=r}}}}getVertexPosition(e,t){const i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,o=i.morphTargetsRelative;t.fromBufferAttribute(s,e);const c=this.morphTargetInfluences;if(r&&c){Ys.set(0,0,0);for(let h=0,u=r.length;h<u;h++){const p=c[h],a=r[h];p!==0&&(Xr.fromBufferAttribute(a,e),o?Ys.addScaledVector(Xr,p):Ys.addScaledVector(Xr.sub(t),p))}t.add(Ys)}return t}raycast(e,t){const i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Hs.copy(i.boundingSphere),Hs.applyMatrix4(r),ni.copy(e.ray).recast(e.near),!(Hs.containsPoint(ni.origin)===!1&&(ni.intersectSphere(Hs,il)===null||ni.origin.distanceToSquared(il)>(e.far-e.near)**2))&&(nl.copy(r).invert(),ni.copy(e.ray).applyMatrix4(nl),!(i.boundingBox!==null&&ni.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,ni)))}_computeIntersections(e,t,i){let s;const r=this.geometry,o=this.material,c=r.index,h=r.attributes.position,u=r.attributes.uv,p=r.attributes.uv1,a=r.attributes.normal,l=r.groups,f=r.drawRange;if(c!==null)if(Array.isArray(o))for(let m=0,S=l.length;m<S;m++){const E=l[m],d=o[E.materialIndex],g=Math.max(E.start,f.start),A=Math.min(c.count,Math.min(E.start+E.count,f.start+f.count));for(let I=g,D=A;I<D;I+=3){const O=c.getX(I),C=c.getX(I+1),U=c.getX(I+2);s=zs(this,d,e,i,u,p,a,O,C,U),s&&(s.faceIndex=Math.floor(I/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,f.start),S=Math.min(c.count,f.start+f.count);for(let E=m,d=S;E<d;E+=3){const g=c.getX(E),A=c.getX(E+1),I=c.getX(E+2);s=zs(this,o,e,i,u,p,a,g,A,I),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}else if(h!==void 0)if(Array.isArray(o))for(let m=0,S=l.length;m<S;m++){const E=l[m],d=o[E.materialIndex],g=Math.max(E.start,f.start),A=Math.min(h.count,Math.min(E.start+E.count,f.start+f.count));for(let I=g,D=A;I<D;I+=3){const O=I,C=I+1,U=I+2;s=zs(this,d,e,i,u,p,a,O,C,U),s&&(s.faceIndex=Math.floor(I/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,f.start),S=Math.min(h.count,f.start+f.count);for(let E=m,d=S;E<d;E+=3){const g=E,A=E+1,I=E+2;s=zs(this,o,e,i,u,p,a,g,A,I),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}}}function Mh(n,e,t,i,s,r,o,c){let h;if(e.side===Lt?h=i.intersectTriangle(o,r,s,!0,c):h=i.intersectTriangle(s,r,o,e.side===An,c),h===null)return null;Ws.copy(c),Ws.applyMatrix4(n.matrixWorld);const u=t.ray.origin.distanceTo(Ws);return u<t.near||u>t.far?null:{distance:u,point:Ws.clone(),object:n}}function zs(n,e,t,i,s,r,o,c,h,u){n.getVertexPosition(c,Gs),n.getVertexPosition(h,Vs),n.getVertexPosition(u,ks);const p=Mh(n,e,t,i,Gs,Vs,ks,sl);if(p){const a=new G;on.getBarycoord(sl,Gs,Vs,ks,a),s&&(p.uv=on.getInterpolatedAttribute(s,c,h,u,a,new oe)),r&&(p.uv1=on.getInterpolatedAttribute(r,c,h,u,a,new oe)),o&&(p.normal=on.getInterpolatedAttribute(o,c,h,u,a,new G),p.normal.dot(i.direction)>0&&p.normal.multiplyScalar(-1));const l={a:c,b:h,c:u,normal:new G,materialIndex:0};on.getNormal(Gs,Vs,ks,l.normal),p.face=l,p.barycoord=a}return p}class Ei extends Rt{constructor(e=1,t=1,i=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:s,heightSegments:r,depthSegments:o};const c=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);const h=[],u=[],p=[],a=[];let l=0,f=0;m("z","y","x",-1,-1,i,t,e,o,r,0),m("z","y","x",1,-1,i,t,-e,o,r,1),m("x","z","y",1,1,e,i,t,s,o,2),m("x","z","y",1,-1,e,i,-t,s,o,3),m("x","y","z",1,-1,e,t,i,s,r,4),m("x","y","z",-1,-1,e,t,-i,s,r,5),this.setIndex(h),this.setAttribute("position",new _t(u,3)),this.setAttribute("normal",new _t(p,3)),this.setAttribute("uv",new _t(a,2));function m(S,E,d,g,A,I,D,O,C,U,R){const v=I/C,P=D/U,V=I/2,Z=D/2,Q=O/2,j=C+1,ie=U+1;let J=0,B=0;const de=new G;for(let pe=0;pe<ie;pe++){const Me=pe*P-Z;for(let He=0;He<j;He++){const Ce=He*v-V;de[S]=Ce*g,de[E]=Me*A,de[d]=Q,u.push(de.x,de.y,de.z),de[S]=0,de[E]=0,de[d]=O>0?1:-1,p.push(de.x,de.y,de.z),a.push(He/C),a.push(1-pe/U),J+=1}}for(let pe=0;pe<U;pe++)for(let Me=0;Me<C;Me++){const He=l+Me+j*pe,Ce=l+Me+j*(pe+1),W=l+(Me+1)+j*(pe+1),w=l+(Me+1)+j*pe;h.push(He,Ce,w),h.push(Ce,W,w),B+=6}c.addGroup(f,B,R),f+=B,l+=J}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ei(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Vi(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const s=n[t][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(Ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=s.clone():Array.isArray(s)?e[t][i]=s.slice():e[t][i]=s}}return e}function Ct(n){const e={};for(let t=0;t<n.length;t++){const i=Vi(n[t]);for(const s in i)e[s]=i[s]}return e}function Ih(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function _c(n){const e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:$e.workingColorSpace}const Lh={clone:Vi,merge:Ct};var yh=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Oh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Bn extends Ar{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=yh,this.fragmentShader=Oh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Vi(e.uniforms),this.uniformsGroups=Ih(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class gc extends qt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new At,this.projectionMatrix=new At,this.projectionMatrixInverse=new At,this.coordinateSystem=mn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Wn=new G,rl=new oe,al=new oe;class jt extends gc{constructor(e=50,t=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=$a*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(rr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return $a*2*Math.atan(Math.tan(rr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){Wn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Wn.x,Wn.y).multiplyScalar(-e/Wn.z),Wn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Wn.x,Wn.y).multiplyScalar(-e/Wn.z)}getViewSize(e,t){return this.getViewBounds(e,rl,al),t.subVectors(al,rl)}setViewOffset(e,t,i,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(rr*.5*this.fov)/this.zoom,i=2*t,s=this.aspect*i,r=-.5*s;const o=this.view;if(this.view!==null&&this.view.enabled){const h=o.fullWidth,u=o.fullHeight;r+=o.offsetX*s/h,t-=o.offsetY*i/u,s*=o.width/h,i*=o.height/u}const c=this.filmOffset;c!==0&&(r+=e*c/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const yi=-90,Oi=1;class bh extends qt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new jt(yi,Oi,e,t);s.layers=this.layers,this.add(s);const r=new jt(yi,Oi,e,t);r.layers=this.layers,this.add(r);const o=new jt(yi,Oi,e,t);o.layers=this.layers,this.add(o);const c=new jt(yi,Oi,e,t);c.layers=this.layers,this.add(c);const h=new jt(yi,Oi,e,t);h.layers=this.layers,this.add(h);const u=new jt(yi,Oi,e,t);u.layers=this.layers,this.add(u)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,s,r,o,c,h]=t;for(const u of t)this.remove(u);if(e===mn)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),c.up.set(0,1,0),c.lookAt(0,0,1),h.up.set(0,1,0),h.lookAt(0,0,-1);else if(e===cr)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),c.up.set(0,-1,0),c.lookAt(0,0,1),h.up.set(0,-1,0),h.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const u of t)this.add(u),u.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,o,c,h,u,p]=this.children,a=e.getRenderTarget(),l=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;const S=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,s),e.render(t,r),e.setRenderTarget(i,1,s),e.render(t,o),e.setRenderTarget(i,2,s),e.render(t,c),e.setRenderTarget(i,3,s),e.render(t,h),e.setRenderTarget(i,4,s),e.render(t,u),i.texture.generateMipmaps=S,e.setRenderTarget(i,5,s),e.render(t,p),e.setRenderTarget(a,l,f),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}}class Tc extends Ut{constructor(e=[],t=Bi,i,s,r,o,c,h,u,p){super(e,t,i,s,r,o,c,h,u,p),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Ch extends wn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},s=[i,i,i,i,i,i];this.texture=new Tc(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Ei(5,5,5),r=new Bn({name:"CubemapFromEquirect",uniforms:Vi(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Lt,blending:Dn});r.uniforms.tEquirect.value=t;const o=new Tt(s,r),c=t.minFilter;return t.minFilter===ui&&(t.minFilter=en),new bh(1,10,this).update(e,o),t.minFilter=c,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,i=!0,s=!0){const r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,i,s);e.setRenderTarget(r)}}class Cn extends qt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Dh={type:"move"};class qr{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Cn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Cn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new G,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new G),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Cn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new G,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new G),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let s=null,r=null,o=null;const c=this._targetRay,h=this._grip,u=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(u&&e.hand){o=!0;for(const S of e.hand.values()){const E=t.getJointPose(S,i),d=this._getHandJoint(u,S);E!==null&&(d.matrix.fromArray(E.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=E.radius),d.visible=E!==null}const p=u.joints["index-finger-tip"],a=u.joints["thumb-tip"],l=p.position.distanceTo(a.position),f=.02,m=.005;u.inputState.pinching&&l>f+m?(u.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!u.inputState.pinching&&l<=f-m&&(u.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else h!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,i),r!==null&&(h.matrix.fromArray(r.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,r.linearVelocity?(h.hasLinearVelocity=!0,h.linearVelocity.copy(r.linearVelocity)):h.hasLinearVelocity=!1,r.angularVelocity?(h.hasAngularVelocity=!0,h.angularVelocity.copy(r.angularVelocity)):h.hasAngularVelocity=!1));c!==null&&(s=t.getPose(e.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1,this.dispatchEvent(Dh)))}return c!==null&&(c.visible=s!==null),h!==null&&(h.visible=r!==null),u!==null&&(u.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new Cn;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class Nh extends qt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Fn,this.environmentIntensity=1,this.environmentRotation=new Fn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class Ph extends Ut{constructor(e=null,t=1,i=1,s,r,o,c,h,u=Xt,p=Xt,a,l){super(null,o,c,h,u,p,s,r,a,l),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Zr=new G,Uh=new G,wh=new We;class yn{constructor(e=new G(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,s){return this.normal.set(e,t,i),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const s=Zr.subVectors(i,t).cross(Uh.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(Zr),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||wh.getNormalMatrix(e),s=this.coplanarPoint(Zr).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ii=new Eo,Fh=new oe(.5,.5),Ks=new G;class Rc{constructor(e=new yn,t=new yn,i=new yn,s=new yn,r=new yn,o=new yn){this.planes=[e,t,i,s,r,o]}set(e,t,i,s,r,o){const c=this.planes;return c[0].copy(e),c[1].copy(t),c[2].copy(i),c[3].copy(s),c[4].copy(r),c[5].copy(o),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=mn,i=!1){const s=this.planes,r=e.elements,o=r[0],c=r[1],h=r[2],u=r[3],p=r[4],a=r[5],l=r[6],f=r[7],m=r[8],S=r[9],E=r[10],d=r[11],g=r[12],A=r[13],I=r[14],D=r[15];if(s[0].setComponents(u-o,f-p,d-m,D-g).normalize(),s[1].setComponents(u+o,f+p,d+m,D+g).normalize(),s[2].setComponents(u+c,f+a,d+S,D+A).normalize(),s[3].setComponents(u-c,f-a,d-S,D-A).normalize(),i)s[4].setComponents(h,l,E,I).normalize(),s[5].setComponents(u-h,f-l,d-E,D-I).normalize();else if(s[4].setComponents(u-h,f-l,d-E,D-I).normalize(),t===mn)s[5].setComponents(u+h,f+l,d+E,D+I).normalize();else if(t===cr)s[5].setComponents(h,l,E,I).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ii.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ii.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ii)}intersectsSprite(e){ii.center.set(0,0,0);const t=Fh.distanceTo(e.center);return ii.radius=.7071067811865476+t,ii.applyMatrix4(e.matrixWorld),this.intersectsSphere(ii)}intersectsSphere(e){const t=this.planes,i=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const s=t[i];if(Ks.x=s.normal.x>0?e.max.x:e.min.x,Ks.y=s.normal.y>0?e.max.y:e.min.y,Ks.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(Ks)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class vc extends Ut{constructor(e,t,i=fi,s,r,o,c=Xt,h=Xt,u,p=As,a=1){if(p!==As&&p!==xs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const l={width:e,height:t,depth:a};super(l,s,r,o,c,h,p,i,u),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new po(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Mc extends Ut{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class xn{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Ke("Curve: .getPoint() not implemented.")}getPointAt(e,t){const i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let i,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)i=this.getPoint(o/e),r+=i.distanceTo(s),t.push(r),s=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const i=this.getLengths();let s=0;const r=i.length;let o;t?o=t:o=e*i[r-1];let c=0,h=r-1,u;for(;c<=h;)if(s=Math.floor(c+(h-c)/2),u=i[s]-o,u<0)c=s+1;else if(u>0)h=s-1;else{h=s;break}if(s=h,i[s]===o)return s/(r-1);const p=i[s],l=i[s+1]-p,f=(o-p)/l;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const o=this.getPoint(s),c=this.getPoint(r),h=t||(o.isVector2?new oe:new G);return h.copy(c).sub(o).normalize(),h}getTangentAt(e,t){const i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t=!1){const i=new G,s=[],r=[],o=[],c=new G,h=new At;for(let f=0;f<=e;f++){const m=f/e;s[f]=this.getTangentAt(m,new G)}r[0]=new G,o[0]=new G;let u=Number.MAX_VALUE;const p=Math.abs(s[0].x),a=Math.abs(s[0].y),l=Math.abs(s[0].z);p<=u&&(u=p,i.set(1,0,0)),a<=u&&(u=a,i.set(0,1,0)),l<=u&&i.set(0,0,1),c.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],c),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),c.crossVectors(s[f-1],s[f]),c.length()>Number.EPSILON){c.normalize();const m=Math.acos(Ze(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(h.makeRotationAxis(c,m))}o[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(Ze(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(c.crossVectors(r[0],r[e]))>0&&(f=-f);for(let m=1;m<=e;m++)r[m].applyMatrix4(h.makeRotationAxis(s[m],f*m)),o[m].crossVectors(s[m],r[m])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Ao extends xn{constructor(e=0,t=0,i=1,s=1,r=0,o=Math.PI*2,c=!1,h=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=c,this.aRotation=h}getPoint(e,t=new oe){const i=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);const c=this.aStartAngle+e*r;let h=this.aX+this.xRadius*Math.cos(c),u=this.aY+this.yRadius*Math.sin(c);if(this.aRotation!==0){const p=Math.cos(this.aRotation),a=Math.sin(this.aRotation),l=h-this.aX,f=u-this.aY;h=l*p-f*a+this.aX,u=l*a+f*p+this.aY}return i.set(h,u)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class Bh extends Ao{constructor(e,t,i,s,r,o){super(e,t,i,i,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}}function xo(){let n=0,e=0,t=0,i=0;function s(r,o,c,h){n=r,e=c,t=-3*r+3*o-2*c-h,i=2*r-2*o+c+h}return{initCatmullRom:function(r,o,c,h,u){s(o,c,u*(c-r),u*(h-o))},initNonuniformCatmullRom:function(r,o,c,h,u,p,a){let l=(o-r)/u-(c-r)/(u+p)+(c-o)/p,f=(c-o)/p-(h-o)/(p+a)+(h-c)/a;l*=p,f*=p,s(o,c,l,f)},calc:function(r){const o=r*r,c=o*r;return n+e*r+t*o+i*c}}}const Xs=new G,Qr=new xo,Jr=new xo,$r=new xo;class Hh extends xn{constructor(e=[],t=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=s}getPoint(e,t=new G){const i=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e;let c=Math.floor(o),h=o-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/r)+1)*r:h===0&&c===r-1&&(c=r-2,h=1);let u,p;this.closed||c>0?u=s[(c-1)%r]:(Xs.subVectors(s[0],s[1]).add(s[0]),u=Xs);const a=s[c%r],l=s[(c+1)%r];if(this.closed||c+2<r?p=s[(c+2)%r]:(Xs.subVectors(s[r-1],s[r-2]).add(s[r-1]),p=Xs),this.curveType==="centripetal"||this.curveType==="chordal"){const f=this.curveType==="chordal"?.5:.25;let m=Math.pow(u.distanceToSquared(a),f),S=Math.pow(a.distanceToSquared(l),f),E=Math.pow(l.distanceToSquared(p),f);S<1e-4&&(S=1),m<1e-4&&(m=S),E<1e-4&&(E=S),Qr.initNonuniformCatmullRom(u.x,a.x,l.x,p.x,m,S,E),Jr.initNonuniformCatmullRom(u.y,a.y,l.y,p.y,m,S,E),$r.initNonuniformCatmullRom(u.z,a.z,l.z,p.z,m,S,E)}else this.curveType==="catmullrom"&&(Qr.initCatmullRom(u.x,a.x,l.x,p.x,this.tension),Jr.initCatmullRom(u.y,a.y,l.y,p.y,this.tension),$r.initCatmullRom(u.z,a.z,l.z,p.z,this.tension));return i.set(Qr.calc(h),Jr.calc(h),$r.calc(h)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new G().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function ol(n,e,t,i,s){const r=(i-e)*.5,o=(s-t)*.5,c=n*n,h=n*c;return(2*t-2*i+r+o)*h+(-3*t+3*i-2*r-o)*c+r*n+t}function Gh(n,e){const t=1-n;return t*t*e}function Vh(n,e){return 2*(1-n)*n*e}function kh(n,e){return n*n*e}function us(n,e,t,i){return Gh(n,e)+Vh(n,t)+kh(n,i)}function Yh(n,e){const t=1-n;return t*t*t*e}function Wh(n,e){const t=1-n;return 3*t*t*n*e}function zh(n,e){return 3*(1-n)*n*n*e}function Kh(n,e){return n*n*n*e}function hs(n,e,t,i,s){return Yh(n,e)+Wh(n,t)+zh(n,i)+Kh(n,s)}class Ic extends xn{constructor(e=new oe,t=new oe,i=new oe,s=new oe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new oe){const i=t,s=this.v0,r=this.v1,o=this.v2,c=this.v3;return i.set(hs(e,s.x,r.x,o.x,c.x),hs(e,s.y,r.y,o.y,c.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Xh extends xn{constructor(e=new G,t=new G,i=new G,s=new G){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new G){const i=t,s=this.v0,r=this.v1,o=this.v2,c=this.v3;return i.set(hs(e,s.x,r.x,o.x,c.x),hs(e,s.y,r.y,o.y,c.y),hs(e,s.z,r.z,o.z,c.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class Lc extends xn{constructor(e=new oe,t=new oe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new oe){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new oe){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class qh extends xn{constructor(e=new G,t=new G){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new G){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new G){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class yc extends xn{constructor(e=new oe,t=new oe,i=new oe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new oe){const i=t,s=this.v0,r=this.v1,o=this.v2;return i.set(us(e,s.x,r.x,o.x),us(e,s.y,r.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Zh extends xn{constructor(e=new G,t=new G,i=new G){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new G){const i=t,s=this.v0,r=this.v1,o=this.v2;return i.set(us(e,s.x,r.x,o.x),us(e,s.y,r.y,o.y),us(e,s.z,r.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Oc extends xn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new oe){const i=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),c=r-o,h=s[o===0?o:o-1],u=s[o],p=s[o>s.length-2?s.length-1:o+1],a=s[o>s.length-3?s.length-1:o+2];return i.set(ol(c,h.x,u.x,p.x,a.x),ol(c,h.y,u.y,p.y,a.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new oe().fromArray(s))}return this}}var ja=Object.freeze({__proto__:null,ArcCurve:Bh,CatmullRomCurve3:Hh,CubicBezierCurve:Ic,CubicBezierCurve3:Xh,EllipseCurve:Ao,LineCurve:Lc,LineCurve3:qh,QuadraticBezierCurve:yc,QuadraticBezierCurve3:Zh,SplineCurve:Oc});class Qh extends xn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new ja[i](t,e))}return this}getPoint(e,t){const i=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=i){const o=s[r]-i,c=this.curves[r],h=c.getLength(),u=h===0?0:1-o/h;return c.getPointAt(u,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let i=0,s=this.curves.length;i<s;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let i;for(let s=0,r=this.curves;s<r.length;s++){const o=r[s],c=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,h=o.getPoints(c);for(let u=0;u<h.length;u++){const p=h[u];i&&i.equals(p)||(t.push(p),i=p)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(new ja[s.type]().fromJSON(s))}return this}}class hi extends Qh{constructor(e){super(),this.type="Path",this.currentPoint=new oe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const i=new Lc(this.currentPoint.clone(),new oe(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,s){const r=new yc(this.currentPoint.clone(),new oe(e,t),new oe(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(e,t,i,s,r,o){const c=new Ic(this.currentPoint.clone(),new oe(e,t),new oe(i,s),new oe(r,o));return this.curves.push(c),this.currentPoint.set(r,o),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),i=new Oc(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,s,r,o){const c=this.currentPoint.x,h=this.currentPoint.y;return this.absarc(e+c,t+h,i,s,r,o),this}absarc(e,t,i,s,r,o){return this.absellipse(e,t,i,i,s,r,o),this}ellipse(e,t,i,s,r,o,c,h){const u=this.currentPoint.x,p=this.currentPoint.y;return this.absellipse(e+u,t+p,i,s,r,o,c,h),this}absellipse(e,t,i,s,r,o,c,h){const u=new Ao(e,t,i,s,r,o,c,h);if(this.curves.length>0){const a=u.getPoint(0);a.equals(this.currentPoint)||this.lineTo(a.x,a.y)}this.curves.push(u);const p=u.getPoint(1);return this.currentPoint.copy(p),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Qn extends hi{constructor(e){super(e),this.uuid=zi(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let i=0,s=this.holes.length;i<s;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(new hi().fromJSON(s))}return this}}function Jh(n,e,t=2){const i=e&&e.length,s=i?e[0]*t:n.length;let r=bc(n,0,s,t,!0);const o=[];if(!r||r.next===r.prev)return o;let c,h,u;if(i&&(r=nf(n,e,r,t)),n.length>80*t){c=n[0],h=n[1];let p=c,a=h;for(let l=t;l<s;l+=t){const f=n[l],m=n[l+1];f<c&&(c=f),m<h&&(h=m),f>p&&(p=f),m>a&&(a=m)}u=Math.max(p-c,a-h),u=u!==0?32767/u:0}return gs(r,o,t,c,h,u,0),o}function bc(n,e,t,i,s){let r;if(s===pf(n,e,t,i)>0)for(let o=e;o<t;o+=i)r=ll(o/i|0,n[o],n[o+1],r);else for(let o=t-i;o>=e;o-=i)r=ll(o/i|0,n[o],n[o+1],r);return r&&ki(r,r.next)&&(Rs(r),r=r.next),r}function di(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(ki(t,t.next)||pt(t.prev,t,t.next)===0)){if(Rs(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function gs(n,e,t,i,s,r,o){if(!n)return;!o&&r&&lf(n,i,s,r);let c=n;for(;n.prev!==n.next;){const h=n.prev,u=n.next;if(r?jh(n,i,s,r):$h(n)){e.push(h.i,n.i,u.i),Rs(n),n=u.next,c=u.next;continue}if(n=u,n===c){o?o===1?(n=ef(di(n),e),gs(n,e,t,i,s,r,2)):o===2&&tf(n,e,t,i,s,r):gs(di(n),e,t,i,s,r,1);break}}}function $h(n){const e=n.prev,t=n,i=n.next;if(pt(e,t,i)>=0)return!1;const s=e.x,r=t.x,o=i.x,c=e.y,h=t.y,u=i.y,p=Math.min(s,r,o),a=Math.min(c,h,u),l=Math.max(s,r,o),f=Math.max(c,h,u);let m=i.next;for(;m!==e;){if(m.x>=p&&m.x<=l&&m.y>=a&&m.y<=f&&os(s,c,r,h,o,u,m.x,m.y)&&pt(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function jh(n,e,t,i){const s=n.prev,r=n,o=n.next;if(pt(s,r,o)>=0)return!1;const c=s.x,h=r.x,u=o.x,p=s.y,a=r.y,l=o.y,f=Math.min(c,h,u),m=Math.min(p,a,l),S=Math.max(c,h,u),E=Math.max(p,a,l),d=eo(f,m,e,t,i),g=eo(S,E,e,t,i);let A=n.prevZ,I=n.nextZ;for(;A&&A.z>=d&&I&&I.z<=g;){if(A.x>=f&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==o&&os(c,p,h,a,u,l,A.x,A.y)&&pt(A.prev,A,A.next)>=0||(A=A.prevZ,I.x>=f&&I.x<=S&&I.y>=m&&I.y<=E&&I!==s&&I!==o&&os(c,p,h,a,u,l,I.x,I.y)&&pt(I.prev,I,I.next)>=0))return!1;I=I.nextZ}for(;A&&A.z>=d;){if(A.x>=f&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==o&&os(c,p,h,a,u,l,A.x,A.y)&&pt(A.prev,A,A.next)>=0)return!1;A=A.prevZ}for(;I&&I.z<=g;){if(I.x>=f&&I.x<=S&&I.y>=m&&I.y<=E&&I!==s&&I!==o&&os(c,p,h,a,u,l,I.x,I.y)&&pt(I.prev,I,I.next)>=0)return!1;I=I.nextZ}return!0}function ef(n,e){let t=n;do{const i=t.prev,s=t.next.next;!ki(i,s)&&Dc(i,t,t.next,s)&&Ts(i,s)&&Ts(s,i)&&(e.push(i.i,t.i,s.i),Rs(t),Rs(t.next),t=n=s),t=t.next}while(t!==n);return di(t)}function tf(n,e,t,i,s,r){let o=n;do{let c=o.next.next;for(;c!==o.prev;){if(o.i!==c.i&&hf(o,c)){let h=Nc(o,c);o=di(o,o.next),h=di(h,h.next),gs(o,e,t,i,s,r,0),gs(h,e,t,i,s,r,0);return}c=c.next}o=o.next}while(o!==n)}function nf(n,e,t,i){const s=[];for(let r=0,o=e.length;r<o;r++){const c=e[r]*i,h=r<o-1?e[r+1]*i:n.length,u=bc(n,c,h,i,!1);u===u.next&&(u.steiner=!0),s.push(uf(u))}s.sort(sf);for(let r=0;r<s.length;r++)t=rf(s[r],t);return t}function sf(n,e){let t=n.x-e.x;if(t===0&&(t=n.y-e.y,t===0)){const i=(n.next.y-n.y)/(n.next.x-n.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=i-s}return t}function rf(n,e){const t=af(n,e);if(!t)return e;const i=Nc(t,n);return di(i,i.next),di(t,t.next)}function af(n,e){let t=e;const i=n.x,s=n.y;let r=-1/0,o;if(ki(n,t))return t;do{if(ki(n,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const a=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(a<=i&&a>r&&(r=a,o=t.x<t.next.x?t:t.next,a===i))return o}t=t.next}while(t!==e);if(!o)return null;const c=o,h=o.x,u=o.y;let p=1/0;t=o;do{if(i>=t.x&&t.x>=h&&i!==t.x&&Cc(s<u?i:r,s,h,u,s<u?r:i,s,t.x,t.y)){const a=Math.abs(s-t.y)/(i-t.x);Ts(t,n)&&(a<p||a===p&&(t.x>o.x||t.x===o.x&&of(o,t)))&&(o=t,p=a)}t=t.next}while(t!==c);return o}function of(n,e){return pt(n.prev,n,e.prev)<0&&pt(e.next,n,n.next)<0}function lf(n,e,t,i){let s=n;do s.z===0&&(s.z=eo(s.x,s.y,e,t,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,cf(s)}function cf(n){let e,t=1;do{let i=n,s;n=null;let r=null;for(e=0;i;){e++;let o=i,c=0;for(let u=0;u<t&&(c++,o=o.nextZ,!!o);u++);let h=t;for(;c>0||h>0&&o;)c!==0&&(h===0||!o||i.z<=o.z)?(s=i,i=i.nextZ,c--):(s=o,o=o.nextZ,h--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;i=o}r.nextZ=null,t*=2}while(e>1);return n}function eo(n,e,t,i,s){return n=(n-t)*s|0,e=(e-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function uf(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function Cc(n,e,t,i,s,r,o,c){return(s-o)*(e-c)>=(n-o)*(r-c)&&(n-o)*(i-c)>=(t-o)*(e-c)&&(t-o)*(r-c)>=(s-o)*(i-c)}function os(n,e,t,i,s,r,o,c){return!(n===o&&e===c)&&Cc(n,e,t,i,s,r,o,c)}function hf(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!ff(n,e)&&(Ts(n,e)&&Ts(e,n)&&df(n,e)&&(pt(n.prev,n,e.prev)||pt(n,e.prev,e))||ki(n,e)&&pt(n.prev,n,n.next)>0&&pt(e.prev,e,e.next)>0)}function pt(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function ki(n,e){return n.x===e.x&&n.y===e.y}function Dc(n,e,t,i){const s=Zs(pt(n,e,t)),r=Zs(pt(n,e,i)),o=Zs(pt(t,i,n)),c=Zs(pt(t,i,e));return!!(s!==r&&o!==c||s===0&&qs(n,t,e)||r===0&&qs(n,i,e)||o===0&&qs(t,n,i)||c===0&&qs(t,e,i))}function qs(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function Zs(n){return n>0?1:n<0?-1:0}function ff(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&Dc(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function Ts(n,e){return pt(n.prev,n,n.next)<0?pt(n,e,n.next)>=0&&pt(n,n.prev,e)>=0:pt(n,e,n.prev)<0||pt(n,n.next,e)<0}function df(n,e){let t=n,i=!1;const s=(n.x+e.x)/2,r=(n.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function Nc(n,e){const t=to(n.i,n.x,n.y),i=to(e.i,e.x,e.y),s=n.next,r=e.prev;return n.next=e,e.prev=n,t.next=s,s.prev=t,i.next=t,t.prev=i,r.next=i,i.prev=r,i}function ll(n,e,t,i){const s=to(n,e,t);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function Rs(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function to(n,e,t){return{i:n,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function pf(n,e,t,i){let s=0;for(let r=e,o=t-i;r<t;r+=i)s+=(n[o]-n[r])*(n[r+1]+n[o+1]),o=r;return s}class Ef{static triangulate(e,t,i=2){return Jh(e,t,i)}}class cn{static area(e){const t=e.length;let i=0;for(let s=t-1,r=0;r<t;s=r++)i+=e[s].x*e[r].y-e[r].x*e[s].y;return i*.5}static isClockWise(e){return cn.area(e)<0}static triangulateShape(e,t){const i=[],s=[],r=[];cl(e),ul(i,e);let o=e.length;t.forEach(cl);for(let h=0;h<t.length;h++)s.push(o),o+=t[h].length,ul(i,t[h]);const c=Ef.triangulate(i,s);for(let h=0;h<c.length;h+=3)r.push(c.slice(h,h+3));return r}}function cl(n){const e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function ul(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}class _o extends Rt{constructor(e=new Qn([new oe(.5,.5),new oe(-.5,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const i=this,s=[],r=[];for(let c=0,h=e.length;c<h;c++){const u=e[c];o(u)}this.setAttribute("position",new _t(s,3)),this.setAttribute("uv",new _t(r,2)),this.computeVertexNormals();function o(c){const h=[],u=t.curveSegments!==void 0?t.curveSegments:12,p=t.steps!==void 0?t.steps:1,a=t.depth!==void 0?t.depth:1;let l=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:f-.1,S=t.bevelOffset!==void 0?t.bevelOffset:0,E=t.bevelSegments!==void 0?t.bevelSegments:3;const d=t.extrudePath,g=t.UVGenerator!==void 0?t.UVGenerator:mf;let A,I=!1,D,O,C,U;d&&(A=d.getSpacedPoints(p),I=!0,l=!1,D=d.computeFrenetFrames(p,!1),O=new G,C=new G,U=new G),l||(E=0,f=0,m=0,S=0);const R=c.extractPoints(u);let v=R.shape;const P=R.holes;if(!cn.isClockWise(v)){v=v.reverse();for(let H=0,T=P.length;H<T;H++){const q=P[H];cn.isClockWise(q)&&(P[H]=q.reverse())}}function Z(H){const q=10000000000000001e-36;let $=H[0];for(let N=1;N<=H.length;N++){const y=N%H.length,ae=H[y],ce=ae.x-$.x,Te=ae.y-$.y,b=ce*ce+Te*Te,x=Math.max(Math.abs(ae.x),Math.abs(ae.y),Math.abs($.x),Math.abs($.y)),z=q*x*x;if(b<=z){H.splice(y,1),N--;continue}$=ae}}Z(v),P.forEach(Z);const Q=P.length,j=v;for(let H=0;H<Q;H++){const T=P[H];v=v.concat(T)}function ie(H,T,q){return T||dt("ExtrudeGeometry: vec does not exist"),H.clone().addScaledVector(T,q)}const J=v.length;function B(H,T,q){let $,N,y;const ae=H.x-T.x,ce=H.y-T.y,Te=q.x-H.x,b=q.y-H.y,x=ae*ae+ce*ce,z=ae*b-ce*Te;if(Math.abs(z)>Number.EPSILON){const re=Math.sqrt(x),fe=Math.sqrt(Te*Te+b*b),ne=T.x-ce/re,Ne=T.y+ae/re,ge=q.x-b/fe,we=q.y+Te/fe,De=((ge-ne)*b-(we-Ne)*Te)/(ae*b-ce*Te);$=ne+ae*De-H.x,N=Ne+ce*De-H.y;const Ee=$*$+N*N;if(Ee<=2)return new oe($,N);y=Math.sqrt(Ee/2)}else{let re=!1;ae>Number.EPSILON?Te>Number.EPSILON&&(re=!0):ae<-Number.EPSILON?Te<-Number.EPSILON&&(re=!0):Math.sign(ce)===Math.sign(b)&&(re=!0),re?($=-ce,N=ae,y=Math.sqrt(x)):($=ae,N=ce,y=Math.sqrt(x/2))}return new oe($/y,N/y)}const de=[];for(let H=0,T=j.length,q=T-1,$=H+1;H<T;H++,q++,$++)q===T&&(q=0),$===T&&($=0),de[H]=B(j[H],j[q],j[$]);const pe=[];let Me,He=de.concat();for(let H=0,T=Q;H<T;H++){const q=P[H];Me=[];for(let $=0,N=q.length,y=N-1,ae=$+1;$<N;$++,y++,ae++)y===N&&(y=0),ae===N&&(ae=0),Me[$]=B(q[$],q[y],q[ae]);pe.push(Me),He=He.concat(Me)}let Ce;if(E===0)Ce=cn.triangulateShape(j,P);else{const H=[],T=[];for(let q=0;q<E;q++){const $=q/E,N=f*Math.cos($*Math.PI/2),y=m*Math.sin($*Math.PI/2)+S;for(let ae=0,ce=j.length;ae<ce;ae++){const Te=ie(j[ae],de[ae],y);se(Te.x,Te.y,-N),$===0&&H.push(Te)}for(let ae=0,ce=Q;ae<ce;ae++){const Te=P[ae];Me=pe[ae];const b=[];for(let x=0,z=Te.length;x<z;x++){const re=ie(Te[x],Me[x],y);se(re.x,re.y,-N),$===0&&b.push(re)}$===0&&T.push(b)}}Ce=cn.triangulateShape(H,T)}const W=Ce.length,w=m+S;for(let H=0;H<J;H++){const T=l?ie(v[H],He[H],w):v[H];I?(C.copy(D.normals[0]).multiplyScalar(T.x),O.copy(D.binormals[0]).multiplyScalar(T.y),U.copy(A[0]).add(C).add(O),se(U.x,U.y,U.z)):se(T.x,T.y,0)}for(let H=1;H<=p;H++)for(let T=0;T<J;T++){const q=l?ie(v[T],He[T],w):v[T];I?(C.copy(D.normals[H]).multiplyScalar(q.x),O.copy(D.binormals[H]).multiplyScalar(q.y),U.copy(A[H]).add(C).add(O),se(U.x,U.y,U.z)):se(q.x,q.y,a/p*H)}for(let H=E-1;H>=0;H--){const T=H/E,q=f*Math.cos(T*Math.PI/2),$=m*Math.sin(T*Math.PI/2)+S;for(let N=0,y=j.length;N<y;N++){const ae=ie(j[N],de[N],$);se(ae.x,ae.y,a+q)}for(let N=0,y=P.length;N<y;N++){const ae=P[N];Me=pe[N];for(let ce=0,Te=ae.length;ce<Te;ce++){const b=ie(ae[ce],Me[ce],$);I?se(b.x,b.y+A[p-1].y,A[p-1].x+q):se(b.x,b.y,a+q)}}}M(),_();function M(){const H=s.length/3;if(l){let T=0,q=J*T;for(let $=0;$<W;$++){const N=Ce[$];k(N[2]+q,N[1]+q,N[0]+q)}T=p+E*2,q=J*T;for(let $=0;$<W;$++){const N=Ce[$];k(N[0]+q,N[1]+q,N[2]+q)}}else{for(let T=0;T<W;T++){const q=Ce[T];k(q[2],q[1],q[0])}for(let T=0;T<W;T++){const q=Ce[T];k(q[0]+J*p,q[1]+J*p,q[2]+J*p)}}i.addGroup(H,s.length/3-H,0)}function _(){const H=s.length/3;let T=0;Y(j,T),T+=j.length;for(let q=0,$=P.length;q<$;q++){const N=P[q];Y(N,T),T+=N.length}i.addGroup(H,s.length/3-H,1)}function Y(H,T){let q=H.length;for(;--q>=0;){const $=q;let N=q-1;N<0&&(N=H.length-1);for(let y=0,ae=p+E*2;y<ae;y++){const ce=J*y,Te=J*(y+1),b=T+$+ce,x=T+N+ce,z=T+N+Te,re=T+$+Te;le(b,x,z,re)}}}function se(H,T,q){h.push(H),h.push(T),h.push(q)}function k(H,T,q){Ae(H),Ae(T),Ae(q);const $=s.length/3,N=g.generateTopUV(i,s,$-3,$-2,$-1);ue(N[0]),ue(N[1]),ue(N[2])}function le(H,T,q,$){Ae(H),Ae(T),Ae($),Ae(T),Ae(q),Ae($);const N=s.length/3,y=g.generateSideWallUV(i,s,N-6,N-3,N-2,N-1);ue(y[0]),ue(y[1]),ue(y[3]),ue(y[1]),ue(y[2]),ue(y[3])}function Ae(H){s.push(h[H*3+0]),s.push(h[H*3+1]),s.push(h[H*3+2])}function ue(H){r.push(H.x),r.push(H.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,i=this.parameters.options;return Sf(t,i,e)}static fromJSON(e,t){const i=[];for(let r=0,o=e.shapes.length;r<o;r++){const c=t[e.shapes[r]];i.push(c)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new ja[s.type]().fromJSON(s)),new _o(i,e.options)}}const mf={generateTopUV:function(n,e,t,i,s){const r=e[t*3],o=e[t*3+1],c=e[i*3],h=e[i*3+1],u=e[s*3],p=e[s*3+1];return[new oe(r,o),new oe(c,h),new oe(u,p)]},generateSideWallUV:function(n,e,t,i,s,r){const o=e[t*3],c=e[t*3+1],h=e[t*3+2],u=e[i*3],p=e[i*3+1],a=e[i*3+2],l=e[s*3],f=e[s*3+1],m=e[s*3+2],S=e[r*3],E=e[r*3+1],d=e[r*3+2];return Math.abs(c-p)<Math.abs(o-u)?[new oe(o,1-h),new oe(u,1-a),new oe(l,1-m),new oe(S,1-d)]:[new oe(c,1-h),new oe(p,1-a),new oe(f,1-m),new oe(E,1-d)]}};function Sf(n,e,t){if(t.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){const r=n[i];t.shapes.push(r.uuid)}else t.shapes.push(n.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class Ms extends Rt{constructor(e=1,t=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:s};const r=e/2,o=t/2,c=Math.floor(i),h=Math.floor(s),u=c+1,p=h+1,a=e/c,l=t/h,f=[],m=[],S=[],E=[];for(let d=0;d<p;d++){const g=d*l-o;for(let A=0;A<u;A++){const I=A*a-r;m.push(I,-g,0),S.push(0,0,1),E.push(A/c),E.push(1-d/h)}}for(let d=0;d<h;d++)for(let g=0;g<c;g++){const A=g+u*d,I=g+u*(d+1),D=g+1+u*(d+1),O=g+1+u*d;f.push(A,I,O),f.push(I,D,O)}this.setIndex(f),this.setAttribute("position",new _t(m,3)),this.setAttribute("normal",new _t(S,3)),this.setAttribute("uv",new _t(E,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ms(e.width,e.height,e.widthSegments,e.heightSegments)}}class go extends Rt{constructor(e=new Qn([new oe(0,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const i=[],s=[],r=[],o=[];let c=0,h=0;if(Array.isArray(e)===!1)u(e);else for(let p=0;p<e.length;p++)u(e[p]),this.addGroup(c,h,p),c+=h,h=0;this.setIndex(i),this.setAttribute("position",new _t(s,3)),this.setAttribute("normal",new _t(r,3)),this.setAttribute("uv",new _t(o,2));function u(p){const a=s.length/3,l=p.extractPoints(t);let f=l.shape;const m=l.holes;cn.isClockWise(f)===!1&&(f=f.reverse());for(let E=0,d=m.length;E<d;E++){const g=m[E];cn.isClockWise(g)===!0&&(m[E]=g.reverse())}const S=cn.triangulateShape(f,m);for(let E=0,d=m.length;E<d;E++){const g=m[E];f=f.concat(g)}for(let E=0,d=f.length;E<d;E++){const g=f[E];s.push(g.x,g.y,0),r.push(0,0,1),o.push(g.x,g.y)}for(let E=0,d=S.length;E<d;E++){const g=S[E],A=g[0]+a,I=g[1]+a,D=g[2]+a;i.push(A,I,D),h+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Af(t,e)}static fromJSON(e,t){const i=[];for(let s=0,r=e.shapes.length;s<r;s++){const o=t[e.shapes[s]];i.push(o)}return new go(i,e.curveSegments)}}function Af(n,e){if(e.shapes=[],Array.isArray(n))for(let t=0,i=n.length;t<i;t++){const s=n[t];e.shapes.push(s.uuid)}else e.shapes.push(n.uuid);return e}class xf extends Ar{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=qu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class _f extends Ar{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const hl={enabled:!1,files:{},add:function(n,e){this.enabled!==!1&&(this.files[n]=e)},get:function(n){if(this.enabled!==!1)return this.files[n]},remove:function(n){delete this.files[n]},clear:function(){this.files={}}};class gf{constructor(e,t,i){const s=this;let r=!1,o=0,c=0,h;const u=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this._abortController=null,this.itemStart=function(p){c++,r===!1&&s.onStart!==void 0&&s.onStart(p,o,c),r=!0},this.itemEnd=function(p){o++,s.onProgress!==void 0&&s.onProgress(p,o,c),o===c&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(p){s.onError!==void 0&&s.onError(p)},this.resolveURL=function(p){return h?h(p):p},this.setURLModifier=function(p){return h=p,this},this.addHandler=function(p,a){return u.push(p,a),this},this.removeHandler=function(p){const a=u.indexOf(p);return a!==-1&&u.splice(a,2),this},this.getHandler=function(p){for(let a=0,l=u.length;a<l;a+=2){const f=u[a],m=u[a+1];if(f.global&&(f.lastIndex=0),f.test(p))return m}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const Tf=new gf;class To{constructor(e){this.manager=e!==void 0?e:Tf,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const i=this;return new Promise(function(s,r){i.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}To.DEFAULT_MATERIAL_NAME="__DEFAULT";const Mn={};class Rf extends Error{constructor(e,t){super(e),this.response=t}}class vf extends To{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,i,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=hl.get(`file:${e}`);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(Mn[e]!==void 0){Mn[e].push({onLoad:t,onProgress:i,onError:s});return}Mn[e]=[],Mn[e].push({onLoad:t,onProgress:i,onError:s});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),c=this.mimeType,h=this.responseType;fetch(o).then(u=>{if(u.status===200||u.status===0){if(u.status===0&&Ke("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||u.body===void 0||u.body.getReader===void 0)return u;const p=Mn[e],a=u.body.getReader(),l=u.headers.get("X-File-Size")||u.headers.get("Content-Length"),f=l?parseInt(l):0,m=f!==0;let S=0;const E=new ReadableStream({start(d){g();function g(){a.read().then(({done:A,value:I})=>{if(A)d.close();else{S+=I.byteLength;const D=new ProgressEvent("progress",{lengthComputable:m,loaded:S,total:f});for(let O=0,C=p.length;O<C;O++){const U=p[O];U.onProgress&&U.onProgress(D)}d.enqueue(I),g()}},A=>{d.error(A)})}}});return new Response(E)}else throw new Rf(`fetch for "${u.url}" responded with ${u.status}: ${u.statusText}`,u)}).then(u=>{switch(h){case"arraybuffer":return u.arrayBuffer();case"blob":return u.blob();case"document":return u.text().then(p=>new DOMParser().parseFromString(p,c));case"json":return u.json();default:if(c==="")return u.text();{const a=/charset="?([^;"\s]*)"?/i.exec(c),l=a&&a[1]?a[1].toLowerCase():void 0,f=new TextDecoder(l);return u.arrayBuffer().then(m=>f.decode(m))}}}).then(u=>{hl.add(`file:${e}`,u);const p=Mn[e];delete Mn[e];for(let a=0,l=p.length;a<l;a++){const f=p[a];f.onLoad&&f.onLoad(u)}}).catch(u=>{const p=Mn[e];if(p===void 0)throw this.manager.itemError(e),u;delete Mn[e];for(let a=0,l=p.length;a<l;a++){const f=p[a];f.onError&&f.onError(u)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class Mf extends gc{constructor(e=-1,t=1,i=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=i-e,o=i+e,c=s+t,h=s-t;if(this.view!==null&&this.view.enabled){const u=(this.right-this.left)/this.view.fullWidth/this.zoom,p=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=u*this.view.offsetX,o=r+u*this.view.width,c-=p*this.view.offsetY,h=c-p*this.view.height}this.projectionMatrix.makeOrthographic(r,o,c,h,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class If extends jt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const fl=new At;class Ro{constructor(e,t,i=0,s=1/0){this.ray=new mo(e,t),this.near=i,this.far=s,this.camera=null,this.layers=new So,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):dt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return fl.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(fl),this}intersectObject(e,t=!0,i=[]){return no(e,this,i,t),i.sort(dl),i}intersectObjects(e,t=!0,i=[]){for(let s=0,r=e.length;s<r;s++)no(e[s],this,i,t);return i.sort(dl),i}}function dl(n,e){return n.distance-e.distance}function no(n,e,t,i){let s=!0;if(n.layers.test(e.layers)&&n.raycast(e,t)===!1&&(s=!1),s===!0&&i===!0){const r=n.children;for(let o=0,c=r.length;o<c;o++)no(r[o],e,t,!0)}}class pl{constructor(e=1,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.radius=e,this.phi=t,this.theta=i}set(e,t,i){return this.radius=e,this.phi=t,this.theta=i,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Ze(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,i){return this.radius=Math.sqrt(e*e+t*t+i*i),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,i),this.phi=Math.acos(Ze(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const El=new oe;class Lf{constructor(e=new oe(1/0,1/0),t=new oe(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=El.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,El).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}class si{constructor(){this.type="ShapePath",this.color=new et,this.subPaths=[],this.currentPath=null}moveTo(e,t){return this.currentPath=new hi,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,i,s){return this.currentPath.quadraticCurveTo(e,t,i,s),this}bezierCurveTo(e,t,i,s,r,o){return this.currentPath.bezierCurveTo(e,t,i,s,r,o),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(e){function t(d){const g=[];for(let A=0,I=d.length;A<I;A++){const D=d[A],O=new Qn;O.curves=D.curves,g.push(O)}return g}function i(d,g){const A=g.length;let I=!1;for(let D=A-1,O=0;O<A;D=O++){let C=g[D],U=g[O],R=U.x-C.x,v=U.y-C.y;if(Math.abs(v)>Number.EPSILON){if(v<0&&(C=g[O],R=-R,U=g[D],v=-v),d.y<C.y||d.y>U.y)continue;if(d.y===C.y){if(d.x===C.x)return!0}else{const P=v*(d.x-C.x)-R*(d.y-C.y);if(P===0)return!0;if(P<0)continue;I=!I}}else{if(d.y!==C.y)continue;if(U.x<=d.x&&d.x<=C.x||C.x<=d.x&&d.x<=U.x)return!0}}return I}const s=cn.isClockWise,r=this.subPaths;if(r.length===0)return[];let o,c,h;const u=[];if(r.length===1)return c=r[0],h=new Qn,h.curves=c.curves,u.push(h),u;let p=!s(r[0].getPoints());p=e?!p:p;const a=[],l=[];let f=[],m=0,S;l[m]=void 0,f[m]=[];for(let d=0,g=r.length;d<g;d++)c=r[d],S=c.getPoints(),o=s(S),o=e?!o:o,o?(!p&&l[m]&&m++,l[m]={s:new Qn,p:S},l[m].s.curves=c.curves,p&&m++,f[m]=[]):f[m].push({h:c,p:S[0]});if(!l[0])return t(r);if(l.length>1){let d=!1,g=0;for(let A=0,I=l.length;A<I;A++)a[A]=[];for(let A=0,I=l.length;A<I;A++){const D=f[A];for(let O=0;O<D.length;O++){const C=D[O];let U=!0;for(let R=0;R<l.length;R++)i(C.p,l[R].p)&&(A!==R&&g++,U?(U=!1,a[R].push(C)):d=!0);U&&a[A].push(C)}}g>0&&d===!1&&(f=a)}let E;for(let d=0,g=l.length;d<g;d++){h=l[d].s,u.push(h),E=f[d];for(let A=0,I=E.length;A<I;A++)h.holes.push(E[A].h)}return u}}class yf extends pi{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){Ke("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function ml(n,e,t,i){const s=Of(i);switch(t){case hc:return n*e;case dc:return n*e/s.components*s.byteLength;case co:return n*e/s.components*s.byteLength;case uo:return n*e*2/s.components*s.byteLength;case ho:return n*e*2/s.components*s.byteLength;case fc:return n*e*3/s.components*s.byteLength;case ln:return n*e*4/s.components*s.byteLength;case fo:return n*e*4/s.components*s.byteLength;case tr:case nr:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case ir:case sr:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Ma:case La:return Math.max(n,16)*Math.max(e,8)/4;case va:case Ia:return Math.max(n,8)*Math.max(e,8)/2;case ya:case Oa:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case ba:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Ca:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Da:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case Na:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case Pa:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case Ua:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case wa:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case Fa:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case Ba:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case Ha:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case Ga:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case Va:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case ka:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case Ya:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case Wa:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case za:case Ka:case Xa:return Math.ceil(n/4)*Math.ceil(e/4)*16;case qa:case Za:return Math.ceil(n/4)*Math.ceil(e/4)*8;case Qa:case Ja:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Of(n){switch(n){case Pn:case oc:return{byteLength:1,components:1};case ms:case lc:case Wi:return{byteLength:2,components:1};case oo:case lo:return{byteLength:2,components:4};case fi:case ao:case bn:return{byteLength:4,components:1};case cc:case uc:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${n}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ro}}));typeof window<"u"&&(window.__THREE__?Ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ro);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Pc(){let n=null,e=!1,t=null,i=null;function s(r,o){t(r,o),i=n.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(s),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){n=r}}}function bf(n){const e=new WeakMap;function t(c,h){const u=c.array,p=c.usage,a=u.byteLength,l=n.createBuffer();n.bindBuffer(h,l),n.bufferData(h,u,p),c.onUploadCallback();let f;if(u instanceof Float32Array)f=n.FLOAT;else if(typeof Float16Array<"u"&&u instanceof Float16Array)f=n.HALF_FLOAT;else if(u instanceof Uint16Array)c.isFloat16BufferAttribute?f=n.HALF_FLOAT:f=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)f=n.SHORT;else if(u instanceof Uint32Array)f=n.UNSIGNED_INT;else if(u instanceof Int32Array)f=n.INT;else if(u instanceof Int8Array)f=n.BYTE;else if(u instanceof Uint8Array)f=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)f=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:l,type:f,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:a}}function i(c,h,u){const p=h.array,a=h.updateRanges;if(n.bindBuffer(u,c),a.length===0)n.bufferSubData(u,0,p);else{a.sort((f,m)=>f.start-m.start);let l=0;for(let f=1;f<a.length;f++){const m=a[l],S=a[f];S.start<=m.start+m.count+1?m.count=Math.max(m.count,S.start+S.count-m.start):(++l,a[l]=S)}a.length=l+1;for(let f=0,m=a.length;f<m;f++){const S=a[f];n.bufferSubData(u,S.start*p.BYTES_PER_ELEMENT,p,S.start,S.count)}h.clearUpdateRanges()}h.onUploadCallback()}function s(c){return c.isInterleavedBufferAttribute&&(c=c.data),e.get(c)}function r(c){c.isInterleavedBufferAttribute&&(c=c.data);const h=e.get(c);h&&(n.deleteBuffer(h.buffer),e.delete(c))}function o(c,h){if(c.isInterleavedBufferAttribute&&(c=c.data),c.isGLBufferAttribute){const p=e.get(c);(!p||p.version<c.version)&&e.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}const u=e.get(c);if(u===void 0)e.set(c,t(c,h));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(u.buffer,c,h),u.version=c.version}}return{get:s,remove:r,update:o}}var Cf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Df=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Nf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Pf=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Uf=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,wf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ff=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Bf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Hf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Gf=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Vf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,kf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Yf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Wf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,zf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Kf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Xf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,qf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Zf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Qf=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Jf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,$f=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,jf=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,ed=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,td=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,nd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,id=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,sd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,rd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,ad=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,od="gl_FragColor = linearToOutputTexel( gl_FragColor );",ld=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,cd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,ud=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,hd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,fd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,dd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,pd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Ed=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,md=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Sd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Ad=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,xd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,_d=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,gd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Td=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Rd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,vd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Md=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Id=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ld=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,yd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Od=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,bd=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Cd=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Dd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Nd=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Pd=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ud=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,wd=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Fd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Bd=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Hd=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Gd=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Vd=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,kd=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Yd=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Wd=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,zd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Kd=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Xd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,qd=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Zd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Qd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Jd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,$d=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,jd=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,ep=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,tp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,np=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ip=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,sp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,rp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,ap=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,op=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,lp=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,cp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,up=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,hp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,fp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,dp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,pp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Ep=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,mp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Sp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ap=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,xp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,_p=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,gp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Tp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Rp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,vp=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Mp=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ip=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Lp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Op=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const bp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Cp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Dp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Np=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Up=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,wp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Fp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Bp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Hp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Gp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Vp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,kp=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Yp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Wp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,zp=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Kp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Xp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qp=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Zp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qp=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Jp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,$p=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,jp=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,eE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,tE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,iE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,rE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,aE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,oE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,lE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,cE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:Cf,alphahash_pars_fragment:Df,alphamap_fragment:Nf,alphamap_pars_fragment:Pf,alphatest_fragment:Uf,alphatest_pars_fragment:wf,aomap_fragment:Ff,aomap_pars_fragment:Bf,batching_pars_vertex:Hf,batching_vertex:Gf,begin_vertex:Vf,beginnormal_vertex:kf,bsdfs:Yf,iridescence_fragment:Wf,bumpmap_pars_fragment:zf,clipping_planes_fragment:Kf,clipping_planes_pars_fragment:Xf,clipping_planes_pars_vertex:qf,clipping_planes_vertex:Zf,color_fragment:Qf,color_pars_fragment:Jf,color_pars_vertex:$f,color_vertex:jf,common:ed,cube_uv_reflection_fragment:td,defaultnormal_vertex:nd,displacementmap_pars_vertex:id,displacementmap_vertex:sd,emissivemap_fragment:rd,emissivemap_pars_fragment:ad,colorspace_fragment:od,colorspace_pars_fragment:ld,envmap_fragment:cd,envmap_common_pars_fragment:ud,envmap_pars_fragment:hd,envmap_pars_vertex:fd,envmap_physical_pars_fragment:Rd,envmap_vertex:dd,fog_vertex:pd,fog_pars_vertex:Ed,fog_fragment:md,fog_pars_fragment:Sd,gradientmap_pars_fragment:Ad,lightmap_pars_fragment:xd,lights_lambert_fragment:_d,lights_lambert_pars_fragment:gd,lights_pars_begin:Td,lights_toon_fragment:vd,lights_toon_pars_fragment:Md,lights_phong_fragment:Id,lights_phong_pars_fragment:Ld,lights_physical_fragment:yd,lights_physical_pars_fragment:Od,lights_fragment_begin:bd,lights_fragment_maps:Cd,lights_fragment_end:Dd,logdepthbuf_fragment:Nd,logdepthbuf_pars_fragment:Pd,logdepthbuf_pars_vertex:Ud,logdepthbuf_vertex:wd,map_fragment:Fd,map_pars_fragment:Bd,map_particle_fragment:Hd,map_particle_pars_fragment:Gd,metalnessmap_fragment:Vd,metalnessmap_pars_fragment:kd,morphinstance_vertex:Yd,morphcolor_vertex:Wd,morphnormal_vertex:zd,morphtarget_pars_vertex:Kd,morphtarget_vertex:Xd,normal_fragment_begin:qd,normal_fragment_maps:Zd,normal_pars_fragment:Qd,normal_pars_vertex:Jd,normal_vertex:$d,normalmap_pars_fragment:jd,clearcoat_normal_fragment_begin:ep,clearcoat_normal_fragment_maps:tp,clearcoat_pars_fragment:np,iridescence_pars_fragment:ip,opaque_fragment:sp,packing:rp,premultiplied_alpha_fragment:ap,project_vertex:op,dithering_fragment:lp,dithering_pars_fragment:cp,roughnessmap_fragment:up,roughnessmap_pars_fragment:hp,shadowmap_pars_fragment:fp,shadowmap_pars_vertex:dp,shadowmap_vertex:pp,shadowmask_pars_fragment:Ep,skinbase_vertex:mp,skinning_pars_vertex:Sp,skinning_vertex:Ap,skinnormal_vertex:xp,specularmap_fragment:_p,specularmap_pars_fragment:gp,tonemapping_fragment:Tp,tonemapping_pars_fragment:Rp,transmission_fragment:vp,transmission_pars_fragment:Mp,uv_pars_fragment:Ip,uv_pars_vertex:Lp,uv_vertex:yp,worldpos_vertex:Op,background_vert:bp,background_frag:Cp,backgroundCube_vert:Dp,backgroundCube_frag:Np,cube_vert:Pp,cube_frag:Up,depth_vert:wp,depth_frag:Fp,distanceRGBA_vert:Bp,distanceRGBA_frag:Hp,equirect_vert:Gp,equirect_frag:Vp,linedashed_vert:kp,linedashed_frag:Yp,meshbasic_vert:Wp,meshbasic_frag:zp,meshlambert_vert:Kp,meshlambert_frag:Xp,meshmatcap_vert:qp,meshmatcap_frag:Zp,meshnormal_vert:Qp,meshnormal_frag:Jp,meshphong_vert:$p,meshphong_frag:jp,meshphysical_vert:eE,meshphysical_frag:tE,meshtoon_vert:nE,meshtoon_frag:iE,points_vert:sE,points_frag:rE,shadow_vert:aE,shadow_frag:oE,sprite_vert:lE,sprite_frag:cE},Ie={common:{diffuse:{value:new et(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new We}},envmap:{envMap:{value:null},envMapRotation:{value:new We},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new We}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new We}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new We},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new We},normalScale:{value:new oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new We},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new We}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new We}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new We}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new et(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new et(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0},uvTransform:{value:new We}},sprite:{diffuse:{value:new et(16777215)},opacity:{value:1},center:{value:new oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}}},En={basic:{uniforms:Ct([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:Ct([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,Ie.lights,{emissive:{value:new et(0)}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:Ct([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,Ie.lights,{emissive:{value:new et(0)},specular:{value:new et(1118481)},shininess:{value:30}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:Ct([Ie.common,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.roughnessmap,Ie.metalnessmap,Ie.fog,Ie.lights,{emissive:{value:new et(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:Ct([Ie.common,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.gradientmap,Ie.fog,Ie.lights,{emissive:{value:new et(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:Ct([Ie.common,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:Ct([Ie.points,Ie.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:Ct([Ie.common,Ie.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:Ct([Ie.common,Ie.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:Ct([Ie.common,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:Ct([Ie.sprite,Ie.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new We},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new We}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distanceRGBA:{uniforms:Ct([Ie.common,Ie.displacementmap,{referencePosition:{value:new G},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distanceRGBA_vert,fragmentShader:qe.distanceRGBA_frag},shadow:{uniforms:Ct([Ie.lights,Ie.fog,{color:{value:new et(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};En.physical={uniforms:Ct([En.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new We},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new We},clearcoatNormalScale:{value:new oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new We},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new We},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new We},sheen:{value:0},sheenColor:{value:new et(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new We},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new We},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new We},transmissionSamplerSize:{value:new oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new We},attenuationDistance:{value:0},attenuationColor:{value:new et(0)},specularColor:{value:new et(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new We},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new We},anisotropyVector:{value:new oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new We}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const Qs={r:0,b:0,g:0},ri=new Fn,uE=new At;function hE(n,e,t,i,s,r,o){const c=new et(0);let h=r===!0?0:1,u,p,a=null,l=0,f=null;function m(A){let I=A.isScene===!0?A.background:null;return I&&I.isTexture&&(I=(A.backgroundBlurriness>0?t:e).get(I)),I}function S(A){let I=!1;const D=m(A);D===null?d(c,h):D&&D.isColor&&(d(D,1),I=!0);const O=n.xr.getEnvironmentBlendMode();O==="additive"?i.buffers.color.setClear(0,0,0,1,o):O==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,o),(n.autoClear||I)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function E(A,I){const D=m(I);D&&(D.isCubeTexture||D.mapping===Sr)?(p===void 0&&(p=new Tt(new Ei(1,1,1),new Bn({name:"BackgroundCubeMaterial",uniforms:Vi(En.backgroundCube.uniforms),vertexShader:En.backgroundCube.vertexShader,fragmentShader:En.backgroundCube.fragmentShader,side:Lt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(O,C,U){this.matrixWorld.copyPosition(U.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(p)),ri.copy(I.backgroundRotation),ri.x*=-1,ri.y*=-1,ri.z*=-1,D.isCubeTexture&&D.isRenderTargetTexture===!1&&(ri.y*=-1,ri.z*=-1),p.material.uniforms.envMap.value=D,p.material.uniforms.flipEnvMap.value=D.isCubeTexture&&D.isRenderTargetTexture===!1?-1:1,p.material.uniforms.backgroundBlurriness.value=I.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(uE.makeRotationFromEuler(ri)),p.material.toneMapped=$e.getTransfer(D.colorSpace)!==st,(a!==D||l!==D.version||f!==n.toneMapping)&&(p.material.needsUpdate=!0,a=D,l=D.version,f=n.toneMapping),p.layers.enableAll(),A.unshift(p,p.geometry,p.material,0,0,null)):D&&D.isTexture&&(u===void 0&&(u=new Tt(new Ms(2,2),new Bn({name:"BackgroundMaterial",uniforms:Vi(En.background.uniforms),vertexShader:En.background.vertexShader,fragmentShader:En.background.fragmentShader,side:An,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(u)),u.material.uniforms.t2D.value=D,u.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,u.material.toneMapped=$e.getTransfer(D.colorSpace)!==st,D.matrixAutoUpdate===!0&&D.updateMatrix(),u.material.uniforms.uvTransform.value.copy(D.matrix),(a!==D||l!==D.version||f!==n.toneMapping)&&(u.material.needsUpdate=!0,a=D,l=D.version,f=n.toneMapping),u.layers.enableAll(),A.unshift(u,u.geometry,u.material,0,0,null))}function d(A,I){A.getRGB(Qs,_c(n)),i.buffers.color.setClear(Qs.r,Qs.g,Qs.b,I,o)}function g(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0)}return{getClearColor:function(){return c},setClearColor:function(A,I=1){c.set(A),h=I,d(c,h)},getClearAlpha:function(){return h},setClearAlpha:function(A){h=A,d(c,h)},render:S,addToRenderList:E,dispose:g}}function fE(n,e){const t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},s=l(null);let r=s,o=!1;function c(v,P,V,Z,Q){let j=!1;const ie=a(Z,V,P);r!==ie&&(r=ie,u(r.object)),j=f(v,Z,V,Q),j&&m(v,Z,V,Q),Q!==null&&e.update(Q,n.ELEMENT_ARRAY_BUFFER),(j||o)&&(o=!1,I(v,P,V,Z),Q!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(Q).buffer))}function h(){return n.createVertexArray()}function u(v){return n.bindVertexArray(v)}function p(v){return n.deleteVertexArray(v)}function a(v,P,V){const Z=V.wireframe===!0;let Q=i[v.id];Q===void 0&&(Q={},i[v.id]=Q);let j=Q[P.id];j===void 0&&(j={},Q[P.id]=j);let ie=j[Z];return ie===void 0&&(ie=l(h()),j[Z]=ie),ie}function l(v){const P=[],V=[],Z=[];for(let Q=0;Q<t;Q++)P[Q]=0,V[Q]=0,Z[Q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:V,attributeDivisors:Z,object:v,attributes:{},index:null}}function f(v,P,V,Z){const Q=r.attributes,j=P.attributes;let ie=0;const J=V.getAttributes();for(const B in J)if(J[B].location>=0){const pe=Q[B];let Me=j[B];if(Me===void 0&&(B==="instanceMatrix"&&v.instanceMatrix&&(Me=v.instanceMatrix),B==="instanceColor"&&v.instanceColor&&(Me=v.instanceColor)),pe===void 0||pe.attribute!==Me||Me&&pe.data!==Me.data)return!0;ie++}return r.attributesNum!==ie||r.index!==Z}function m(v,P,V,Z){const Q={},j=P.attributes;let ie=0;const J=V.getAttributes();for(const B in J)if(J[B].location>=0){let pe=j[B];pe===void 0&&(B==="instanceMatrix"&&v.instanceMatrix&&(pe=v.instanceMatrix),B==="instanceColor"&&v.instanceColor&&(pe=v.instanceColor));const Me={};Me.attribute=pe,pe&&pe.data&&(Me.data=pe.data),Q[B]=Me,ie++}r.attributes=Q,r.attributesNum=ie,r.index=Z}function S(){const v=r.newAttributes;for(let P=0,V=v.length;P<V;P++)v[P]=0}function E(v){d(v,0)}function d(v,P){const V=r.newAttributes,Z=r.enabledAttributes,Q=r.attributeDivisors;V[v]=1,Z[v]===0&&(n.enableVertexAttribArray(v),Z[v]=1),Q[v]!==P&&(n.vertexAttribDivisor(v,P),Q[v]=P)}function g(){const v=r.newAttributes,P=r.enabledAttributes;for(let V=0,Z=P.length;V<Z;V++)P[V]!==v[V]&&(n.disableVertexAttribArray(V),P[V]=0)}function A(v,P,V,Z,Q,j,ie){ie===!0?n.vertexAttribIPointer(v,P,V,Q,j):n.vertexAttribPointer(v,P,V,Z,Q,j)}function I(v,P,V,Z){S();const Q=Z.attributes,j=V.getAttributes(),ie=P.defaultAttributeValues;for(const J in j){const B=j[J];if(B.location>=0){let de=Q[J];if(de===void 0&&(J==="instanceMatrix"&&v.instanceMatrix&&(de=v.instanceMatrix),J==="instanceColor"&&v.instanceColor&&(de=v.instanceColor)),de!==void 0){const pe=de.normalized,Me=de.itemSize,He=e.get(de);if(He===void 0)continue;const Ce=He.buffer,W=He.type,w=He.bytesPerElement,M=W===n.INT||W===n.UNSIGNED_INT||de.gpuType===ao;if(de.isInterleavedBufferAttribute){const _=de.data,Y=_.stride,se=de.offset;if(_.isInstancedInterleavedBuffer){for(let k=0;k<B.locationSize;k++)d(B.location+k,_.meshPerAttribute);v.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=_.meshPerAttribute*_.count)}else for(let k=0;k<B.locationSize;k++)E(B.location+k);n.bindBuffer(n.ARRAY_BUFFER,Ce);for(let k=0;k<B.locationSize;k++)A(B.location+k,Me/B.locationSize,W,pe,Y*w,(se+Me/B.locationSize*k)*w,M)}else{if(de.isInstancedBufferAttribute){for(let _=0;_<B.locationSize;_++)d(B.location+_,de.meshPerAttribute);v.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=de.meshPerAttribute*de.count)}else for(let _=0;_<B.locationSize;_++)E(B.location+_);n.bindBuffer(n.ARRAY_BUFFER,Ce);for(let _=0;_<B.locationSize;_++)A(B.location+_,Me/B.locationSize,W,pe,Me*w,Me/B.locationSize*_*w,M)}}else if(ie!==void 0){const pe=ie[J];if(pe!==void 0)switch(pe.length){case 2:n.vertexAttrib2fv(B.location,pe);break;case 3:n.vertexAttrib3fv(B.location,pe);break;case 4:n.vertexAttrib4fv(B.location,pe);break;default:n.vertexAttrib1fv(B.location,pe)}}}}g()}function D(){U();for(const v in i){const P=i[v];for(const V in P){const Z=P[V];for(const Q in Z)p(Z[Q].object),delete Z[Q];delete P[V]}delete i[v]}}function O(v){if(i[v.id]===void 0)return;const P=i[v.id];for(const V in P){const Z=P[V];for(const Q in Z)p(Z[Q].object),delete Z[Q];delete P[V]}delete i[v.id]}function C(v){for(const P in i){const V=i[P];if(V[v.id]===void 0)continue;const Z=V[v.id];for(const Q in Z)p(Z[Q].object),delete Z[Q];delete V[v.id]}}function U(){R(),o=!0,r!==s&&(r=s,u(r.object))}function R(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:c,reset:U,resetDefaultState:R,dispose:D,releaseStatesOfGeometry:O,releaseStatesOfProgram:C,initAttributes:S,enableAttribute:E,disableUnusedAttributes:g}}function dE(n,e,t){let i;function s(u){i=u}function r(u,p){n.drawArrays(i,u,p),t.update(p,i,1)}function o(u,p,a){a!==0&&(n.drawArraysInstanced(i,u,p,a),t.update(p,i,a))}function c(u,p,a){if(a===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,u,0,p,0,a);let f=0;for(let m=0;m<a;m++)f+=p[m];t.update(f,i,1)}function h(u,p,a,l){if(a===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let m=0;m<u.length;m++)o(u[m],p[m],l[m]);else{f.multiDrawArraysInstancedWEBGL(i,u,0,p,0,l,0,a);let m=0;for(let S=0;S<a;S++)m+=p[S]*l[S];t.update(m,i,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=c,this.renderMultiDrawInstances=h}function pE(n,e,t,i){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const C=e.get("EXT_texture_filter_anisotropic");s=n.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(C){return!(C!==ln&&i.convert(C)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function c(C){const U=C===Wi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(C!==Pn&&i.convert(C)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE)&&C!==bn&&!U)}function h(C){if(C==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=t.precision!==void 0?t.precision:"highp";const p=h(u);p!==u&&(Ke("WebGLRenderer:",u,"not supported, using",p,"instead."),u=p);const a=t.logarithmicDepthBuffer===!0,l=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),f=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),S=n.getParameter(n.MAX_TEXTURE_SIZE),E=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),d=n.getParameter(n.MAX_VERTEX_ATTRIBS),g=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),A=n.getParameter(n.MAX_VARYING_VECTORS),I=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),D=m>0,O=n.getParameter(n.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:h,textureFormatReadable:o,textureTypeReadable:c,precision:u,logarithmicDepthBuffer:a,reversedDepthBuffer:l,maxTextures:f,maxVertexTextures:m,maxTextureSize:S,maxCubemapSize:E,maxAttributes:d,maxVertexUniforms:g,maxVaryings:A,maxFragmentUniforms:I,vertexTextures:D,maxSamples:O}}function EE(n){const e=this;let t=null,i=0,s=!1,r=!1;const o=new yn,c=new We,h={value:null,needsUpdate:!1};this.uniform=h,this.numPlanes=0,this.numIntersection=0,this.init=function(a,l){const f=a.length!==0||l||i!==0||s;return s=l,i=a.length,f},this.beginShadows=function(){r=!0,p(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(a,l){t=p(a,l,0)},this.setState=function(a,l,f){const m=a.clippingPlanes,S=a.clipIntersection,E=a.clipShadows,d=n.get(a);if(!s||m===null||m.length===0||r&&!E)r?p(null):u();else{const g=r?0:i,A=g*4;let I=d.clippingState||null;h.value=I,I=p(m,l,A,f);for(let D=0;D!==A;++D)I[D]=t[D];d.clippingState=I,this.numIntersection=S?this.numPlanes:0,this.numPlanes+=g}};function u(){h.value!==t&&(h.value=t,h.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function p(a,l,f,m){const S=a!==null?a.length:0;let E=null;if(S!==0){if(E=h.value,m!==!0||E===null){const d=f+S*4,g=l.matrixWorldInverse;c.getNormalMatrix(g),(E===null||E.length<d)&&(E=new Float32Array(d));for(let A=0,I=f;A!==S;++A,I+=4)o.copy(a[A]).applyMatrix4(g,c),o.normal.toArray(E,I),E[I+3]=o.constant}h.value=E,h.needsUpdate=!0}return e.numPlanes=S,e.numIntersection=0,E}}function mE(n){let e=new WeakMap;function t(o,c){return c===_a?o.mapping=Bi:c===ga&&(o.mapping=Hi),o}function i(o){if(o&&o.isTexture){const c=o.mapping;if(c===_a||c===ga)if(e.has(o)){const h=e.get(o).texture;return t(h,o.mapping)}else{const h=o.image;if(h&&h.height>0){const u=new Ch(h.height);return u.fromEquirectangularTexture(n,o),e.set(o,u),o.addEventListener("dispose",s),t(u.texture,o.mapping)}else return null}}return o}function s(o){const c=o.target;c.removeEventListener("dispose",s);const h=e.get(c);h!==void 0&&(e.delete(c),h.dispose())}function r(){e=new WeakMap}return{get:i,dispose:r}}const qn=4,Sl=[.125,.215,.35,.446,.526,.582],li=20,SE=256,is=new Mf,Al=new et;let jr=null,ea=0,ta=0,na=!1;const AE=new G;class xl{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,i=.1,s=100,r={}){const{size:o=256,position:c=AE}=r;jr=this._renderer.getRenderTarget(),ea=this._renderer.getActiveCubeFace(),ta=this._renderer.getActiveMipmapLevel(),na=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const h=this._allocateTargets();return h.depthBuffer=!0,this._sceneToCubeUV(e,i,s,h,c),t>0&&this._blur(h,0,0,t),this._applyPMREM(h),this._cleanup(h),h}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Tl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=gl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(jr,ea,ta),this._renderer.xr.enabled=na,e.scissorTest=!1,bi(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Bi||e.mapping===Hi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),jr=this._renderer.getRenderTarget(),ea=this._renderer.getActiveCubeFace(),ta=this._renderer.getActiveMipmapLevel(),na=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:en,minFilter:en,generateMipmaps:!1,type:Wi,format:ln,colorSpace:Gi,depthBuffer:!1},s=_l(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=_l(e,t,i);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=xE(r)),this._blurMaterial=gE(r,e,t),this._ggxMaterial=_E(r,e,t)}return s}_compileMaterial(e){const t=new Tt(new Rt,e);this._renderer.compile(t,is)}_sceneToCubeUV(e,t,i,s,r){const h=new jt(90,1,t,i),u=[1,-1,1,1,1,1],p=[1,1,1,-1,-1,-1],a=this._renderer,l=a.autoClear,f=a.toneMapping;a.getClearColor(Al),a.toneMapping=Zn,a.autoClear=!1,a.state.buffers.depth.getReversed()&&(a.setRenderTarget(s),a.clearDepth(),a.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Tt(new Ei,new Kt({name:"PMREM.Background",side:Lt,depthWrite:!1,depthTest:!1})));const S=this._backgroundBox,E=S.material;let d=!1;const g=e.background;g?g.isColor&&(E.color.copy(g),e.background=null,d=!0):(E.color.copy(Al),d=!0);for(let A=0;A<6;A++){const I=A%3;I===0?(h.up.set(0,u[A],0),h.position.set(r.x,r.y,r.z),h.lookAt(r.x+p[A],r.y,r.z)):I===1?(h.up.set(0,0,u[A]),h.position.set(r.x,r.y,r.z),h.lookAt(r.x,r.y+p[A],r.z)):(h.up.set(0,u[A],0),h.position.set(r.x,r.y,r.z),h.lookAt(r.x,r.y,r.z+p[A]));const D=this._cubeSize;bi(s,I*D,A>2?D:0,D,D),a.setRenderTarget(s),d&&a.render(S,h),a.render(e,h)}a.toneMapping=f,a.autoClear=l,e.background=g}_textureToCubeUV(e,t){const i=this._renderer,s=e.mapping===Bi||e.mapping===Hi;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Tl()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=gl());const r=s?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=r;const c=r.uniforms;c.envMap.value=e;const h=this._cubeSize;bi(t,0,0,3*h,2*h),i.setRenderTarget(t),i.render(o,is)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const s=this._lodMeshes.length;for(let r=1;r<s;r++)this._applyGGXFilter(e,r-1,r);t.autoClear=i}_applyGGXFilter(e,t,i){const s=this._renderer,r=this._pingPongRenderTarget,o=this._ggxMaterial,c=this._lodMeshes[i];c.material=o;const h=o.uniforms,u=i/(this._lodMeshes.length-1),p=t/(this._lodMeshes.length-1),a=Math.sqrt(u*u-p*p),l=.05+u*.95,f=a*l,{_lodMax:m}=this,S=this._sizeLods[i],E=3*S*(i>m-qn?i-m+qn:0),d=4*(this._cubeSize-S);h.envMap.value=e.texture,h.roughness.value=f,h.mipInt.value=m-t,bi(r,E,d,3*S,2*S),s.setRenderTarget(r),s.render(c,is),h.envMap.value=r.texture,h.roughness.value=0,h.mipInt.value=m-i,bi(e,E,d,3*S,2*S),s.setRenderTarget(e),s.render(c,is)}_blur(e,t,i,s,r){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,i,s,"latitudinal",r),this._halfBlur(o,e,i,i,s,"longitudinal",r)}_halfBlur(e,t,i,s,r,o,c){const h=this._renderer,u=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&dt("blur direction must be either latitudinal or longitudinal!");const p=3,a=this._lodMeshes[s];a.material=u;const l=u.uniforms,f=this._sizeLods[i]-1,m=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*li-1),S=r/m,E=isFinite(r)?1+Math.floor(p*S):li;E>li&&Ke(`sigmaRadians, ${r}, is too large and will clip, as it requested ${E} samples when the maximum is set to ${li}`);const d=[];let g=0;for(let C=0;C<li;++C){const U=C/S,R=Math.exp(-U*U/2);d.push(R),C===0?g+=R:C<E&&(g+=2*R)}for(let C=0;C<d.length;C++)d[C]=d[C]/g;l.envMap.value=e.texture,l.samples.value=E,l.weights.value=d,l.latitudinal.value=o==="latitudinal",c&&(l.poleAxis.value=c);const{_lodMax:A}=this;l.dTheta.value=m,l.mipInt.value=A-i;const I=this._sizeLods[s],D=3*I*(s>A-qn?s-A+qn:0),O=4*(this._cubeSize-I);bi(t,D,O,3*I,2*I),h.setRenderTarget(t),h.render(a,is)}}function xE(n){const e=[],t=[],i=[];let s=n;const r=n-qn+1+Sl.length;for(let o=0;o<r;o++){const c=Math.pow(2,s);e.push(c);let h=1/c;o>n-qn?h=Sl[o-n+qn-1]:o===0&&(h=0),t.push(h);const u=1/(c-2),p=-u,a=1+u,l=[p,p,a,p,a,a,p,p,a,a,p,a],f=6,m=6,S=3,E=2,d=1,g=new Float32Array(S*m*f),A=new Float32Array(E*m*f),I=new Float32Array(d*m*f);for(let O=0;O<f;O++){const C=O%3*2/3-1,U=O>2?0:-1,R=[C,U,0,C+2/3,U,0,C+2/3,U+1,0,C,U,0,C+2/3,U+1,0,C,U+1,0];g.set(R,S*m*O),A.set(l,E*m*O);const v=[O,O,O,O,O,O];I.set(v,d*m*O)}const D=new Rt;D.setAttribute("position",new un(g,S)),D.setAttribute("uv",new un(A,E)),D.setAttribute("faceIndex",new un(I,d)),i.push(new Tt(D,null)),s>qn&&s--}return{lodMeshes:i,sizeLods:e,sigmas:t}}function _l(n,e,t){const i=new wn(n,e,t);return i.texture.mapping=Sr,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function bi(n,e,t,i,s){n.viewport.set(e,t,i,s),n.scissor.set(e,t,i,s)}function _E(n,e,t){return new Bn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:SE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:xr(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function gE(n,e,t){const i=new Float32Array(li),s=new G(0,1,0);return new Bn({name:"SphericalGaussianBlur",defines:{n:li,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:xr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function gl(){return new Bn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:xr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function Tl(){return new Bn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:xr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function xr(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function TE(n){let e=new WeakMap,t=null;function i(c){if(c&&c.isTexture){const h=c.mapping,u=h===_a||h===ga,p=h===Bi||h===Hi;if(u||p){let a=e.get(c);const l=a!==void 0?a.texture.pmremVersion:0;if(c.isRenderTargetTexture&&c.pmremVersion!==l)return t===null&&(t=new xl(n)),a=u?t.fromEquirectangular(c,a):t.fromCubemap(c,a),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),a.texture;if(a!==void 0)return a.texture;{const f=c.image;return u&&f&&f.height>0||p&&f&&s(f)?(t===null&&(t=new xl(n)),a=u?t.fromEquirectangular(c):t.fromCubemap(c),a.texture.pmremVersion=c.pmremVersion,e.set(c,a),c.addEventListener("dispose",r),a.texture):null}}}return c}function s(c){let h=0;const u=6;for(let p=0;p<u;p++)c[p]!==void 0&&h++;return h===u}function r(c){const h=c.target;h.removeEventListener("dispose",r);const u=e.get(h);u!==void 0&&(e.delete(h),u.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:o}}function RE(n){const e={};function t(i){if(e[i]!==void 0)return e[i];const s=n.getExtension(i);return e[i]=s,s}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const s=t(i);return s===null&&_s("WebGLRenderer: "+i+" extension not supported."),s}}}function vE(n,e,t,i){const s={},r=new WeakMap;function o(a){const l=a.target;l.index!==null&&e.remove(l.index);for(const m in l.attributes)e.remove(l.attributes[m]);l.removeEventListener("dispose",o),delete s[l.id];const f=r.get(l);f&&(e.remove(f),r.delete(l)),i.releaseStatesOfGeometry(l),l.isInstancedBufferGeometry===!0&&delete l._maxInstanceCount,t.memory.geometries--}function c(a,l){return s[l.id]===!0||(l.addEventListener("dispose",o),s[l.id]=!0,t.memory.geometries++),l}function h(a){const l=a.attributes;for(const f in l)e.update(l[f],n.ARRAY_BUFFER)}function u(a){const l=[],f=a.index,m=a.attributes.position;let S=0;if(f!==null){const g=f.array;S=f.version;for(let A=0,I=g.length;A<I;A+=3){const D=g[A+0],O=g[A+1],C=g[A+2];l.push(D,O,O,C,C,D)}}else if(m!==void 0){const g=m.array;S=m.version;for(let A=0,I=g.length/3-1;A<I;A+=3){const D=A+0,O=A+1,C=A+2;l.push(D,O,O,C,C,D)}}else return;const E=new(Ec(l)?xc:Ac)(l,1);E.version=S;const d=r.get(a);d&&e.remove(d),r.set(a,E)}function p(a){const l=r.get(a);if(l){const f=a.index;f!==null&&l.version<f.version&&u(a)}else u(a);return r.get(a)}return{get:c,update:h,getWireframeAttribute:p}}function ME(n,e,t){let i;function s(l){i=l}let r,o;function c(l){r=l.type,o=l.bytesPerElement}function h(l,f){n.drawElements(i,f,r,l*o),t.update(f,i,1)}function u(l,f,m){m!==0&&(n.drawElementsInstanced(i,f,r,l*o,m),t.update(f,i,m))}function p(l,f,m){if(m===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,f,0,r,l,0,m);let E=0;for(let d=0;d<m;d++)E+=f[d];t.update(E,i,1)}function a(l,f,m,S){if(m===0)return;const E=e.get("WEBGL_multi_draw");if(E===null)for(let d=0;d<l.length;d++)u(l[d]/o,f[d],S[d]);else{E.multiDrawElementsInstancedWEBGL(i,f,0,r,l,0,S,0,m);let d=0;for(let g=0;g<m;g++)d+=f[g]*S[g];t.update(d,i,1)}}this.setMode=s,this.setIndex=c,this.render=h,this.renderInstances=u,this.renderMultiDraw=p,this.renderMultiDrawInstances=a}function IE(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,o,c){switch(t.calls++,o){case n.TRIANGLES:t.triangles+=c*(r/3);break;case n.LINES:t.lines+=c*(r/2);break;case n.LINE_STRIP:t.lines+=c*(r-1);break;case n.LINE_LOOP:t.lines+=c*r;break;case n.POINTS:t.points+=c*r;break;default:dt("WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:i}}function LE(n,e,t){const i=new WeakMap,s=new St;function r(o,c,h){const u=o.morphTargetInfluences,p=c.morphAttributes.position||c.morphAttributes.normal||c.morphAttributes.color,a=p!==void 0?p.length:0;let l=i.get(c);if(l===void 0||l.count!==a){let v=function(){U.dispose(),i.delete(c),c.removeEventListener("dispose",v)};var f=v;l!==void 0&&l.texture.dispose();const m=c.morphAttributes.position!==void 0,S=c.morphAttributes.normal!==void 0,E=c.morphAttributes.color!==void 0,d=c.morphAttributes.position||[],g=c.morphAttributes.normal||[],A=c.morphAttributes.color||[];let I=0;m===!0&&(I=1),S===!0&&(I=2),E===!0&&(I=3);let D=c.attributes.position.count*I,O=1;D>e.maxTextureSize&&(O=Math.ceil(D/e.maxTextureSize),D=e.maxTextureSize);const C=new Float32Array(D*O*4*a),U=new mc(C,D,O,a);U.type=bn,U.needsUpdate=!0;const R=I*4;for(let P=0;P<a;P++){const V=d[P],Z=g[P],Q=A[P],j=D*O*4*P;for(let ie=0;ie<V.count;ie++){const J=ie*R;m===!0&&(s.fromBufferAttribute(V,ie),C[j+J+0]=s.x,C[j+J+1]=s.y,C[j+J+2]=s.z,C[j+J+3]=0),S===!0&&(s.fromBufferAttribute(Z,ie),C[j+J+4]=s.x,C[j+J+5]=s.y,C[j+J+6]=s.z,C[j+J+7]=0),E===!0&&(s.fromBufferAttribute(Q,ie),C[j+J+8]=s.x,C[j+J+9]=s.y,C[j+J+10]=s.z,C[j+J+11]=Q.itemSize===4?s.w:1)}}l={count:a,texture:U,size:new oe(D,O)},i.set(c,l),c.addEventListener("dispose",v)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)h.getUniforms().setValue(n,"morphTexture",o.morphTexture,t);else{let m=0;for(let E=0;E<u.length;E++)m+=u[E];const S=c.morphTargetsRelative?1:1-m;h.getUniforms().setValue(n,"morphTargetBaseInfluence",S),h.getUniforms().setValue(n,"morphTargetInfluences",u)}h.getUniforms().setValue(n,"morphTargetsTexture",l.texture,t),h.getUniforms().setValue(n,"morphTargetsTextureSize",l.size)}return{update:r}}function yE(n,e,t,i){let s=new WeakMap;function r(h){const u=i.render.frame,p=h.geometry,a=e.get(h,p);if(s.get(a)!==u&&(e.update(a),s.set(a,u)),h.isInstancedMesh&&(h.hasEventListener("dispose",c)===!1&&h.addEventListener("dispose",c),s.get(h)!==u&&(t.update(h.instanceMatrix,n.ARRAY_BUFFER),h.instanceColor!==null&&t.update(h.instanceColor,n.ARRAY_BUFFER),s.set(h,u))),h.isSkinnedMesh){const l=h.skeleton;s.get(l)!==u&&(l.update(),s.set(l,u))}return a}function o(){s=new WeakMap}function c(h){const u=h.target;u.removeEventListener("dispose",c),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:r,dispose:o}}const Uc=new Ut,Rl=new vc(1,1),wc=new mc,Fc=new ph,Bc=new Tc,vl=[],Ml=[],Il=new Float32Array(16),Ll=new Float32Array(9),yl=new Float32Array(4);function Xi(n,e,t){const i=n[0];if(i<=0||i>0)return n;const s=e*t;let r=vl[s];if(r===void 0&&(r=new Float32Array(s),vl[s]=r),e!==0){i.toArray(r,0);for(let o=1,c=0;o!==e;++o)c+=t,n[o].toArray(r,c)}return r}function vt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function Mt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function _r(n,e){let t=Ml[e];t===void 0&&(t=new Int32Array(e),Ml[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function OE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function bE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2fv(this.addr,e),Mt(t,e)}}function CE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(vt(t,e))return;n.uniform3fv(this.addr,e),Mt(t,e)}}function DE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4fv(this.addr,e),Mt(t,e)}}function NE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;yl.set(i),n.uniformMatrix2fv(this.addr,!1,yl),Mt(t,i)}}function PE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;Ll.set(i),n.uniformMatrix3fv(this.addr,!1,Ll),Mt(t,i)}}function UE(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(vt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),Mt(t,e)}else{if(vt(t,i))return;Il.set(i),n.uniformMatrix4fv(this.addr,!1,Il),Mt(t,i)}}function wE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function FE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2iv(this.addr,e),Mt(t,e)}}function BE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(vt(t,e))return;n.uniform3iv(this.addr,e),Mt(t,e)}}function HE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4iv(this.addr,e),Mt(t,e)}}function GE(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function VE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(vt(t,e))return;n.uniform2uiv(this.addr,e),Mt(t,e)}}function kE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(vt(t,e))return;n.uniform3uiv(this.addr,e),Mt(t,e)}}function YE(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(vt(t,e))return;n.uniform4uiv(this.addr,e),Mt(t,e)}}function WE(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r;this.type===n.SAMPLER_2D_SHADOW?(Rl.compareFunction=pc,r=Rl):r=Uc,t.setTexture2D(e||r,s)}function zE(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture3D(e||Fc,s)}function KE(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTextureCube(e||Bc,s)}function XE(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture2DArray(e||wc,s)}function qE(n){switch(n){case 5126:return OE;case 35664:return bE;case 35665:return CE;case 35666:return DE;case 35674:return NE;case 35675:return PE;case 35676:return UE;case 5124:case 35670:return wE;case 35667:case 35671:return FE;case 35668:case 35672:return BE;case 35669:case 35673:return HE;case 5125:return GE;case 36294:return VE;case 36295:return kE;case 36296:return YE;case 35678:case 36198:case 36298:case 36306:case 35682:return WE;case 35679:case 36299:case 36307:return zE;case 35680:case 36300:case 36308:case 36293:return KE;case 36289:case 36303:case 36311:case 36292:return XE}}function ZE(n,e){n.uniform1fv(this.addr,e)}function QE(n,e){const t=Xi(e,this.size,2);n.uniform2fv(this.addr,t)}function JE(n,e){const t=Xi(e,this.size,3);n.uniform3fv(this.addr,t)}function $E(n,e){const t=Xi(e,this.size,4);n.uniform4fv(this.addr,t)}function jE(n,e){const t=Xi(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function em(n,e){const t=Xi(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function tm(n,e){const t=Xi(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function nm(n,e){n.uniform1iv(this.addr,e)}function im(n,e){n.uniform2iv(this.addr,e)}function sm(n,e){n.uniform3iv(this.addr,e)}function rm(n,e){n.uniform4iv(this.addr,e)}function am(n,e){n.uniform1uiv(this.addr,e)}function om(n,e){n.uniform2uiv(this.addr,e)}function lm(n,e){n.uniform3uiv(this.addr,e)}function cm(n,e){n.uniform4uiv(this.addr,e)}function um(n,e,t){const i=this.cache,s=e.length,r=_r(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture2D(e[o]||Uc,r[o])}function hm(n,e,t){const i=this.cache,s=e.length,r=_r(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Fc,r[o])}function fm(n,e,t){const i=this.cache,s=e.length,r=_r(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Bc,r[o])}function dm(n,e,t){const i=this.cache,s=e.length,r=_r(t,s);vt(i,r)||(n.uniform1iv(this.addr,r),Mt(i,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||wc,r[o])}function pm(n){switch(n){case 5126:return ZE;case 35664:return QE;case 35665:return JE;case 35666:return $E;case 35674:return jE;case 35675:return em;case 35676:return tm;case 5124:case 35670:return nm;case 35667:case 35671:return im;case 35668:case 35672:return sm;case 35669:case 35673:return rm;case 5125:return am;case 36294:return om;case 36295:return lm;case 36296:return cm;case 35678:case 36198:case 36298:case 36306:case 35682:return um;case 35679:case 36299:case 36307:return hm;case 35680:case 36300:case 36308:case 36293:return fm;case 36289:case 36303:case 36311:case 36292:return dm}}class Em{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=qE(t.type)}}class mm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=pm(t.type)}}class Sm{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const s=this.seq;for(let r=0,o=s.length;r!==o;++r){const c=s[r];c.setValue(e,t[c.id],i)}}}const ia=/(\w+)(\])?(\[|\.)?/g;function Ol(n,e){n.seq.push(e),n.map[e.id]=e}function Am(n,e,t){const i=n.name,s=i.length;for(ia.lastIndex=0;;){const r=ia.exec(i),o=ia.lastIndex;let c=r[1];const h=r[2]==="]",u=r[3];if(h&&(c=c|0),u===void 0||u==="["&&o+2===s){Ol(t,u===void 0?new Em(c,n,e):new mm(c,n,e));break}else{let a=t.map[c];a===void 0&&(a=new Sm(c),Ol(t,a)),t=a}}}class ar{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const r=e.getActiveUniform(t,s),o=e.getUniformLocation(t,r.name);Am(r,o,this)}}setValue(e,t,i,s){const r=this.map[t];r!==void 0&&r.setValue(e,i,s)}setOptional(e,t,i){const s=t[i];s!==void 0&&this.setValue(e,i,s)}static upload(e,t,i,s){for(let r=0,o=t.length;r!==o;++r){const c=t[r],h=i[c.id];h.needsUpdate!==!1&&c.setValue(e,h.value,s)}}static seqWithValue(e,t){const i=[];for(let s=0,r=e.length;s!==r;++s){const o=e[s];o.id in t&&i.push(o)}return i}}function bl(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const xm=37297;let _m=0;function gm(n,e){const t=n.split(`
`),i=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){const c=o+1;i.push(`${c===e?">":" "} ${c}: ${t[o]}`)}return i.join(`
`)}const Cl=new We;function Tm(n){$e._getMatrix(Cl,$e.workingColorSpace,n);const e=`mat3( ${Cl.elements.map(t=>t.toFixed(4))} )`;switch($e.getTransfer(n)){case lr:return[e,"LinearTransferOETF"];case st:return[e,"sRGBTransferOETF"];default:return Ke("WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function Dl(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=(n.getShaderInfoLog(e)||"").trim();if(i&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const c=parseInt(o[1]);return t.toUpperCase()+`

`+r+`

`+gm(n.getShaderSource(e),c)}else return r}function Rm(n,e){const t=Tm(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function vm(n,e){let t;switch(e){case Gu:t="Linear";break;case Vu:t="Reinhard";break;case ku:t="Cineon";break;case Yu:t="ACESFilmic";break;case zu:t="AgX";break;case Ku:t="Neutral";break;case Wu:t="Custom";break;default:Ke("WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Js=new G;function Mm(){$e.getLuminanceCoefficients(Js);const n=Js.x.toFixed(4),e=Js.y.toFixed(4),t=Js.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Im(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ls).join(`
`)}function Lm(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function ym(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){const r=n.getActiveAttrib(e,s),o=r.name;let c=1;r.type===n.FLOAT_MAT2&&(c=2),r.type===n.FLOAT_MAT3&&(c=3),r.type===n.FLOAT_MAT4&&(c=4),t[o]={type:r.type,location:n.getAttribLocation(e,o),locationSize:c}}return t}function ls(n){return n!==""}function Nl(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Pl(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Om=/^[ \t]*#include +<([\w\d./]+)>/gm;function io(n){return n.replace(Om,Cm)}const bm=new Map;function Cm(n,e){let t=qe[e];if(t===void 0){const i=bm.get(e);if(i!==void 0)t=qe[i],Ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return io(t)}const Dm=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Ul(n){return n.replace(Dm,Nm)}function Nm(n,e,t,i){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function wl(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Pm(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===sc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===xu?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===Ln&&(e="SHADOWMAP_TYPE_VSM"),e}function Um(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Bi:case Hi:e="ENVMAP_TYPE_CUBE";break;case Sr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function wm(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Hi:e="ENVMAP_MODE_REFRACTION";break}return e}function Fm(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case rc:e="ENVMAP_BLENDING_MULTIPLY";break;case Bu:e="ENVMAP_BLENDING_MIX";break;case Hu:e="ENVMAP_BLENDING_ADD";break}return e}function Bm(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Hm(n,e,t,i){const s=n.getContext(),r=t.defines;let o=t.vertexShader,c=t.fragmentShader;const h=Pm(t),u=Um(t),p=wm(t),a=Fm(t),l=Bm(t),f=Im(t),m=Lm(r),S=s.createProgram();let E,d,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(E=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ls).join(`
`),E.length>0&&(E+=`
`),d=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ls).join(`
`),d.length>0&&(d+=`
`)):(E=[wl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+p:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+h:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ls).join(`
`),d=[wl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.envMap?"#define "+p:"",t.envMap?"#define "+a:"",l?"#define CUBEUV_TEXEL_WIDTH "+l.texelWidth:"",l?"#define CUBEUV_TEXEL_HEIGHT "+l.texelHeight:"",l?"#define CUBEUV_MAX_MIP "+l.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+h:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Zn?"#define TONE_MAPPING":"",t.toneMapping!==Zn?qe.tonemapping_pars_fragment:"",t.toneMapping!==Zn?vm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,Rm("linearToOutputTexel",t.outputColorSpace),Mm(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(ls).join(`
`)),o=io(o),o=Nl(o,t),o=Pl(o,t),c=io(c),c=Nl(c,t),c=Pl(c,t),o=Ul(o),c=Ul(c),t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,E=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+E,d=["#define varying in",t.glslVersion===ko?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===ko?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+d);const A=g+E+o,I=g+d+c,D=bl(s,s.VERTEX_SHADER,A),O=bl(s,s.FRAGMENT_SHADER,I);s.attachShader(S,D),s.attachShader(S,O),t.index0AttributeName!==void 0?s.bindAttribLocation(S,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(S,0,"position"),s.linkProgram(S);function C(P){if(n.debug.checkShaderErrors){const V=s.getProgramInfoLog(S)||"",Z=s.getShaderInfoLog(D)||"",Q=s.getShaderInfoLog(O)||"",j=V.trim(),ie=Z.trim(),J=Q.trim();let B=!0,de=!0;if(s.getProgramParameter(S,s.LINK_STATUS)===!1)if(B=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,S,D,O);else{const pe=Dl(s,D,"vertex"),Me=Dl(s,O,"fragment");dt("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(S,s.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+j+`
`+pe+`
`+Me)}else j!==""?Ke("WebGLProgram: Program Info Log:",j):(ie===""||J==="")&&(de=!1);de&&(P.diagnostics={runnable:B,programLog:j,vertexShader:{log:ie,prefix:E},fragmentShader:{log:J,prefix:d}})}s.deleteShader(D),s.deleteShader(O),U=new ar(s,S),R=ym(s,S)}let U;this.getUniforms=function(){return U===void 0&&C(this),U};let R;this.getAttributes=function(){return R===void 0&&C(this),R};let v=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return v===!1&&(v=s.getProgramParameter(S,xm)),v},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(S),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=_m++,this.cacheKey=e,this.usedTimes=1,this.program=S,this.vertexShader=D,this.fragmentShader=O,this}let Gm=0;class Vm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(i),o=this._getShaderCacheForMaterial(e);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new km(e),t.set(e,i)),i}}class km{constructor(e){this.id=Gm++,this.code=e,this.usedTimes=0}}function Ym(n,e,t,i,s,r,o){const c=new So,h=new Vm,u=new Set,p=[],a=s.logarithmicDepthBuffer,l=s.vertexTextures;let f=s.precision;const m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function S(R){return u.add(R),R===0?"uv":`uv${R}`}function E(R,v,P,V,Z){const Q=V.fog,j=Z.geometry,ie=R.isMeshStandardMaterial?V.environment:null,J=(R.isMeshStandardMaterial?t:e).get(R.envMap||ie),B=J&&J.mapping===Sr?J.image.height:null,de=m[R.type];R.precision!==null&&(f=s.getMaxPrecision(R.precision),f!==R.precision&&Ke("WebGLProgram.getParameters:",R.precision,"not supported, using",f,"instead."));const pe=j.morphAttributes.position||j.morphAttributes.normal||j.morphAttributes.color,Me=pe!==void 0?pe.length:0;let He=0;j.morphAttributes.position!==void 0&&(He=1),j.morphAttributes.normal!==void 0&&(He=2),j.morphAttributes.color!==void 0&&(He=3);let Ce,W,w,M;if(de){const tt=En[de];Ce=tt.vertexShader,W=tt.fragmentShader}else Ce=R.vertexShader,W=R.fragmentShader,h.update(R),w=h.getVertexShaderID(R),M=h.getFragmentShaderID(R);const _=n.getRenderTarget(),Y=n.state.buffers.depth.getReversed(),se=Z.isInstancedMesh===!0,k=Z.isBatchedMesh===!0,le=!!R.map,Ae=!!R.matcap,ue=!!J,H=!!R.aoMap,T=!!R.lightMap,q=!!R.bumpMap,$=!!R.normalMap,N=!!R.displacementMap,y=!!R.emissiveMap,ae=!!R.metalnessMap,ce=!!R.roughnessMap,Te=R.anisotropy>0,b=R.clearcoat>0,x=R.dispersion>0,z=R.iridescence>0,re=R.sheen>0,fe=R.transmission>0,ne=Te&&!!R.anisotropyMap,Ne=b&&!!R.clearcoatMap,ge=b&&!!R.clearcoatNormalMap,we=b&&!!R.clearcoatRoughnessMap,De=z&&!!R.iridescenceMap,Ee=z&&!!R.iridescenceThicknessMap,xe=re&&!!R.sheenColorMap,ke=re&&!!R.sheenRoughnessMap,Ge=!!R.specularMap,Oe=!!R.specularColorMap,ze=!!R.specularIntensityMap,F=fe&&!!R.transmissionMap,Le=fe&&!!R.thicknessMap,Re=!!R.gradientMap,ve=!!R.alphaMap,Se=R.alphaTest>0,he=!!R.alphaHash,Pe=!!R.extensions;let Xe=Zn;R.toneMapped&&(_===null||_.isXRRenderTarget===!0)&&(Xe=n.toneMapping);const ct={shaderID:de,shaderType:R.type,shaderName:R.name,vertexShader:Ce,fragmentShader:W,defines:R.defines,customVertexShaderID:w,customFragmentShaderID:M,isRawShaderMaterial:R.isRawShaderMaterial===!0,glslVersion:R.glslVersion,precision:f,batching:k,batchingColor:k&&Z._colorsTexture!==null,instancing:se,instancingColor:se&&Z.instanceColor!==null,instancingMorph:se&&Z.morphTexture!==null,supportsVertexTextures:l,outputColorSpace:_===null?n.outputColorSpace:_.isXRRenderTarget===!0?_.texture.colorSpace:Gi,alphaToCoverage:!!R.alphaToCoverage,map:le,matcap:Ae,envMap:ue,envMapMode:ue&&J.mapping,envMapCubeUVHeight:B,aoMap:H,lightMap:T,bumpMap:q,normalMap:$,displacementMap:l&&N,emissiveMap:y,normalMapObjectSpace:$&&R.normalMapType===Ju,normalMapTangentSpace:$&&R.normalMapType===Qu,metalnessMap:ae,roughnessMap:ce,anisotropy:Te,anisotropyMap:ne,clearcoat:b,clearcoatMap:Ne,clearcoatNormalMap:ge,clearcoatRoughnessMap:we,dispersion:x,iridescence:z,iridescenceMap:De,iridescenceThicknessMap:Ee,sheen:re,sheenColorMap:xe,sheenRoughnessMap:ke,specularMap:Ge,specularColorMap:Oe,specularIntensityMap:ze,transmission:fe,transmissionMap:F,thicknessMap:Le,gradientMap:Re,opaque:R.transparent===!1&&R.blending===Ui&&R.alphaToCoverage===!1,alphaMap:ve,alphaTest:Se,alphaHash:he,combine:R.combine,mapUv:le&&S(R.map.channel),aoMapUv:H&&S(R.aoMap.channel),lightMapUv:T&&S(R.lightMap.channel),bumpMapUv:q&&S(R.bumpMap.channel),normalMapUv:$&&S(R.normalMap.channel),displacementMapUv:N&&S(R.displacementMap.channel),emissiveMapUv:y&&S(R.emissiveMap.channel),metalnessMapUv:ae&&S(R.metalnessMap.channel),roughnessMapUv:ce&&S(R.roughnessMap.channel),anisotropyMapUv:ne&&S(R.anisotropyMap.channel),clearcoatMapUv:Ne&&S(R.clearcoatMap.channel),clearcoatNormalMapUv:ge&&S(R.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:we&&S(R.clearcoatRoughnessMap.channel),iridescenceMapUv:De&&S(R.iridescenceMap.channel),iridescenceThicknessMapUv:Ee&&S(R.iridescenceThicknessMap.channel),sheenColorMapUv:xe&&S(R.sheenColorMap.channel),sheenRoughnessMapUv:ke&&S(R.sheenRoughnessMap.channel),specularMapUv:Ge&&S(R.specularMap.channel),specularColorMapUv:Oe&&S(R.specularColorMap.channel),specularIntensityMapUv:ze&&S(R.specularIntensityMap.channel),transmissionMapUv:F&&S(R.transmissionMap.channel),thicknessMapUv:Le&&S(R.thicknessMap.channel),alphaMapUv:ve&&S(R.alphaMap.channel),vertexTangents:!!j.attributes.tangent&&($||Te),vertexColors:R.vertexColors,vertexAlphas:R.vertexColors===!0&&!!j.attributes.color&&j.attributes.color.itemSize===4,pointsUvs:Z.isPoints===!0&&!!j.attributes.uv&&(le||ve),fog:!!Q,useFog:R.fog===!0,fogExp2:!!Q&&Q.isFogExp2,flatShading:R.flatShading===!0&&R.wireframe===!1,sizeAttenuation:R.sizeAttenuation===!0,logarithmicDepthBuffer:a,reversedDepthBuffer:Y,skinning:Z.isSkinnedMesh===!0,morphTargets:j.morphAttributes.position!==void 0,morphNormals:j.morphAttributes.normal!==void 0,morphColors:j.morphAttributes.color!==void 0,morphTargetsCount:Me,morphTextureStride:He,numDirLights:v.directional.length,numPointLights:v.point.length,numSpotLights:v.spot.length,numSpotLightMaps:v.spotLightMap.length,numRectAreaLights:v.rectArea.length,numHemiLights:v.hemi.length,numDirLightShadows:v.directionalShadowMap.length,numPointLightShadows:v.pointShadowMap.length,numSpotLightShadows:v.spotShadowMap.length,numSpotLightShadowsWithMaps:v.numSpotLightShadowsWithMaps,numLightProbes:v.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:R.dithering,shadowMapEnabled:n.shadowMap.enabled&&P.length>0,shadowMapType:n.shadowMap.type,toneMapping:Xe,decodeVideoTexture:le&&R.map.isVideoTexture===!0&&$e.getTransfer(R.map.colorSpace)===st,decodeVideoTextureEmissive:y&&R.emissiveMap.isVideoTexture===!0&&$e.getTransfer(R.emissiveMap.colorSpace)===st,premultipliedAlpha:R.premultipliedAlpha,doubleSided:R.side===an,flipSided:R.side===Lt,useDepthPacking:R.depthPacking>=0,depthPacking:R.depthPacking||0,index0AttributeName:R.index0AttributeName,extensionClipCullDistance:Pe&&R.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Pe&&R.extensions.multiDraw===!0||k)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:R.customProgramCacheKey()};return ct.vertexUv1s=u.has(1),ct.vertexUv2s=u.has(2),ct.vertexUv3s=u.has(3),u.clear(),ct}function d(R){const v=[];if(R.shaderID?v.push(R.shaderID):(v.push(R.customVertexShaderID),v.push(R.customFragmentShaderID)),R.defines!==void 0)for(const P in R.defines)v.push(P),v.push(R.defines[P]);return R.isRawShaderMaterial===!1&&(g(v,R),A(v,R),v.push(n.outputColorSpace)),v.push(R.customProgramCacheKey),v.join()}function g(R,v){R.push(v.precision),R.push(v.outputColorSpace),R.push(v.envMapMode),R.push(v.envMapCubeUVHeight),R.push(v.mapUv),R.push(v.alphaMapUv),R.push(v.lightMapUv),R.push(v.aoMapUv),R.push(v.bumpMapUv),R.push(v.normalMapUv),R.push(v.displacementMapUv),R.push(v.emissiveMapUv),R.push(v.metalnessMapUv),R.push(v.roughnessMapUv),R.push(v.anisotropyMapUv),R.push(v.clearcoatMapUv),R.push(v.clearcoatNormalMapUv),R.push(v.clearcoatRoughnessMapUv),R.push(v.iridescenceMapUv),R.push(v.iridescenceThicknessMapUv),R.push(v.sheenColorMapUv),R.push(v.sheenRoughnessMapUv),R.push(v.specularMapUv),R.push(v.specularColorMapUv),R.push(v.specularIntensityMapUv),R.push(v.transmissionMapUv),R.push(v.thicknessMapUv),R.push(v.combine),R.push(v.fogExp2),R.push(v.sizeAttenuation),R.push(v.morphTargetsCount),R.push(v.morphAttributeCount),R.push(v.numDirLights),R.push(v.numPointLights),R.push(v.numSpotLights),R.push(v.numSpotLightMaps),R.push(v.numHemiLights),R.push(v.numRectAreaLights),R.push(v.numDirLightShadows),R.push(v.numPointLightShadows),R.push(v.numSpotLightShadows),R.push(v.numSpotLightShadowsWithMaps),R.push(v.numLightProbes),R.push(v.shadowMapType),R.push(v.toneMapping),R.push(v.numClippingPlanes),R.push(v.numClipIntersection),R.push(v.depthPacking)}function A(R,v){c.disableAll(),v.supportsVertexTextures&&c.enable(0),v.instancing&&c.enable(1),v.instancingColor&&c.enable(2),v.instancingMorph&&c.enable(3),v.matcap&&c.enable(4),v.envMap&&c.enable(5),v.normalMapObjectSpace&&c.enable(6),v.normalMapTangentSpace&&c.enable(7),v.clearcoat&&c.enable(8),v.iridescence&&c.enable(9),v.alphaTest&&c.enable(10),v.vertexColors&&c.enable(11),v.vertexAlphas&&c.enable(12),v.vertexUv1s&&c.enable(13),v.vertexUv2s&&c.enable(14),v.vertexUv3s&&c.enable(15),v.vertexTangents&&c.enable(16),v.anisotropy&&c.enable(17),v.alphaHash&&c.enable(18),v.batching&&c.enable(19),v.dispersion&&c.enable(20),v.batchingColor&&c.enable(21),v.gradientMap&&c.enable(22),R.push(c.mask),c.disableAll(),v.fog&&c.enable(0),v.useFog&&c.enable(1),v.flatShading&&c.enable(2),v.logarithmicDepthBuffer&&c.enable(3),v.reversedDepthBuffer&&c.enable(4),v.skinning&&c.enable(5),v.morphTargets&&c.enable(6),v.morphNormals&&c.enable(7),v.morphColors&&c.enable(8),v.premultipliedAlpha&&c.enable(9),v.shadowMapEnabled&&c.enable(10),v.doubleSided&&c.enable(11),v.flipSided&&c.enable(12),v.useDepthPacking&&c.enable(13),v.dithering&&c.enable(14),v.transmission&&c.enable(15),v.sheen&&c.enable(16),v.opaque&&c.enable(17),v.pointsUvs&&c.enable(18),v.decodeVideoTexture&&c.enable(19),v.decodeVideoTextureEmissive&&c.enable(20),v.alphaToCoverage&&c.enable(21),R.push(c.mask)}function I(R){const v=m[R.type];let P;if(v){const V=En[v];P=Lh.clone(V.uniforms)}else P=R.uniforms;return P}function D(R,v){let P;for(let V=0,Z=p.length;V<Z;V++){const Q=p[V];if(Q.cacheKey===v){P=Q,++P.usedTimes;break}}return P===void 0&&(P=new Hm(n,v,R,r),p.push(P)),P}function O(R){if(--R.usedTimes===0){const v=p.indexOf(R);p[v]=p[p.length-1],p.pop(),R.destroy()}}function C(R){h.remove(R)}function U(){h.dispose()}return{getParameters:E,getProgramCacheKey:d,getUniforms:I,acquireProgram:D,releaseProgram:O,releaseShaderCache:C,programs:p,dispose:U}}function Wm(){let n=new WeakMap;function e(o){return n.has(o)}function t(o){let c=n.get(o);return c===void 0&&(c={},n.set(o,c)),c}function i(o){n.delete(o)}function s(o,c,h){n.get(o)[c]=h}function r(){n=new WeakMap}return{has:e,get:t,remove:i,update:s,dispose:r}}function zm(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Fl(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function Bl(){const n=[];let e=0;const t=[],i=[],s=[];function r(){e=0,t.length=0,i.length=0,s.length=0}function o(a,l,f,m,S,E){let d=n[e];return d===void 0?(d={id:a.id,object:a,geometry:l,material:f,groupOrder:m,renderOrder:a.renderOrder,z:S,group:E},n[e]=d):(d.id=a.id,d.object=a,d.geometry=l,d.material=f,d.groupOrder=m,d.renderOrder=a.renderOrder,d.z=S,d.group=E),e++,d}function c(a,l,f,m,S,E){const d=o(a,l,f,m,S,E);f.transmission>0?i.push(d):f.transparent===!0?s.push(d):t.push(d)}function h(a,l,f,m,S,E){const d=o(a,l,f,m,S,E);f.transmission>0?i.unshift(d):f.transparent===!0?s.unshift(d):t.unshift(d)}function u(a,l){t.length>1&&t.sort(a||zm),i.length>1&&i.sort(l||Fl),s.length>1&&s.sort(l||Fl)}function p(){for(let a=e,l=n.length;a<l;a++){const f=n[a];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:i,transparent:s,init:r,push:c,unshift:h,finish:p,sort:u}}function Km(){let n=new WeakMap;function e(i,s){const r=n.get(i);let o;return r===void 0?(o=new Bl,n.set(i,[o])):s>=r.length?(o=new Bl,r.push(o)):o=r[s],o}function t(){n=new WeakMap}return{get:e,dispose:t}}function Xm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new G,color:new et};break;case"SpotLight":t={position:new G,direction:new G,color:new et,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new G,color:new et,distance:0,decay:0};break;case"HemisphereLight":t={direction:new G,skyColor:new et,groundColor:new et};break;case"RectAreaLight":t={color:new et,position:new G,halfWidth:new G,halfHeight:new G};break}return n[e.id]=t,t}}}function qm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let Zm=0;function Qm(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function Jm(n){const e=new Xm,t=qm(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)i.probe.push(new G);const s=new G,r=new At,o=new At;function c(u){let p=0,a=0,l=0;for(let R=0;R<9;R++)i.probe[R].set(0,0,0);let f=0,m=0,S=0,E=0,d=0,g=0,A=0,I=0,D=0,O=0,C=0;u.sort(Qm);for(let R=0,v=u.length;R<v;R++){const P=u[R],V=P.color,Z=P.intensity,Q=P.distance,j=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)p+=V.r*Z,a+=V.g*Z,l+=V.b*Z;else if(P.isLightProbe){for(let ie=0;ie<9;ie++)i.probe[ie].addScaledVector(P.sh.coefficients[ie],Z);C++}else if(P.isDirectionalLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){const J=P.shadow,B=t.get(P);B.shadowIntensity=J.intensity,B.shadowBias=J.bias,B.shadowNormalBias=J.normalBias,B.shadowRadius=J.radius,B.shadowMapSize=J.mapSize,i.directionalShadow[f]=B,i.directionalShadowMap[f]=j,i.directionalShadowMatrix[f]=P.shadow.matrix,g++}i.directional[f]=ie,f++}else if(P.isSpotLight){const ie=e.get(P);ie.position.setFromMatrixPosition(P.matrixWorld),ie.color.copy(V).multiplyScalar(Z),ie.distance=Q,ie.coneCos=Math.cos(P.angle),ie.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),ie.decay=P.decay,i.spot[S]=ie;const J=P.shadow;if(P.map&&(i.spotLightMap[D]=P.map,D++,J.updateMatrices(P),P.castShadow&&O++),i.spotLightMatrix[S]=J.matrix,P.castShadow){const B=t.get(P);B.shadowIntensity=J.intensity,B.shadowBias=J.bias,B.shadowNormalBias=J.normalBias,B.shadowRadius=J.radius,B.shadowMapSize=J.mapSize,i.spotShadow[S]=B,i.spotShadowMap[S]=j,I++}S++}else if(P.isRectAreaLight){const ie=e.get(P);ie.color.copy(V).multiplyScalar(Z),ie.halfWidth.set(P.width*.5,0,0),ie.halfHeight.set(0,P.height*.5,0),i.rectArea[E]=ie,E++}else if(P.isPointLight){const ie=e.get(P);if(ie.color.copy(P.color).multiplyScalar(P.intensity),ie.distance=P.distance,ie.decay=P.decay,P.castShadow){const J=P.shadow,B=t.get(P);B.shadowIntensity=J.intensity,B.shadowBias=J.bias,B.shadowNormalBias=J.normalBias,B.shadowRadius=J.radius,B.shadowMapSize=J.mapSize,B.shadowCameraNear=J.camera.near,B.shadowCameraFar=J.camera.far,i.pointShadow[m]=B,i.pointShadowMap[m]=j,i.pointShadowMatrix[m]=P.shadow.matrix,A++}i.point[m]=ie,m++}else if(P.isHemisphereLight){const ie=e.get(P);ie.skyColor.copy(P.color).multiplyScalar(Z),ie.groundColor.copy(P.groundColor).multiplyScalar(Z),i.hemi[d]=ie,d++}}E>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=Ie.LTC_FLOAT_1,i.rectAreaLTC2=Ie.LTC_FLOAT_2):(i.rectAreaLTC1=Ie.LTC_HALF_1,i.rectAreaLTC2=Ie.LTC_HALF_2)),i.ambient[0]=p,i.ambient[1]=a,i.ambient[2]=l;const U=i.hash;(U.directionalLength!==f||U.pointLength!==m||U.spotLength!==S||U.rectAreaLength!==E||U.hemiLength!==d||U.numDirectionalShadows!==g||U.numPointShadows!==A||U.numSpotShadows!==I||U.numSpotMaps!==D||U.numLightProbes!==C)&&(i.directional.length=f,i.spot.length=S,i.rectArea.length=E,i.point.length=m,i.hemi.length=d,i.directionalShadow.length=g,i.directionalShadowMap.length=g,i.pointShadow.length=A,i.pointShadowMap.length=A,i.spotShadow.length=I,i.spotShadowMap.length=I,i.directionalShadowMatrix.length=g,i.pointShadowMatrix.length=A,i.spotLightMatrix.length=I+D-O,i.spotLightMap.length=D,i.numSpotLightShadowsWithMaps=O,i.numLightProbes=C,U.directionalLength=f,U.pointLength=m,U.spotLength=S,U.rectAreaLength=E,U.hemiLength=d,U.numDirectionalShadows=g,U.numPointShadows=A,U.numSpotShadows=I,U.numSpotMaps=D,U.numLightProbes=C,i.version=Zm++)}function h(u,p){let a=0,l=0,f=0,m=0,S=0;const E=p.matrixWorldInverse;for(let d=0,g=u.length;d<g;d++){const A=u[d];if(A.isDirectionalLight){const I=i.directional[a];I.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),I.direction.sub(s),I.direction.transformDirection(E),a++}else if(A.isSpotLight){const I=i.spot[f];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),I.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),I.direction.sub(s),I.direction.transformDirection(E),f++}else if(A.isRectAreaLight){const I=i.rectArea[m];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),o.identity(),r.copy(A.matrixWorld),r.premultiply(E),o.extractRotation(r),I.halfWidth.set(A.width*.5,0,0),I.halfHeight.set(0,A.height*.5,0),I.halfWidth.applyMatrix4(o),I.halfHeight.applyMatrix4(o),m++}else if(A.isPointLight){const I=i.point[l];I.position.setFromMatrixPosition(A.matrixWorld),I.position.applyMatrix4(E),l++}else if(A.isHemisphereLight){const I=i.hemi[S];I.direction.setFromMatrixPosition(A.matrixWorld),I.direction.transformDirection(E),S++}}}return{setup:c,setupView:h,state:i}}function Hl(n){const e=new Jm(n),t=[],i=[];function s(p){u.camera=p,t.length=0,i.length=0}function r(p){t.push(p)}function o(p){i.push(p)}function c(){e.setup(t)}function h(p){e.setupView(t,p)}const u={lightsArray:t,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:u,setupLights:c,setupLightsView:h,pushLight:r,pushShadow:o}}function $m(n){let e=new WeakMap;function t(s,r=0){const o=e.get(s);let c;return o===void 0?(c=new Hl(n),e.set(s,[c])):r>=o.length?(c=new Hl(n),o.push(c)):c=o[r],c}function i(){e=new WeakMap}return{get:t,dispose:i}}const jm=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,eS=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function tS(n,e,t){let i=new Rc;const s=new oe,r=new oe,o=new St,c=new xf({depthPacking:Zu}),h=new _f,u={},p=t.maxTextureSize,a={[An]:Lt,[Lt]:An,[an]:an},l=new Bn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new oe},radius:{value:4}},vertexShader:jm,fragmentShader:eS}),f=l.clone();f.defines.HORIZONTAL_PASS=1;const m=new Rt;m.setAttribute("position",new un(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const S=new Tt(m,l),E=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=sc;let d=this.type;this.render=function(O,C,U){if(E.enabled===!1||E.autoUpdate===!1&&E.needsUpdate===!1||O.length===0)return;const R=n.getRenderTarget(),v=n.getActiveCubeFace(),P=n.getActiveMipmapLevel(),V=n.state;V.setBlending(Dn),V.buffers.depth.getReversed()===!0?V.buffers.color.setClear(0,0,0,0):V.buffers.color.setClear(1,1,1,1),V.buffers.depth.setTest(!0),V.setScissorTest(!1);const Z=d!==Ln&&this.type===Ln,Q=d===Ln&&this.type!==Ln;for(let j=0,ie=O.length;j<ie;j++){const J=O[j],B=J.shadow;if(B===void 0){Ke("WebGLShadowMap:",J,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;s.copy(B.mapSize);const de=B.getFrameExtents();if(s.multiply(de),r.copy(B.mapSize),(s.x>p||s.y>p)&&(s.x>p&&(r.x=Math.floor(p/de.x),s.x=r.x*de.x,B.mapSize.x=r.x),s.y>p&&(r.y=Math.floor(p/de.y),s.y=r.y*de.y,B.mapSize.y=r.y)),B.map===null||Z===!0||Q===!0){const Me=this.type!==Ln?{minFilter:Xt,magFilter:Xt}:{};B.map!==null&&B.map.dispose(),B.map=new wn(s.x,s.y,Me),B.map.texture.name=J.name+".shadowMap",B.camera.updateProjectionMatrix()}n.setRenderTarget(B.map),n.clear();const pe=B.getViewportCount();for(let Me=0;Me<pe;Me++){const He=B.getViewport(Me);o.set(r.x*He.x,r.y*He.y,r.x*He.z,r.y*He.w),V.viewport(o),B.updateMatrices(J,Me),i=B.getFrustum(),I(C,U,B.camera,J,this.type)}B.isPointLightShadow!==!0&&this.type===Ln&&g(B,U),B.needsUpdate=!1}d=this.type,E.needsUpdate=!1,n.setRenderTarget(R,v,P)};function g(O,C){const U=e.update(S);l.defines.VSM_SAMPLES!==O.blurSamples&&(l.defines.VSM_SAMPLES=O.blurSamples,f.defines.VSM_SAMPLES=O.blurSamples,l.needsUpdate=!0,f.needsUpdate=!0),O.mapPass===null&&(O.mapPass=new wn(s.x,s.y)),l.uniforms.shadow_pass.value=O.map.texture,l.uniforms.resolution.value=O.mapSize,l.uniforms.radius.value=O.radius,n.setRenderTarget(O.mapPass),n.clear(),n.renderBufferDirect(C,null,U,l,S,null),f.uniforms.shadow_pass.value=O.mapPass.texture,f.uniforms.resolution.value=O.mapSize,f.uniforms.radius.value=O.radius,n.setRenderTarget(O.map),n.clear(),n.renderBufferDirect(C,null,U,f,S,null)}function A(O,C,U,R){let v=null;const P=U.isPointLight===!0?O.customDistanceMaterial:O.customDepthMaterial;if(P!==void 0)v=P;else if(v=U.isPointLight===!0?h:c,n.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0||C.alphaToCoverage===!0){const V=v.uuid,Z=C.uuid;let Q=u[V];Q===void 0&&(Q={},u[V]=Q);let j=Q[Z];j===void 0&&(j=v.clone(),Q[Z]=j,C.addEventListener("dispose",D)),v=j}if(v.visible=C.visible,v.wireframe=C.wireframe,R===Ln?v.side=C.shadowSide!==null?C.shadowSide:C.side:v.side=C.shadowSide!==null?C.shadowSide:a[C.side],v.alphaMap=C.alphaMap,v.alphaTest=C.alphaToCoverage===!0?.5:C.alphaTest,v.map=C.map,v.clipShadows=C.clipShadows,v.clippingPlanes=C.clippingPlanes,v.clipIntersection=C.clipIntersection,v.displacementMap=C.displacementMap,v.displacementScale=C.displacementScale,v.displacementBias=C.displacementBias,v.wireframeLinewidth=C.wireframeLinewidth,v.linewidth=C.linewidth,U.isPointLight===!0&&v.isMeshDistanceMaterial===!0){const V=n.properties.get(v);V.light=U}return v}function I(O,C,U,R,v){if(O.visible===!1)return;if(O.layers.test(C.layers)&&(O.isMesh||O.isLine||O.isPoints)&&(O.castShadow||O.receiveShadow&&v===Ln)&&(!O.frustumCulled||i.intersectsObject(O))){O.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,O.matrixWorld);const Z=e.update(O),Q=O.material;if(Array.isArray(Q)){const j=Z.groups;for(let ie=0,J=j.length;ie<J;ie++){const B=j[ie],de=Q[B.materialIndex];if(de&&de.visible){const pe=A(O,de,R,v);O.onBeforeShadow(n,O,C,U,Z,pe,B),n.renderBufferDirect(U,null,Z,pe,O,B),O.onAfterShadow(n,O,C,U,Z,pe,B)}}}else if(Q.visible){const j=A(O,Q,R,v);O.onBeforeShadow(n,O,C,U,Z,j,null),n.renderBufferDirect(U,null,Z,j,O,null),O.onAfterShadow(n,O,C,U,Z,j,null)}}const V=O.children;for(let Z=0,Q=V.length;Z<Q;Z++)I(V[Z],C,U,R,v)}function D(O){O.target.removeEventListener("dispose",D);for(const U in u){const R=u[U],v=O.target.uuid;v in R&&(R[v].dispose(),delete R[v])}}}const nS={[da]:pa,[Ea]:Aa,[ma]:xa,[Fi]:Sa,[pa]:da,[Aa]:Ea,[xa]:ma,[Sa]:Fi};function iS(n,e){function t(){let F=!1;const Le=new St;let Re=null;const ve=new St(0,0,0,0);return{setMask:function(Se){Re!==Se&&!F&&(n.colorMask(Se,Se,Se,Se),Re=Se)},setLocked:function(Se){F=Se},setClear:function(Se,he,Pe,Xe,ct){ct===!0&&(Se*=Xe,he*=Xe,Pe*=Xe),Le.set(Se,he,Pe,Xe),ve.equals(Le)===!1&&(n.clearColor(Se,he,Pe,Xe),ve.copy(Le))},reset:function(){F=!1,Re=null,ve.set(-1,0,0,0)}}}function i(){let F=!1,Le=!1,Re=null,ve=null,Se=null;return{setReversed:function(he){if(Le!==he){const Pe=e.get("EXT_clip_control");he?Pe.clipControlEXT(Pe.LOWER_LEFT_EXT,Pe.ZERO_TO_ONE_EXT):Pe.clipControlEXT(Pe.LOWER_LEFT_EXT,Pe.NEGATIVE_ONE_TO_ONE_EXT),Le=he;const Xe=Se;Se=null,this.setClear(Xe)}},getReversed:function(){return Le},setTest:function(he){he?_(n.DEPTH_TEST):Y(n.DEPTH_TEST)},setMask:function(he){Re!==he&&!F&&(n.depthMask(he),Re=he)},setFunc:function(he){if(Le&&(he=nS[he]),ve!==he){switch(he){case da:n.depthFunc(n.NEVER);break;case pa:n.depthFunc(n.ALWAYS);break;case Ea:n.depthFunc(n.LESS);break;case Fi:n.depthFunc(n.LEQUAL);break;case ma:n.depthFunc(n.EQUAL);break;case Sa:n.depthFunc(n.GEQUAL);break;case Aa:n.depthFunc(n.GREATER);break;case xa:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}ve=he}},setLocked:function(he){F=he},setClear:function(he){Se!==he&&(Le&&(he=1-he),n.clearDepth(he),Se=he)},reset:function(){F=!1,Re=null,ve=null,Se=null,Le=!1}}}function s(){let F=!1,Le=null,Re=null,ve=null,Se=null,he=null,Pe=null,Xe=null,ct=null;return{setTest:function(tt){F||(tt?_(n.STENCIL_TEST):Y(n.STENCIL_TEST))},setMask:function(tt){Le!==tt&&!F&&(n.stencilMask(tt),Le=tt)},setFunc:function(tt,hn,tn){(Re!==tt||ve!==hn||Se!==tn)&&(n.stencilFunc(tt,hn,tn),Re=tt,ve=hn,Se=tn)},setOp:function(tt,hn,tn){(he!==tt||Pe!==hn||Xe!==tn)&&(n.stencilOp(tt,hn,tn),he=tt,Pe=hn,Xe=tn)},setLocked:function(tt){F=tt},setClear:function(tt){ct!==tt&&(n.clearStencil(tt),ct=tt)},reset:function(){F=!1,Le=null,Re=null,ve=null,Se=null,he=null,Pe=null,Xe=null,ct=null}}}const r=new t,o=new i,c=new s,h=new WeakMap,u=new WeakMap;let p={},a={},l=new WeakMap,f=[],m=null,S=!1,E=null,d=null,g=null,A=null,I=null,D=null,O=null,C=new et(0,0,0),U=0,R=!1,v=null,P=null,V=null,Z=null,Q=null;const j=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let ie=!1,J=0;const B=n.getParameter(n.VERSION);B.indexOf("WebGL")!==-1?(J=parseFloat(/^WebGL (\d)/.exec(B)[1]),ie=J>=1):B.indexOf("OpenGL ES")!==-1&&(J=parseFloat(/^OpenGL ES (\d)/.exec(B)[1]),ie=J>=2);let de=null,pe={};const Me=n.getParameter(n.SCISSOR_BOX),He=n.getParameter(n.VIEWPORT),Ce=new St().fromArray(Me),W=new St().fromArray(He);function w(F,Le,Re,ve){const Se=new Uint8Array(4),he=n.createTexture();n.bindTexture(F,he),n.texParameteri(F,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(F,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Pe=0;Pe<Re;Pe++)F===n.TEXTURE_3D||F===n.TEXTURE_2D_ARRAY?n.texImage3D(Le,0,n.RGBA,1,1,ve,0,n.RGBA,n.UNSIGNED_BYTE,Se):n.texImage2D(Le+Pe,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Se);return he}const M={};M[n.TEXTURE_2D]=w(n.TEXTURE_2D,n.TEXTURE_2D,1),M[n.TEXTURE_CUBE_MAP]=w(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),M[n.TEXTURE_2D_ARRAY]=w(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),M[n.TEXTURE_3D]=w(n.TEXTURE_3D,n.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),c.setClear(0),_(n.DEPTH_TEST),o.setFunc(Fi),q(!1),$(wo),_(n.CULL_FACE),H(Dn);function _(F){p[F]!==!0&&(n.enable(F),p[F]=!0)}function Y(F){p[F]!==!1&&(n.disable(F),p[F]=!1)}function se(F,Le){return a[F]!==Le?(n.bindFramebuffer(F,Le),a[F]=Le,F===n.DRAW_FRAMEBUFFER&&(a[n.FRAMEBUFFER]=Le),F===n.FRAMEBUFFER&&(a[n.DRAW_FRAMEBUFFER]=Le),!0):!1}function k(F,Le){let Re=f,ve=!1;if(F){Re=l.get(Le),Re===void 0&&(Re=[],l.set(Le,Re));const Se=F.textures;if(Re.length!==Se.length||Re[0]!==n.COLOR_ATTACHMENT0){for(let he=0,Pe=Se.length;he<Pe;he++)Re[he]=n.COLOR_ATTACHMENT0+he;Re.length=Se.length,ve=!0}}else Re[0]!==n.BACK&&(Re[0]=n.BACK,ve=!0);ve&&n.drawBuffers(Re)}function le(F){return m!==F?(n.useProgram(F),m=F,!0):!1}const Ae={[oi]:n.FUNC_ADD,[gu]:n.FUNC_SUBTRACT,[Tu]:n.FUNC_REVERSE_SUBTRACT};Ae[Ru]=n.MIN,Ae[vu]=n.MAX;const ue={[Mu]:n.ZERO,[Iu]:n.ONE,[Lu]:n.SRC_COLOR,[ha]:n.SRC_ALPHA,[Nu]:n.SRC_ALPHA_SATURATE,[Cu]:n.DST_COLOR,[Ou]:n.DST_ALPHA,[yu]:n.ONE_MINUS_SRC_COLOR,[fa]:n.ONE_MINUS_SRC_ALPHA,[Du]:n.ONE_MINUS_DST_COLOR,[bu]:n.ONE_MINUS_DST_ALPHA,[Pu]:n.CONSTANT_COLOR,[Uu]:n.ONE_MINUS_CONSTANT_COLOR,[wu]:n.CONSTANT_ALPHA,[Fu]:n.ONE_MINUS_CONSTANT_ALPHA};function H(F,Le,Re,ve,Se,he,Pe,Xe,ct,tt){if(F===Dn){S===!0&&(Y(n.BLEND),S=!1);return}if(S===!1&&(_(n.BLEND),S=!0),F!==_u){if(F!==E||tt!==R){if((d!==oi||I!==oi)&&(n.blendEquation(n.FUNC_ADD),d=oi,I=oi),tt)switch(F){case Ui:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Fo:n.blendFunc(n.ONE,n.ONE);break;case Bo:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ho:n.blendFuncSeparate(n.DST_COLOR,n.ONE_MINUS_SRC_ALPHA,n.ZERO,n.ONE);break;default:dt("WebGLState: Invalid blending: ",F);break}else switch(F){case Ui:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Fo:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE,n.ONE,n.ONE);break;case Bo:dt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Ho:dt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:dt("WebGLState: Invalid blending: ",F);break}g=null,A=null,D=null,O=null,C.set(0,0,0),U=0,E=F,R=tt}return}Se=Se||Le,he=he||Re,Pe=Pe||ve,(Le!==d||Se!==I)&&(n.blendEquationSeparate(Ae[Le],Ae[Se]),d=Le,I=Se),(Re!==g||ve!==A||he!==D||Pe!==O)&&(n.blendFuncSeparate(ue[Re],ue[ve],ue[he],ue[Pe]),g=Re,A=ve,D=he,O=Pe),(Xe.equals(C)===!1||ct!==U)&&(n.blendColor(Xe.r,Xe.g,Xe.b,ct),C.copy(Xe),U=ct),E=F,R=!1}function T(F,Le){F.side===an?Y(n.CULL_FACE):_(n.CULL_FACE);let Re=F.side===Lt;Le&&(Re=!Re),q(Re),F.blending===Ui&&F.transparent===!1?H(Dn):H(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.blendColor,F.blendAlpha,F.premultipliedAlpha),o.setFunc(F.depthFunc),o.setTest(F.depthTest),o.setMask(F.depthWrite),r.setMask(F.colorWrite);const ve=F.stencilWrite;c.setTest(ve),ve&&(c.setMask(F.stencilWriteMask),c.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),c.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),y(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?_(n.SAMPLE_ALPHA_TO_COVERAGE):Y(n.SAMPLE_ALPHA_TO_COVERAGE)}function q(F){v!==F&&(F?n.frontFace(n.CW):n.frontFace(n.CCW),v=F)}function $(F){F!==Su?(_(n.CULL_FACE),F!==P&&(F===wo?n.cullFace(n.BACK):F===Au?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Y(n.CULL_FACE),P=F}function N(F){F!==V&&(ie&&n.lineWidth(F),V=F)}function y(F,Le,Re){F?(_(n.POLYGON_OFFSET_FILL),(Z!==Le||Q!==Re)&&(n.polygonOffset(Le,Re),Z=Le,Q=Re)):Y(n.POLYGON_OFFSET_FILL)}function ae(F){F?_(n.SCISSOR_TEST):Y(n.SCISSOR_TEST)}function ce(F){F===void 0&&(F=n.TEXTURE0+j-1),de!==F&&(n.activeTexture(F),de=F)}function Te(F,Le,Re){Re===void 0&&(de===null?Re=n.TEXTURE0+j-1:Re=de);let ve=pe[Re];ve===void 0&&(ve={type:void 0,texture:void 0},pe[Re]=ve),(ve.type!==F||ve.texture!==Le)&&(de!==Re&&(n.activeTexture(Re),de=Re),n.bindTexture(F,Le||M[F]),ve.type=F,ve.texture=Le)}function b(){const F=pe[de];F!==void 0&&F.type!==void 0&&(n.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function x(){try{n.compressedTexImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function z(){try{n.compressedTexImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function re(){try{n.texSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function fe(){try{n.texSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ne(){try{n.compressedTexSubImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Ne(){try{n.compressedTexSubImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function ge(){try{n.texStorage2D(...arguments)}catch(F){F("WebGLState:",F)}}function we(){try{n.texStorage3D(...arguments)}catch(F){F("WebGLState:",F)}}function De(){try{n.texImage2D(...arguments)}catch(F){F("WebGLState:",F)}}function Ee(){try{n.texImage3D(...arguments)}catch(F){F("WebGLState:",F)}}function xe(F){Ce.equals(F)===!1&&(n.scissor(F.x,F.y,F.z,F.w),Ce.copy(F))}function ke(F){W.equals(F)===!1&&(n.viewport(F.x,F.y,F.z,F.w),W.copy(F))}function Ge(F,Le){let Re=u.get(Le);Re===void 0&&(Re=new WeakMap,u.set(Le,Re));let ve=Re.get(F);ve===void 0&&(ve=n.getUniformBlockIndex(Le,F.name),Re.set(F,ve))}function Oe(F,Le){const ve=u.get(Le).get(F);h.get(Le)!==ve&&(n.uniformBlockBinding(Le,ve,F.__bindingPointIndex),h.set(Le,ve))}function ze(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),o.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),p={},de=null,pe={},a={},l=new WeakMap,f=[],m=null,S=!1,E=null,d=null,g=null,A=null,I=null,D=null,O=null,C=new et(0,0,0),U=0,R=!1,v=null,P=null,V=null,Z=null,Q=null,Ce.set(0,0,n.canvas.width,n.canvas.height),W.set(0,0,n.canvas.width,n.canvas.height),r.reset(),o.reset(),c.reset()}return{buffers:{color:r,depth:o,stencil:c},enable:_,disable:Y,bindFramebuffer:se,drawBuffers:k,useProgram:le,setBlending:H,setMaterial:T,setFlipSided:q,setCullFace:$,setLineWidth:N,setPolygonOffset:y,setScissorTest:ae,activeTexture:ce,bindTexture:Te,unbindTexture:b,compressedTexImage2D:x,compressedTexImage3D:z,texImage2D:De,texImage3D:Ee,updateUBOMapping:Ge,uniformBlockBinding:Oe,texStorage2D:ge,texStorage3D:we,texSubImage2D:re,texSubImage3D:fe,compressedTexSubImage2D:ne,compressedTexSubImage3D:Ne,scissor:xe,viewport:ke,reset:ze}}function sS(n,e,t,i,s,r,o){const c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,h=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new oe,p=new WeakMap;let a;const l=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(b,x){return f?new OffscreenCanvas(b,x):ur("canvas")}function S(b,x,z){let re=1;const fe=Te(b);if((fe.width>z||fe.height>z)&&(re=z/Math.max(fe.width,fe.height)),re<1)if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&b instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&b instanceof ImageBitmap||typeof VideoFrame<"u"&&b instanceof VideoFrame){const ne=Math.floor(re*fe.width),Ne=Math.floor(re*fe.height);a===void 0&&(a=m(ne,Ne));const ge=x?m(ne,Ne):a;return ge.width=ne,ge.height=Ne,ge.getContext("2d").drawImage(b,0,0,ne,Ne),Ke("WebGLRenderer: Texture has been resized from ("+fe.width+"x"+fe.height+") to ("+ne+"x"+Ne+")."),ge}else return"data"in b&&Ke("WebGLRenderer: Image in DataTexture is too big ("+fe.width+"x"+fe.height+")."),b;return b}function E(b){return b.generateMipmaps}function d(b){n.generateMipmap(b)}function g(b){return b.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:b.isWebGL3DRenderTarget?n.TEXTURE_3D:b.isWebGLArrayRenderTarget||b.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function A(b,x,z,re,fe=!1){if(b!==null){if(n[b]!==void 0)return n[b];Ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+b+"'")}let ne=x;if(x===n.RED&&(z===n.FLOAT&&(ne=n.R32F),z===n.HALF_FLOAT&&(ne=n.R16F),z===n.UNSIGNED_BYTE&&(ne=n.R8)),x===n.RED_INTEGER&&(z===n.UNSIGNED_BYTE&&(ne=n.R8UI),z===n.UNSIGNED_SHORT&&(ne=n.R16UI),z===n.UNSIGNED_INT&&(ne=n.R32UI),z===n.BYTE&&(ne=n.R8I),z===n.SHORT&&(ne=n.R16I),z===n.INT&&(ne=n.R32I)),x===n.RG&&(z===n.FLOAT&&(ne=n.RG32F),z===n.HALF_FLOAT&&(ne=n.RG16F),z===n.UNSIGNED_BYTE&&(ne=n.RG8)),x===n.RG_INTEGER&&(z===n.UNSIGNED_BYTE&&(ne=n.RG8UI),z===n.UNSIGNED_SHORT&&(ne=n.RG16UI),z===n.UNSIGNED_INT&&(ne=n.RG32UI),z===n.BYTE&&(ne=n.RG8I),z===n.SHORT&&(ne=n.RG16I),z===n.INT&&(ne=n.RG32I)),x===n.RGB_INTEGER&&(z===n.UNSIGNED_BYTE&&(ne=n.RGB8UI),z===n.UNSIGNED_SHORT&&(ne=n.RGB16UI),z===n.UNSIGNED_INT&&(ne=n.RGB32UI),z===n.BYTE&&(ne=n.RGB8I),z===n.SHORT&&(ne=n.RGB16I),z===n.INT&&(ne=n.RGB32I)),x===n.RGBA_INTEGER&&(z===n.UNSIGNED_BYTE&&(ne=n.RGBA8UI),z===n.UNSIGNED_SHORT&&(ne=n.RGBA16UI),z===n.UNSIGNED_INT&&(ne=n.RGBA32UI),z===n.BYTE&&(ne=n.RGBA8I),z===n.SHORT&&(ne=n.RGBA16I),z===n.INT&&(ne=n.RGBA32I)),x===n.RGB&&(z===n.UNSIGNED_INT_5_9_9_9_REV&&(ne=n.RGB9_E5),z===n.UNSIGNED_INT_10F_11F_11F_REV&&(ne=n.R11F_G11F_B10F)),x===n.RGBA){const Ne=fe?lr:$e.getTransfer(re);z===n.FLOAT&&(ne=n.RGBA32F),z===n.HALF_FLOAT&&(ne=n.RGBA16F),z===n.UNSIGNED_BYTE&&(ne=Ne===st?n.SRGB8_ALPHA8:n.RGBA8),z===n.UNSIGNED_SHORT_4_4_4_4&&(ne=n.RGBA4),z===n.UNSIGNED_SHORT_5_5_5_1&&(ne=n.RGB5_A1)}return(ne===n.R16F||ne===n.R32F||ne===n.RG16F||ne===n.RG32F||ne===n.RGBA16F||ne===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function I(b,x){let z;return b?x===null||x===fi||x===Ss?z=n.DEPTH24_STENCIL8:x===bn?z=n.DEPTH32F_STENCIL8:x===ms&&(z=n.DEPTH24_STENCIL8,Ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):x===null||x===fi||x===Ss?z=n.DEPTH_COMPONENT24:x===bn?z=n.DEPTH_COMPONENT32F:x===ms&&(z=n.DEPTH_COMPONENT16),z}function D(b,x){return E(b)===!0||b.isFramebufferTexture&&b.minFilter!==Xt&&b.minFilter!==en?Math.log2(Math.max(x.width,x.height))+1:b.mipmaps!==void 0&&b.mipmaps.length>0?b.mipmaps.length:b.isCompressedTexture&&Array.isArray(b.image)?x.mipmaps.length:1}function O(b){const x=b.target;x.removeEventListener("dispose",O),U(x),x.isVideoTexture&&p.delete(x)}function C(b){const x=b.target;x.removeEventListener("dispose",C),v(x)}function U(b){const x=i.get(b);if(x.__webglInit===void 0)return;const z=b.source,re=l.get(z);if(re){const fe=re[x.__cacheKey];fe.usedTimes--,fe.usedTimes===0&&R(b),Object.keys(re).length===0&&l.delete(z)}i.remove(b)}function R(b){const x=i.get(b);n.deleteTexture(x.__webglTexture);const z=b.source,re=l.get(z);delete re[x.__cacheKey],o.memory.textures--}function v(b){const x=i.get(b);if(b.depthTexture&&(b.depthTexture.dispose(),i.remove(b.depthTexture)),b.isWebGLCubeRenderTarget)for(let re=0;re<6;re++){if(Array.isArray(x.__webglFramebuffer[re]))for(let fe=0;fe<x.__webglFramebuffer[re].length;fe++)n.deleteFramebuffer(x.__webglFramebuffer[re][fe]);else n.deleteFramebuffer(x.__webglFramebuffer[re]);x.__webglDepthbuffer&&n.deleteRenderbuffer(x.__webglDepthbuffer[re])}else{if(Array.isArray(x.__webglFramebuffer))for(let re=0;re<x.__webglFramebuffer.length;re++)n.deleteFramebuffer(x.__webglFramebuffer[re]);else n.deleteFramebuffer(x.__webglFramebuffer);if(x.__webglDepthbuffer&&n.deleteRenderbuffer(x.__webglDepthbuffer),x.__webglMultisampledFramebuffer&&n.deleteFramebuffer(x.__webglMultisampledFramebuffer),x.__webglColorRenderbuffer)for(let re=0;re<x.__webglColorRenderbuffer.length;re++)x.__webglColorRenderbuffer[re]&&n.deleteRenderbuffer(x.__webglColorRenderbuffer[re]);x.__webglDepthRenderbuffer&&n.deleteRenderbuffer(x.__webglDepthRenderbuffer)}const z=b.textures;for(let re=0,fe=z.length;re<fe;re++){const ne=i.get(z[re]);ne.__webglTexture&&(n.deleteTexture(ne.__webglTexture),o.memory.textures--),i.remove(z[re])}i.remove(b)}let P=0;function V(){P=0}function Z(){const b=P;return b>=s.maxTextures&&Ke("WebGLTextures: Trying to use "+b+" texture units while this GPU supports only "+s.maxTextures),P+=1,b}function Q(b){const x=[];return x.push(b.wrapS),x.push(b.wrapT),x.push(b.wrapR||0),x.push(b.magFilter),x.push(b.minFilter),x.push(b.anisotropy),x.push(b.internalFormat),x.push(b.format),x.push(b.type),x.push(b.generateMipmaps),x.push(b.premultiplyAlpha),x.push(b.flipY),x.push(b.unpackAlignment),x.push(b.colorSpace),x.join()}function j(b,x){const z=i.get(b);if(b.isVideoTexture&&ae(b),b.isRenderTargetTexture===!1&&b.isExternalTexture!==!0&&b.version>0&&z.__version!==b.version){const re=b.image;if(re===null)Ke("WebGLRenderer: Texture marked for update but no image data found.");else if(re.complete===!1)Ke("WebGLRenderer: Texture marked for update but image is incomplete");else{M(z,b,x);return}}else b.isExternalTexture&&(z.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D,z.__webglTexture,n.TEXTURE0+x)}function ie(b,x){const z=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&z.__version!==b.version){M(z,b,x);return}else b.isExternalTexture&&(z.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D_ARRAY,z.__webglTexture,n.TEXTURE0+x)}function J(b,x){const z=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&z.__version!==b.version){M(z,b,x);return}t.bindTexture(n.TEXTURE_3D,z.__webglTexture,n.TEXTURE0+x)}function B(b,x){const z=i.get(b);if(b.version>0&&z.__version!==b.version){_(z,b,x);return}t.bindTexture(n.TEXTURE_CUBE_MAP,z.__webglTexture,n.TEXTURE0+x)}const de={[Ta]:n.REPEAT,[On]:n.CLAMP_TO_EDGE,[Ra]:n.MIRRORED_REPEAT},pe={[Xt]:n.NEAREST,[Xu]:n.NEAREST_MIPMAP_NEAREST,[Os]:n.NEAREST_MIPMAP_LINEAR,[en]:n.LINEAR,[Ir]:n.LINEAR_MIPMAP_NEAREST,[ui]:n.LINEAR_MIPMAP_LINEAR},Me={[$u]:n.NEVER,[sh]:n.ALWAYS,[ju]:n.LESS,[pc]:n.LEQUAL,[eh]:n.EQUAL,[ih]:n.GEQUAL,[th]:n.GREATER,[nh]:n.NOTEQUAL};function He(b,x){if(x.type===bn&&e.has("OES_texture_float_linear")===!1&&(x.magFilter===en||x.magFilter===Ir||x.magFilter===Os||x.magFilter===ui||x.minFilter===en||x.minFilter===Ir||x.minFilter===Os||x.minFilter===ui)&&Ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(b,n.TEXTURE_WRAP_S,de[x.wrapS]),n.texParameteri(b,n.TEXTURE_WRAP_T,de[x.wrapT]),(b===n.TEXTURE_3D||b===n.TEXTURE_2D_ARRAY)&&n.texParameteri(b,n.TEXTURE_WRAP_R,de[x.wrapR]),n.texParameteri(b,n.TEXTURE_MAG_FILTER,pe[x.magFilter]),n.texParameteri(b,n.TEXTURE_MIN_FILTER,pe[x.minFilter]),x.compareFunction&&(n.texParameteri(b,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(b,n.TEXTURE_COMPARE_FUNC,Me[x.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(x.magFilter===Xt||x.minFilter!==Os&&x.minFilter!==ui||x.type===bn&&e.has("OES_texture_float_linear")===!1)return;if(x.anisotropy>1||i.get(x).__currentAnisotropy){const z=e.get("EXT_texture_filter_anisotropic");n.texParameterf(b,z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(x.anisotropy,s.getMaxAnisotropy())),i.get(x).__currentAnisotropy=x.anisotropy}}}function Ce(b,x){let z=!1;b.__webglInit===void 0&&(b.__webglInit=!0,x.addEventListener("dispose",O));const re=x.source;let fe=l.get(re);fe===void 0&&(fe={},l.set(re,fe));const ne=Q(x);if(ne!==b.__cacheKey){fe[ne]===void 0&&(fe[ne]={texture:n.createTexture(),usedTimes:0},o.memory.textures++,z=!0),fe[ne].usedTimes++;const Ne=fe[b.__cacheKey];Ne!==void 0&&(fe[b.__cacheKey].usedTimes--,Ne.usedTimes===0&&R(x)),b.__cacheKey=ne,b.__webglTexture=fe[ne].texture}return z}function W(b,x,z){return Math.floor(Math.floor(b/z)/x)}function w(b,x,z,re){const ne=b.updateRanges;if(ne.length===0)t.texSubImage2D(n.TEXTURE_2D,0,0,0,x.width,x.height,z,re,x.data);else{ne.sort((Ee,xe)=>Ee.start-xe.start);let Ne=0;for(let Ee=1;Ee<ne.length;Ee++){const xe=ne[Ne],ke=ne[Ee],Ge=xe.start+xe.count,Oe=W(ke.start,x.width,4),ze=W(xe.start,x.width,4);ke.start<=Ge+1&&Oe===ze&&W(ke.start+ke.count-1,x.width,4)===Oe?xe.count=Math.max(xe.count,ke.start+ke.count-xe.start):(++Ne,ne[Ne]=ke)}ne.length=Ne+1;const ge=n.getParameter(n.UNPACK_ROW_LENGTH),we=n.getParameter(n.UNPACK_SKIP_PIXELS),De=n.getParameter(n.UNPACK_SKIP_ROWS);n.pixelStorei(n.UNPACK_ROW_LENGTH,x.width);for(let Ee=0,xe=ne.length;Ee<xe;Ee++){const ke=ne[Ee],Ge=Math.floor(ke.start/4),Oe=Math.ceil(ke.count/4),ze=Ge%x.width,F=Math.floor(Ge/x.width),Le=Oe,Re=1;n.pixelStorei(n.UNPACK_SKIP_PIXELS,ze),n.pixelStorei(n.UNPACK_SKIP_ROWS,F),t.texSubImage2D(n.TEXTURE_2D,0,ze,F,Le,Re,z,re,x.data)}b.clearUpdateRanges(),n.pixelStorei(n.UNPACK_ROW_LENGTH,ge),n.pixelStorei(n.UNPACK_SKIP_PIXELS,we),n.pixelStorei(n.UNPACK_SKIP_ROWS,De)}}function M(b,x,z){let re=n.TEXTURE_2D;(x.isDataArrayTexture||x.isCompressedArrayTexture)&&(re=n.TEXTURE_2D_ARRAY),x.isData3DTexture&&(re=n.TEXTURE_3D);const fe=Ce(b,x),ne=x.source;t.bindTexture(re,b.__webglTexture,n.TEXTURE0+z);const Ne=i.get(ne);if(ne.version!==Ne.__version||fe===!0){t.activeTexture(n.TEXTURE0+z);const ge=$e.getPrimaries($e.workingColorSpace),we=x.colorSpace===Xn?null:$e.getPrimaries(x.colorSpace),De=x.colorSpace===Xn||ge===we?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,x.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,x.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,De);let Ee=S(x.image,!1,s.maxTextureSize);Ee=ce(x,Ee);const xe=r.convert(x.format,x.colorSpace),ke=r.convert(x.type);let Ge=A(x.internalFormat,xe,ke,x.colorSpace,x.isVideoTexture);He(re,x);let Oe;const ze=x.mipmaps,F=x.isVideoTexture!==!0,Le=Ne.__version===void 0||fe===!0,Re=ne.dataReady,ve=D(x,Ee);if(x.isDepthTexture)Ge=I(x.format===xs,x.type),Le&&(F?t.texStorage2D(n.TEXTURE_2D,1,Ge,Ee.width,Ee.height):t.texImage2D(n.TEXTURE_2D,0,Ge,Ee.width,Ee.height,0,xe,ke,null));else if(x.isDataTexture)if(ze.length>0){F&&Le&&t.texStorage2D(n.TEXTURE_2D,ve,Ge,ze[0].width,ze[0].height);for(let Se=0,he=ze.length;Se<he;Se++)Oe=ze[Se],F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,xe,ke,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,Ge,Oe.width,Oe.height,0,xe,ke,Oe.data);x.generateMipmaps=!1}else F?(Le&&t.texStorage2D(n.TEXTURE_2D,ve,Ge,Ee.width,Ee.height),Re&&w(x,Ee,xe,ke)):t.texImage2D(n.TEXTURE_2D,0,Ge,Ee.width,Ee.height,0,xe,ke,Ee.data);else if(x.isCompressedTexture)if(x.isCompressedArrayTexture){F&&Le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,Ge,ze[0].width,ze[0].height,Ee.depth);for(let Se=0,he=ze.length;Se<he;Se++)if(Oe=ze[Se],x.format!==ln)if(xe!==null)if(F){if(Re)if(x.layerUpdates.size>0){const Pe=ml(Oe.width,Oe.height,x.format,x.type);for(const Xe of x.layerUpdates){const ct=Oe.data.subarray(Xe*Pe/Oe.data.BYTES_PER_ELEMENT,(Xe+1)*Pe/Oe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,Xe,Oe.width,Oe.height,1,xe,ct)}x.clearLayerUpdates()}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,Ee.depth,xe,Oe.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Se,Ge,Oe.width,Oe.height,Ee.depth,0,Oe.data,0,0);else Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else F?Re&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,Ee.depth,xe,ke,Oe.data):t.texImage3D(n.TEXTURE_2D_ARRAY,Se,Ge,Oe.width,Oe.height,Ee.depth,0,xe,ke,Oe.data)}else{F&&Le&&t.texStorage2D(n.TEXTURE_2D,ve,Ge,ze[0].width,ze[0].height);for(let Se=0,he=ze.length;Se<he;Se++)Oe=ze[Se],x.format!==ln?xe!==null?F?Re&&t.compressedTexSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,xe,Oe.data):t.compressedTexImage2D(n.TEXTURE_2D,Se,Ge,Oe.width,Oe.height,0,Oe.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,xe,ke,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,Ge,Oe.width,Oe.height,0,xe,ke,Oe.data)}else if(x.isDataArrayTexture)if(F){if(Le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,Ge,Ee.width,Ee.height,Ee.depth),Re)if(x.layerUpdates.size>0){const Se=ml(Ee.width,Ee.height,x.format,x.type);for(const he of x.layerUpdates){const Pe=Ee.data.subarray(he*Se/Ee.data.BYTES_PER_ELEMENT,(he+1)*Se/Ee.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,he,Ee.width,Ee.height,1,xe,ke,Pe)}x.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,Ee.width,Ee.height,Ee.depth,xe,ke,Ee.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,Ge,Ee.width,Ee.height,Ee.depth,0,xe,ke,Ee.data);else if(x.isData3DTexture)F?(Le&&t.texStorage3D(n.TEXTURE_3D,ve,Ge,Ee.width,Ee.height,Ee.depth),Re&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,Ee.width,Ee.height,Ee.depth,xe,ke,Ee.data)):t.texImage3D(n.TEXTURE_3D,0,Ge,Ee.width,Ee.height,Ee.depth,0,xe,ke,Ee.data);else if(x.isFramebufferTexture){if(Le)if(F)t.texStorage2D(n.TEXTURE_2D,ve,Ge,Ee.width,Ee.height);else{let Se=Ee.width,he=Ee.height;for(let Pe=0;Pe<ve;Pe++)t.texImage2D(n.TEXTURE_2D,Pe,Ge,Se,he,0,xe,ke,null),Se>>=1,he>>=1}}else if(ze.length>0){if(F&&Le){const Se=Te(ze[0]);t.texStorage2D(n.TEXTURE_2D,ve,Ge,Se.width,Se.height)}for(let Se=0,he=ze.length;Se<he;Se++)Oe=ze[Se],F?Re&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,xe,ke,Oe):t.texImage2D(n.TEXTURE_2D,Se,Ge,xe,ke,Oe);x.generateMipmaps=!1}else if(F){if(Le){const Se=Te(Ee);t.texStorage2D(n.TEXTURE_2D,ve,Ge,Se.width,Se.height)}Re&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,xe,ke,Ee)}else t.texImage2D(n.TEXTURE_2D,0,Ge,xe,ke,Ee);E(x)&&d(re),Ne.__version=ne.version,x.onUpdate&&x.onUpdate(x)}b.__version=x.version}function _(b,x,z){if(x.image.length!==6)return;const re=Ce(b,x),fe=x.source;t.bindTexture(n.TEXTURE_CUBE_MAP,b.__webglTexture,n.TEXTURE0+z);const ne=i.get(fe);if(fe.version!==ne.__version||re===!0){t.activeTexture(n.TEXTURE0+z);const Ne=$e.getPrimaries($e.workingColorSpace),ge=x.colorSpace===Xn?null:$e.getPrimaries(x.colorSpace),we=x.colorSpace===Xn||Ne===ge?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,x.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,x.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,we);const De=x.isCompressedTexture||x.image[0].isCompressedTexture,Ee=x.image[0]&&x.image[0].isDataTexture,xe=[];for(let he=0;he<6;he++)!De&&!Ee?xe[he]=S(x.image[he],!0,s.maxCubemapSize):xe[he]=Ee?x.image[he].image:x.image[he],xe[he]=ce(x,xe[he]);const ke=xe[0],Ge=r.convert(x.format,x.colorSpace),Oe=r.convert(x.type),ze=A(x.internalFormat,Ge,Oe,x.colorSpace),F=x.isVideoTexture!==!0,Le=ne.__version===void 0||re===!0,Re=fe.dataReady;let ve=D(x,ke);He(n.TEXTURE_CUBE_MAP,x);let Se;if(De){F&&Le&&t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,ze,ke.width,ke.height);for(let he=0;he<6;he++){Se=xe[he].mipmaps;for(let Pe=0;Pe<Se.length;Pe++){const Xe=Se[Pe];x.format!==ln?Ge!==null?F?Re&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe,0,0,Xe.width,Xe.height,Ge,Xe.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe,ze,Xe.width,Xe.height,0,Xe.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe,0,0,Xe.width,Xe.height,Ge,Oe,Xe.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe,ze,Xe.width,Xe.height,0,Ge,Oe,Xe.data)}}}else{if(Se=x.mipmaps,F&&Le){Se.length>0&&ve++;const he=Te(xe[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,ze,he.width,he.height)}for(let he=0;he<6;he++)if(Ee){F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,0,0,xe[he].width,xe[he].height,Ge,Oe,xe[he].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,ze,xe[he].width,xe[he].height,0,Ge,Oe,xe[he].data);for(let Pe=0;Pe<Se.length;Pe++){const ct=Se[Pe].image[he].image;F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe+1,0,0,ct.width,ct.height,Ge,Oe,ct.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe+1,ze,ct.width,ct.height,0,Ge,Oe,ct.data)}}else{F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,0,0,Ge,Oe,xe[he]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,0,ze,Ge,Oe,xe[he]);for(let Pe=0;Pe<Se.length;Pe++){const Xe=Se[Pe];F?Re&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe+1,0,0,Ge,Oe,Xe.image[he]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+he,Pe+1,ze,Ge,Oe,Xe.image[he])}}}E(x)&&d(n.TEXTURE_CUBE_MAP),ne.__version=fe.version,x.onUpdate&&x.onUpdate(x)}b.__version=x.version}function Y(b,x,z,re,fe,ne){const Ne=r.convert(z.format,z.colorSpace),ge=r.convert(z.type),we=A(z.internalFormat,Ne,ge,z.colorSpace),De=i.get(x),Ee=i.get(z);if(Ee.__renderTarget=x,!De.__hasExternalTextures){const xe=Math.max(1,x.width>>ne),ke=Math.max(1,x.height>>ne);fe===n.TEXTURE_3D||fe===n.TEXTURE_2D_ARRAY?t.texImage3D(fe,ne,we,xe,ke,x.depth,0,Ne,ge,null):t.texImage2D(fe,ne,we,xe,ke,0,Ne,ge,null)}t.bindFramebuffer(n.FRAMEBUFFER,b),y(x)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,re,fe,Ee.__webglTexture,0,N(x)):(fe===n.TEXTURE_2D||fe>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&fe<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,re,fe,Ee.__webglTexture,ne),t.bindFramebuffer(n.FRAMEBUFFER,null)}function se(b,x,z){if(n.bindRenderbuffer(n.RENDERBUFFER,b),x.depthBuffer){const re=x.depthTexture,fe=re&&re.isDepthTexture?re.type:null,ne=I(x.stencilBuffer,fe),Ne=x.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ge=N(x);y(x)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ge,ne,x.width,x.height):z?n.renderbufferStorageMultisample(n.RENDERBUFFER,ge,ne,x.width,x.height):n.renderbufferStorage(n.RENDERBUFFER,ne,x.width,x.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,Ne,n.RENDERBUFFER,b)}else{const re=x.textures;for(let fe=0;fe<re.length;fe++){const ne=re[fe],Ne=r.convert(ne.format,ne.colorSpace),ge=r.convert(ne.type),we=A(ne.internalFormat,Ne,ge,ne.colorSpace),De=N(x);z&&y(x)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,De,we,x.width,x.height):y(x)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,De,we,x.width,x.height):n.renderbufferStorage(n.RENDERBUFFER,we,x.width,x.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function k(b,x){if(x&&x.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,b),!(x.depthTexture&&x.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const re=i.get(x.depthTexture);re.__renderTarget=x,(!re.__webglTexture||x.depthTexture.image.width!==x.width||x.depthTexture.image.height!==x.height)&&(x.depthTexture.image.width=x.width,x.depthTexture.image.height=x.height,x.depthTexture.needsUpdate=!0),j(x.depthTexture,0);const fe=re.__webglTexture,ne=N(x);if(x.depthTexture.format===As)y(x)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,fe,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,fe,0);else if(x.depthTexture.format===xs)y(x)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,fe,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,fe,0);else throw new Error("Unknown depthTexture format")}function le(b){const x=i.get(b),z=b.isWebGLCubeRenderTarget===!0;if(x.__boundDepthTexture!==b.depthTexture){const re=b.depthTexture;if(x.__depthDisposeCallback&&x.__depthDisposeCallback(),re){const fe=()=>{delete x.__boundDepthTexture,delete x.__depthDisposeCallback,re.removeEventListener("dispose",fe)};re.addEventListener("dispose",fe),x.__depthDisposeCallback=fe}x.__boundDepthTexture=re}if(b.depthTexture&&!x.__autoAllocateDepthBuffer){if(z)throw new Error("target.depthTexture not supported in Cube render targets");const re=b.texture.mipmaps;re&&re.length>0?k(x.__webglFramebuffer[0],b):k(x.__webglFramebuffer,b)}else if(z){x.__webglDepthbuffer=[];for(let re=0;re<6;re++)if(t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer[re]),x.__webglDepthbuffer[re]===void 0)x.__webglDepthbuffer[re]=n.createRenderbuffer(),se(x.__webglDepthbuffer[re],b,!1);else{const fe=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer[re];n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,fe,n.RENDERBUFFER,ne)}}else{const re=b.texture.mipmaps;if(re&&re.length>0?t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer[0]):t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer),x.__webglDepthbuffer===void 0)x.__webglDepthbuffer=n.createRenderbuffer(),se(x.__webglDepthbuffer,b,!1);else{const fe=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,fe,n.RENDERBUFFER,ne)}}t.bindFramebuffer(n.FRAMEBUFFER,null)}function Ae(b,x,z){const re=i.get(b);x!==void 0&&Y(re.__webglFramebuffer,b,b.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),z!==void 0&&le(b)}function ue(b){const x=b.texture,z=i.get(b),re=i.get(x);b.addEventListener("dispose",C);const fe=b.textures,ne=b.isWebGLCubeRenderTarget===!0,Ne=fe.length>1;if(Ne||(re.__webglTexture===void 0&&(re.__webglTexture=n.createTexture()),re.__version=x.version,o.memory.textures++),ne){z.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(x.mipmaps&&x.mipmaps.length>0){z.__webglFramebuffer[ge]=[];for(let we=0;we<x.mipmaps.length;we++)z.__webglFramebuffer[ge][we]=n.createFramebuffer()}else z.__webglFramebuffer[ge]=n.createFramebuffer()}else{if(x.mipmaps&&x.mipmaps.length>0){z.__webglFramebuffer=[];for(let ge=0;ge<x.mipmaps.length;ge++)z.__webglFramebuffer[ge]=n.createFramebuffer()}else z.__webglFramebuffer=n.createFramebuffer();if(Ne)for(let ge=0,we=fe.length;ge<we;ge++){const De=i.get(fe[ge]);De.__webglTexture===void 0&&(De.__webglTexture=n.createTexture(),o.memory.textures++)}if(b.samples>0&&y(b)===!1){z.__webglMultisampledFramebuffer=n.createFramebuffer(),z.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,z.__webglMultisampledFramebuffer);for(let ge=0;ge<fe.length;ge++){const we=fe[ge];z.__webglColorRenderbuffer[ge]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,z.__webglColorRenderbuffer[ge]);const De=r.convert(we.format,we.colorSpace),Ee=r.convert(we.type),xe=A(we.internalFormat,De,Ee,we.colorSpace,b.isXRRenderTarget===!0),ke=N(b);n.renderbufferStorageMultisample(n.RENDERBUFFER,ke,xe,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ge,n.RENDERBUFFER,z.__webglColorRenderbuffer[ge])}n.bindRenderbuffer(n.RENDERBUFFER,null),b.depthBuffer&&(z.__webglDepthRenderbuffer=n.createRenderbuffer(),se(z.__webglDepthRenderbuffer,b,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(ne){t.bindTexture(n.TEXTURE_CUBE_MAP,re.__webglTexture),He(n.TEXTURE_CUBE_MAP,x);for(let ge=0;ge<6;ge++)if(x.mipmaps&&x.mipmaps.length>0)for(let we=0;we<x.mipmaps.length;we++)Y(z.__webglFramebuffer[ge][we],b,x,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,we);else Y(z.__webglFramebuffer[ge],b,x,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);E(x)&&d(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ne){for(let ge=0,we=fe.length;ge<we;ge++){const De=fe[ge],Ee=i.get(De);let xe=n.TEXTURE_2D;(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(xe=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(xe,Ee.__webglTexture),He(xe,De),Y(z.__webglFramebuffer,b,De,n.COLOR_ATTACHMENT0+ge,xe,0),E(De)&&d(xe)}t.unbindTexture()}else{let ge=n.TEXTURE_2D;if((b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(ge=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(ge,re.__webglTexture),He(ge,x),x.mipmaps&&x.mipmaps.length>0)for(let we=0;we<x.mipmaps.length;we++)Y(z.__webglFramebuffer[we],b,x,n.COLOR_ATTACHMENT0,ge,we);else Y(z.__webglFramebuffer,b,x,n.COLOR_ATTACHMENT0,ge,0);E(x)&&d(ge),t.unbindTexture()}b.depthBuffer&&le(b)}function H(b){const x=b.textures;for(let z=0,re=x.length;z<re;z++){const fe=x[z];if(E(fe)){const ne=g(b),Ne=i.get(fe).__webglTexture;t.bindTexture(ne,Ne),d(ne),t.unbindTexture()}}}const T=[],q=[];function $(b){if(b.samples>0){if(y(b)===!1){const x=b.textures,z=b.width,re=b.height;let fe=n.COLOR_BUFFER_BIT;const ne=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,Ne=i.get(b),ge=x.length>1;if(ge)for(let De=0;De<x.length;De++)t.bindFramebuffer(n.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+De,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,Ne.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+De,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer);const we=b.texture.mipmaps;we&&we.length>0?t.bindFramebuffer(n.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer[0]):t.bindFramebuffer(n.DRAW_FRAMEBUFFER,Ne.__webglFramebuffer);for(let De=0;De<x.length;De++){if(b.resolveDepthBuffer&&(b.depthBuffer&&(fe|=n.DEPTH_BUFFER_BIT),b.stencilBuffer&&b.resolveStencilBuffer&&(fe|=n.STENCIL_BUFFER_BIT)),ge){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,Ne.__webglColorRenderbuffer[De]);const Ee=i.get(x[De]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,Ee,0)}n.blitFramebuffer(0,0,z,re,0,0,z,re,fe,n.NEAREST),h===!0&&(T.length=0,q.length=0,T.push(n.COLOR_ATTACHMENT0+De),b.depthBuffer&&b.resolveDepthBuffer===!1&&(T.push(ne),q.push(ne),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,q)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,T))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),ge)for(let De=0;De<x.length;De++){t.bindFramebuffer(n.FRAMEBUFFER,Ne.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+De,n.RENDERBUFFER,Ne.__webglColorRenderbuffer[De]);const Ee=i.get(x[De]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,Ne.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+De,n.TEXTURE_2D,Ee,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,Ne.__webglMultisampledFramebuffer)}else if(b.depthBuffer&&b.resolveDepthBuffer===!1&&h){const x=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[x])}}}function N(b){return Math.min(s.maxSamples,b.samples)}function y(b){const x=i.get(b);return b.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&x.__useRenderToTexture!==!1}function ae(b){const x=o.render.frame;p.get(b)!==x&&(p.set(b,x),b.update())}function ce(b,x){const z=b.colorSpace,re=b.format,fe=b.type;return b.isCompressedTexture===!0||b.isVideoTexture===!0||z!==Gi&&z!==Xn&&($e.getTransfer(z)===st?(re!==ln||fe!==Pn)&&Ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):dt("WebGLTextures: Unsupported texture color space:",z)),x}function Te(b){return typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement?(u.width=b.naturalWidth||b.width,u.height=b.naturalHeight||b.height):typeof VideoFrame<"u"&&b instanceof VideoFrame?(u.width=b.displayWidth,u.height=b.displayHeight):(u.width=b.width,u.height=b.height),u}this.allocateTextureUnit=Z,this.resetTextureUnits=V,this.setTexture2D=j,this.setTexture2DArray=ie,this.setTexture3D=J,this.setTextureCube=B,this.rebindTextures=Ae,this.setupRenderTarget=ue,this.updateRenderTargetMipmap=H,this.updateMultisampleRenderTarget=$,this.setupDepthRenderbuffer=le,this.setupFrameBufferTexture=Y,this.useMultisampledRTT=y}function rS(n,e){function t(i,s=Xn){let r;const o=$e.getTransfer(s);if(i===Pn)return n.UNSIGNED_BYTE;if(i===oo)return n.UNSIGNED_SHORT_4_4_4_4;if(i===lo)return n.UNSIGNED_SHORT_5_5_5_1;if(i===cc)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===uc)return n.UNSIGNED_INT_10F_11F_11F_REV;if(i===oc)return n.BYTE;if(i===lc)return n.SHORT;if(i===ms)return n.UNSIGNED_SHORT;if(i===ao)return n.INT;if(i===fi)return n.UNSIGNED_INT;if(i===bn)return n.FLOAT;if(i===Wi)return n.HALF_FLOAT;if(i===hc)return n.ALPHA;if(i===fc)return n.RGB;if(i===ln)return n.RGBA;if(i===As)return n.DEPTH_COMPONENT;if(i===xs)return n.DEPTH_STENCIL;if(i===dc)return n.RED;if(i===co)return n.RED_INTEGER;if(i===uo)return n.RG;if(i===ho)return n.RG_INTEGER;if(i===fo)return n.RGBA_INTEGER;if(i===tr||i===nr||i===ir||i===sr)if(o===st)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===tr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===nr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===ir)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===sr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===tr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===nr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===ir)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===sr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===va||i===Ma||i===Ia||i===La)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===va)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Ma)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Ia)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===La)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===ya||i===Oa||i===ba)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(i===ya||i===Oa)return o===st?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===ba)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===Ca||i===Da||i===Na||i===Pa||i===Ua||i===wa||i===Fa||i===Ba||i===Ha||i===Ga||i===Va||i===ka||i===Ya||i===Wa)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(i===Ca)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Da)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===Na)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Pa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===Ua)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===wa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===Fa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===Ba)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===Ha)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Ga)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===Va)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===ka)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Ya)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Wa)return o===st?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===za||i===Ka||i===Xa)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(i===za)return o===st?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===Ka)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Xa)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===qa||i===Za||i===Qa||i===Ja)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(i===qa)return r.COMPRESSED_RED_RGTC1_EXT;if(i===Za)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===Qa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===Ja)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===Ss?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}const aS=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,oS=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class lS{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const i=new Mc(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,i=new Bn({vertexShader:aS,fragmentShader:oS,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Tt(new Ms(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class cS extends pi{constructor(e,t){super();const i=this;let s=null,r=1,o=null,c="local-floor",h=1,u=null,p=null,a=null,l=null,f=null,m=null;const S=typeof XRWebGLBinding<"u",E=new lS,d={},g=t.getContextAttributes();let A=null,I=null;const D=[],O=[],C=new oe;let U=null;const R=new jt;R.viewport=new St;const v=new jt;v.viewport=new St;const P=[R,v],V=new If;let Z=null,Q=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(M){let _=D[M];return _===void 0&&(_=new qr,D[M]=_),_.getTargetRaySpace()},this.getControllerGrip=function(M){let _=D[M];return _===void 0&&(_=new qr,D[M]=_),_.getGripSpace()},this.getHand=function(M){let _=D[M];return _===void 0&&(_=new qr,D[M]=_),_.getHandSpace()};function j(M){const _=O.indexOf(M.inputSource);if(_===-1)return;const Y=D[_];Y!==void 0&&(Y.update(M.inputSource,M.frame,u||o),Y.dispatchEvent({type:M.type,data:M.inputSource}))}function ie(){s.removeEventListener("select",j),s.removeEventListener("selectstart",j),s.removeEventListener("selectend",j),s.removeEventListener("squeeze",j),s.removeEventListener("squeezestart",j),s.removeEventListener("squeezeend",j),s.removeEventListener("end",ie),s.removeEventListener("inputsourceschange",J);for(let M=0;M<D.length;M++){const _=O[M];_!==null&&(O[M]=null,D[M].disconnect(_))}Z=null,Q=null,E.reset();for(const M in d)delete d[M];e.setRenderTarget(A),f=null,l=null,a=null,s=null,I=null,w.stop(),i.isPresenting=!1,e.setPixelRatio(U),e.setSize(C.width,C.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(M){r=M,i.isPresenting===!0&&Ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(M){c=M,i.isPresenting===!0&&Ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return u||o},this.setReferenceSpace=function(M){u=M},this.getBaseLayer=function(){return l!==null?l:f},this.getBinding=function(){return a===null&&S&&(a=new XRWebGLBinding(s,t)),a},this.getFrame=function(){return m},this.getSession=function(){return s},this.setSession=async function(M){if(s=M,s!==null){if(A=e.getRenderTarget(),s.addEventListener("select",j),s.addEventListener("selectstart",j),s.addEventListener("selectend",j),s.addEventListener("squeeze",j),s.addEventListener("squeezestart",j),s.addEventListener("squeezeend",j),s.addEventListener("end",ie),s.addEventListener("inputsourceschange",J),g.xrCompatible!==!0&&await t.makeXRCompatible(),U=e.getPixelRatio(),e.getSize(C),S&&"createProjectionLayer"in XRWebGLBinding.prototype){let Y=null,se=null,k=null;g.depth&&(k=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Y=g.stencil?xs:As,se=g.stencil?Ss:fi);const le={colorFormat:t.RGBA8,depthFormat:k,scaleFactor:r};a=this.getBinding(),l=a.createProjectionLayer(le),s.updateRenderState({layers:[l]}),e.setPixelRatio(1),e.setSize(l.textureWidth,l.textureHeight,!1),I=new wn(l.textureWidth,l.textureHeight,{format:ln,type:Pn,depthTexture:new vc(l.textureWidth,l.textureHeight,se,void 0,void 0,void 0,void 0,void 0,void 0,Y),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:l.ignoreDepthValues===!1,resolveStencilBuffer:l.ignoreDepthValues===!1})}else{const Y={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,Y),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),I=new wn(f.framebufferWidth,f.framebufferHeight,{format:ln,type:Pn,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}I.isXRRenderTarget=!0,this.setFoveation(h),u=null,o=await s.requestReferenceSpace(c),w.setContext(s),w.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return E.getDepthTexture()};function J(M){for(let _=0;_<M.removed.length;_++){const Y=M.removed[_],se=O.indexOf(Y);se>=0&&(O[se]=null,D[se].disconnect(Y))}for(let _=0;_<M.added.length;_++){const Y=M.added[_];let se=O.indexOf(Y);if(se===-1){for(let le=0;le<D.length;le++)if(le>=O.length){O.push(Y),se=le;break}else if(O[le]===null){O[le]=Y,se=le;break}if(se===-1)break}const k=D[se];k&&k.connect(Y)}}const B=new G,de=new G;function pe(M,_,Y){B.setFromMatrixPosition(_.matrixWorld),de.setFromMatrixPosition(Y.matrixWorld);const se=B.distanceTo(de),k=_.projectionMatrix.elements,le=Y.projectionMatrix.elements,Ae=k[14]/(k[10]-1),ue=k[14]/(k[10]+1),H=(k[9]+1)/k[5],T=(k[9]-1)/k[5],q=(k[8]-1)/k[0],$=(le[8]+1)/le[0],N=Ae*q,y=Ae*$,ae=se/(-q+$),ce=ae*-q;if(_.matrixWorld.decompose(M.position,M.quaternion,M.scale),M.translateX(ce),M.translateZ(ae),M.matrixWorld.compose(M.position,M.quaternion,M.scale),M.matrixWorldInverse.copy(M.matrixWorld).invert(),k[10]===-1)M.projectionMatrix.copy(_.projectionMatrix),M.projectionMatrixInverse.copy(_.projectionMatrixInverse);else{const Te=Ae+ae,b=ue+ae,x=N-ce,z=y+(se-ce),re=H*ue/b*Te,fe=T*ue/b*Te;M.projectionMatrix.makePerspective(x,z,re,fe,Te,b),M.projectionMatrixInverse.copy(M.projectionMatrix).invert()}}function Me(M,_){_===null?M.matrixWorld.copy(M.matrix):M.matrixWorld.multiplyMatrices(_.matrixWorld,M.matrix),M.matrixWorldInverse.copy(M.matrixWorld).invert()}this.updateCamera=function(M){if(s===null)return;let _=M.near,Y=M.far;E.texture!==null&&(E.depthNear>0&&(_=E.depthNear),E.depthFar>0&&(Y=E.depthFar)),V.near=v.near=R.near=_,V.far=v.far=R.far=Y,(Z!==V.near||Q!==V.far)&&(s.updateRenderState({depthNear:V.near,depthFar:V.far}),Z=V.near,Q=V.far),V.layers.mask=M.layers.mask|6,R.layers.mask=V.layers.mask&3,v.layers.mask=V.layers.mask&5;const se=M.parent,k=V.cameras;Me(V,se);for(let le=0;le<k.length;le++)Me(k[le],se);k.length===2?pe(V,R,v):V.projectionMatrix.copy(R.projectionMatrix),He(M,V,se)};function He(M,_,Y){Y===null?M.matrix.copy(_.matrixWorld):(M.matrix.copy(Y.matrixWorld),M.matrix.invert(),M.matrix.multiply(_.matrixWorld)),M.matrix.decompose(M.position,M.quaternion,M.scale),M.updateMatrixWorld(!0),M.projectionMatrix.copy(_.projectionMatrix),M.projectionMatrixInverse.copy(_.projectionMatrixInverse),M.isPerspectiveCamera&&(M.fov=$a*2*Math.atan(1/M.projectionMatrix.elements[5]),M.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(l===null&&f===null))return h},this.setFoveation=function(M){h=M,l!==null&&(l.fixedFoveation=M),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=M)},this.hasDepthSensing=function(){return E.texture!==null},this.getDepthSensingMesh=function(){return E.getMesh(V)},this.getCameraTexture=function(M){return d[M]};let Ce=null;function W(M,_){if(p=_.getViewerPose(u||o),m=_,p!==null){const Y=p.views;f!==null&&(e.setRenderTargetFramebuffer(I,f.framebuffer),e.setRenderTarget(I));let se=!1;Y.length!==V.cameras.length&&(V.cameras.length=0,se=!0);for(let ue=0;ue<Y.length;ue++){const H=Y[ue];let T=null;if(f!==null)T=f.getViewport(H);else{const $=a.getViewSubImage(l,H);T=$.viewport,ue===0&&(e.setRenderTargetTextures(I,$.colorTexture,$.depthStencilTexture),e.setRenderTarget(I))}let q=P[ue];q===void 0&&(q=new jt,q.layers.enable(ue),q.viewport=new St,P[ue]=q),q.matrix.fromArray(H.transform.matrix),q.matrix.decompose(q.position,q.quaternion,q.scale),q.projectionMatrix.fromArray(H.projectionMatrix),q.projectionMatrixInverse.copy(q.projectionMatrix).invert(),q.viewport.set(T.x,T.y,T.width,T.height),ue===0&&(V.matrix.copy(q.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),se===!0&&V.cameras.push(q)}const k=s.enabledFeatures;if(k&&k.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&S){a=i.getBinding();const ue=a.getDepthInformation(Y[0]);ue&&ue.isValid&&ue.texture&&E.init(ue,s.renderState)}if(k&&k.includes("camera-access")&&S){e.state.unbindTexture(),a=i.getBinding();for(let ue=0;ue<Y.length;ue++){const H=Y[ue].camera;if(H){let T=d[H];T||(T=new Mc,d[H]=T);const q=a.getCameraImage(H);T.sourceTexture=q}}}}for(let Y=0;Y<D.length;Y++){const se=O[Y],k=D[Y];se!==null&&k!==void 0&&k.update(se,_,u||o)}Ce&&Ce(M,_),_.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:_}),m=null}const w=new Pc;w.setAnimationLoop(W),this.setAnimationLoop=function(M){Ce=M},this.dispose=function(){}}}const ai=new Fn,uS=new At;function hS(n,e){function t(E,d){E.matrixAutoUpdate===!0&&E.updateMatrix(),d.value.copy(E.matrix)}function i(E,d){d.color.getRGB(E.fogColor.value,_c(n)),d.isFog?(E.fogNear.value=d.near,E.fogFar.value=d.far):d.isFogExp2&&(E.fogDensity.value=d.density)}function s(E,d,g,A,I){d.isMeshBasicMaterial||d.isMeshLambertMaterial?r(E,d):d.isMeshToonMaterial?(r(E,d),a(E,d)):d.isMeshPhongMaterial?(r(E,d),p(E,d)):d.isMeshStandardMaterial?(r(E,d),l(E,d),d.isMeshPhysicalMaterial&&f(E,d,I)):d.isMeshMatcapMaterial?(r(E,d),m(E,d)):d.isMeshDepthMaterial?r(E,d):d.isMeshDistanceMaterial?(r(E,d),S(E,d)):d.isMeshNormalMaterial?r(E,d):d.isLineBasicMaterial?(o(E,d),d.isLineDashedMaterial&&c(E,d)):d.isPointsMaterial?h(E,d,g,A):d.isSpriteMaterial?u(E,d):d.isShadowMaterial?(E.color.value.copy(d.color),E.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function r(E,d){E.opacity.value=d.opacity,d.color&&E.diffuse.value.copy(d.color),d.emissive&&E.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(E.map.value=d.map,t(d.map,E.mapTransform)),d.alphaMap&&(E.alphaMap.value=d.alphaMap,t(d.alphaMap,E.alphaMapTransform)),d.bumpMap&&(E.bumpMap.value=d.bumpMap,t(d.bumpMap,E.bumpMapTransform),E.bumpScale.value=d.bumpScale,d.side===Lt&&(E.bumpScale.value*=-1)),d.normalMap&&(E.normalMap.value=d.normalMap,t(d.normalMap,E.normalMapTransform),E.normalScale.value.copy(d.normalScale),d.side===Lt&&E.normalScale.value.negate()),d.displacementMap&&(E.displacementMap.value=d.displacementMap,t(d.displacementMap,E.displacementMapTransform),E.displacementScale.value=d.displacementScale,E.displacementBias.value=d.displacementBias),d.emissiveMap&&(E.emissiveMap.value=d.emissiveMap,t(d.emissiveMap,E.emissiveMapTransform)),d.specularMap&&(E.specularMap.value=d.specularMap,t(d.specularMap,E.specularMapTransform)),d.alphaTest>0&&(E.alphaTest.value=d.alphaTest);const g=e.get(d),A=g.envMap,I=g.envMapRotation;A&&(E.envMap.value=A,ai.copy(I),ai.x*=-1,ai.y*=-1,ai.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(ai.y*=-1,ai.z*=-1),E.envMapRotation.value.setFromMatrix4(uS.makeRotationFromEuler(ai)),E.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,E.reflectivity.value=d.reflectivity,E.ior.value=d.ior,E.refractionRatio.value=d.refractionRatio),d.lightMap&&(E.lightMap.value=d.lightMap,E.lightMapIntensity.value=d.lightMapIntensity,t(d.lightMap,E.lightMapTransform)),d.aoMap&&(E.aoMap.value=d.aoMap,E.aoMapIntensity.value=d.aoMapIntensity,t(d.aoMap,E.aoMapTransform))}function o(E,d){E.diffuse.value.copy(d.color),E.opacity.value=d.opacity,d.map&&(E.map.value=d.map,t(d.map,E.mapTransform))}function c(E,d){E.dashSize.value=d.dashSize,E.totalSize.value=d.dashSize+d.gapSize,E.scale.value=d.scale}function h(E,d,g,A){E.diffuse.value.copy(d.color),E.opacity.value=d.opacity,E.size.value=d.size*g,E.scale.value=A*.5,d.map&&(E.map.value=d.map,t(d.map,E.uvTransform)),d.alphaMap&&(E.alphaMap.value=d.alphaMap,t(d.alphaMap,E.alphaMapTransform)),d.alphaTest>0&&(E.alphaTest.value=d.alphaTest)}function u(E,d){E.diffuse.value.copy(d.color),E.opacity.value=d.opacity,E.rotation.value=d.rotation,d.map&&(E.map.value=d.map,t(d.map,E.mapTransform)),d.alphaMap&&(E.alphaMap.value=d.alphaMap,t(d.alphaMap,E.alphaMapTransform)),d.alphaTest>0&&(E.alphaTest.value=d.alphaTest)}function p(E,d){E.specular.value.copy(d.specular),E.shininess.value=Math.max(d.shininess,1e-4)}function a(E,d){d.gradientMap&&(E.gradientMap.value=d.gradientMap)}function l(E,d){E.metalness.value=d.metalness,d.metalnessMap&&(E.metalnessMap.value=d.metalnessMap,t(d.metalnessMap,E.metalnessMapTransform)),E.roughness.value=d.roughness,d.roughnessMap&&(E.roughnessMap.value=d.roughnessMap,t(d.roughnessMap,E.roughnessMapTransform)),d.envMap&&(E.envMapIntensity.value=d.envMapIntensity)}function f(E,d,g){E.ior.value=d.ior,d.sheen>0&&(E.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),E.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(E.sheenColorMap.value=d.sheenColorMap,t(d.sheenColorMap,E.sheenColorMapTransform)),d.sheenRoughnessMap&&(E.sheenRoughnessMap.value=d.sheenRoughnessMap,t(d.sheenRoughnessMap,E.sheenRoughnessMapTransform))),d.clearcoat>0&&(E.clearcoat.value=d.clearcoat,E.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(E.clearcoatMap.value=d.clearcoatMap,t(d.clearcoatMap,E.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(E.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,t(d.clearcoatRoughnessMap,E.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(E.clearcoatNormalMap.value=d.clearcoatNormalMap,t(d.clearcoatNormalMap,E.clearcoatNormalMapTransform),E.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===Lt&&E.clearcoatNormalScale.value.negate())),d.dispersion>0&&(E.dispersion.value=d.dispersion),d.iridescence>0&&(E.iridescence.value=d.iridescence,E.iridescenceIOR.value=d.iridescenceIOR,E.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],E.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(E.iridescenceMap.value=d.iridescenceMap,t(d.iridescenceMap,E.iridescenceMapTransform)),d.iridescenceThicknessMap&&(E.iridescenceThicknessMap.value=d.iridescenceThicknessMap,t(d.iridescenceThicknessMap,E.iridescenceThicknessMapTransform))),d.transmission>0&&(E.transmission.value=d.transmission,E.transmissionSamplerMap.value=g.texture,E.transmissionSamplerSize.value.set(g.width,g.height),d.transmissionMap&&(E.transmissionMap.value=d.transmissionMap,t(d.transmissionMap,E.transmissionMapTransform)),E.thickness.value=d.thickness,d.thicknessMap&&(E.thicknessMap.value=d.thicknessMap,t(d.thicknessMap,E.thicknessMapTransform)),E.attenuationDistance.value=d.attenuationDistance,E.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(E.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(E.anisotropyMap.value=d.anisotropyMap,t(d.anisotropyMap,E.anisotropyMapTransform))),E.specularIntensity.value=d.specularIntensity,E.specularColor.value.copy(d.specularColor),d.specularColorMap&&(E.specularColorMap.value=d.specularColorMap,t(d.specularColorMap,E.specularColorMapTransform)),d.specularIntensityMap&&(E.specularIntensityMap.value=d.specularIntensityMap,t(d.specularIntensityMap,E.specularIntensityMapTransform))}function m(E,d){d.matcap&&(E.matcap.value=d.matcap)}function S(E,d){const g=e.get(d).light;E.referencePosition.value.setFromMatrixPosition(g.matrixWorld),E.nearDistance.value=g.shadow.camera.near,E.farDistance.value=g.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function fS(n,e,t,i){let s={},r={},o=[];const c=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function h(g,A){const I=A.program;i.uniformBlockBinding(g,I)}function u(g,A){let I=s[g.id];I===void 0&&(m(g),I=p(g),s[g.id]=I,g.addEventListener("dispose",E));const D=A.program;i.updateUBOMapping(g,D);const O=e.render.frame;r[g.id]!==O&&(l(g),r[g.id]=O)}function p(g){const A=a();g.__bindingPointIndex=A;const I=n.createBuffer(),D=g.__size,O=g.usage;return n.bindBuffer(n.UNIFORM_BUFFER,I),n.bufferData(n.UNIFORM_BUFFER,D,O),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,A,I),I}function a(){for(let g=0;g<c;g++)if(o.indexOf(g)===-1)return o.push(g),g;return dt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function l(g){const A=s[g.id],I=g.uniforms,D=g.__cache;n.bindBuffer(n.UNIFORM_BUFFER,A);for(let O=0,C=I.length;O<C;O++){const U=Array.isArray(I[O])?I[O]:[I[O]];for(let R=0,v=U.length;R<v;R++){const P=U[R];if(f(P,O,R,D)===!0){const V=P.__offset,Z=Array.isArray(P.value)?P.value:[P.value];let Q=0;for(let j=0;j<Z.length;j++){const ie=Z[j],J=S(ie);typeof ie=="number"||typeof ie=="boolean"?(P.__data[0]=ie,n.bufferSubData(n.UNIFORM_BUFFER,V+Q,P.__data)):ie.isMatrix3?(P.__data[0]=ie.elements[0],P.__data[1]=ie.elements[1],P.__data[2]=ie.elements[2],P.__data[3]=0,P.__data[4]=ie.elements[3],P.__data[5]=ie.elements[4],P.__data[6]=ie.elements[5],P.__data[7]=0,P.__data[8]=ie.elements[6],P.__data[9]=ie.elements[7],P.__data[10]=ie.elements[8],P.__data[11]=0):(ie.toArray(P.__data,Q),Q+=J.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,V,P.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function f(g,A,I,D){const O=g.value,C=A+"_"+I;if(D[C]===void 0)return typeof O=="number"||typeof O=="boolean"?D[C]=O:D[C]=O.clone(),!0;{const U=D[C];if(typeof O=="number"||typeof O=="boolean"){if(U!==O)return D[C]=O,!0}else if(U.equals(O)===!1)return U.copy(O),!0}return!1}function m(g){const A=g.uniforms;let I=0;const D=16;for(let C=0,U=A.length;C<U;C++){const R=Array.isArray(A[C])?A[C]:[A[C]];for(let v=0,P=R.length;v<P;v++){const V=R[v],Z=Array.isArray(V.value)?V.value:[V.value];for(let Q=0,j=Z.length;Q<j;Q++){const ie=Z[Q],J=S(ie),B=I%D,de=B%J.boundary,pe=B+de;I+=de,pe!==0&&D-pe<J.storage&&(I+=D-pe),V.__data=new Float32Array(J.storage/Float32Array.BYTES_PER_ELEMENT),V.__offset=I,I+=J.storage}}}const O=I%D;return O>0&&(I+=D-O),g.__size=I,g.__cache={},this}function S(g){const A={boundary:0,storage:0};return typeof g=="number"||typeof g=="boolean"?(A.boundary=4,A.storage=4):g.isVector2?(A.boundary=8,A.storage=8):g.isVector3||g.isColor?(A.boundary=16,A.storage=12):g.isVector4?(A.boundary=16,A.storage=16):g.isMatrix3?(A.boundary=48,A.storage=48):g.isMatrix4?(A.boundary=64,A.storage=64):g.isTexture?Ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Ke("WebGLRenderer: Unsupported uniform value type.",g),A}function E(g){const A=g.target;A.removeEventListener("dispose",E);const I=o.indexOf(A.__bindingPointIndex);o.splice(I,1),n.deleteBuffer(s[A.id]),delete s[A.id],delete r[A.id]}function d(){for(const g in s)n.deleteBuffer(s[g]);o=[],s={},r={}}return{bind:h,update:u,dispose:d}}const dS=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let In=null;function pS(){return In===null&&(In=new Ph(dS,32,32,uo,Wi),In.minFilter=en,In.magFilter=en,In.wrapS=On,In.wrapT=On,In.generateMipmaps=!1,In.needsUpdate=!0),In}class ES{constructor(e={}){const{canvas:t=rh(),context:i=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:c=!1,premultipliedAlpha:h=!0,preserveDrawingBuffer:u=!1,powerPreference:p="default",failIfMajorPerformanceCaveat:a=!1,reversedDepthBuffer:l=!1}=e;this.isWebGLRenderer=!0;let f;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=i.getContextAttributes().alpha}else f=o;const m=new Set([fo,ho,co]),S=new Set([Pn,fi,ms,Ss,oo,lo]),E=new Uint32Array(4),d=new Int32Array(4);let g=null,A=null;const I=[],D=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Zn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const O=this;let C=!1;this._outputColorSpace=Nt;let U=0,R=0,v=null,P=-1,V=null;const Z=new St,Q=new St;let j=null;const ie=new et(0);let J=0,B=t.width,de=t.height,pe=1,Me=null,He=null;const Ce=new St(0,0,B,de),W=new St(0,0,B,de);let w=!1;const M=new Rc;let _=!1,Y=!1;const se=new At,k=new G,le=new St,Ae={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ue=!1;function H(){return v===null?pe:1}let T=i;function q(L,K){return t.getContext(L,K)}try{const L={alpha:!0,depth:s,stencil:r,antialias:c,premultipliedAlpha:h,preserveDrawingBuffer:u,powerPreference:p,failIfMajorPerformanceCaveat:a};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${ro}`),t.addEventListener("webglcontextlost",Se,!1),t.addEventListener("webglcontextrestored",he,!1),t.addEventListener("webglcontextcreationerror",Pe,!1),T===null){const K="webgl2";if(T=q(K,L),T===null)throw q(K)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(L){throw L("WebGLRenderer: "+L.message),L}let $,N,y,ae,ce,Te,b,x,z,re,fe,ne,Ne,ge,we,De,Ee,xe,ke,Ge,Oe,ze,F,Le;function Re(){$=new RE(T),$.init(),ze=new rS(T,$),N=new pE(T,$,e,ze),y=new iS(T,$),N.reversedDepthBuffer&&l&&y.buffers.depth.setReversed(!0),ae=new IE(T),ce=new Wm,Te=new sS(T,$,y,ce,N,ze,ae),b=new mE(O),x=new TE(O),z=new bf(T),F=new fE(T,z),re=new vE(T,z,ae,F),fe=new yE(T,re,z,ae),ke=new LE(T,N,Te),De=new EE(ce),ne=new Ym(O,b,x,$,N,F,De),Ne=new hS(O,ce),ge=new Km,we=new $m($),xe=new hE(O,b,x,y,fe,f,h),Ee=new tS(O,fe,N),Le=new fS(T,ae,N,y),Ge=new dE(T,$,ae),Oe=new ME(T,$,ae),ae.programs=ne.programs,O.capabilities=N,O.extensions=$,O.properties=ce,O.renderLists=ge,O.shadowMap=Ee,O.state=y,O.info=ae}Re();const ve=new cS(O,T);this.xr=ve,this.getContext=function(){return T},this.getContextAttributes=function(){return T.getContextAttributes()},this.forceContextLoss=function(){const L=$.get("WEBGL_lose_context");L&&L.loseContext()},this.forceContextRestore=function(){const L=$.get("WEBGL_lose_context");L&&L.restoreContext()},this.getPixelRatio=function(){return pe},this.setPixelRatio=function(L){L!==void 0&&(pe=L,this.setSize(B,de,!1))},this.getSize=function(L){return L.set(B,de)},this.setSize=function(L,K,ee=!0){if(ve.isPresenting){Ke("WebGLRenderer: Can't change size while VR device is presenting.");return}B=L,de=K,t.width=Math.floor(L*pe),t.height=Math.floor(K*pe),ee===!0&&(t.style.width=L+"px",t.style.height=K+"px"),this.setViewport(0,0,L,K)},this.getDrawingBufferSize=function(L){return L.set(B*pe,de*pe).floor()},this.setDrawingBufferSize=function(L,K,ee){B=L,de=K,pe=ee,t.width=Math.floor(L*ee),t.height=Math.floor(K*ee),this.setViewport(0,0,L,K)},this.getCurrentViewport=function(L){return L.copy(Z)},this.getViewport=function(L){return L.copy(Ce)},this.setViewport=function(L,K,ee,te){L.isVector4?Ce.set(L.x,L.y,L.z,L.w):Ce.set(L,K,ee,te),y.viewport(Z.copy(Ce).multiplyScalar(pe).round())},this.getScissor=function(L){return L.copy(W)},this.setScissor=function(L,K,ee,te){L.isVector4?W.set(L.x,L.y,L.z,L.w):W.set(L,K,ee,te),y.scissor(Q.copy(W).multiplyScalar(pe).round())},this.getScissorTest=function(){return w},this.setScissorTest=function(L){y.setScissorTest(w=L)},this.setOpaqueSort=function(L){Me=L},this.setTransparentSort=function(L){He=L},this.getClearColor=function(L){return L.copy(xe.getClearColor())},this.setClearColor=function(){xe.setClearColor(...arguments)},this.getClearAlpha=function(){return xe.getClearAlpha()},this.setClearAlpha=function(){xe.setClearAlpha(...arguments)},this.clear=function(L=!0,K=!0,ee=!0){let te=0;if(L){let X=!1;if(v!==null){const _e=v.texture.format;X=m.has(_e)}if(X){const _e=v.texture.type,ye=S.has(_e),Ue=xe.getClearColor(),be=xe.getClearAlpha(),Ve=Ue.r,Ye=Ue.g,Fe=Ue.b;ye?(E[0]=Ve,E[1]=Ye,E[2]=Fe,E[3]=be,T.clearBufferuiv(T.COLOR,0,E)):(d[0]=Ve,d[1]=Ye,d[2]=Fe,d[3]=be,T.clearBufferiv(T.COLOR,0,d))}else te|=T.COLOR_BUFFER_BIT}K&&(te|=T.DEPTH_BUFFER_BIT),ee&&(te|=T.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),T.clear(te)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Se,!1),t.removeEventListener("webglcontextrestored",he,!1),t.removeEventListener("webglcontextcreationerror",Pe,!1),xe.dispose(),ge.dispose(),we.dispose(),ce.dispose(),b.dispose(),x.dispose(),fe.dispose(),F.dispose(),Le.dispose(),ne.dispose(),ve.dispose(),ve.removeEventListener("sessionstart",Oo),ve.removeEventListener("sessionend",bo),$n.stop()};function Se(L){L.preventDefault(),Wo("WebGLRenderer: Context Lost."),C=!0}function he(){Wo("WebGLRenderer: Context Restored."),C=!1;const L=ae.autoReset,K=Ee.enabled,ee=Ee.autoUpdate,te=Ee.needsUpdate,X=Ee.type;Re(),ae.autoReset=L,Ee.enabled=K,Ee.autoUpdate=ee,Ee.needsUpdate=te,Ee.type=X}function Pe(L){dt("WebGLRenderer: A WebGL context could not be created. Reason: ",L.statusMessage)}function Xe(L){const K=L.target;K.removeEventListener("dispose",Xe),ct(K)}function ct(L){tt(L),ce.remove(L)}function tt(L){const K=ce.get(L).programs;K!==void 0&&(K.forEach(function(ee){ne.releaseProgram(ee)}),L.isShaderMaterial&&ne.releaseShaderCache(L))}this.renderBufferDirect=function(L,K,ee,te,X,_e){K===null&&(K=Ae);const ye=X.isMesh&&X.matrixWorld.determinant()<0,Ue=ou(L,K,ee,te,X);y.setMaterial(te,ye);let be=ee.index,Ve=1;if(te.wireframe===!0){if(be=re.getWireframeAttribute(ee),be===void 0)return;Ve=2}const Ye=ee.drawRange,Fe=ee.attributes.position;let Qe=Ye.start*Ve,nt=(Ye.start+Ye.count)*Ve;_e!==null&&(Qe=Math.max(Qe,_e.start*Ve),nt=Math.min(nt,(_e.start+_e.count)*Ve)),be!==null?(Qe=Math.max(Qe,0),nt=Math.min(nt,be.count)):Fe!=null&&(Qe=Math.max(Qe,0),nt=Math.min(nt,Fe.count));const Et=nt-Qe;if(Et<0||Et===1/0)return;F.setup(X,te,Ue,ee,be);let mt,at=Ge;if(be!==null&&(mt=z.get(be),at=Oe,at.setIndex(mt)),X.isMesh)te.wireframe===!0?(y.setLineWidth(te.wireframeLinewidth*H()),at.setMode(T.LINES)):at.setMode(T.TRIANGLES);else if(X.isLine){let Be=te.linewidth;Be===void 0&&(Be=1),y.setLineWidth(Be*H()),X.isLineSegments?at.setMode(T.LINES):X.isLineLoop?at.setMode(T.LINE_LOOP):at.setMode(T.LINE_STRIP)}else X.isPoints?at.setMode(T.POINTS):X.isSprite&&at.setMode(T.TRIANGLES);if(X.isBatchedMesh)if(X._multiDrawInstances!==null)_s("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),at.renderMultiDrawInstances(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount,X._multiDrawInstances);else if($.get("WEBGL_multi_draw"))at.renderMultiDraw(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount);else{const Be=X._multiDrawStarts,ht=X._multiDrawCounts,Je=X._multiDrawCount,Gt=be?z.get(be).bytesPerElement:1,mi=ce.get(te).currentProgram.getUniforms();for(let Vt=0;Vt<Je;Vt++)mi.setValue(T,"_gl_DrawID",Vt),at.render(Be[Vt]/Gt,ht[Vt])}else if(X.isInstancedMesh)at.renderInstances(Qe,Et,X.count);else if(ee.isInstancedBufferGeometry){const Be=ee._maxInstanceCount!==void 0?ee._maxInstanceCount:1/0,ht=Math.min(ee.instanceCount,Be);at.renderInstances(Qe,Et,ht)}else at.render(Qe,Et)};function hn(L,K,ee){L.transparent===!0&&L.side===an&&L.forceSinglePass===!1?(L.side=Lt,L.needsUpdate=!0,ys(L,K,ee),L.side=An,L.needsUpdate=!0,ys(L,K,ee),L.side=an):ys(L,K,ee)}this.compile=function(L,K,ee=null){ee===null&&(ee=L),A=we.get(ee),A.init(K),D.push(A),ee.traverseVisible(function(X){X.isLight&&X.layers.test(K.layers)&&(A.pushLight(X),X.castShadow&&A.pushShadow(X))}),L!==ee&&L.traverseVisible(function(X){X.isLight&&X.layers.test(K.layers)&&(A.pushLight(X),X.castShadow&&A.pushShadow(X))}),A.setupLights();const te=new Set;return L.traverse(function(X){if(!(X.isMesh||X.isPoints||X.isLine||X.isSprite))return;const _e=X.material;if(_e)if(Array.isArray(_e))for(let ye=0;ye<_e.length;ye++){const Ue=_e[ye];hn(Ue,ee,X),te.add(Ue)}else hn(_e,ee,X),te.add(_e)}),A=D.pop(),te},this.compileAsync=function(L,K,ee=null){const te=this.compile(L,K,ee);return new Promise(X=>{function _e(){if(te.forEach(function(ye){ce.get(ye).currentProgram.isReady()&&te.delete(ye)}),te.size===0){X(L);return}setTimeout(_e,10)}$.get("KHR_parallel_shader_compile")!==null?_e():setTimeout(_e,10)})};let tn=null;function au(L){tn&&tn(L)}function Oo(){$n.stop()}function bo(){$n.start()}const $n=new Pc;$n.setAnimationLoop(au),typeof self<"u"&&$n.setContext(self),this.setAnimationLoop=function(L){tn=L,ve.setAnimationLoop(L),L===null?$n.stop():$n.start()},ve.addEventListener("sessionstart",Oo),ve.addEventListener("sessionend",bo),this.render=function(L,K){if(K!==void 0&&K.isCamera!==!0){dt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(C===!0)return;if(L.matrixWorldAutoUpdate===!0&&L.updateMatrixWorld(),K.parent===null&&K.matrixWorldAutoUpdate===!0&&K.updateMatrixWorld(),ve.enabled===!0&&ve.isPresenting===!0&&(ve.cameraAutoUpdate===!0&&ve.updateCamera(K),K=ve.getCamera()),L.isScene===!0&&L.onBeforeRender(O,L,K,v),A=we.get(L,D.length),A.init(K),D.push(A),se.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),M.setFromProjectionMatrix(se,mn,K.reversedDepth),Y=this.localClippingEnabled,_=De.init(this.clippingPlanes,Y),g=ge.get(L,I.length),g.init(),I.push(g),ve.enabled===!0&&ve.isPresenting===!0){const _e=O.xr.getDepthSensingMesh();_e!==null&&vr(_e,K,-1/0,O.sortObjects)}vr(L,K,0,O.sortObjects),g.finish(),O.sortObjects===!0&&g.sort(Me,He),ue=ve.enabled===!1||ve.isPresenting===!1||ve.hasDepthSensing()===!1,ue&&xe.addToRenderList(g,L),this.info.render.frame++,_===!0&&De.beginShadows();const ee=A.state.shadowsArray;Ee.render(ee,L,K),_===!0&&De.endShadows(),this.info.autoReset===!0&&this.info.reset();const te=g.opaque,X=g.transmissive;if(A.setupLights(),K.isArrayCamera){const _e=K.cameras;if(X.length>0)for(let ye=0,Ue=_e.length;ye<Ue;ye++){const be=_e[ye];Do(te,X,L,be)}ue&&xe.render(L);for(let ye=0,Ue=_e.length;ye<Ue;ye++){const be=_e[ye];Co(g,L,be,be.viewport)}}else X.length>0&&Do(te,X,L,K),ue&&xe.render(L),Co(g,L,K);v!==null&&R===0&&(Te.updateMultisampleRenderTarget(v),Te.updateRenderTargetMipmap(v)),L.isScene===!0&&L.onAfterRender(O,L,K),F.resetDefaultState(),P=-1,V=null,D.pop(),D.length>0?(A=D[D.length-1],_===!0&&De.setGlobalState(O.clippingPlanes,A.state.camera)):A=null,I.pop(),I.length>0?g=I[I.length-1]:g=null};function vr(L,K,ee,te){if(L.visible===!1)return;if(L.layers.test(K.layers)){if(L.isGroup)ee=L.renderOrder;else if(L.isLOD)L.autoUpdate===!0&&L.update(K);else if(L.isLight)A.pushLight(L),L.castShadow&&A.pushShadow(L);else if(L.isSprite){if(!L.frustumCulled||M.intersectsSprite(L)){te&&le.setFromMatrixPosition(L.matrixWorld).applyMatrix4(se);const ye=fe.update(L),Ue=L.material;Ue.visible&&g.push(L,ye,Ue,ee,le.z,null)}}else if((L.isMesh||L.isLine||L.isPoints)&&(!L.frustumCulled||M.intersectsObject(L))){const ye=fe.update(L),Ue=L.material;if(te&&(L.boundingSphere!==void 0?(L.boundingSphere===null&&L.computeBoundingSphere(),le.copy(L.boundingSphere.center)):(ye.boundingSphere===null&&ye.computeBoundingSphere(),le.copy(ye.boundingSphere.center)),le.applyMatrix4(L.matrixWorld).applyMatrix4(se)),Array.isArray(Ue)){const be=ye.groups;for(let Ve=0,Ye=be.length;Ve<Ye;Ve++){const Fe=be[Ve],Qe=Ue[Fe.materialIndex];Qe&&Qe.visible&&g.push(L,ye,Qe,ee,le.z,Fe)}}else Ue.visible&&g.push(L,ye,Ue,ee,le.z,null)}}const _e=L.children;for(let ye=0,Ue=_e.length;ye<Ue;ye++)vr(_e[ye],K,ee,te)}function Co(L,K,ee,te){const{opaque:X,transmissive:_e,transparent:ye}=L;A.setupLightsView(ee),_===!0&&De.setGlobalState(O.clippingPlanes,ee),te&&y.viewport(Z.copy(te)),X.length>0&&Ls(X,K,ee),_e.length>0&&Ls(_e,K,ee),ye.length>0&&Ls(ye,K,ee),y.buffers.depth.setTest(!0),y.buffers.depth.setMask(!0),y.buffers.color.setMask(!0),y.setPolygonOffset(!1)}function Do(L,K,ee,te){if((ee.isScene===!0?ee.overrideMaterial:null)!==null)return;A.state.transmissionRenderTarget[te.id]===void 0&&(A.state.transmissionRenderTarget[te.id]=new wn(1,1,{generateMipmaps:!0,type:$.has("EXT_color_buffer_half_float")||$.has("EXT_color_buffer_float")?Wi:Pn,minFilter:ui,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:$e.workingColorSpace}));const _e=A.state.transmissionRenderTarget[te.id],ye=te.viewport||Z;_e.setSize(ye.z*O.transmissionResolutionScale,ye.w*O.transmissionResolutionScale);const Ue=O.getRenderTarget(),be=O.getActiveCubeFace(),Ve=O.getActiveMipmapLevel();O.setRenderTarget(_e),O.getClearColor(ie),J=O.getClearAlpha(),J<1&&O.setClearColor(16777215,.5),O.clear(),ue&&xe.render(ee);const Ye=O.toneMapping;O.toneMapping=Zn;const Fe=te.viewport;if(te.viewport!==void 0&&(te.viewport=void 0),A.setupLightsView(te),_===!0&&De.setGlobalState(O.clippingPlanes,te),Ls(L,ee,te),Te.updateMultisampleRenderTarget(_e),Te.updateRenderTargetMipmap(_e),$.has("WEBGL_multisampled_render_to_texture")===!1){let Qe=!1;for(let nt=0,Et=K.length;nt<Et;nt++){const mt=K[nt],{object:at,geometry:Be,material:ht,group:Je}=mt;if(ht.side===an&&at.layers.test(te.layers)){const Gt=ht.side;ht.side=Lt,ht.needsUpdate=!0,No(at,ee,te,Be,ht,Je),ht.side=Gt,ht.needsUpdate=!0,Qe=!0}}Qe===!0&&(Te.updateMultisampleRenderTarget(_e),Te.updateRenderTargetMipmap(_e))}O.setRenderTarget(Ue,be,Ve),O.setClearColor(ie,J),Fe!==void 0&&(te.viewport=Fe),O.toneMapping=Ye}function Ls(L,K,ee){const te=K.isScene===!0?K.overrideMaterial:null;for(let X=0,_e=L.length;X<_e;X++){const ye=L[X],{object:Ue,geometry:be,group:Ve}=ye;let Ye=ye.material;Ye.allowOverride===!0&&te!==null&&(Ye=te),Ue.layers.test(ee.layers)&&No(Ue,K,ee,be,Ye,Ve)}}function No(L,K,ee,te,X,_e){L.onBeforeRender(O,K,ee,te,X,_e),L.modelViewMatrix.multiplyMatrices(ee.matrixWorldInverse,L.matrixWorld),L.normalMatrix.getNormalMatrix(L.modelViewMatrix),X.onBeforeRender(O,K,ee,te,L,_e),X.transparent===!0&&X.side===an&&X.forceSinglePass===!1?(X.side=Lt,X.needsUpdate=!0,O.renderBufferDirect(ee,K,te,X,L,_e),X.side=An,X.needsUpdate=!0,O.renderBufferDirect(ee,K,te,X,L,_e),X.side=an):O.renderBufferDirect(ee,K,te,X,L,_e),L.onAfterRender(O,K,ee,te,X,_e)}function ys(L,K,ee){K.isScene!==!0&&(K=Ae);const te=ce.get(L),X=A.state.lights,_e=A.state.shadowsArray,ye=X.state.version,Ue=ne.getParameters(L,X.state,_e,K,ee),be=ne.getProgramCacheKey(Ue);let Ve=te.programs;te.environment=L.isMeshStandardMaterial?K.environment:null,te.fog=K.fog,te.envMap=(L.isMeshStandardMaterial?x:b).get(L.envMap||te.environment),te.envMapRotation=te.environment!==null&&L.envMap===null?K.environmentRotation:L.envMapRotation,Ve===void 0&&(L.addEventListener("dispose",Xe),Ve=new Map,te.programs=Ve);let Ye=Ve.get(be);if(Ye!==void 0){if(te.currentProgram===Ye&&te.lightsStateVersion===ye)return Uo(L,Ue),Ye}else Ue.uniforms=ne.getUniforms(L),L.onBeforeCompile(Ue,O),Ye=ne.acquireProgram(Ue,be),Ve.set(be,Ye),te.uniforms=Ue.uniforms;const Fe=te.uniforms;return(!L.isShaderMaterial&&!L.isRawShaderMaterial||L.clipping===!0)&&(Fe.clippingPlanes=De.uniform),Uo(L,Ue),te.needsLights=cu(L),te.lightsStateVersion=ye,te.needsLights&&(Fe.ambientLightColor.value=X.state.ambient,Fe.lightProbe.value=X.state.probe,Fe.directionalLights.value=X.state.directional,Fe.directionalLightShadows.value=X.state.directionalShadow,Fe.spotLights.value=X.state.spot,Fe.spotLightShadows.value=X.state.spotShadow,Fe.rectAreaLights.value=X.state.rectArea,Fe.ltc_1.value=X.state.rectAreaLTC1,Fe.ltc_2.value=X.state.rectAreaLTC2,Fe.pointLights.value=X.state.point,Fe.pointLightShadows.value=X.state.pointShadow,Fe.hemisphereLights.value=X.state.hemi,Fe.directionalShadowMap.value=X.state.directionalShadowMap,Fe.directionalShadowMatrix.value=X.state.directionalShadowMatrix,Fe.spotShadowMap.value=X.state.spotShadowMap,Fe.spotLightMatrix.value=X.state.spotLightMatrix,Fe.spotLightMap.value=X.state.spotLightMap,Fe.pointShadowMap.value=X.state.pointShadowMap,Fe.pointShadowMatrix.value=X.state.pointShadowMatrix),te.currentProgram=Ye,te.uniformsList=null,Ye}function Po(L){if(L.uniformsList===null){const K=L.currentProgram.getUniforms();L.uniformsList=ar.seqWithValue(K.seq,L.uniforms)}return L.uniformsList}function Uo(L,K){const ee=ce.get(L);ee.outputColorSpace=K.outputColorSpace,ee.batching=K.batching,ee.batchingColor=K.batchingColor,ee.instancing=K.instancing,ee.instancingColor=K.instancingColor,ee.instancingMorph=K.instancingMorph,ee.skinning=K.skinning,ee.morphTargets=K.morphTargets,ee.morphNormals=K.morphNormals,ee.morphColors=K.morphColors,ee.morphTargetsCount=K.morphTargetsCount,ee.numClippingPlanes=K.numClippingPlanes,ee.numIntersection=K.numClipIntersection,ee.vertexAlphas=K.vertexAlphas,ee.vertexTangents=K.vertexTangents,ee.toneMapping=K.toneMapping}function ou(L,K,ee,te,X){K.isScene!==!0&&(K=Ae),Te.resetTextureUnits();const _e=K.fog,ye=te.isMeshStandardMaterial?K.environment:null,Ue=v===null?O.outputColorSpace:v.isXRRenderTarget===!0?v.texture.colorSpace:Gi,be=(te.isMeshStandardMaterial?x:b).get(te.envMap||ye),Ve=te.vertexColors===!0&&!!ee.attributes.color&&ee.attributes.color.itemSize===4,Ye=!!ee.attributes.tangent&&(!!te.normalMap||te.anisotropy>0),Fe=!!ee.morphAttributes.position,Qe=!!ee.morphAttributes.normal,nt=!!ee.morphAttributes.color;let Et=Zn;te.toneMapped&&(v===null||v.isXRRenderTarget===!0)&&(Et=O.toneMapping);const mt=ee.morphAttributes.position||ee.morphAttributes.normal||ee.morphAttributes.color,at=mt!==void 0?mt.length:0,Be=ce.get(te),ht=A.state.lights;if(_===!0&&(Y===!0||L!==V)){const bt=L===V&&te.id===P;De.setState(te,L,bt)}let Je=!1;te.version===Be.__version?(Be.needsLights&&Be.lightsStateVersion!==ht.state.version||Be.outputColorSpace!==Ue||X.isBatchedMesh&&Be.batching===!1||!X.isBatchedMesh&&Be.batching===!0||X.isBatchedMesh&&Be.batchingColor===!0&&X.colorTexture===null||X.isBatchedMesh&&Be.batchingColor===!1&&X.colorTexture!==null||X.isInstancedMesh&&Be.instancing===!1||!X.isInstancedMesh&&Be.instancing===!0||X.isSkinnedMesh&&Be.skinning===!1||!X.isSkinnedMesh&&Be.skinning===!0||X.isInstancedMesh&&Be.instancingColor===!0&&X.instanceColor===null||X.isInstancedMesh&&Be.instancingColor===!1&&X.instanceColor!==null||X.isInstancedMesh&&Be.instancingMorph===!0&&X.morphTexture===null||X.isInstancedMesh&&Be.instancingMorph===!1&&X.morphTexture!==null||Be.envMap!==be||te.fog===!0&&Be.fog!==_e||Be.numClippingPlanes!==void 0&&(Be.numClippingPlanes!==De.numPlanes||Be.numIntersection!==De.numIntersection)||Be.vertexAlphas!==Ve||Be.vertexTangents!==Ye||Be.morphTargets!==Fe||Be.morphNormals!==Qe||Be.morphColors!==nt||Be.toneMapping!==Et||Be.morphTargetsCount!==at)&&(Je=!0):(Je=!0,Be.__version=te.version);let Gt=Be.currentProgram;Je===!0&&(Gt=ys(te,K,X));let mi=!1,Vt=!1,Ji=!1;const ft=Gt.getUniforms(),wt=Be.uniforms;if(y.useProgram(Gt.program)&&(mi=!0,Vt=!0,Ji=!0),te.id!==P&&(P=te.id,Vt=!0),mi||V!==L){y.buffers.depth.getReversed()&&L.reversedDepth!==!0&&(L._reversedDepth=!0,L.updateProjectionMatrix()),ft.setValue(T,"projectionMatrix",L.projectionMatrix),ft.setValue(T,"viewMatrix",L.matrixWorldInverse);const Ft=ft.map.cameraPosition;Ft!==void 0&&Ft.setValue(T,k.setFromMatrixPosition(L.matrixWorld)),N.logarithmicDepthBuffer&&ft.setValue(T,"logDepthBufFC",2/(Math.log(L.far+1)/Math.LN2)),(te.isMeshPhongMaterial||te.isMeshToonMaterial||te.isMeshLambertMaterial||te.isMeshBasicMaterial||te.isMeshStandardMaterial||te.isShaderMaterial)&&ft.setValue(T,"isOrthographic",L.isOrthographicCamera===!0),V!==L&&(V=L,Vt=!0,Ji=!0)}if(X.isSkinnedMesh){ft.setOptional(T,X,"bindMatrix"),ft.setOptional(T,X,"bindMatrixInverse");const bt=X.skeleton;bt&&(bt.boneTexture===null&&bt.computeBoneTexture(),ft.setValue(T,"boneTexture",bt.boneTexture,Te))}X.isBatchedMesh&&(ft.setOptional(T,X,"batchingTexture"),ft.setValue(T,"batchingTexture",X._matricesTexture,Te),ft.setOptional(T,X,"batchingIdTexture"),ft.setValue(T,"batchingIdTexture",X._indirectTexture,Te),ft.setOptional(T,X,"batchingColorTexture"),X._colorsTexture!==null&&ft.setValue(T,"batchingColorTexture",X._colorsTexture,Te));const Zt=ee.morphAttributes;if((Zt.position!==void 0||Zt.normal!==void 0||Zt.color!==void 0)&&ke.update(X,ee,Gt),(Vt||Be.receiveShadow!==X.receiveShadow)&&(Be.receiveShadow=X.receiveShadow,ft.setValue(T,"receiveShadow",X.receiveShadow)),te.isMeshGouraudMaterial&&te.envMap!==null&&(wt.envMap.value=be,wt.flipEnvMap.value=be.isCubeTexture&&be.isRenderTargetTexture===!1?-1:1),te.isMeshStandardMaterial&&te.envMap===null&&K.environment!==null&&(wt.envMapIntensity.value=K.environmentIntensity),wt.dfgLUT!==void 0&&(wt.dfgLUT.value=pS()),Vt&&(ft.setValue(T,"toneMappingExposure",O.toneMappingExposure),Be.needsLights&&lu(wt,Ji),_e&&te.fog===!0&&Ne.refreshFogUniforms(wt,_e),Ne.refreshMaterialUniforms(wt,te,pe,de,A.state.transmissionRenderTarget[L.id]),ar.upload(T,Po(Be),wt,Te)),te.isShaderMaterial&&te.uniformsNeedUpdate===!0&&(ar.upload(T,Po(Be),wt,Te),te.uniformsNeedUpdate=!1),te.isSpriteMaterial&&ft.setValue(T,"center",X.center),ft.setValue(T,"modelViewMatrix",X.modelViewMatrix),ft.setValue(T,"normalMatrix",X.normalMatrix),ft.setValue(T,"modelMatrix",X.matrixWorld),te.isShaderMaterial||te.isRawShaderMaterial){const bt=te.uniformsGroups;for(let Ft=0,Mr=bt.length;Ft<Mr;Ft++){const jn=bt[Ft];Le.update(jn,Gt),Le.bind(jn,Gt)}}return Gt}function lu(L,K){L.ambientLightColor.needsUpdate=K,L.lightProbe.needsUpdate=K,L.directionalLights.needsUpdate=K,L.directionalLightShadows.needsUpdate=K,L.pointLights.needsUpdate=K,L.pointLightShadows.needsUpdate=K,L.spotLights.needsUpdate=K,L.spotLightShadows.needsUpdate=K,L.rectAreaLights.needsUpdate=K,L.hemisphereLights.needsUpdate=K}function cu(L){return L.isMeshLambertMaterial||L.isMeshToonMaterial||L.isMeshPhongMaterial||L.isMeshStandardMaterial||L.isShadowMaterial||L.isShaderMaterial&&L.lights===!0}this.getActiveCubeFace=function(){return U},this.getActiveMipmapLevel=function(){return R},this.getRenderTarget=function(){return v},this.setRenderTargetTextures=function(L,K,ee){const te=ce.get(L);te.__autoAllocateDepthBuffer=L.resolveDepthBuffer===!1,te.__autoAllocateDepthBuffer===!1&&(te.__useRenderToTexture=!1),ce.get(L.texture).__webglTexture=K,ce.get(L.depthTexture).__webglTexture=te.__autoAllocateDepthBuffer?void 0:ee,te.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(L,K){const ee=ce.get(L);ee.__webglFramebuffer=K,ee.__useDefaultFramebuffer=K===void 0};const uu=T.createFramebuffer();this.setRenderTarget=function(L,K=0,ee=0){v=L,U=K,R=ee;let te=!0,X=null,_e=!1,ye=!1;if(L){const be=ce.get(L);if(be.__useDefaultFramebuffer!==void 0)y.bindFramebuffer(T.FRAMEBUFFER,null),te=!1;else if(be.__webglFramebuffer===void 0)Te.setupRenderTarget(L);else if(be.__hasExternalTextures)Te.rebindTextures(L,ce.get(L.texture).__webglTexture,ce.get(L.depthTexture).__webglTexture);else if(L.depthBuffer){const Fe=L.depthTexture;if(be.__boundDepthTexture!==Fe){if(Fe!==null&&ce.has(Fe)&&(L.width!==Fe.image.width||L.height!==Fe.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Te.setupDepthRenderbuffer(L)}}const Ve=L.texture;(Ve.isData3DTexture||Ve.isDataArrayTexture||Ve.isCompressedArrayTexture)&&(ye=!0);const Ye=ce.get(L).__webglFramebuffer;L.isWebGLCubeRenderTarget?(Array.isArray(Ye[K])?X=Ye[K][ee]:X=Ye[K],_e=!0):L.samples>0&&Te.useMultisampledRTT(L)===!1?X=ce.get(L).__webglMultisampledFramebuffer:Array.isArray(Ye)?X=Ye[ee]:X=Ye,Z.copy(L.viewport),Q.copy(L.scissor),j=L.scissorTest}else Z.copy(Ce).multiplyScalar(pe).floor(),Q.copy(W).multiplyScalar(pe).floor(),j=w;if(ee!==0&&(X=uu),y.bindFramebuffer(T.FRAMEBUFFER,X)&&te&&y.drawBuffers(L,X),y.viewport(Z),y.scissor(Q),y.setScissorTest(j),_e){const be=ce.get(L.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_CUBE_MAP_POSITIVE_X+K,be.__webglTexture,ee)}else if(ye){const be=K;for(let Ve=0;Ve<L.textures.length;Ve++){const Ye=ce.get(L.textures[Ve]);T.framebufferTextureLayer(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0+Ve,Ye.__webglTexture,ee,be)}}else if(L!==null&&ee!==0){const be=ce.get(L.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,be.__webglTexture,ee)}P=-1},this.readRenderTargetPixels=function(L,K,ee,te,X,_e,ye,Ue=0){if(!(L&&L.isWebGLRenderTarget)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=ce.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&ye!==void 0&&(be=be[ye]),be){y.bindFramebuffer(T.FRAMEBUFFER,be);try{const Ve=L.textures[Ue],Ye=Ve.format,Fe=Ve.type;if(!N.textureFormatReadable(Ye)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!N.textureTypeReadable(Fe)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}K>=0&&K<=L.width-te&&ee>=0&&ee<=L.height-X&&(L.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Ue),T.readPixels(K,ee,te,X,ze.convert(Ye),ze.convert(Fe),_e))}finally{const Ve=v!==null?ce.get(v).__webglFramebuffer:null;y.bindFramebuffer(T.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(L,K,ee,te,X,_e,ye,Ue=0){if(!(L&&L.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=ce.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&ye!==void 0&&(be=be[ye]),be)if(K>=0&&K<=L.width-te&&ee>=0&&ee<=L.height-X){y.bindFramebuffer(T.FRAMEBUFFER,be);const Ve=L.textures[Ue],Ye=Ve.format,Fe=Ve.type;if(!N.textureFormatReadable(Ye))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!N.textureTypeReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Qe=T.createBuffer();T.bindBuffer(T.PIXEL_PACK_BUFFER,Qe),T.bufferData(T.PIXEL_PACK_BUFFER,_e.byteLength,T.STREAM_READ),L.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Ue),T.readPixels(K,ee,te,X,ze.convert(Ye),ze.convert(Fe),0);const nt=v!==null?ce.get(v).__webglFramebuffer:null;y.bindFramebuffer(T.FRAMEBUFFER,nt);const Et=T.fenceSync(T.SYNC_GPU_COMMANDS_COMPLETE,0);return T.flush(),await ah(T,Et,4),T.bindBuffer(T.PIXEL_PACK_BUFFER,Qe),T.getBufferSubData(T.PIXEL_PACK_BUFFER,0,_e),T.deleteBuffer(Qe),T.deleteSync(Et),_e}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(L,K=null,ee=0){const te=Math.pow(2,-ee),X=Math.floor(L.image.width*te),_e=Math.floor(L.image.height*te),ye=K!==null?K.x:0,Ue=K!==null?K.y:0;Te.setTexture2D(L,0),T.copyTexSubImage2D(T.TEXTURE_2D,ee,0,0,ye,Ue,X,_e),y.unbindTexture()};const hu=T.createFramebuffer(),fu=T.createFramebuffer();this.copyTextureToTexture=function(L,K,ee=null,te=null,X=0,_e=null){_e===null&&(X!==0?(_s("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),_e=X,X=0):_e=0);let ye,Ue,be,Ve,Ye,Fe,Qe,nt,Et;const mt=L.isCompressedTexture?L.mipmaps[_e]:L.image;if(ee!==null)ye=ee.max.x-ee.min.x,Ue=ee.max.y-ee.min.y,be=ee.isBox3?ee.max.z-ee.min.z:1,Ve=ee.min.x,Ye=ee.min.y,Fe=ee.isBox3?ee.min.z:0;else{const Zt=Math.pow(2,-X);ye=Math.floor(mt.width*Zt),Ue=Math.floor(mt.height*Zt),L.isDataArrayTexture?be=mt.depth:L.isData3DTexture?be=Math.floor(mt.depth*Zt):be=1,Ve=0,Ye=0,Fe=0}te!==null?(Qe=te.x,nt=te.y,Et=te.z):(Qe=0,nt=0,Et=0);const at=ze.convert(K.format),Be=ze.convert(K.type);let ht;K.isData3DTexture?(Te.setTexture3D(K,0),ht=T.TEXTURE_3D):K.isDataArrayTexture||K.isCompressedArrayTexture?(Te.setTexture2DArray(K,0),ht=T.TEXTURE_2D_ARRAY):(Te.setTexture2D(K,0),ht=T.TEXTURE_2D),T.pixelStorei(T.UNPACK_FLIP_Y_WEBGL,K.flipY),T.pixelStorei(T.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),T.pixelStorei(T.UNPACK_ALIGNMENT,K.unpackAlignment);const Je=T.getParameter(T.UNPACK_ROW_LENGTH),Gt=T.getParameter(T.UNPACK_IMAGE_HEIGHT),mi=T.getParameter(T.UNPACK_SKIP_PIXELS),Vt=T.getParameter(T.UNPACK_SKIP_ROWS),Ji=T.getParameter(T.UNPACK_SKIP_IMAGES);T.pixelStorei(T.UNPACK_ROW_LENGTH,mt.width),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,mt.height),T.pixelStorei(T.UNPACK_SKIP_PIXELS,Ve),T.pixelStorei(T.UNPACK_SKIP_ROWS,Ye),T.pixelStorei(T.UNPACK_SKIP_IMAGES,Fe);const ft=L.isDataArrayTexture||L.isData3DTexture,wt=K.isDataArrayTexture||K.isData3DTexture;if(L.isDepthTexture){const Zt=ce.get(L),bt=ce.get(K),Ft=ce.get(Zt.__renderTarget),Mr=ce.get(bt.__renderTarget);y.bindFramebuffer(T.READ_FRAMEBUFFER,Ft.__webglFramebuffer),y.bindFramebuffer(T.DRAW_FRAMEBUFFER,Mr.__webglFramebuffer);for(let jn=0;jn<be;jn++)ft&&(T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ce.get(L).__webglTexture,X,Fe+jn),T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ce.get(K).__webglTexture,_e,Et+jn)),T.blitFramebuffer(Ve,Ye,ye,Ue,Qe,nt,ye,Ue,T.DEPTH_BUFFER_BIT,T.NEAREST);y.bindFramebuffer(T.READ_FRAMEBUFFER,null),y.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else if(X!==0||L.isRenderTargetTexture||ce.has(L)){const Zt=ce.get(L),bt=ce.get(K);y.bindFramebuffer(T.READ_FRAMEBUFFER,hu),y.bindFramebuffer(T.DRAW_FRAMEBUFFER,fu);for(let Ft=0;Ft<be;Ft++)ft?T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,Zt.__webglTexture,X,Fe+Ft):T.framebufferTexture2D(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,Zt.__webglTexture,X),wt?T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,bt.__webglTexture,_e,Et+Ft):T.framebufferTexture2D(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,bt.__webglTexture,_e),X!==0?T.blitFramebuffer(Ve,Ye,ye,Ue,Qe,nt,ye,Ue,T.COLOR_BUFFER_BIT,T.NEAREST):wt?T.copyTexSubImage3D(ht,_e,Qe,nt,Et+Ft,Ve,Ye,ye,Ue):T.copyTexSubImage2D(ht,_e,Qe,nt,Ve,Ye,ye,Ue);y.bindFramebuffer(T.READ_FRAMEBUFFER,null),y.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else wt?L.isDataTexture||L.isData3DTexture?T.texSubImage3D(ht,_e,Qe,nt,Et,ye,Ue,be,at,Be,mt.data):K.isCompressedArrayTexture?T.compressedTexSubImage3D(ht,_e,Qe,nt,Et,ye,Ue,be,at,mt.data):T.texSubImage3D(ht,_e,Qe,nt,Et,ye,Ue,be,at,Be,mt):L.isDataTexture?T.texSubImage2D(T.TEXTURE_2D,_e,Qe,nt,ye,Ue,at,Be,mt.data):L.isCompressedTexture?T.compressedTexSubImage2D(T.TEXTURE_2D,_e,Qe,nt,mt.width,mt.height,at,mt.data):T.texSubImage2D(T.TEXTURE_2D,_e,Qe,nt,ye,Ue,at,Be,mt);T.pixelStorei(T.UNPACK_ROW_LENGTH,Je),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,Gt),T.pixelStorei(T.UNPACK_SKIP_PIXELS,mi),T.pixelStorei(T.UNPACK_SKIP_ROWS,Vt),T.pixelStorei(T.UNPACK_SKIP_IMAGES,Ji),_e===0&&K.generateMipmaps&&T.generateMipmap(ht),y.unbindTexture()},this.initRenderTarget=function(L){ce.get(L).__webglFramebuffer===void 0&&Te.setupRenderTarget(L)},this.initTexture=function(L){L.isCubeTexture?Te.setTextureCube(L,0):L.isData3DTexture?Te.setTexture3D(L,0):L.isDataArrayTexture||L.isCompressedArrayTexture?Te.setTexture2DArray(L,0):Te.setTexture2D(L,0),y.unbindTexture()},this.resetState=function(){U=0,R=0,v=null,y.reset(),F.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return mn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=$e._getDrawingBufferColorSpace(e),t.unpackColorSpace=$e._getUnpackColorSpace()}}var ss=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},sa={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var Gl;function mS(){return Gl||(Gl=1,(function(n){(function(){var e=function(){this.init()};e.prototype={init:function(){var a=this||t;return a._counter=1e3,a._html5AudioPool=[],a.html5PoolSize=10,a._codecs={},a._howls=[],a._muted=!1,a._volume=1,a._canPlayEvent="canplaythrough",a._navigator=typeof window<"u"&&window.navigator?window.navigator:null,a.masterGain=null,a.noAudio=!1,a.usingWebAudio=!0,a.autoSuspend=!0,a.ctx=null,a.autoUnlock=!0,a._setup(),a},volume:function(a){var l=this||t;if(a=parseFloat(a),l.ctx||p(),typeof a<"u"&&a>=0&&a<=1){if(l._volume=a,l._muted)return l;l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a,t.ctx.currentTime);for(var f=0;f<l._howls.length;f++)if(!l._howls[f]._webAudio)for(var m=l._howls[f]._getSoundIds(),S=0;S<m.length;S++){var E=l._howls[f]._soundById(m[S]);E&&E._node&&(E._node.volume=E._volume*a)}return l}return l._volume},mute:function(a){var l=this||t;l.ctx||p(),l._muted=a,l.usingWebAudio&&l.masterGain.gain.setValueAtTime(a?0:l._volume,t.ctx.currentTime);for(var f=0;f<l._howls.length;f++)if(!l._howls[f]._webAudio)for(var m=l._howls[f]._getSoundIds(),S=0;S<m.length;S++){var E=l._howls[f]._soundById(m[S]);E&&E._node&&(E._node.muted=a?!0:E._muted)}return l},stop:function(){for(var a=this||t,l=0;l<a._howls.length;l++)a._howls[l].stop();return a},unload:function(){for(var a=this||t,l=a._howls.length-1;l>=0;l--)a._howls[l].unload();return a.usingWebAudio&&a.ctx&&typeof a.ctx.close<"u"&&(a.ctx.close(),a.ctx=null,p()),a},codecs:function(a){return(this||t)._codecs[a.replace(/^x-/,"")]},_setup:function(){var a=this||t;if(a.state=a.ctx&&a.ctx.state||"suspended",a._autoSuspend(),!a.usingWebAudio)if(typeof Audio<"u")try{var l=new Audio;typeof l.oncanplaythrough>"u"&&(a._canPlayEvent="canplay")}catch{a.noAudio=!0}else a.noAudio=!0;try{var l=new Audio;l.muted&&(a.noAudio=!0)}catch{}return a.noAudio||a._setupCodecs(),a},_setupCodecs:function(){var a=this||t,l=null;try{l=typeof Audio<"u"?new Audio:null}catch{return a}if(!l||typeof l.canPlayType!="function")return a;var f=l.canPlayType("audio/mpeg;").replace(/^no$/,""),m=a._navigator?a._navigator.userAgent:"",S=m.match(/OPR\/(\d+)/g),E=S&&parseInt(S[0].split("/")[1],10)<33,d=m.indexOf("Safari")!==-1&&m.indexOf("Chrome")===-1,g=m.match(/Version\/(.*?) /),A=d&&g&&parseInt(g[1],10)<15;return a._codecs={mp3:!!(!E&&(f||l.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!f,opus:!!l.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!l.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(l.canPlayType('audio/wav; codecs="1"')||l.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!l.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!l.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(l.canPlayType("audio/x-m4a;")||l.canPlayType("audio/m4a;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(l.canPlayType("audio/x-m4b;")||l.canPlayType("audio/m4b;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(l.canPlayType("audio/x-mp4;")||l.canPlayType("audio/mp4;")||l.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!A&&l.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!l.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(l.canPlayType("audio/x-flac;")||l.canPlayType("audio/flac;")).replace(/^no$/,"")},a},_unlockAudio:function(){var a=this||t;if(!(a._audioUnlocked||!a.ctx)){a._audioUnlocked=!1,a.autoUnlock=!1,!a._mobileUnloaded&&a.ctx.sampleRate!==44100&&(a._mobileUnloaded=!0,a.unload()),a._scratchBuffer=a.ctx.createBuffer(1,1,22050);var l=function(f){for(;a._html5AudioPool.length<a.html5PoolSize;)try{var m=new Audio;m._unlocked=!0,a._releaseHtml5Audio(m)}catch{a.noAudio=!0;break}for(var S=0;S<a._howls.length;S++)if(!a._howls[S]._webAudio)for(var E=a._howls[S]._getSoundIds(),d=0;d<E.length;d++){var g=a._howls[S]._soundById(E[d]);g&&g._node&&!g._node._unlocked&&(g._node._unlocked=!0,g._node.load())}a._autoResume();var A=a.ctx.createBufferSource();A.buffer=a._scratchBuffer,A.connect(a.ctx.destination),typeof A.start>"u"?A.noteOn(0):A.start(0),typeof a.ctx.resume=="function"&&a.ctx.resume(),A.onended=function(){A.disconnect(0),a._audioUnlocked=!0,document.removeEventListener("touchstart",l,!0),document.removeEventListener("touchend",l,!0),document.removeEventListener("click",l,!0),document.removeEventListener("keydown",l,!0);for(var I=0;I<a._howls.length;I++)a._howls[I]._emit("unlock")}};return document.addEventListener("touchstart",l,!0),document.addEventListener("touchend",l,!0),document.addEventListener("click",l,!0),document.addEventListener("keydown",l,!0),a}},_obtainHtml5Audio:function(){var a=this||t;if(a._html5AudioPool.length)return a._html5AudioPool.pop();var l=new Audio().play();return l&&typeof Promise<"u"&&(l instanceof Promise||typeof l.then=="function")&&l.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(a){var l=this||t;return a._unlocked&&l._html5AudioPool.push(a),l},_autoSuspend:function(){var a=this;if(!(!a.autoSuspend||!a.ctx||typeof a.ctx.suspend>"u"||!t.usingWebAudio)){for(var l=0;l<a._howls.length;l++)if(a._howls[l]._webAudio){for(var f=0;f<a._howls[l]._sounds.length;f++)if(!a._howls[l]._sounds[f]._paused)return a}return a._suspendTimer&&clearTimeout(a._suspendTimer),a._suspendTimer=setTimeout(function(){if(a.autoSuspend){a._suspendTimer=null,a.state="suspending";var m=function(){a.state="suspended",a._resumeAfterSuspend&&(delete a._resumeAfterSuspend,a._autoResume())};a.ctx.suspend().then(m,m)}},3e4),a}},_autoResume:function(){var a=this;if(!(!a.ctx||typeof a.ctx.resume>"u"||!t.usingWebAudio))return a.state==="running"&&a.ctx.state!=="interrupted"&&a._suspendTimer?(clearTimeout(a._suspendTimer),a._suspendTimer=null):a.state==="suspended"||a.state==="running"&&a.ctx.state==="interrupted"?(a.ctx.resume().then(function(){a.state="running";for(var l=0;l<a._howls.length;l++)a._howls[l]._emit("resume")}),a._suspendTimer&&(clearTimeout(a._suspendTimer),a._suspendTimer=null)):a.state==="suspending"&&(a._resumeAfterSuspend=!0),a}};var t=new e,i=function(a){var l=this;if(!a.src||a.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}l.init(a)};i.prototype={init:function(a){var l=this;return t.ctx||p(),l._autoplay=a.autoplay||!1,l._format=typeof a.format!="string"?a.format:[a.format],l._html5=a.html5||!1,l._muted=a.mute||!1,l._loop=a.loop||!1,l._pool=a.pool||5,l._preload=typeof a.preload=="boolean"||a.preload==="metadata"?a.preload:!0,l._rate=a.rate||1,l._sprite=a.sprite||{},l._src=typeof a.src!="string"?a.src:[a.src],l._volume=a.volume!==void 0?a.volume:1,l._xhr={method:a.xhr&&a.xhr.method?a.xhr.method:"GET",headers:a.xhr&&a.xhr.headers?a.xhr.headers:null,withCredentials:a.xhr&&a.xhr.withCredentials?a.xhr.withCredentials:!1},l._duration=0,l._state="unloaded",l._sounds=[],l._endTimers={},l._queue=[],l._playLock=!1,l._onend=a.onend?[{fn:a.onend}]:[],l._onfade=a.onfade?[{fn:a.onfade}]:[],l._onload=a.onload?[{fn:a.onload}]:[],l._onloaderror=a.onloaderror?[{fn:a.onloaderror}]:[],l._onplayerror=a.onplayerror?[{fn:a.onplayerror}]:[],l._onpause=a.onpause?[{fn:a.onpause}]:[],l._onplay=a.onplay?[{fn:a.onplay}]:[],l._onstop=a.onstop?[{fn:a.onstop}]:[],l._onmute=a.onmute?[{fn:a.onmute}]:[],l._onvolume=a.onvolume?[{fn:a.onvolume}]:[],l._onrate=a.onrate?[{fn:a.onrate}]:[],l._onseek=a.onseek?[{fn:a.onseek}]:[],l._onunlock=a.onunlock?[{fn:a.onunlock}]:[],l._onresume=[],l._webAudio=t.usingWebAudio&&!l._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(l),l._autoplay&&l._queue.push({event:"play",action:function(){l.play()}}),l._preload&&l._preload!=="none"&&l.load(),l},load:function(){var a=this,l=null;if(t.noAudio){a._emit("loaderror",null,"No audio support.");return}typeof a._src=="string"&&(a._src=[a._src]);for(var f=0;f<a._src.length;f++){var m,S;if(a._format&&a._format[f])m=a._format[f];else{if(S=a._src[f],typeof S!="string"){a._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}m=/^data:audio\/([^;,]+);/i.exec(S),m||(m=/\.([^.]+)$/.exec(S.split("?",1)[0])),m&&(m=m[1].toLowerCase())}if(m||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),m&&t.codecs(m)){l=a._src[f];break}}if(!l){a._emit("loaderror",null,"No codec support for selected audio sources.");return}return a._src=l,a._state="loading",window.location.protocol==="https:"&&l.slice(0,5)==="http:"&&(a._html5=!0,a._webAudio=!1),new s(a),a._webAudio&&o(a),a},play:function(a,l){var f=this,m=null;if(typeof a=="number")m=a,a=null;else{if(typeof a=="string"&&f._state==="loaded"&&!f._sprite[a])return null;if(typeof a>"u"&&(a="__default",!f._playLock)){for(var S=0,E=0;E<f._sounds.length;E++)f._sounds[E]._paused&&!f._sounds[E]._ended&&(S++,m=f._sounds[E]._id);S===1?a=null:m=null}}var d=m?f._soundById(m):f._inactiveSound();if(!d)return null;if(m&&!a&&(a=d._sprite||"__default"),f._state!=="loaded"){d._sprite=a,d._ended=!1;var g=d._id;return f._queue.push({event:"play",action:function(){f.play(g)}}),g}if(m&&!d._paused)return l||f._loadQueue("play"),d._id;f._webAudio&&t._autoResume();var A=Math.max(0,d._seek>0?d._seek:f._sprite[a][0]/1e3),I=Math.max(0,(f._sprite[a][0]+f._sprite[a][1])/1e3-A),D=I*1e3/Math.abs(d._rate),O=f._sprite[a][0]/1e3,C=(f._sprite[a][0]+f._sprite[a][1])/1e3;d._sprite=a,d._ended=!1;var U=function(){d._paused=!1,d._seek=A,d._start=O,d._stop=C,d._loop=!!(d._loop||f._sprite[a][2])};if(A>=C){f._ended(d);return}var R=d._node;if(f._webAudio){var v=function(){f._playLock=!1,U(),f._refreshBuffer(d);var Q=d._muted||f._muted?0:d._volume;R.gain.setValueAtTime(Q,t.ctx.currentTime),d._playStart=t.ctx.currentTime,typeof R.bufferSource.start>"u"?d._loop?R.bufferSource.noteGrainOn(0,A,86400):R.bufferSource.noteGrainOn(0,A,I):d._loop?R.bufferSource.start(0,A,86400):R.bufferSource.start(0,A,I),D!==1/0&&(f._endTimers[d._id]=setTimeout(f._ended.bind(f,d),D)),l||setTimeout(function(){f._emit("play",d._id),f._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?v():(f._playLock=!0,f.once("resume",v),f._clearTimer(d._id))}else{var P=function(){R.currentTime=A,R.muted=d._muted||f._muted||t._muted||R.muted,R.volume=d._volume*t.volume(),R.playbackRate=d._rate;try{var Q=R.play();if(Q&&typeof Promise<"u"&&(Q instanceof Promise||typeof Q.then=="function")?(f._playLock=!0,U(),Q.then(function(){f._playLock=!1,R._unlocked=!0,l?f._loadQueue():f._emit("play",d._id)}).catch(function(){f._playLock=!1,f._emit("playerror",d._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),d._ended=!0,d._paused=!0})):l||(f._playLock=!1,U(),f._emit("play",d._id)),R.playbackRate=d._rate,R.paused){f._emit("playerror",d._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}a!=="__default"||d._loop?f._endTimers[d._id]=setTimeout(f._ended.bind(f,d),D):(f._endTimers[d._id]=function(){f._ended(d),R.removeEventListener("ended",f._endTimers[d._id],!1)},R.addEventListener("ended",f._endTimers[d._id],!1))}catch(j){f._emit("playerror",d._id,j)}};R.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(R.src=f._src,R.load());var V=window&&window.ejecta||!R.readyState&&t._navigator.isCocoonJS;if(R.readyState>=3||V)P();else{f._playLock=!0,f._state="loading";var Z=function(){f._state="loaded",P(),R.removeEventListener(t._canPlayEvent,Z,!1)};R.addEventListener(t._canPlayEvent,Z,!1),f._clearTimer(d._id)}}return d._id},pause:function(a){var l=this;if(l._state!=="loaded"||l._playLock)return l._queue.push({event:"pause",action:function(){l.pause(a)}}),l;for(var f=l._getSoundIds(a),m=0;m<f.length;m++){l._clearTimer(f[m]);var S=l._soundById(f[m]);if(S&&!S._paused&&(S._seek=l.seek(f[m]),S._rateSeek=0,S._paused=!0,l._stopFade(f[m]),S._node))if(l._webAudio){if(!S._node.bufferSource)continue;typeof S._node.bufferSource.stop>"u"?S._node.bufferSource.noteOff(0):S._node.bufferSource.stop(0),l._cleanBuffer(S._node)}else(!isNaN(S._node.duration)||S._node.duration===1/0)&&S._node.pause();arguments[1]||l._emit("pause",S?S._id:null)}return l},stop:function(a,l){var f=this;if(f._state!=="loaded"||f._playLock)return f._queue.push({event:"stop",action:function(){f.stop(a)}}),f;for(var m=f._getSoundIds(a),S=0;S<m.length;S++){f._clearTimer(m[S]);var E=f._soundById(m[S]);E&&(E._seek=E._start||0,E._rateSeek=0,E._paused=!0,E._ended=!0,f._stopFade(m[S]),E._node&&(f._webAudio?E._node.bufferSource&&(typeof E._node.bufferSource.stop>"u"?E._node.bufferSource.noteOff(0):E._node.bufferSource.stop(0),f._cleanBuffer(E._node)):(!isNaN(E._node.duration)||E._node.duration===1/0)&&(E._node.currentTime=E._start||0,E._node.pause(),E._node.duration===1/0&&f._clearSound(E._node))),l||f._emit("stop",E._id))}return f},mute:function(a,l){var f=this;if(f._state!=="loaded"||f._playLock)return f._queue.push({event:"mute",action:function(){f.mute(a,l)}}),f;if(typeof l>"u")if(typeof a=="boolean")f._muted=a;else return f._muted;for(var m=f._getSoundIds(l),S=0;S<m.length;S++){var E=f._soundById(m[S]);E&&(E._muted=a,E._interval&&f._stopFade(E._id),f._webAudio&&E._node?E._node.gain.setValueAtTime(a?0:E._volume,t.ctx.currentTime):E._node&&(E._node.muted=t._muted?!0:a),f._emit("mute",E._id))}return f},volume:function(){var a=this,l=arguments,f,m;if(l.length===0)return a._volume;if(l.length===1||l.length===2&&typeof l[1]>"u"){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):f=parseFloat(l[0])}else l.length>=2&&(f=parseFloat(l[0]),m=parseInt(l[1],10));var d;if(typeof f<"u"&&f>=0&&f<=1){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"volume",action:function(){a.volume.apply(a,l)}}),a;typeof m>"u"&&(a._volume=f),m=a._getSoundIds(m);for(var g=0;g<m.length;g++)d=a._soundById(m[g]),d&&(d._volume=f,l[2]||a._stopFade(m[g]),a._webAudio&&d._node&&!d._muted?d._node.gain.setValueAtTime(f,t.ctx.currentTime):d._node&&!d._muted&&(d._node.volume=f*t.volume()),a._emit("volume",d._id))}else return d=m?a._soundById(m):a._sounds[0],d?d._volume:0;return a},fade:function(a,l,f,m){var S=this;if(S._state!=="loaded"||S._playLock)return S._queue.push({event:"fade",action:function(){S.fade(a,l,f,m)}}),S;a=Math.min(Math.max(0,parseFloat(a)),1),l=Math.min(Math.max(0,parseFloat(l)),1),f=parseFloat(f),S.volume(a,m);for(var E=S._getSoundIds(m),d=0;d<E.length;d++){var g=S._soundById(E[d]);if(g){if(m||S._stopFade(E[d]),S._webAudio&&!g._muted){var A=t.ctx.currentTime,I=A+f/1e3;g._volume=a,g._node.gain.setValueAtTime(a,A),g._node.gain.linearRampToValueAtTime(l,I)}S._startFadeInterval(g,a,l,f,E[d],typeof m>"u")}}return S},_startFadeInterval:function(a,l,f,m,S,E){var d=this,g=l,A=f-l,I=Math.abs(A/.01),D=Math.max(4,I>0?m/I:m),O=Date.now();a._fadeTo=f,a._interval=setInterval(function(){var C=(Date.now()-O)/m;O=Date.now(),g+=A*C,g=Math.round(g*100)/100,A<0?g=Math.max(f,g):g=Math.min(f,g),d._webAudio?a._volume=g:d.volume(g,a._id,!0),E&&(d._volume=g),(f<l&&g<=f||f>l&&g>=f)&&(clearInterval(a._interval),a._interval=null,a._fadeTo=null,d.volume(f,a._id),d._emit("fade",a._id))},D)},_stopFade:function(a){var l=this,f=l._soundById(a);return f&&f._interval&&(l._webAudio&&f._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(f._interval),f._interval=null,l.volume(f._fadeTo,a),f._fadeTo=null,l._emit("fade",a)),l},loop:function(){var a=this,l=arguments,f,m,S;if(l.length===0)return a._loop;if(l.length===1)if(typeof l[0]=="boolean")f=l[0],a._loop=f;else return S=a._soundById(parseInt(l[0],10)),S?S._loop:!1;else l.length===2&&(f=l[0],m=parseInt(l[1],10));for(var E=a._getSoundIds(m),d=0;d<E.length;d++)S=a._soundById(E[d]),S&&(S._loop=f,a._webAudio&&S._node&&S._node.bufferSource&&(S._node.bufferSource.loop=f,f&&(S._node.bufferSource.loopStart=S._start||0,S._node.bufferSource.loopEnd=S._stop,a.playing(E[d])&&(a.pause(E[d],!0),a.play(E[d],!0)))));return a},rate:function(){var a=this,l=arguments,f,m;if(l.length===0)m=a._sounds[0]._id;else if(l.length===1){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):f=parseFloat(l[0])}else l.length===2&&(f=parseFloat(l[0]),m=parseInt(l[1],10));var d;if(typeof f=="number"){if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"rate",action:function(){a.rate.apply(a,l)}}),a;typeof m>"u"&&(a._rate=f),m=a._getSoundIds(m);for(var g=0;g<m.length;g++)if(d=a._soundById(m[g]),d){a.playing(m[g])&&(d._rateSeek=a.seek(m[g]),d._playStart=a._webAudio?t.ctx.currentTime:d._playStart),d._rate=f,a._webAudio&&d._node&&d._node.bufferSource?d._node.bufferSource.playbackRate.setValueAtTime(f,t.ctx.currentTime):d._node&&(d._node.playbackRate=f);var A=a.seek(m[g]),I=(a._sprite[d._sprite][0]+a._sprite[d._sprite][1])/1e3-A,D=I*1e3/Math.abs(d._rate);(a._endTimers[m[g]]||!d._paused)&&(a._clearTimer(m[g]),a._endTimers[m[g]]=setTimeout(a._ended.bind(a,d),D)),a._emit("rate",d._id)}}else return d=a._soundById(m),d?d._rate:a._rate;return a},seek:function(){var a=this,l=arguments,f,m;if(l.length===0)a._sounds.length&&(m=a._sounds[0]._id);else if(l.length===1){var S=a._getSoundIds(),E=S.indexOf(l[0]);E>=0?m=parseInt(l[0],10):a._sounds.length&&(m=a._sounds[0]._id,f=parseFloat(l[0]))}else l.length===2&&(f=parseFloat(l[0]),m=parseInt(l[1],10));if(typeof m>"u")return 0;if(typeof f=="number"&&(a._state!=="loaded"||a._playLock))return a._queue.push({event:"seek",action:function(){a.seek.apply(a,l)}}),a;var d=a._soundById(m);if(d)if(typeof f=="number"&&f>=0){var g=a.playing(m);g&&a.pause(m,!0),d._seek=f,d._ended=!1,a._clearTimer(m),!a._webAudio&&d._node&&!isNaN(d._node.duration)&&(d._node.currentTime=f);var A=function(){g&&a.play(m,!0),a._emit("seek",m)};if(g&&!a._webAudio){var I=function(){a._playLock?setTimeout(I,0):A()};setTimeout(I,0)}else A()}else if(a._webAudio){var D=a.playing(m)?t.ctx.currentTime-d._playStart:0,O=d._rateSeek?d._rateSeek-d._seek:0;return d._seek+(O+D*Math.abs(d._rate))}else return d._node.currentTime;return a},playing:function(a){var l=this;if(typeof a=="number"){var f=l._soundById(a);return f?!f._paused:!1}for(var m=0;m<l._sounds.length;m++)if(!l._sounds[m]._paused)return!0;return!1},duration:function(a){var l=this,f=l._duration,m=l._soundById(a);return m&&(f=l._sprite[m._sprite][1]/1e3),f},state:function(){return this._state},unload:function(){for(var a=this,l=a._sounds,f=0;f<l.length;f++)l[f]._paused||a.stop(l[f]._id),a._webAudio||(a._clearSound(l[f]._node),l[f]._node.removeEventListener("error",l[f]._errorFn,!1),l[f]._node.removeEventListener(t._canPlayEvent,l[f]._loadFn,!1),l[f]._node.removeEventListener("ended",l[f]._endFn,!1),t._releaseHtml5Audio(l[f]._node)),delete l[f]._node,a._clearTimer(l[f]._id);var m=t._howls.indexOf(a);m>=0&&t._howls.splice(m,1);var S=!0;for(f=0;f<t._howls.length;f++)if(t._howls[f]._src===a._src||a._src.indexOf(t._howls[f]._src)>=0){S=!1;break}return r&&S&&delete r[a._src],t.noAudio=!1,a._state="unloaded",a._sounds=[],a=null,null},on:function(a,l,f,m){var S=this,E=S["_on"+a];return typeof l=="function"&&E.push(m?{id:f,fn:l,once:m}:{id:f,fn:l}),S},off:function(a,l,f){var m=this,S=m["_on"+a],E=0;if(typeof l=="number"&&(f=l,l=null),l||f)for(E=0;E<S.length;E++){var d=f===S[E].id;if(l===S[E].fn&&d||!l&&d){S.splice(E,1);break}}else if(a)m["_on"+a]=[];else{var g=Object.keys(m);for(E=0;E<g.length;E++)g[E].indexOf("_on")===0&&Array.isArray(m[g[E]])&&(m[g[E]]=[])}return m},once:function(a,l,f){var m=this;return m.on(a,l,f,1),m},_emit:function(a,l,f){for(var m=this,S=m["_on"+a],E=S.length-1;E>=0;E--)(!S[E].id||S[E].id===l||a==="load")&&(setTimeout((function(d){d.call(this,l,f)}).bind(m,S[E].fn),0),S[E].once&&m.off(a,S[E].fn,S[E].id));return m._loadQueue(a),m},_loadQueue:function(a){var l=this;if(l._queue.length>0){var f=l._queue[0];f.event===a&&(l._queue.shift(),l._loadQueue()),a||f.action()}return l},_ended:function(a){var l=this,f=a._sprite;if(!l._webAudio&&a._node&&!a._node.paused&&!a._node.ended&&a._node.currentTime<a._stop)return setTimeout(l._ended.bind(l,a),100),l;var m=!!(a._loop||l._sprite[f][2]);if(l._emit("end",a._id),!l._webAudio&&m&&l.stop(a._id,!0).play(a._id),l._webAudio&&m){l._emit("play",a._id),a._seek=a._start||0,a._rateSeek=0,a._playStart=t.ctx.currentTime;var S=(a._stop-a._start)*1e3/Math.abs(a._rate);l._endTimers[a._id]=setTimeout(l._ended.bind(l,a),S)}return l._webAudio&&!m&&(a._paused=!0,a._ended=!0,a._seek=a._start||0,a._rateSeek=0,l._clearTimer(a._id),l._cleanBuffer(a._node),t._autoSuspend()),!l._webAudio&&!m&&l.stop(a._id,!0),l},_clearTimer:function(a){var l=this;if(l._endTimers[a]){if(typeof l._endTimers[a]!="function")clearTimeout(l._endTimers[a]);else{var f=l._soundById(a);f&&f._node&&f._node.removeEventListener("ended",l._endTimers[a],!1)}delete l._endTimers[a]}return l},_soundById:function(a){for(var l=this,f=0;f<l._sounds.length;f++)if(a===l._sounds[f]._id)return l._sounds[f];return null},_inactiveSound:function(){var a=this;a._drain();for(var l=0;l<a._sounds.length;l++)if(a._sounds[l]._ended)return a._sounds[l].reset();return new s(a)},_drain:function(){var a=this,l=a._pool,f=0,m=0;if(!(a._sounds.length<l)){for(m=0;m<a._sounds.length;m++)a._sounds[m]._ended&&f++;for(m=a._sounds.length-1;m>=0;m--){if(f<=l)return;a._sounds[m]._ended&&(a._webAudio&&a._sounds[m]._node&&a._sounds[m]._node.disconnect(0),a._sounds.splice(m,1),f--)}}},_getSoundIds:function(a){var l=this;if(typeof a>"u"){for(var f=[],m=0;m<l._sounds.length;m++)f.push(l._sounds[m]._id);return f}else return[a]},_refreshBuffer:function(a){var l=this;return a._node.bufferSource=t.ctx.createBufferSource(),a._node.bufferSource.buffer=r[l._src],a._panner?a._node.bufferSource.connect(a._panner):a._node.bufferSource.connect(a._node),a._node.bufferSource.loop=a._loop,a._loop&&(a._node.bufferSource.loopStart=a._start||0,a._node.bufferSource.loopEnd=a._stop||0),a._node.bufferSource.playbackRate.setValueAtTime(a._rate,t.ctx.currentTime),l},_cleanBuffer:function(a){var l=this,f=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!a.bufferSource)return l;if(t._scratchBuffer&&a.bufferSource&&(a.bufferSource.onended=null,a.bufferSource.disconnect(0),f))try{a.bufferSource.buffer=t._scratchBuffer}catch{}return a.bufferSource=null,l},_clearSound:function(a){var l=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);l||(a.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var s=function(a){this._parent=a,this.init()};s.prototype={init:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,l._sounds.push(a),a.create(),a},create:function(){var a=this,l=a._parent,f=t._muted||a._muted||a._parent._muted?0:a._volume;return l._webAudio?(a._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),a._node.gain.setValueAtTime(f,t.ctx.currentTime),a._node.paused=!0,a._node.connect(t.masterGain)):t.noAudio||(a._node=t._obtainHtml5Audio(),a._errorFn=a._errorListener.bind(a),a._node.addEventListener("error",a._errorFn,!1),a._loadFn=a._loadListener.bind(a),a._node.addEventListener(t._canPlayEvent,a._loadFn,!1),a._endFn=a._endListener.bind(a),a._node.addEventListener("ended",a._endFn,!1),a._node.src=l._src,a._node.preload=l._preload===!0?"auto":l._preload,a._node.volume=f*t.volume(),a._node.load()),a},reset:function(){var a=this,l=a._parent;return a._muted=l._muted,a._loop=l._loop,a._volume=l._volume,a._rate=l._rate,a._seek=0,a._rateSeek=0,a._paused=!0,a._ended=!0,a._sprite="__default",a._id=++t._counter,a},_errorListener:function(){var a=this;a._parent._emit("loaderror",a._id,a._node.error?a._node.error.code:0),a._node.removeEventListener("error",a._errorFn,!1)},_loadListener:function(){var a=this,l=a._parent;l._duration=Math.ceil(a._node.duration*10)/10,Object.keys(l._sprite).length===0&&(l._sprite={__default:[0,l._duration*1e3]}),l._state!=="loaded"&&(l._state="loaded",l._emit("load"),l._loadQueue()),a._node.removeEventListener(t._canPlayEvent,a._loadFn,!1)},_endListener:function(){var a=this,l=a._parent;l._duration===1/0&&(l._duration=Math.ceil(a._node.duration*10)/10,l._sprite.__default[1]===1/0&&(l._sprite.__default[1]=l._duration*1e3),l._ended(a)),a._node.removeEventListener("ended",a._endFn,!1)}};var r={},o=function(a){var l=a._src;if(r[l]){a._duration=r[l].duration,u(a);return}if(/^data:[^;]+;base64,/.test(l)){for(var f=atob(l.split(",")[1]),m=new Uint8Array(f.length),S=0;S<f.length;++S)m[S]=f.charCodeAt(S);h(m.buffer,a)}else{var E=new XMLHttpRequest;E.open(a._xhr.method,l,!0),E.withCredentials=a._xhr.withCredentials,E.responseType="arraybuffer",a._xhr.headers&&Object.keys(a._xhr.headers).forEach(function(d){E.setRequestHeader(d,a._xhr.headers[d])}),E.onload=function(){var d=(E.status+"")[0];if(d!=="0"&&d!=="2"&&d!=="3"){a._emit("loaderror",null,"Failed loading audio file with status: "+E.status+".");return}h(E.response,a)},E.onerror=function(){a._webAudio&&(a._html5=!0,a._webAudio=!1,a._sounds=[],delete r[l],a.load())},c(E)}},c=function(a){try{a.send()}catch{a.onerror()}},h=function(a,l){var f=function(){l._emit("loaderror",null,"Decoding audio data failed.")},m=function(S){S&&l._sounds.length>0?(r[l._src]=S,u(l,S)):f()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(a).then(m).catch(f):t.ctx.decodeAudioData(a,m,f)},u=function(a,l){l&&!a._duration&&(a._duration=l.duration),Object.keys(a._sprite).length===0&&(a._sprite={__default:[0,a._duration*1e3]}),a._state!=="loaded"&&(a._state="loaded",a._emit("load"),a._loadQueue())},p=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var a=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),l=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),f=l?parseInt(l[1],10):null;if(a&&f&&f<9){var m=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!m&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};n.Howler=t,n.Howl=i,typeof ss<"u"?(ss.HowlerGlobal=e,ss.Howler=t,ss.Howl=i,ss.Sound=s):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=i,window.Sound=s)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var i=this;if(!i.ctx||!i.ctx.listener)return i;for(var s=i._howls.length-1;s>=0;s--)i._howls[s].stereo(t);return i},HowlerGlobal.prototype.pos=function(t,i,s){var r=this;if(!r.ctx||!r.ctx.listener)return r;if(i=typeof i!="number"?r._pos[1]:i,s=typeof s!="number"?r._pos[2]:s,typeof t=="number")r._pos=[t,i,s],typeof r.ctx.listener.positionX<"u"?(r.ctx.listener.positionX.setTargetAtTime(r._pos[0],Howler.ctx.currentTime,.1),r.ctx.listener.positionY.setTargetAtTime(r._pos[1],Howler.ctx.currentTime,.1),r.ctx.listener.positionZ.setTargetAtTime(r._pos[2],Howler.ctx.currentTime,.1)):r.ctx.listener.setPosition(r._pos[0],r._pos[1],r._pos[2]);else return r._pos;return r},HowlerGlobal.prototype.orientation=function(t,i,s,r,o,c){var h=this;if(!h.ctx||!h.ctx.listener)return h;var u=h._orientation;if(i=typeof i!="number"?u[1]:i,s=typeof s!="number"?u[2]:s,r=typeof r!="number"?u[3]:r,o=typeof o!="number"?u[4]:o,c=typeof c!="number"?u[5]:c,typeof t=="number")h._orientation=[t,i,s,r,o,c],typeof h.ctx.listener.forwardX<"u"?(h.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),h.ctx.listener.forwardY.setTargetAtTime(i,Howler.ctx.currentTime,.1),h.ctx.listener.forwardZ.setTargetAtTime(s,Howler.ctx.currentTime,.1),h.ctx.listener.upX.setTargetAtTime(r,Howler.ctx.currentTime,.1),h.ctx.listener.upY.setTargetAtTime(o,Howler.ctx.currentTime,.1),h.ctx.listener.upZ.setTargetAtTime(c,Howler.ctx.currentTime,.1)):h.ctx.listener.setOrientation(t,i,s,r,o,c);else return u;return h},Howl.prototype.init=(function(t){return function(i){var s=this;return s._orientation=i.orientation||[1,0,0],s._stereo=i.stereo||null,s._pos=i.pos||null,s._pannerAttr={coneInnerAngle:typeof i.coneInnerAngle<"u"?i.coneInnerAngle:360,coneOuterAngle:typeof i.coneOuterAngle<"u"?i.coneOuterAngle:360,coneOuterGain:typeof i.coneOuterGain<"u"?i.coneOuterGain:0,distanceModel:typeof i.distanceModel<"u"?i.distanceModel:"inverse",maxDistance:typeof i.maxDistance<"u"?i.maxDistance:1e4,panningModel:typeof i.panningModel<"u"?i.panningModel:"HRTF",refDistance:typeof i.refDistance<"u"?i.refDistance:1,rolloffFactor:typeof i.rolloffFactor<"u"?i.rolloffFactor:1},s._onstereo=i.onstereo?[{fn:i.onstereo}]:[],s._onpos=i.onpos?[{fn:i.onpos}]:[],s._onorientation=i.onorientation?[{fn:i.onorientation}]:[],t.call(this,i)}})(Howl.prototype.init),Howl.prototype.stereo=function(t,i){var s=this;if(!s._webAudio)return s;if(s._state!=="loaded")return s._queue.push({event:"stereo",action:function(){s.stereo(t,i)}}),s;var r=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof i>"u")if(typeof t=="number")s._stereo=t,s._pos=[t,0,0];else return s._stereo;for(var o=s._getSoundIds(i),c=0;c<o.length;c++){var h=s._soundById(o[c]);if(h)if(typeof t=="number")h._stereo=t,h._pos=[t,0,0],h._node&&(h._pannerAttr.panningModel="equalpower",(!h._panner||!h._panner.pan)&&e(h,r),r==="spatial"?typeof h._panner.positionX<"u"?(h._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),h._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),h._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):h._panner.setPosition(t,0,0):h._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),s._emit("stereo",h._id);else return h._stereo}return s},Howl.prototype.pos=function(t,i,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"pos",action:function(){o.pos(t,i,s,r)}}),o;if(i=typeof i!="number"?0:i,s=typeof s!="number"?-.5:s,typeof r>"u")if(typeof t=="number")o._pos=[t,i,s];else return o._pos;for(var c=o._getSoundIds(r),h=0;h<c.length;h++){var u=o._soundById(c[h]);if(u)if(typeof t=="number")u._pos=[t,i,s],u._node&&((!u._panner||u._panner.pan)&&e(u,"spatial"),typeof u._panner.positionX<"u"?(u._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.positionY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.positionZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setPosition(t,i,s)),o._emit("pos",u._id);else return u._pos}return o},Howl.prototype.orientation=function(t,i,s,r){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"orientation",action:function(){o.orientation(t,i,s,r)}}),o;if(i=typeof i!="number"?o._orientation[1]:i,s=typeof s!="number"?o._orientation[2]:s,typeof r>"u")if(typeof t=="number")o._orientation=[t,i,s];else return o._orientation;for(var c=o._getSoundIds(r),h=0;h<c.length;h++){var u=o._soundById(c[h]);if(u)if(typeof t=="number")u._orientation=[t,i,s],u._node&&(u._panner||(u._pos||(u._pos=o._pos||[0,0,-.5]),e(u,"spatial")),typeof u._panner.orientationX<"u"?(u._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.orientationY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.orientationZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setOrientation(t,i,s)),o._emit("orientation",u._id);else return u._orientation}return o},Howl.prototype.pannerAttr=function(){var t=this,i=arguments,s,r,o;if(!t._webAudio)return t;if(i.length===0)return t._pannerAttr;if(i.length===1)if(typeof i[0]=="object")s=i[0],typeof r>"u"&&(s.pannerAttr||(s.pannerAttr={coneInnerAngle:s.coneInnerAngle,coneOuterAngle:s.coneOuterAngle,coneOuterGain:s.coneOuterGain,distanceModel:s.distanceModel,maxDistance:s.maxDistance,refDistance:s.refDistance,rolloffFactor:s.rolloffFactor,panningModel:s.panningModel}),t._pannerAttr={coneInnerAngle:typeof s.pannerAttr.coneInnerAngle<"u"?s.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof s.pannerAttr.coneOuterAngle<"u"?s.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof s.pannerAttr.coneOuterGain<"u"?s.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof s.pannerAttr.distanceModel<"u"?s.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof s.pannerAttr.maxDistance<"u"?s.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof s.pannerAttr.refDistance<"u"?s.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof s.pannerAttr.rolloffFactor<"u"?s.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof s.pannerAttr.panningModel<"u"?s.pannerAttr.panningModel:t._panningModel});else return o=t._soundById(parseInt(i[0],10)),o?o._pannerAttr:t._pannerAttr;else i.length===2&&(s=i[0],r=parseInt(i[1],10));for(var c=t._getSoundIds(r),h=0;h<c.length;h++)if(o=t._soundById(c[h]),o){var u=o._pannerAttr;u={coneInnerAngle:typeof s.coneInnerAngle<"u"?s.coneInnerAngle:u.coneInnerAngle,coneOuterAngle:typeof s.coneOuterAngle<"u"?s.coneOuterAngle:u.coneOuterAngle,coneOuterGain:typeof s.coneOuterGain<"u"?s.coneOuterGain:u.coneOuterGain,distanceModel:typeof s.distanceModel<"u"?s.distanceModel:u.distanceModel,maxDistance:typeof s.maxDistance<"u"?s.maxDistance:u.maxDistance,refDistance:typeof s.refDistance<"u"?s.refDistance:u.refDistance,rolloffFactor:typeof s.rolloffFactor<"u"?s.rolloffFactor:u.rolloffFactor,panningModel:typeof s.panningModel<"u"?s.panningModel:u.panningModel};var p=o._panner;p||(o._pos||(o._pos=t._pos||[0,0,-.5]),e(o,"spatial"),p=o._panner),p.coneInnerAngle=u.coneInnerAngle,p.coneOuterAngle=u.coneOuterAngle,p.coneOuterGain=u.coneOuterGain,p.distanceModel=u.distanceModel,p.maxDistance=u.maxDistance,p.refDistance=u.refDistance,p.rolloffFactor=u.rolloffFactor,p.panningModel=u.panningModel}return t},Sound.prototype.init=(function(t){return function(){var i=this,s=i._parent;i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,t.call(this),i._stereo?s.stereo(i._stereo):i._pos&&s.pos(i._pos[0],i._pos[1],i._pos[2],i._id)}})(Sound.prototype.init),Sound.prototype.reset=(function(t){return function(){var i=this,s=i._parent;return i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,i._stereo?s.stereo(i._stereo):i._pos?s.pos(i._pos[0],i._pos[1],i._pos[2],i._id):i._panner&&(i._panner.disconnect(0),i._panner=void 0,s._refreshBuffer(i)),t.call(this)}})(Sound.prototype.reset);var e=function(t,i){i=i||"spatial",i==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()})(sa)),sa}var SS=mS();function Hc(n){return n[Math.floor(Math.random()*n.length)]}function Gc(n,e=10){const t=1/(1+Math.exp(e*.5)),i=1/(1+Math.exp(-e*.5));return(1/(1+Math.exp(-e*(n-.5)))-t)/(i-t)}const AS=["click_002.ogg"],Vl=["spinner","object-meshes","track-geometry","track-boosts","sound-effects","tile-glyph-geometries"],kl={spinner:5,"object-meshes":50,"track-geometry":50,"track-boosts":50,"sound-effects":50,"tile-glyph-geometries":100},Vc=new Map;function vo(n,e){Vc.set(n,e)}async function xS(n){const e=Vl.reduce((s,r)=>s+(kl[r]??0),0);let t=0;const i=new Map;for(const s of Vl){const r=Vc.get(s),o=performance.now();r&&await r();const c=performance.now()-o;i.set(s,c),t+=kl[s]??c,e>0&&n(Math.round(100*t/e))}n(100)}const Yl=new Map;vo("sound-effects",_S);async function _S(){AS.map(async n=>{Yl.set(n,new SS.Howl({src:[`sounds/${n}`],format:["ogg"]}))}),await Promise.all(Object.values(Yl).map(n=>new Promise((e,t)=>{const i=n;i.once("load",e),i.once("loaderror",()=>{t()})})))}const gS=`aback
abaft
abase
abate
abbey
abbot
abhor
abide
abler
abode
about
above
abuse
abyss
ached
aches
acids
acorn
acres
acrid
acted
actor
acute
adage
adapt
added
adder
adept
adieu
admit
adobe
adopt
adore
adorn
adult
aegis
aeons
affix
afire
afoot
after
again
agape
agate
agent
agile
aging
aglow
agony
agree
ahead
aided
aides
ailed
aimed
aired
aisle
alarm
album
alder
alert
alias
alibi
alien
alike
alive
allay
alley
allot
allow
alloy
aloes
aloft
alone
along
aloof
aloud
alpha
altar
alter
altos
amass
amaze
amber
amble
amend
amigo
amiss
amity
among
amour
ample
amply
amuse
angel
anger
angle
angry
angst
anime
ankle
annex
annoy
annul
antes
antic
anvil
apace
apart
aping
appal
apple
apply
apron
aptly
areas
arena
argue
arise
armed
aroma
arose
array
arrow
arson
ashen
ashes
aside
asked
askew
aspen
assay
asses
asset
atlas
atoll
atoms
atone
attar
attic
audio
audit
auger
aught
augur
aunts
auras
autos
avail
avert
avoid
avows
await
awake
award
aware
awful
awoke
axiom
axles
azure
babel
babes
backs
bacon
badge
badly
baggy
baits
baize
baked
baker
bales
balls
balmy
banal
bands
bandy
bangs
banjo
banks
barbs
bards
bared
barge
barks
barns
baron
basal
based
baser
bases
basic
basil
basin
basis
baste
batch
bated
bathe
baths
baton
bayou
beach
beads
beady
beaks
beams
beans
beard
bears
beast
beaux
beech
beets
befit
began
begat
beget
begin
begot
begun
being
belie
belle
bells
belly
below
belts
bench
bends
bergs
berry
berth
beryl
beset
bevel
bible
bides
bight
bigot
bilge
bills
billy
binds
biped
birch
birds
birth
bison
bites
black
blade
blame
bland
blank
blare
blast
blaze
bleak
bleat
bleed
blend
bless
blest
blind
blink
bliss
block
blond
blood
bloom
blots
blown
blows
bluer
blues
bluff
blunt
blurt
blush
board
boars
boast
boats
boded
bodes
boggy
bogus
boils
boles
bolts
bombs
bonds
boned
bones
bonny
bonus
booby
books
booms
boons
boors
boost
booth
boots
booty
booze
borax
bored
bores
bosom
bough
bound
bouts
bowed
bowel
bower
bowls
boxed
boxer
boxes
brace
brags
braid
brain
brake
brand
brass
brats
brave
bravo
brawl
brawn
bread
break
breed
briar
bribe
brick
bride
brief
brier
brigs
brims
brine
bring
brink
briny
brisk
broad
broil
broke
brood
brook
broom
broth
brown
brows
bruin
brunt
brush
brute
bucks
budge
buggy
bugle
build
built
bulbs
bulge
bulks
bulky
bulls
bully
bumps
bunch
bunks
buoys
burly
burns
burnt
burrs
burst
bushy
busts
butte
butts
buxom
buyer
cabal
cabby
cabin
cable
cacao
cache
cadet
cadre
caged
cages
cairn
caked
cakes
calls
calms
calyx
camel
cameo
camps
canal
candy
canes
canny
canoe
canon
canto
caper
capes
capon
cards
cared
cares
cargo
carol
carry
carts
carve
cased
cases
casks
caste
casts
catch
cater
cause
caved
caves
cavil
cease
cedar
ceded
cells
cents
chafe
chaff
chain
chair
chalk
champ
chant
chaos
chaps
charm
chart
chary
chase
chasm
chats
cheap
cheat
check
cheek
cheer
chefs
chess
chest
chick
chide
chief
child
chill
chime
china
chink
chins
chips
chirp
choir
choke
chops
chord
chose
chuck
chump
chums
chunk
churl
churn
chute
cider
cigar
cinch
circa
cited
cites
civet
civic
civil
clack
claim
clamp
clams
clang
clank
clans
claps
clash
clasp
class
claws
clean
clear
clefs
cleft
clerk
clews
click
cliff
climb
clime
cling
clink
clips
cloak
clock
clods
clogs
close
cloth
cloud
clout
clove
clown
clubs
cluck
clues
clump
clung
coach
coals
coast
coats
cobra
cocks
cocoa
codes
coils
coins
colds
colic
colon
colts
combs
comer
comes
comet
comic
comma
conch
cones
conic
cooed
cooks
cools
copra
copse
coral
cords
cores
corks
corns
corps
costs
cotes
couch
cough
could
count
coupe
coups
court
cover
coves
covet
covey
cowed
cower
coyly
cozen
crabs
crack
craft
crags
cramp
crane
crank
crape
crash
crass
crate
crave
crawl
craze
crazy
creak
cream
credo
creed
creek
creep
crepe
crept
cress
crest
crews
cribs
crick
cried
crier
cries
crime
crimp
crisp
croak
crock
crone
crony
crook
crops
cross
croup
crowd
crown
crows
crude
cruel
crumb
crush
crust
crypt
cubes
cubic
cubit
cuffs
cults
curds
cured
cures
curls
curly
curry
curse
curve
cycle
cynic
daddy
daily
dairy
daisy
dales
dally
dames
damps
dance
dandy
dared
dares
darts
dated
dates
datum
daubs
daunt
dawns
dazed
deals
dealt
deans
dears
death
debar
debit
debts
debut
decay
decks
decoy
decry
deeds
deems
deeps
defer
deign
deity
delay
dells
delta
delve
demon
demur
dense
dents
depot
depth
derby
desks
deter
deuce
devil
diary
diced
dices
dicta
diets
digit
dikes
dimes
dimly
dined
diner
dines
dingy
dirge
dirty
discs
disks
ditch
ditto
ditty
divan
dived
diver
dives
dizzy
docks
dodge
doers
dogma
doing
doled
dolls
domed
domes
donor
dooms
doors
dosed
doses
doted
dotes
doubt
dough
doves
downs
downy
dowry
dozed
dozen
draft
drags
drain
drake
drama
drams
drank
drape
drawl
drawn
draws
dread
dream
dregs
dress
dried
drier
dries
drift
drill
drily
drink
drips
drive
droll
drone
droop
drops
dross
drove
drown
drugs
drums
drunk
dryly
ducal
ducat
ducks
ducts
duels
duets
dukes
dully
dummy
dumps
dumpy
dunce
dunes
duped
dupes
dusky
dusty
dwarf
dwell
dwelt
dying
dykes
eager
eagle
earls
early
earns
earth
eased
easel
eases
eaten
eater
eaves
ebbed
ebony
edged
edges
edict
edify
eerie
egged
eight
eject
elate
elbow
elder
elect
elegy
elfin
elite
elope
elude
elves
email
emits
empty
enact
ended
endow
enemy
enjoy
ensue
enter
entry
envoy
epics
epoch
equal
equip
erase
erect
erred
error
essay
ether
ethic
evade
event
every
evils
evoke
exact
exalt
excel
exert
exile
exist
exits
expel
extol
extra
exult
eying
fable
faced
faces
facts
faded
fades
fails
faint
fairs
fairy
faith
falls
false
famed
fancy
fangs
farce
fared
fares
farms
fasts
fatal
fated
fates
fatty
fault
fauna
fauns
fawns
fears
feast
feats
feeds
feels
feign
feint
fells
felon
fence
feral
ferns
ferry
fetch
fetid
fetus
feuds
fever
fewer
fiefs
field
fiend
fiery
fifes
fifth
fifty
fight
filch
filed
files
filet
fills
filly
films
filmy
filth
final
finch
finds
fined
finer
fines
fired
fires
firms
first
fishy
fists
fitly
fives
fixed
fixer
fixes
fjord
flags
flail
flair
flake
flaky
flame
flank
flaps
flare
flash
flask
flats
flaws
fleas
fleck
flees
fleet
flesh
flick
flier
flies
fling
flint
flirt
flits
float
flock
floes
flood
floor
flora
floss
flour
flout
flown
flows
flues
fluff
fluid
fluke
flume
flung
flush
flute
flyer
foams
foamy
focal
focus
foggy
foils
foist
folds
folio
folks
folly
foods
fools
foray
force
fords
forge
forgo
forks
forms
forte
forth
forts
forty
forum
found
fount
fours
fowls
foxes
foyer
frail
frame
franc
frank
fraud
freak
freed
freer
frees
fresh
frets
friar
fried
frill
frisk
frock
frogs
frond
front
frost
froth
frown
froze
fruit
fudge
fuels
fugue
fully
fumed
fumes
funds
fungi
funny
furry
furze
fused
fuses
fussy
fuzzy
gable
gaily
gains
gales
galls
games
gamin
gamma
gamut
gangs
gaped
gapes
gases
gasps
gates
gaudy
gauge
gaunt
gauze
gauzy
gavel
gawky
gayer
gayly
gazed
gazer
gazes
gears
geese
genie
genre
gents
genus
germs
ghost
giant
gibes
giddy
gifts
gilds
gills
gimme
gipsy
girds
girls
girth
given
gives
glade
gland
glare
glass
glaze
gleam
glean
glens
glide
glint
gloat
globe
gloom
glory
gloss
glove
glows
glued
gnash
gnats
gnaws
gnome
goads
goals
goats
godly
going
golly
gongs
gonna
goods
goody
goose
gored
gorge
gorse
gotta
gouge
gourd
gouty
gowns
grabs
grace
grade
graft
grain
grams
grand
grant
grape
graph
grasp
grass
grate
grave
gravy
graze
great
greed
green
greet
greys
grief
grill
grime
grimy
grind
grins
gripe
grips
grist
groan
groin
groom
grope
gross
group
grove
growl
grown
grows
grubs
gruel
gruff
grunt
guano
guard
guess
guest
guide
guild
guile
guilt
guise
gulch
gulfs
gulls
gully
gummy
gusto
gusts
gusty
habit
hacks
hails
hairs
hairy
haled
halls
halts
halve
hands
handy
hangs
happy
hardy
harem
hares
harms
harps
harpy
harry
harsh
harts
haste
hasty
hatch
hated
hater
hauls
haven
havoc
hawks
hazel
heads
heady
heals
heaps
heard
hears
heart
heath
heats
heave
heavy
hedge
heeds
heels
heirs
helix
hello
helms
helps
hence
herbs
herds
heron
heros
hewed
hides
hills
hilly
hilts
hinds
hinge
hints
hired
hires
hitch
hives
hoard
hoary
hobby
hoist
holds
holes
holly
homes
honey
hoods
hoofs
hooks
hoops
hoots
hoped
hopes
horde
horns
horny
horse
hosts
hotel
hotly
hound
hours
house
hovel
hover
howls
hulks
hulls
human
humid
humps
humus
hunch
hunts
hurls
hurry
hurts
husks
husky
hussy
hydra
hyena
hymns
icily
icing
ideal
ideas
idiom
idiot
idled
idler
idols
idyll
igloo
image
imbue
impel
imply
inane
incur
index
inept
inert
infer
ingot
inlet
inner
inter
inure
irate
irked
irons
irony
isles
islet
issue
items
ivory
jacks
jaded
jails
jaunt
jeans
jeers
jelly
jerks
jerky
jests
jetty
jewel
jiffy
joins
joint
joked
joker
jokes
jolly
joust
joyed
judge
juice
juicy
jumps
junks
junta
juror
karma
keels
keeps
ketch
keyed
khaki
kicks
kills
kinda
kinds
kings
kiosk
kites
knack
knave
knead
kneel
knees
knell
knelt
knife
knits
knobs
knock
knoll
knots
known
knows
label
laced
laces
lacks
laden
ladle
lager
lairs
laity
lakes
lambs
lamed
lames
lamps
lance
lands
lanes
lanky
lapel
lapse
larch
large
largo
larks
larva
lasso
lasts
latch
later
lathe
laths
laugh
lawns
layer
leads
leafy
leaks
leaky
leans
leaps
leapt
learn
lease
leash
least
leave
ledge
leech
leeks
legal
lemme
lemon
lends
leper
levee
level
lever
liars
libel
licks
liege
liens
lifts
light
liked
liken
liker
likes
lilac
limbo
limbs
limes
limit
lined
linen
liner
lines
lingo
links
lions
lists
lithe
lived
liver
lives
livid
llama
loads
loamy
loans
loath
lobby
lobes
local
locks
locus
lodge
lofty
loges
logic
login
loins
longs
looks
looms
loons
loops
loose
lords
loser
loses
lotus
louse
lousy
loved
lover
loves
lowed
lower
lowly
loyal
lucid
lucky
lulls
lumps
lumpy
lunar
lunch
lunge
lungs
lurch
lured
lures
lurid
lurks
lusts
lusty
lutes
lying
lymph
lynch
lyric
maces
madam
madly
magic
maids
mails
mains
maize
major
maker
makes
males
mamma
manes
manga
mange
mango
mangy
mania
manly
manor
maple
march
mares
marks
marry
marsh
marts
masks
mason
masts
match
mated
mates
mauve
maxim
maybe
mayor
mazes
meals
mealy
means
meant
meats
medal
media
meets
melon
melts
memes
mends
menus
mercy
meres
merge
merit
merry
mesas
metal
meted
meter
mewed
midst
miens
might
milch
miles
milky
mills
mimes
mimic
mince
minds
mined
miner
mines
minor
mints
minus
mirth
miser
mists
mites
mixed
mixes
moans
moats
mocks
model
modem
modes
moist
molar
moles
momma
money
monks
month
moods
moody
moons
moors
moose
moped
moral
mores
mossy
motes
moths
motif
motor
motto
mound
mount
mourn
mouse
mouth
moved
mover
moves
movie
mowed
mower
mucus
muddy
mules
mummy
mumps
munch
mural
murky
mused
muses
music
musky
musty
muted
mutes
myrrh
myths
nails
naive
naked
named
names
nasal
nasty
natal
natty
naval
navel
naves
nears
necks
needs
needy
neigh
nerve
nests
never
newer
newly
nicer
niche
niece
night
ninny
noble
nobly
noise
noisy
nomad
nonce
nooks
noose
north
nosed
noses
notch
noted
notes
nouns
novel
nudge
nurse
nymph
oaken
oases
oasis
oaten
oaths
obese
obeys
occur
ocean
ochre
odder
oddly
odium
offer
often
oiled
olden
older
omens
omits
onion
onset
oozed
oozes
opals
opens
opera
opine
opium
optic
orbit
order
organ
other
otter
ought
ounce
outdo
outer
ovals
ovary
ovens
overt
owing
owned
owner
oxide
ozone
paces
packs
paddy
padre
pagan
pages
pails
pains
paint
pairs
paled
paler
pales
palms
palmy
palsy
panel
panes
pangs
panic
pansy
pants
papal
papas
paper
pared
parka
parks
parry
parse
parts
party
pasha
paste
pasty
patch
pates
paths
patio
pause
paved
pawed
pawns
payed
payer
peace
peach
peaks
peals
pearl
pears
pease
pecks
pedal
peeps
peers
pelts
penal
pence
penny
peons
perch
peril
pesky
pesos
pests
petal
petty
phase
phial
phone
photo
piano
picks
piece
piers
piety
pigmy
pikes
piled
piles
pills
pilot
pinch
pined
pines
pinks
pinto
pints
pious
piped
piper
pipes
pique
pitch
pithy
pivot
place
plaid
plain
plait
plane
plank
plans
plant
plate
plays
plaza
plead
pleas
plied
plies
plots
pluck
plugs
plumb
plume
plums
plush
podia
poems
poesy
poets
point
poise
poked
poker
pokes
polar
poles
polka
polls
ponds
pools
popes
poppa
poppy
porch
pored
pores
ports
posed
poser
poses
posse
posts
pouch
pound
pours
power
prank
prate
prays
press
preys
price
prick
pride
pried
pries
prime
print
prior
prism
privy
prize
probe
prone
proof
props
prose
prosy
proud
prove
prowl
prows
proxy
prude
prune
psalm
pshaw
pudgy
puffs
puffy
pulls
pulpy
pulse
pumps
punch
pupil
puppy
puree
purer
purge
purse
pussy
putty
quack
quaff
quail
quake
qualm
quart
quasi
quays
queen
queer
quell
query
quest
queue
quick
quiet
quill
quilt
quips
quire
quite
quits
quota
quote
quoth
rabbi
rabid
raced
racer
races
racks
radii
radio
rafts
raged
rages
raids
rails
rains
rainy
raise
rajah
raked
rakes
rally
ranch
range
ranks
rapid
rarer
rares
rated
rates
ratio
raved
raven
raves
rayon
razed
razor
reach
react
reads
ready
realm
reals
reams
reaps
rears
rebel
rebus
rebut
recur
reeds
reedy
reefs
reeks
reels
reeve
refer
refit
regal
reign
reins
relax
relay
relic
remit
rends
renew
rents
repay
repel
reply
reset
resin
rests
revel
rhyme
rider
rides
ridge
rifle
rifts
right
rigid
riled
rimes
rings
rinse
riots
ripen
riper
risen
riser
rises
risks
risky
rites
rival
riven
river
rivet
roads
roams
roars
roast
robed
robes
robin
rocks
rocky
rogue
roles
rolls
roman
roofs
rooks
rooms
roomy
roost
roots
roped
ropes
roses
rosin
rouge
rough
round
rouse
route
routs
roved
rover
rowdy
rowed
royal
ruder
ruins
ruled
ruler
rules
runes
rungs
rupee
rural
ruses
sable
sabre
sacks
sadly
safer
sagas
sages
sails
saint
salad
sales
sally
salon
salsa
salts
salty
salve
salvo
sands
sandy
saner
sated
satin
satyr
sauce
saucy
saved
saves
sawed
scald
scale
scalp
scaly
scans
scant
scare
scarf
scars
scene
scent
scion
scoff
scold
scoop
scope
score
scorn
scour
scout
scowl
scrap
screw
scrip
scrub
scull
seals
seams
seamy
seats
sects
sedan
sedge
seeds
seedy
seeks
seems
seers
seize
sells
sends
sense
serfs
serge
serum
serve
seven
sever
sewed
sewer
sexes
shack
shade
shady
shaft
shake
shaky
shale
shall
shalt
shame
shams
shank
shape
share
shark
sharp
shave
shawl
sheaf
shear
sheds
sheen
sheep
sheer
sheet
sheik
shelf
shell
shied
shift
shine
shins
shiny
ships
shire
shirk
shirt
shoal
shock
shoes
shone
shook
shoon
shoot
shops
shore
shorn
short
shots
shout
shove
shown
shows
showy
shred
shrew
shrub
shrug
shuns
shuts
shyly
sided
sides
siege
sieve
sighs
sight
sigma
signs
silks
silky
sills
silly
since
sinew
singe
sings
sinks
siren
sires
sites
sixes
sixth
sixty
sized
sizes
skate
skies
skiff
skill
skims
skins
skips
skirt
skulk
skull
skunk
slabs
slack
slags
slain
slang
slant
slaps
slash
slate
slats
slave
slays
sleds
sleek
sleep
sleet
slept
slice
slick
slide
slime
slimy
sling
slink
slips
slits
slope
sloth
slugs
slump
slums
slung
slush
slyly
smack
small
smart
smash
smear
smell
smelt
smile
smirk
smite
smith
smock
smoke
smoky
smote
snack
snags
snail
snake
snaky
snaps
snare
snarl
sneak
sneer
sniff
snipe
snobs
snore
snort
snout
snows
snowy
soapy
soars
sober
socks
sofas
soggy
soils
solar
soles
solid
solos
solve
songs
sonny
sooth
sooty
sores
sorry
sorts
souls
sound
soups
south
sowed
sower
space
spade
spake
spank
spans
spare
spark
spars
spasm
spawn
speak
spear
speck
speed
spell
spelt
spend
spent
sperm
spice
spicy
spied
spies
spike
spill
spilt
spine
spins
spiny
spire
spite
spits
split
spoil
spoke
spook
spool
spoon
spoor
spore
sport
spots
spout
spray
spree
sprig
spunk
spurn
spurs
spurt
squad
squat
squaw
stabs
stack
staff
stage
stags
staid
stain
stair
stake
stale
stalk
stall
stamp
stand
stank
stare
stark
stars
start
state
stave
stays
stead
steak
steal
steam
steed
steel
steep
steer
stems
steps
stern
stews
stick
stiff
stile
still
sting
stink
stint
stirs
stock
stoic
stole
stone
stony
stood
stool
stoop
stops
store
stork
storm
story
stout
stove
strap
straw
stray
strew
strip
strut
stuck
studs
study
stuff
stump
stung
stunt
style
suave
sucks
sugar
suing
suite
suits
sulks
sulky
sully
sunny
super
surer
surge
surly
swain
swamp
swans
sward
swarm
sways
swear
sweat
sweep
sweet
swell
swept
swift
swill
swims
swine
swing
swirl
swish
swoon
swoop
sword
swore
sworn
swung
synod
syrup
tabby
table
taboo
tacit
tacks
tails
taint
taken
takes
tales
talks
tally
talon
tamed
tamer
tanks
taper
tapes
tardy
tarry
tarts
tasks
taste
tasty
taunt
tawny
taxed
taxes
teach
teams
tears
tease
teems
teens
teeth
tells
tempo
tends
tenet
tenor
tense
tenth
tents
tepid
terms
terse
tests
testy
texts
thank
theft
their
theme
there
these
thick
thief
thigh
thine
thing
think
third
thong
thorn
those
three
threw
throb
throe
throw
thumb
thump
thyme
tiara
tibia
ticks
tidal
tides
tiers
tiger
tight
tilde
tiled
tiles
tills
tilts
timed
times
timid
tinge
tints
tipsy
tired
tires
tithe
title
toads
toast
today
toddy
toils
token
tolls
tombs
tomes
toned
tones
tongs
tonic
tools
tooth
topaz
topic
torch
torso
total
totem
touch
tough
tours
towed
towel
tower
towns
toxic
toyed
trace
track
tract
trade
trail
train
trait
tramp
trams
traps
trash
trays
tread
treat
treed
trees
trend
tress
triad
trial
tribe
trice
trick
tried
tries
trill
tripe
trips
trite
troll
troop
troth
trots
trout
truce
truck
truer
truly
trump
trunk
truss
trust
truth
tryst
tubes
tufts
tulip
tulle
tuned
tunes
tunic
turns
tusks
tutor
twain
twang
tweed
twice
twigs
twine
twins
twirl
twist
tying
typed
types
udder
ulcer
ultra
uncle
uncut
under
undid
undue
unfit
union
unite
units
unity
unsay
untie
until
upper
upset
urban
urged
urges
urine
usage
users
usher
using
usual
usurp
utter
vague
vales
valet
valid
value
valve
vanes
vapid
vases
vault
vaunt
veils
veins
veldt
venal
venom
vents
venue
verbs
verge
verse
verve
vests
vexed
vexes
vials
vicar
vices
video
views
vigil
viler
villa
vines
viola
viper
virus
visit
visor
vista
vital
vivid
vixen
vizor
vocal
vodka
vogue
voice
voile
volts
vomit
voted
voter
votes
vouch
vowed
vowel
vying
waded
wafer
wafts
waged
wager
wages
wagon
waifs
wails
waist
waits
waive
waked
waken
wakes
walks
walls
waltz
wands
waned
wanes
wants
wards
wares
warms
warns
warts
wasps
waste
watch
water
waved
waver
waves
waxed
waxen
waxes
wears
weary
weave
wedge
weeds
weedy
weeks
weeps
weigh
weird
welch
wells
wench
whack
whale
wharf
wheat
wheel
whelp
where
which
whiff
while
whims
whine
whips
whirl
whisk
white
whole
whoop
whose
wicks
widen
wider
widow
width
wield
wight
wilds
wiles
wills
wince
winch
winds
windy
wines
wings
winks
wiped
wipes
wired
wires
wiser
wisps
witch
witty
wives
woman
women
woods
woody
wooed
wooer
words
wordy
works
world
worms
worry
worse
worst
worth
would
wound
wrack
wraps
wrapt
wrath
wreak
wreck
wrest
wring
wrist
write
writs
wrong
wrote
wroth
yacht
yards
yarns
yawns
yearn
years
yeast
yells
yelps
yield
yoked
yokes
yolks
young
yours
youth
zebra
zones`,ra=["SOULSI S PE H AV E KEERIE","AMPLEL  I O  K N  E GIRDS","YACHTO U RU R IR S LSWELL","GOTTAR O RU N RE E AL D Y","VENALI  L L  I LABELA  N ","FOYERI A UE W LRANGEY S R","CROSSR   EOTHERC   GKNAVE","RUNGSA   EGAYERE   USWARM","HANGSE E UL V PM E ESURER","CADETR   OANGSTG   ESERUM","AFFIXD E  I R  E N  UNSAY","FLIERA D URAYONE L ESILKS","MEANTA L OX I NI E EMINED","MOVEDE   ER   BR   IYACHT","PRATEU  W N  I CAIRNH  L ","NERVEO A AMARTSA E EDISKS","BIBLEI R LT I BE M OS S W","AGINGD N IOWNERR E TNORTH","SYRUPE   EREEFSU   OMULES","ALIENW N EA T VK E EERROR","CORALO  N ADAGES  E TULLE","WARESI  L ROYALE  T DIVES","CHOPSH  I U  V C  O KNITS","LEDGEE E LA C FKHAKIS Y N","FANGSU U EENDEDL G ASHEEN","FLUNGO N AALIASM O ESINGS","PANELA O  TABBYC L  HEEDS","BRUINA    NOOSEJ    ORBIT","SAGASK  L IRATEP  O SLASH","OPINEX  A I  T DEATHE  Y ","SHALEO  I R  N EAGERS  D ","ALIKES D AHULKSE E ES D L","MIXEDO  T OATHSD  E SHARK","LINESU A LR S AENTRYD Y S","GOOSER P  OVARYI L  NOSED","FILEDI O EN C LE K AS S Y","BRACER  A ARENAV  A OPALS","MOSSYI T ON U UELFINR F G","TRUMPW  A E  R ERASED  H ","TRUCEI D XN D ITEENSS R T","BEVELI O OL I OLOCKSS E E","PANGSO  R S  O TULIPS  N ","SMITEN  O O  W REBELT  R ","LASTSA P HD I OLINGOE S T","LAWNSI I WV D UE E ND N G","BROADL A IASSETM I TE S O","STUFFM L OO C LT E LEARLY","UDDERN W ADWARFE R TRAFTS","READSI G EN A EGAPEDS E S","FABLEI R LL E OCLAMPH D E","MERGEO U APINTSE E EDOSED","FOISTA   RULTRAN   CSTUNT","SKIMSP  I ISLESL  N LEASE","FASTSA  A R  S CASTEE  Y ","MORALA  M R  I ERASES  S ","WAISTA    NOTEDD    SMOCK","CAMEOH  X AVOIDR  L MOWED","DELAYA E ALIVERL E NYARNS","LIONSO   ITIMIDU   ESEAMS","IDOLSN Z PE O AP N NTEEMS","SCANTH M URUINSU S KBUSTS","LEASEA V TB A HEXILEL L R","SNACKP M NO I AOPTICR Y K","FURZER  E O  B G  R STEAL","TRIADH  M I  I NASTYK  Y ","FIFTHO    REPELG    EXULT","RIVALO I IB D TI E HNOOSE","RURALA   UGAINSE   TDECOY","CREEKH  T I  H CAVESK  R ","GRINDU   EL   ML   OSPAWN","TIERSO N TN S OE U OSWELL","GRANDR  O ANGRYD  T EIGHT","HANDYA  A L  R VOLTSE  S ","OUTDOW O DIDLEDN L LGUSTY","INNERN O AE U IPINTST S E","VILERA O OL D OINGOTD E S","SCARST   WOPERAR   IKNOWN","JOLLYE  A REARSK  G YOKES","BLENDU L ORIDESS E ETURNS","ASSETC I HT X IOBESER S F","WOMENO I OO L RELECTD S H","AGONYR  A SNAKYO  E NEEDY","GASPSL Q IO U ZO A EMEWED","SPAKET  N ORBITL  F EAVES","FOURSU   TN   ANEWLYY   S","DRONEI P LV A DE L ED S R","TRYSTA   IBROODB   EYELPS","NOTEDE I  W P  ESSAYR Y  ","WAKESH   HIGLOON   VEVOKE","QUAYSU  E A  A ROARST  N ","COULDA  I N  N ELEGYS  O ","RENTSE E WA A ICARTST S H","FROCKE M AR I RR T MY S A","FIELDL  I ASKEWG  N SLASH","CASTEL W AE E RWRESTS P H","REEKSE A OMOTIFI E ATENDS","NAILSA M TV B OEQUIPS E S","PINTOO O PN S ED E NS S S","MOUNTO T HDITTYE E MMERGE","POKERU  X P  I PAUSEY  T ","SLICK E  N A  ESPIKE S  L","FIFTY N  AENTER E  NAREAS","KNOWS E E SWEAR E V ERRED","PLAIT Y  A R  U I  NSCENT","COBRA A  L T  DGENRE N  R","THEIR E  ATAPER P  EASSES","RIVEN D X ELITE E R IDEAS","ANGRY O  O I  U S  TNYMPH","FLIRT U  HSNARE G  ITENOR","RAKES Z  TQUOTA R  YNEARS","CUBIC T  L T  ARELIC R  K","ROUGE A  ASTING H  LISSUE","BRUNT O  I W  LADORE Y  D","FARCE B  NTYPES S  UUSAGE","BLOTS O W EGGED I E  N D ","TOPIC V  O E  OSNACK S  S","TIDAL R  OMAGIC T  KMENDS","OUTDO R E  I B UNFIT E T ","SHAMS O  T P  ADETER S  K","HONEY O D  Z G RESET D S ","ROGUE V N  E C KNELT S E ","STAID R N  U D SLEEK Y X ","CEDAR X  ELITHE L  DDECOY","MOTOR O U OZONE E C IDLED","BAGGY R R COMIC S N SEEDY","SMART E   VALET N   STEPS","SCION R U FAINT M C SPEED","EARLS N  LAGATE E  EFREAK","CATCH W  A A  VBRAVO E  C","SHAKY A  A S  C T  HYEAST","VALID R  ELILAC S  RPENNY","MOTHS O A  Z T KEYED S D ","ARENA E  G I  IKNOWN S  G","SOGGY C A  C M QUEUE R T ","VALID S  RKHAKI E  N S  K","RATES M D BILGE S E  S S ","CIVIC D  R Y  OBLESS L  S","HUSKS R  T G  A E  RASIDE","DIRTY D H  I R BOSOM T B ","MILCH S  AFLYER E  PISLES","JUNTA N H  D I DEANS R E ","FLASH O  U B  SBEAKS S  Y","HOARY F  E T  A E  RONION","SWORD A O  N A ADORE S S ","SPERM I U ANGST E E  D S ","STAND H A  I M ACTED K S ","DOZEN C S TENSE A A  N Y ","AGAIN N T GAVEL T M  S S ","SWANS H  C I  ASPOIL S  D","PATIO W  N F  S U  EBLAST","WEDGE B E EBONY E T  D S ","CHUNK A  I T  OKEEPS R  K","MUCUS N  T C  A U  VSTAVE","GOLLY C  O C  KJUICE R  D","MARKS Z N  U O CRIBS E S ","SLITS A  O N  REDICT S  S","FURZE R E  B B CADRE N A ","SCREW L X LOVED A R SKATE","SERVE Q I  U S GIRTH P A ","HUMID R C AGAIN E L  D Y ","ZONES N V  I E ROUND N T ","SHORN O  EPURGE S  DTEEMS","OWING A O  V I CEASE D E ","HYENA E  B A  AUSERS T  E","THREE E  V N  ISCULL E  S","CHASE A A SCALP K S ASSAY","SIZES N  AENDED E  LIRONY","FILLS D I  E N MARES S D ","IDEAS E P AVAIL I N FLAGS","TEARS R  A E  TICILY T  R","SLOTH O I  O D KNEAD S L ","TARRY R  EMOMMA S  RHELMS","AWAKE A N TIMED V E TEASE","EMAIL I N  X A  E N IDLED","SORRY V A DEBTS R I STOOP","IRKED A  I J  CVALET H  A","GLUED I   LACED R   USUAL","CARRY L I BLADE O E SWORE","GOODS V  H A  ABLANK S  Y","LEAVE R A  R U NEWLY D T ","RIVEN S   BLUFF E   ASIDE","PROOF A L  T D SEWED D R ","RIDGE D   SIGHT O   ITEMS","TRACK I A EDICT E H ASKEW","LURID N R  F K WIPED T D ","IDEAS O C  U H ABBEY T D ","ORDER I  EASHEN E  TSNAPS","WIDTH N  OSTEER E  SCRATE","BARED L  IMINCE B  TTILTS","FRONT O  UASHEN I  EENDED","TRESS A  P K  ANESTS D  M","SHEDS U I TROTS R C MYTHS","SILKY N N METAL P V STEEL","CUBIC N  HSTAGE I  SREACT","FRIAR E  EUSUAL E  ISTOIC","REACT D   LINED C   STAVE","NOUNS C I  E N EARNS N Y ","SNEER O  AUSHER E  EUSERS","HAVEN N  O G  BGRILL Y  E","WORMS P A JESTS N E  S S ","GRAPHA S  PASTYE A  SHYLY","ROBINE U  BUYERE E  LARVA","MIGHTA A  COVEYE E  SALVO","BEACHA I  NUDGEA E  LEDGE","SWOREQ A  UNTILA E  TUNIC","WRAPS  S  DUSTY  A  KEYED","ALIVED S  E L  P E  TOTEM","MERGEA O LT B OCRISPH N E","SURERO E AB B NE U KRITES","STALEH M NRABIDU L EBREAD","NICERA R IV I VE E AS S L","DEEPSI Y LT I UTENTSO G H","PINESR E TI W ACREPTK R E","GIRDSR A UA T IBLESTS D E","FRANCU P AS P RSALVOY E L","VIRUSI O AAPARTL R YS S R","DRONEE D  PEDALO L  TOYED","SERGEC E BO A BR L ENOSED","CHINK  C EGUILE  N PAEGIS","HOWLSA A TVERSEO M ECASED","FAULTO R ER G NGREEDO S S","WEAVE  M ABLUER  S LIDEAS","PADDYE A OD I UABLERL Y S","LINKSY A LN K UC E GHIDES","CLOAKA V  TEENSC R  HOTLY","VIVIDA I ULOOSEE L LTRAMS","SWIFTT N RO A UPANICS E E","CALMSH I PI K IN E EADDED","PILES  U CDICTA  K LKEYED","GOALSI M PM P EMOLARE E M","MUMMYO O AO O RD S DSEEKS","STINKO S NW L IEVENTD T S","CIGARA H EB O NBASTEY T W","LOWER  A ALILAC  K KRESTS","PERCH  E EDRAKE  M LNOSES","ALONGS P  SLINKE U  TIMID","SEALST M MA I AMOTORP Y T","DRAPE  W NLEAPT  R ECLEAR","VALES  O HPHOTO  S PGLENS","SHEER  X  SOCKS  E  COLIC","SPASM  B IQUAIL  T CFLESH","SULKSW U TA M AN P IS S D","SHUTST L EI C ECREEDK R Y","EQUIPM N AP D STOUGHY E A","TILDER O DE U IE S FSEEDY","UNDERP R IP E PE G EROSIN","TAMEDR A IE S VANKLET S S","LEARNE C ODATUMG E AENDED","STEWSA A EBATEDR E AE N N","DOSEDR W IA U GFUNGIT G T","STORK  B IDWELL  S LMIENS","SHALEU G  LOAMYK P  SEEMS","CHATSA L  NAILSO K  NEEDS","SATYRL I EO L APOLARE S S","ROAMSE N ABEGATU L ISHEEN","FEEDSO T HL H OD E RSIREN","LAMEDI I IMANESB E COASIS","TEETH  X  GAPED  E  SALTY","STOOLH F UALTARR E KPINES","SKIPSL M PE A AEGGEDT E E","DREGS  B A  O LHANDS  Y A","BAGGYR L AI E WSPAWNK M S","MARCHO A AO D LSPICEE O D","CASTER W  E O  SHREWS D  ","MESASE U OW I AENTERD S S","PIKESR N OI O IC L LKILLS","FIENDO A AR T TTHESEH R S","FILCH  O  CHIRP  N  EASEL","SWOON  M  DRIER  T  FUSED","FILTHU O OSUCKSS A TYELPS","DECRYO H  U A  BASICT E  ","VEILS  D IBEING  O HLAMES","SIEGEI L EN A RE T IWHERE","PROWSA I KU L USHEENE D K","ATTARL U IO B PU E ED S R","LIBELO A  W L  LUMPYY Y  ","EXITST D HH O EE L ERISER","VESTSO T OM E OINEPTT R Y","TROOPA V LS A UT L GEASES","TOPICH A HR R AE E SWEDGE","QUILT  C ASCION  N KPAGES","PUDGYR U  I M  COMICE Y  ","VOICEI D  C O  ALLAYR S  ","WORSTR E OI F NN E GGERMS","URBANN A OI N ITAKESS S E","HARES  E I  B G  E NFOLDS","CASESR U TO L RN K AESSAY","JOYED  E IVELDT  P C  S H","AILEDL O EL T UO U CTASTE","CHUCKH S  I A  CIGARK E  ","CLIPSI D NVILLAI E RLODGE","EBONYA P  SCARFE L  LISTS","BELLYU U AX S WOFTENM S S","CHALKH G EUSAGEN P PKEELS","MANIAI O NE S GNIECES S R","GRAVEN F IO I GMARCHE E T","SEATSY U  RIDESU I  PROUD","BLUSHL N OA D RSUITST D E","QUOTEU T RINTERT E ESHRED","STARSC L TO I AR E IE N R","SHEEP U J  R E FLECK S T ","NIECE   A    L FILMY   S ","BACONU  M RILEDN  N TRYST","FLING O I LYING A N PLAYS","KNACKN  R ONIONL  N LOVES","GLEAN O M AGAIN E T  S Y ","TREADO  F ROUTSC  E HEIRS","SWEPT E I REEKS P E  S S ","VINESE  R REARSS  E ELUDE","DOMES Z Q  O U KNEAD E L ","UNSAYR  B GLOBEE  O SALTS","MOLAR T Z SHRUG E R IRKED","PLANE U A SLIME L E ASIDE","TRUSSH  U I  N NOUNSE  Y ","HOLES   M FLOAT   I DALLY","SOARSA  U THESEY  E ROOST","FLAIL E N  M D COMES N X ","EVENT O I  M G NIGHT T T ","BEINGL  O U  V SWEETH  L ","ADAGEU  A G  Z HIREDT  R ","FACESL  A EXERTE  T SIGHS","PRIOR O P  B A BELLS S S ","SLANG   O PLAID   S TRAYS","OTTER U L  R O SNAPS S E ","EXALTL  A UNITSD  E EVERY","PRIEDE  L SPADEO  E SWIRL","CURLSA  A TOADSC  L HAVEN","PESOS X V  U E FLANK T S ","VAUNT L E RIGID B G FISHY","LYNCH   A SNOBS   I BLANK","FETID X C STAID R N MANGO","ROBED   N PORTS   E POURS","SNEER   A CLOGS   L LIVES","RIVALI  C SEERSE  E ROUSE","GLENSL  A O  K O  E MUDDY","IDLER   A WHARF   T BIGHT","CLEFSR  L AMOURN  E KIOSK","DELVEO  A SADLYE  I SANDS","FLANK   A TESTS   T PRAYS","DRILL E U  M T DIVED T S ","CUBIC N D SCALD L E LEADS","STANK H I LYNCH M H SEVEN","COVERH  A ALARMR  N TRYST","CIVICR  S ERASEP  U ELDER","FREER E A ABATE U E USERS","YOKED T A SHIRK E T  R H ","HORNS A E  S E BINDS S Y ","HINTS V I SOAPY R S  Y Y ","AROMAM  A IVORYG  R OBEYS","DOSEDU  X NATALC  C EMITS","GAYERR  N I  E LOOMSL  Y ","STOVEU  O PASTEE  E REEDS","FILLYR  Y ARENAN  C CACHE","TWIRL   A TILTS   I CANOE","DREAM E F ELITE A E EXTRA","MIGHTU  U STALEK  L YEAST","AUTOS   N CURSE   E UNITS","PULSE L O SCION E T PREYS","CLODSA  I SLAGST  I SMOTE","LARCH V E  O D LINEN D D ","VIALS V O  O O AROSE Y E ","SHACK A O  I U FLIRT S T ","DROLL   E FLEAS   P BLUSH","SCRIPH  N U  E TRIPES  T ","GAUZE W E  F B  U R GLOAT","OXIDEU  R N  O CREPTE  S ","SALON V T  O T FINED D R ","UNTIER  D BULLYA  E NEEDS","SCALPP  A A  N SMOKYM  Y ","TONGSE  U M  E PEASEO  S ","DRAFT E A UNITY E E SWISH","SHUTS   R COLIC   B AIDED","AUDITN  N NINNYO  E YEARN","DROWN A I STERN I E MOOSE","CHECKA  U BOARDA  V LACED","GREYS   I EASES   L BENDS","STUNT A A ABOVE O E BOILS","HAZEL F A  F G  I E EXTRA","GRIME E A GAMIN R D  S S ","MOUSE R M  G I HALTS N E ","DOLEDO  B W  O REINSY  Y ","CREAK I T  F T ATTIC S C ","THONGE  A R  S SCRAPE  L ","MOTORE  W DAWNSI  E ABIDE","BRICK E L  I U KNACK S K ","SPORE A E STRAW I L LOAMY","WICKSR  E IDLEDT  L ERASE","BONED V L WARES L C  S T ","WILES   R SHARE   O HOARY","CHAOSA  T LATHSL  E STORK","REBEL   X SCRIP   L BOWER","STAGE   R ALLOY   U CRAPE","BASEDI  X N  U DROLLS  T ","ADORE E O CLOWN T E HANDS","HELMSE  A I  Z RIVETS  S ","MEETS L R VEXES G S  Y S ","SOFAS   V PRIOR   I STUDS","SLAVE U E  N R LARGE R E ","EVILS   A BLACK   K JOUST","CURDSA  I KNOTSE  T SWAYS","AIDES    IDOING    HBLUES","WATCH U  AAGENT H  C T  H","ROLLS R  T B  O I  OSTRAP","OPINEC N AH T TREEVEE R N","SPRAYI E OE P KGEESEE L S","FLAWSR X NIGLOOA E BRISES","NEWER R  UEASEL S  EPESOS","SURGE N  M T  IBIGHT E  S","CLOCKL A NI S OM I BBASIS","SYNODO   ILYRICE   ESLAPS","GNASH O  A V  IREVEL L  S","BLEST    EBORAX    TWHIPS","THESE E  NGLADE L  MSONNY","PLUMB    RFORGO    TCOUCH","LODGEI O LN U FG B IOATEN","SIRENI O ON A ICODESE S Y","EPICS  N A  L F  E EMOTOR","BANDYU   ET   ATRUERE   N","HOPEDO I WA T ARACERY H F","CLAMPO L IPAPALS H LE A S","HURTSU E HN A ECURSEH S N","CANALR A EE T DSLANGT L E","GRILLA D OS Y YPOLKAS L L","LOADS V  TMAMMA L  GASHES","MANGEA O NPAILSL S UE Y E","CADREO O NW U VE G OD H Y","SLEEK I  N K  O E  WASSES","TREAD  L I  B RWRONG  W E","SUAVE    NAVOID    OASKEW","CHIME    LPLUMB    OWIDOW","GEESEU X ASUPERT E NYOLKS","JADEDU O RI S AC E FY S T","BUILDO N UA N MSWEEPT R S","GAZER    ECOBRA    CFILCH","LEVEL B  E B  A E  KIDEAS","DEEMSR X LA E OFIRSTT T H","CRUELI T IN T KCREPEH R N","SMITEH S QR L UU E ABASIL","FURRY S  A H  RREIGN R  S","RAKEDI H USWARME K PRAINY","REPLYO H AU I RSPAWNE L S","PROVER D AORDERW L LSHYLY","LARGOI O XN U IEASEDR E E","CAGESA A TTRUERE Z AREEDY","FERRY    ETIARA    RWANDS","FOAMYO D OADIEUM E NSWUNG","NESTS N  L D  I E  MADAGE","LUNGS S  TVIOLA N  R G  S","LOVED T  I T  CCEASE R  D","TRICEO   BU   OR   NSHAKY","GAUZYO S OWHACKN G ESPEND","STUNG E  O M  N P  NCOPRA","SCARE O  BCLIMB D  EASKED","BEGAN B  EWORDS N  TMYTHS","AGLOWM I ABEVELE E KRIDES","LAGER C  A I  VADAGE S  N","THEFTU L EFIFEST I TSONGS","BIPED N  O E  UWRONG T  H","CLEAR O  URADII M  NDYKES","VAGUEI O BG N OI N NLEAKY","PANIC B  R B  A O  NSTOVE","EXTRAX R NP A IE C MLIEGE","STOREM   AANGSTR   ETAKEN","REACH L  ALOWER P  PDECOY","SPERM E  I A  LCRICK L  Y","CYCLE  R NTEAMS  V UGEESE","SURLYW E OO B KROUGEN S D","TENTSI   HNICHET   ISTALK","INERTD Q OY U ML A ELULLS","WICKS N  EQUASI R  ZPEASE","TOXICW   OI   NR   ELIARS","WHOLER N NE S TSMEART T Y","LYINGO N LB E IBARONY T T","FUNNYL   AALLOWI   NLANES","SIXTHI   OE   UVOTERE   S","TENSEH A RR S ROUTDOW Y R","POLKAU   CRUDERG   IEASED","ADMIT R  HCIRCA E  NCRANK","LUCIDE L UA E NFRANCY N E","SHOWYH   OR   UU   TGULCH","PAPAS D  PRAISE G  C E  K","HABIT  A AMODEM  L EPAYER","MUTED N  ESTUFF I  ELEVER","GIANT N  AADIEU E  NEXIST","TRITEE C LN I VTENSES G S","AROMA O  UDOING K  HISLET","HURLS N  O F  U I  NSTOOD","LAKESA A LK R IE M TSLAGS","FEASTA T EN T XC I TY C S","TRIPE I  S S  SMEDIA S  Y","LIKEN G  O L  O O  KSOUPS","QUOTE N  L T  UFINED L  E","LEECHO P OBROILE C DS H S","BEADYL X IALIVEN O LK M D","GIRDSR O PU M UN A RT N N","PLIED I  O K  N E  OINTER","TRAMPU D ET A LOUGHTR E S","SIGNST O TE A OACTORM S K","CANON L  E B  ERULED M  Y","OPALS  N P  G O  L OWREAK","P M  SPUNKA M  LUMPYM Y  ","A  A DINGYE  R P  E TREED","I W HSHOVEL R AENDEDT Y S","S   SWIDENI   AF   RTRILL","A  D STARTS  A A  M YEAST","S L EPLIEDU S IR T FS S Y","O  H FATEDT  R E  O NOUNS","A  F GABLEI  I N  C GAWKY","T  E HALVEO  A R  D NOSED","I  B DOLLSL  O E  W DRONE","S  H HEWEDI  N ERECTD  E ","O G  FALSEF O  ELBOWR E  ","W  A HEATHI  T MUSICS  C ","A E EMIXEDI A IG C CO T T","S S  PALSYO E  ODDLYR S  ","S U CTIPSYR S CIDEALP T E","E  S VOUCHA  A DRILYE  P ","A  S BOLTSB  O O  O TEMPO","A   IMASONE   AN   NDROVE","T H SWRATHI I OSTRAWT Y N","S G ILURKSI O LM W EYELPS","A T TFLUTEF L NI I EX P T","A O UGAPESA T UT I AEXCEL","A   SDATUMO   IR   TNOOSE","O   FDUNCED   VLODGEY   R","F W RLLAMAU F CM E EERRED","S  I PEONSA  N RULESK  R ","A C OGRANDA L DP L LESSAY","A S IBUCKSO A LD L EERECT","A F LFORTEO I GOPERAT D L","U   SSCIONI   AN   RGUISE","A  A FEELST  O ERRORR  F ","A   ULANDSI   AA   GSLICE","M T PIDEASN S AEXTOLD S M","U  C SIGHTH  A EVERYR  T ","S R  CLANGI I  OWNEDN Y  ","S  A KIOSKI  H RUSEST  S ","A A WSUGARK R IEVENTW E S","A P UBELTSO I AV E GENSUE","P I ULORDSA A UN T AKNELL","I C SSNOUTS C OU O NELATE","S F CNORTHO E IBLEEDS D E","I H  DREAMI L  OILEDT O  ","O D SFRANCT T OEQUIPN M E","E H  LEASTU R  DREGSE M  ","A  B PALESI  R NESTSG  H ","U E SSINEWA V IGROSSE Y H","I K ADRESSE E PA L ES S N","A  A CRASSH  S ELVESS  T ","U Q KSPURNA E OGRUELE E L","A M  CHINSI L  DICESS H  ","S L UHAIRSI N HN G ESCOUR","C I DLINERU U INERVEG E D","A  S DIRTYM  U I  F THEFT","A P YMAIZEE C AN K SD S T","S  S TRAPSI  E FLUNGF  T ","C A  HACKSO T  SNORTE R  ","A Y ADOOMSA U HGENREE G N","S  H PINESI  A NERVEY  Y ","A F CBLUSHA R OTARTSE Y E","O  I FLOSST  L EDGESN  T ","A M SSLACKK M IE M FWHARF","C  O HUNTSE  H ENDEDK  R ","A S CCATERH U UENDEDS Y E","A  A BILGEY  A S  I SLINK","A B MFARCEF I AI D NX E T","S  W PAGESA  L R  C SIGHS","P M AAMENDL R EE I PS T T","D   ARABIDA   OM   RALIKE","S E  HANGSA J  LOOMSL Y  ","A D IBLEEDI T LD E EERROR","S A SWAXENO L AO E PNESTS","A  M DAZEDA  A POLLST  Y ","U   VSERGEA   RG   GELUDE","S F ACORNSE E INOTEDT S E","A O SCIVETT A AO R LROYAL","U  G SHOALH  M ENEMYR  A ","I   SDOGMAY   LLIGHTL   S","M G AOBEYSW N SEXILER E T","S A  HOBBYE A  I T  KNELL","I O ISIZEDS O IU N OEXERT","A  B BURLYU  U SIRENE  S ","A  H FOYERF  A IRATEX  S ","A R VSTONYS O IELFINS S G","S  S LUMPSI  I DRANKE  Y ","A S ABANALO O IU R AT T S","D  S ROBINI  G FOAMST  A ","B  Q IMBUER  I C  R HIRES","A R SSHIRKP D IE E FN S F","A J BSHAPEK D RENEMYD D L","G  E REARSA  R PILOTH  R ","E I  PUDGYO O  CALMSH S  ","A E CCOVEYI A CD D LSIEVE","S P NPROXYA U MSCRIPM S H","S A IPOSTSO K SO E UN W E","A  S SIXTYK  A E  I DRINK","A P SSTRAPS I EE S NTIMED","P  F EDGEDA  R R  R SWAYS","U T SSNEAKH N AEVENTR T E","A F BSTILLS R OERECTS S S"," F R PLIES O V ASHEN S L "," F  SFLEET I  A N  IAGAIN"," C O PATCH S E ATLAS E N "," P H IRKED A A UNITY K S "," M  AVENOM T  P E  LADORE"," B A QUEST L I  K D TYPES"," S C TWIRL I I  S S CHOPS"," Q D FUSES I A  L T ALPHA"," T S TRAPS I A  B N PESKY"," D P GEESE C A RALLY Y M "," T I TORSO O S  L U ASPEN"," K  ALIENS N  P D  EASHEN"," F L BLEAT E N  A C USHER"," Q S QUEEN I I CRAZY E E "," V T MIGHT D I REINS O G "," W  SCIVIC P  ODEFER D  N"," C B BOWLS L O  D W  S S "," H  FBASIL R  A T  TISLES"," C L FLIES E M DRUMS K E "," S H WISER Z A HEAPS D S "," T  SBRISK E  I N  EIDOLS"," H  LPATIO R  C R  KTYPES"," P  TERROR I  A D  PPEALS"," N V DEVIL W O SLYLY Y A "," O  SAMAZE I  VSTORE S  N"," T A PUSSY N K LEVER S W "," L R TIMED C I  K G USING"," P  MGRAVE I  A C  LSKIPS"," R  AGANGS Z  SVOILE R  S"," F  TFUSSY N  PANGLE Y  S"," F  OALOOF O  F O  EFRIAR"," E A MANGY R R UTTER H E "," A  TSHAME E  ERAVEN D  S"," B  RFLUTE O  E C  KSKIES"," J  PFACTS I  AFLAIL S  M"," C S VOICE R O  P R ASHEN"," C  RGRIPE A  E F  VSTYLE"," D  AGRIEF E  IRAZOR M  E"," S M STOOD A D  L E TERMS"," M B CASED R N KETCH S H "," C T COMER M X DENTS T S "," G  ALOBES N  SAGAPE S  T"," U  SBLEST C  URELIC R  K"," C   CLOGS O    U   STUFF"," C A LOTUS R D  K I  S O "," B  FBATHE T  AOCCUR H  S"," D A CRUDE O M SWAIN N T "," S S ELOPE U I  M C SPIED"," P  SMURKY R  NIGLOO E  D"," C  ACOINS P  H S  EMEETS"," C T BLOWN I I SNAGS G S "," F  AREEFS T  S I  EADAPT"," G D COVES O C ADORN Y Y "," S  GSMEAR A  E C  YSKIES"," S D LACED V A FERRY D S "," S B SKULK I E PLANK L D "," P  URINGS K  I E  NUSING"," C W DREAD O T  A E SKIRT"," D  SCOURT L  E L  PISLES"," A  AAFFIX T  L E  ECROPS"," E P TABOO R O SLYLY Y S "," B D TROOP A Z ASPEN S D "," S R BLUES A B KNEEL T L "," P  GWAGON C  OREALM S  E"," S  SSLEET A  O V  OWEIRD"," F  SSLATE Y  EMETER R  S"," S  PSTOLE U  N D  CCYCLE"," E B SPURN I A SCRIP S N "," H A WOODS L O  D R USING"," H  UMIENS L  I L  NEYING"," C   MOSSY M    E   CREAM"," C V CREED I R  M V SEWED"," F M SIZES L D BEFIT S A "," T  ATWIST I  OSCULL E  L"," E B HYDRA I A UNTIE G N "," L A POEMS U O  S N WEDGE"," M U VERSE N H  D E USURP"," F   PONDS I   FLOWS S   "," V  UDIVAN X  I E  OONION"," B  ISEAMS G  LCARVE T  T"," J  CDANDY C  C K  LUSAGE"," B F BUILT C I SKINS S G "," D O PEEPS L T STRIP A C "," D  SQUIET N  AFEVER S  S"," P S PLUMB O A  T L PSALM"," T  SMIGHT G  E H  RSTAIN"," E  INAKED R  LSTYLE H  R"," H  AVEXES R  S D  EASHES"," Q S GUSTS E R BEGAN R W "," R  CFULLY S  N E  I S  C"," R A GOODS P M DEVIL S T "," P  HCABLE N  ASTOUT S  S"," R  WWINCH V  IMEETS N  K"," S H LEMON N T ODDLY S Y "," W I PARSE I L ASHES T T "," A S SMITH I O AGING O Y "," B I LLAMA O A  N G EDGED"," A S BLINK T E METER R R "," P  SBIRTH L  IGLIDE S  D"," P I GHOST I L  A E FLESH","T T DHORDEE E BS E AELDER","S S  CLICKR Z  ITEMSP D  ","W H  HEARSI V  CLERKH N  ","S W  HEELSY N  LICKSY H  ","G I ALASTSI L HD E EEASES","  C SDEALT  N ATROUT  E E","S H ATOYEDI E ER N PSMART","S S UTAPESI O ER O RSERFS","O S YPRIMEI G AUSHERM T S","U A FLEMMET B NR E CAGREE","B L  OVARYS T  OPERAM R  ","C A IRISENU H EM E RBESET","A S IBIPEDA E LCEASEK K R","  I UMOCKS  I EFINER  G S","E S SDEPOTI I ACANDYT S S","  L FPRIZE  N I  E NUPSET","W S AARMEDL I DLITHES H D","  F PGIRLS  O AMETAL  H M","B S  ENTRYR A  GILLSS K  ","  S UPATHS  E EMOWER  S S","F E BLIVERA O EW K ASPEAK","D B LATONER M NEBBEDS S S","S S APATESE U KLANCEL G D","Q S SUNTIEI R IL A ZT W E","  E GLABEL  B O  E VJUDGE","A E FBASALY S AS A KSLYLY","  A AAIDES  M S  I APUTTY","S P SMIRTHE O AA V DREEVE","A D BFLARET I RESSAYR Y L","S U CMISERA U ISERUMH P E","  B TFOLLY  A P  C ELIKES","  F SBRINK  V UWHEEL  S L","D E GRIVALO I AOILEDP S E","C A UOOZESU U HCARVEH E R","  S PFEELS  W ADWELL  R M","E F ADRUMSI Z KC Z ETOYED","A S IWALKSO A SK V UE E E","  S ROUTDO  A AWAFER  F S","A S ISOCKSH E LE N ESEEDS","S S CTOWELA A OLINEDE S S","S F OPROOFI R FT C ESPEAR","S S HPETTYR O DIDLERG E A","  A  CURES  S  BOOBY  N  ","A T SGAUNTR T OE O REERIE","S E  WAXENI I  N S  GOTTA","S S DMONEYA E KSTATEH K S","A E ABULBSA E KC G EKEYED","O Q PFEUDST I AEXCELN K M","  B WTOUCH  R OHARES  S E","  K YDENSE  O ADUCTS  K T","  F  BALMY  A  HANGS  K  ","T B UWIRESI I ESOBERT E S","A G ISQUADK I OE S LDRESS","T S EROPEDA O IM R FPETTY","Y A  ANGRYC E  HANDYT T  ","  N HQUERY  W EOCEAN  R A","R E AEDGEDA G ML E IMIDST","  L DKNAVE  N B  D TMISTS","  T PCURES  U AVENAL  K M","A P TBRIERO E UU R LTESTY","  S  BANDY  I    P  CLEAR","A L USWAINI M CD E UE S T","  F UFORDS  U E  I RVOTES","D U CESSAYV U NI A ILILAC","S A FTIGERA I ITILLSE E K","  L EBEAMS  B S  E ABILLY","  S SBREAK  I IGAZER  E T","  H ESCOLD  R GJUDGE  E S","A A  FIFESI F  RAILSE X  ","F S BIMPELL A AMISERY M E","  S  CITES  A  SMIRK  N  ","A S MBELLEI I RD N GE K E","S A HTODAYE D EE E ND D A","  A SVIGIL  E ITUNIC  T K","B O  ELVESI E  N R  GOTTA","  S CAPTLY  A C  I LVERGE","P M KSLAINH N AA I CWRACK","  A CBUGGY  A CLAPEL  E E","S B BPURSEA I RSUNNYM Y L","I K SSMIRKL L IE L MTESTS","I M SSWIRLL N AE C STEETH","S M ACRUSTO S OR I MNECKS","E A GBEGINB A AE P TDUELS","A M LSHOVES O EA R KY S S","  D ACOINS  V KCRAZE  N W","A S ASATYRI A ODUCTSE K E","S G LTHOSEU D MN L MTHYME","A O PFOWLSO N HO E ATHROW","  M YSPINE  L ASALTS  S T","  A IWOMAN  P ATALON  E E","G G AOWNEDN A AG T GS S E","  L PSHAMS  R AFOCAL  H M","S F STALLYO A RR W UE S P","T I DWAGERE L AE O ND O K","A J IBOONSO I LVENUEE S T","U C SSTACKA N IG N FE Y F","A C UFLUESO F AO F GTASTE","A C  SORRYH A  ESSAYS H  ","I P TSHIREL L XE E TTUSKS","S M ACLIFFU N ILATERL S E"," F L SUGAR N M  G E KINDA","S  S WANTSU  E N  R GLINT"," T H TRAYS I M GAINS D S "," V S MONKS W I HELPS L S "," E H ALOUD D M  E P CRISP"," G O JAILS T D  E E USERS"," C S PORCH P E  S N PESTS"," D E DEIGN L G  T E WANDS"," R F MEALY S O LEVEE T S ","O  A PARSEE  S NICERS  S ","S  O CHUCKO  E OCEANP  N "," L S WASTE C I TELLS S E "," W I THANK E G TALON T T "," R W FAIRY Z I  E T ADIEU"," M F LEVEL S L LADLE S S "," A A EDIFY A T  G E GEARS"," P H TAXED G A  A T GNASH","E  S THYMEH  A I  L COOLS","   B SIDES   A    R AMASS"," A O JUNTA D H  I E GOURD"," E S SMOKY A I  I P CLASP"," O D SPARE E E  R A BARDS","   C SPARE   O    P JOUST"," B E FARMS Y I  O T FUSSY"," R T BASER B R  B M TIPSY"," G A CRUMB O P  U L UPPER","E  A DICTAG  T E  A DOWRY","S  S HASTYO  A U  R TENSE"," S V SHEEN E S  D T  S S ","A  S BASALI  I D  N EMITS"," D S RISER C E  T M FALSE"," C O CRAZY E O  D N BORED"," A D QUEER D P  I T MOTHS"," F A TORSO R H  G E BOONS"," T W SHEAF U I  M V ABBEY"," S S QUOTA G A JAILS R K ","S  M TREATA  X BASICS  M "," A S ELITE L O CAIRN Y Y ","O  Y PATESE  A NEARSS  S "," P O FIEFS O F QUEER S R "," C F MANLY M E  E A ROUSE","I  D DOWRYE  I ALOFTL  T ","D  A READSA  O W  P LIFTS"," N M REPAY V T TEACH R H "," B H DUCAT R R TRAMS S S ","T  S ROCKSU  U L  N YOLKS"," F K TOWNS R O  G W HOUSE","A  D MOTESO  E N  M GRIST","A  A PUDGYA  A C  T ENDED"," S P JADED N S IDIOM Y S "," L C NICHE A O GRASP S E ","A  E CANDYH  G E  E DENSE","A  D SPEEDH  A E  T NICHE"," H S COOKS B I  B P  Y S ","   U FLASH   I    N JUDGE"," B S WAKEN S W  I E ASIDE","A  A BRIDEO  O U  P TEETH","A  C TIGHTO  O M  K SAVES","A  S SLYLYH  A E  B SLASH","   A DEIGN   I SHALE   E "," D S TERMS F A YEARN R T "," T S DUSKY S U SKUNK S K "," C T FAIRY V O NESTS S H "," H S PEACH L O  P P ASKEW"," W S BRICK E A SCANT K S "," B S TRIPS U O  N I STYLE"," A G SNEER I N  M T CEASE"," F E BEANS T J PIVOT D Y "," T S HOOPS P U YAWNS Z K ","U  F SPORTI  E NOISYG  H "," D S MOUND N O  O W TRASH"," A D IDLER O E SPADE T S "," B O TEAMS R I AGATE S S "," D W FRAIL A N AWOKE N S "," V F YIELD D U  E E NOISY","C  C ABBOTC  A HURLSE  S ","S  D MINESE  C ACTORR  Y ","A  K BASISA  N TOADSE  S ","G  U LOINSO  C A  L TOKEN"," B T REGAL V P SEWER L S ","O  C BEARSE  A Y  C SUCKS","A  O WROTEA  H IRKEDT  R "," B D HIRED R M  T O CHINA","   P CEASE   H    A AVOWS","S  S EXITSR  A U  L MISER"," C U SHINS E C SCOLD K E "," F F GAILY L O  S O REEDS"," L R DIKES M C  B U COPRA","O  B FAULTT  E EAGERN  D "," H A LASSO I S BRIEF S S ","S  M TENORA  U G  T EIGHT"," H A SINCE R U TENTH D E ","S  A KILLSI  A F  R FOAMY"," C S CANTO N A STIFF O F ","F  H OTHERR  A CARVEE  E "," N A HOUND V K  E L BLEED"," A B ABHOR A X  S E GEESE","S  A TRUSTA  S T  E ELITE","S  S CREPEO  U P  N EVOKE"," D U CRISP I E SPIRE S S ","A S GPIQUET U AL A RYAWNS","S D ITREADA E EMAMMAP S L"," P  LNOISY P  R P  ICYNIC","F S AJOKEDO I ORIPERD S N","R C SADOPTN A EG S REATEN","U S BSPILLH G OETHICR T K"," U  VSNIPE T  NVILLA L  L"," A  IOBEYS O  SADIEU E  E","S L SWRISTE A AA R GTASTE","D O BAWFULM F APOEMSS R T"," S  SSKUNK I  IBRAWN T  S","E G ULORDSB O EO W RWILLS","  Q ADAUBS  I K  L EAGLOW"," V  AHEADS N  H T  EISLES","A G UMULESI O HGABLEO E R","  H CGAYER  D E  R PAWAIT"," H  ILIFTS N  L T  EASHES","  A CGAMMA  I P  G OSHORN","C S ALICKSE E KF N ESPEND","A N HGOODYI V MN E NGALLS","  S ICOTES  A S  R UUNTIE","T R UWEEDSI C IN U NSHRUG","U   ASTREWA   AG   RELITE","I P SSTARKS R UUNTILE S L","S C ATILEDI I DLEMMEL B D"," Y  IHOWLS K  L E  EIDOLS","P   PSWEARA   IL   DMAPLE","S L ACLODSO S KU E ETHREW","A S PSEWERK A IE R VDUMPY","M L AIDEASN G HE A ERULES","F W ULIARSA I IG T NS S G","I   IDATUME   BA   USPAKE"," S  PTARTS U  H C  ARENEW","A C NTEASET S II E GC S H","  N USCANS  S USATYR  Y P"," T  PHOLDS D  HPARKA Y  W","S S OMUTEDE R IADIEUR P M"," A  CSWILL A  IFROWN E  G","P S REXILEA E SL G ESLEET"," S  SSMOCK E  I L  FSTIFF","S F STRUTHU N AN G KGUISE","S O PTRACEA K OM E NPINKS"," S  AMAILS V  SBELLE S  S"," A  SAGAPE E  I N  ZSTILE","S   APIPESU   SR   ETRIPS","U D LSTEELU L AALARML Y A","  F ESALON  I VCANTO  G Y","  M CCOACH  I E  L SUPSET","S A COLDERA M APOINTY T E","F N BJUICEO C FR H IDWELT","A B SSNOUTS M UEBBEDS S Y","F S NLOWLYO E MO E PDEPTH"," P  PQUELL P  A I  NCLINK","L K EANNEXI O ER B RS S T","  C CGUANO  N UCLAMP  L S","S S AHOPEDO I MP E IS D T","  E IFADED  I O  C LLATHS","S E PNAVELO A IBUDGES E D","  G MVERVE  A WAMPLE  E D","  U BGENRE  D G  E AHERON"," C  ATYPED C  IBLAZE E  U","  U JDENSE  F RWHISK  T S"," S  SSKIRT A  OSTOOP E  S","S S STITLEA O AGROOME D S"," T  EYELLS N  SMOMMA R  Y","E S HDECOYG O DE W RDELTA","E O ADOTEDI T OCHEAPT R T"," F  EHOURS R  S G  AMONEY"," R  ADINES N  HUSAGE E  N","O   WTABOOT   UE   LRAGED","S A AHOSTSO H KPIECES S D"," B  AURGES O  KLADLE D  D","A B HBEADYA S EC E NKARMA","A T ABRINGB A IE R LY A E","P M TSCALYA N IL L NM Y G"," F  UCLEWS O  H R  EGAYER","  T NSCOPE  W AINNER  S S","A O LFIFTYF F NI E CX R H","B B MLEAKYE S TA I HTELLS","A C MSHOVEH M NE I DNECKS"," S  AHALTS L  P V  EBEGUN"," F  LTODDY R  R D  I S  C","E P FDWELLG A AE K WS S S","S L APROOFI C FKHAKIE L X"," V  SLOGIN G  ACUBIC E  K"," T  DGROPE A  N I  SCLOVE"," G  SFROST U  A E  NFLASK","F   UOATHSR   IM   NSWUNG","S D ATWIGSO A HVERSEE Y N","W D DROUGEI C EN A DGULFS"," G  DVAGUE I  CKNACK S  S","  L SFRISK  M U  B NSHOOK","R N RALIVEK C SE H TSEEMS","T B SWROTHI X ISTERNT D E","A S SSALTYK O RE P UWHELP","  S MABATE  T A  I LPONDS","S   LPUFFYI   NTOPICE   H","  F DSNORE  R M  M UBASER","  T SGIANT  K I  E LCANAL","M B IIDEASX A SE R UDODGE","VERBSA  E PURGEI  I DOING","VERSEO  W LATERT  L SABLE","CAUSEI  E VENALI  M LASSO","CODESA  V SEWEDK  R SLAYS","FAUNAL   DASKEDT   ESALAD","PANELA  D TWIGSH  E SENSE","RUDERU E  PALMYE T  EXALT","W R PA U OFILLST E SS S E","HANDSO  I BOOTSB  C YACHT","REPLYE  A SNAKYE  E TIPSY","POSSEO   MSWAMPS   TEDIFY","PSALMA L APUPILA H ESOARS","PRUNES  E HELIXA  G WIGHT","SOARSE  U ATTICT  N SENSE","TONEDO   OWIDOWE   NRACES","LEAPTE B UDRAMSG F KE T S","CREDOO  R COMICO  V AGREE","TAMEDE   WSNORET   LSTILL","I H FN O ADAREDE N EX S D","N B ME R UREALSV T EEASES","ANTESS  L HAVOCE  P NAKED","PICKSI    POEMSE    RIGID","RIGHTI  I VEILSE  L TEASE","ASSAYB  D HAVOCO  P RIOTS","AUTOSS    HERDSE    NATAL","BASERU M ECHAFEK R DSITES","ADOPTS   OSQUATE   ASTILL","NICERO  V VIPERE  R L  Y ","CLIFFA  R VOCALE  U SANDS","DEIGNU  L MOTORP  V STEED","CHILDU N ORACESV U EEARLS","GORSER  H AGREEP  E EBONY","JOINTU   HDUSKYG   MERASE","NYMPHO    BOOMSL    YOUTH","WHITEI  R TYPEDT  A YOUTH","RACERI R OSPERME E AN P N","PLATEU  I FLAREF  E YARDS","HUMANE  S DENSEG  E EMITS","L T OU W PCRAVEI N RDOGMA","SEEDYA    GOODYE    STARK","OWNERA   AKEYEDE   IN   O","ICINGN N UFOCUSE U TRARES","LYRICA    CLEFTE    SPILL","BURLYU    SMELTH    YOKES","POISEI M  PUPILE E  SALVE","F V AI E DFIXEDE E ESIDED","H O RE A IDOSESG I KEASES","POKESO H  STALLE K  SHIRK","MIENSU  A SHAVEI  E CRUST","G S MI M IPIERSS L TYOLKS","B S VO O AROUTSE P EDOSES","LENDSL  A APPLYM  L A  Y ","EXITSN  A SMASHU  K ERASE","DUPEDR    ALLEYK    ETHER","DADDYO  O MUMMYE  E DRESS","FEEDSO  E CHEFSU  E SHARE","E S OS A USPLITA S EY A R","J  A A  M DRAPEE  L D  Y ","N   PO   OMIXESA   TDEARS","T F AI R SCOALSK I ESPLIT","USHERR   EBUGLEA   VNIECE","BORESU A  LARKSL E  Y S  ","R B UO L NBOOSTE W IDANCE","VISITA C EPAUSEI L MDELLS","G Q FR U UOMITSU T EPESTS","GAUGEU   NSEEMST   USCARE","APARTZ U UURGESR E KEARNS","REEDSA    BERRYB    ICING","GRASPA G ESTIRSP N TSIGHS","S C TH O HATONEF L STASTE","LOWEDI   ACEDARK   ESTOOD","T P LI A ULILACE S KDRYLY","B L MA A OSTINTE R ERUSES","HEATSI  H DUNESE  R SEVEN","ABACKR  H GAZESU  C EVOKE","B C MR A IOLDENK E EE T S","T L UH A NYACHTM K IENSUE","PLAZAI W DQUALMU R IELECT","WHISKA   ISCORNP   GSOLES","DEALTA T ELOTUSL A TYARDS","B P LU A OSUNNYT G AS S L","TARTSA E IBLANDO L EO S D","H F MO A ABRICKB R EY S R","DOUGHA  A WHIPSN  E SMASH","G O VR A IANTICS E ESENDS","COMICO   ABRAGSR   KAIDES","MASTSU  A SLICKI  I CENTS","RACESO  A BARGEE  L SHEEN","LAMPSO A UOTTERN C LS H Y","E   FV   IEQUALR   TYOUTH","TOTALY  V POSESE  R DICTA","PARRYO O  STUMPE T  REEDY","U T PD A ADARESE T TR S E","RIFTSA I  GASESE H  DRYLY","V M EA O SSELLSE A ASURLY","DEPOTE  B FIVESE  Y RAISE","BRASSR  A ACUTEW  E NEEDS","CANOEI  D GOODSA  E ROARS","AWOKES  N HAVOCE  W NOOSE","M S UO U NTUNEDH N IS Y D","AGATE R  ADATES F  ESTEWS","SMASH O  ODUETS S  TBEARS","SOLAR C  USHEEP R  EPEACE"," B G  O L POKES T N  S S ","CRANE O  AROOMS K  EUSUAL"," A  V C  OTHREW E  EIDYLL","USURP A  ACLOWN E  SASSAY"," B  A O  EOWING L  IASSES"," S B  T A TOUCH I O SCENE","SCANS A   FLARE L   USING"," S  A L  DFETID P  ESTAIR","ABLER A  OFLAGS E  EISLES","RENEW Y  AHIRES N  TAGAPE"," G A  O L GOATS S E ZEBRA"," S P  T I COULD V O DEPTH","CHOIR I N DRYLY E E  S T "," S  B A  AABHOR L  DLEEKS","ISLES H  PVIGIL R  ISTUNT","VICAR S P SLIPS E A STALL"," S P  M A PAWNS C G  K S ","ABLER A  ESCALE K  VISSUE","GLINT A  IDRAFT K  LUSAGE","SPOTS R   VAULT N   SKIRT","ACUTE H  ADUCTS M  EOPALS"," S C  P Y LANCE C L FEWER","DWARF E  OFEWER P  T S  H","FLASH I  USKIMS E  KDROSS","AFTER L   GUILT F   AFFIX","THIGH E  EFLUID P  GISSUE"," Q B  U L VALET F E  F D "," D T  U I SPECK E K  D S ","EGGED L  UTOADS A  TSTUDY","TEASE D   SIDED F   SYRUP","ISSUE H  NDEEDS E  USPACE","AGENT I O CLANG D C ASHEN"," S P  P I DELVE R O OMITS","ADIEU O   PITHY N   AGLOW"," F  M R  OBOAST S  ISTAFF","ARRAY A   FILCH L   ASIDE","ISLET T V ZONES N N DELTA"," G  M L  ADOCKS A  KSTEPS","BARBS G R TIRED N E  G D ","SKIRT N   FIXED T   PSHAW"," S  H H  ATOMES O  TGNOME","SCOLD R I PAYED T G SEWED","ABIDE E W RIPEN N L AGILE","SPICE A   PLAIN E   TRAMP","ADDED E X FETCH D E PSALM","SLATS O  YSCION A  OGLAND","STORM O  ESTEMS A  AFLIES","AMEND E  RIRONY G  LBERRY","STAFF H  OGRIMY O  ELEPER","RELIC T  OSHOOT I  EACIDS","CHEST I M ALOES L L  S T "," B  G I  USPILL E  LIDOLS","EGGED R  OLACKS D  EREELS","AGLOW R B QUEEN N S STEEL","ADOBE R U CYNIC L L  Y D ","OLDER Y N BRIDE I O SCOWL"," V  U I  NGORED L  EMANOR","ABAFT U I FLEES K F  S S ","WROTH I   SPENT E   CRIBS"," S T  C H NAVES L I DECRY"," G  P I  RALIVE D  SISLES","CHILD E U HARMS T P GHOST","STUNT O  OPADDY S  ESTAND","SQUAW U U CANDY L I AMITY","FALSE W W LOGIN K F CENTS","SCRUB O  RFUNGI N  ESTEER","SIEVE V I DOUGH R I CYCLE","SLAVE A I SCENT K E  S S ","AFIRE U  ACREWS R  ETYPED","ACUTE L I HURLS C E  K S "," B  G E  UWEDGE T  SUSERS"," A  B C  UTODAY R  EINTER","SWARM H  UPATHS L  ENESTS","SCARE A U ANGRY E A PSALM","ADOBE E  LKEYED P  EUSHER","AGILE R U TEAMS E P  N Y ","ABIDE E W ALOES I L BERTH","LLAMA O  CTOOTH N  EISLES","SCORN L  ISEVEN A  NGRIMY","ISSUE T N HANDS I U TREES","ROAST T  ASHARK E  EGRAIN","USERS H   JOINS R   STING"," B  G R  UGATES C  TLEAKS"," D D  R E VERBS A T AMASS","SCENT L   PALES S   SHACK","ASKED T  RMEDIA E  PADORE","SPITE O   CRICK T   USING"," N J  E O AWOKE L E  Y D ","AGAIN L N CASTS Z E PEARS"," B  O A  LPILED T  EUSHER","ALTER E  ESPOOL E  AGRAVY"," F G  O E SINEW L S ASKED","UPSET L A TEARS A N  S S ","HAPPY C A START O K TREAT","OFFER L   FARES P   ASKEW"," S C  I L UTTER E A USING","EBBED I  AABOUT L  ESEALS","FUMESA I OCOLICE L KDESKS","S L CP A AEASESN S TDOORS","UNDER  E AGUMMY  O OLINEN","SORESA O IBEGUNR U EE E W","E Y AT O SHAULSI R ECASES","OCCUR  A  LASTS  K  HASTE","LIFTSO L AFRIEDT N LY G Y","VILLA  O NSMOCK  S LGEESE","SURERI O  NASALE I  WENCH","ANGRYF A  FAULTI Z  X Y  ","B T FR O LAPPLEV A SE Z H","MEALSO I TDEMURE E ASADLY","N T VA A IKICKSE I ODETER","N T AO E PSWEEPE T LD H Y","R H FO O UBOWLSE L SS S Y","ENTRY  I  GONGS  T  LASTS","CORKSA O PTOWERC D EH Y E","COPRAO I SCONESO T AAGONY","ROBES  E  PERCH  R  PAYED","ATTICM I  PREYSL R  ESSAY","S I PU N ALUNARL E TY R Y","VENUEO A NTITLEE T MSHYLY","M S EE H LTRIBEE P GRISKY","SHOWS  R ALIGHT  A YMANOR","WOMAN  U  DOMED  P  BOSOM","F T FU E USTARSE R ES S S","J E OI X LFATEDF R EY A R","MUSIC  T RSHARE  R SVISIT","T G CI R OGUANOH S ETEPID","INFERM R EBOOMSU Z EERECT","AMBERP U IACRIDR N ETUSKS","BUTTS  R  CHASM  I  BITES","P S CO U LUNITEN T WDISCS","AWFULM R  BROOKL T  ETHIC","MADAME I AARMEDN L AS Y M","E C SR O OROVERO E RRISKY","LATHEU W  SPELLT E  SADLY","G F CL L HALIKER R CE T K","MEDAL  U EMAMMA  P KGAYLY","DEBARU O ACLOUDK R IS S O","LOBESA R TPRONEE W MLINES","BASIL  L  CHAFE  G  PESKY","CLAPSA N LBUGLEA S EL T T","FASTSA P  BEARSL N  E K  ","APPLEL O STONESA D ARISKY","RIFTSE O PFORGOE A OROYAL","BELLYA U  SERFSI E  CASTS","SPRIGA O UCHUTEK S SSPENT","ASSET  T WBRACE  R ECAKED","BEECHU L  GNOMEG P  YIELD","YIELD  M UPIPES  T KGAYLY","ZEBRA  L BTRULY  E SEASES","CABBY  U  HATCH  T  LOSES","OLDENV A  ENDOWR D  TRYST","SALTSH I AREVELE I SD D A","S V PT E OAGREEI S MREEFS","R P TE O EBEETSE T TLASTS","D P MO U ATUFTSE F KS S S","MACESO H ADRIFTE M YSPEAR","COUPSA R CLAGERY E AX S P","FACESU H WSPINEE P ES S T","FRIAR  V OHOOPS  R EABYSS","A Q MP U EPEONSA T ALEEKS","SECTS  O  HUMUS  B  LOSES","RISENE P OCHATSU N ERAKED","D B HO U UDOTESG T SESSAY","RIFTSE L EAHEADC C ATAKEN","BUYERO O  SOLIDO K  MUSED","R R FO A OPAYERE O TSONGS","RADII  I  SINEW  E  BERTH","I P MN U ODOMEDE P EX S M","LASSO  H BSTALE  R YPIPES","E R TA E WRUPEET E EHALED","BEAKSA B  SPARSI S  CHEFS","DOGMAR O UAGAINW D TNOSES","NEVERU I EDIVESG I IE D N","ASPENN A OGALLSS E ETIDES","WIDER  R ABUILD  E ITORSO","REEVEU L  POUCHE D  ELEGY","ALTERB O EHENCEO E DRISKY","TITHE  O NGAPED  A EDOZED","SOCKS  L ICROWD  G EEASED","SIGHS  R  DRUNK  F  PUFFY","LIMBSA A  TENETH I  SMASH","ARSONB L ABUILTE N TY G Y","MUSIC  I OFOXES  E TDISKS","DUSTYE W  SHOONK R  SANDY","EXCELA A AREMITL E HY O S","FUSESJ I  OOZESR E  DUSTY","INFER  R  FLAME  I  FILED","YEARSA M OCOBRAH L RTEENS","BUGLEA R  SNARLE T  STEEP","COMETO A ALOGESO I TNICHE","NOSED  C IGROAN  L EENDED","JEWELI O UFROWNF D AY Y R","D G VO R ITRAINE T ESEEDS","UNCUTR R EGNATSE W TSILKY","A G ML E ALANKYO U BY S E","  G K  I EHEDGE  D PABYSS","LOVER  I ALUNAR  E ELOSER","TEETHA  O KICKSE  E NINNY","OUNCEA  A SOUPSE  E SPERM","CLEFS O R POKER K E  S S ","SCOWL H A COLIC I V DRIES","STUDS O A SPUNK A C  Z E ","ROUSEI  A DIRTYE  I RAINS","DAISY R N COMER M E HAIRS","ALIBI   U EMITS   T GLASS","ERASEL  W FELONI  R NAKED","TIGHT   O SALTS   L TRAYS","WALLS M E FANGS Z A DEALS","TIARAA  A CHIDEK  I SPOON"," M M  A E WRING T D  S S ","MUSTYO  H TOTEME  S SATED","BEFITA  N NATTYD  E YEARN","PUTTY S E FADES G M YEAST"," S P  M I TOYED T R LEASE","CRAFT   I STAFF   T BUSHY","BLUSHU  P CEDARK  R SOCKS","PSALM U O BROWN E L PREYS","LYINGE  A PALMYE  E ROUSE","WELCH   E HORDE   E GOODS","SKIFFH  E RIOTSU  I BANDS","CLEAN O L PULLS S E BERYL","REPEL   A GRASP   E VIOLA","MEATSA  U GLENSI  I CRICK"," R H  A I NINNY S T LEAST","EDIFYX  R CARESE  S LITHE","CLASPI  C TWIRLE  U DOUBT","FORUMO  N RESINM  T SWISH","OBESE O T AWFUL E D PRAYS","INEPT   A WHINE   G ARISE","FUNDSO  U WHOSEL  K SWAYS","AFTERS  L HANDYE  E SHORE","BRICKA  H BAREDE  E SWARM","CRIMPA  U NOOSEO  T N  Y ","FACTS I U WRONG E E  D D ","STUDY   U AISLE   L OBEYS","BULLSO  I DUMMYE  B DROSS","WIVES M A HALTS G E REINS","LEAVEO  I GUIDEI  E CROOK"," Z S  E T ABHOR R L CAKED","SHADEE  R RELICV  F ELATE","IDIOM R B FINED P S ASSET","LEAFY M U CATER I L BLAST","CROAKA  M PROPSE  L SATYR","D  H I  E SILLYK  M SALSA"," S S  T H CAPON N R SKIES","WRAPT   U SKINS   C BATHE","RUINS R A DIETS N A SEALS","TENTSH  O YELPSM  A E  Z ","SHAKEL  I ALONGY  D SLASH","MINTS T H SEXES M I USURP"," S M  M U EARTH L E GLADE","GLOWS O E HONEY P K  S S ","CUFFS   I GLINT   E NOOSE","CHAFFL  I ANKLES  E SALTY","DOCKSI  A CHORDE  M DREAM","YARDS   O SKIES   R COPSE","CABAL G S FRESH E A BERYL","HAIRS G A TRUCE E E BEAST","EVILST  A HINTSE  E REARS","SHEENO  X BOOTSE  R RURAL","DAUBS M I FOLDS U E FROST","LATHE   I FULLY   T OBESE","SPITE R R LIMES C E HEADY","DICTAR  U ALOFTK  T EXIST","BAKED L A SPASM H E BANDS","LAIRS L I TABLE R E  M D ","BLOWS A I STOPS E E TRADE","SPASM U I CRAZY S E READY","M  Q U  U RACESA  S LASTS","CLICKA  A GAUGEE  E DANDY","HOBBYI  U VOLTSE  T SPREE","REEFS   L VANES   E GOATS","OATHSF  O FORTHE  L R  Y ","GRAFT E E HEATH K C  S H ","WEEPS T U SHIPS I I SCALP","MOISTU  H DRIEDD  A YEARN","BLUFF A U BRINE G D GEESE","POUCH T O SHOPS E R DREAD","KNITS   U ALIBI   E GIPSY","VOUCHO  R MUTEDI  W TIPSY","HUSSY   E BLOWN   E EXERT","STATE H R FIVES R E  D S ","U  F N  U DRAMAU  E ELUDE","VIEWS G A PLAIT O T LOOSE","BOGGYA  O CHUNKO  N NATAL","AGREE R A PASTY C E JEERS","FAULT   A SNORT   V VICAR","RURALA  T BUTTEI  I DISCS"," P B  I O SNOWY K E ASIDE","AGATE R A SALSA D T LEVER","LOOSEI  A BULLYE  V LEMON","MOURN C E LEVEE A D  N Y ","SHOWY O A TOXIC F T  S S ","YACHT   O BERRY   N SLAYS","VICESI  E SOARSI  I TREES","RUSESA  J COVEYE  C ROUTE"," R J  I O SMOKE E E  S S ","L C FO O ECOUNTK N USITES","GUANOA G AWORDSK E EY E S"," B  A O  BFILTH L  OUSHER","FOCALA R OSQUATT E USELLS","BLUFFE   AROVERG   MSEATS","SCARF A  IGROAN G  DPOOLS","L E MI X ICATERK R TSMASH","R F UI L NSMELTE E INATAL"," R  V E  AFATAL D  VCYCLE","OOZESI   HLOAMYE   LDEITY","SCRUBU A EPOLKAE L UR Y X","PRISME   ONEVERA   ELIFTS","EDIFY R  ATAMER M  NASHES","ASSES U  ODRILL E  VGROPE"," P  B S  ACHINK A  ESWARD"," C  C U  IWRIST L  EDYKES","ABBOTD   ODOMEDE   DDAILY","  O J  P UREALM  L PFUSES","O C FR L UGLENSA F ENOSED","D L GE I APINTSO E PTUNES","F C VA R IDIETSE D ISCOUT","R C BO H ABOUTSE M IS S C","SEEKSN   IAGINGG   HSQUAT","WATCHI R OSTUNTE C LREEDY","GLEAMU A OMETEDM E EY N M"," E  P M  ISPINE T  CCYCLE","ISLET I  OGLEAN L  ICYNIC","S S FT N UAWARDG I GSALVE","CAVILH I AUPSETR T CN A H","STRAPA   ATREESY   TREADY","REALME L AALOESC F OT T N"," Q  C U  OBOARS T  TFACTS"," S  C O  AGLAND I  EEDICT","H   PA   ERULESS   THILLS","USHER A  AINEPT D  I S  O","FRUIT A  RBLADE L  ATYPED","SCALD A  OBRIMS T  EASKED","N C DE H YSTACKT M ES P S","EXITST   HHEADYI   LCARRY"," S  A H  LBEAST L  OBLOWS"," F  K L  EROCKY U  EGREED","PILLS N  TALLEY E  LSTOLE","HATED  O RDRAKE  D ABASED","CHARM O  ILOCAL T  LISLES","REBELI E OFORTST Y ESOLAR","PSALM T  UDAMPS R  ESKIES","TUNIC  O ALENDS  C ETIERS","L M IO U SBASILE I ESUCKS"," P  B R  ACUFFS D  ESEWER","READSE Z IFLUKEI R VTHERE","B P WA L ISWARDE N ER K N","VODKA  O LLOVED  E EMISER","ADORE O  AMOUNT M  EUSHER"," B  H L  UGAINS S  KSTAGS","USERS H  HPASTE L  AATTAR","SPRIG I  OSQUAD U  LSEAMY"," D  J E  OBLACK V  EHERDS","SAGES  A HUNTIE  E AVISOR","INFER    ESHAME    VTRICE","TOTEM  R AWHACK  I EGALES","O D MC W UHEELSR L KE L Y","L P JO I UBEGINE M TS Y A","R C UO A SPATCHE C ED H R","A C SC R LHEADYE S LDUSTY","ACHED L  UNOOKS T  KSHADY","STAIR    OSPARS    EDOOMS","START    OVIZOR    SCANTO","G   BA   ASNAGSP   ASCULL","LEVELE   AEASESK   SSALVO","N   VO   IBOWLSL   IYACHT","MOTIF P  ESTART I  USCARS","INURED   TEARTHA   ELEVER","UNCUTL R ATHUMPR S EACHES","T S TA Y OSCREWT U EY P R","BATCHO H AGIRLSU O TSIEVE","CLAIM    EBARED    IULTRA","DEPOTE E OTALLYE T ER S D","R N LI A USAVESE A TSALTY","RACKSA A LZEBRAO I NR N G","O H IP U NTASTEI K PCRYPT"," P  Q I  UUNDUE T  ECOZEN","ALOOFL Z EBROILU N LMEETS","RABID  I RBALMY  G LQUERY","H B DU O OMOONSU M ES S D"," B  O L  UBEFIT N  EUDDER","ABBOT U  EISLES T  TESSAY"," F  S A  EFINER N  GSTOLE","S S ST I CINTERL E AE S P","PLUMB  S OCHAIN  G NELEGY","ISLET A  OUTTER Y  CCRASH","BUXOM S  ACHESS E  OGREEN","TWISTY   APRICKE   EDALES","S E BT S RAISLEK A AE Y K","AFOOT L  OSULKY E  EASKED","SHRUB E  ABARBS D  I S  C","ADIEUL   PPLUGSH   EADOPT","M S TU H RSIEVEE E SSORTS"," D  V R  ILOOMS L  IBLEAT","T B VA I ICORPSI D IT S T","DELTAO   LENDEDR   ESATYR","PEACER D XO M IWRISTL T S","B A RLEDGEE M VSPICET T L","SWIMSN  U O  S WROTES  Y ","VOTEDI I RA M OLAIRSS D S","C P RABODET L ACHASMH R S","CUBICO I LM G UBOOZES T S","REBUSE E WA A AMERCYS D S","LARCHO  R U  E STEADY  M ","STILEP M RI A ALOGEST E E","L P EAVAILU P VGLADEH S S","B L SLEECHU A OSAFERH Y E","F P VRAISEO A RCONESK O E","SEAMYO  O A  N ROUTES  H ","DRONEE U RR T ABIDESY O E","BULLSR E WI A OBAKERE Y E","S B TELITEA L NTALESS S E","E  W DELAYI  N FASTSY  S ","AROSEL  H P  Y HULLSA  Y ","WIGHTE R ID O PGOWNSE S Y","NAMEDO I AI L ISACKSY H Y","H  H ACHEDR  A PRIVYY  Y ","T  C ELDERE  D TRIADH  R ","W D YROUSEI C LSTAMPT T S","C L AALARMI T ARACKSN H S","B S AO C LO O OROUSES T S","DUCALE  C L  H VEXESE  D ","W  U ALONER  S EQUALS  Y ","GORSER  M O  I WANTSN  E ","S T THARRYO E PCRAZEK D S","JERKSU U TI R ACHANTE L E","S C DPLANEA B NWILLSN E E","S C HHARRYI A DROVERK E A","ALLAYU O OD C KINANET L D","SHOCKC  A U  R LEPERL  D ","B R AA O BN O OJOKEDO S E","APACER  A R  V OASESW  S ","K P CN O OO K YWHEELN R Y","S  H HUMANA  V DUNESE  N ","ARSONL T AI O IBERYLI Y S","C E RAUDIOL I UYACHTX T S","CHILDL  O I  T CLOUTK  S ","PULLSL  O E  W ADDEDD  R ","H B AE R BR O YBROWSS D S","D P QI O UV I AANNOYN T S","MATCHA  L P  E LEAFYE  S ","R F KONIONO X IKNELTS S S","POPESR R PO O ABOXESE Y M","C  C LEARNI  I PERCHS  K ","PEARSR E TO G IBRIEFE S F","SLIMEK  O I  I FALSEF  T ","Q M DUSAGEI X NTRIESE M E","DITCHI I EN M RGRINDY D S","HANGSE A TA I URILEDT S Y","POUCHR  U I  B VIPERY  S ","D  T AVOWSU  A BONNYS  G ","S  N CALYXA  M LEAPTD  H ","A D MNURSEK I RLINERE K Y","BRAVER  I I  T AREASR  L ","R  E IRONSG  V HAVOCT  Y ","BULLYA E AR V RBREADS L S","ANNOYM  T I  H SLEETS  R ","L B BATONEU S RGOODYH M L","GROANN  U A  D STAINH  T ","SPASMU  T G  O ADAPTR  S ","SNAILI  R E  K VALESE  D ","S  M PIPERA  R KEYEDE  S ","HAVENY I  M E  NEWLYS S  ","SKIFFM  L O  O CACAOK  T ","EJECTX  U U  R LAIRST  Y ","F S WEXTRAT A ICORALH E S","S D ILURESA O LTILDEE L T","BELOWU Y AN R DCHIDEH C D","H L SOXIDEW M NLOBESS O E","SINGSH  R O  A UNDIDT  N ","COACHH  A I  U PROSYS  E ","S S GTAMERU O AFOCUSF K S","P S ARACKSO O IVOWEDE L E","EXACTS F IS O LAROSEY T D","DOINGO D OW I TROOSTY T A","B P NAGAPET R ECITEDH S S","R M  AHEADN A  GANGSE T  ","FOUNTL T UE T LSPELLH R E","W V FAGILEN T LDRAWLS L S","G G PR R EU E NFRANCF T E","ANGSTU  M G  I HULLST  E ","C C FRARERA A EFABLET S R","CASKSL H LI E OCRAMPK R E","PEEPSE L LE O AREPAYS E S","SANERL E AI R CMOVIEY E S","G  B ROVERO  E WRECKN  H ","SMEARN L IO F NBAITSS N E","O S PUSHERN A OCALYXE T Y","A C HB I UY G SSTAGSS R Y","D S FAMAZEM G RPLAINS S S","SNOWST  A I  I CUFFSK  S ","HUMANI  M N  U GEESEE  E ","B   SEASELA   YSWIRLT   Y","E  I LARGOE  L CROOKT  O ","TRUERR N II T GALIBIL E D","SILLYT  I A  K KEYEDE  R "," S  WSTAIR Y  OALERT E  H","AFIRE E U  R S BASER L S "," H  GFOLIO A  RGRIPS D  E","ESSAY T  A O  RWOUND P  S","VERBS X O  T X TRIES A R ","SPICE A A  S N THROW A N ","SCION H  A A  VNICHE N  S"," M  B E  U L  OGOUTY N  S"," S  ASCION O  GDRIVE E  L"," W N SHOOK O R VOLTS P H "," C G COLON V R FEAST T E "," S  SSTINK O  UQUEEN T  K"," A  TANIME N  RBOOMS Y  E"," S  SPLUCK Y  UCLOWN Y  K"," S F KNELL E E DATED K S "," V A NIECE S I TILDE T S ","START E  O N  ASOCKS R  T","USURP C  I O  CCREAK N  S"," B  DBRAKE O  FAWAKE N  R"," G   BRISK O   LOOKS M   ","EVERY I O  E O SWIFT S S ","STOVE I  X L  IALIAS S  T"," B U BURST N E SCORN H S "," O G CURRY T E BERYL R S "," T R BRUIN A T BIDES T S ","FAULT L  A I  KABOVE I  S"," A S CHUMP E O LANKY D Y "," C  MCHARY O  TFRESH D  S"," F  TDITTO L  RHEEDS D  O"," P  ITRIES O  LEXILE Y  T"," S V UNION E I TEACH R E "," T  SEIGHT G  ASHYLY T  S","AFIRE L  A O  RQUIET T  H"," V  SPIVOT Z  AJOLLY R  S","IDLED A V  M E PENNY S T "," S B OPIUM R I FAULT Y D "," S  A I  M E  AOVENS E  S"," P F CLOAK A C GIBES T S ","CIVIC D  H I  ULOWER M  L"," I D EDGED I N WORST T E ","ALIEN O  U G  RBINDS N  E","AGREE R X  O I CASTE N S ","ABYSS I P  G E AHEAD T K ","VITAL D  O E  RFACED L  S"," V D CEDED N R STABS S Y "," J   SEEMS L   ALOOF Y   "," S  CCHINA R  LPULPY G  X"," U  EANNEX S  CDANCE Y  L"," L  EDOZED F  ISTIFF Y  Y"," S P SMIRK E O FLOWS L S ","MURAL N  U D  RBUTTE E  D"," S  ASPARS O  IGUARD T  E"," S F MEDIA R E BURRS M Y "," A T AWAIT F A QUIRE L A "," M A NOUNS T I SHAME S E ","USURP C  A R  RCIDER P  Y"," C P FRUIT I E HEART R S ","SWARD O  E R  LDROLL Y  S"," A  PSTEER O  IIMAGE S  S"," T  ARAPID L  OMOTOR N  E","MAZES U X  G I BUGLE R E "," Q  ULURKS O  ASTUNG A  E","ASKEW T P  R O CATCH W H "," C M GAMUT N T SOWED N D "," C L SHRUG O R FRAIL D D ","STREW U L  N D FIRES C R "," V  Q I  U C  AFEATS S  I","STAVE I I  G C SHEET T S ","SPASM I H  L A FOILS T E "," B F PINES G R LOYAL T L "," L  ISEVEN G  AOAKEN L  E"," S  COPERA L  LFILMY T  X"," G S GREEN O X LURES P S ","OVARY A A  L N DINGY D E "," S  H T  O O  USOFAS D  E"," A  PFLIER I  ILAMED S  E"," H  ABINDS L  SSLIME S  S"," M  BMOTTO T  NWIPED F  S","SLICK U  N R  OMIMIC D  K"," H B ROSIN L P SEVER S D ","LEASH A P  G O ALOOF E R ","GROSS A T  L U CLING Y G "," G  R R  I E  NHYMNS S  E"," S F SPARE E E TRASH M H ","SPIED L  R A  EKNOWS K  S"," D A SEALS E T SMEAR S R "," S  F W  I O  RCROWS N  T","SLYLY O O  C U NURSE S E ","AHEAD U N  M T GASES N S ","SUING S  U H  IREEFS R  E"," G  QBAYOU L  AELEGY S  S","ASSES C X  A I PROSE S T ","DUNES N  E I  EROUND N  S","CABAL R M  R A POESY W S "," P F TAILS I O ARRAY S T "," S  FMANGO L  IYOKES N  T"," P  LPROSE O  VVOICE F  R","ASIDE P E  R T AILED G R ","PRIES E  A L  LSINCE C  S","KNITS I  I C  XPHONE E  S","  S SCOPRA  O TGLOBE  N D","POEMSR N PO A IBACONE T E","PIPERL U OA L UCALLSE S E","KNITSE N PE E APURERS T K","GAPESU R AI O LSEXESE Y A","D M TR I RE E ASUNNYS S S","RABIDO R EA I VRABBIS E L","S G ATHEIRA A OVERBSE S E","B S HR H OU U TSENSEH S L","  S FGRATE  T RFOYER  R Y","RABBIA L  B O  BENCHI D  ","T P  HARDYE O  SOULSE D  ","BREEDA N RT T OCORALH Y L","PUDGYI R EE A ARAKESS E T","B W  ROADSO T  OVERTM R  ","P T  HAILSI L  ANTICL S  ","S A  WORRYE S  ALOEST N  ","SOUNDP N OE I CCLOCKK N S","P S BOCHRES E RTODAYS S L","MUSIC  T L  A AQUIPS  D S","COSTSR H NA O ASPOOKH K Y","H I DE D AA I TDROVES M D","  C OSCRUB  O ETAWNY  N S","BIGHTL O OO W AWINESS S T","B G PU R RS I OHELIXY L Y","S A  TENETA T  THIGHE C  ","S L UTRIESA F EVOTERE S S","G D BA R RI I ILIVIDY E E","E V  DAIRYI S  CHIPST T  ","COWEDL E AI A IFIVESF E Y","G B LATONET U AEDGESS H E","SHREWM A OA D OCHILDK O Y","UNCUTN H WI O ITUSKSE E T","PAVEDE A EN L CCREEKE T S","W R NH O II A CLEMMEE S R","A L NL O UA U RRISESM Y E","SHYLYT E EE L AWIPESS S T","S J BO U IL N NVOTEDE A S","PIQUEO U RE E ASORESY Y E","C H CLOOSEA U AWINDSS D E","R P VO U EU P RGRIPSH L E","S A BTHROEI R LROOSTS W S","T U AWANTSI T KGLIDES E W","  C WSLUSH  R ICADET  S E","DUPESR R WA O IFOXEST Y H","M C  ACHESM U  MIMESA S  ","  A BVOCAL  O UFIRES  N H","B R AA E PN I PJUNTAO S L","  M FKNOLL  V ASHIRT  E S","CUFFSL I HE F AFIENDS S E","  W CFAITH  T APACES  H E","  B FQUEER  R ISTYLE  L D","ROSESA H AB I TBANDYI E R","PIPESE L IR U DISSUEL H D","RISERU O ON R OGUESTS S S","SHEERH D EA G ADREADE D Y","CARGOH U CU R ETIARAE L N","S D LPIECEA C ESHACKM Y S","N I AOWNEDI U OSCRUBE E E","S B JO A OL S YAWAKER L D","COVETL O IU C MCRATEK L S","OCHRE  Y V  E AFINED  A E","MUSICI H LD O ASHORNT T S","SWAMPN T RO T UBUILDS C E","A B ABROWNO A GDESKSE T T","SIGMAL E NA N GTRUSSE S T","S O ALIVESA E KTERSEE T D","RUINSE D WA E ACRAZYH S S","MOURNA N AN T VGUIDEE E S","Y C JI H AE I DLARGED P D","B P WO R OO A OKEYEDS S Y","M A MO U IU T MSMOKEE S S","A L  BOATSA M  CLERKK S  ","M P QY U UT S AHUSKYS Y S","AWFULD L EO U MRATION E N","P D SIDIOTV T AOTTERT Y T","W P  IRONYS E  PASHAS Y  ","F S  ACHESL O  LOOKSS N  ","H S AUPPERN R RCREDOH E W","OVALS  P H  A EFARCE  T R","  F SSPURT  S ESWEAR  D N","CHAIRR M IA P PBILGES E N","ROOSTO L AU D BSHELLE R E","A B TLEASHB S IUSINGM S H","P L OI I UT E GCINCHH S T","D G SRURALE A ISAVEDS Y E","  T CCHAIR  M ISTEAM  D P","RESINE T IN R NTWAINS Y Y","C G  HARRYA O  SEWEDE L  ","EATENV H OE I IRANKSY G Y","S S PPHASEA L CCLANKE D S","B B CE R AR U RGUILDS N S","TIGERH U  E I  FILMYT E  ","LARGEO E AW B TLOUSEY T N","T G ERELAXU O USPOILS M T","F D  LEEKSA F  REEDSE R  ","S T LPHONEA P ADEANSE Z H","R A OA D BD M EICILYI T S","E S  DUPESI O  CLUEST T  ","WIDEN  R O  A BJEWEL  N Y"," E S PLAID B L VODKA W S ","GLEANR  B A  H BUXOMS  R ","C  W OASISR  D DARTSS  H ","WAGONE  B L  E CALYXH  S ","LOOSEO  K O  A PELTSS  E ","CASTEH  A I  R LEARNL  Y ","C  T RULESI  L COILSK  S ","STOUTT  S A  A LIEGEL  E ","FOAMS R O  G R DATES N S ","PARRY G A  A C FILED N S "," P N RIMES P E READS R Y "," S C  T H  O A HURTS T S ","S  S KNEESA  D TIDALE  N ","FRISKO  L R  A MAINSS  T ","CHECK I R  L E SLIDE Y O ","VALVE B I  B D POSES T O ","I  Q DEMURE  I ABACKS  K ","SHAMSH  I O  N WANEDN  R ","GASPS X I  I T FORCE M H "," B S GIFTS B I CLEFS E F ","B  R EQUIPL  D LAPELY  R ","S  T THIRDA  O BROTHS  S "," B C VENOM G V SANER N T ","P  C IDOLSN  U THICKS  K ","P  P ORGANN  L DUMMYS  S "," C S ARRAY A N UNDER K R ","LEASTE  U E  N CLANGH  Y ","CRABS I R  F I FLUSH E K ","S  F HELIXI  X FIREST  R "," A W HUMAN G I GULFS R S ","C  W HERONU  R MENDSS  S ","I  B NEARSE  O PLAITT  L ","WHISK E T  L E GLOAT O D ","CABALL  U O  G UNDUED  R "," S H STEAD O R COUPE P S "," B C PEARS L O CLEWS S N "," M A JIFFY N T POSED R R ","HOARYE  I D  S GAWKYE  S ","SKIFFT  R E  A WRONGS  K ","DRAWNE  O R  M BATEDY  N ","AMISSL  U P  I HALTSA  E "," B L VIZOR L A CLODS Y S ","WALTZR  H E  E STUFFT  T ","S  A PUPILO  D REBELE  D "," R C EARLY Y U COMBS N S ","DAIRY V E  E A CRAPE T S ","C  C LOCALE  D FACESS  T "," L S HASTY T A WHERE E K "," R Q VAGUE I A USURP E T "," U S ENACT D A NINNY D T ","SOOTYP  A O  L TAILSS  Y ","QUIRE N A  D V BUYER E D ","QUASI S H  U O MANOR L K "," C C BULLY R A FRESH Y P "," P P PAIRS S O SHOWS A L ","GROWSO  O U  R GROSSE  T ","FINAL D S  E I DANDY S E ","PLEADR  L O  I SERVEY  E "," B D CABAL S M RARES L S "," G B  R R  A O APRON H D "," R W YEARN F A HELPS R S ","TRUCE A L  L A GLENS Y K "," S M SCRAP O T QUICK R H "," V M RACES P R NIECE D Y ","SLUSHO  A L  V VICESE  S "," B C PROOF O I FOILS K S ","BARBS U R  R O RAYON S K ","BEADSA  R N  A JERKYO  E ","CLOWN U A  N L PARKA R S ","OCEAN A B  C O SHRUG E T ","T  F OVARYO  A TRAITH  L ","NYMPH O R  U O STOPS H S "," C F FOLIO R E CABLE L D ","F  M LOGESO  T WAKENS  R ","TRIAL E G  C E FUNNY R T ","S  S WHIMSI  A SHAREH  T ","TRUTHH  W E  A FRANKT  G ","T  W RATIOA  C COOKSE  S ","SHALE E O  A A TRITE T H ","W  F AUGURI  L FELLSS  Y ","RIGHTO  I A  V SLEEKT  S ","DOERSR  O A  W MINEDS  D "," F S HELPS T U LIARS D N ","AMIGO E R  L A POISE N P "," S T SHOOK E R BEACH N H "," H M BELIE A N TROUT S S "," U M ARRAY G R FEAST S H ","O  F BANJOE  O SPURNE  D ","B  L OCEANM  R BRIGSS  O ","CREPE U A  I T KNACK S H "," W W  H H  I I BLUSH E K "," S B SWEAR U S UNSAY G L ","FATTYL  R O  O SCRUBS  T ","E  G DROOPI  U FATTYY  Y ","B  T ROARSA  U TAMERS  R ","B  C APARTS  I ALIBIL  S ","TRAPSR  A O  P LOCALL  L ","STOLEA  O F  G EDGEDR  S "," G P OASES L R TEPID S L "," C C SHALT I O PENAL F K "," G  A R  I O  DPURGE P  D","N C PO H II A PSLIMEY N R","SPEAR R  A O  IJOKED F  S"," R  OMODEM M  EBACON N  S","SWEATC Q RO U AREADYE L S","A I MGUMMYA B TPOUCHE E S","SYRUPI E RG A EHARDYT S S","G S MN H UA O TSTATEH L D","  I MFUNGI  U DCORKS  E T","SHIPST   LI   AFUSSYF   S","S B BK R EI O LFRILLF L S","ETHIC R  A O  MRUPEE T  O","  G STULIP  O OSPANK  T E","S S FPOKERA U OWALTZN L E","  I SCYNIC  E ASUPER  T F","A G GCARGOR A TEXISTS N A","B T LL I EE R ASHELFS S Y","  C SBELOW  A OMISER  S E","  N RPHOTO  O APOSED  E S"," P  PSANER Y  EPETTY D  S","SIRESL I WE G ADRILYS D S"," S  KSTORE U  EANVIL T  S"," A  TACTOR U  USTILL E  Y","  R ISTERN  I NSINGE  S R","E   GMASONP   ATAILSY   H","PIPES  R H  A AJOYED  S Y","GONNAR O DI I OMISERE Y N","OFTEN L  E O  CFRANK A  S"," Q  HGUANO E  TBRIBE Y  L","S A AT C BA R ABRIEFS D T","E B SL O ME D ICLEFTT S H","SPENDE R IR R CFRONTS R A"," B  H L  O E  IBACKS K  T","I O PMANGOA S IGUESSE T E","STINGI T OG E WHUMANS S S","A A PCOVERI O IDAWNSS S M","T S CR H UE O RACRESD N E"," S  STHREW R  APUPPY G  S","WIGHT M  I P  GFLASH Y  T","O T ECHEERE A AAURASN S E","A H NSTAREK R AELDERW Y S","SCENT A  R R  UWEEDS D  S"," G  LSLOPE E  AMASON M  S","SHOUTL R II G TCRASHE N E","WORDSI A PN N ECOCOAE H K","  D SKARMA  O TSALLY  L R","S M ACREAMO R IFLINGF T O","D M VALIBII M ASWIRLY C S","T W PA A II X TLEECHS S Y","CHAMPL U RO R ISEALSE S M","GRUFFR   AA   ICEDARE   S","PROOF O  E B  ALIMES N  T","ATTICS I AI B LDEITYE A X","H T SALOFTL R OVICARE H K"," L  GCOBRA Y  UWADED L  Y","SQUAW U  A E  VDELVE R  S","BRAWL E  O A  CFLOCK M  S","C F DOPERAL I UORGANN N T"," S  ASWAMP E  ABASER T  T","DISCSI H PT O ATOWEDY Y E","TOUCHI N AP D ISHEARY R S"," B  CCEDAR R  EMYTHS L  S","I S LMOTTOP A ALIGHTY E H"," B  PCOPRA A  STREAT S  Y","BASIC F  H O  EPOOLS T  S","O D PLARVAD I IELFINN T S"," D  PPRIOR I  ESPRAY S  S","C W FL E IO A RCAVESK E T","RATIOI R XN O ISQUADE T E","CIGARR E EA N AMATEDP S S"," U  B N  I D  PFUDGE E  D"," T  BSIEVE D  AFAILS L  T"," C  CBOXER R  UBAKED L  E","CUBICL L OO U ACUFFSK F T"," F  JPLAZA I  DVERSE S  D"," E  BFEWER R  ECIRCA E  D","D P VENSUEE A RMILLSS M E","T S CWOOERI U AGATESS H S","F T ML A OA I OTELLSS S E","WIDOWA R IG E NEVADED D S","LURKSY E LN P ICHASMH Y E"," V  HLARGO U  OBLAND T  S","CHINSE D WL E ALEAFYS S S"," S  ZSTAKE R  BRAZOR Y  A","PLUMB U  I L  PCLOSE S  D","PAPERR L AI A CCHICKE T S","SHELF O  R R  OENDOW Y  N"," B  NQUOTA X  TCOUNT M  Y","C T LOCHREU E ECRICKH R S","HAREMI E EN A NGAPEDE S S","B T GAROMAN X YJUICEO C R","F A BEXCELA R USAILST D H","  S CVENAL  O OTOWED  Y S","F H GAMOURL A ISIRENE Y D","P C CSCOURA M ULOBESM S H","C P BR O RE L AWILESS S S","L L NL E IA A GMUNCHA S T","L P CO L AA E UMOATSY S E","FILTHR E EE M ASCOLDH N S"," M  SWORSE V  NGENUS D  E","T B DWEAVEA Y UN O CGOUGE","S G PITEMSD E AE S LDREAM","G A SABBEYM A NM T OAMEND","A  S MYTHSI  O G  O OWING","MAGICI R  NEIGHU L  SOLES","S A  ODDLYC O  K B  SPERM","S W RCREDOE I ON R MTIDES","TOUCHH T EULTRAM E LBIRDS","L B MY L AI U SN E TGUSTS","P  B ROYALO  S O  I FULLY","FEASTI  P FLOUTT  R HEATS","S  S CHATSR  A U  K BRIEF","SAILSH G HALLOYM O LEBONY","LIGHTA    ROOSTV    AUDIO","ELOPET  H HELIXI  A CHALK","LOSERO A OAGLOWT S DHEADY","C T TR O HU R IM S CBLOCK","HIDESI   PLATERL   ESOLVE","QUILLU C EODIUMT N MARGUE","S A PPASHAA H DS E DMANGY","O  A COUCHC  O U  R REINS","BEFITE E  LIVESO E  WORTH","CHAMPO  O NERVEI  I COVEY","Q  D U  R OATENT  A AROMA","EASESX   ATHEFTR   IALIEN","I A ADAMESL I SE G ERIOTS","TRAMPH L  UNITSM B  BEING","G  F ROARSU  A F  N FLECK","ANGERL   AORGANO   GFENCE","F  C AGLOWU  M N  M ALLAY","B F CA O LSURGEI G FCOOKS","M L SIDIOTR B UT E DHELPS","SPITSO   ULABELA   KROCKY","CITESO R IADULTC E EHURLS","SALTYW  R EXCELE  A PONDS","RURALA A IK D NE I ESHIED","LEAFYA  J RAYONC  R HANDS","HOOPSO    VASESE    LODGE","FORTSR A  ATTICN I  CROCK","SMITET  R OCCURO  C PACKS","A  M GRAINL  D O  S WASTE","REAPSI  L PIQUEE  M RABBI","SALSAC  T UNFITL  C LEEKS","DYINGE N RE C OP U VSPREE","TRACEH S DR P GO E EWINKS","CROSSR  P EXTRAA  I MANGO","T B FH A IU Y FM O TBLUSH","TURNSH  I UPPERM  C PLIED","H C DUSHERR I ET N ASPASM","TEENSH    ROWDYO    BURRS","ASSAYG T  ADORNP L  ERECT","MATEDA    NOISEG    AMIGO","TRADEH  U INANEG  C HATER","M S II H RM O OI O NCANDY","RARESE A  AURASL E  MASON","C  S REELSE  A E  V POSER","A V KN I NT D AI E CCROOK","SOFASC  I RINSEU  L BIPED","ABACKZ  H UNCUTR  R EARLY","SOCKST   PUTTERN   EGLOVE","LOTUSA H EROUNDV M AASPEN","U  W N  H TRUERI  L LAMPS","SWARDT  E RELAXI  L POEMS","T   AHACKSR   KO   EBROAD","A A ACOVESI A KD I ESOLID","ALTOST    TRIALI    CLIFF","GRIMYR  O ABATEN  T DROOP","FLORAI   TX   TE   ARIPER","S  B TIMESU  G N  U GRAND","FILETI   INERVEA   RLOINS","Q  P UNDUEI  R L  G TAXES","M P HABOVEN D DG I GAMAZE","S S BH C OEYINGE O GNINNY","ROAMSE  A PRIMEE  M LOCAL","K D RHYENAA V BK I IIDLED","A  S RIFTSR  A O  I WRING","GUSTSR P EUSAGEF C DFIERY","CROPSR U PU T OM D OBROOK","SALADI  R DEIGNE  U DYKES","S M PW Y OINTERN H EGASES","SLICKP    EPICSR    MANLY","AUDITN O ATIGERI M DCRAZY","R B BA A ATRYSTE O CDOUGH","CAKEDR   EELUDEE   DDELLS","ADULTL  I ODDLYN  A GULCH","S V LE E URENTSU O TMUMPS","D O GODDERU D IG E NHIRED","CUREDR   RERASEE   SPEERS","M G FUSUALS A UI N TCHOSE","URBANS E OIGLOON O KGOWNS","VICESO A AD M TK E EALOUD","GASPSA  O MUSKYM  E ALARM","COASTR N OUNTILM I LBACKS","MUSESU H ISHREDI U ECAGED","SPICEL M  IMBUEN U  GLEAM","M C WO A OTENORI T MFOOLS","GAMUTR  T IRATEL  E LAIRS","BUTTSL   UUPPERF   LFILLY","E C WX O HU R OL A STULLE","K B FN E AO G LL E LLOTUS"," C S PIECE D O  E R GRIND"," A C SLAYS P C  H L CAMEO"," C S NASTY R A  G I LOINS","ASSES M  TFOLIO K  PMYTHS"," L  TGAYER I  E T  EHYMNS"," U  RADAGE D  B E  UCREPT","RULER N  A I  I O  SUNITE"," P R CLOAK I D  E I ADMIT","STATE E  XARENA S  CFEAST","MANGY F   OFTEN I   EXULT","AGLOW U L ASIDE T E MOURN"," S P BACON T I  I S SNEER"," A  P L  ARIGID B  DPIGMY","STAVE H I WRECK E A SWORD"," S C  P R TABOO C C REEKS"," M C CADRE N E  G E LOCKS","AMEND A Y GNOME G P PATHS"," P H  A E STUDY I G COWER","ASHES W X FIFTY N O JELLY","ROOMS P A REAPS R L MANES","ITEMS E   AMONG P   MOTIF","AFIRE R  AWANTS M  EVERBS","SCOLD H  IYEARN E  ETREAD","PROUD A  EIDIOT I  EVISOR","WROTH A  O D  A I  RFILED","ADDED A  WERASE E  LADMIT"," T  BARENA A  L C  EMELTS","CARVE N   INLET U   FLEAS","FREER A  AABHOR B  ELIKER","SQUAD U I FALSE S L PIPER"," C  EFRAIL A  D S  ESHEAR"," C  UVOWEL N  T C  RCHINA","WRING A I EDICT I H PORES"," D M GROAN O N  V G LEMON","SCRIP A   ITEMS C   SHRUB"," B R MATES I L  Z I BEACH"," S O  T C BREED A A OWING","SCARS A  W N  I A  NSLUNG","MIMIC N S DAISY N U HEWED"," P  F I  ISNIFF T  TBOUGH","UDDER I X STATE C R AHEAD","EBBED A L  Y F  O I GUANO","SPEND O  IOPTIC P  EBATED"," R D PAWED D N  I S WIRES"," A D INERT I A  M P BESET","SKULK H  ESADLY K  EFINED"," A S ALONG B A  U P SMASH"," A  G M  A I  M G  ITOKEN","SCRUB R  RLINGO S  OOPIUM","IDLED E  UOLDEN T  EHARTS","CREWS I  W V  I E  LBROIL"," F P  A R SCRUB E D UDDER","WAIFS G U ALONE O G TWAIN","PSALM A  OBLAST V  HGOATS"," F  IFLOSS U  L T  EYEAST","AGAIN L   MANIA Z   GENRE","JAILS B O FAWNS S G TENSE"," S G FILES G E  M S LABEL","SCALY H   RIVEN N   SATIN","PANGS D O VIGIL E N BULGE"," L R VIRUS M L  B E WORSE"," B F VAULT K I  E N FROGS","ASKED P  RBANJO C  LMETAL","ABUSE R  XVAUNT V  RPOLKA","ABASE L P TUBES S R THUMP","GUSTO S O BURRS A S FLOOR"," Z L DEPOT B G  R I WATCH","AGING O  A U  W G  KNEEDY"," P S NORTH L E  K A GAMMA","SCANT R U REEDS D G COVES","ABYSS A W DYKES O E JUMPS"," M  AFORMS M  K M  EWAXED","SCRIP A  R C  I A  STOTEM","CRAZY O   AGATE U   FEVER"," S C RIVAL G N  H O STANK"," B B FAULT Y E  O A BUTTS"," G A  O L STEPS T H CABAL","STAND H I WRECK O H OWNED","SOFAS P B TENOR R V LAKES"," T  B R  UVOTER O  NSPOUT"," E  WSTONE H  I E  RARMED","STUDY I I EBONY I E MARRY","STAGE R O MIENS L N ALTAR"," L S MILES M I  B Z BOWER","QUOTA T  R T  O E  SCRATE","AGILE A  DAMONG M  EGANGS","SCANS R   MELTS D   MOUND","CRESS E H IVORY E U ALIBI","SPOOR O  A L  V K  EOAKEN","SELLS L   GIRLS T   LEPER"," F P  R I TIRED L T SLAYS"," G  Q E  U N  O I  TZEBRA"," S  ASTEED R  O E  BAWARE","SKIMS I A SNAKY D E WAIST"," T  EWADED B  I O  FROWDY","ABOUT A  OSYNOD O  APUTTY"," G A CURDS A D  N E MOORS","ICILY O O SCOUT O S TAKES"," W  CPINTO D  Z O  ESWORN"," Q  HHURRY A  D S  RCIRCA","HOSTS  H AWRONG  O ACAKES","  C CLOATH  L U  Y RVIXEN","ISSUED A XE L IA V SSCENT","REBUT  L AGLOWS  T TPASTY","CUBESR R OO O UU W TPUNCH","NASALO W  SMASHE R  DUMPS","TAKESO H TN A OI K PCHIPS","LABEL  A I  Y G  O HVAULT","P E TR Q AO U SO A KFALLS","A B SSNAILH Y OE O PSAUCE","E P IGRIPSG A LE N EDROSS","BASED  O  SELLS  E  ASSET","L T UITEMSE M AN P GSWORE","A W  GRIMYE R  N E  TODAY","CAGEDY A ON U NI G OCHEER","S D TPARKAE A KR W EMALES","WIRED  O RDOGMA  U FCHEAT","  L CSHALL  R O  V SABASE","EGGEDL U IBUSTSO T CWOODS","BOWERA R OD A UL C NYOKED","  T USUITS  D E  E RFISTS","A C TR R HOBESEM D RADORE","  C SSYRUP  I U  M NCHECK","B R SEXERTL C AO U GWARNS","L S SOCHREC E WA E ELEPER","BOREDO A ENOBLED B PSKINS","TUSKSH U  URGESM A  BORED","C R AHOOKSI U IL S DLIEGE","B Q HA U EYEARNO S CUNITE","WAKEN  H  SHARE  K  CHICK","S R  CREEKR N  U D  BUSHY","A S MV A OA L VI V ELOOMS","O A ADALESI I IU B DMAIZE","NYMPH  E ORATIO  A DBILLS","E R  VOICEI D  L E  SCRUB","C G TO U IMUSEDI T ECLOGS","  T UASHEN  I D  N IBREED","  W CVIOLA  O S  E EBORED","A B FSMALLS Y UE O NSTUNG","  V UWAILS  D U  E AKNOLL","TRIES  G AHALED  O LIVORY","S K MCHINAA N LL D EPEARS","S L CHEAVYO R CE V LSHALE","D W TE A HPOSSEO T RTHESE","IMBUE  I P  G I  H CVOTES","S T SCRICKR L IU T MBUSTS","U S  SWUNGU I  A N  LAGER","  A  FILLY  P    H  SLAIN","FAMED  I  ORDER  S  MOTOR","CUBICL R RI U ON I PGONGS","S H HN E AI A RF T RFISHY","AMPLE  A VMANGA  I DCACHE","DECOYI A  MACESE A  STORM","AUDITB I RY T IS T CSHOCK","ROVED  A  DRUNK  N  CATER","ROAMSO D  BRINEE E  SQUAW","SHIFT  G RDELTA  O CCLOAK","ULTRAN H LT U LI M OELBOW","MARESO O ATRUSTI T EFIEND","  T GFLORA  R U  S ZCRONE","  P IBLEED  N O  C LFEEDS","P M PL I LU N IM O EBARED","W W AHAILSE D KL O EPAWED","T P GH O RU P AM P IBRAIN","COATS  D CGUISE  E NMOUNT","B S ELATHSE E SS E ATIPSY","O C SI I LLARVAE C BDEANS","TAMED  I OBANDS  E EPORED","U Q SSQUATE A ER S PSPINS","  Q AYOUNG  A A  S PTWINE","U R SSHOONI M AN A RGENIE","  W DCEASE  R N  M SHASTE","T B SOZONET N EE D DMUSTY","S S FT A UROBESU L ETWEED","A R BSTAIRS D AE I NTHIRD","DECKSI O TS B UK R DSEATS","A G UFALLSO O HO O ETAMER","  B  BLOND  S    O  MIMIC","CASTSL C  IVORYM L  BODES","FUSED  T AMOURN  F DJIFFY","DIVED  A IFELON  U EDREAD","UNDUE  O  LEGAL  M  CHASM","N S NO C ESTAKEE L DDUPES","CLASPL D OODDERU E ETIRED","MOVES  I TMUSTY  T LKNAVE","D R BO A RTABOOE B ISWILL","T H AROARSU R HT E EHUMAN","SADLY  E  COCKS  K  NASTY","BOWEDU I ODOSEDG E GEERIE","CAKES  H HDIARY  K LPRIVY","  R IPLANS  B L  B EQUILT","CAVES  O TWATER  E ATHROW","FUSSY  A  TRITE  N  CATCH","TUBESR A PO Y AL O CLOUSE","S F UYELLSR O HU C EPOKER","  L LADIEU  N S  E TPARTY","DIVERR O  INDEXE K  DEARS","FLANK  M NSLIDE  G ABROAD","  Q H  U OHYENA  E RFIRED","DRAMA  D SPAINS  E AGAUZY"," D G FELON A U  L G OTTER","CLICK A R BREAD G Z VOTER","THROWR  Z INGOTA  N LINEN","UNIONS  F UNITER  E PAINS","DROWN E H  B A  U R STAFF","FEIGN   R UPPER   E ROUND","ERECTA  L RAYONT  A HUSKS","SCARE R A NERVE D E CORDS","FARMS N E STATE I A SCOLD"," B O LAIRS Y B  O I LUSTY","Q  C UNTIEA  V F  I FLECK","SCRAPN  M ARROWR  N LUNGS","LEASE   U POPPY   E IVORY","S  S TINTSE  E E  E PROPS","S  S NICHEI  E F  L FOOLS","AGATE O H UNDUE N M CABBY","C  P ROARSE  O A  V MODEM"," S G STALE O O  U O STEMS","MEATS   O GAUNT   I JUICY","CAPONH  U IMAGEL  H LISTS","HAIRS M I RINSE G E BOORS","B  F ACORNY  I O  A USERS","DEARSR  A ELUDEA  I MIMIC","TWISTH  P IDEALE  S FLAME","GROWSR  H UNFITF  N FLEES","LAPSE N H LILAC M L VESTS","GRAPE E S SPEAK E L CLUMP","EDIFY O L IGLOO M E LAPSE","TOLLSA  O SLAYSK  A SABLE","SPADE A R ALIEN E A CRAMP","SKATE A H  R R  M O MAYBE","ABAFT   A ROGUE   L FATTY"," S W AHEAD R F  E E SWORD","ROOFS U L STRAW D K VOTER","KNOTSI  A N  B D  O AUTOS","STOOD H C SEWED I A FROND","AGATEC  U HILLSE  I DROPS","TRADER  O ELBOWA  M TEASE"," R C GUARD P E  E D PESOS"," S A DINGY D R  E E ISLES","GROWNL  A INERTN  M TORSO","HERONE  W APINGR  E SNORT","GREED A X  D T  I R TIDAL","H  M APRONR  W E  E MOORS","GERMS   A WRONG   G VITAL","GRIME   O FJORD   A AISLE","ALOFT A R DROOP V N HASTY"," H Q REBUT R A  O S UNDID"," M S LOFTY V E  I A JELLY","GANGSR  R OCEANU  T PACES","LEVERY  T RIGHTI  I CROCK"," P N FADED S R  H V DAZED"," P Q BONUS L A  K S RADII","USURP T A CREDO I I SPRIG","PESTS A O PROXY T I CHICK","B  V RABIDI  O E  L ROYAL","S  U CHARTR  B U  A BLEND","VICAR D D RIGID O E AMOUR","STEAM   D CABIN   E FRAUD"," G G ROARS N O  N W BARNS","ABBOT A X LYRIC O D MULES","S  H ALOUDN  N D  C YACHT","BUMPSR  L ORGANO  T MOLES","GATESR  L ORGANU  T PATES","WOMANH  B ASSAYR  T FLIER","BLAST U C SNARL A E CRAWL","S  C TIDALI  P R  E SCORN"," C B PILOT R A  C S RAFTS"," M P WOULD T O  T T HORSE","TROUTH  N RIFTSO  I BIBLE","   B FRILL   U    S LITHE","SPADE R Y LINKS O E FRESH","GRAPH   O SCOWL   E WEIRD","D  S INEPTC  I T  N ANGST"," S C WHERE E U  E M STABS"," Z G DEBIT B P  R S CALYX","WREAK A L ADMIT I B RIGID","LUNGS   N ALLOT   M QUEEN","P  T EXERTR  A C  M HARPS","ABAFTL  I IDLERK  L EVADE","SHOVEN  O AEGISI  L LIKER","ELOPEA  E ROARSL  I SILLS"," P W MIGHT N A  T L ROVED","LOOKS N H DIVAN O K SNAIL","   P GLEAN   R    S BOWEL"," L B TAXES P G  E U BLANK"," F A SLYLY Y B  E U TRAMP","COMMA   A PROXY   I BEAMS"," S M ALIEN E T  E E SPORE"," Q C BUXOM A N  S C MIGHT"," J S OUGHT N I  T N LAYER","BRISKE  P LILACO  S WHIMS","CEASE   P FLUID   C RULES"," R H FADED D A  I R WITTY"," C D MERRY A O  S L REPLY","S  W PESOSE  R R  S MIXES","POUCHR  H IMPELO  C RACKS"," S W ACORN R I  A S SPITE","M  W OVERTT  I I  N FORGO","LEMONO  Z ABBOTD  N SATED","P   TLURCHU   IM   NBLINK","ELBOWA A ITOYEDE O TROUGH","PLUMBR   AOUTERO   NFAIRS","ATTICM O RI O IG T EOTHER","K S DE Q IE U VP A ESAWED","  L B  I LCOBRA  E MVALUE"," K  R A  IDRAWS M  KBADLY","ICING H  RDICTA N  SHACKS","DEBUTE R AL A KT V EADORN","BIRCH    EVIOLA    TFILCH","  A SGULCH  P E  H ISTALK","SABREO I NBASEDE O ORENEW","M K AA N BDROLLA W EMINOR","WIDOWI   ISATINE   DRAINS","A C RB I AA D CS E EERRED","PUNCH  A ECAMEL  E IINDEX","PLACEL L PAMIGOI B CNEIGH","GIFTSA U WZ N EE G PSHIFT"," R  SLEASH A  I L  RSMACK","S   RCOPRAO   ZF   OFEVER","THREW  E IRULED  A EFIXER"," O  RFUNGI T  P D  EMOVER","  P BVILLA  A S  Z TFRAME","STIFF    AERECT    THARRY"," F  BPUPIL N  U G  NGIANT"," N  WPODIA N  G C  OBEGAN"," K  B H  OCARGO K  ZTITHE"," W  C A  AEVENT E  CBRUSH","  J ASWUNG  R O  O NJERKY","C W POCHREM I CI M KCASKS","S A CCIGARA A ER P ESTEAK","G A CR U UODDERU I VPROVE","I R SDWELLE I AA G ILINEN","DWARFW V LA A UR I IFILED","THROB E  UGAUNT P  TUSAGE"," B  TBRUSH O  A I  NCLOAK"," Q  BGUSTO A  O S  MPIERS","B H RO E ESCALPO R AMUDDY","L Q PO U EBRAVOE S NSKIES","BESET  P UTHUMB  R EWANDS","PLAZAO R NSPORTT M ESNAPS","REVELI   APALERE   GNONCE","AVAIL I  ACOMER L  GCAUSE","AROMA I  GOPERA E  PTRIBE","A T SBLOOMI R ID S TEPOCH","CIVIC N  O D  V E  EEXULT","S S GA H AL E MV I IOAKEN","T B PH R RU O OM I SBELIE","ATTICT I OO A IL R NLEANS","V B FI R ISNIFFI E TTARRY"," K  H A  AFREER M  PPASTY","S F HHELLOA U WC M LKEELS","SLANG  N RGONNA  E NWAXED","FLECK E  NMANIA S  CCHECK","CRISP I  IKNOLL S  ETEPID","G C AR R UU A GF Z EFLYER","BROOM  M AGLEAN  N GPOSSE","YACHTO A ILAPSEK O RSONGS"," R  WMAMMA D  G I  ELINED","  P KFLAKE  T Y  I EAVOID","BLURTA   ELIKENL   SSWORE"," K  OTHUMP A  I K  NNICHE","  D BCHURL  P O  E OMADAM"," F  S A  ISUING N  HCANES","M A DABLERX P II H EMEATS"," Q  FFUNGI A  L S  EPILOT","F C HAROMAR M IE E RSORES"," C  C I  LBRAVO C  TRAJAH","MATEDU I RS A OE R NSLAVE","WRITS I  OASKEW E  EBRIAR","B S BA W ISTEEDI A ELURES","S L SLILACI A OP M FSCARF","AMBLE  A QBAYOU  O ICLUMP","PASHAR I TE G OS M MSLAPS","R S UU I PSHEEPE V ESHEAR","QUASI  R M  E B  N UPLATE","CUBICO R HL A II V LCROWD","A O VLIMBOO I WO T EFUSED","N   KELFINI   EG   AHEARD","MURAL  A OBAYOU  O SDINGY","LEVEL    OCRUMB    EMANES"," P  FRABBI N  L E  EALIAS"," U  WEPOCH P  I E  PTRESS","FETCHR H YACUTEN M NCOBRA"," O  B F  AAFOOT E  OGROWN"," G  RCREDO O  W W  DANNOY"," O  POTHER T  O E  WBROIL","CLANS E  HKARMA S  NTHINK"," C  WPOPPA P  R R  DGATES"," B  FBASIL Y  A O  NQUACK","MAKER  I OLINGO  D KBOATS","SIGNST L KO O UI O LCAMEL"," P  AJOINT D  O I  MTALES","S U CQ L HULTRAA R NWRAPT","  P MGUANO  L V  E EPESTS","A F MVILLAA O II A LLUTES","SCRUBO   ROUTDOT   KHEAVE"," S  GSPOOR I  I N  MJERKY","S C RIGLOOZ I CE N KSAGAS"," B  TSUPER N  I C  PTHOSE"],Jn=.88,TS=.12,Yi=5,hr=Jn,vs=.15,kc=hr+vs,Yc=Yi*kc+vs,Wc=hr+vs*2,zc=.18,RS=.28,vS=.18;function Jt(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function Wl(n,e){const t=new Rt;return t.setAttribute("position",new _t(n,3)),t.setIndex(e),t.computeVertexNormals(),t}function MS(){const n=[],e=[],t=[],i=[],s=Yc,r=Wc,o=zc,c=o+RS,h=vS;Jt(n,e,[0,o,0],[s,o,0],[s,o,r],[0,o,r]),Jt(t,i,[0,0,0],[s,0,0],[s,0,r],[0,0,r]),Jt(t,i,[s,0,0],[0,0,0],[0,o,0],[s,o,0]),Jt(t,i,[0,0,r],[s,0,r],[s,o,r],[0,o,r]),Jt(t,i,[0,0,0],[0,0,r],[0,o,r],[0,o,0]),Jt(t,i,[s,0,r],[s,0,0],[s,o,0],[s,o,r]),Jt(n,e,[0,c,r],[s,c,r],[s,c,r+h],[0,c,r+h]),Jt(t,i,[0,0,r],[s,0,r],[s,0,r+h],[0,0,r+h]),Jt(t,i,[s,o,r],[0,o,r],[0,c,r],[s,c,r]),Jt(t,i,[0,0,r+h],[s,0,r+h],[s,c,r+h],[0,c,r+h]),Jt(t,i,[0,0,r],[0,0,r+h],[0,c,r+h],[0,c,r]),Jt(t,i,[s,0,r+h],[s,0,r],[s,c,r],[s,c,r+h]);const u=new Kt({color:13421772,side:an}),p=new Kt({color:0,side:an}),a=new Tt(Wl(n,e),u);a.geometry.translate(-s/2,0,0);const l=new Tt(Wl(t,i),p);l.geometry.translate(-s/2,0,0);const f=new Cn;return f.add(a,l),f}function IS(n){const e=n*kc+vs+hr/2,t=vs+hr/2;return new G(e-Yc/2-.42,zc,t-Wc/2+.3)}const rs={};function LS(n,e,t){const i=new Map;for(const s of n){const r=s[e];i.has(r)||i.set(r,[]),i.get(r).push(s)}for(const s of n){const r=s[t],o=i.get(r)??[];for(const c of o){if(c===s)continue;const h=Array.from({length:5},()=>Array(5).fill(null));for(let u=0;u<5;u++)h[e][u]=s[u],h[u][t]=c[u];return h}}return null}function yS(n){return`  '${n.flat().map(t=>t??" ").join("")}'`}function OS(n){const e=[];for(let t=0;t<5;t++)n[t].every(i=>i!==null)&&e.push(t);return e}function bS(n){const e=[];for(let t=0;t<5;t++){let i=!0;for(let s=0;s<5;s++)if(n[s][t]===null){i=!1;break}i&&e.push(t)}return e}function zl(n,e){return e.includes(n-1)||e.includes(n+1)}function Kl(n,e){for(let t=0;t<5;t++){const i=e[t];if(i!==null&&n[t]!==i)return!1}return!0}function CS(n,e){const t=OS(n),i=bS(n),s=[];for(let r=0;r<5;r++)t.includes(r)||zl(r,t)||s.push({axis:"row",idx:r});for(let r=0;r<5;r++)i.includes(r)||zl(r,i)||s.push({axis:"col",idx:r});fr(s),fr(e);for(const r of s){if(r.axis==="row"){const h=n[r.idx],u=e.find(p=>Kl(p,h));if(!u)continue;for(let p=0;p<5;p++)n[r.idx][p]=u[p];return!0}const o=[];for(let h=0;h<5;h++)o.push(n[h][r.idx]);const c=e.find(h=>Kl(h,o));if(c){for(let h=0;h<5;h++)n[h][r.idx]=c[h];return!0}}return!1}function DS(n,e){for(;CS(n,e););}function NS(n){const e=new Map;for(const t of n){const i=t.flat().map(s=>s??" ").join("");e.has(i)||e.set(i,t)}return Array.from(e.values())}async function PS(){const n=rs.resolve(__dirname,".."),e=rs.join(n,"src","scrabble","words.txt"),t=rs.join(n,"src","scrabble","puzzles.ts"),s=(await rs.readFile(e,"utf8")).split(/\r?\n/).map(h=>h.trim().toUpperCase()).filter(Boolean),r=[];for(let h=0;h<5;h++)for(let u=0;u<5;u++)for(let p=0;p<100;p++){fr(s);const a=LS(s,h,u);a&&(DS(a,s),r.push(a))}const o=NS(r),c=[];c.push("/**"),c.push(" * @file puzzles.ts"),c.push(" *"),c.push(" * Auto-generated by build/build-puzzles.ts."),c.push(" * Do not edit manually."),c.push(" */"),c.push(""),c.push("export const PUZZLES: readonly string[] = [");for(const h of o)c.push(yS(h)+",");c.push("]"),c.push(""),await rs.writeFile(t,c.join(`
`),"utf8"),console.log(`Generated ${r.length} puzzles (${o.length} unique) -> ${t}`)}PS();function fr(n){let e=n.length,t;for(;e>0;)t=Math.floor(Math.random()*e),e--,[n[e],n[t]]=[n[t],n[e]];return n}const Kc=gS.split(/\r?\n/).map(n=>n.trim()).filter(Boolean);function US(){if(ra.length===0)throw new Error("No puzzles available — run build-puzzles first.");const n=[...ra[Math.floor(Math.random()*ra.length)]],e=[];for(let t=0;t<25;t++){const i=n[t];if(i===" ")continue;const s=wS(t);let r=0;for(const o of s)n[o]!==" "&&r++;if(r>2&&(e.push(i),n[t]=" ",e.length===Yi))break}for(fr(e);e.length<Yi;)Math.random()>.5?e.unshift(" "):e.push(" ");return[...e,...n].join("")}const Ci=[];function wS(n){Ci.length=0;const e=Math.floor(n/5),t=n%5;return t>0&&Ci.push(n-1),t<4&&Ci.push(n+1),e>0&&Ci.push(n-5),e<4&&Ci.push(n+5),Ci}function Xc(n){let e=0;const t=US();for(const i of n._scrabbleTiles)i.slotPos=n.slotPos[e],i.slotQuat=n.slotQuat[e],i.group.position.copy(i.slotPos),i.group.quaternion.copy(i.slotQuat),i.setLetter(t[e++])}function FS(n){const e=new Set;let t=0;for(let i=0;i<Yi;i++)n._scrabbleTiles[t].glyph!==" "&&(e.add(i),t++);for(let i=0;i<25;i++)n._scrabbleTiles[i].glyph!==" "&&e.add(t),t++;for(let i=0;i<5;i++)if(BS(n,i))for(let s=0;s<5;s++)e.delete(dr(i,s));for(let i=0;i<5;i++)if(HS(n,i))for(let s=0;s<5;s++)e.delete(dr(s,i));return e.size===0}function dr(n,e){return Yi+n*5+e}function BS(n,e){const t=[];for(let s=0;s<5;s++){const r=n._scrabbleTiles[dr(e,s)].glyph;if(r===" ")return!1;t.push(r)}const i=t.join("").toLowerCase();return Kc.includes(i)}function HS(n,e){const t=[];for(let s=0;s<5;s++){const r=n._scrabbleTiles[dr(s,e)].glyph;if(r===" ")return!1;t.push(r)}const i=t.join("").toLowerCase();return Kc.includes(i)}const Xl={type:"change"},Mo={type:"start"},qc={type:"end"},$s=new mo,ql=new yn,GS=Math.cos(70*lh.DEG2RAD),gt=new G,Ht=2*Math.PI,rt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},aa=1e-6;class VS extends yf{constructor(e,t=null){super(e,t),this.state=rt.NONE,this.target=new G,this.cursor=new G,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Pi.ROTATE,MIDDLE:Pi.DOLLY,RIGHT:Pi.PAN},this.touches={ONE:Di.ROTATE,TWO:Di.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new G,this._lastQuaternion=new Un,this._lastTargetPosition=new G,this._quat=new Un().setFromUnitVectors(e.up,new G(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new pl,this._sphericalDelta=new pl,this._scale=1,this._panOffset=new G,this._rotateStart=new oe,this._rotateEnd=new oe,this._rotateDelta=new oe,this._panStart=new oe,this._panEnd=new oe,this._panDelta=new oe,this._dollyStart=new oe,this._dollyEnd=new oe,this._dollyDelta=new oe,this._dollyDirection=new G,this._mouse=new oe,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=YS.bind(this),this._onPointerDown=kS.bind(this),this._onPointerUp=WS.bind(this),this._onContextMenu=JS.bind(this),this._onMouseWheel=XS.bind(this),this._onKeyDown=qS.bind(this),this._onTouchStart=ZS.bind(this),this._onTouchMove=QS.bind(this),this._onMouseDown=zS.bind(this),this._onMouseMove=KS.bind(this),this._interceptControlDown=$S.bind(this),this._interceptControlUp=jS.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Xl),this.update(),this.state=rt.NONE}update(e=null){const t=this.object.position;gt.copy(t).sub(this.target),gt.applyQuaternion(this._quat),this._spherical.setFromVector3(gt),this.autoRotate&&this.state===rt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(i)&&isFinite(s)&&(i<-Math.PI?i+=Ht:i>Math.PI&&(i-=Ht),s<-Math.PI?s+=Ht:s>Math.PI&&(s-=Ht),i<=s?this._spherical.theta=Math.max(i,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+s)/2?Math.max(i,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(gt.setFromSpherical(this._spherical),gt.applyQuaternion(this._quatInverse),t.copy(this.target).add(gt),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const c=gt.length();o=this._clampDistance(c*this._scale);const h=c-o;this.object.position.addScaledVector(this._dollyDirection,h),this.object.updateMatrixWorld(),r=!!h}else if(this.object.isOrthographicCamera){const c=new G(this._mouse.x,this._mouse.y,0);c.unproject(this.object);const h=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=h!==this.object.zoom;const u=new G(this._mouse.x,this._mouse.y,0);u.unproject(this.object),this.object.position.sub(u).add(c),this.object.updateMatrixWorld(),o=gt.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):($s.origin.copy(this.object.position),$s.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot($s.direction))<GS?this.object.lookAt(this.target):(ql.setFromNormalAndCoplanarPoint(this.object.up,this.target),$s.intersectPlane(ql,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>aa||8*(1-this._lastQuaternion.dot(this.object.quaternion))>aa||this._lastTargetPosition.distanceToSquared(this.target)>aa?(this.dispatchEvent(Xl),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?Ht/60*this.autoRotateSpeed*e:Ht/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){gt.setFromMatrixColumn(t,0),gt.multiplyScalar(-e),this._panOffset.add(gt)}_panUp(e,t){this.screenSpacePanning===!0?gt.setFromMatrixColumn(t,1):(gt.setFromMatrixColumn(t,0),gt.crossVectors(this.object.up,gt)),gt.multiplyScalar(e),this._panOffset.add(gt)}_pan(e,t){const i=this.domElement;if(this.object.isPerspectiveCamera){const s=this.object.position;gt.copy(s).sub(this.target);let r=gt.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/i.clientHeight,this.object.matrix),this._panUp(2*t*r/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const i=this.domElement.getBoundingClientRect(),s=e-i.left,r=t-i.top,o=i.width,c=i.height;this._mouse.x=s/o*2-1,this._mouse.y=-(r/c)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._rotateStart.set(i,s)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panStart.set(i,s)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),r=.5*(e.pageY+i.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panEnd.set(i,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,c=(e.pageY+t.y)*.5;this._updateZoomParameters(o,c)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new oe,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,i={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}}function kS(n){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(n.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(n)&&(this._addPointer(n),n.pointerType==="touch"?this._onTouchStart(n):this._onMouseDown(n)))}function YS(n){this.enabled!==!1&&(n.pointerType==="touch"?this._onTouchMove(n):this._onMouseMove(n))}function WS(n){switch(this._removePointer(n),this._pointers.length){case 0:this.domElement.releasePointerCapture(n.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(qc),this.state=rt.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function zS(n){let e;switch(n.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Pi.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(n),this.state=rt.DOLLY;break;case Pi.ROTATE:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}break;case Pi.PAN:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Mo)}function KS(n){switch(this.state){case rt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(n);break;case rt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(n);break;case rt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(n);break}}function XS(n){this.enabled===!1||this.enableZoom===!1||this.state!==rt.NONE||(n.preventDefault(),this.dispatchEvent(Mo),this._handleMouseWheel(this._customWheelEvent(n)),this.dispatchEvent(qc))}function qS(n){this.enabled!==!1&&this._handleKeyDown(n)}function ZS(n){switch(this._trackPointer(n),this._pointers.length){case 1:switch(this.touches.ONE){case Di.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(n),this.state=rt.TOUCH_ROTATE;break;case Di.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(n),this.state=rt.TOUCH_PAN;break;default:this.state=rt.NONE}break;case 2:switch(this.touches.TWO){case Di.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(n),this.state=rt.TOUCH_DOLLY_PAN;break;case Di.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(n),this.state=rt.TOUCH_DOLLY_ROTATE;break;default:this.state=rt.NONE}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Mo)}function QS(n){switch(this._trackPointer(n),this.state){case rt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(n),this.update();break;case rt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(n),this.update();break;case rt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(n),this.update();break;case rt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(n),this.update();break;default:this.state=rt.NONE}}function JS(n){this.enabled!==!1&&n.preventDefault()}function $S(n){n.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function jS(n){n.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}class Zc{constructor(e){me(this,"_canvas");me(this,"_renderer");me(this,"_camera");this.app=e,this._canvas=e._canvas,this._renderer=e._renderer,this._camera=e._camera}}class e0 extends Zc{constructor(){super(...arguments);me(this,"_pix",1);me(this,"_renderSize",new oe)}onResize(){this._camera.aspect=window.innerWidth/window.innerHeight,this._camera.updateProjectionMatrix(),this._applyRendererResolution()}_applyRendererResolution(){const i=(window.devicePixelRatio||1)/this.app._renderPixelScale;this._pix=i,this._renderer.setPixelRatio(i),this._renderer.setSize(window.innerWidth,window.innerHeight),this._positionControlOverlays()}_positionControlOverlays(){const t=document.getElementById("overlay-canvas");this._setupPixelPerfectOverlay(t)}_setupPixelPerfectOverlay(t){const i=t.getContext("2d");t.width=this._renderSize.x,t.height=this._renderSize.y,i.imageSmoothingEnabled=!1}}const fn=5,dn=1,Dt=.2,Qc=.3,t0=.15,pn=dn+Dt,ut=fn*pn+Dt,ot=Qc,zt=Qc-t0;function $t(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function Zl(n,e){const t=new Rt;return t.setAttribute("position",new _t(n,3)),t.setIndex(e),t.computeVertexNormals(),t}const cs=[],n0=[];function i0(){const n=[],e=[],t=[],i=[],s=-ut/2,r=-ut/2-1;for(let l=0;l<=fn;l++)for(let f=0;f<=fn;f++)cs.push(new G(s+Dt/2+f*(dn+Dt),ot,r+Dt/2+l*(dn+Dt)));const o=[2.5,3.5];n0.push(...o.map(l=>[new G(-3,ot,l),new G(3,ot,l)]));for(let l=0;l<=fn;l++){const f=l*pn,m=f+Dt;$t(n,e,[0,ot,f],[ut,ot,f],[ut,ot,m],[0,ot,m])}for(let l=0;l<=fn;l++){const f=l*pn,m=f+Dt;for(let S=0;S<fn;S++){const E=S*pn+Dt,d=E+dn;$t(n,e,[f,ot,E],[m,ot,E],[m,ot,d],[f,ot,d])}}for(let l=0;l<fn;l++)for(let f=0;f<fn;f++){const m=f*pn+Dt,S=m+dn,E=l*pn+Dt,d=E+dn;$t(n,e,[m,zt,E],[S,zt,E],[S,zt,d],[m,zt,d])}$t(t,i,[ut,0,0],[0,0,0],[0,ot,0],[ut,ot,0]),$t(t,i,[0,0,ut],[ut,0,ut],[ut,ot,ut],[0,ot,ut]),$t(t,i,[0,0,0],[0,0,ut],[0,ot,ut],[0,ot,0]),$t(t,i,[ut,0,ut],[ut,0,0],[ut,ot,0],[ut,ot,ut]),$t(t,i,[0,0,0],[ut,0,0],[ut,0,ut],[0,0,ut]);for(let l=0;l<fn;l++)for(let f=0;f<fn;f++){const m=f*pn+Dt,S=m+dn,E=l*pn+Dt,d=E+dn;$t(t,i,[S,zt,E],[m,zt,E],[m,ot,E],[S,ot,E]),$t(t,i,[m,zt,d],[S,zt,d],[S,ot,d],[m,ot,d]),$t(t,i,[m,zt,E],[m,zt,d],[m,ot,d],[m,ot,E]),$t(t,i,[S,zt,d],[S,zt,E],[S,ot,E],[S,ot,d])}const c=new Kt({color:13421772,side:Lt}),h=new Kt({color:0,side:Lt}),u=new Tt(Zl(n,e),c),p=new Tt(Zl(t,i),h),a=new Cn;return a.add(u,p),a.position.set(s,0,r),a}function s0(n,e){const t=e*pn+Dt+dn/2-Jn/2,i=n*pn+Dt+dn/2-Jn/2;return new G(t,zt,i)}class Io{constructor(){me(this,"duration",3e3);me(this,"hasRenderedScene",!1);me(this,"shouldSkipTileExit",!1)}getMaskCount(e){return this.getMasks(e).length}initMeshes(e){}updateMeshes(e,t){}cleanupMeshes(e){}}const fs={entrance:new WeakMap,exit:new WeakMap},pr={entrance:new WeakSet,exit:new WeakSet},r0=new WeakMap,a0=new WeakMap;function gr(n){return n?"exit":"entrance"}function Tr(n,e){const t=e==="exit"?a0:r0;let i=t.get(n);return i||(i=[],t.set(n,i)),i}function Sn(n){return Math.max(0,Math.min(1,n))}function o0(n){const e=Sn(n.startScanIndex/(n.w*n.h));if(n.activeCompId<0)return e;const t=Sn(n.bfsReadIndex/Math.max(1,n.bfsQueue.length));return Sn(e*.85+t*.15)}function l0(n){if(n.phase==="prepare-color")return 0;if(n.phase==="scan-color-mask")return Sn(n.maskScanIndex/Math.max(1,n.flipped.length)*.45);if(n.phase==="components")return Sn(.45+o0(n)*.4);if(n.phase==="build-regions"){const e=Sn(n.buildCompIndex/Math.max(1,n.compBounds.length));return Sn(.85+e*.15)}return 0}function c0(n){if(Tr(n.app,n.kind).length>=100)return 100;const e=Math.max(1,n.flipped.length);if(n.phase==="render")return 1;if(n.phase==="flip")return 2+18*Sn(n.flipY/Math.max(1,n.h));if(n.phase==="collect-colors")return 20+15*Sn(n.colorScanIndex/e);if(n.phase==="done")return 100;const t=Math.max(1,n.colors.length,n.colorSet.size),i=65/t,s=Math.min(n.colorIndex,t)*i,r=l0(n)*i;return Sn((35+s+r)/100)*100}function u0(n,e){const t=window.innerWidth,i=window.innerHeight;return{app:n,kind:e,w:t,h:i,phase:"render",pixels:new Uint8Array(t*i*4),flipped:new Uint8ClampedArray(t*i*4),flipY:0,colorSet:new Set,colorScanIndex:0,colors:[],colorIndex:0,targetHex:0,filterColor:lt._MASK_FILTER_COLORS[0],maskData:null,md:null,maskScanIndex:0,componentMap:new Int32Array(t*i).fill(-1),compBounds:[],compSamples:[],startScanIndex:0,bfsQueue:[],bfsReadIndex:0,activeCompId:-1,activeBounds:null,buildCompIndex:0,raycaster:new Ro,rayNdc:new oe}}function h0(n){const{w:e,h:t}=n;n.targetHex=n.colors[n.colorIndex],n.filterColor=lt._MASK_FILTER_COLORS[n.colorIndex%lt._MASK_FILTER_COLORS.length],n.maskData=new ImageData(e,t),n.md=n.maskData.data,n.maskScanIndex=0,n.componentMap.fill(-1),n.compBounds=[],n.compSamples=[],n.startScanIndex=0,n.bfsQueue.length=0,n.bfsReadIndex=0,n.activeCompId=-1,n.activeBounds=null,n.buildCompIndex=0}function f0(n,e){const{app:t,w:i,h:s,compBounds:r,componentMap:o,md:c,filterColor:h}=n,u=1.5*Math.hypot(i/2,s/2),p=Tr(t,n.kind);if(!c)return;const a=r[e],l=a.maxX-a.minX+1,f=a.maxY-a.minY+1;if(l===i&&f===s)return;const m=new OffscreenCanvas(l,f),S=m.getContext("2d"),E=S.createImageData(l,f),d=E.data;for(let C=a.minY;C<=a.maxY;C++)for(let U=a.minX;U<=a.maxX;U++)if(o[C*i+U]===e){const R=((C-a.minY)*l+(U-a.minX))*4,v=(C*i+U)*4;d[R]=c[v],d[R+1]=c[v+1],d[R+2]=c[v+2],d[R+3]=c[v+3]}S.putImageData(E,0,0);const g=new G(0,0,0);let A=0,I=0,D=0,O=0;if(g){const C=g.clone().project(t._nextCamera),U=(C.x+1)/2*i,R=(1-C.y)/2*s;A=a.minX-(U-m.width/2),I=a.minY-(R-m.height/2);const v=(a.minX+a.maxX)/2,P=(a.minY+a.maxY)/2,V=v-i/2,Z=P-s/2;let Q=2*Math.hypot(V,Z)+Math.random()*100;Q=Math.max(Q,u);const j=Math.atan2(Z,V);D=Q*Math.cos(j),O=Q*Math.sin(j)}p.length>=100||p.push({filterColor:h,canvas:m,x:a.minX,y:a.minY,worldPos:g,restOffsetX:A,restOffsetY:I,animOffsetX:D,animOffsetY:O,restAngle:-Math.PI+2*Math.random()*Math.PI})}function d0(n){const{app:e,w:t,h:i}=n,s=new wn(t,i);s.texture.colorSpace=Nt,e._renderer.setRenderTarget(s);const r=e._scrabbleTiles.some(o=>o.isVisible);if(r)for(const o of e._allTiles)o.hide();if(e._renderer.render(e._scene,n.kind==="entrance"?e._nextCamera:e._camera),r)for(const o of e._allTiles)o.show();e._renderer.setRenderTarget(null),e._renderer.readRenderTargetPixels(s,0,0,t,i,n.pixels),s.dispose(),n.phase="flip"}function p0(n,e){const{w:t,h:i}=n;for(;n.flipY<i;n.flipY++){const o=(i-1-n.flipY)*t*4,c=n.flipY*t*4;if(n.flipped.set(n.pixels.subarray(o,o+t*4),c),(n.flipY&31)===0&&performance.now()>=e)return!1}const s=document.getElementById("buffer-canvas");s.width=t,s.height=i;const r=Uint8ClampedArray.from(n.flipped);return s.getContext("2d").putImageData(new ImageData(r,t,i),0,0),n.phase="collect-colors",!0}function E0(n,e){for(;n.colorScanIndex<n.flipped.length;n.colorScanIndex+=4)if(!(n.flipped[n.colorScanIndex]>150)&&(n.colorSet.add(n.flipped[n.colorScanIndex]<<16|n.flipped[n.colorScanIndex+1]<<8|n.flipped[n.colorScanIndex+2]),(n.colorScanIndex&4095)===0&&performance.now()>=e))return!1;if(n.colorSet.size>5)throw new Error(`Expected ≤5 unique colors, got ${n.colorSet.size}`);return n.colors=[...n.colorSet],n.colorIndex=0,n.phase="prepare-color",!0}function m0(n,e){const t=n.md;if(!t)throw new Error("maskData not initialized");for(;n.maskScanIndex<n.flipped.length;n.maskScanIndex+=4)if((n.flipped[n.maskScanIndex]<<16|n.flipped[n.maskScanIndex+1]<<8|n.flipped[n.maskScanIndex+2])===n.targetHex&&(t[n.maskScanIndex]=n.flipped[n.maskScanIndex],t[n.maskScanIndex+1]=n.flipped[n.maskScanIndex+1],t[n.maskScanIndex+2]=n.flipped[n.maskScanIndex+2],t[n.maskScanIndex+3]=255),(n.maskScanIndex&4095)===0&&performance.now()>=e)return!1;return n.phase="components",!0}function S0(n,e){const{w:t,h:i}=n,s=n.md,r=n.activeBounds;if(!s)throw new Error("maskData not initialized");if(!r)throw new Error("active component bounds missing");let o=0;for(;n.bfsReadIndex<n.bfsQueue.length;){const u=n.bfsQueue[n.bfsReadIndex++],p=u%t,a=u/t|0;if(p<r.minX&&(r.minX=p),p>r.maxX&&(r.maxX=p),a<r.minY&&(r.minY=a),a>r.maxY&&(r.maxY=a),p>0&&n.componentMap[u-1]===-1&&s[(u-1)*4+3]>0&&(n.componentMap[u-1]=n.activeCompId,n.bfsQueue.push(u-1)),p<t-1&&n.componentMap[u+1]===-1&&s[(u+1)*4+3]>0&&(n.componentMap[u+1]=n.activeCompId,n.bfsQueue.push(u+1)),a>0&&n.componentMap[u-t]===-1&&s[(u-t)*4+3]>0&&(n.componentMap[u-t]=n.activeCompId,n.bfsQueue.push(u-t)),a<i-1&&n.componentMap[u+t]===-1&&s[(u+t)*4+3]>0&&(n.componentMap[u+t]=n.activeCompId,n.bfsQueue.push(u+t)),o++,(o&255)===0&&performance.now()>=e)return!1}const c=[],h=Math.max(1,Math.floor(n.bfsQueue.length/5));for(let u=0;u<n.bfsQueue.length&&c.length<5;u+=h)c.push(n.bfsQueue[u]);return n.compSamples.push(c),n.activeCompId=-1,n.activeBounds=null,n.bfsQueue.length=0,n.bfsReadIndex=0,!0}function A0(n,e){const{w:t,h:i}=n,s=n.md;if(!s)throw new Error("maskData not initialized");let r=-1;for(;n.startScanIndex<t*i;n.startScanIndex++){if(s[n.startScanIndex*4+3]>0&&n.componentMap[n.startScanIndex]===-1){r=n.startScanIndex,n.startScanIndex++;break}if((n.startScanIndex&1023)===0&&performance.now()>=e)return!1}if(r<0)return n.phase="build-regions",!0;const o=n.compBounds.length,c={minX:t,maxX:-1,minY:i,maxY:-1};return n.compBounds.push(c),n.activeCompId=o,n.activeBounds=c,n.bfsQueue.length=0,n.bfsReadIndex=0,n.bfsQueue.push(r),n.componentMap[r]=o,!0}function x0(n,e){for(;performance.now()<e;){if(n.activeCompId>=0){if(!S0(n,e))return!1;continue}if(!A0(n,e))return!1;if(n.phase==="build-regions")return!0}return!1}function _0(n,e){for(;n.buildCompIndex<n.compBounds.length;){if(performance.now()>=e)return!1;f0(n,n.buildCompIndex),n.buildCompIndex++}return n.colorIndex++,n.phase="prepare-color",!0}function g0(n,e){for(;performance.now()<e;){if(n.phase==="render"){d0(n);continue}if(n.phase==="flip"){if(!p0(n,e))return!1;continue}if(n.phase==="collect-colors"){if(!E0(n,e))return!1;continue}if(n.phase==="prepare-color"){if(n.colorIndex>=n.colors.length){n.phase="done";continue}h0(n),n.phase="scan-color-mask";continue}if(n.phase==="scan-color-mask"){if(!m0(n,e))return!1;continue}if(n.phase==="components"){if(!x0(n,e))return!1;continue}if(n.phase==="build-regions"){if(!_0(n,e))return!1;continue}if(n.phase==="done")return!0}return n.phase==="done"}function Jc(n,e=!1){const t=gr(e);Tr(n,t).length=0,pr[t].delete(n),fs[t].set(n,u0(n,t))}function T0(n,e=5,t=!1){const i=gr(t);if(!fs[i].has(n)){if(pr[i].has(n))return!0;Jc(n,t)}const s=fs[i].get(n);if(!s)return!0;const r=Number.isFinite(e)?Math.max(0,e):Number.POSITIVE_INFINITY,o=performance.now()+r,c=g0(s,o);return c&&(fs[i].delete(n),pr[i].add(n)),c}function R0(n,e=!1){const t=gr(e);if(pr[t].has(n))return 100;const i=fs[t].get(n);if(!i)return 0;const s=c0(i);return Math.max(0,Math.min(100,s))}function v0(n,e=!1){return Tr(n,gr(e))}class M0 extends Io{constructor(e){super(),this._isExit=e}begin(e){Jc(e,this._isExit)}incremental(e,t=5){return T0(e,t,this._isExit)}getPercentComplete(e){return R0(e,this._isExit)}getMasks(e){return v0(e,this._isExit)}}const Ql=["KeyA","ArrowLeft","KeyD","ArrowRight","Space"];class I0 extends Zc{constructor(){super(...arguments);me(this,"_cpDummy",[0,0])}wireUiInput(){const t=this.app._canvas;window.addEventListener("keydown",i=>{Ql.includes(i.code)&&this._routeKeyDown(i.code)&&(i.preventDefault(),i.stopPropagation())}),window.addEventListener("keyup",i=>{Ql.includes(i.code)&&this._routeKeyUp(i.code)&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousedown",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerDown("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousemove",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerMove("mouse",s[0],s[1])}),t.addEventListener("mouseup",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerUp("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mouseleave",i=>{this._routePointerLeave("mouse")}),t.addEventListener("touchstart",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerDown(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchmove",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerMove(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchend",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerUp(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchcancel",i=>{for(const s of Array.from(i.changedTouches))this._routePointerLeave(s.identifier);i.preventDefault()},{passive:!1})}_toCanvasPoint(t,i){const s=t.getBoundingClientRect();return s.width<=0||s.height<=0?null:(this._cpDummy[0]=(i.clientX-s.left)*(t.width/s.width),this._cpDummy[1]=(i.clientY-s.top)*(t.height/s.height),this._cpDummy)}_routePointerMove(t,i,s){this.app.mouseMove(i,s)}_routeKeyDown(t){return!1}_routeKeyUp(t){return!1}_routePointerDown(t,i,s){return this.app.mouseMove(i,s),this.app.mouseDown(),!1}_routePointerUp(t,i,s){return this.app.mouseUp(),!1}_routePointerLeave(t){this.app.mouseUp(),document.documentElement.style.cursor="default"}}const L0=Nt;class Er extends To{constructor(e){super(e),this.defaultDPI=90,this.defaultUnit="px"}load(e,t,i,s){const r=this,o=new vf(r.manager);o.setPath(r.path),o.setRequestHeader(r.requestHeader),o.setWithCredentials(r.withCredentials),o.load(e,function(c){try{t(r.parse(c))}catch(h){s?s(h):console.error(h),r.manager.itemError(e)}},i,s)}parse(e){const t=this;function i(W,w){if(W.nodeType!==1)return;const M=I(W);let _=!1,Y=null;switch(W.nodeName){case"svg":w=m(W,w);break;case"style":r(W);break;case"g":w=m(W,w);break;case"path":w=m(W,w),W.hasAttribute("d")&&(Y=s(W));break;case"rect":w=m(W,w),Y=h(W);break;case"polygon":w=m(W,w),Y=u(W);break;case"polyline":w=m(W,w),Y=p(W);break;case"circle":w=m(W,w),Y=a(W);break;case"ellipse":w=m(W,w),Y=l(W);break;case"line":w=m(W,w),Y=f(W);break;case"defs":_=!0;break;case"use":w=m(W,w);const le=(W.getAttributeNS("http://www.w3.org/1999/xlink","href")||"").substring(1),Ae=W.viewportElement.getElementById(le);Ae?i(Ae,w):console.warn("SVGLoader: 'use node' references non-existent node id: "+le);break}Y&&(w.fill!==void 0&&w.fill!=="none"&&Y.color.setStyle(w.fill,L0),O(Y,Me),V.push(Y),Y.userData={node:W,style:w});const se=W.childNodes;for(let k=0;k<se.length;k++){const le=se[k];_&&le.nodeName!=="style"&&le.nodeName!=="defs"||i(le,w)}M&&(Q.pop(),Q.length>0?Me.copy(Q[Q.length-1]):Me.identity())}function s(W){const w=new si,M=new oe,_=new oe,Y=new oe;let se=!0,k=!1;const le=W.getAttribute("d");if(le===""||le==="none")return null;const Ae=le.match(/[a-df-z][^a-df-z]*/ig);for(let ue=0,H=Ae.length;ue<H;ue++){const T=Ae[ue],q=T.charAt(0),$=T.slice(1).trim();se===!0&&(k=!0,se=!1);let N;switch(q){case"M":N=E($);for(let y=0,ae=N.length;y<ae;y+=2)M.x=N[y+0],M.y=N[y+1],_.x=M.x,_.y=M.y,y===0?w.moveTo(M.x,M.y):w.lineTo(M.x,M.y),y===0&&Y.copy(M);break;case"H":N=E($);for(let y=0,ae=N.length;y<ae;y++)M.x=N[y],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"V":N=E($);for(let y=0,ae=N.length;y<ae;y++)M.y=N[y],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"L":N=E($);for(let y=0,ae=N.length;y<ae;y+=2)M.x=N[y+0],M.y=N[y+1],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"C":N=E($);for(let y=0,ae=N.length;y<ae;y+=6)w.bezierCurveTo(N[y+0],N[y+1],N[y+2],N[y+3],N[y+4],N[y+5]),_.x=N[y+2],_.y=N[y+3],M.x=N[y+4],M.y=N[y+5],y===0&&k===!0&&Y.copy(M);break;case"S":N=E($);for(let y=0,ae=N.length;y<ae;y+=4)w.bezierCurveTo(S(M.x,_.x),S(M.y,_.y),N[y+0],N[y+1],N[y+2],N[y+3]),_.x=N[y+0],_.y=N[y+1],M.x=N[y+2],M.y=N[y+3],y===0&&k===!0&&Y.copy(M);break;case"Q":N=E($);for(let y=0,ae=N.length;y<ae;y+=4)w.quadraticCurveTo(N[y+0],N[y+1],N[y+2],N[y+3]),_.x=N[y+0],_.y=N[y+1],M.x=N[y+2],M.y=N[y+3],y===0&&k===!0&&Y.copy(M);break;case"T":N=E($);for(let y=0,ae=N.length;y<ae;y+=2){const ce=S(M.x,_.x),Te=S(M.y,_.y);w.quadraticCurveTo(ce,Te,N[y+0],N[y+1]),_.x=ce,_.y=Te,M.x=N[y+0],M.y=N[y+1],y===0&&k===!0&&Y.copy(M)}break;case"A":N=E($,[3,4],7);for(let y=0,ae=N.length;y<ae;y+=7){if(N[y+5]==M.x&&N[y+6]==M.y)continue;const ce=M.clone();M.x=N[y+5],M.y=N[y+6],_.x=M.x,_.y=M.y,o(w,N[y],N[y+1],N[y+2],N[y+3],N[y+4],ce,M),y===0&&k===!0&&Y.copy(M)}break;case"m":N=E($);for(let y=0,ae=N.length;y<ae;y+=2)M.x+=N[y+0],M.y+=N[y+1],_.x=M.x,_.y=M.y,y===0?w.moveTo(M.x,M.y):w.lineTo(M.x,M.y),y===0&&Y.copy(M);break;case"h":N=E($);for(let y=0,ae=N.length;y<ae;y++)M.x+=N[y],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"v":N=E($);for(let y=0,ae=N.length;y<ae;y++)M.y+=N[y],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"l":N=E($);for(let y=0,ae=N.length;y<ae;y+=2)M.x+=N[y+0],M.y+=N[y+1],_.x=M.x,_.y=M.y,w.lineTo(M.x,M.y),y===0&&k===!0&&Y.copy(M);break;case"c":N=E($);for(let y=0,ae=N.length;y<ae;y+=6)w.bezierCurveTo(M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3],M.x+N[y+4],M.y+N[y+5]),_.x=M.x+N[y+2],_.y=M.y+N[y+3],M.x+=N[y+4],M.y+=N[y+5],y===0&&k===!0&&Y.copy(M);break;case"s":N=E($);for(let y=0,ae=N.length;y<ae;y+=4)w.bezierCurveTo(S(M.x,_.x),S(M.y,_.y),M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3]),_.x=M.x+N[y+0],_.y=M.y+N[y+1],M.x+=N[y+2],M.y+=N[y+3],y===0&&k===!0&&Y.copy(M);break;case"q":N=E($);for(let y=0,ae=N.length;y<ae;y+=4)w.quadraticCurveTo(M.x+N[y+0],M.y+N[y+1],M.x+N[y+2],M.y+N[y+3]),_.x=M.x+N[y+0],_.y=M.y+N[y+1],M.x+=N[y+2],M.y+=N[y+3],y===0&&k===!0&&Y.copy(M);break;case"t":N=E($);for(let y=0,ae=N.length;y<ae;y+=2){const ce=S(M.x,_.x),Te=S(M.y,_.y);w.quadraticCurveTo(ce,Te,M.x+N[y+0],M.y+N[y+1]),_.x=ce,_.y=Te,M.x=M.x+N[y+0],M.y=M.y+N[y+1],y===0&&k===!0&&Y.copy(M)}break;case"a":N=E($,[3,4],7);for(let y=0,ae=N.length;y<ae;y+=7){if(N[y+5]==0&&N[y+6]==0)continue;const ce=M.clone();M.x+=N[y+5],M.y+=N[y+6],_.x=M.x,_.y=M.y,o(w,N[y],N[y+1],N[y+2],N[y+3],N[y+4],ce,M),y===0&&k===!0&&Y.copy(M)}break;case"Z":case"z":w.currentPath.autoClose=!0,w.currentPath.curves.length>0&&(M.copy(Y),w.currentPath.currentPoint.copy(M),se=!0);break;default:console.warn(T)}k=!1}return w}function r(W){if(!(!W.sheet||!W.sheet.cssRules||!W.sheet.cssRules.length))for(let w=0;w<W.sheet.cssRules.length;w++){const M=W.sheet.cssRules[w];if(M.type!==1)continue;const _=M.selectorText.split(/,/gm).filter(Boolean).map(Y=>Y.trim());for(let Y=0;Y<_.length;Y++){const se=Object.fromEntries(Object.entries(M.style).filter(([,k])=>k!==""));Z[_[Y]]=Object.assign(Z[_[Y]]||{},se)}}}function o(W,w,M,_,Y,se,k,le){if(w==0||M==0){W.lineTo(le.x,le.y);return}_=_*Math.PI/180,w=Math.abs(w),M=Math.abs(M);const Ae=(k.x-le.x)/2,ue=(k.y-le.y)/2,H=Math.cos(_)*Ae+Math.sin(_)*ue,T=-Math.sin(_)*Ae+Math.cos(_)*ue;let q=w*w,$=M*M;const N=H*H,y=T*T,ae=N/q+y/$;if(ae>1){const ge=Math.sqrt(ae);w=ge*w,M=ge*M,q=w*w,$=M*M}const ce=q*y+$*N,Te=(q*$-ce)/ce;let b=Math.sqrt(Math.max(0,Te));Y===se&&(b=-b);const x=b*w*T/M,z=-b*M*H/w,re=Math.cos(_)*x-Math.sin(_)*z+(k.x+le.x)/2,fe=Math.sin(_)*x+Math.cos(_)*z+(k.y+le.y)/2,ne=c(1,0,(H-x)/w,(T-z)/M),Ne=c((H-x)/w,(T-z)/M,(-H-x)/w,(-T-z)/M)%(Math.PI*2);W.currentPath.absellipse(re,fe,w,M,ne,ne+Ne,se===0,_)}function c(W,w,M,_){const Y=W*M+w*_,se=Math.sqrt(W*W+w*w)*Math.sqrt(M*M+_*_);let k=Math.acos(Math.max(-1,Math.min(1,Y/se)));return W*_-w*M<0&&(k=-k),k}function h(W){const w=A(W.getAttribute("x")||0),M=A(W.getAttribute("y")||0),_=A(W.getAttribute("rx")||W.getAttribute("ry")||0),Y=A(W.getAttribute("ry")||W.getAttribute("rx")||0),se=A(W.getAttribute("width")),k=A(W.getAttribute("height")),le=1-.551915024494,Ae=new si;return Ae.moveTo(w+_,M),Ae.lineTo(w+se-_,M),(_!==0||Y!==0)&&Ae.bezierCurveTo(w+se-_*le,M,w+se,M+Y*le,w+se,M+Y),Ae.lineTo(w+se,M+k-Y),(_!==0||Y!==0)&&Ae.bezierCurveTo(w+se,M+k-Y*le,w+se-_*le,M+k,w+se-_,M+k),Ae.lineTo(w+_,M+k),(_!==0||Y!==0)&&Ae.bezierCurveTo(w+_*le,M+k,w,M+k-Y*le,w,M+k-Y),Ae.lineTo(w,M+Y),(_!==0||Y!==0)&&Ae.bezierCurveTo(w,M+Y*le,w+_*le,M,w+_,M),Ae}function u(W){function w(se,k,le){const Ae=A(k),ue=A(le);Y===0?_.moveTo(Ae,ue):_.lineTo(Ae,ue),Y++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,_=new si;let Y=0;return W.getAttribute("points").replace(M,w),_.currentPath.autoClose=!0,_}function p(W){function w(se,k,le){const Ae=A(k),ue=A(le);Y===0?_.moveTo(Ae,ue):_.lineTo(Ae,ue),Y++}const M=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,_=new si;let Y=0;return W.getAttribute("points").replace(M,w),_.currentPath.autoClose=!1,_}function a(W){const w=A(W.getAttribute("cx")||0),M=A(W.getAttribute("cy")||0),_=A(W.getAttribute("r")||0),Y=new hi;Y.absarc(w,M,_,0,Math.PI*2);const se=new si;return se.subPaths.push(Y),se}function l(W){const w=A(W.getAttribute("cx")||0),M=A(W.getAttribute("cy")||0),_=A(W.getAttribute("rx")||0),Y=A(W.getAttribute("ry")||0),se=new hi;se.absellipse(w,M,_,Y,0,Math.PI*2);const k=new si;return k.subPaths.push(se),k}function f(W){const w=A(W.getAttribute("x1")||0),M=A(W.getAttribute("y1")||0),_=A(W.getAttribute("x2")||0),Y=A(W.getAttribute("y2")||0),se=new si;return se.moveTo(w,M),se.lineTo(_,Y),se.currentPath.autoClose=!1,se}function m(W,w){w=Object.assign({},w);let M={};if(W.hasAttribute("class")){const k=W.getAttribute("class").split(/\s/).filter(Boolean).map(le=>le.trim());for(let le=0;le<k.length;le++)M=Object.assign(M,Z["."+k[le]])}W.hasAttribute("id")&&(M=Object.assign(M,Z["#"+W.getAttribute("id")]));function _(k,le,Ae){Ae===void 0&&(Ae=function(H){return H.startsWith("url")&&console.warn("SVGLoader: url access in attributes is not implemented."),H}),W.hasAttribute(k)&&(w[le]=Ae(W.getAttribute(k))),M[k]&&(w[le]=Ae(M[k])),W.style&&W.style[k]!==""&&(w[le]=Ae(W.style[k]))}function Y(k){return Math.max(0,Math.min(1,A(k)))}function se(k){return Math.max(0,A(k))}return _("fill","fill"),_("fill-opacity","fillOpacity",Y),_("fill-rule","fillRule"),_("opacity","opacity",Y),_("stroke","stroke"),_("stroke-opacity","strokeOpacity",Y),_("stroke-width","strokeWidth",se),_("stroke-linejoin","strokeLineJoin"),_("stroke-linecap","strokeLineCap"),_("stroke-miterlimit","strokeMiterLimit",se),_("visibility","visibility"),w}function S(W,w){return W-(w-W)}function E(W,w,M){if(typeof W!="string")throw new TypeError("Invalid input: "+typeof W);const _={WHITESPACE:/[ \t\r\n]/,DIGIT:/[\d]/,SIGN:/[-+]/,POINT:/\./,COMMA:/,/,EXP:/e/i,FLAGS:/[01]/},Y=0,se=1,k=2,le=3;let Ae=Y,ue=!0,H="",T="";const q=[];function $(ce,Te,b){const x=new SyntaxError('Unexpected character "'+ce+'" at index '+Te+".");throw x.partial=b,x}function N(){H!==""&&(T===""?q.push(Number(H)):q.push(Number(H)*Math.pow(10,Number(T)))),H="",T=""}let y;const ae=W.length;for(let ce=0;ce<ae;ce++){if(y=W[ce],Array.isArray(w)&&w.includes(q.length%M)&&_.FLAGS.test(y)){Ae=se,H=y,N();continue}if(Ae===Y){if(_.WHITESPACE.test(y))continue;if(_.DIGIT.test(y)||_.SIGN.test(y)){Ae=se,H=y;continue}if(_.POINT.test(y)){Ae=k,H=y;continue}_.COMMA.test(y)&&(ue&&$(y,ce,q),ue=!0)}if(Ae===se){if(_.DIGIT.test(y)){H+=y;continue}if(_.POINT.test(y)){H+=y,Ae=k;continue}if(_.EXP.test(y)){Ae=le;continue}_.SIGN.test(y)&&H.length===1&&_.SIGN.test(H[0])&&$(y,ce,q)}if(Ae===k){if(_.DIGIT.test(y)){H+=y;continue}if(_.EXP.test(y)){Ae=le;continue}_.POINT.test(y)&&H[H.length-1]==="."&&$(y,ce,q)}if(Ae===le){if(_.DIGIT.test(y)){T+=y;continue}if(_.SIGN.test(y)){if(T===""){T+=y;continue}T.length===1&&_.SIGN.test(T)&&$(y,ce,q)}}_.WHITESPACE.test(y)?(N(),Ae=Y,ue=!1):_.COMMA.test(y)?(N(),Ae=Y,ue=!0):_.SIGN.test(y)?(N(),Ae=se,H=y):_.POINT.test(y)?(N(),Ae=k,H=y):$(y,ce,q)}return N(),q}const d=["mm","cm","in","pt","pc","px"],g={mm:{mm:1,cm:.1,in:1/25.4,pt:72/25.4,pc:6/25.4,px:-1},cm:{mm:10,cm:1,in:1/2.54,pt:72/2.54,pc:6/2.54,px:-1},in:{mm:25.4,cm:2.54,in:1,pt:72,pc:6,px:-1},pt:{mm:25.4/72,cm:2.54/72,in:1/72,pt:1,pc:6/72,px:-1},pc:{mm:25.4/6,cm:2.54/6,in:1/6,pt:72/6,pc:1,px:-1},px:{px:1}};function A(W){let w="px";if(typeof W=="string"||W instanceof String)for(let _=0,Y=d.length;_<Y;_++){const se=d[_];if(W.endsWith(se)){w=se,W=W.substring(0,W.length-se.length);break}}let M;return w==="px"&&t.defaultUnit!=="px"?M=g.in[t.defaultUnit]/t.defaultDPI:(M=g[w][t.defaultUnit],M<0&&(M=g[w].in*t.defaultDPI)),M*parseFloat(W)}function I(W){if(!(W.hasAttribute("transform")||W.nodeName==="use"&&(W.hasAttribute("x")||W.hasAttribute("y"))))return null;const w=D(W);return Q.length>0&&w.premultiply(Q[Q.length-1]),Me.copy(w),Q.push(w),w}function D(W){const w=new We,M=j;if(W.nodeName==="use"&&(W.hasAttribute("x")||W.hasAttribute("y"))){const _=A(W.getAttribute("x")||0),Y=A(W.getAttribute("y")||0);w.translate(_,Y)}if(W.hasAttribute("transform")){const _=W.getAttribute("transform").split(")");for(let Y=_.length-1;Y>=0;Y--){const se=_[Y].trim();if(se==="")continue;const k=se.indexOf("("),le=se.length;if(k>0&&k<le){const Ae=se.slice(0,k),ue=E(se.slice(k+1));switch(M.identity(),Ae){case"translate":if(ue.length>=1){const H=ue[0];let T=0;ue.length>=2&&(T=ue[1]),M.translate(H,T)}break;case"rotate":if(ue.length>=1){let H=0,T=0,q=0;H=ue[0]*Math.PI/180,ue.length>=3&&(T=ue[1],q=ue[2]),ie.makeTranslation(-T,-q),J.makeRotation(H),B.multiplyMatrices(J,ie),ie.makeTranslation(T,q),M.multiplyMatrices(ie,B)}break;case"scale":if(ue.length>=1){const H=ue[0];let T=H;ue.length>=2&&(T=ue[1]),M.scale(H,T)}break;case"skewX":ue.length===1&&M.set(1,Math.tan(ue[0]*Math.PI/180),0,0,1,0,0,0,1);break;case"skewY":ue.length===1&&M.set(1,0,0,Math.tan(ue[0]*Math.PI/180),1,0,0,0,1);break;case"matrix":ue.length===6&&M.set(ue[0],ue[2],ue[4],ue[1],ue[3],ue[5],0,0,1);break}}w.premultiply(M)}}return w}function O(W,w){function M(k){pe.set(k.x,k.y,1).applyMatrix3(w),k.set(pe.x,pe.y)}function _(k){const le=k.xRadius,Ae=k.yRadius,ue=Math.cos(k.aRotation),H=Math.sin(k.aRotation),T=new G(le*ue,le*H,0),q=new G(-Ae*H,Ae*ue,0),$=T.applyMatrix3(w),N=q.applyMatrix3(w),y=j.set($.x,N.x,0,$.y,N.y,0,0,0,1),ae=ie.copy(y).invert(),b=J.copy(ae).transpose().multiply(ae).elements,x=P(b[0],b[1],b[4]),z=Math.sqrt(x.rt1),re=Math.sqrt(x.rt2);if(k.xRadius=1/z,k.yRadius=1/re,k.aRotation=Math.atan2(x.sn,x.cs),!((k.aEndAngle-k.aStartAngle)%(2*Math.PI)<Number.EPSILON)){const ne=ie.set(z,0,0,0,re,0,0,0,1),Ne=J.set(x.cs,x.sn,0,-x.sn,x.cs,0,0,0,1),ge=ne.multiply(Ne).multiply(y),we=De=>{const{x:Ee,y:xe}=new G(Math.cos(De),Math.sin(De),0).applyMatrix3(ge);return Math.atan2(xe,Ee)};k.aStartAngle=we(k.aStartAngle),k.aEndAngle=we(k.aEndAngle),C(w)&&(k.aClockwise=!k.aClockwise)}}function Y(k){const le=R(w),Ae=v(w);k.xRadius*=le,k.yRadius*=Ae;const ue=le>Number.EPSILON?Math.atan2(w.elements[1],w.elements[0]):Math.atan2(-w.elements[3],w.elements[4]);k.aRotation+=ue,C(w)&&(k.aStartAngle*=-1,k.aEndAngle*=-1,k.aClockwise=!k.aClockwise)}const se=W.subPaths;for(let k=0,le=se.length;k<le;k++){const ue=se[k].curves;for(let H=0;H<ue.length;H++){const T=ue[H];T.isLineCurve?(M(T.v1),M(T.v2)):T.isCubicBezierCurve?(M(T.v0),M(T.v1),M(T.v2),M(T.v3)):T.isQuadraticBezierCurve?(M(T.v0),M(T.v1),M(T.v2)):T.isEllipseCurve&&(de.set(T.aX,T.aY),M(de),T.aX=de.x,T.aY=de.y,U(w)?_(T):Y(T))}}}function C(W){const w=W.elements;return w[0]*w[4]-w[1]*w[3]<0}function U(W){const w=W.elements,M=w[0]*w[3]+w[1]*w[4];if(M===0)return!1;const _=R(W),Y=v(W);return Math.abs(M/(_*Y))>Number.EPSILON}function R(W){const w=W.elements;return Math.sqrt(w[0]*w[0]+w[1]*w[1])}function v(W){const w=W.elements;return Math.sqrt(w[3]*w[3]+w[4]*w[4])}function P(W,w,M){let _,Y,se,k,le;const Ae=W+M,ue=W-M,H=Math.sqrt(ue*ue+4*w*w);return Ae>0?(_=.5*(Ae+H),le=1/_,Y=W*le*M-w*le*w):Ae<0?Y=.5*(Ae-H):(_=.5*H,Y=-.5*H),ue>0?se=ue+H:se=ue-H,Math.abs(se)>2*Math.abs(w)?(le=-2*w/se,k=1/Math.sqrt(1+le*le),se=le*k):Math.abs(w)===0?(se=1,k=0):(le=-.5*se/w,se=1/Math.sqrt(1+le*le),k=le*se),ue>0&&(le=se,se=-k,k=le),{rt1:_,rt2:Y,cs:se,sn:k}}const V=[],Z={},Q=[],j=new We,ie=new We,J=new We,B=new We,de=new oe,pe=new G,Me=new We,He=new DOMParser().parseFromString(e,"image/svg+xml");return i(He.documentElement,{fill:"#000",fillOpacity:1,strokeOpacity:1,strokeWidth:1,strokeLineJoin:"miter",strokeLineCap:"butt",strokeMiterLimit:4}),{paths:V,xml:He.documentElement}}static createShapes(e){const i={ORIGIN:0,DESTINATION:1,BETWEEN:2,LEFT:3,RIGHT:4,BEHIND:5,BEYOND:6},s={loc:i.ORIGIN,t:0};function r(S,E,d,g){const A=S.x,I=E.x,D=d.x,O=g.x,C=S.y,U=E.y,R=d.y,v=g.y,P=(O-D)*(C-R)-(v-R)*(A-D),V=(I-A)*(C-R)-(U-C)*(A-D),Z=(v-R)*(I-A)-(O-D)*(U-C),Q=P/Z,j=V/Z;if(Z===0&&P!==0||Q<=0||Q>=1||j<0||j>1)return null;if(P===0&&Z===0){for(let ie=0;ie<2;ie++)if(o(ie===0?d:g,S,E),s.loc==i.ORIGIN){const J=ie===0?d:g;return{x:J.x,y:J.y,t:s.t}}else if(s.loc==i.BETWEEN){const J=+(A+s.t*(I-A)).toPrecision(10),B=+(C+s.t*(U-C)).toPrecision(10);return{x:J,y:B,t:s.t}}return null}else{for(let B=0;B<2;B++)if(o(B===0?d:g,S,E),s.loc==i.ORIGIN){const de=B===0?d:g;return{x:de.x,y:de.y,t:s.t}}const ie=+(A+Q*(I-A)).toPrecision(10),J=+(C+Q*(U-C)).toPrecision(10);return{x:ie,y:J,t:Q}}}function o(S,E,d){const g=d.x-E.x,A=d.y-E.y,I=S.x-E.x,D=S.y-E.y,O=g*D-I*A;if(S.x===E.x&&S.y===E.y){s.loc=i.ORIGIN,s.t=0;return}if(S.x===d.x&&S.y===d.y){s.loc=i.DESTINATION,s.t=1;return}if(O<-Number.EPSILON){s.loc=i.LEFT;return}if(O>Number.EPSILON){s.loc=i.RIGHT;return}if(g*I<0||A*D<0){s.loc=i.BEHIND;return}if(Math.sqrt(g*g+A*A)<Math.sqrt(I*I+D*D)){s.loc=i.BEYOND;return}let C;g!==0?C=I/g:C=D/A,s.loc=i.BETWEEN,s.t=C}function c(S,E){const d=[],g=[];for(let A=1;A<S.length;A++){const I=S[A-1],D=S[A];for(let O=1;O<E.length;O++){const C=E[O-1],U=E[O],R=r(I,D,C,U);R!==null&&d.find(v=>v.t<=R.t+Number.EPSILON&&v.t>=R.t-Number.EPSILON)===void 0&&(d.push(R),g.push(new oe(R.x,R.y)))}}return g}function h(S,E,d){const g=new oe;E.getCenter(g);const A=[];return d.forEach(I=>{I.boundingBox.containsPoint(g)&&c(S,I.points).forEach(O=>{A.push({identifier:I.identifier,isCW:I.isCW,point:O})})}),A.sort((I,D)=>I.point.x-D.point.x),A}function u(S,E,d,g,A){(A==null||A==="")&&(A="nonzero");const I=new oe;S.boundingBox.getCenter(I);const D=[new oe(d,I.y),new oe(g,I.y)],O=h(D,S.boundingBox,E);O.sort((V,Z)=>V.point.x-Z.point.x);const C=[],U=[];O.forEach(V=>{V.identifier===S.identifier?C.push(V):U.push(V)});const R=C[0].point.x,v=[];let P=0;for(;P<U.length&&U[P].point.x<R;)v.length>0&&v[v.length-1]===U[P].identifier?v.pop():v.push(U[P].identifier),P++;if(v.push(S.identifier),A==="evenodd"){const V=v.length%2===0,Z=v[v.length-2];return{identifier:S.identifier,isHole:V,for:Z}}else if(A==="nonzero"){let V=!0,Z=null,Q=null;for(let j=0;j<v.length;j++){const ie=v[j];V?(Q=E[ie].isCW,V=!1,Z=ie):Q!==E[ie].isCW&&(Q=E[ie].isCW,V=!0)}return{identifier:S.identifier,isHole:V,for:Z}}else console.warn('fill-rule: "'+A+'" is currently not implemented.')}let p=999999999,a=-999999999,l=e.subPaths.map(S=>{const E=S.getPoints();let d=-999999999,g=999999999,A=-999999999,I=999999999;for(let D=0;D<E.length;D++){const O=E[D];O.y>d&&(d=O.y),O.y<g&&(g=O.y),O.x>A&&(A=O.x),O.x<I&&(I=O.x)}return a<=A&&(a=A+1),p>=I&&(p=I-1),{curves:S.curves,points:E,isCW:cn.isClockWise(E),identifier:-1,boundingBox:new Lf(new oe(I,g),new oe(A,d))}});l=l.filter(S=>S.points.length>1);for(let S=0;S<l.length;S++)l[S].identifier=S;const f=l.map(S=>u(S,l,p,a,e.userData?e.userData.style.fillRule:void 0)),m=[];return l.forEach(S=>{if(!f[S.identifier].isHole){const d=new Qn;d.curves=S.curves,f.filter(A=>A.isHole&&A.for===S.identifier).forEach(A=>{const I=l[A.identifier],D=new hi;D.curves=I.curves,d.holes.push(D)}),m.push(d)}}),m}static getStrokeStyle(e,t,i,s,r){return e=e!==void 0?e:1,t=t!==void 0?t:"#000",i=i!==void 0?i:"miter",s=s!==void 0?s:"butt",r=r!==void 0?r:4,{strokeColor:t,strokeWidth:e,strokeLineJoin:i,strokeLineCap:s,strokeMiterLimit:r}}static pointsToStroke(e,t,i,s){const r=[],o=[],c=[];if(Er.pointsToStrokeWithBuffers(e,t,i,s,r,o,c)===0)return null;const h=new Rt;return h.setAttribute("position",new _t(r,3)),h.setAttribute("normal",new _t(o,3)),h.setAttribute("uv",new _t(c,2)),h}static pointsToStrokeWithBuffers(e,t,i,s,r,o,c,h){const u=new oe,p=new oe,a=new oe,l=new oe,f=new oe,m=new oe,S=new oe,E=new oe,d=new oe,g=new oe,A=new oe,I=new oe,D=new oe,O=new oe,C=new oe,U=new oe,R=new oe;i=i!==void 0?i:12,s=s!==void 0?s:.001,h=h!==void 0?h:0,e=ue(e);const v=e.length;if(v<2)return 0;const P=e[0].equals(e[v-1]);let V,Z=e[0],Q;const j=t.strokeWidth/2,ie=1/(v-1);let J=0,B,de,pe,Me,He=!1,Ce=0,W=h*3,w=h*2;M(e[0],e[1],u).multiplyScalar(j),E.copy(e[0]).sub(u),d.copy(e[0]).add(u),g.copy(E),A.copy(d);for(let H=1;H<v;H++){V=e[H],H===v-1?P?Q=e[1]:Q=void 0:Q=e[H+1];const T=u;if(M(Z,V,T),a.copy(T).multiplyScalar(j),I.copy(V).sub(a),D.copy(V).add(a),B=J+ie,de=!1,Q!==void 0){M(V,Q,p),a.copy(p).multiplyScalar(j),O.copy(V).sub(a),C.copy(V).add(a),pe=!0,a.subVectors(Q,Z),T.dot(a)<0&&(pe=!1),H===1&&(He=pe),a.subVectors(Q,V),a.normalize();const q=Math.abs(T.dot(a));if(q>Number.EPSILON){const $=j/q;a.multiplyScalar(-$),l.subVectors(V,Z),f.copy(l).setLength($).add(a),U.copy(f).negate();const N=f.length(),y=l.length();l.divideScalar(y),m.subVectors(Q,V);const ae=m.length();switch(m.divideScalar(ae),l.dot(U)<y&&m.dot(U)<ae&&(de=!0),R.copy(f).add(V),U.add(V),Me=!1,de?pe?(C.copy(U),D.copy(U)):(O.copy(U),I.copy(U)):se(),t.strokeLineJoin){case"bevel":k(pe,de,B);break;case"round":le(pe,de),pe?Y(V,I,O,B,0):Y(V,C,D,B,1);break;case"miter":case"miter-clip":default:const ce=j*t.strokeMiterLimit/N;if(ce<1)if(t.strokeLineJoin!=="miter-clip"){k(pe,de,B);break}else le(pe,de),pe?(m.subVectors(R,I).multiplyScalar(ce).add(I),S.subVectors(R,O).multiplyScalar(ce).add(O),_(I,B,0),_(m,B,0),_(V,B,.5),_(V,B,.5),_(m,B,0),_(S,B,0),_(V,B,.5),_(S,B,0),_(O,B,0)):(m.subVectors(R,D).multiplyScalar(ce).add(D),S.subVectors(R,C).multiplyScalar(ce).add(C),_(D,B,1),_(m,B,1),_(V,B,.5),_(V,B,.5),_(m,B,1),_(S,B,1),_(V,B,.5),_(S,B,1),_(C,B,1));else de?(pe?(_(d,J,1),_(E,J,0),_(R,B,0),_(d,J,1),_(R,B,0),_(U,B,1)):(_(d,J,1),_(E,J,0),_(R,B,1),_(E,J,0),_(U,B,0),_(R,B,1)),pe?O.copy(R):C.copy(R)):pe?(_(I,B,0),_(R,B,0),_(V,B,.5),_(V,B,.5),_(R,B,0),_(O,B,0)):(_(D,B,1),_(R,B,1),_(V,B,.5),_(V,B,.5),_(R,B,1),_(C,B,1)),Me=!0;break}}else se()}else se();!P&&H===v-1&&Ae(e[0],g,A,pe,!0,J),J=B,Z=V,E.copy(O),d.copy(C)}if(!P)Ae(V,I,D,pe,!1,B);else if(de&&r){let H=R,T=U;He!==pe&&(H=U,T=R),pe?(Me||He)&&(T.toArray(r,0),T.toArray(r,9),Me&&H.toArray(r,3)):(Me||!He)&&(T.toArray(r,3),T.toArray(r,9),Me&&H.toArray(r,0))}return Ce;function M(H,T,q){return q.subVectors(T,H),q.set(-q.y,q.x).normalize()}function _(H,T,q){r&&(r[W]=H.x,r[W+1]=H.y,r[W+2]=0,o&&(o[W]=0,o[W+1]=0,o[W+2]=1),W+=3,c&&(c[w]=T,c[w+1]=q,w+=2)),Ce+=3}function Y(H,T,q,$,N){u.copy(T).sub(H).normalize(),p.copy(q).sub(H).normalize();let y=Math.PI;const ae=u.dot(p);Math.abs(ae)<1&&(y=Math.abs(Math.acos(ae))),y/=i,a.copy(T);for(let ce=0,Te=i-1;ce<Te;ce++)l.copy(a).rotateAround(H,y),_(a,$,N),_(l,$,N),_(H,$,.5),a.copy(l);_(l,$,N),_(q,$,N),_(H,$,.5)}function se(){_(d,J,1),_(E,J,0),_(I,B,0),_(d,J,1),_(I,B,0),_(D,B,1)}function k(H,T,q){T?H?(_(d,J,1),_(E,J,0),_(I,B,0),_(d,J,1),_(I,B,0),_(U,B,1),_(I,q,0),_(O,q,0),_(U,q,.5)):(_(d,J,1),_(E,J,0),_(D,B,1),_(E,J,0),_(U,B,0),_(D,B,1),_(D,q,1),_(U,q,0),_(C,q,1)):H?(_(I,q,0),_(O,q,0),_(V,q,.5)):(_(D,q,1),_(C,q,0),_(V,q,.5))}function le(H,T){T&&(H?(_(d,J,1),_(E,J,0),_(I,B,0),_(d,J,1),_(I,B,0),_(U,B,1),_(I,J,0),_(V,B,.5),_(U,B,1),_(V,B,.5),_(O,J,0),_(U,B,1)):(_(d,J,1),_(E,J,0),_(D,B,1),_(E,J,0),_(U,B,0),_(D,B,1),_(D,J,1),_(U,B,0),_(V,B,.5),_(V,B,.5),_(U,B,0),_(C,J,1)))}function Ae(H,T,q,$,N,y){switch(t.strokeLineCap){case"round":N?Y(H,q,T,y,.5):Y(H,T,q,y,.5);break;case"square":if(N)u.subVectors(T,H),p.set(u.y,-u.x),a.addVectors(u,p).add(H),l.subVectors(p,u).add(H),$?(a.toArray(r,3),l.toArray(r,0),l.toArray(r,9)):(a.toArray(r,3),c[7]===1?l.toArray(r,9):a.toArray(r,9),l.toArray(r,0));else{u.subVectors(q,H),p.set(u.y,-u.x),a.addVectors(u,p).add(H),l.subVectors(p,u).add(H);const ae=r.length;$?(a.toArray(r,ae-3),l.toArray(r,ae-6),l.toArray(r,ae-12)):(l.toArray(r,ae-6),a.toArray(r,ae-3),l.toArray(r,ae-12))}break}}function ue(H){let T=!1;for(let $=1,N=H.length-1;$<N;$++)if(H[$].distanceTo(H[$+1])<s){T=!0;break}if(!T)return H;const q=[];q.push(H[0]);for(let $=1,N=H.length-1;$<N;$++)H[$].distanceTo(H[$+1])>=s&&q.push(H[$]);return q.push(H[H.length-1]),q}}}function y0(n,e=!1){const t=n[0].index!==null,i=new Set(Object.keys(n[0].attributes)),s=new Set(Object.keys(n[0].morphAttributes)),r={},o={},c=n[0].morphTargetsRelative,h=new Rt;let u=0;for(let p=0;p<n.length;++p){const a=n[p];let l=0;if(t!==(a.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const f in a.attributes){if(!i.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(a.attributes[f]),l++}if(l!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". Make sure all geometries have the same number of attributes."),null;if(c!==a.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const f in a.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+".  .morphAttributes must be consistent throughout all geometries."),null;o[f]===void 0&&(o[f]=[]),o[f].push(a.morphAttributes[f])}if(e){let f;if(t)f=a.index.count;else if(a.attributes.position!==void 0)f=a.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". The geometry must have either an index or a position attribute"),null;h.addGroup(u,f,p),u+=f}}if(t){let p=0;const a=[];for(let l=0;l<n.length;++l){const f=n[l].index;for(let m=0;m<f.count;++m)a.push(f.getX(m)+p);p+=n[l].attributes.position.count}h.setIndex(a)}for(const p in r){const a=Jl(r[p]);if(!a)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" attribute."),null;h.setAttribute(p,a)}for(const p in o){const a=o[p][0].length;if(a===0)break;h.morphAttributes=h.morphAttributes||{},h.morphAttributes[p]=[];for(let l=0;l<a;++l){const f=[];for(let S=0;S<o[p].length;++S)f.push(o[p][S][l]);const m=Jl(f);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" morphAttribute."),null;h.morphAttributes[p].push(m)}}return h}function Jl(n){let e,t,i,s=-1,r=0;for(let u=0;u<n.length;++u){const p=n[u];if(e===void 0&&(e=p.array.constructor),e!==p.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=p.itemSize),t!==p.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=p.normalized),i!==p.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=p.gpuType),s!==p.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=p.count*t}const o=new e(r),c=new un(o,t,i);let h=0;for(let u=0;u<n.length;++u){const p=n[u];if(p.isInterleavedBufferAttribute){const a=h/t;for(let l=0,f=p.count;l<f;l++)for(let m=0;m<t;m++){const S=p.getComponent(l,m);c.setComponent(l+a,m,S)}}else o.set(p.array,h);h+=p.count*t}return s!==void 0&&(c.gpuType=s),c}const O0={A:{horizAdvX:1325,d:"M1108 0l-162 435h-573l-160 -435h-213l558 1468h210l555 -1468h-215zM889 613l-154 431q-7 22 -21.5 66t-29 91t-23.5 78q-10 -41 -23 -86.5t-25.5 -85t-20.5 -63.5l-156 -431h453z"},B:{horizAdvX:1336,d:"M196 1462h424q279 0 420 -82t141 -281q0 -85 -31 -152t-90 -111t-145 -60v-10q90 -15 160 -54t110.5 -110.5t40.5 -183.5q0 -134 -63 -227.5t-178.5 -142t-274.5 -48.5h-514v1462zM401 847h255q177 0 245 58t68 169q0 115 -81 165.5t-257 50.5h-230v-443zM401 678v-505 h279q181 0 255.5 71t74.5 191q0 76 -33.5 130.5t-108.5 83.5t-202 29h-265z"},C:{horizAdvX:1294,d:"M820 1306q-113 0 -202.5 -39.5t-151.5 -115t-95 -181.5t-33 -239q0 -177 52.5 -306t158.5 -199t267 -70q96 0 183.5 17.5t174.5 45.5v-176q-84 -32 -173.5 -47.5t-209.5 -15.5q-224 0 -372.5 93t-221.5 261.5t-73 397.5q0 166 46 303.5t135 238t218.5 155t298.5 54.5 q110 0 214.5 -23.5t192.5 -65.5l-76 -171q-73 33 -156.5 58t-176.5 25z"},D:{horizAdvX:1494,d:"M1370 745q0 -247 -91 -412.5t-263.5 -249t-418.5 -83.5h-401v1462h446q224 0 387 -81.5t252 -241t89 -394.5zM1155 739q0 188 -61 310t-179 181.5t-289 59.5h-225v-1116h189q283 0 424 142t141 423z"},E:{horizAdvX:1140,d:"M1017 0h-821v1462h821v-176h-616v-435h579v-174h-579v-500h616v-177z"},F:{horizAdvX:1074,d:"M400 0h-204v1462h820v-176h-616v-496h578v-175h-578v-615z"},G:{horizAdvX:1488,d:"M804 780h528v-721q-115 -39 -237 -59t-274 -20q-226 0 -381 90t-235.5 258t-80.5 404q0 227 89 396t259 262t410 93q120 0 230.5 -23t203.5 -64l-74 -173q-78 35 -172.5 59.5t-195.5 24.5q-168 0 -288.5 -71t-185 -200t-64.5 -306q0 -173 54 -302t169 -201t296 -72 q91 0 155.5 10t118.5 24v412h-325v179z"},H:{horizAdvX:1524,d:"M1327 0h-205v675h-721v-675h-205v1462h205v-610h721v610h205v-1462z"},I:{horizAdvX:599,d:"M196 0v1462h205v-1462h-205z"},J:{horizAdvX:582,d:"M0 -396q-53 0 -93 7t-68 18v173q32 -9 69 -15t79 -6q56 0 102 22t73 76t27 150v1433h206v-1423q0 -149 -48.5 -245.5t-137.5 -143t-209 -46.5z"},K:{horizAdvX:1281,d:"M1281 0h-239l-491 687l-150 -128v-559h-205v1462h205v-714q51 60 103.5 119t104.5 119l419 476h235l-564 -637z"},L:{horizAdvX:1091,d:"M196 0v1462h205v-1284h635v-178h-840z"},M:{horizAdvX:1864,d:"M833 0l-456 1257h-8q3 -41 6.5 -105.5t6 -140t2.5 -148.5v-863h-188v1462h295l433 -1191h7l444 1191h293v-1462h-198v875q0 66 2 137.5t5.5 136t6.5 106.5h-9l-467 -1255h-175z"},N:{horizAdvX:1573,d:"M1378 0h-246l-757 1198h-8q3 -54 7 -118.5t6.5 -135t3.5 -142.5v-802h-188v1462h244l754 -1192h7q-2 44 -5 109t-5.5 137.5t-2.5 137.5v808h190v-1462z"},O:{horizAdvX:1602,d:"M1479 733q0 -169 -43 -307.5t-127.5 -238t-211 -153.5t-295.5 -54q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5t152 -200t261.5 -70.5q161 0 263 70.5 t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},P:{horizAdvX:1246,d:"M599 1462q283 0 413.5 -113t130.5 -321q0 -94 -30 -178.5t-97.5 -149t-177.5 -102t-270 -37.5h-167v-561h-205v1462h403zM583 1290h-182v-556h145q127 0 213 28.5t130 91.5t44 166q0 136 -85 203t-265 67z"},Q:{horizAdvX:1602,d:"M1479 733q0 -176 -46.5 -319t-139 -243.5t-230.5 -149.5l346 -369h-282l-279 330q-12 0 -23 -1t-23 -1q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5 t152 -200t261.5 -70.5q161 0 263 70.5t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},R:{horizAdvX:1286,d:"M599 1462q185 0 305.5 -45.5t179.5 -138t59 -234.5q0 -112 -41 -189t-107.5 -126t-142.5 -77l409 -652h-235l-356 598h-269v-598h-205v1462h403zM586 1288h-185v-519h199q173 0 253 67.5t80 199.5q0 137 -85 194.5t-262 57.5z"},S:{horizAdvX:1124,d:"M1031 393q0 -130 -64.5 -222.5t-181.5 -141.5t-278 -49q-81 0 -154.5 8.5t-136.5 24.5t-114 40v194q83 -34 192 -63.5t225 -29.5q101 0 169.5 27.5t103.5 77.5t35 120t-34 117.5t-107.5 87.5t-192.5 85q-83 30 -151 68.5t-117.5 88.5t-76.5 117.5t-27 155.5 q0 121 59.5 207t166.5 131.5t248 45.5q116 0 216.5 -23t191.5 -63l-65 -170q-85 35 -171 57t-178 22q-85 0 -143.5 -25t-89 -71t-30.5 -109q0 -71 32 -118t101 -85t180 -81q125 -48 212.5 -102t133.5 -130t46 -192z"},T:{horizAdvX:1143,d:"M674 0h-206v1285h-444v177h1093v-177h-443v-1285z"},U:{horizAdvX:1507,d:"M1323 1462v-946q0 -154 -63.5 -275t-191.5 -191t-322 -70q-275 0 -419.5 147.5t-144.5 392.5v942h206v-934q0 -185 92.5 -279t275.5 -94q126 0 206 45.5t118.5 129t38.5 198.5v934h204z"},V:{horizAdvX:1249,d:"M1249 1462l-518 -1462h-213l-518 1462h212l325 -940q18 -49 34 -103.5t30 -108.5t23 -99q9 45 22.5 99t30.5 109.5t34 105.5l324 937h214z"},W:{horizAdvX:1913,d:"M1891 1462l-386 -1462h-217l-267 930q-11 37 -22 80t-21.5 85.5t-17.5 76.5t-10 52q-2 -18 -8.5 -51.5t-15.5 -75.5t-20 -85.5t-22 -82.5l-261 -929h-216l-384 1462h209l223 -887q11 -44 21.5 -89.5t19.5 -91t16 -88t13 -80.5q5 39 13 83.5t17.5 90.5t20.5 91t23 86 l250 885h205l259 -890q12 -42 23.5 -88t21 -92t17 -88t13.5 -78q7 50 17.5 108t24.5 120t28 122l223 886h210z"},X:{horizAdvX:1229,d:"M1224 0h-234l-381 621l-386 -621h-218l486 760l-453 702h227l353 -569l352 569h219l-454 -704z"},Y:{horizAdvX:1178,d:"M590 762l368 700h220l-486 -894v-568h-205v559l-487 903h224z"},Z:{horizAdvX:1176,d:"M1104 0h-1033v146l765 1138h-740v178h988v-146l-766 -1138h786v-178z"},GREATER:{horizAdvX:1171,d:"M99 403l759 319l-759 357v171l970 -481v-107l-970 -429v170z"}},mr=3e3,or=new Map;vo("tile-glyph-geometries",b0);async function b0(){or.clear(),or.set(" ",{side:new Rt,back:new Rt});for(const[n,e]of Object.entries(O0)){const t=C0(D0(e.d,e.horizAdvX));or.set(n,t)}}function $l(n){const e=n.toUpperCase(),t=or.get(e);if(!t)throw new Error(`Tile symbol geometry not preloaded for letter: ${e}`);return t}function C0(n){const t=new Er().parse(n),i=[],s=[],r=new Qn;r.moveTo(0,0),r.lineTo(24,0),r.lineTo(24,24),r.lineTo(0,24),r.closePath(),t.paths.forEach(m=>{Er.createShapes(m).forEach(E=>{const d=new _o(E,{depth:.1*mr,bevelEnabled:!1}),{side:g,back:A}=N0(d);i.push(g),s.push(A),r.holes.push(new hi(E.getPoints(12))),E.holes.forEach(I=>{const D=new Qn(I.getPoints(12));new go(D).translate(0,0,2)})})});const o=jl(i,"side"),c=jl(s,"back"),h=Jn/mr;o.scale(h,-h,h),c.scale(h,-h,h),o.rotateX(Math.PI/2),c.rotateX(Math.PI/2),o.computeBoundingBox();const u=o.boundingBox;if(!u)throw new Error("Failed to compute symbol bounds");const p=new G;u.getCenter(p);const a=-p.x,l=-u.max.y,f=-p.z;return o.translate(a,l,f),c.translate(a,l,f),{side:o,back:c}}function D0(n,e){return`
    <svg width="800px" height="800px" viewBox="0 0 ${mr} ${mr}" 
    version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <title>font_fill</title>
        <g fill-rule="evenodd">
            <path d="${n}">
          /path>
        </g>
    </svg>
  `}function N0(n){const t=n.toNonIndexed().getAttribute("position"),i=[],s=[],r=new G,o=new G,c=new G,h=new G,u=new G,p=new G;let a=-1/0;for(let m=0;m<t.count;m+=1)a=Math.max(a,t.getZ(m));for(let m=0;m<t.count;m+=3){if(r.fromBufferAttribute(t,m),o.fromBufferAttribute(t,m+1),c.fromBufferAttribute(t,m+2),h.subVectors(o,r),u.subVectors(c,r),p.crossVectors(h,u).normalize(),!(Math.abs(p.z)>.9)){i.push(r.x,r.y,r.z,o.x,o.y,o.z,c.x,c.y,c.z);continue}const E=(r.z+o.z+c.z)/3;Math.abs(E-a)<=.001&&s.push(r.x,r.y,r.z,o.x,o.y,o.z,c.x,c.y,c.z)}const l=new Rt;l.setAttribute("position",new _t(i,3)),l.computeVertexNormals();const f=new Rt;return f.setAttribute("position",new _t(s,3)),f.computeVertexNormals(),{side:l,back:f}}function jl(n,e){const t=y0(n);if(!t)throw new Error(`Failed to merge ${e} SVG geometries`);return t}const je=Jn,Pt=TS;function qi(n,e,t,i,s,r){const o=n.length/3;n.push(...t,...i,...s,...r),e.push(o,o+1,o+2,o,o+2,o+3)}function $c(n,e){const t=new Rt;return t.setAttribute("position",new _t(n,3)),t.setIndex(e),t.computeVertexNormals(),t}const jc=[],eu=[],Zi=[],Qi=[];qi(jc,eu,[0,Pt,0],[je,Pt,0],[je,Pt,je],[0,Pt,je]);qi(Zi,Qi,[je,0,0],[0,0,0],[0,Pt,0],[je,Pt,0]);qi(Zi,Qi,[0,0,je],[je,0,je],[je,Pt,je],[0,Pt,je]);qi(Zi,Qi,[0,0,0],[0,0,je],[0,Pt,je],[0,Pt,0]);qi(Zi,Qi,[je,0,je],[je,0,0],[je,Pt,0],[je,Pt,je]);qi(Zi,Qi,[0,0,0],[je,0,0],[je,0,je],[0,0,je]);const P0=$c(jc,eu),U0=$c(Zi,Qi),oa=.08,tu=new Ei(je+oa*2,Pt+oa*2,je+oa*2);tu.translate(je/2,Pt/2,je/2);const Es=class Es{constructor(e){me(this,"group");me(this,"pickableMesh");me(this,"_topMesh");me(this,"_sideMesh");me(this,"_symbolSideMesh");me(this,"_symbolBackMesh");me(this,"slotPos");me(this,"slotQuat");me(this,"_isVisible",!1);me(this,"animOffset",0);this.glyph=e;const t=new Kt({color:11184810,side:Lt,depthTest:!1,depthWrite:!1}),i=new Kt({color:0,depthTest:!1,depthWrite:!1}),s=new Kt({color:0,depthTest:!1,depthWrite:!1,side:An}),r=new Kt({color:5592405,depthTest:!1,depthWrite:!1,side:An}),o=new Tt(P0,t),c=new Tt(U0,i),h=$l(e),u=new Tt(h.side,s),p=new Tt(h.back,r),a=new Cn;a.add(p,u),a.position.set(je/2,Pt+1e-4,je/2);const l=new Kt({color:16777215,depthTest:!1,depthWrite:!1,visible:!1}),f=new Tt(tu,l);f.userData.glyph=e;const m=new Cn;m.add(o,c,a,f),m.position.set(-je/2,0,-je/2);const S=!1;for(const E of[o,c,a])E.visible=S;this.group=m,this._symbolSideMesh=u,this._symbolBackMesh=p,this._topMesh=o,this._sideMesh=c,this.pickableMesh=f,this.pickableMesh.userData["scrabble-tile"]=this,this.updateRenderOrder()}updateRenderOrder(e=0){this._topMesh.renderOrder=10+e,this._sideMesh.renderOrder=9+e,this._symbolSideMesh.renderOrder=11+e,this._symbolBackMesh.renderOrder=12+e,this.pickableMesh.renderOrder=8}randomizeLetter(){const e=Es._LETTERS[Math.floor(Math.random()*Es._LETTERS.length)];this.setLetter(e)}setLetter(e){this.glyph=e,this.pickableMesh.userData.glyph=e;const t=$l(e);t&&(this._symbolSideMesh.geometry=t.side,this._symbolBackMesh.geometry=t.back)}get isVisible(){return this._isVisible}set isVisible(e){this._isVisible=e,this.glyph===" "&&(e=!1);for(const t of this.group.children)t.visible=e;this.pickableMesh.visible=!0}toggle(){this._isVisible?this.hide():this.show()}hide(){this.isVisible=!1}show(){this.isVisible=!0}set anim(e){e+=this.animOffset;const t=-.3;e=t+e*(1-2*t),e=Math.max(0,Math.min(1,e));const i=(1-e)*30,s=-(1-e)*30;this.group.position.y=this.slotPos.y+i,this.group.position.z=this.slotPos.z+s}};me(Es,"_LETTERS","ABCDEFGHIJKLMNOPQRSTUVWXYZ");let ds=Es;const js=Math.PI*2;function Wt(n){const e=Math.sin(n*127.1+311.7)*43758.5453123;return e-Math.floor(e)}function ec(n,e,t){return Math.max(e,Math.min(t,n))}const Ni=class Ni{constructor(){me(this,"_seeds",[]);me(this,"_timeMs",0);me(this,"_blend",1)}update(e,t,i){if(this._ensureMaskSeeds(i),this._timeMs+=e,t){this._blend=Math.min(1,this._blend+e/Ni._BLEND_IN_DURATION);return}this._blend=Math.max(0,this._blend-e/Ni._BLEND_OUT_DURATION)}getBlend(){return this._blend}getMaskPose(e,t,i,s,r){const o=this._seeds[e];if(!o||t<=0||i<=0)return{x:0,y:0,angle:0};const c=this._timeMs*1e-4,h=o.anchorXNorm*t+Math.sin(c*o.freqX+o.phaseX)*o.ampXNorm*t+Math.sin(c*o.driftFreq+o.driftPhase)*.03*t,u=o.anchorYNorm*i+Math.cos(c*o.freqY+o.phaseY)*o.ampYNorm*i+Math.cos(c*(o.driftFreq*.73)+o.driftPhase)*.025*i,p=s*.5,a=r*.5,l=8,f=ec(h,p+l,t-p-l),m=ec(u,a+l,i-a-l),S=Math.sin(c*o.spinFreq+o.spinPhase)*o.spinAmpRad;return{x:f-p,y:m-a,angle:S}}_ensureMaskSeeds(e){for(let t=this._seeds.length;t<e;t+=1)this._seeds.push(this._buildSeed(t))}_buildSeed(e){const t=(e+1)*17*Math.random();return{anchorXNorm:.2+Wt(t+1)*.6,anchorYNorm:.2+Wt(t+2)*.6,ampXNorm:.05+Wt(t+3)*.1,ampYNorm:.04+Wt(t+4)*.09,freqX:.45+Wt(t+5)*.95,freqY:.4+Wt(t+6)*.85,phaseX:Wt(t+7)*js,phaseY:Wt(t+8)*js,driftFreq:.15+Wt(t+9)*.35,driftPhase:Wt(t+10)*js,spinFreq:.55+Wt(t+11)*.8,spinPhase:Wt(t+12)*js,spinAmpRad:.18+Wt(t+13)*.36}}};me(Ni,"_BLEND_IN_DURATION",350),me(Ni,"_BLEND_OUT_DURATION",2e3);let so=Ni;const ci=6,nu=(ci-1)*(ci-1),ps={entrance:new WeakMap,exit:new WeakMap},w0={entrance:new WeakMap,exit:new WeakMap};function Rr(n){return n?"exit":"entrance"}function Is(n,e){const t=w0[e];let i=t.get(n);return i||(i=[],t.set(n,i)),i}function F0(n,e){const t=window.innerWidth,i=window.innerHeight;return{app:n,kind:e,w:t,h:i,phase:"render",pixels:new Uint8Array(t*i*4),flipped:new Uint8ClampedArray(t*i*4),flipY:0,quadIndex:0,coveredNonBg:new Uint8Array(t*i),leftoverVisited:new Uint8Array(t*i),leftoverScanIndex:0,leftoverQueue:[],leftoverQueueRead:0,leftoverComponentPixels:[],leftoverBounds:null}}function Lo(n,e,t){return n===204&&e===204&&t===204}function B0(n){return n.phase==="render"?1:n.phase==="flip"?20*Math.min(1,n.flipY/Math.max(1,n.h)):n.phase==="build-quads"?20+80*Math.min(1,n.quadIndex/nu):n.phase==="build-leftovers"?80+20*Math.min(1,n.leftoverScanIndex/Math.max(1,n.w*n.h)):100}function H0(n){const{app:e,w:t,h:i}=n,s=new wn(t,i);if(s.texture.colorSpace=Nt,e._renderer.setRenderTarget(s),n.kind==="entrance"){for(const r of e._allTiles)r.hide();e._renderer.render(e._scene,e._nextCamera);for(const r of e._allTiles)r.show()}else e._renderer.render(e._scene,e._camera);e._renderer.setRenderTarget(null),e._renderer.readRenderTargetPixels(s,0,0,t,i,n.pixels),s.dispose(),n.phase="flip"}function G0(n,e){const{w:t,h:i}=n;for(;n.flipY<i;n.flipY++){const o=(i-1-n.flipY)*t*4,c=n.flipY*t*4;if(n.flipped.set(n.pixels.subarray(o,o+t*4),c),(n.flipY&31)===0&&performance.now()>=e)return!1}const s=document.getElementById("buffer-canvas");s.width=t,s.height=i;const r=Uint8ClampedArray.from(n.flipped);return s.getContext("2d").putImageData(new ImageData(r,t,i),0,0),n.phase="build-quads",n.quadIndex=0,!0}function V0(n,e,t,i){const s=n.clone().project(e);return new oe((s.x+1)/2*t,(1-s.y)/2*i)}function tc(n,e,t,i,s){const r=s.x-t.x,o=s.y-t.y,c=i.x-t.x,h=i.y-t.y,u=n-t.x,p=e-t.y,a=r*r+o*o,l=r*c+o*h,f=r*u+o*p,m=c*c+h*h,S=c*u+h*p,E=a*m-l*l;if(E===0)return!1;const d=1/E,g=(m*f-l*S)*d,A=(a*S-l*f)*d;return g>=0&&A>=0&&g+A<=1}function k0(n,e,t){return tc(n,e,t[0],t[1],t[2])||tc(n,e,t[0],t[2],t[3])}function Y0(n,e){const{app:t,w:i,h:s,flipped:r}=n,o=1.5*Math.hypot(i/2,s/2),c=n.kind,h=Is(t,c),u=c==="entrance"?t._nextCamera:t._camera,p=Math.floor(e/(ci-1)),a=e%(ci-1),l=p*ci+a,f=[cs[l],cs[l+1],cs[l+ci+1],cs[l+ci]];if(f.some(Ce=>!Ce))return null;const m=f.map(Ce=>V0(Ce,u,i,s)),S=Math.max(0,Math.floor(Math.min(...m.map(Ce=>Ce.x)))),E=Math.max(0,Math.floor(Math.min(...m.map(Ce=>Ce.y)))),d=Math.min(i-1,Math.ceil(Math.max(...m.map(Ce=>Ce.x)))),g=Math.min(s-1,Math.ceil(Math.max(...m.map(Ce=>Ce.y))));if(d<S||g<E)return null;const A=d-S+1,I=g-E+1,D=new OffscreenCanvas(A,I),O=D.getContext("2d"),C=O.createImageData(A,I),U=C.data;for(let Ce=E;Ce<=g;Ce++)for(let W=S;W<=d;W++){if(!k0(W+.5,Ce+.5,m))continue;const w=((Ce-E)*A+(W-S))*4,M=(Ce*i+W)*4,_=r[M],Y=r[M+1],se=r[M+2],k=r[M+3];U[w]=_,U[w+1]=Y,U[w+2]=se,U[w+3]=k,Lo(_,Y,se)?U[w+3]=0:n.coveredNonBg[Ce*i+W]=1}O.putImageData(C,0,0);const R=new G;for(const Ce of f)R.add(Ce);R.divideScalar(f.length);const v=(S+d)/2,P=(E+g)/2,V=new Ro,Z=new oe,Q=Math.floor(v),j=Math.floor(P);Z.set(Q/i*2-1,-(j/s)*2+1),V.setFromCamera(Z,u);const ie=[],J=ie.length>0?ie[0].point.clone():R;let B=0,de=0,pe=0,Me=0;if(J){const Ce=J.clone().project(u),W=(Ce.x+1)/2*i,w=(1-Ce.y)/2*s;B=S-(W-D.width/2),de=E-(w-D.height/2);const M=v-i/2,_=P-s/2;let Y=2*Math.hypot(M,_)+Math.random()*100;Y=Math.max(Y,o);const se=Math.atan2(_,M),k=se+Math.PI/2,le=1e3;pe=Y*Math.cos(se)+le*Math.cos(k),Me=Y*Math.sin(se)+le*Math.sin(k)}const He={filterColor:"#ffffff",canvas:D,x:S,y:E,worldPos:J,restOffsetX:B,restOffsetY:de,animOffsetX:pe,animOffsetY:Me,restAngle:-Math.PI+2*Math.random()*Math.PI};return h.push(He),He}function W0(n,e){for(;n.quadIndex<nu;n.quadIndex++){if(performance.now()>=e)return!1;Y0(n,n.quadIndex)}return n.phase="build-leftovers",n.leftoverScanIndex=0,n.leftoverVisited.fill(0),n.leftoverQueue.length=0,n.leftoverQueueRead=0,n.leftoverComponentPixels.length=0,n.leftoverBounds=null,!0}function z0(n){const e=n.leftoverBounds;if(!e||n.leftoverComponentPixels.length===0)return;const{app:t,w:i,h:s,flipped:r}=n,o=e.maxX-e.minX+1,c=e.maxY-e.minY+1,h=new OffscreenCanvas(o,c),u=h.getContext("2d"),p=u.createImageData(o,c),a=p.data;for(const O of n.leftoverComponentPixels){const C=O%i,U=O/i|0,R=O*4,v=((U-e.minY)*o+(C-e.minX))*4;a[v]=r[R],a[v+1]=r[R+1],a[v+2]=r[R+2],a[v+3]=r[R+3]}u.putImageData(p,0,0);const l=(e.minX+e.maxX)/2,f=(e.minY+e.maxY)/2,m=l-i/2,S=f-s/2,E=2*Math.hypot(m,S)+Math.random()*100,d=Math.atan2(S,m),g=new G(0,0,0),A=g.clone().project(n.kind==="entrance"?t._nextCamera:t._camera),I=(A.x+1)/2*i,D=(1-A.y)/2*s;Is(t,n.kind).push({filterColor:"#ffffff",canvas:h,x:e.minX,y:e.minY,worldPos:g,restOffsetX:e.minX-(I-h.width/2),restOffsetY:e.minY-(D-h.height/2),animOffsetX:E*Math.cos(d),animOffsetY:E*Math.sin(d),restAngle:-Math.PI+2*Math.random()*Math.PI})}function K0(n,e){const{w:t,h:i,flipped:s}=n;for(;n.leftoverScanIndex<t*i;n.leftoverScanIndex++){const r=n.leftoverScanIndex;if(n.leftoverVisited[r])continue;const o=r*4,c=s[o],h=s[o+1],u=s[o+2],p=s[o+3];if(n.leftoverVisited[r]=1,!(p>0&&!Lo(c,h,u))||n.coveredNonBg[r]){if((r&511)===0&&performance.now()>=e)return!1;continue}const l=r%t,f=r/t|0;return n.leftoverQueue.length=0,n.leftoverQueue.push(r),n.leftoverQueueRead=0,n.leftoverComponentPixels.length=0,n.leftoverComponentPixels.push(r),n.leftoverBounds={minX:l,maxX:l,minY:f,maxY:f},!0}return!0}function X0(n,e){const{w:t,h:i,flipped:s}=n,r=n.leftoverBounds;if(!r)return!0;for(;n.leftoverQueueRead<n.leftoverQueue.length;){const o=n.leftoverQueue[n.leftoverQueueRead++],c=o%t,h=o/t|0;c<r.minX&&(r.minX=c),c>r.maxX&&(r.maxX=c),h<r.minY&&(r.minY=h),h>r.maxY&&(r.maxY=h);const u=[o-1,o+1,o-t,o+t];for(let p=0;p<u.length;p++){const a=u[p];if(p===0&&c===0||p===1&&c===t-1||p===2&&h===0||p===3&&h===i-1||a<0||a>=t*i||n.leftoverVisited[a])continue;n.leftoverVisited[a]=1;const l=a*4,f=s[l],m=s[l+1],S=s[l+2];!(s[l+3]>0&&!Lo(f,m,S))||n.coveredNonBg[a]||(n.leftoverQueue.push(a),n.leftoverComponentPixels.push(a))}if((n.leftoverQueueRead&255)===0&&performance.now()>=e)return!1}return z0(n),n.leftoverQueue.length=0,n.leftoverQueueRead=0,n.leftoverComponentPixels.length=0,n.leftoverBounds=null,!0}function q0(n,e){for(;performance.now()<e;){if(n.leftoverBounds){if(!X0(n,e))return!1;continue}if(!K0(n,e))return!1;if(n.leftoverScanIndex>=n.w*n.h&&!n.leftoverBounds)return n.phase="done",!0}return!1}function Z0(n,e){for(;performance.now()<e;){if(n.phase==="render"){H0(n);continue}if(n.phase==="flip"){if(!G0(n,e))return!1;continue}if(n.phase==="build-quads"){if(!W0(n,e))return!1;continue}if(n.phase==="build-leftovers"){if(!q0(n,e))return!1;continue}if(n.phase==="done")return!0}return n.phase==="done"}function iu(n,e=!1){const t=Rr(e);Is(n,t).length=0,ps[t].set(n,F0(n,t))}function Q0(n,e=5,t=!1){const i=Rr(t);ps[i].has(n)||iu(n,t);const s=ps[i].get(n);if(!s)return!0;const r=Z0(s,performance.now()+Math.max(0,e));return r&&ps[i].delete(n),r}function J0(n,e=!1){const t=Rr(e),i=ps[t].get(n);return i?B0(i):Is(n,t).length>0?100:0}function $0(n,e=!1){return Is(n,Rr(e))}class j0 extends Io{constructor(t){super();me(this,"shouldSkipTileExit",!0);this._isExit=t}begin(t){iu(t,this._isExit)}incremental(t,i=5){return Q0(t,i,this._isExit)}getPercentComplete(t){return J0(t,this._isExit)}getMasks(t){return $0(t,this._isExit)}}const su="#cccccc",yo=new Ms(10,10);yo.rotateX(-Math.PI/2-.05);yo.rotateZ(.01);const eA=new Kt({color:su}),as=new Tt(yo,eA);class tA extends Io{constructor(){super();me(this,"hasRenderedScene",!0);me(this,"duration",500)}begin(t){}initMeshes(t){t._scene.add(as),as.visible=!1}updateMeshes(t,i){as.visible=!0,as.position.y=.6-i*1}cleanupMeshes(t){as.visible=!1}incremental(t,i){return!0}getPercentComplete(t){return 100}getMasks(t){return[]}}const it=class it{constructor(){me(this,"gameState","loading");me(this,"_appGfx");me(this,"_canvas");me(this,"_renderer");me(this,"_scene");me(this,"_boardGroup");me(this,"_trayGroup");me(this,"_allTilesGroup");me(this,"_uiTiles",[]);me(this,"_scrabbleTiles",[]);me(this,"_allTiles");me(this,"_pickableMeshes",[]);me(this,"_raycaster",new Ro);me(this,"_pointer",new oe);me(this,"_hoveredPickable",null);me(this,"_camera");me(this,"_nextCamera");me(this,"_controls");me(this,"_renderPixelScale",1);me(this,"_entranceMaskAnimation");me(this,"_allExitAnimations",[]);me(this,"_exitMaskAnimation");me(this,"_animVec",new G);me(this,"_trayVisibilityBounds",new Ki(it._TRAY_VISIBILITY_BOX_MIN.clone(),it._TRAY_VISIBILITY_BOX_MAX.clone()));me(this,"_trayCorner",new G);me(this,"_cameraOffset",new G);me(this,"_trayBoundsDebugMesh");me(this,"_focusTargetPos",new G);me(this,"_titleScreenDance",new so);me(this,"_animT",0);me(this,"_camT",0);me(this,"_tileT",0);me(this,"_nextEntranceT",0);me(this,"_nextExitT",0);me(this,"_tileExitT",1);me(this,"_exitT",0);me(this,"_canGotoNextLevel",!1);me(this,"_isGotoNextLevelQueued",!1);me(this,"_focusTimeMs",0);me(this,"_focusedTile",null);me(this,"_returningTiles",[]);me(this,"slotPos");me(this,"slotQuat");me(this,"_dragStartTime",0);me(this,"_dragStartPos",new oe);me(this,"_isDragging",!1);me(this,"_draggingPos",new G(0,0,0));me(this,"_targetIntersection",new G);me(this,"_dragPlane",new yn(new G(0,-1,0),2));me(this,"dt",0);me(this,"_didFinishEntrance",!1);me(this,"_didSolvePuzzle",!1);const e=document.getElementById("app-canvas");if(!e)throw new Error("Missing #app-canvas");this._canvas=e,this._renderer=new ES({canvas:e,antialias:!1}),this._renderer.autoClear=!1,this._renderer.setSize(window.innerWidth,window.innerHeight),this._renderer.shadowMap.enabled=!1,this._canvas.style.imageRendering="crisp-edges",this._canvas.style.imageRendering="pixelated",this._scene=new Nh,this._scene.background=new et(su),this._camera=it.newCamera(),this._camera.position.copy(it._CAM_START),this._camera.lookAt(0,0,0),this._nextCamera=this._camera,this._controls=new VS(this._camera,this._canvas),this._controls.enableDamping=!0,this._controls.dampingFactor=.08,this._controls.maxPolarAngle=Math.PI*.48,this._controls.target.set(0,0,0),this._controls.enabled=!1,this._appGfx=new e0(this),this._appGfx.onResize(),this._boardGroup=i0(),this._trayGroup=MS(),this._trayGroup.position.set(0,.5,3),this._trayGroup.rotateX(.4),this._allTilesGroup=new Cn,this._scene.add(this._allTilesGroup);const t=new G().subVectors(it._TRAY_VISIBILITY_BOX_MAX,it._TRAY_VISIBILITY_BOX_MIN),i=new G().addVectors(it._TRAY_VISIBILITY_BOX_MIN,it._TRAY_VISIBILITY_BOX_MAX).multiplyScalar(.5);this._trayBoundsDebugMesh=new Tt(new Ei(t.x,t.y,t.z),new Kt({color:3388927,transparent:!0,opacity:.18,depthWrite:!1,visible:!1})),this._trayBoundsDebugMesh.position.copy(i);for(let h=0;h<Yi;h++){const u=new ds(" ");u.animOffset=h*.1,this._scrabbleTiles.push(u);const p=IS(h);u.group.position.copy(p),this._trayGroup.add(u.group),this._pickableMeshes.push(u.pickableMesh)}for(let h=0;h<5;h++)for(let u=0;u<5;u++){const a=new ds(" ");a.animOffset=(h+u)*.1,this._scrabbleTiles.push(a);const l=s0(h,u);a.group.position.copy(l),this._boardGroup.add(a.group),this._pickableMeshes.push(a.pickableMesh)}const s=[],r=[];this.slotPos=s,this.slotQuat=r;for(const h of this._scrabbleTiles)s.push(h.group.getWorldPosition(new G)),r.push(h.group.getWorldQuaternion(new Un));for(const[h,u]of this._scrabbleTiles.entries())this._allTilesGroup.add(u.group),u.group.position.copy(s[h]),u.group.quaternion.copy(r[h]),u.slotPos=s[h],u.slotQuat=r[h],this._allTilesGroup.add(u.pickableMesh),u.pickableMesh.position.copy(s[h]),u.pickableMesh.quaternion.copy(r[h]);const o=new ds("GREATER");this._allTilesGroup.add(o.group),this._pickableMeshes.push(o.pickableMesh);const c=new G(-Jn/2,0,-6);o.group.position.copy(c),o.slotPos=c,o.slotQuat=new Un,this._uiTiles.push(o),this._allTiles=[...this._scrabbleTiles,...this._uiTiles],Xc(this),this._entranceMaskAnimation=new M0(!1),this._entranceMaskAnimation.initMeshes(this),this._allExitAnimations=[new j0(!0),new tA];for(const h of this._allExitAnimations)h.initMeshes(this);this._exitMaskAnimation=Hc(this._allExitAnimations)}static randomCamStart(){return new G(3,.8,0).lerp(new G(-6,3,6),Math.random())}static newCamera(){return new jt(60,window.innerWidth/window.innerHeight,.1,1e6)}mouseUp(){const e=performance.now()-this._dragStartTime<200,t=this._dragStartPos.distanceTo(this._pointer)<.01;if(e&&t){this._isDragging=!1;return}if(this._isDragging&&this._hoveredPickable&&this._hoveredPickable.userData["scrabble-tile"].glyph===" "){this.mouseDown(),this._isDragging=!1;return}this._isDragging=!1,this._queueReturnFocusedTile(),this.mouseMove(null,null)}mouseDown(){var e;if(this.gameState==="title-screen"){this.gameState="playing";return}if(this._hoveredPickable){const t=this._hoveredPickable.userData["scrabble-tile"];if(t&&t.glyph==="GREATER"){this._didSolvePuzzle=!0,this._isGotoNextLevelQueued=!0;return}if(t&&t.glyph!==" ")this._focusedTile?((e=this._focusedTile)==null?void 0:e.tile)===t&&this._queueReturnFocusedTile():(this._focusTile(t),this._isDragging=!0,document.documentElement.style.cursor="grabbing",this._dragStartTime=performance.now(),this._dragStartPos.copy(this._pointer));else if(this._focusedTile&&t&&t.glyph===" "){const i=this._scrabbleTiles.indexOf(this._focusedTile.tile),s=this._scrabbleTiles.indexOf(t);this._scrabbleTiles[i]=t,this._scrabbleTiles[s]=this._focusedTile.tile,this._focusedTile.slotIndex=s,this._queueReturnFocusedTile(),this.mouseMove(null,null),t.group.position.copy(this.slotPos[i]),t.group.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[i].slotPos=this.slotPos[i],this._scrabbleTiles[i].slotQuat=this.slotQuat[i],this._scrabbleTiles[s].slotPos=this.slotPos[s],this._scrabbleTiles[s].slotQuat=this.slotQuat[s],this._scrabbleTiles[i].pickableMesh.position.copy(this.slotPos[i]),this._scrabbleTiles[i].pickableMesh.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[s].pickableMesh.position.copy(this.slotPos[s]),this._scrabbleTiles[s].pickableMesh.quaternion.copy(this.slotQuat[s])}}else this._queueReturnFocusedTile()}mouseMove(e,t){this._isDragging||(document.documentElement.style.cursor="default");const i=this._didFinishEntrance&&!this._didSolvePuzzle;let s=null;if(i&&e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.intersectObjects(this._pickableMeshes,!1);r.length>0&&(s=r[0].object)}if(s&&!this._focusedTile&&s.userData["scrabble-tile"].glyph===" "&&(s=null),s&&!this._isDragging&&(document.documentElement.style.cursor="pointer"),this._hoveredPickable&&(this._hoveredPickable.material.visible=!1),this._hoveredPickable=s,s&&(s.material.visible=!0),e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.ray.intersectPlane(this._dragPlane,this._targetIntersection);r&&(this._draggingPos.copy(r),this._draggingPos.x-=Jn/2,this._draggingPos.z-=Jn/2)}}_focusTile(e){var r;if(((r=this._focusedTile)==null?void 0:r.tile)===e){this._queueReturnFocusedTile();return}this._queueReturnFocusedTile();const t=this._returningTiles.findIndex(o=>o.tile===e),i=t>=0?this._returningTiles[t]:null;t>=0&&this._returningTiles.splice(t,1);const s=this._scrabbleTiles.indexOf(e);this._focusedTile={tile:e,position:((i==null?void 0:i.position)??e.group.position).clone(),quaternion:((i==null?void 0:i.quaternion)??e.group.quaternion).clone(),slotIndex:s},e.updateRenderOrder(20),this._focusTimeMs=0}_queueReturnFocusedTile(){if(!this._focusedTile)return;const e=this._focusedTile;this._returningTiles.push({tile:e.tile,position:e.position,quaternion:e.quaternion,slotIndex:e.slotIndex}),e.tile.updateRenderOrder(10),this._focusedTile=null}async init(){this._scene.add(this._boardGroup),this._scene.add(this._trayGroup),this._scene.add(this._trayBoundsDebugMesh),this.gameState="title-screen",this._entranceMaskAnimation.begin(this),this._entranceMaskAnimation.incremental(this,Number.POSITIVE_INFINITY),new I0(this).wireUiInput()}onResize(){this._appGfx.onResize(),this._animT<1&&(this._boardGroup.visible=!0,this._trayGroup.visible=!0,this._entranceMaskAnimation.begin(this),this._entranceMaskAnimation.incremental(this,Number.POSITIVE_INFINITY),this._animT=0),this._exitT===0&&this._didFinishEntrance&&(this._entranceMaskAnimation.begin(this),this._exitMaskAnimation.begin(this),this._nextEntranceT=0,this._nextExitT=0)}cycleRenderPixelScale(){this.setRenderPixelScale(this._renderPixelScale%6+1)}getRenderPixelScale(){return this._renderPixelScale}setRenderPixelScale(e){this._renderPixelScale!==e&&(this._renderPixelScale=e,this._appGfx.onResize())}};me(it,"_ANIM_MAX_ROTATION",Math.PI*.4),me(it,"_ANIM_DURATION",2e3),me(it,"_CAM_DURATION",2e3),me(it,"_TILE_DURATION",800),me(it,"_TILE_EXIT_DURATION",1e3),me(it,"_CAM_START",it.randomCamStart()),me(it,"_CAM_END",new G(0,8,4)),me(it,"_FOCUS_POS",new G(0,3.1,3)),me(it,"_FOCUS_LERP_ALPHA",.4),me(it,"_FOCUS_OSC_AMP",.07),me(it,"_FOCUS_OSC_SPEED",.006),me(it,"_POST_ENTRANCE_ZOOM_OUT_SPEED",.0055),me(it,"_POST_ENTRANCE_MAX_CAMERA_DISTANCE",30),me(it,"_TRAY_VISIBILITY_NDC_LIMIT",.98),me(it,"_TRAY_VISIBILITY_BOX_MIN",new G(-2.4,0,3)),me(it,"_TRAY_VISIBILITY_BOX_MAX",new G(2.4,1,4.5)),me(it,"_MASK_FILTER_COLORS",["#ff4466","#44ffaa","#4488ff","#ffcc00","#cc44ff"]);let lt=it;function er(n,e,t){return(1-t)*n+t*e}const Kn=100,nA=40,zn=50;let ru,nc=0;const iA=.02;function sA(n,e){nc+=n.dt*iA;const t=window.innerWidth-zn,i=window.innerHeight-zn;e.save(),e.translate(t+zn/2,i+zn/2),e.rotate(nc),e.drawImage(ru,0,0,Kn,Kn,-zn/2,-zn/2,zn,zn),e.restore()}async function rA(){const n=document.createElement("canvas"),e=n.getContext("2d");n.width=Kn,n.height=Kn,e.clearRect(0,0,Kn,Kn),e.fillStyle="black",e.beginPath(),e.arc(Kn/2,Kn/2,nA,0,Math.PI),e.closePath(),e.fill(),ru=n}vo("spinner",rA);function aA(n){oA(n);const e=document.getElementById("overlay-canvas");(e.width!==window.innerWidth||e.height!==window.innerHeight)&&(e.width=window.innerWidth,e.height=window.innerHeight);const t=e.getContext("2d");if(t.clearRect(0,0,e.width,e.height),n._animT<1){const i=n._animT;n._entranceMaskAnimation.updateMeshes(n,i),ic(n,t,e.width,e.height,i)}else if(n._exitT>0&&n._exitT<1){let i=1-n._exitT;n._exitMaskAnimation.updateMeshes(n,i),i=Math.pow(i,1/4),ic(n,t,e.width,e.height,i,!0)}(n._nextEntranceT>0&&n._nextEntranceT<1||n._nextExitT>0&&n._nextExitT<1)&&sA(n,t)}function oA(n){const e=n._animT===1&&(n._exitT===0||n._exitMaskAnimation.hasRenderedScene);n._boardGroup.visible=e,n._trayGroup.visible=e,n._allTilesGroup.visible=e,n._renderer.render(n._scene,n._camera)}function ic(n,e,t,i,s,r=!1){const o=t,c=i,h=Gc(s,5),u=(1-h)*lt._ANIM_MAX_ROTATION,p=Math.cos(u),a=Math.sin(u),l=n._titleScreenDance.getBlend();e.globalAlpha=1;const f=r?n._exitMaskAnimation.getMasks(n):n._entranceMaskAnimation.getMasks(n);for(let m=0;m<f.length;m+=1){const S=f[m];let E=S.x,d=S.y;if(S.worldPos){n._animVec.set(S.worldPos.x*p+S.worldPos.z*a,S.worldPos.y,-S.worldPos.x*a+S.worldPos.z*p).project(n._camera);const A=(n._animVec.x+1)/2*o,I=(1-n._animVec.y)/2*c;E=A-S.canvas.width/2+S.restOffsetX+S.animOffsetX*(1-s),d=I-S.canvas.height/2+S.restOffsetY+S.animOffsetY*(1-s)}let g=er(S.restAngle,0,h);if(l>0){const A=n._titleScreenDance.getMaskPose(m,o,c,S.canvas.width,S.canvas.height);E=er(E,A.x,l),d=er(d,A.y,l),g=er(g,A.angle,l)}e.save(),e.translate(E+S.canvas.width/2,d+S.canvas.height/2),e.rotate(g),e.drawImage(S.canvas,-S.canvas.width/2,-S.canvas.height/2),e.restore()}}function lA(n,e){n.dt=e;const t=n.gameState==="title-screen";if(n._titleScreenDance.update(e,t,n._entranceMaskAnimation.getMaskCount(n)),t||(n._animT=Math.min(1,n._animT+e/lt._ANIM_DURATION),n._animT>=1&&n._entranceMaskAnimation.cleanupMeshes(n)),n._animT>=1&&n._camT<1){n._camT=Math.min(1,n._camT+e/lt._CAM_DURATION);const s=Gc(n._camT,10);n._camera.position.lerpVectors(lt._CAM_START,lt._CAM_END,s)}if(n._animT>=1&&n._camT>=1&&n._tileT<1){n._tileT=Math.min(1,n._tileT+e/lt._TILE_DURATION);for(const s of n._allTiles)s.show(),s.anim=n._tileT}const i=n._exitMaskAnimation.shouldSkipTileExit;if(!n._didFinishEntrance&&n._tileT>=1){n._didFinishEntrance=!0;for(const s of n._allTiles)s.show(),s.anim=1;n._nextCamera=lt.newCamera(),n._nextCamera.position.copy(lt.randomCamStart()),n._nextCamera.lookAt(0,0,0),n._entranceMaskAnimation.begin(n),n._nextEntranceT=0,n._nextExitT=0,n._tileExitT=0,n._exitT=0}else if(n._didFinishEntrance&&n._nextEntranceT<1)n._entranceMaskAnimation.incremental(n),n._nextEntranceT=n._entranceMaskAnimation.getPercentComplete(n)/100;else if(n._didFinishEntrance&&n._nextExitT<1&&n._didSolvePuzzle)n._exitMaskAnimation.incremental(n,5),n._nextExitT=n._exitMaskAnimation.getPercentComplete(n)/100,n._nextExitT>=1&&(n._canGotoNextLevel=!0);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._tileExitT<1&&!i&&n._isGotoNextLevelQueued)if(n._tileExitT=Math.min(1,n._tileExitT+e/lt._TILE_EXIT_DURATION),n._tileExitT>=1)for(const s of n._allTiles)s.hide();else for(const s of n._allTiles)s.anim=1-n._tileExitT;else if(n._nextEntranceT>=1&&n._nextExitT>=1&&(n._tileExitT>=1||i)&&n._exitT<1&&n._isGotoNextLevelQueued)n._exitT=Math.min(1,n._exitT+e/n._exitMaskAnimation.duration);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._exitT>=1){n._didFinishEntrance=!1,n._didSolvePuzzle=!1,n._canGotoNextLevel=!1,n._isGotoNextLevelQueued=!1,n._animT=0,n._camT=0,n._tileT=0,n._nextEntranceT=0,n._nextExitT=0,n._tileExitT=0,n._exitT=0,lt._CAM_START.copy(n._nextCamera.position),n._camera.position.copy(n._nextCamera.position),n._camera.quaternion.copy(n._nextCamera.quaternion);for(const s of n._allTiles)s.hide();n._exitMaskAnimation.cleanupMeshes(n),n._exitMaskAnimation=Hc(n._allExitAnimations),Xc(n)}cA(n,e),hA(n,e),n._controls.update(),aA(n)}function cA(n,e){if(n._focusedTile){n._focusTimeMs+=e;const t=Math.sin(n._focusTimeMs*lt._FOCUS_OSC_SPEED)*lt._FOCUS_OSC_AMP;n._focusTargetPos.copy(n._isDragging?n._draggingPos:lt._FOCUS_POS),n._focusTargetPos.y+=t,n._focusedTile.tile.group.position.lerp(n._focusTargetPos,lt._FOCUS_LERP_ALPHA)}for(let t=n._returningTiles.length-1;t>=0;t-=1){const i=n._returningTiles[t],s=n.slotPos[i.slotIndex],r=n.slotQuat[i.slotIndex];i.tile.group.position.lerp(s,lt._FOCUS_LERP_ALPHA),i.tile.group.quaternion.slerp(r,lt._FOCUS_LERP_ALPHA);const o=i.tile.group.position.distanceToSquared(s)<1e-4,c=Math.abs(i.tile.group.quaternion.dot(r))>.999;!o||!c||(i.tile.group.position.copy(s),i.tile.group.quaternion.copy(r),n._returningTiles.splice(t,1),i.tile.updateRenderOrder(),FS(n)&&(n._didSolvePuzzle=!0,n.mouseMove(null,null),n._isGotoNextLevelQueued=!0,n._exitMaskAnimation.begin(n)))}}const la=[0,0],ca=[0,0],ua=[0,0];function uA(n){if(n._trayVisibilityBounds.isEmpty())return!0;const{min:e,max:t}=n._trayVisibilityBounds,i=lt._TRAY_VISIBILITY_NDC_LIMIT;la[0]=e.x,la[1]=t.x,ca[0]=e.y,ca[1]=t.y,ua[0]=e.z,ua[1]=t.z;for(const s of la)for(const r of ca)for(const o of ua)if(n._trayCorner.set(s,r,o).project(n._camera),!Number.isFinite(n._trayCorner.x)||!Number.isFinite(n._trayCorner.y)||!Number.isFinite(n._trayCorner.z)||Math.abs(n._trayCorner.x)>i||Math.abs(n._trayCorner.y)>i||n._trayCorner.z<-1||n._trayCorner.z>1)return!1;return!0}function hA(n,e){if(n._camT<1||uA(n))return;n._cameraOffset.copy(n._camera.position).sub(n._controls.target);const t=n._cameraOffset.length();if(t===0||t>=lt._POST_ENTRANCE_MAX_CAMERA_DISTANCE)return;n._cameraOffset.divideScalar(t);const i=lt._POST_ENTRANCE_ZOOM_OUT_SPEED*e,s=lt._POST_ENTRANCE_MAX_CAMERA_DISTANCE-t;n._camera.position.addScaledVector(n._cameraOffset,Math.min(i,s))}async function fA(){const n=document.getElementById("startup-loading-label"),e=document.getElementById("startup-loading-screen");await xS(r=>{n&&(n.innerHTML=`LOADING (${r}%)`)});const t=new lt;await t.init(),e==null||e.classList.add("hidden"),window.addEventListener("resize",()=>t.onResize());let i=performance.now();const s=()=>{requestAnimationFrame(s);const r=performance.now(),o=Math.min(30,r-i);i=r,lA(t,o)};requestAnimationFrame(s)}fA();
