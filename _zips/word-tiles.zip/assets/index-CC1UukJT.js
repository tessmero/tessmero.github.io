var Hu=Object.defineProperty;var Gu=(n,e,t)=>e in n?Hu(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var ce=(n,e,t)=>Gu(n,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(s){if(s.ep)return;s.ep=!0;const r=t(s);fetch(s.href,r)}})();function Vu(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}function ku(n,e){return new Proxy(n,{get(t,i,s){return Reflect.get(t,i,s)},set(t,i,s,r){return Reflect.set(t,i,s,r)}})}globalThis.__trackObject=Vu;globalThis.__trackArray=ku;/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Ra="181",Yi={ROTATE:0,DOLLY:1,PAN:2},Vi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Yu=0,el=1,Wu=2,vc=1,zu=2,yn=3,mn=0,Ot=1,on=2,Pn=0,Wi=1,tl=2,nl=3,il=4,Ku=5,ui=100,Xu=101,qu=102,Zu=103,Ju=104,Qu=200,$u=201,ju=202,eh=203,Io=204,yo=205,th=206,nh=207,ih=208,sh=209,rh=210,oh=211,ah=212,lh=213,ch=214,Lo=0,Oo=1,bo=2,Ki=3,Co=4,Do=5,Po=6,No=7,Ic=0,uh=1,hh=2,Zn=0,dh=1,fh=2,ph=3,Eh=4,mh=5,Sh=6,Ah=7,yc=300,Xi=301,qi=302,Uo=303,wo=304,vr=306,Fo=1e3,Cn=1001,Bo=1002,Kt=1003,_h=1004,ws=1005,$t=1006,Fr=1007,pi=1008,Un=1009,Lc=1010,Oc=1011,gs=1012,Ma=1013,Si=1014,Dn=1015,ji=1016,va=1017,Ia=1018,Ts=1020,bc=35902,Cc=35899,Dc=1021,Pc=1022,ln=1023,Rs=1026,Ms=1027,Nc=1028,ya=1029,La=1030,Oa=1031,ba=1033,cr=33776,ur=33777,hr=33778,dr=33779,Ho=35840,Go=35841,Vo=35842,ko=35843,Yo=36196,Wo=37492,zo=37496,Ko=37808,Xo=37809,qo=37810,Zo=37811,Jo=37812,Qo=37813,$o=37814,jo=37815,ea=37816,ta=37817,na=37818,ia=37819,sa=37820,ra=37821,oa=36492,aa=36494,la=36495,ca=36283,ua=36284,ha=36285,da=36286,xh=3200,gh=3201,Th=0,Rh=1,Xn="",Nt="srgb",Zi="srgb-linear",mr="linear",it="srgb",Ri=7680,sl=519,Mh=512,vh=513,Ih=514,Uc=515,yh=516,Lh=517,Oh=518,bh=519,rl=35044,ol="300 es",fn=2e3,Sr=2001;function wc(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function Ar(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function Ch(){const n=Ar("canvas");return n.style.display="block",n}const al={};function ll(...n){const e="THREE."+n.shift();console.log(e,...n)}function Ke(...n){const e="THREE."+n.shift();console.warn(e,...n)}function dt(...n){const e="THREE."+n.shift();console.error(e,...n)}function vs(...n){const e=n.join(" ");e in al||(al[e]=!0,Ke(...n))}function Dh(n,e,t){return new Promise(function(i,s){function r(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:s();break;case n.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:i()}}setTimeout(r,t)})}class xi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){const i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){const i=this._listeners;if(i===void 0)return;const s=i[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const i=t[e.type];if(i!==void 0){e.target=this;const s=i.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,e);e.target=null}}}const bt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],fr=Math.PI/180,fa=180/Math.PI;function es(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(bt[n&255]+bt[n>>8&255]+bt[n>>16&255]+bt[n>>24&255]+"-"+bt[e&255]+bt[e>>8&255]+"-"+bt[e>>16&15|64]+bt[e>>24&255]+"-"+bt[t&63|128]+bt[t>>8&255]+"-"+bt[t>>16&255]+bt[t>>24&255]+bt[i&255]+bt[i>>8&255]+bt[i>>16&255]+bt[i>>24&255]).toLowerCase()}function Ze(n,e,t){return Math.max(e,Math.min(t,n))}function Ph(n,e){return(n%e+e)%e}function Br(n,e,t){return(1-t)*n+t*e}function ss(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function Bt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}const Nh={DEG2RAD:fr};class le{constructor(e=0,t=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),le.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6],this.y=s[1]*t+s[4]*i+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),s=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*i-a*s+e.x,this.y=r*s+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Sn{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=s}static slerpFlat(e,t,i,s,r,a,l){let d=i[s+0],u=i[s+1],p=i[s+2],o=i[s+3],c=r[a+0],h=r[a+1],m=r[a+2],S=r[a+3];if(l<=0){e[t+0]=d,e[t+1]=u,e[t+2]=p,e[t+3]=o;return}if(l>=1){e[t+0]=c,e[t+1]=h,e[t+2]=m,e[t+3]=S;return}if(o!==S||d!==c||u!==h||p!==m){let E=d*c+u*h+p*m+o*S;E<0&&(c=-c,h=-h,m=-m,S=-S,E=-E);let f=1-l;if(E<.9995){const _=Math.acos(E),A=Math.sin(_);f=Math.sin(f*_)/A,l=Math.sin(l*_)/A,d=d*f+c*l,u=u*f+h*l,p=p*f+m*l,o=o*f+S*l}else{d=d*f+c*l,u=u*f+h*l,p=p*f+m*l,o=o*f+S*l;const _=1/Math.sqrt(d*d+u*u+p*p+o*o);d*=_,u*=_,p*=_,o*=_}}e[t]=d,e[t+1]=u,e[t+2]=p,e[t+3]=o}static multiplyQuaternionsFlat(e,t,i,s,r,a){const l=i[s],d=i[s+1],u=i[s+2],p=i[s+3],o=r[a],c=r[a+1],h=r[a+2],m=r[a+3];return e[t]=l*m+p*o+d*h-u*c,e[t+1]=d*m+p*c+u*o-l*h,e[t+2]=u*m+p*h+l*c-d*o,e[t+3]=p*m-l*o-d*c-u*h,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,s){return this._x=e,this._y=t,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,s=e._y,r=e._z,a=e._order,l=Math.cos,d=Math.sin,u=l(i/2),p=l(s/2),o=l(r/2),c=d(i/2),h=d(s/2),m=d(r/2);switch(a){case"XYZ":this._x=c*p*o+u*h*m,this._y=u*h*o-c*p*m,this._z=u*p*m+c*h*o,this._w=u*p*o-c*h*m;break;case"YXZ":this._x=c*p*o+u*h*m,this._y=u*h*o-c*p*m,this._z=u*p*m-c*h*o,this._w=u*p*o+c*h*m;break;case"ZXY":this._x=c*p*o-u*h*m,this._y=u*h*o+c*p*m,this._z=u*p*m+c*h*o,this._w=u*p*o-c*h*m;break;case"ZYX":this._x=c*p*o-u*h*m,this._y=u*h*o+c*p*m,this._z=u*p*m-c*h*o,this._w=u*p*o+c*h*m;break;case"YZX":this._x=c*p*o+u*h*m,this._y=u*h*o+c*p*m,this._z=u*p*m-c*h*o,this._w=u*p*o-c*h*m;break;case"XZY":this._x=c*p*o-u*h*m,this._y=u*h*o-c*p*m,this._z=u*p*m+c*h*o,this._w=u*p*o+c*h*m;break;default:Ke("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,s=Math.sin(i);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],s=t[4],r=t[8],a=t[1],l=t[5],d=t[9],u=t[2],p=t[6],o=t[10],c=i+l+o;if(c>0){const h=.5/Math.sqrt(c+1);this._w=.25/h,this._x=(p-d)*h,this._y=(r-u)*h,this._z=(a-s)*h}else if(i>l&&i>o){const h=2*Math.sqrt(1+i-l-o);this._w=(p-d)/h,this._x=.25*h,this._y=(s+a)/h,this._z=(r+u)/h}else if(l>o){const h=2*Math.sqrt(1+l-i-o);this._w=(r-u)/h,this._x=(s+a)/h,this._y=.25*h,this._z=(d+p)/h}else{const h=2*Math.sqrt(1+o-i-l);this._w=(a-s)/h,this._x=(r+u)/h,this._y=(d+p)/h,this._z=.25*h}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ze(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const s=Math.min(1,t/i);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,s=e._y,r=e._z,a=e._w,l=t._x,d=t._y,u=t._z,p=t._w;return this._x=i*p+a*l+s*u-r*d,this._y=s*p+a*d+r*l-i*u,this._z=r*p+a*u+i*d-s*l,this._w=a*p-i*l-s*d-r*u,this._onChangeCallback(),this}slerp(e,t){if(t<=0)return this;if(t>=1)return this.copy(e);let i=e._x,s=e._y,r=e._z,a=e._w,l=this.dot(e);l<0&&(i=-i,s=-s,r=-r,a=-a,l=-l);let d=1-t;if(l<.9995){const u=Math.acos(l),p=Math.sin(u);d=Math.sin(d*u)/p,t=Math.sin(t*u)/p,this._x=this._x*d+i*t,this._y=this._y*d+s*t,this._z=this._z*d+r*t,this._w=this._w*d+a*t,this._onChangeCallback()}else this._x=this._x*d+i*t,this._y=this._y*d+s*t,this._z=this._z*d+r*t,this._w=this._w*d+a*t,this.normalize();return this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class w{constructor(e=0,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),w.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(cl.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(cl.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6]*s,this.y=r[1]*t+r[4]*i+r[7]*s,this.z=r[2]*t+r[5]*i+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=e.elements,a=1/(r[3]*t+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*i+r[8]*s+r[12])*a,this.y=(r[1]*t+r[5]*i+r[9]*s+r[13])*a,this.z=(r[2]*t+r[6]*i+r[10]*s+r[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,s=this.z,r=e.x,a=e.y,l=e.z,d=e.w,u=2*(a*s-l*i),p=2*(l*t-r*s),o=2*(r*i-a*t);return this.x=t+d*u+a*o-l*p,this.y=i+d*p+l*u-r*o,this.z=s+d*o+r*p-a*u,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*i+r[8]*s,this.y=r[1]*t+r[5]*i+r[9]*s,this.z=r[2]*t+r[6]*i+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,s=e.y,r=e.z,a=t.x,l=t.y,d=t.z;return this.x=s*d-r*l,this.y=r*a-i*d,this.z=i*l-s*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Hr.copy(this).projectOnVector(e),this.sub(Hr)}reflect(e){return this.sub(Hr.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ze(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,s=this.z-e.z;return t*t+i*i+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const s=Math.sin(t)*e;return this.x=s*Math.sin(i),this.y=Math.cos(t)*e,this.z=s*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Hr=new w,cl=new Sn;class We{constructor(e,t,i,s,r,a,l,d,u){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),We.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,a,l,d,u)}set(e,t,i,s,r,a,l,d,u){const p=this.elements;return p[0]=e,p[1]=s,p[2]=l,p[3]=t,p[4]=r,p[5]=d,p[6]=i,p[7]=a,p[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,a=i[0],l=i[3],d=i[6],u=i[1],p=i[4],o=i[7],c=i[2],h=i[5],m=i[8],S=s[0],E=s[3],f=s[6],_=s[1],A=s[4],R=s[7],C=s[2],L=s[5],D=s[8];return r[0]=a*S+l*_+d*C,r[3]=a*E+l*A+d*L,r[6]=a*f+l*R+d*D,r[1]=u*S+p*_+o*C,r[4]=u*E+p*A+o*L,r[7]=u*f+p*R+o*D,r[2]=c*S+h*_+m*C,r[5]=c*E+h*A+m*L,r[8]=c*f+h*R+m*D,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],l=e[5],d=e[6],u=e[7],p=e[8];return t*a*p-t*l*u-i*r*p+i*l*d+s*r*u-s*a*d}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],l=e[5],d=e[6],u=e[7],p=e[8],o=p*a-l*u,c=l*d-p*r,h=u*r-a*d,m=t*o+i*c+s*h;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);const S=1/m;return e[0]=o*S,e[1]=(s*u-p*i)*S,e[2]=(l*i-s*a)*S,e[3]=c*S,e[4]=(p*t-s*d)*S,e[5]=(s*r-l*t)*S,e[6]=h*S,e[7]=(i*d-u*t)*S,e[8]=(a*t-i*r)*S,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,s,r,a,l){const d=Math.cos(r),u=Math.sin(r);return this.set(i*d,i*u,-i*(d*a+u*l)+a+e,-s*u,s*d,-s*(-u*a+d*l)+l+t,0,0,1),this}scale(e,t){return this.premultiply(Gr.makeScale(e,t)),this}rotate(e){return this.premultiply(Gr.makeRotation(-e)),this}translate(e,t){return this.premultiply(Gr.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<9;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Gr=new We,ul=new We().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),hl=new We().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Uh(){const n={enabled:!0,workingColorSpace:Zi,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===it&&(s.r=Nn(s.r),s.g=Nn(s.g),s.b=Nn(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===it&&(s.r=zi(s.r),s.g=zi(s.g),s.b=zi(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Xn?mr:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return vs("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),n.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return vs("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),n.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],i=[.3127,.329];return n.define({[Zi]:{primaries:e,whitePoint:i,transfer:mr,toXYZ:ul,fromXYZ:hl,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Nt},outputColorSpaceConfig:{drawingBufferColorSpace:Nt}},[Nt]:{primaries:e,whitePoint:i,transfer:it,toXYZ:ul,fromXYZ:hl,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Nt}}}),n}const je=Uh();function Nn(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function zi(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let Mi;class wh{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{Mi===void 0&&(Mi=Ar("canvas")),Mi.width=e.width,Mi.height=e.height;const s=Mi.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),i=Mi}return i.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Ar("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const s=i.getImageData(0,0,e.width,e.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=Nn(r[a]/255)*255;return i.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Nn(t[i]/255)*255):t[i]=Nn(t[i]);return{data:t,width:e.width,height:e.height}}else return Ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Fh=0;class Ca{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Fh++}),this.uuid=es(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,l=s.length;a<l;a++)s[a].isDataTexture?r.push(Vr(s[a].image)):r.push(Vr(s[a]))}else r=Vr(s);i.url=r}return t||(e.images[this.uuid]=i),i}}function Vr(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?wh.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(Ke("Texture: Unable to serialize Texture."),{})}let Bh=0;const kr=new w;class Ut extends xi{constructor(e=Ut.DEFAULT_IMAGE,t=Ut.DEFAULT_MAPPING,i=Cn,s=Cn,r=$t,a=pi,l=ln,d=Un,u=Ut.DEFAULT_ANISOTROPY,p=Xn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Bh++}),this.uuid=es(),this.name="",this.source=new Ca(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=u,this.format=l,this.internalFormat=null,this.type=d,this.offset=new le(0,0),this.repeat=new le(1,1),this.center=new le(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new We,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=p,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(kr).x}get height(){return this.source.getSize(kr).y}get depth(){return this.source.getSize(kr).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const i=e[t];if(i===void 0){Ke(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ke(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&i&&s.isVector2&&i.isVector2||s&&i&&s.isVector3&&i.isVector3||s&&i&&s.isMatrix3&&i.isMatrix3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==yc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Fo:e.x=e.x-Math.floor(e.x);break;case Cn:e.x=e.x<0?0:1;break;case Bo:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Fo:e.y=e.y-Math.floor(e.y);break;case Cn:e.y=e.y<0?0:1;break;case Bo:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Ut.DEFAULT_IMAGE=null;Ut.DEFAULT_MAPPING=yc;Ut.DEFAULT_ANISOTROPY=1;class St{constructor(e=0,t=0,i=0,s=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),St.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,s){return this.x=e,this.y=t,this.z=i,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,s=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*s+a[12]*r,this.y=a[1]*t+a[5]*i+a[9]*s+a[13]*r,this.z=a[2]*t+a[6]*i+a[10]*s+a[14]*r,this.w=a[3]*t+a[7]*i+a[11]*s+a[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,s,r;const d=e.elements,u=d[0],p=d[4],o=d[8],c=d[1],h=d[5],m=d[9],S=d[2],E=d[6],f=d[10];if(Math.abs(p-c)<.01&&Math.abs(o-S)<.01&&Math.abs(m-E)<.01){if(Math.abs(p+c)<.1&&Math.abs(o+S)<.1&&Math.abs(m+E)<.1&&Math.abs(u+h+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const A=(u+1)/2,R=(h+1)/2,C=(f+1)/2,L=(p+c)/4,D=(o+S)/4,F=(m+E)/4;return A>R&&A>C?A<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(A),s=L/i,r=D/i):R>C?R<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(R),i=L/s,r=F/s):C<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(C),i=D/r,s=F/r),this.set(i,s,r,t),this}let _=Math.sqrt((E-m)*(E-m)+(o-S)*(o-S)+(c-p)*(c-p));return Math.abs(_)<.001&&(_=1),this.x=(E-m)/_,this.y=(o-S)/_,this.z=(c-p)/_,this.w=Math.acos((u+h+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Ze(this.x,e.x,t.x),this.y=Ze(this.y,e.y,t.y),this.z=Ze(this.z,e.z,t.z),this.w=Ze(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Ze(this.x,e,t),this.y=Ze(this.y,e,t),this.z=Ze(this.z,e,t),this.w=Ze(this.w,e,t),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Ze(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Hh extends xi{constructor(e=1,t=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:$t,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},i),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=i.depth,this.scissor=new St(0,0,e,t),this.scissorTest=!1,this.viewport=new St(0,0,e,t);const s={width:e,height:t,depth:i.depth},r=new Ut(s);this.textures=[];const a=i.count;for(let l=0;l<a;l++)this.textures[l]=r.clone(),this.textures[l].isRenderTargetTexture=!0,this.textures[l].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview}_setTextureOptions(e={}){const t={minFilter:$t,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=i,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,i=e.textures.length;t<i;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new Ca(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class wn extends Hh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class Fc extends Ut{constructor(e=null,t=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Kt,this.minFilter=Kt,this.wrapR=Cn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Gh extends Ut{constructor(e=null,t=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:s},this.magFilter=Kt,this.minFilter=Kt,this.wrapR=Cn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class ts{constructor(e=new w(1/0,1/0,1/0),t=new w(-1/0,-1/0,-1/0)){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(tn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(tn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=tn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const r=i.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let a=0,l=r.count;a<l;a++)e.isMesh===!0?e.getVertexPosition(a,tn):tn.fromBufferAttribute(r,a),tn.applyMatrix4(e.matrixWorld),this.expandByPoint(tn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Fs.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Fs.copy(i.boundingBox)),Fs.applyMatrix4(e.matrixWorld),this.union(Fs)}const s=e.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,tn),tn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(rs),Bs.subVectors(this.max,rs),vi.subVectors(e.a,rs),Ii.subVectors(e.b,rs),yi.subVectors(e.c,rs),Hn.subVectors(Ii,vi),Gn.subVectors(yi,Ii),ii.subVectors(vi,yi);let t=[0,-Hn.z,Hn.y,0,-Gn.z,Gn.y,0,-ii.z,ii.y,Hn.z,0,-Hn.x,Gn.z,0,-Gn.x,ii.z,0,-ii.x,-Hn.y,Hn.x,0,-Gn.y,Gn.x,0,-ii.y,ii.x,0];return!Yr(t,vi,Ii,yi,Bs)||(t=[1,0,0,0,1,0,0,0,1],!Yr(t,vi,Ii,yi,Bs))?!1:(Hs.crossVectors(Hn,Gn),t=[Hs.x,Hs.y,Hs.z],Yr(t,vi,Ii,yi,Bs))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,tn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(tn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(xn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),xn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),xn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),xn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),xn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),xn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),xn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),xn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(xn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const xn=[new w,new w,new w,new w,new w,new w,new w,new w],tn=new w,Fs=new ts,vi=new w,Ii=new w,yi=new w,Hn=new w,Gn=new w,ii=new w,rs=new w,Bs=new w,Hs=new w,si=new w;function Yr(n,e,t,i,s){for(let r=0,a=n.length-3;r<=a;r+=3){si.fromArray(n,r);const l=s.x*Math.abs(si.x)+s.y*Math.abs(si.y)+s.z*Math.abs(si.z),d=e.dot(si),u=t.dot(si),p=i.dot(si);if(Math.max(-Math.max(d,u,p),Math.min(d,u,p))>l)return!1}return!0}const Vh=new ts,os=new w,Wr=new w;class Da{constructor(e=new w,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Vh.setFromPoints(e).getCenter(i);let s=0;for(let r=0,a=e.length;r<a;r++)s=Math.max(s,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;os.subVectors(e,this.center);const t=os.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),s=(i-this.radius)*.5;this.center.addScaledVector(os,s/i),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Wr.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(os.copy(e.center).add(Wr)),this.expandByPoint(os.copy(e.center).sub(Wr))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const gn=new w,zr=new w,Gs=new w,Vn=new w,Kr=new w,Vs=new w,Xr=new w;class Pa{constructor(e=new w,t=new w(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,gn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=gn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(gn.copy(this.origin).addScaledVector(this.direction,t),gn.distanceToSquared(e))}distanceSqToSegment(e,t,i,s){zr.copy(e).add(t).multiplyScalar(.5),Gs.copy(t).sub(e).normalize(),Vn.copy(this.origin).sub(zr);const r=e.distanceTo(t)*.5,a=-this.direction.dot(Gs),l=Vn.dot(this.direction),d=-Vn.dot(Gs),u=Vn.lengthSq(),p=Math.abs(1-a*a);let o,c,h,m;if(p>0)if(o=a*d-l,c=a*l-d,m=r*p,o>=0)if(c>=-m)if(c<=m){const S=1/p;o*=S,c*=S,h=o*(o+a*c+2*l)+c*(a*o+c+2*d)+u}else c=r,o=Math.max(0,-(a*c+l)),h=-o*o+c*(c+2*d)+u;else c=-r,o=Math.max(0,-(a*c+l)),h=-o*o+c*(c+2*d)+u;else c<=-m?(o=Math.max(0,-(-a*r+l)),c=o>0?-r:Math.min(Math.max(-r,-d),r),h=-o*o+c*(c+2*d)+u):c<=m?(o=0,c=Math.min(Math.max(-r,-d),r),h=c*(c+2*d)+u):(o=Math.max(0,-(a*r+l)),c=o>0?r:Math.min(Math.max(-r,-d),r),h=-o*o+c*(c+2*d)+u);else c=a>0?-r:r,o=Math.max(0,-(a*c+l)),h=-o*o+c*(c+2*d)+u;return i&&i.copy(this.origin).addScaledVector(this.direction,o),s&&s.copy(zr).addScaledVector(Gs,c),h}intersectSphere(e,t){gn.subVectors(e.center,this.origin);const i=gn.dot(this.direction),s=gn.dot(gn)-i*i,r=e.radius*e.radius;if(s>r)return null;const a=Math.sqrt(r-s),l=i-a,d=i+a;return d<0?null:l<0?this.at(d,t):this.at(l,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,s,r,a,l,d;const u=1/this.direction.x,p=1/this.direction.y,o=1/this.direction.z,c=this.origin;return u>=0?(i=(e.min.x-c.x)*u,s=(e.max.x-c.x)*u):(i=(e.max.x-c.x)*u,s=(e.min.x-c.x)*u),p>=0?(r=(e.min.y-c.y)*p,a=(e.max.y-c.y)*p):(r=(e.max.y-c.y)*p,a=(e.min.y-c.y)*p),i>a||r>s||((r>i||isNaN(i))&&(i=r),(a<s||isNaN(s))&&(s=a),o>=0?(l=(e.min.z-c.z)*o,d=(e.max.z-c.z)*o):(l=(e.max.z-c.z)*o,d=(e.min.z-c.z)*o),i>d||l>s)||((l>i||i!==i)&&(i=l),(d<s||s!==s)&&(s=d),s<0)?null:this.at(i>=0?i:s,t)}intersectsBox(e){return this.intersectBox(e,gn)!==null}intersectTriangle(e,t,i,s,r){Kr.subVectors(t,e),Vs.subVectors(i,e),Xr.crossVectors(Kr,Vs);let a=this.direction.dot(Xr),l;if(a>0){if(s)return null;l=1}else if(a<0)l=-1,a=-a;else return null;Vn.subVectors(this.origin,e);const d=l*this.direction.dot(Vs.crossVectors(Vn,Vs));if(d<0)return null;const u=l*this.direction.dot(Kr.cross(Vn));if(u<0||d+u>a)return null;const p=-l*Vn.dot(Xr);return p<0?null:this.at(p/a,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class _t{constructor(e,t,i,s,r,a,l,d,u,p,o,c,h,m,S,E){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),_t.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,s,r,a,l,d,u,p,o,c,h,m,S,E)}set(e,t,i,s,r,a,l,d,u,p,o,c,h,m,S,E){const f=this.elements;return f[0]=e,f[4]=t,f[8]=i,f[12]=s,f[1]=r,f[5]=a,f[9]=l,f[13]=d,f[2]=u,f[6]=p,f[10]=o,f[14]=c,f[3]=h,f[7]=m,f[11]=S,f[15]=E,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new _t().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,s=1/Li.setFromMatrixColumn(e,0).length(),r=1/Li.setFromMatrixColumn(e,1).length(),a=1/Li.setFromMatrixColumn(e,2).length();return t[0]=i[0]*s,t[1]=i[1]*s,t[2]=i[2]*s,t[3]=0,t[4]=i[4]*r,t[5]=i[5]*r,t[6]=i[6]*r,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,s=e.y,r=e.z,a=Math.cos(i),l=Math.sin(i),d=Math.cos(s),u=Math.sin(s),p=Math.cos(r),o=Math.sin(r);if(e.order==="XYZ"){const c=a*p,h=a*o,m=l*p,S=l*o;t[0]=d*p,t[4]=-d*o,t[8]=u,t[1]=h+m*u,t[5]=c-S*u,t[9]=-l*d,t[2]=S-c*u,t[6]=m+h*u,t[10]=a*d}else if(e.order==="YXZ"){const c=d*p,h=d*o,m=u*p,S=u*o;t[0]=c+S*l,t[4]=m*l-h,t[8]=a*u,t[1]=a*o,t[5]=a*p,t[9]=-l,t[2]=h*l-m,t[6]=S+c*l,t[10]=a*d}else if(e.order==="ZXY"){const c=d*p,h=d*o,m=u*p,S=u*o;t[0]=c-S*l,t[4]=-a*o,t[8]=m+h*l,t[1]=h+m*l,t[5]=a*p,t[9]=S-c*l,t[2]=-a*u,t[6]=l,t[10]=a*d}else if(e.order==="ZYX"){const c=a*p,h=a*o,m=l*p,S=l*o;t[0]=d*p,t[4]=m*u-h,t[8]=c*u+S,t[1]=d*o,t[5]=S*u+c,t[9]=h*u-m,t[2]=-u,t[6]=l*d,t[10]=a*d}else if(e.order==="YZX"){const c=a*d,h=a*u,m=l*d,S=l*u;t[0]=d*p,t[4]=S-c*o,t[8]=m*o+h,t[1]=o,t[5]=a*p,t[9]=-l*p,t[2]=-u*p,t[6]=h*o+m,t[10]=c-S*o}else if(e.order==="XZY"){const c=a*d,h=a*u,m=l*d,S=l*u;t[0]=d*p,t[4]=-o,t[8]=u*p,t[1]=c*o+S,t[5]=a*p,t[9]=h*o-m,t[2]=m*o-h,t[6]=l*p,t[10]=S*o+c}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(kh,e,Yh)}lookAt(e,t,i){const s=this.elements;return kt.subVectors(e,t),kt.lengthSq()===0&&(kt.z=1),kt.normalize(),kn.crossVectors(i,kt),kn.lengthSq()===0&&(Math.abs(i.z)===1?kt.x+=1e-4:kt.z+=1e-4,kt.normalize(),kn.crossVectors(i,kt)),kn.normalize(),ks.crossVectors(kt,kn),s[0]=kn.x,s[4]=ks.x,s[8]=kt.x,s[1]=kn.y,s[5]=ks.y,s[9]=kt.y,s[2]=kn.z,s[6]=ks.z,s[10]=kt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,s=t.elements,r=this.elements,a=i[0],l=i[4],d=i[8],u=i[12],p=i[1],o=i[5],c=i[9],h=i[13],m=i[2],S=i[6],E=i[10],f=i[14],_=i[3],A=i[7],R=i[11],C=i[15],L=s[0],D=s[4],F=s[8],I=s[12],M=s[1],N=s[5],V=s[9],Z=s[13],J=s[2],Q=s[6],ie=s[10],j=s[14],H=s[3],Ee=s[7],re=s[11],ge=s[15];return r[0]=a*L+l*M+d*J+u*H,r[4]=a*D+l*N+d*Q+u*Ee,r[8]=a*F+l*V+d*ie+u*re,r[12]=a*I+l*Z+d*j+u*ge,r[1]=p*L+o*M+c*J+h*H,r[5]=p*D+o*N+c*Q+h*Ee,r[9]=p*F+o*V+c*ie+h*re,r[13]=p*I+o*Z+c*j+h*ge,r[2]=m*L+S*M+E*J+f*H,r[6]=m*D+S*N+E*Q+f*Ee,r[10]=m*F+S*V+E*ie+f*re,r[14]=m*I+S*Z+E*j+f*ge,r[3]=_*L+A*M+R*J+C*H,r[7]=_*D+A*N+R*Q+C*Ee,r[11]=_*F+A*V+R*ie+C*re,r[15]=_*I+A*Z+R*j+C*ge,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],s=e[8],r=e[12],a=e[1],l=e[5],d=e[9],u=e[13],p=e[2],o=e[6],c=e[10],h=e[14],m=e[3],S=e[7],E=e[11],f=e[15];return m*(+r*d*o-s*u*o-r*l*c+i*u*c+s*l*h-i*d*h)+S*(+t*d*h-t*u*c+r*a*c-s*a*h+s*u*p-r*d*p)+E*(+t*u*o-t*l*h-r*a*o+i*a*h+r*l*p-i*u*p)+f*(-s*l*p-t*d*o+t*l*c+s*a*o-i*a*c+i*d*p)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],s=e[2],r=e[3],a=e[4],l=e[5],d=e[6],u=e[7],p=e[8],o=e[9],c=e[10],h=e[11],m=e[12],S=e[13],E=e[14],f=e[15],_=o*E*u-S*c*u+S*d*h-l*E*h-o*d*f+l*c*f,A=m*c*u-p*E*u-m*d*h+a*E*h+p*d*f-a*c*f,R=p*S*u-m*o*u+m*l*h-a*S*h-p*l*f+a*o*f,C=m*o*d-p*S*d-m*l*c+a*S*c+p*l*E-a*o*E,L=t*_+i*A+s*R+r*C;if(L===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const D=1/L;return e[0]=_*D,e[1]=(S*c*r-o*E*r-S*s*h+i*E*h+o*s*f-i*c*f)*D,e[2]=(l*E*r-S*d*r+S*s*u-i*E*u-l*s*f+i*d*f)*D,e[3]=(o*d*r-l*c*r-o*s*u+i*c*u+l*s*h-i*d*h)*D,e[4]=A*D,e[5]=(p*E*r-m*c*r+m*s*h-t*E*h-p*s*f+t*c*f)*D,e[6]=(m*d*r-a*E*r-m*s*u+t*E*u+a*s*f-t*d*f)*D,e[7]=(a*c*r-p*d*r+p*s*u-t*c*u-a*s*h+t*d*h)*D,e[8]=R*D,e[9]=(m*o*r-p*S*r-m*i*h+t*S*h+p*i*f-t*o*f)*D,e[10]=(a*S*r-m*l*r+m*i*u-t*S*u-a*i*f+t*l*f)*D,e[11]=(p*l*r-a*o*r-p*i*u+t*o*u+a*i*h-t*l*h)*D,e[12]=C*D,e[13]=(p*S*s-m*o*s+m*i*c-t*S*c-p*i*E+t*o*E)*D,e[14]=(m*l*s-a*S*s-m*i*d+t*S*d+a*i*E-t*l*E)*D,e[15]=(a*o*s-p*l*s+p*i*d-t*o*d-a*i*c+t*l*c)*D,this}scale(e){const t=this.elements,i=e.x,s=e.y,r=e.z;return t[0]*=i,t[4]*=s,t[8]*=r,t[1]*=i,t[5]*=s,t[9]*=r,t[2]*=i,t[6]*=s,t[10]*=r,t[3]*=i,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,s))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),s=Math.sin(t),r=1-i,a=e.x,l=e.y,d=e.z,u=r*a,p=r*l;return this.set(u*a+i,u*l-s*d,u*d+s*l,0,u*l+s*d,p*l+i,p*d-s*a,0,u*d-s*l,p*d+s*a,r*d*d+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,s,r,a){return this.set(1,i,r,0,e,1,a,0,t,s,1,0,0,0,0,1),this}compose(e,t,i){const s=this.elements,r=t._x,a=t._y,l=t._z,d=t._w,u=r+r,p=a+a,o=l+l,c=r*u,h=r*p,m=r*o,S=a*p,E=a*o,f=l*o,_=d*u,A=d*p,R=d*o,C=i.x,L=i.y,D=i.z;return s[0]=(1-(S+f))*C,s[1]=(h+R)*C,s[2]=(m-A)*C,s[3]=0,s[4]=(h-R)*L,s[5]=(1-(c+f))*L,s[6]=(E+_)*L,s[7]=0,s[8]=(m+A)*D,s[9]=(E-_)*D,s[10]=(1-(c+S))*D,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,i){const s=this.elements;let r=Li.set(s[0],s[1],s[2]).length();const a=Li.set(s[4],s[5],s[6]).length(),l=Li.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],nn.copy(this);const u=1/r,p=1/a,o=1/l;return nn.elements[0]*=u,nn.elements[1]*=u,nn.elements[2]*=u,nn.elements[4]*=p,nn.elements[5]*=p,nn.elements[6]*=p,nn.elements[8]*=o,nn.elements[9]*=o,nn.elements[10]*=o,t.setFromRotationMatrix(nn),i.x=r,i.y=a,i.z=l,this}makePerspective(e,t,i,s,r,a,l=fn,d=!1){const u=this.elements,p=2*r/(t-e),o=2*r/(i-s),c=(t+e)/(t-e),h=(i+s)/(i-s);let m,S;if(d)m=r/(a-r),S=a*r/(a-r);else if(l===fn)m=-(a+r)/(a-r),S=-2*a*r/(a-r);else if(l===Sr)m=-a/(a-r),S=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+l);return u[0]=p,u[4]=0,u[8]=c,u[12]=0,u[1]=0,u[5]=o,u[9]=h,u[13]=0,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=-1,u[15]=0,this}makeOrthographic(e,t,i,s,r,a,l=fn,d=!1){const u=this.elements,p=2/(t-e),o=2/(i-s),c=-(t+e)/(t-e),h=-(i+s)/(i-s);let m,S;if(d)m=1/(a-r),S=a/(a-r);else if(l===fn)m=-2/(a-r),S=-(a+r)/(a-r);else if(l===Sr)m=-1/(a-r),S=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+l);return u[0]=p,u[4]=0,u[8]=0,u[12]=c,u[1]=0,u[5]=o,u[9]=0,u[13]=h,u[2]=0,u[6]=0,u[10]=m,u[14]=S,u[3]=0,u[7]=0,u[11]=0,u[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let s=0;s<16;s++)if(t[s]!==i[s])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const Li=new w,nn=new _t,kh=new w(0,0,0),Yh=new w(1,1,1),kn=new w,ks=new w,kt=new w,dl=new _t,fl=new Sn;class Fn{constructor(e=0,t=0,i=0,s=Fn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,s=this._order){return this._x=e,this._y=t,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const s=e.elements,r=s[0],a=s[4],l=s[8],d=s[1],u=s[5],p=s[9],o=s[2],c=s[6],h=s[10];switch(t){case"XYZ":this._y=Math.asin(Ze(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-p,h),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(c,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Ze(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(l,h),this._z=Math.atan2(d,u)):(this._y=Math.atan2(-o,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ze(c,-1,1)),Math.abs(c)<.9999999?(this._y=Math.atan2(-o,h),this._z=Math.atan2(-a,u)):(this._y=0,this._z=Math.atan2(d,r));break;case"ZYX":this._y=Math.asin(-Ze(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(c,h),this._z=Math.atan2(d,r)):(this._x=0,this._z=Math.atan2(-a,u));break;case"YZX":this._z=Math.asin(Ze(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-p,u),this._y=Math.atan2(-o,r)):(this._x=0,this._y=Math.atan2(l,h));break;case"XZY":this._z=Math.asin(-Ze(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(c,u),this._y=Math.atan2(l,r)):(this._x=Math.atan2(-p,h),this._y=0);break;default:Ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return dl.makeRotationFromQuaternion(e),this.setFromRotationMatrix(dl,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return fl.setFromEuler(this),this.setFromQuaternion(fl,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Fn.DEFAULT_ORDER="XYZ";class Na{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Wh=0;const pl=new w,Oi=new Sn,Tn=new _t,Ys=new w,as=new w,zh=new w,Kh=new Sn,El=new w(1,0,0),ml=new w(0,1,0),Sl=new w(0,0,1),Al={type:"added"},Xh={type:"removed"},bi={type:"childadded",child:null},qr={type:"childremoved",child:null};class Xt extends xi{constructor(){super(),this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Wh++}),this.uuid=es(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Xt.DEFAULT_UP.clone();const e=new w,t=new Fn,i=new Sn,s=new w(1,1,1);function r(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(r),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new _t},normalMatrix:{value:new We}}),this.matrix=new _t,this.matrixWorld=new _t,this.matrixAutoUpdate=Xt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Xt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Na,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Oi.setFromAxisAngle(e,t),this.quaternion.multiply(Oi),this}rotateOnWorldAxis(e,t){return Oi.setFromAxisAngle(e,t),this.quaternion.premultiply(Oi),this}rotateX(e){return this.rotateOnAxis(El,e)}rotateY(e){return this.rotateOnAxis(ml,e)}rotateZ(e){return this.rotateOnAxis(Sl,e)}translateOnAxis(e,t){return pl.copy(e).applyQuaternion(this.quaternion),this.position.add(pl.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(El,e)}translateY(e){return this.translateOnAxis(ml,e)}translateZ(e){return this.translateOnAxis(Sl,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Tn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Ys.copy(e):Ys.set(e,t,i);const s=this.parent;this.updateWorldMatrix(!0,!1),as.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Tn.lookAt(as,Ys,this.up):Tn.lookAt(Ys,as,this.up),this.quaternion.setFromRotationMatrix(Tn),s&&(Tn.extractRotation(s.matrixWorld),Oi.setFromRotationMatrix(Tn),this.quaternion.premultiply(Oi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(dt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Al),bi.child=e,this.dispatchEvent(bi),bi.child=null):dt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Xh),qr.child=e,this.dispatchEvent(qr),qr.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Tn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Tn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Tn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Al),bi.child=e,this.dispatchEvent(bi),bi.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,s=this.children.length;i<s;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(as,e,zh),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(as,Kh,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,s=t.length;i<s;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(l=>({...l,boundingBox:l.boundingBox?l.boundingBox.toJSON():void 0,boundingSphere:l.boundingSphere?l.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(l=>({...l})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(l,d){return l[d.uuid]===void 0&&(l[d.uuid]=d.toJSON(e)),d.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const l=this.geometry.parameters;if(l!==void 0&&l.shapes!==void 0){const d=l.shapes;if(Array.isArray(d))for(let u=0,p=d.length;u<p;u++){const o=d[u];r(e.shapes,o)}else r(e.shapes,d)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const l=[];for(let d=0,u=this.material.length;d<u;d++)l.push(r(e.materials,this.material[d]));s.material=l}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let l=0;l<this.children.length;l++)s.children.push(this.children[l].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let l=0;l<this.animations.length;l++){const d=this.animations[l];s.animations.push(r(e.animations,d))}}if(t){const l=a(e.geometries),d=a(e.materials),u=a(e.textures),p=a(e.images),o=a(e.shapes),c=a(e.skeletons),h=a(e.animations),m=a(e.nodes);l.length>0&&(i.geometries=l),d.length>0&&(i.materials=d),u.length>0&&(i.textures=u),p.length>0&&(i.images=p),o.length>0&&(i.shapes=o),c.length>0&&(i.skeletons=c),h.length>0&&(i.animations=h),m.length>0&&(i.nodes=m)}return i.object=s,i;function a(l){const d=[];for(const u in l){const p=l[u];delete p.metadata,d.push(p)}return d}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const s=e.children[i];this.add(s.clone())}return this}}Xt.DEFAULT_UP=new w(0,1,0);Xt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Xt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const sn=new w,Rn=new w,Zr=new w,Mn=new w,Ci=new w,Di=new w,_l=new w,Jr=new w,Qr=new w,$r=new w,jr=new St,eo=new St,to=new St;class an{constructor(e=new w,t=new w,i=new w){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,s){s.subVectors(i,t),sn.subVectors(e,t),s.cross(sn);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,i,s,r){sn.subVectors(s,t),Rn.subVectors(i,t),Zr.subVectors(e,t);const a=sn.dot(sn),l=sn.dot(Rn),d=sn.dot(Zr),u=Rn.dot(Rn),p=Rn.dot(Zr),o=a*u-l*l;if(o===0)return r.set(0,0,0),null;const c=1/o,h=(u*d-l*p)*c,m=(a*p-l*d)*c;return r.set(1-h-m,m,h)}static containsPoint(e,t,i,s){return this.getBarycoord(e,t,i,s,Mn)===null?!1:Mn.x>=0&&Mn.y>=0&&Mn.x+Mn.y<=1}static getInterpolation(e,t,i,s,r,a,l,d){return this.getBarycoord(e,t,i,s,Mn)===null?(d.x=0,d.y=0,"z"in d&&(d.z=0),"w"in d&&(d.w=0),null):(d.setScalar(0),d.addScaledVector(r,Mn.x),d.addScaledVector(a,Mn.y),d.addScaledVector(l,Mn.z),d)}static getInterpolatedAttribute(e,t,i,s,r,a){return jr.setScalar(0),eo.setScalar(0),to.setScalar(0),jr.fromBufferAttribute(e,t),eo.fromBufferAttribute(e,i),to.fromBufferAttribute(e,s),a.setScalar(0),a.addScaledVector(jr,r.x),a.addScaledVector(eo,r.y),a.addScaledVector(to,r.z),a}static isFrontFacing(e,t,i,s){return sn.subVectors(i,t),Rn.subVectors(e,t),sn.cross(Rn).dot(s)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,s){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,i,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return sn.subVectors(this.c,this.b),Rn.subVectors(this.a,this.b),sn.cross(Rn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return an.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return an.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,s,r){return an.getInterpolation(e,this.a,this.b,this.c,t,i,s,r)}containsPoint(e){return an.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return an.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,s=this.b,r=this.c;let a,l;Ci.subVectors(s,i),Di.subVectors(r,i),Jr.subVectors(e,i);const d=Ci.dot(Jr),u=Di.dot(Jr);if(d<=0&&u<=0)return t.copy(i);Qr.subVectors(e,s);const p=Ci.dot(Qr),o=Di.dot(Qr);if(p>=0&&o<=p)return t.copy(s);const c=d*o-p*u;if(c<=0&&d>=0&&p<=0)return a=d/(d-p),t.copy(i).addScaledVector(Ci,a);$r.subVectors(e,r);const h=Ci.dot($r),m=Di.dot($r);if(m>=0&&h<=m)return t.copy(r);const S=h*u-d*m;if(S<=0&&u>=0&&m<=0)return l=u/(u-m),t.copy(i).addScaledVector(Di,l);const E=p*m-h*o;if(E<=0&&o-p>=0&&h-m>=0)return _l.subVectors(r,s),l=(o-p)/(o-p+(h-m)),t.copy(s).addScaledVector(_l,l);const f=1/(E+S+c);return a=S*f,l=c*f,t.copy(i).addScaledVector(Ci,a).addScaledVector(Di,l)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Bc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Yn={h:0,s:0,l:0},Ws={h:0,s:0,l:0};function no(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Qe{constructor(e,t,i){return this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Nt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,je.colorSpaceToWorking(this,t),this}setRGB(e,t,i,s=je.workingColorSpace){return this.r=e,this.g=t,this.b=i,je.colorSpaceToWorking(this,s),this}setHSL(e,t,i,s=je.workingColorSpace){if(e=Ph(e,1),t=Ze(t,0,1),i=Ze(i,0,1),t===0)this.r=this.g=this.b=i;else{const r=i<=.5?i*(1+t):i+t-i*t,a=2*i-r;this.r=no(a,r,e+1/3),this.g=no(a,r,e),this.b=no(a,r,e-1/3)}return je.colorSpaceToWorking(this,s),this}setStyle(e,t=Nt){function i(r){r!==void 0&&parseFloat(r)<1&&Ke("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const a=s[1],l=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:Ke("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);Ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Nt){const i=Bc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):Ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Nn(e.r),this.g=Nn(e.g),this.b=Nn(e.b),this}copyLinearToSRGB(e){return this.r=zi(e.r),this.g=zi(e.g),this.b=zi(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Nt){return je.workingToColorSpace(Ct.copy(this),e),Math.round(Ze(Ct.r*255,0,255))*65536+Math.round(Ze(Ct.g*255,0,255))*256+Math.round(Ze(Ct.b*255,0,255))}getHexString(e=Nt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=je.workingColorSpace){je.workingToColorSpace(Ct.copy(this),t);const i=Ct.r,s=Ct.g,r=Ct.b,a=Math.max(i,s,r),l=Math.min(i,s,r);let d,u;const p=(l+a)/2;if(l===a)d=0,u=0;else{const o=a-l;switch(u=p<=.5?o/(a+l):o/(2-a-l),a){case i:d=(s-r)/o+(s<r?6:0);break;case s:d=(r-i)/o+2;break;case r:d=(i-s)/o+4;break}d/=6}return e.h=d,e.s=u,e.l=p,e}getRGB(e,t=je.workingColorSpace){return je.workingToColorSpace(Ct.copy(this),t),e.r=Ct.r,e.g=Ct.g,e.b=Ct.b,e}getStyle(e=Nt){je.workingToColorSpace(Ct.copy(this),e);const t=Ct.r,i=Ct.g,s=Ct.b;return e!==Nt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(e,t,i){return this.getHSL(Yn),this.setHSL(Yn.h+e,Yn.s+t,Yn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Yn),e.getHSL(Ws);const i=Br(Yn.h,Ws.h,t),s=Br(Yn.s,Ws.s,t),r=Br(Yn.l,Ws.l,t);return this.setHSL(i,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*i+r[6]*s,this.g=r[1]*t+r[4]*i+r[7]*s,this.b=r[2]*t+r[5]*i+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ct=new Qe;Qe.NAMES=Bc;let qh=0;class Ir extends xi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:qh++}),this.uuid=es(),this.name="",this.type="Material",this.blending=Wi,this.side=mn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Io,this.blendDst=yo,this.blendEquation=ui,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Qe(0,0,0),this.blendAlpha=0,this.depthFunc=Ki,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=sl,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ri,this.stencilZFail=Ri,this.stencilZPass=Ri,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){Ke(`Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){Ke(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Wi&&(i.blending=this.blending),this.side!==mn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Io&&(i.blendSrc=this.blendSrc),this.blendDst!==yo&&(i.blendDst=this.blendDst),this.blendEquation!==ui&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==Ki&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==sl&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ri&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Ri&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Ri&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){const a=[];for(const l in r){const d=r[l];delete d.metadata,a.push(d)}return a}if(t){const r=s(e.textures),a=s(e.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const s=t.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=t[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class jn extends Ir{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Fn,this.combine=Ic,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const xt=new w,zs=new le;let Zh=0;class un{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Zh++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=rl,this.updateRanges=[],this.gpuType=Dn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[i+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)zs.fromBufferAttribute(this,t),zs.applyMatrix3(e),this.setXY(t,zs.x,zs.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix3(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyMatrix4(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.applyNormalMatrix(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)xt.fromBufferAttribute(this,t),xt.transformDirection(e),this.setXYZ(t,xt.x,xt.y,xt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=ss(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Bt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=ss(t,this.array)),t}setX(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=ss(t,this.array)),t}setY(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=ss(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=ss(t,this.array)),t}setW(e,t){return this.normalized&&(t=Bt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,s){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this}setXYZW(e,t,i,s,r){return e*=this.itemSize,this.normalized&&(t=Bt(t,this.array),i=Bt(i,this.array),s=Bt(s,this.array),r=Bt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==rl&&(e.usage=this.usage),e}}class Hc extends un{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class Gc extends un{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class Tt extends un{constructor(e,t,i){super(new Float32Array(e),t,i)}}let Jh=0;const Zt=new _t,io=new Xt,Pi=new w,Yt=new ts,ls=new ts,It=new w;class Rt extends xi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Jh++}),this.uuid=es(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(wc(e)?Gc:Hc)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const r=new We().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Zt.makeRotationFromQuaternion(e),this.applyMatrix4(Zt),this}rotateX(e){return Zt.makeRotationX(e),this.applyMatrix4(Zt),this}rotateY(e){return Zt.makeRotationY(e),this.applyMatrix4(Zt),this}rotateZ(e){return Zt.makeRotationZ(e),this.applyMatrix4(Zt),this}translate(e,t,i){return Zt.makeTranslation(e,t,i),this.applyMatrix4(Zt),this}scale(e,t,i){return Zt.makeScale(e,t,i),this.applyMatrix4(Zt),this}lookAt(e){return io.lookAt(e),io.updateMatrix(),this.applyMatrix4(io.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Pi).negate(),this.translate(Pi.x,Pi.y,Pi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const i=[];for(let s=0,r=e.length;s<r;s++){const a=e[s];i.push(a.x,a.y,a.z||0)}this.setAttribute("position",new Tt(i,3))}else{const i=Math.min(e.length,t.count);for(let s=0;s<i;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&Ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ts);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new w(-1/0,-1/0,-1/0),new w(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,s=t.length;i<s;i++){const r=t[i];Yt.setFromBufferAttribute(r),this.morphTargetsRelative?(It.addVectors(this.boundingBox.min,Yt.min),this.boundingBox.expandByPoint(It),It.addVectors(this.boundingBox.max,Yt.max),this.boundingBox.expandByPoint(It)):(this.boundingBox.expandByPoint(Yt.min),this.boundingBox.expandByPoint(Yt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&dt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Da);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){dt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new w,1/0);return}if(e){const i=this.boundingSphere.center;if(Yt.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const l=t[r];ls.setFromBufferAttribute(l),this.morphTargetsRelative?(It.addVectors(Yt.min,ls.min),Yt.expandByPoint(It),It.addVectors(Yt.max,ls.max),Yt.expandByPoint(It)):(Yt.expandByPoint(ls.min),Yt.expandByPoint(ls.max))}Yt.getCenter(i);let s=0;for(let r=0,a=e.count;r<a;r++)It.fromBufferAttribute(e,r),s=Math.max(s,i.distanceToSquared(It));if(t)for(let r=0,a=t.length;r<a;r++){const l=t[r],d=this.morphTargetsRelative;for(let u=0,p=l.count;u<p;u++)It.fromBufferAttribute(l,u),d&&(Pi.fromBufferAttribute(e,u),It.add(Pi)),s=Math.max(s,i.distanceToSquared(It))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&dt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){dt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new un(new Float32Array(4*i.count),4));const a=this.getAttribute("tangent"),l=[],d=[];for(let F=0;F<i.count;F++)l[F]=new w,d[F]=new w;const u=new w,p=new w,o=new w,c=new le,h=new le,m=new le,S=new w,E=new w;function f(F,I,M){u.fromBufferAttribute(i,F),p.fromBufferAttribute(i,I),o.fromBufferAttribute(i,M),c.fromBufferAttribute(r,F),h.fromBufferAttribute(r,I),m.fromBufferAttribute(r,M),p.sub(u),o.sub(u),h.sub(c),m.sub(c);const N=1/(h.x*m.y-m.x*h.y);isFinite(N)&&(S.copy(p).multiplyScalar(m.y).addScaledVector(o,-h.y).multiplyScalar(N),E.copy(o).multiplyScalar(h.x).addScaledVector(p,-m.x).multiplyScalar(N),l[F].add(S),l[I].add(S),l[M].add(S),d[F].add(E),d[I].add(E),d[M].add(E))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let F=0,I=_.length;F<I;++F){const M=_[F],N=M.start,V=M.count;for(let Z=N,J=N+V;Z<J;Z+=3)f(e.getX(Z+0),e.getX(Z+1),e.getX(Z+2))}const A=new w,R=new w,C=new w,L=new w;function D(F){C.fromBufferAttribute(s,F),L.copy(C);const I=l[F];A.copy(I),A.sub(C.multiplyScalar(C.dot(I))).normalize(),R.crossVectors(L,I);const N=R.dot(d[F])<0?-1:1;a.setXYZW(F,A.x,A.y,A.z,N)}for(let F=0,I=_.length;F<I;++F){const M=_[F],N=M.start,V=M.count;for(let Z=N,J=N+V;Z<J;Z+=3)D(e.getX(Z+0)),D(e.getX(Z+1)),D(e.getX(Z+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new un(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let c=0,h=i.count;c<h;c++)i.setXYZ(c,0,0,0);const s=new w,r=new w,a=new w,l=new w,d=new w,u=new w,p=new w,o=new w;if(e)for(let c=0,h=e.count;c<h;c+=3){const m=e.getX(c+0),S=e.getX(c+1),E=e.getX(c+2);s.fromBufferAttribute(t,m),r.fromBufferAttribute(t,S),a.fromBufferAttribute(t,E),p.subVectors(a,r),o.subVectors(s,r),p.cross(o),l.fromBufferAttribute(i,m),d.fromBufferAttribute(i,S),u.fromBufferAttribute(i,E),l.add(p),d.add(p),u.add(p),i.setXYZ(m,l.x,l.y,l.z),i.setXYZ(S,d.x,d.y,d.z),i.setXYZ(E,u.x,u.y,u.z)}else for(let c=0,h=t.count;c<h;c+=3)s.fromBufferAttribute(t,c+0),r.fromBufferAttribute(t,c+1),a.fromBufferAttribute(t,c+2),p.subVectors(a,r),o.subVectors(s,r),p.cross(o),i.setXYZ(c+0,p.x,p.y,p.z),i.setXYZ(c+1,p.x,p.y,p.z),i.setXYZ(c+2,p.x,p.y,p.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)It.fromBufferAttribute(e,t),It.normalize(),e.setXYZ(t,It.x,It.y,It.z)}toNonIndexed(){function e(l,d){const u=l.array,p=l.itemSize,o=l.normalized,c=new u.constructor(d.length*p);let h=0,m=0;for(let S=0,E=d.length;S<E;S++){l.isInterleavedBufferAttribute?h=d[S]*l.data.stride+l.offset:h=d[S]*p;for(let f=0;f<p;f++)c[m++]=u[h++]}return new un(c,p,o)}if(this.index===null)return Ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Rt,i=this.index.array,s=this.attributes;for(const l in s){const d=s[l],u=e(d,i);t.setAttribute(l,u)}const r=this.morphAttributes;for(const l in r){const d=[],u=r[l];for(let p=0,o=u.length;p<o;p++){const c=u[p],h=e(c,i);d.push(h)}t.morphAttributes[l]=d}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let l=0,d=a.length;l<d;l++){const u=a[l];t.addGroup(u.start,u.count,u.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const d=this.parameters;for(const u in d)d[u]!==void 0&&(e[u]=d[u]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const d in i){const u=i[d];e.data.attributes[d]=u.toJSON(e.data)}const s={};let r=!1;for(const d in this.morphAttributes){const u=this.morphAttributes[d],p=[];for(let o=0,c=u.length;o<c;o++){const h=u[o];p.push(h.toJSON(e.data))}p.length>0&&(s[d]=p,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const l=this.boundingSphere;return l!==null&&(e.data.boundingSphere=l.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone());const s=e.attributes;for(const u in s){const p=s[u];this.setAttribute(u,p.clone(t))}const r=e.morphAttributes;for(const u in r){const p=[],o=r[u];for(let c=0,h=o.length;c<h;c++)p.push(o[c].clone(t));this.morphAttributes[u]=p}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let u=0,p=a.length;u<p;u++){const o=a[u];this.addGroup(o.start,o.count,o.materialIndex)}const l=e.boundingBox;l!==null&&(this.boundingBox=l.clone());const d=e.boundingSphere;return d!==null&&(this.boundingSphere=d.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const xl=new _t,ri=new Pa,Ks=new Da,gl=new w,Xs=new w,qs=new w,Zs=new w,so=new w,Js=new w,Tl=new w,Qs=new w;class At extends Xt{constructor(e=new Rt,t=new jn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const s=t[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const l=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[l]=r}}}}getVertexPosition(e,t){const i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(s,e);const l=this.morphTargetInfluences;if(r&&l){Js.set(0,0,0);for(let d=0,u=r.length;d<u;d++){const p=l[d],o=r[d];p!==0&&(so.fromBufferAttribute(o,e),a?Js.addScaledVector(so,p):Js.addScaledVector(so.sub(t),p))}t.add(Js)}return t}raycast(e,t){const i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Ks.copy(i.boundingSphere),Ks.applyMatrix4(r),ri.copy(e.ray).recast(e.near),!(Ks.containsPoint(ri.origin)===!1&&(ri.intersectSphere(Ks,gl)===null||ri.origin.distanceToSquared(gl)>(e.far-e.near)**2))&&(xl.copy(r).invert(),ri.copy(e.ray).applyMatrix4(xl),!(i.boundingBox!==null&&ri.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,ri)))}_computeIntersections(e,t,i){let s;const r=this.geometry,a=this.material,l=r.index,d=r.attributes.position,u=r.attributes.uv,p=r.attributes.uv1,o=r.attributes.normal,c=r.groups,h=r.drawRange;if(l!==null)if(Array.isArray(a))for(let m=0,S=c.length;m<S;m++){const E=c[m],f=a[E.materialIndex],_=Math.max(E.start,h.start),A=Math.min(l.count,Math.min(E.start+E.count,h.start+h.count));for(let R=_,C=A;R<C;R+=3){const L=l.getX(R),D=l.getX(R+1),F=l.getX(R+2);s=$s(this,f,e,i,u,p,o,L,D,F),s&&(s.faceIndex=Math.floor(R/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,h.start),S=Math.min(l.count,h.start+h.count);for(let E=m,f=S;E<f;E+=3){const _=l.getX(E),A=l.getX(E+1),R=l.getX(E+2);s=$s(this,a,e,i,u,p,o,_,A,R),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}else if(d!==void 0)if(Array.isArray(a))for(let m=0,S=c.length;m<S;m++){const E=c[m],f=a[E.materialIndex],_=Math.max(E.start,h.start),A=Math.min(d.count,Math.min(E.start+E.count,h.start+h.count));for(let R=_,C=A;R<C;R+=3){const L=R,D=R+1,F=R+2;s=$s(this,f,e,i,u,p,o,L,D,F),s&&(s.faceIndex=Math.floor(R/3),s.face.materialIndex=E.materialIndex,t.push(s))}}else{const m=Math.max(0,h.start),S=Math.min(d.count,h.start+h.count);for(let E=m,f=S;E<f;E+=3){const _=E,A=E+1,R=E+2;s=$s(this,a,e,i,u,p,o,_,A,R),s&&(s.faceIndex=Math.floor(E/3),t.push(s))}}}}function Qh(n,e,t,i,s,r,a,l){let d;if(e.side===Ot?d=i.intersectTriangle(a,r,s,!0,l):d=i.intersectTriangle(s,r,a,e.side===mn,l),d===null)return null;Qs.copy(l),Qs.applyMatrix4(n.matrixWorld);const u=t.ray.origin.distanceTo(Qs);return u<t.near||u>t.far?null:{distance:u,point:Qs.clone(),object:n}}function $s(n,e,t,i,s,r,a,l,d,u){n.getVertexPosition(l,Xs),n.getVertexPosition(d,qs),n.getVertexPosition(u,Zs);const p=Qh(n,e,t,i,Xs,qs,Zs,Tl);if(p){const o=new w;an.getBarycoord(Tl,Xs,qs,Zs,o),s&&(p.uv=an.getInterpolatedAttribute(s,l,d,u,o,new le)),r&&(p.uv1=an.getInterpolatedAttribute(r,l,d,u,o,new le)),a&&(p.normal=an.getInterpolatedAttribute(a,l,d,u,o,new w),p.normal.dot(i.direction)>0&&p.normal.multiplyScalar(-1));const c={a:l,b:d,c:u,normal:new w,materialIndex:0};an.getNormal(Xs,qs,Zs,c.normal),p.face=c,p.barycoord=o}return p}class gi extends Rt{constructor(e=1,t=1,i=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:s,heightSegments:r,depthSegments:a};const l=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const d=[],u=[],p=[],o=[];let c=0,h=0;m("z","y","x",-1,-1,i,t,e,a,r,0),m("z","y","x",1,-1,i,t,-e,a,r,1),m("x","z","y",1,1,e,i,t,s,a,2),m("x","z","y",1,-1,e,i,-t,s,a,3),m("x","y","z",1,-1,e,t,i,s,r,4),m("x","y","z",-1,-1,e,t,-i,s,r,5),this.setIndex(d),this.setAttribute("position",new Tt(u,3)),this.setAttribute("normal",new Tt(p,3)),this.setAttribute("uv",new Tt(o,2));function m(S,E,f,_,A,R,C,L,D,F,I){const M=R/D,N=C/F,V=R/2,Z=C/2,J=L/2,Q=D+1,ie=F+1;let j=0,H=0;const Ee=new w;for(let re=0;re<ie;re++){const ge=re*N-Z;for(let we=0;we<Q;we++){const Ve=we*M-V;Ee[S]=Ve*_,Ee[E]=ge*A,Ee[f]=J,u.push(Ee.x,Ee.y,Ee.z),Ee[S]=0,Ee[E]=0,Ee[f]=L>0?1:-1,p.push(Ee.x,Ee.y,Ee.z),o.push(we/D),o.push(1-re/F),j+=1}}for(let re=0;re<F;re++)for(let ge=0;ge<D;ge++){const we=c+ge+Q*re,Ve=c+ge+Q*(re+1),z=c+(ge+1)+Q*(re+1),U=c+(ge+1)+Q*re;d.push(we,Ve,U),d.push(Ve,z,U),H+=6}l.addGroup(h,H,I),h+=H,c+=j}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new gi(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Ji(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const s=n[t][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(Ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=s.clone():Array.isArray(s)?e[t][i]=s.slice():e[t][i]=s}}return e}function Pt(n){const e={};for(let t=0;t<n.length;t++){const i=Ji(n[t]);for(const s in i)e[s]=i[s]}return e}function $h(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function Vc(n){const e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:je.workingColorSpace}const jh={clone:Ji,merge:Pt};var ed=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,td=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Bn extends Ir{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=ed,this.fragmentShader=td,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ji(e.uniforms),this.uniformsGroups=$h(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?t.uniforms[s]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[s]={type:"m4",value:a.toArray()}:t.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class kc extends Xt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _t,this.projectionMatrix=new _t,this.projectionMatrixInverse=new _t,this.coordinateSystem=fn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Wn=new w,Rl=new le,Ml=new le;class zt extends kc{constructor(e=50,t=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=fa*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(fr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return fa*2*Math.atan(Math.tan(fr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){Wn.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Wn.x,Wn.y).multiplyScalar(-e/Wn.z),Wn.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Wn.x,Wn.y).multiplyScalar(-e/Wn.z)}getViewSize(e,t){return this.getViewBounds(e,Rl,Ml),t.subVectors(Ml,Rl)}setViewOffset(e,t,i,s,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(fr*.5*this.fov)/this.zoom,i=2*t,s=this.aspect*i,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const d=a.fullWidth,u=a.fullHeight;r+=a.offsetX*s/d,t-=a.offsetY*i/u,s*=a.width/d,i*=a.height/u}const l=this.filmOffset;l!==0&&(r+=e*l/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Ni=-90,Ui=1;class nd extends Xt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new zt(Ni,Ui,e,t);s.layers=this.layers,this.add(s);const r=new zt(Ni,Ui,e,t);r.layers=this.layers,this.add(r);const a=new zt(Ni,Ui,e,t);a.layers=this.layers,this.add(a);const l=new zt(Ni,Ui,e,t);l.layers=this.layers,this.add(l);const d=new zt(Ni,Ui,e,t);d.layers=this.layers,this.add(d);const u=new zt(Ni,Ui,e,t);u.layers=this.layers,this.add(u)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,s,r,a,l,d]=t;for(const u of t)this.remove(u);if(e===fn)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),l.up.set(0,1,0),l.lookAt(0,0,1),d.up.set(0,1,0),d.lookAt(0,0,-1);else if(e===Sr)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),l.up.set(0,-1,0),l.lookAt(0,0,1),d.up.set(0,-1,0),d.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const u of t)this.add(u),u.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,a,l,d,u,p]=this.children,o=e.getRenderTarget(),c=e.getActiveCubeFace(),h=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;const S=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,s),e.render(t,r),e.setRenderTarget(i,1,s),e.render(t,a),e.setRenderTarget(i,2,s),e.render(t,l),e.setRenderTarget(i,3,s),e.render(t,d),e.setRenderTarget(i,4,s),e.render(t,u),i.texture.generateMipmaps=S,e.setRenderTarget(i,5,s),e.render(t,p),e.setRenderTarget(o,c,h),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}}class Yc extends Ut{constructor(e=[],t=Xi,i,s,r,a,l,d,u,p){super(e,t,i,s,r,a,l,d,u,p),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class id extends wn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},s=[i,i,i,i,i,i];this.texture=new Yc(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new gi(5,5,5),r=new Bn({name:"CubemapFromEquirect",uniforms:Ji(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Ot,blending:Pn});r.uniforms.tEquirect.value=t;const a=new At(s,r),l=t.minFilter;return t.minFilter===pi&&(t.minFilter=$t),new nd(1,10,this).update(e,a),t.minFilter=l,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,i=!0,s=!0){const r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,s);e.setRenderTarget(r)}}class jt extends Xt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const sd={type:"move"};class ro{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new jt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new jt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new w,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new w),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new jt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new w,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new w),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let s=null,r=null,a=null;const l=this._targetRay,d=this._grip,u=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(u&&e.hand){a=!0;for(const S of e.hand.values()){const E=t.getJointPose(S,i),f=this._getHandJoint(u,S);E!==null&&(f.matrix.fromArray(E.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=E.radius),f.visible=E!==null}const p=u.joints["index-finger-tip"],o=u.joints["thumb-tip"],c=p.position.distanceTo(o.position),h=.02,m=.005;u.inputState.pinching&&c>h+m?(u.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!u.inputState.pinching&&c<=h-m&&(u.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else d!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,i),r!==null&&(d.matrix.fromArray(r.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,r.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(r.linearVelocity)):d.hasLinearVelocity=!1,r.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(r.angularVelocity)):d.hasAngularVelocity=!1));l!==null&&(s=t.getPose(e.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1,this.dispatchEvent(sd)))}return l!==null&&(l.visible=s!==null),d!==null&&(d.visible=r!==null),u!==null&&(u.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new jt;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class rd extends Xt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Fn,this.environmentIntensity=1,this.environmentRotation=new Fn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class od extends Ut{constructor(e=null,t=1,i=1,s,r,a,l,d,u=Kt,p=Kt,o,c){super(null,a,l,d,u,p,s,r,o,c),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const oo=new w,ad=new w,ld=new We;class On{constructor(e=new w(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,s){return this.normal.set(e,t,i),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const s=oo.subVectors(i,t).cross(ad.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(oo),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||ld.getNormalMatrix(e),s=this.coplanarPoint(oo).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const oi=new Da,cd=new le(.5,.5),js=new w;class Wc{constructor(e=new On,t=new On,i=new On,s=new On,r=new On,a=new On){this.planes=[e,t,i,s,r,a]}set(e,t,i,s,r,a){const l=this.planes;return l[0].copy(e),l[1].copy(t),l[2].copy(i),l[3].copy(s),l[4].copy(r),l[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=fn,i=!1){const s=this.planes,r=e.elements,a=r[0],l=r[1],d=r[2],u=r[3],p=r[4],o=r[5],c=r[6],h=r[7],m=r[8],S=r[9],E=r[10],f=r[11],_=r[12],A=r[13],R=r[14],C=r[15];if(s[0].setComponents(u-a,h-p,f-m,C-_).normalize(),s[1].setComponents(u+a,h+p,f+m,C+_).normalize(),s[2].setComponents(u+l,h+o,f+S,C+A).normalize(),s[3].setComponents(u-l,h-o,f-S,C-A).normalize(),i)s[4].setComponents(d,c,E,R).normalize(),s[5].setComponents(u-d,h-c,f-E,C-R).normalize();else if(s[4].setComponents(u-d,h-c,f-E,C-R).normalize(),t===fn)s[5].setComponents(u+d,h+c,f+E,C+R).normalize();else if(t===Sr)s[5].setComponents(d,c,E,R).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),oi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),oi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(oi)}intersectsSprite(e){oi.center.set(0,0,0);const t=cd.distanceTo(e.center);return oi.radius=.7071067811865476+t,oi.applyMatrix4(e.matrixWorld),this.intersectsSphere(oi)}intersectsSphere(e){const t=this.planes,i=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const s=t[i];if(js.x=s.normal.x>0?e.max.x:e.min.x,js.y=s.normal.y>0?e.max.y:e.min.y,js.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(js)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class zc extends Ut{constructor(e,t,i=Si,s,r,a,l=Kt,d=Kt,u,p=Rs,o=1){if(p!==Rs&&p!==Ms)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const c={width:e,height:t,depth:o};super(c,s,r,a,l,d,p,i,u),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Ca(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Kc extends Ut{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class An{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){Ke("Curve: .getPoint() not implemented.")}getPointAt(e,t){const i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){const t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let i,s=this.getPoint(0),r=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),r+=i.distanceTo(s),t.push(r),s=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const i=this.getLengths();let s=0;const r=i.length;let a;t?a=t:a=e*i[r-1];let l=0,d=r-1,u;for(;l<=d;)if(s=Math.floor(l+(d-l)/2),u=i[s]-a,u<0)l=s+1;else if(u>0)d=s-1;else{d=s;break}if(s=d,i[s]===a)return s/(r-1);const p=i[s],c=i[s+1]-p,h=(a-p)/c;return(s+h)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);const a=this.getPoint(s),l=this.getPoint(r),d=t||(a.isVector2?new le:new w);return d.copy(l).sub(a).normalize(),d}getTangentAt(e,t){const i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t=!1){const i=new w,s=[],r=[],a=[],l=new w,d=new _t;for(let h=0;h<=e;h++){const m=h/e;s[h]=this.getTangentAt(m,new w)}r[0]=new w,a[0]=new w;let u=Number.MAX_VALUE;const p=Math.abs(s[0].x),o=Math.abs(s[0].y),c=Math.abs(s[0].z);p<=u&&(u=p,i.set(1,0,0)),o<=u&&(u=o,i.set(0,1,0)),c<=u&&i.set(0,0,1),l.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],l),a[0].crossVectors(s[0],r[0]);for(let h=1;h<=e;h++){if(r[h]=r[h-1].clone(),a[h]=a[h-1].clone(),l.crossVectors(s[h-1],s[h]),l.length()>Number.EPSILON){l.normalize();const m=Math.acos(Ze(s[h-1].dot(s[h]),-1,1));r[h].applyMatrix4(d.makeRotationAxis(l,m))}a[h].crossVectors(s[h],r[h])}if(t===!0){let h=Math.acos(Ze(r[0].dot(r[e]),-1,1));h/=e,s[0].dot(l.crossVectors(r[0],r[e]))>0&&(h=-h);for(let m=1;m<=e;m++)r[m].applyMatrix4(d.makeRotationAxis(s[m],h*m)),a[m].crossVectors(s[m],r[m])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class Ua extends An{constructor(e=0,t=0,i=1,s=1,r=0,a=Math.PI*2,l=!1,d=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=l,this.aRotation=d}getPoint(e,t=new le){const i=t,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);const l=this.aStartAngle+e*r;let d=this.aX+this.xRadius*Math.cos(l),u=this.aY+this.yRadius*Math.sin(l);if(this.aRotation!==0){const p=Math.cos(this.aRotation),o=Math.sin(this.aRotation),c=d-this.aX,h=u-this.aY;d=c*p-h*o+this.aX,u=c*o+h*p+this.aY}return i.set(d,u)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){const e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}}class ud extends Ua{constructor(e,t,i,s,r,a){super(e,t,i,i,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}}function wa(){let n=0,e=0,t=0,i=0;function s(r,a,l,d){n=r,e=l,t=-3*r+3*a-2*l-d,i=2*r-2*a+l+d}return{initCatmullRom:function(r,a,l,d,u){s(a,l,u*(l-r),u*(d-a))},initNonuniformCatmullRom:function(r,a,l,d,u,p,o){let c=(a-r)/u-(l-r)/(u+p)+(l-a)/p,h=(l-a)/p-(d-a)/(p+o)+(d-l)/o;c*=p,h*=p,s(a,l,c,h)},calc:function(r){const a=r*r,l=a*r;return n+e*r+t*a+i*l}}}const er=new w,ao=new wa,lo=new wa,co=new wa;class hd extends An{constructor(e=[],t=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=s}getPoint(e,t=new w){const i=t,s=this.points,r=s.length,a=(r-(this.closed?0:1))*e;let l=Math.floor(a),d=a-l;this.closed?l+=l>0?0:(Math.floor(Math.abs(l)/r)+1)*r:d===0&&l===r-1&&(l=r-2,d=1);let u,p;this.closed||l>0?u=s[(l-1)%r]:(er.subVectors(s[0],s[1]).add(s[0]),u=er);const o=s[l%r],c=s[(l+1)%r];if(this.closed||l+2<r?p=s[(l+2)%r]:(er.subVectors(s[r-1],s[r-2]).add(s[r-1]),p=er),this.curveType==="centripetal"||this.curveType==="chordal"){const h=this.curveType==="chordal"?.5:.25;let m=Math.pow(u.distanceToSquared(o),h),S=Math.pow(o.distanceToSquared(c),h),E=Math.pow(c.distanceToSquared(p),h);S<1e-4&&(S=1),m<1e-4&&(m=S),E<1e-4&&(E=S),ao.initNonuniformCatmullRom(u.x,o.x,c.x,p.x,m,S,E),lo.initNonuniformCatmullRom(u.y,o.y,c.y,p.y,m,S,E),co.initNonuniformCatmullRom(u.z,o.z,c.z,p.z,m,S,E)}else this.curveType==="catmullrom"&&(ao.initCatmullRom(u.x,o.x,c.x,p.x,this.tension),lo.initCatmullRom(u.y,o.y,c.y,p.y,this.tension),co.initCatmullRom(u.z,o.z,c.z,p.z,this.tension));return i.set(ao.calc(d),lo.calc(d),co.calc(d)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new w().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}}function vl(n,e,t,i,s){const r=(i-e)*.5,a=(s-t)*.5,l=n*n,d=n*l;return(2*t-2*i+r+a)*d+(-3*t+3*i-2*r-a)*l+r*n+t}function dd(n,e){const t=1-n;return t*t*e}function fd(n,e){return 2*(1-n)*n*e}function pd(n,e){return n*n*e}function Es(n,e,t,i){return dd(n,e)+fd(n,t)+pd(n,i)}function Ed(n,e){const t=1-n;return t*t*t*e}function md(n,e){const t=1-n;return 3*t*t*n*e}function Sd(n,e){return 3*(1-n)*n*n*e}function Ad(n,e){return n*n*n*e}function ms(n,e,t,i,s){return Ed(n,e)+md(n,t)+Sd(n,i)+Ad(n,s)}class Xc extends An{constructor(e=new le,t=new le,i=new le,s=new le){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new le){const i=t,s=this.v0,r=this.v1,a=this.v2,l=this.v3;return i.set(ms(e,s.x,r.x,a.x,l.x),ms(e,s.y,r.y,a.y,l.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class _d extends An{constructor(e=new w,t=new w,i=new w,s=new w){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=s}getPoint(e,t=new w){const i=t,s=this.v0,r=this.v1,a=this.v2,l=this.v3;return i.set(ms(e,s.x,r.x,a.x,l.x),ms(e,s.y,r.y,a.y,l.y),ms(e,s.z,r.z,a.z,l.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}}class qc extends An{constructor(e=new le,t=new le){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new le){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new le){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class xd extends An{constructor(e=new w,t=new w){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new w){const i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new w){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Zc extends An{constructor(e=new le,t=new le,i=new le){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new le){const i=t,s=this.v0,r=this.v1,a=this.v2;return i.set(Es(e,s.x,r.x,a.x),Es(e,s.y,r.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class gd extends An{constructor(e=new w,t=new w,i=new w){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new w){const i=t,s=this.v0,r=this.v1,a=this.v2;return i.set(Es(e,s.x,r.x,a.x),Es(e,s.y,r.y,a.y),Es(e,s.z,r.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){const e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}}class Jc extends An{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new le){const i=t,s=this.points,r=(s.length-1)*e,a=Math.floor(r),l=r-a,d=s[a===0?a:a-1],u=s[a],p=s[a>s.length-2?s.length-1:a+1],o=s[a>s.length-3?s.length-1:a+2];return i.set(vl(l,d.x,u.x,p.x,o.x),vl(l,d.y,u.y,p.y,o.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){const s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){const s=e.points[t];this.points.push(new le().fromArray(s))}return this}}var pa=Object.freeze({__proto__:null,ArcCurve:ud,CatmullRomCurve3:hd,CubicBezierCurve:Xc,CubicBezierCurve3:_d,EllipseCurve:Ua,LineCurve:qc,LineCurve3:xd,QuadraticBezierCurve:Zc,QuadraticBezierCurve3:gd,SplineCurve:Jc});class Td extends An{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){const e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){const i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new pa[i](t,e))}return this}getPoint(e,t){const i=e*this.getLength(),s=this.getCurveLengths();let r=0;for(;r<s.length;){if(s[r]>=i){const a=s[r]-i,l=this.curves[r],d=l.getLength(),u=d===0?0:1-a/d;return l.getPointAt(u,t)}r++}return null}getLength(){const e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const e=[];let t=0;for(let i=0,s=this.curves.length;i<s;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){const t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){const t=[];let i;for(let s=0,r=this.curves;s<r.length;s++){const a=r[s],l=a.isEllipseCurve?e*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,d=a.getPoints(l);for(let u=0;u<d.length;u++){const p=d[u];i&&i.equals(p)||(t.push(p),i=p)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){const e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){const s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){const s=e.curves[t];this.curves.push(new pa[s.type]().fromJSON(s))}return this}}class mi extends Td{constructor(e){super(),this.type="Path",this.currentPoint=new le,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){const i=new qc(this.currentPoint.clone(),new le(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,s){const r=new Zc(this.currentPoint.clone(),new le(e,t),new le(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(e,t,i,s,r,a){const l=new Xc(this.currentPoint.clone(),new le(e,t),new le(i,s),new le(r,a));return this.curves.push(l),this.currentPoint.set(r,a),this}splineThru(e){const t=[this.currentPoint.clone()].concat(e),i=new Jc(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,s,r,a){const l=this.currentPoint.x,d=this.currentPoint.y;return this.absarc(e+l,t+d,i,s,r,a),this}absarc(e,t,i,s,r,a){return this.absellipse(e,t,i,i,s,r,a),this}ellipse(e,t,i,s,r,a,l,d){const u=this.currentPoint.x,p=this.currentPoint.y;return this.absellipse(e+u,t+p,i,s,r,a,l,d),this}absellipse(e,t,i,s,r,a,l,d){const u=new Ua(e,t,i,s,r,a,l,d);if(this.curves.length>0){const o=u.getPoint(0);o.equals(this.currentPoint)||this.lineTo(o.x,o.y)}this.curves.push(u);const p=u.getPoint(1);return this.currentPoint.copy(p),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){const e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}}class Jn extends mi{constructor(e){super(e),this.uuid=es(),this.type="Shape",this.holes=[]}getPointsHoles(e){const t=[];for(let i=0,s=this.holes.length;i<s;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){const e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){const s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){const s=e.holes[t];this.holes.push(new mi().fromJSON(s))}return this}}function Rd(n,e,t=2){const i=e&&e.length,s=i?e[0]*t:n.length;let r=Qc(n,0,s,t,!0);const a=[];if(!r||r.next===r.prev)return a;let l,d,u;if(i&&(r=Ld(n,e,r,t)),n.length>80*t){l=n[0],d=n[1];let p=l,o=d;for(let c=t;c<s;c+=t){const h=n[c],m=n[c+1];h<l&&(l=h),m<d&&(d=m),h>p&&(p=h),m>o&&(o=m)}u=Math.max(p-l,o-d),u=u!==0?32767/u:0}return Is(r,a,t,l,d,u,0),a}function Qc(n,e,t,i,s){let r;if(s===Hd(n,e,t,i)>0)for(let a=e;a<t;a+=i)r=Il(a/i|0,n[a],n[a+1],r);else for(let a=t-i;a>=e;a-=i)r=Il(a/i|0,n[a],n[a+1],r);return r&&Qi(r,r.next)&&(Ls(r),r=r.next),r}function Ai(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(Qi(t,t.next)||ft(t.prev,t,t.next)===0)){if(Ls(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function Is(n,e,t,i,s,r,a){if(!n)return;!a&&r&&Pd(n,i,s,r);let l=n;for(;n.prev!==n.next;){const d=n.prev,u=n.next;if(r?vd(n,i,s,r):Md(n)){e.push(d.i,n.i,u.i),Ls(n),n=u.next,l=u.next;continue}if(n=u,n===l){a?a===1?(n=Id(Ai(n),e),Is(n,e,t,i,s,r,2)):a===2&&yd(n,e,t,i,s,r):Is(Ai(n),e,t,i,s,r,1);break}}}function Md(n){const e=n.prev,t=n,i=n.next;if(ft(e,t,i)>=0)return!1;const s=e.x,r=t.x,a=i.x,l=e.y,d=t.y,u=i.y,p=Math.min(s,r,a),o=Math.min(l,d,u),c=Math.max(s,r,a),h=Math.max(l,d,u);let m=i.next;for(;m!==e;){if(m.x>=p&&m.x<=c&&m.y>=o&&m.y<=h&&fs(s,l,r,d,a,u,m.x,m.y)&&ft(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function vd(n,e,t,i){const s=n.prev,r=n,a=n.next;if(ft(s,r,a)>=0)return!1;const l=s.x,d=r.x,u=a.x,p=s.y,o=r.y,c=a.y,h=Math.min(l,d,u),m=Math.min(p,o,c),S=Math.max(l,d,u),E=Math.max(p,o,c),f=Ea(h,m,e,t,i),_=Ea(S,E,e,t,i);let A=n.prevZ,R=n.nextZ;for(;A&&A.z>=f&&R&&R.z<=_;){if(A.x>=h&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==a&&fs(l,p,d,o,u,c,A.x,A.y)&&ft(A.prev,A,A.next)>=0||(A=A.prevZ,R.x>=h&&R.x<=S&&R.y>=m&&R.y<=E&&R!==s&&R!==a&&fs(l,p,d,o,u,c,R.x,R.y)&&ft(R.prev,R,R.next)>=0))return!1;R=R.nextZ}for(;A&&A.z>=f;){if(A.x>=h&&A.x<=S&&A.y>=m&&A.y<=E&&A!==s&&A!==a&&fs(l,p,d,o,u,c,A.x,A.y)&&ft(A.prev,A,A.next)>=0)return!1;A=A.prevZ}for(;R&&R.z<=_;){if(R.x>=h&&R.x<=S&&R.y>=m&&R.y<=E&&R!==s&&R!==a&&fs(l,p,d,o,u,c,R.x,R.y)&&ft(R.prev,R,R.next)>=0)return!1;R=R.nextZ}return!0}function Id(n,e){let t=n;do{const i=t.prev,s=t.next.next;!Qi(i,s)&&jc(i,t,t.next,s)&&ys(i,s)&&ys(s,i)&&(e.push(i.i,t.i,s.i),Ls(t),Ls(t.next),t=n=s),t=t.next}while(t!==n);return Ai(t)}function yd(n,e,t,i,s,r){let a=n;do{let l=a.next.next;for(;l!==a.prev;){if(a.i!==l.i&&wd(a,l)){let d=eu(a,l);a=Ai(a,a.next),d=Ai(d,d.next),Is(a,e,t,i,s,r,0),Is(d,e,t,i,s,r,0);return}l=l.next}a=a.next}while(a!==n)}function Ld(n,e,t,i){const s=[];for(let r=0,a=e.length;r<a;r++){const l=e[r]*i,d=r<a-1?e[r+1]*i:n.length,u=Qc(n,l,d,i,!1);u===u.next&&(u.steiner=!0),s.push(Ud(u))}s.sort(Od);for(let r=0;r<s.length;r++)t=bd(s[r],t);return t}function Od(n,e){let t=n.x-e.x;if(t===0&&(t=n.y-e.y,t===0)){const i=(n.next.y-n.y)/(n.next.x-n.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=i-s}return t}function bd(n,e){const t=Cd(n,e);if(!t)return e;const i=eu(t,n);return Ai(i,i.next),Ai(t,t.next)}function Cd(n,e){let t=e;const i=n.x,s=n.y;let r=-1/0,a;if(Qi(n,t))return t;do{if(Qi(n,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){const o=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(o<=i&&o>r&&(r=o,a=t.x<t.next.x?t:t.next,o===i))return a}t=t.next}while(t!==e);if(!a)return null;const l=a,d=a.x,u=a.y;let p=1/0;t=a;do{if(i>=t.x&&t.x>=d&&i!==t.x&&$c(s<u?i:r,s,d,u,s<u?r:i,s,t.x,t.y)){const o=Math.abs(s-t.y)/(i-t.x);ys(t,n)&&(o<p||o===p&&(t.x>a.x||t.x===a.x&&Dd(a,t)))&&(a=t,p=o)}t=t.next}while(t!==l);return a}function Dd(n,e){return ft(n.prev,n,e.prev)<0&&ft(e.next,n,n.next)<0}function Pd(n,e,t,i){let s=n;do s.z===0&&(s.z=Ea(s.x,s.y,e,t,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,Nd(s)}function Nd(n){let e,t=1;do{let i=n,s;n=null;let r=null;for(e=0;i;){e++;let a=i,l=0;for(let u=0;u<t&&(l++,a=a.nextZ,!!a);u++);let d=t;for(;l>0||d>0&&a;)l!==0&&(d===0||!a||i.z<=a.z)?(s=i,i=i.nextZ,l--):(s=a,a=a.nextZ,d--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;i=a}r.nextZ=null,t*=2}while(e>1);return n}function Ea(n,e,t,i,s){return n=(n-t)*s|0,e=(e-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function Ud(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function $c(n,e,t,i,s,r,a,l){return(s-a)*(e-l)>=(n-a)*(r-l)&&(n-a)*(i-l)>=(t-a)*(e-l)&&(t-a)*(r-l)>=(s-a)*(i-l)}function fs(n,e,t,i,s,r,a,l){return!(n===a&&e===l)&&$c(n,e,t,i,s,r,a,l)}function wd(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!Fd(n,e)&&(ys(n,e)&&ys(e,n)&&Bd(n,e)&&(ft(n.prev,n,e.prev)||ft(n,e.prev,e))||Qi(n,e)&&ft(n.prev,n,n.next)>0&&ft(e.prev,e,e.next)>0)}function ft(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function Qi(n,e){return n.x===e.x&&n.y===e.y}function jc(n,e,t,i){const s=nr(ft(n,e,t)),r=nr(ft(n,e,i)),a=nr(ft(t,i,n)),l=nr(ft(t,i,e));return!!(s!==r&&a!==l||s===0&&tr(n,t,e)||r===0&&tr(n,i,e)||a===0&&tr(t,n,i)||l===0&&tr(t,e,i))}function tr(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function nr(n){return n>0?1:n<0?-1:0}function Fd(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&jc(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function ys(n,e){return ft(n.prev,n,n.next)<0?ft(n,e,n.next)>=0&&ft(n,n.prev,e)>=0:ft(n,e,n.prev)<0||ft(n,n.next,e)<0}function Bd(n,e){let t=n,i=!1;const s=(n.x+e.x)/2,r=(n.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function eu(n,e){const t=ma(n.i,n.x,n.y),i=ma(e.i,e.x,e.y),s=n.next,r=e.prev;return n.next=e,e.prev=n,t.next=s,s.prev=t,i.next=t,t.prev=i,r.next=i,i.prev=r,i}function Il(n,e,t,i){const s=ma(n,e,t);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function Ls(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function ma(n,e,t){return{i:n,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Hd(n,e,t,i){let s=0;for(let r=e,a=t-i;r<t;r+=i)s+=(n[a]-n[r])*(n[r+1]+n[a+1]),a=r;return s}class Gd{static triangulate(e,t,i=2){return Rd(e,t,i)}}class cn{static area(e){const t=e.length;let i=0;for(let s=t-1,r=0;r<t;s=r++)i+=e[s].x*e[r].y-e[r].x*e[s].y;return i*.5}static isClockWise(e){return cn.area(e)<0}static triangulateShape(e,t){const i=[],s=[],r=[];yl(e),Ll(i,e);let a=e.length;t.forEach(yl);for(let d=0;d<t.length;d++)s.push(a),a+=t[d].length,Ll(i,t[d]);const l=Gd.triangulate(i,s);for(let d=0;d<l.length;d+=3)r.push(l.slice(d,d+3));return r}}function yl(n){const e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function Ll(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}class Fa extends Rt{constructor(e=new Jn([new le(.5,.5),new le(-.5,.5),new le(-.5,-.5),new le(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];const i=this,s=[],r=[];for(let l=0,d=e.length;l<d;l++){const u=e[l];a(u)}this.setAttribute("position",new Tt(s,3)),this.setAttribute("uv",new Tt(r,2)),this.computeVertexNormals();function a(l){const d=[],u=t.curveSegments!==void 0?t.curveSegments:12,p=t.steps!==void 0?t.steps:1,o=t.depth!==void 0?t.depth:1;let c=t.bevelEnabled!==void 0?t.bevelEnabled:!0,h=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:h-.1,S=t.bevelOffset!==void 0?t.bevelOffset:0,E=t.bevelSegments!==void 0?t.bevelSegments:3;const f=t.extrudePath,_=t.UVGenerator!==void 0?t.UVGenerator:Vd;let A,R=!1,C,L,D,F;f&&(A=f.getSpacedPoints(p),R=!0,c=!1,C=f.computeFrenetFrames(p,!1),L=new w,D=new w,F=new w),c||(E=0,h=0,m=0,S=0);const I=l.extractPoints(u);let M=I.shape;const N=I.holes;if(!cn.isClockWise(M)){M=M.reverse();for(let G=0,T=N.length;G<T;G++){const q=N[G];cn.isClockWise(q)&&(N[G]=q.reverse())}}function Z(G){const q=10000000000000001e-36;let $=G[0];for(let P=1;P<=G.length;P++){const O=P%G.length,ae=G[O],ue=ae.x-$.x,Re=ae.y-$.y,b=ue*ue+Re*Re,x=Math.max(Math.abs(ae.x),Math.abs(ae.y),Math.abs($.x),Math.abs($.y)),Y=q*x*x;if(b<=Y){G.splice(O,1),P--;continue}$=ae}}Z(M),N.forEach(Z);const J=N.length,Q=M;for(let G=0;G<J;G++){const T=N[G];M=M.concat(T)}function ie(G,T,q){return T||dt("ExtrudeGeometry: vec does not exist"),G.clone().addScaledVector(T,q)}const j=M.length;function H(G,T,q){let $,P,O;const ae=G.x-T.x,ue=G.y-T.y,Re=q.x-G.x,b=q.y-G.y,x=ae*ae+ue*ue,Y=ae*b-ue*Re;if(Math.abs(Y)>Number.EPSILON){const se=Math.sqrt(x),pe=Math.sqrt(Re*Re+b*b),ne=T.x-ue/se,De=T.y+ae/se,Te=q.x-b/pe,Ue=q.y+Re/pe,Ce=((Te-ne)*b-(Ue-De)*Re)/(ae*b-ue*Re);$=ne+ae*Ce-G.x,P=De+ue*Ce-G.y;const me=$*$+P*P;if(me<=2)return new le($,P);O=Math.sqrt(me/2)}else{let se=!1;ae>Number.EPSILON?Re>Number.EPSILON&&(se=!0):ae<-Number.EPSILON?Re<-Number.EPSILON&&(se=!0):Math.sign(ue)===Math.sign(b)&&(se=!0),se?($=-ue,P=ae,O=Math.sqrt(x)):($=ae,P=ue,O=Math.sqrt(x/2))}return new le($/O,P/O)}const Ee=[];for(let G=0,T=Q.length,q=T-1,$=G+1;G<T;G++,q++,$++)q===T&&(q=0),$===T&&($=0),Ee[G]=H(Q[G],Q[q],Q[$]);const re=[];let ge,we=Ee.concat();for(let G=0,T=J;G<T;G++){const q=N[G];ge=[];for(let $=0,P=q.length,O=P-1,ae=$+1;$<P;$++,O++,ae++)O===P&&(O=0),ae===P&&(ae=0),ge[$]=H(q[$],q[O],q[ae]);re.push(ge),we=we.concat(ge)}let Ve;if(E===0)Ve=cn.triangulateShape(Q,N);else{const G=[],T=[];for(let q=0;q<E;q++){const $=q/E,P=h*Math.cos($*Math.PI/2),O=m*Math.sin($*Math.PI/2)+S;for(let ae=0,ue=Q.length;ae<ue;ae++){const Re=ie(Q[ae],Ee[ae],O);oe(Re.x,Re.y,-P),$===0&&G.push(Re)}for(let ae=0,ue=J;ae<ue;ae++){const Re=N[ae];ge=re[ae];const b=[];for(let x=0,Y=Re.length;x<Y;x++){const se=ie(Re[x],ge[x],O);oe(se.x,se.y,-P),$===0&&b.push(se)}$===0&&T.push(b)}}Ve=cn.triangulateShape(G,T)}const z=Ve.length,U=m+S;for(let G=0;G<j;G++){const T=c?ie(M[G],we[G],U):M[G];R?(D.copy(C.normals[0]).multiplyScalar(T.x),L.copy(C.binormals[0]).multiplyScalar(T.y),F.copy(A[0]).add(D).add(L),oe(F.x,F.y,F.z)):oe(T.x,T.y,0)}for(let G=1;G<=p;G++)for(let T=0;T<j;T++){const q=c?ie(M[T],we[T],U):M[T];R?(D.copy(C.normals[G]).multiplyScalar(q.x),L.copy(C.binormals[G]).multiplyScalar(q.y),F.copy(A[G]).add(D).add(L),oe(F.x,F.y,F.z)):oe(q.x,q.y,o/p*G)}for(let G=E-1;G>=0;G--){const T=G/E,q=h*Math.cos(T*Math.PI/2),$=m*Math.sin(T*Math.PI/2)+S;for(let P=0,O=Q.length;P<O;P++){const ae=ie(Q[P],Ee[P],$);oe(ae.x,ae.y,o+q)}for(let P=0,O=N.length;P<O;P++){const ae=N[P];ge=re[P];for(let ue=0,Re=ae.length;ue<Re;ue++){const b=ie(ae[ue],ge[ue],$);R?oe(b.x,b.y+A[p-1].y,A[p-1].x+q):oe(b.x,b.y,o+q)}}}v(),g();function v(){const G=s.length/3;if(c){let T=0,q=j*T;for(let $=0;$<z;$++){const P=Ve[$];k(P[2]+q,P[1]+q,P[0]+q)}T=p+E*2,q=j*T;for(let $=0;$<z;$++){const P=Ve[$];k(P[0]+q,P[1]+q,P[2]+q)}}else{for(let T=0;T<z;T++){const q=Ve[T];k(q[2],q[1],q[0])}for(let T=0;T<z;T++){const q=Ve[T];k(q[0]+j*p,q[1]+j*p,q[2]+j*p)}}i.addGroup(G,s.length/3-G,0)}function g(){const G=s.length/3;let T=0;K(Q,T),T+=Q.length;for(let q=0,$=N.length;q<$;q++){const P=N[q];K(P,T),T+=P.length}i.addGroup(G,s.length/3-G,1)}function K(G,T){let q=G.length;for(;--q>=0;){const $=q;let P=q-1;P<0&&(P=G.length-1);for(let O=0,ae=p+E*2;O<ae;O++){const ue=j*O,Re=j*(O+1),b=T+$+ue,x=T+P+ue,Y=T+P+Re,se=T+$+Re;he(b,x,Y,se)}}}function oe(G,T,q){d.push(G),d.push(T),d.push(q)}function k(G,T,q){Ae(G),Ae(T),Ae(q);const $=s.length/3,P=_.generateTopUV(i,s,$-3,$-2,$-1);de(P[0]),de(P[1]),de(P[2])}function he(G,T,q,$){Ae(G),Ae(T),Ae($),Ae(T),Ae(q),Ae($);const P=s.length/3,O=_.generateSideWallUV(i,s,P-6,P-3,P-2,P-1);de(O[0]),de(O[1]),de(O[3]),de(O[1]),de(O[2]),de(O[3])}function Ae(G){s.push(d[G*3+0]),s.push(d[G*3+1]),s.push(d[G*3+2])}function de(G){r.push(G.x),r.push(G.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes,i=this.parameters.options;return kd(t,i,e)}static fromJSON(e,t){const i=[];for(let r=0,a=e.shapes.length;r<a;r++){const l=t[e.shapes[r]];i.push(l)}const s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new pa[s.type]().fromJSON(s)),new Fa(i,e.options)}}const Vd={generateTopUV:function(n,e,t,i,s){const r=e[t*3],a=e[t*3+1],l=e[i*3],d=e[i*3+1],u=e[s*3],p=e[s*3+1];return[new le(r,a),new le(l,d),new le(u,p)]},generateSideWallUV:function(n,e,t,i,s,r){const a=e[t*3],l=e[t*3+1],d=e[t*3+2],u=e[i*3],p=e[i*3+1],o=e[i*3+2],c=e[s*3],h=e[s*3+1],m=e[s*3+2],S=e[r*3],E=e[r*3+1],f=e[r*3+2];return Math.abs(l-p)<Math.abs(a-u)?[new le(a,1-d),new le(u,1-o),new le(c,1-m),new le(S,1-f)]:[new le(l,1-d),new le(p,1-o),new le(h,1-m),new le(E,1-f)]}};function kd(n,e,t){if(t.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){const r=n[i];t.shapes.push(r.uuid)}else t.shapes.push(n.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}class ei extends Rt{constructor(e=1,t=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:s};const r=e/2,a=t/2,l=Math.floor(i),d=Math.floor(s),u=l+1,p=d+1,o=e/l,c=t/d,h=[],m=[],S=[],E=[];for(let f=0;f<p;f++){const _=f*c-a;for(let A=0;A<u;A++){const R=A*o-r;m.push(R,-_,0),S.push(0,0,1),E.push(A/l),E.push(1-f/d)}}for(let f=0;f<d;f++)for(let _=0;_<l;_++){const A=_+u*f,R=_+u*(f+1),C=_+1+u*(f+1),L=_+1+u*f;h.push(A,R,L),h.push(R,C,L)}this.setIndex(h),this.setAttribute("position",new Tt(m,3)),this.setAttribute("normal",new Tt(S,3)),this.setAttribute("uv",new Tt(E,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ei(e.width,e.height,e.widthSegments,e.heightSegments)}}class Ba extends Rt{constructor(e=new Jn([new le(0,.5),new le(-.5,-.5),new le(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};const i=[],s=[],r=[],a=[];let l=0,d=0;if(Array.isArray(e)===!1)u(e);else for(let p=0;p<e.length;p++)u(e[p]),this.addGroup(l,d,p),l+=d,d=0;this.setIndex(i),this.setAttribute("position",new Tt(s,3)),this.setAttribute("normal",new Tt(r,3)),this.setAttribute("uv",new Tt(a,2));function u(p){const o=s.length/3,c=p.extractPoints(t);let h=c.shape;const m=c.holes;cn.isClockWise(h)===!1&&(h=h.reverse());for(let E=0,f=m.length;E<f;E++){const _=m[E];cn.isClockWise(_)===!0&&(m[E]=_.reverse())}const S=cn.triangulateShape(h,m);for(let E=0,f=m.length;E<f;E++){const _=m[E];h=h.concat(_)}for(let E=0,f=h.length;E<f;E++){const _=h[E];s.push(_.x,_.y,0),r.push(0,0,1),a.push(_.x,_.y)}for(let E=0,f=S.length;E<f;E++){const _=S[E],A=_[0]+o,R=_[1]+o,C=_[2]+o;i.push(A,R,C),d+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){const e=super.toJSON(),t=this.parameters.shapes;return Yd(t,e)}static fromJSON(e,t){const i=[];for(let s=0,r=e.shapes.length;s<r;s++){const a=t[e.shapes[s]];i.push(a)}return new Ba(i,e.curveSegments)}}function Yd(n,e){if(e.shapes=[],Array.isArray(n))for(let t=0,i=n.length;t<i;t++){const s=n[t];e.shapes.push(s.uuid)}else e.shapes.push(n.uuid);return e}class Wd extends Ir{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=xh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class zd extends Ir{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Ol={enabled:!1,files:{},add:function(n,e){this.enabled!==!1&&(this.files[n]=e)},get:function(n){if(this.enabled!==!1)return this.files[n]},remove:function(n){delete this.files[n]},clear:function(){this.files={}}};class Kd{constructor(e,t,i){const s=this;let r=!1,a=0,l=0,d;const u=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this._abortController=null,this.itemStart=function(p){l++,r===!1&&s.onStart!==void 0&&s.onStart(p,a,l),r=!0},this.itemEnd=function(p){a++,s.onProgress!==void 0&&s.onProgress(p,a,l),a===l&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(p){s.onError!==void 0&&s.onError(p)},this.resolveURL=function(p){return d?d(p):p},this.setURLModifier=function(p){return d=p,this},this.addHandler=function(p,o){return u.push(p,o),this},this.removeHandler=function(p){const o=u.indexOf(p);return o!==-1&&u.splice(o,2),this},this.getHandler=function(p){for(let o=0,c=u.length;o<c;o+=2){const h=u[o],m=u[o+1];if(h.global&&(h.lastIndex=0),h.test(p))return m}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}}const Xd=new Kd;class Ha{constructor(e){this.manager=e!==void 0?e:Xd,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const i=this;return new Promise(function(s,r){i.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}Ha.DEFAULT_MATERIAL_NAME="__DEFAULT";const vn={};class qd extends Error{constructor(e,t){super(e),this.response=t}}class Zd extends Ha{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,i,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=Ol.get(`file:${e}`);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(vn[e]!==void 0){vn[e].push({onLoad:t,onProgress:i,onError:s});return}vn[e]=[],vn[e].push({onLoad:t,onProgress:i,onError:s});const a=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),l=this.mimeType,d=this.responseType;fetch(a).then(u=>{if(u.status===200||u.status===0){if(u.status===0&&Ke("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||u.body===void 0||u.body.getReader===void 0)return u;const p=vn[e],o=u.body.getReader(),c=u.headers.get("X-File-Size")||u.headers.get("Content-Length"),h=c?parseInt(c):0,m=h!==0;let S=0;const E=new ReadableStream({start(f){_();function _(){o.read().then(({done:A,value:R})=>{if(A)f.close();else{S+=R.byteLength;const C=new ProgressEvent("progress",{lengthComputable:m,loaded:S,total:h});for(let L=0,D=p.length;L<D;L++){const F=p[L];F.onProgress&&F.onProgress(C)}f.enqueue(R),_()}},A=>{f.error(A)})}}});return new Response(E)}else throw new qd(`fetch for "${u.url}" responded with ${u.status}: ${u.statusText}`,u)}).then(u=>{switch(d){case"arraybuffer":return u.arrayBuffer();case"blob":return u.blob();case"document":return u.text().then(p=>new DOMParser().parseFromString(p,l));case"json":return u.json();default:if(l==="")return u.text();{const o=/charset="?([^;"\s]*)"?/i.exec(l),c=o&&o[1]?o[1].toLowerCase():void 0,h=new TextDecoder(c);return u.arrayBuffer().then(m=>h.decode(m))}}}).then(u=>{Ol.add(`file:${e}`,u);const p=vn[e];delete vn[e];for(let o=0,c=p.length;o<c;o++){const h=p[o];h.onLoad&&h.onLoad(u)}}).catch(u=>{const p=vn[e];if(p===void 0)throw this.manager.itemError(e),u;delete vn[e];for(let o=0,c=p.length;o<c;o++){const h=p[o];h.onError&&h.onError(u)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class Jd extends kc{constructor(e=-1,t=1,i=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=i-e,a=i+e,l=s+t,d=s-t;if(this.view!==null&&this.view.enabled){const u=(this.right-this.left)/this.view.fullWidth/this.zoom,p=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=u*this.view.offsetX,a=r+u*this.view.width,l-=p*this.view.offsetY,d=l-p*this.view.height}this.projectionMatrix.makeOrthographic(r,a,l,d,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Qd extends zt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const bl=new _t;class Ga{constructor(e,t,i=0,s=1/0){this.ray=new Pa(e,t),this.near=i,this.far=s,this.camera=null,this.layers=new Na,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):dt("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return bl.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(bl),this}intersectObject(e,t=!0,i=[]){return Sa(e,this,i,t),i.sort(Cl),i}intersectObjects(e,t=!0,i=[]){for(let s=0,r=e.length;s<r;s++)Sa(e[s],this,i,t);return i.sort(Cl),i}}function Cl(n,e){return n.distance-e.distance}function Sa(n,e,t,i){let s=!0;if(n.layers.test(e.layers)&&n.raycast(e,t)===!1&&(s=!1),s===!0&&i===!0){const r=n.children;for(let a=0,l=r.length;a<l;a++)Sa(r[a],e,t,!0)}}class Dl{constructor(e=1,t=0,i=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.radius=e,this.phi=t,this.theta=i}set(e,t,i){return this.radius=e,this.phi=t,this.theta=i,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Ze(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,i){return this.radius=Math.sqrt(e*e+t*t+i*i),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,i),this.phi=Math.acos(Ze(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const Pl=new le;class $d{constructor(e=new le(1/0,1/0),t=new le(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=Pl.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Pl).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}class ai{constructor(){this.type="ShapePath",this.color=new Qe,this.subPaths=[],this.currentPath=null}moveTo(e,t){return this.currentPath=new mi,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,i,s){return this.currentPath.quadraticCurveTo(e,t,i,s),this}bezierCurveTo(e,t,i,s,r,a){return this.currentPath.bezierCurveTo(e,t,i,s,r,a),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(e){function t(f){const _=[];for(let A=0,R=f.length;A<R;A++){const C=f[A],L=new Jn;L.curves=C.curves,_.push(L)}return _}function i(f,_){const A=_.length;let R=!1;for(let C=A-1,L=0;L<A;C=L++){let D=_[C],F=_[L],I=F.x-D.x,M=F.y-D.y;if(Math.abs(M)>Number.EPSILON){if(M<0&&(D=_[L],I=-I,F=_[C],M=-M),f.y<D.y||f.y>F.y)continue;if(f.y===D.y){if(f.x===D.x)return!0}else{const N=M*(f.x-D.x)-I*(f.y-D.y);if(N===0)return!0;if(N<0)continue;R=!R}}else{if(f.y!==D.y)continue;if(F.x<=f.x&&f.x<=D.x||D.x<=f.x&&f.x<=F.x)return!0}}return R}const s=cn.isClockWise,r=this.subPaths;if(r.length===0)return[];let a,l,d;const u=[];if(r.length===1)return l=r[0],d=new Jn,d.curves=l.curves,u.push(d),u;let p=!s(r[0].getPoints());p=e?!p:p;const o=[],c=[];let h=[],m=0,S;c[m]=void 0,h[m]=[];for(let f=0,_=r.length;f<_;f++)l=r[f],S=l.getPoints(),a=s(S),a=e?!a:a,a?(!p&&c[m]&&m++,c[m]={s:new Jn,p:S},c[m].s.curves=l.curves,p&&m++,h[m]=[]):h[m].push({h:l,p:S[0]});if(!c[0])return t(r);if(c.length>1){let f=!1,_=0;for(let A=0,R=c.length;A<R;A++)o[A]=[];for(let A=0,R=c.length;A<R;A++){const C=h[A];for(let L=0;L<C.length;L++){const D=C[L];let F=!0;for(let I=0;I<c.length;I++)i(D.p,c[I].p)&&(A!==I&&_++,F?(F=!1,o[I].push(D)):f=!0);F&&o[A].push(D)}}_>0&&f===!1&&(h=o)}let E;for(let f=0,_=c.length;f<_;f++){d=c[f].s,u.push(d),E=h[f];for(let A=0,R=E.length;A<R;A++)d.holes.push(E[A].h)}return u}}class jd extends xi{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){if(e===void 0){Ke("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}}function Nl(n,e,t,i){const s=ef(i);switch(t){case Dc:return n*e;case Nc:return n*e/s.components*s.byteLength;case ya:return n*e/s.components*s.byteLength;case La:return n*e*2/s.components*s.byteLength;case Oa:return n*e*2/s.components*s.byteLength;case Pc:return n*e*3/s.components*s.byteLength;case ln:return n*e*4/s.components*s.byteLength;case ba:return n*e*4/s.components*s.byteLength;case cr:case ur:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case hr:case dr:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Go:case ko:return Math.max(n,16)*Math.max(e,8)/4;case Ho:case Vo:return Math.max(n,8)*Math.max(e,8)/2;case Yo:case Wo:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case zo:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Ko:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case Xo:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case qo:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case Zo:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case Jo:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case Qo:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case $o:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case jo:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case ea:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case ta:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case na:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case ia:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case sa:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case ra:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case oa:case aa:case la:return Math.ceil(n/4)*Math.ceil(e/4)*16;case ca:case ua:return Math.ceil(n/4)*Math.ceil(e/4)*8;case ha:case da:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function ef(n){switch(n){case Un:case Lc:return{byteLength:1,components:1};case gs:case Oc:case ji:return{byteLength:2,components:1};case va:case Ia:return{byteLength:2,components:4};case Si:case Ma:case Dn:return{byteLength:4,components:1};case bc:case Cc:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${n}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ra}}));typeof window<"u"&&(window.__THREE__?Ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ra);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function tu(){let n=null,e=!1,t=null,i=null;function s(r,a){t(r,a),i=n.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(s),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){n=r}}}function tf(n){const e=new WeakMap;function t(l,d){const u=l.array,p=l.usage,o=u.byteLength,c=n.createBuffer();n.bindBuffer(d,c),n.bufferData(d,u,p),l.onUploadCallback();let h;if(u instanceof Float32Array)h=n.FLOAT;else if(typeof Float16Array<"u"&&u instanceof Float16Array)h=n.HALF_FLOAT;else if(u instanceof Uint16Array)l.isFloat16BufferAttribute?h=n.HALF_FLOAT:h=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)h=n.SHORT;else if(u instanceof Uint32Array)h=n.UNSIGNED_INT;else if(u instanceof Int32Array)h=n.INT;else if(u instanceof Int8Array)h=n.BYTE;else if(u instanceof Uint8Array)h=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)h=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:c,type:h,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:o}}function i(l,d,u){const p=d.array,o=d.updateRanges;if(n.bindBuffer(u,l),o.length===0)n.bufferSubData(u,0,p);else{o.sort((h,m)=>h.start-m.start);let c=0;for(let h=1;h<o.length;h++){const m=o[c],S=o[h];S.start<=m.start+m.count+1?m.count=Math.max(m.count,S.start+S.count-m.start):(++c,o[c]=S)}o.length=c+1;for(let h=0,m=o.length;h<m;h++){const S=o[h];n.bufferSubData(u,S.start*p.BYTES_PER_ELEMENT,p,S.start,S.count)}d.clearUpdateRanges()}d.onUploadCallback()}function s(l){return l.isInterleavedBufferAttribute&&(l=l.data),e.get(l)}function r(l){l.isInterleavedBufferAttribute&&(l=l.data);const d=e.get(l);d&&(n.deleteBuffer(d.buffer),e.delete(l))}function a(l,d){if(l.isInterleavedBufferAttribute&&(l=l.data),l.isGLBufferAttribute){const p=e.get(l);(!p||p.version<l.version)&&e.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}const u=e.get(l);if(u===void 0)e.set(l,t(l,d));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(u.buffer,l,d),u.version=l.version}}return{get:s,remove:r,update:a}}var nf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,sf=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,rf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,of=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,af=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,lf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,cf=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,uf=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,hf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,df=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,ff=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,pf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Ef=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,mf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Sf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Af=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,_f=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,xf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,gf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Tf=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Rf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Mf=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,vf=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,If=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,yf=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Lf=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Of=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,bf=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Cf=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Df=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Pf="gl_FragColor = linearToOutputTexel( gl_FragColor );",Nf=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Uf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,wf=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Ff=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Bf=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Hf=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Gf=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Vf=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,kf=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Yf=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Wf=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,zf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Kf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Xf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,qf=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Zf=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Jf=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Qf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,$f=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,jf=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ep=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,tp=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,np=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,ip=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,sp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,rp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,op=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ap=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,lp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,cp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,up=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,hp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,dp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,fp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,pp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ep=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,mp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Sp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Ap=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,_p=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,xp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,gp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Tp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Rp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Mp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,vp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Ip=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,yp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Lp=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Op=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,bp=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Cp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Dp=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Pp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Np=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Up=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,wp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Fp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Bp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Hp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Gp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Vp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,kp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Yp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Wp=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,zp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Kp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Xp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,qp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Zp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Jp=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Qp=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,$p=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,eE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,tE=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const nE=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,iE=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,rE=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,oE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,aE=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,cE=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,uE=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,hE=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,dE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,fE=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pE=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,EE=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,SE=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,AE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,_E=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,xE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,gE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,TE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,RE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,ME=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,IE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,yE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,LE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,OE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,CE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,DE=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,PE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,NE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,UE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,qe={alphahash_fragment:nf,alphahash_pars_fragment:sf,alphamap_fragment:rf,alphamap_pars_fragment:of,alphatest_fragment:af,alphatest_pars_fragment:lf,aomap_fragment:cf,aomap_pars_fragment:uf,batching_pars_vertex:hf,batching_vertex:df,begin_vertex:ff,beginnormal_vertex:pf,bsdfs:Ef,iridescence_fragment:mf,bumpmap_pars_fragment:Sf,clipping_planes_fragment:Af,clipping_planes_pars_fragment:_f,clipping_planes_pars_vertex:xf,clipping_planes_vertex:gf,color_fragment:Tf,color_pars_fragment:Rf,color_pars_vertex:Mf,color_vertex:vf,common:If,cube_uv_reflection_fragment:yf,defaultnormal_vertex:Lf,displacementmap_pars_vertex:Of,displacementmap_vertex:bf,emissivemap_fragment:Cf,emissivemap_pars_fragment:Df,colorspace_fragment:Pf,colorspace_pars_fragment:Nf,envmap_fragment:Uf,envmap_common_pars_fragment:wf,envmap_pars_fragment:Ff,envmap_pars_vertex:Bf,envmap_physical_pars_fragment:Zf,envmap_vertex:Hf,fog_vertex:Gf,fog_pars_vertex:Vf,fog_fragment:kf,fog_pars_fragment:Yf,gradientmap_pars_fragment:Wf,lightmap_pars_fragment:zf,lights_lambert_fragment:Kf,lights_lambert_pars_fragment:Xf,lights_pars_begin:qf,lights_toon_fragment:Jf,lights_toon_pars_fragment:Qf,lights_phong_fragment:$f,lights_phong_pars_fragment:jf,lights_physical_fragment:ep,lights_physical_pars_fragment:tp,lights_fragment_begin:np,lights_fragment_maps:ip,lights_fragment_end:sp,logdepthbuf_fragment:rp,logdepthbuf_pars_fragment:op,logdepthbuf_pars_vertex:ap,logdepthbuf_vertex:lp,map_fragment:cp,map_pars_fragment:up,map_particle_fragment:hp,map_particle_pars_fragment:dp,metalnessmap_fragment:fp,metalnessmap_pars_fragment:pp,morphinstance_vertex:Ep,morphcolor_vertex:mp,morphnormal_vertex:Sp,morphtarget_pars_vertex:Ap,morphtarget_vertex:_p,normal_fragment_begin:xp,normal_fragment_maps:gp,normal_pars_fragment:Tp,normal_pars_vertex:Rp,normal_vertex:Mp,normalmap_pars_fragment:vp,clearcoat_normal_fragment_begin:Ip,clearcoat_normal_fragment_maps:yp,clearcoat_pars_fragment:Lp,iridescence_pars_fragment:Op,opaque_fragment:bp,packing:Cp,premultiplied_alpha_fragment:Dp,project_vertex:Pp,dithering_fragment:Np,dithering_pars_fragment:Up,roughnessmap_fragment:wp,roughnessmap_pars_fragment:Fp,shadowmap_pars_fragment:Bp,shadowmap_pars_vertex:Hp,shadowmap_vertex:Gp,shadowmask_pars_fragment:Vp,skinbase_vertex:kp,skinning_pars_vertex:Yp,skinning_vertex:Wp,skinnormal_vertex:zp,specularmap_fragment:Kp,specularmap_pars_fragment:Xp,tonemapping_fragment:qp,tonemapping_pars_fragment:Zp,transmission_fragment:Jp,transmission_pars_fragment:Qp,uv_pars_fragment:$p,uv_pars_vertex:jp,uv_vertex:eE,worldpos_vertex:tE,background_vert:nE,background_frag:iE,backgroundCube_vert:sE,backgroundCube_frag:rE,cube_vert:oE,cube_frag:aE,depth_vert:lE,depth_frag:cE,distanceRGBA_vert:uE,distanceRGBA_frag:hE,equirect_vert:dE,equirect_frag:fE,linedashed_vert:pE,linedashed_frag:EE,meshbasic_vert:mE,meshbasic_frag:SE,meshlambert_vert:AE,meshlambert_frag:_E,meshmatcap_vert:xE,meshmatcap_frag:gE,meshnormal_vert:TE,meshnormal_frag:RE,meshphong_vert:ME,meshphong_frag:vE,meshphysical_vert:IE,meshphysical_frag:yE,meshtoon_vert:LE,meshtoon_frag:OE,points_vert:bE,points_frag:CE,shadow_vert:DE,shadow_frag:PE,sprite_vert:NE,sprite_frag:UE},Ie={common:{diffuse:{value:new Qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new We}},envmap:{envMap:{value:null},envMapRotation:{value:new We},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new We}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new We}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new We},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new We},normalScale:{value:new le(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new We},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new We}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new We}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new We}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0},uvTransform:{value:new We}},sprite:{diffuse:{value:new Qe(16777215)},opacity:{value:1},center:{value:new le(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}}},dn={basic:{uniforms:Pt([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.fog]),vertexShader:qe.meshbasic_vert,fragmentShader:qe.meshbasic_frag},lambert:{uniforms:Pt([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,Ie.lights,{emissive:{value:new Qe(0)}}]),vertexShader:qe.meshlambert_vert,fragmentShader:qe.meshlambert_frag},phong:{uniforms:Pt([Ie.common,Ie.specularmap,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,Ie.lights,{emissive:{value:new Qe(0)},specular:{value:new Qe(1118481)},shininess:{value:30}}]),vertexShader:qe.meshphong_vert,fragmentShader:qe.meshphong_frag},standard:{uniforms:Pt([Ie.common,Ie.envmap,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.roughnessmap,Ie.metalnessmap,Ie.fog,Ie.lights,{emissive:{value:new Qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag},toon:{uniforms:Pt([Ie.common,Ie.aomap,Ie.lightmap,Ie.emissivemap,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.gradientmap,Ie.fog,Ie.lights,{emissive:{value:new Qe(0)}}]),vertexShader:qe.meshtoon_vert,fragmentShader:qe.meshtoon_frag},matcap:{uniforms:Pt([Ie.common,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,Ie.fog,{matcap:{value:null}}]),vertexShader:qe.meshmatcap_vert,fragmentShader:qe.meshmatcap_frag},points:{uniforms:Pt([Ie.points,Ie.fog]),vertexShader:qe.points_vert,fragmentShader:qe.points_frag},dashed:{uniforms:Pt([Ie.common,Ie.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:qe.linedashed_vert,fragmentShader:qe.linedashed_frag},depth:{uniforms:Pt([Ie.common,Ie.displacementmap]),vertexShader:qe.depth_vert,fragmentShader:qe.depth_frag},normal:{uniforms:Pt([Ie.common,Ie.bumpmap,Ie.normalmap,Ie.displacementmap,{opacity:{value:1}}]),vertexShader:qe.meshnormal_vert,fragmentShader:qe.meshnormal_frag},sprite:{uniforms:Pt([Ie.sprite,Ie.fog]),vertexShader:qe.sprite_vert,fragmentShader:qe.sprite_frag},background:{uniforms:{uvTransform:{value:new We},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:qe.background_vert,fragmentShader:qe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new We}},vertexShader:qe.backgroundCube_vert,fragmentShader:qe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:qe.cube_vert,fragmentShader:qe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:qe.equirect_vert,fragmentShader:qe.equirect_frag},distanceRGBA:{uniforms:Pt([Ie.common,Ie.displacementmap,{referencePosition:{value:new w},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:qe.distanceRGBA_vert,fragmentShader:qe.distanceRGBA_frag},shadow:{uniforms:Pt([Ie.lights,Ie.fog,{color:{value:new Qe(0)},opacity:{value:1}}]),vertexShader:qe.shadow_vert,fragmentShader:qe.shadow_frag}};dn.physical={uniforms:Pt([dn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new We},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new We},clearcoatNormalScale:{value:new le(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new We},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new We},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new We},sheen:{value:0},sheenColor:{value:new Qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new We},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new We},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new We},transmissionSamplerSize:{value:new le},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new We},attenuationDistance:{value:0},attenuationColor:{value:new Qe(0)},specularColor:{value:new Qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new We},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new We},anisotropyVector:{value:new le},anisotropyMap:{value:null},anisotropyMapTransform:{value:new We}}]),vertexShader:qe.meshphysical_vert,fragmentShader:qe.meshphysical_frag};const ir={r:0,b:0,g:0},li=new Fn,wE=new _t;function FE(n,e,t,i,s,r,a){const l=new Qe(0);let d=r===!0?0:1,u,p,o=null,c=0,h=null;function m(A){let R=A.isScene===!0?A.background:null;return R&&R.isTexture&&(R=(A.backgroundBlurriness>0?t:e).get(R)),R}function S(A){let R=!1;const C=m(A);C===null?f(l,d):C&&C.isColor&&(f(C,1),R=!0);const L=n.xr.getEnvironmentBlendMode();L==="additive"?i.buffers.color.setClear(0,0,0,1,a):L==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||R)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function E(A,R){const C=m(R);C&&(C.isCubeTexture||C.mapping===vr)?(p===void 0&&(p=new At(new gi(1,1,1),new Bn({name:"BackgroundCubeMaterial",uniforms:Ji(dn.backgroundCube.uniforms),vertexShader:dn.backgroundCube.vertexShader,fragmentShader:dn.backgroundCube.fragmentShader,side:Ot,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(L,D,F){this.matrixWorld.copyPosition(F.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(p)),li.copy(R.backgroundRotation),li.x*=-1,li.y*=-1,li.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(li.y*=-1,li.z*=-1),p.material.uniforms.envMap.value=C,p.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,p.material.uniforms.backgroundBlurriness.value=R.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=R.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(wE.makeRotationFromEuler(li)),p.material.toneMapped=je.getTransfer(C.colorSpace)!==it,(o!==C||c!==C.version||h!==n.toneMapping)&&(p.material.needsUpdate=!0,o=C,c=C.version,h=n.toneMapping),p.layers.enableAll(),A.unshift(p,p.geometry,p.material,0,0,null)):C&&C.isTexture&&(u===void 0&&(u=new At(new ei(2,2),new Bn({name:"BackgroundMaterial",uniforms:Ji(dn.background.uniforms),vertexShader:dn.background.vertexShader,fragmentShader:dn.background.fragmentShader,side:mn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(u)),u.material.uniforms.t2D.value=C,u.material.uniforms.backgroundIntensity.value=R.backgroundIntensity,u.material.toneMapped=je.getTransfer(C.colorSpace)!==it,C.matrixAutoUpdate===!0&&C.updateMatrix(),u.material.uniforms.uvTransform.value.copy(C.matrix),(o!==C||c!==C.version||h!==n.toneMapping)&&(u.material.needsUpdate=!0,o=C,c=C.version,h=n.toneMapping),u.layers.enableAll(),A.unshift(u,u.geometry,u.material,0,0,null))}function f(A,R){A.getRGB(ir,Vc(n)),i.buffers.color.setClear(ir.r,ir.g,ir.b,R,a)}function _(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0)}return{getClearColor:function(){return l},setClearColor:function(A,R=1){l.set(A),d=R,f(l,d)},getClearAlpha:function(){return d},setClearAlpha:function(A){d=A,f(l,d)},render:S,addToRenderList:E,dispose:_}}function BE(n,e){const t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},s=c(null);let r=s,a=!1;function l(M,N,V,Z,J){let Q=!1;const ie=o(Z,V,N);r!==ie&&(r=ie,u(r.object)),Q=h(M,Z,V,J),Q&&m(M,Z,V,J),J!==null&&e.update(J,n.ELEMENT_ARRAY_BUFFER),(Q||a)&&(a=!1,R(M,N,V,Z),J!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(J).buffer))}function d(){return n.createVertexArray()}function u(M){return n.bindVertexArray(M)}function p(M){return n.deleteVertexArray(M)}function o(M,N,V){const Z=V.wireframe===!0;let J=i[M.id];J===void 0&&(J={},i[M.id]=J);let Q=J[N.id];Q===void 0&&(Q={},J[N.id]=Q);let ie=Q[Z];return ie===void 0&&(ie=c(d()),Q[Z]=ie),ie}function c(M){const N=[],V=[],Z=[];for(let J=0;J<t;J++)N[J]=0,V[J]=0,Z[J]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:N,enabledAttributes:V,attributeDivisors:Z,object:M,attributes:{},index:null}}function h(M,N,V,Z){const J=r.attributes,Q=N.attributes;let ie=0;const j=V.getAttributes();for(const H in j)if(j[H].location>=0){const re=J[H];let ge=Q[H];if(ge===void 0&&(H==="instanceMatrix"&&M.instanceMatrix&&(ge=M.instanceMatrix),H==="instanceColor"&&M.instanceColor&&(ge=M.instanceColor)),re===void 0||re.attribute!==ge||ge&&re.data!==ge.data)return!0;ie++}return r.attributesNum!==ie||r.index!==Z}function m(M,N,V,Z){const J={},Q=N.attributes;let ie=0;const j=V.getAttributes();for(const H in j)if(j[H].location>=0){let re=Q[H];re===void 0&&(H==="instanceMatrix"&&M.instanceMatrix&&(re=M.instanceMatrix),H==="instanceColor"&&M.instanceColor&&(re=M.instanceColor));const ge={};ge.attribute=re,re&&re.data&&(ge.data=re.data),J[H]=ge,ie++}r.attributes=J,r.attributesNum=ie,r.index=Z}function S(){const M=r.newAttributes;for(let N=0,V=M.length;N<V;N++)M[N]=0}function E(M){f(M,0)}function f(M,N){const V=r.newAttributes,Z=r.enabledAttributes,J=r.attributeDivisors;V[M]=1,Z[M]===0&&(n.enableVertexAttribArray(M),Z[M]=1),J[M]!==N&&(n.vertexAttribDivisor(M,N),J[M]=N)}function _(){const M=r.newAttributes,N=r.enabledAttributes;for(let V=0,Z=N.length;V<Z;V++)N[V]!==M[V]&&(n.disableVertexAttribArray(V),N[V]=0)}function A(M,N,V,Z,J,Q,ie){ie===!0?n.vertexAttribIPointer(M,N,V,J,Q):n.vertexAttribPointer(M,N,V,Z,J,Q)}function R(M,N,V,Z){S();const J=Z.attributes,Q=V.getAttributes(),ie=N.defaultAttributeValues;for(const j in Q){const H=Q[j];if(H.location>=0){let Ee=J[j];if(Ee===void 0&&(j==="instanceMatrix"&&M.instanceMatrix&&(Ee=M.instanceMatrix),j==="instanceColor"&&M.instanceColor&&(Ee=M.instanceColor)),Ee!==void 0){const re=Ee.normalized,ge=Ee.itemSize,we=e.get(Ee);if(we===void 0)continue;const Ve=we.buffer,z=we.type,U=we.bytesPerElement,v=z===n.INT||z===n.UNSIGNED_INT||Ee.gpuType===Ma;if(Ee.isInterleavedBufferAttribute){const g=Ee.data,K=g.stride,oe=Ee.offset;if(g.isInstancedInterleavedBuffer){for(let k=0;k<H.locationSize;k++)f(H.location+k,g.meshPerAttribute);M.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=g.meshPerAttribute*g.count)}else for(let k=0;k<H.locationSize;k++)E(H.location+k);n.bindBuffer(n.ARRAY_BUFFER,Ve);for(let k=0;k<H.locationSize;k++)A(H.location+k,ge/H.locationSize,z,re,K*U,(oe+ge/H.locationSize*k)*U,v)}else{if(Ee.isInstancedBufferAttribute){for(let g=0;g<H.locationSize;g++)f(H.location+g,Ee.meshPerAttribute);M.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=Ee.meshPerAttribute*Ee.count)}else for(let g=0;g<H.locationSize;g++)E(H.location+g);n.bindBuffer(n.ARRAY_BUFFER,Ve);for(let g=0;g<H.locationSize;g++)A(H.location+g,ge/H.locationSize,z,re,ge*U,ge/H.locationSize*g*U,v)}}else if(ie!==void 0){const re=ie[j];if(re!==void 0)switch(re.length){case 2:n.vertexAttrib2fv(H.location,re);break;case 3:n.vertexAttrib3fv(H.location,re);break;case 4:n.vertexAttrib4fv(H.location,re);break;default:n.vertexAttrib1fv(H.location,re)}}}}_()}function C(){F();for(const M in i){const N=i[M];for(const V in N){const Z=N[V];for(const J in Z)p(Z[J].object),delete Z[J];delete N[V]}delete i[M]}}function L(M){if(i[M.id]===void 0)return;const N=i[M.id];for(const V in N){const Z=N[V];for(const J in Z)p(Z[J].object),delete Z[J];delete N[V]}delete i[M.id]}function D(M){for(const N in i){const V=i[N];if(V[M.id]===void 0)continue;const Z=V[M.id];for(const J in Z)p(Z[J].object),delete Z[J];delete V[M.id]}}function F(){I(),a=!0,r!==s&&(r=s,u(r.object))}function I(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:l,reset:F,resetDefaultState:I,dispose:C,releaseStatesOfGeometry:L,releaseStatesOfProgram:D,initAttributes:S,enableAttribute:E,disableUnusedAttributes:_}}function HE(n,e,t){let i;function s(u){i=u}function r(u,p){n.drawArrays(i,u,p),t.update(p,i,1)}function a(u,p,o){o!==0&&(n.drawArraysInstanced(i,u,p,o),t.update(p,i,o))}function l(u,p,o){if(o===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,u,0,p,0,o);let h=0;for(let m=0;m<o;m++)h+=p[m];t.update(h,i,1)}function d(u,p,o,c){if(o===0)return;const h=e.get("WEBGL_multi_draw");if(h===null)for(let m=0;m<u.length;m++)a(u[m],p[m],c[m]);else{h.multiDrawArraysInstancedWEBGL(i,u,0,p,0,c,0,o);let m=0;for(let S=0;S<o;S++)m+=p[S]*c[S];t.update(m,i,1)}}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=l,this.renderMultiDrawInstances=d}function GE(n,e,t,i){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const D=e.get("EXT_texture_filter_anisotropic");s=n.getParameter(D.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(D){return!(D!==ln&&i.convert(D)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function l(D){const F=D===ji&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(D!==Un&&i.convert(D)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE)&&D!==Dn&&!F)}function d(D){if(D==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";D="mediump"}return D==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=t.precision!==void 0?t.precision:"highp";const p=d(u);p!==u&&(Ke("WebGLRenderer:",u,"not supported, using",p,"instead."),u=p);const o=t.logarithmicDepthBuffer===!0,c=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),h=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),S=n.getParameter(n.MAX_TEXTURE_SIZE),E=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),f=n.getParameter(n.MAX_VERTEX_ATTRIBS),_=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),A=n.getParameter(n.MAX_VARYING_VECTORS),R=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),C=m>0,L=n.getParameter(n.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:d,textureFormatReadable:a,textureTypeReadable:l,precision:u,logarithmicDepthBuffer:o,reversedDepthBuffer:c,maxTextures:h,maxVertexTextures:m,maxTextureSize:S,maxCubemapSize:E,maxAttributes:f,maxVertexUniforms:_,maxVaryings:A,maxFragmentUniforms:R,vertexTextures:C,maxSamples:L}}function VE(n){const e=this;let t=null,i=0,s=!1,r=!1;const a=new On,l=new We,d={value:null,needsUpdate:!1};this.uniform=d,this.numPlanes=0,this.numIntersection=0,this.init=function(o,c){const h=o.length!==0||c||i!==0||s;return s=c,i=o.length,h},this.beginShadows=function(){r=!0,p(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(o,c){t=p(o,c,0)},this.setState=function(o,c,h){const m=o.clippingPlanes,S=o.clipIntersection,E=o.clipShadows,f=n.get(o);if(!s||m===null||m.length===0||r&&!E)r?p(null):u();else{const _=r?0:i,A=_*4;let R=f.clippingState||null;d.value=R,R=p(m,c,A,h);for(let C=0;C!==A;++C)R[C]=t[C];f.clippingState=R,this.numIntersection=S?this.numPlanes:0,this.numPlanes+=_}};function u(){d.value!==t&&(d.value=t,d.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function p(o,c,h,m){const S=o!==null?o.length:0;let E=null;if(S!==0){if(E=d.value,m!==!0||E===null){const f=h+S*4,_=c.matrixWorldInverse;l.getNormalMatrix(_),(E===null||E.length<f)&&(E=new Float32Array(f));for(let A=0,R=h;A!==S;++A,R+=4)a.copy(o[A]).applyMatrix4(_,l),a.normal.toArray(E,R),E[R+3]=a.constant}d.value=E,d.needsUpdate=!0}return e.numPlanes=S,e.numIntersection=0,E}}function kE(n){let e=new WeakMap;function t(a,l){return l===Uo?a.mapping=Xi:l===wo&&(a.mapping=qi),a}function i(a){if(a&&a.isTexture){const l=a.mapping;if(l===Uo||l===wo)if(e.has(a)){const d=e.get(a).texture;return t(d,a.mapping)}else{const d=a.image;if(d&&d.height>0){const u=new id(d.height);return u.fromEquirectangularTexture(n,a),e.set(a,u),a.addEventListener("dispose",s),t(u.texture,a.mapping)}else return null}}return a}function s(a){const l=a.target;l.removeEventListener("dispose",s);const d=e.get(l);d!==void 0&&(e.delete(l),d.dispose())}function r(){e=new WeakMap}return{get:i,dispose:r}}const qn=4,Ul=[.125,.215,.35,.446,.526,.582],hi=20,YE=256,cs=new Jd,wl=new Qe;let uo=null,ho=0,fo=0,po=!1;const WE=new w;class Fl{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,i=.1,s=100,r={}){const{size:a=256,position:l=WE}=r;uo=this._renderer.getRenderTarget(),ho=this._renderer.getActiveCubeFace(),fo=this._renderer.getActiveMipmapLevel(),po=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const d=this._allocateTargets();return d.depthBuffer=!0,this._sceneToCubeUV(e,i,s,d,l),t>0&&this._blur(d,0,0,t),this._applyPMREM(d),this._cleanup(d),d}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Gl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Hl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(uo,ho,fo),this._renderer.xr.enabled=po,e.scissorTest=!1,wi(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Xi||e.mapping===qi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),uo=this._renderer.getRenderTarget(),ho=this._renderer.getActiveCubeFace(),fo=this._renderer.getActiveMipmapLevel(),po=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:$t,minFilter:$t,generateMipmaps:!1,type:ji,format:ln,colorSpace:Zi,depthBuffer:!1},s=Bl(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Bl(e,t,i);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=zE(r)),this._blurMaterial=XE(r,e,t),this._ggxMaterial=KE(r,e,t)}return s}_compileMaterial(e){const t=new At(new Rt,e);this._renderer.compile(t,cs)}_sceneToCubeUV(e,t,i,s,r){const d=new zt(90,1,t,i),u=[1,-1,1,1,1,1],p=[1,1,1,-1,-1,-1],o=this._renderer,c=o.autoClear,h=o.toneMapping;o.getClearColor(wl),o.toneMapping=Zn,o.autoClear=!1,o.state.buffers.depth.getReversed()&&(o.setRenderTarget(s),o.clearDepth(),o.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new At(new gi,new jn({name:"PMREM.Background",side:Ot,depthWrite:!1,depthTest:!1})));const S=this._backgroundBox,E=S.material;let f=!1;const _=e.background;_?_.isColor&&(E.color.copy(_),e.background=null,f=!0):(E.color.copy(wl),f=!0);for(let A=0;A<6;A++){const R=A%3;R===0?(d.up.set(0,u[A],0),d.position.set(r.x,r.y,r.z),d.lookAt(r.x+p[A],r.y,r.z)):R===1?(d.up.set(0,0,u[A]),d.position.set(r.x,r.y,r.z),d.lookAt(r.x,r.y+p[A],r.z)):(d.up.set(0,u[A],0),d.position.set(r.x,r.y,r.z),d.lookAt(r.x,r.y,r.z+p[A]));const C=this._cubeSize;wi(s,R*C,A>2?C:0,C,C),o.setRenderTarget(s),f&&o.render(S,d),o.render(e,d)}o.toneMapping=h,o.autoClear=c,e.background=_}_textureToCubeUV(e,t){const i=this._renderer,s=e.mapping===Xi||e.mapping===qi;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Gl()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Hl());const r=s?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=r;const l=r.uniforms;l.envMap.value=e;const d=this._cubeSize;wi(t,0,0,3*d,2*d),i.setRenderTarget(t),i.render(a,cs)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const s=this._lodMeshes.length;for(let r=1;r<s;r++)this._applyGGXFilter(e,r-1,r);t.autoClear=i}_applyGGXFilter(e,t,i){const s=this._renderer,r=this._pingPongRenderTarget,a=this._ggxMaterial,l=this._lodMeshes[i];l.material=a;const d=a.uniforms,u=i/(this._lodMeshes.length-1),p=t/(this._lodMeshes.length-1),o=Math.sqrt(u*u-p*p),c=.05+u*.95,h=o*c,{_lodMax:m}=this,S=this._sizeLods[i],E=3*S*(i>m-qn?i-m+qn:0),f=4*(this._cubeSize-S);d.envMap.value=e.texture,d.roughness.value=h,d.mipInt.value=m-t,wi(r,E,f,3*S,2*S),s.setRenderTarget(r),s.render(l,cs),d.envMap.value=r.texture,d.roughness.value=0,d.mipInt.value=m-i,wi(e,E,f,3*S,2*S),s.setRenderTarget(e),s.render(l,cs)}_blur(e,t,i,s,r){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,s,"latitudinal",r),this._halfBlur(a,e,i,i,s,"longitudinal",r)}_halfBlur(e,t,i,s,r,a,l){const d=this._renderer,u=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&dt("blur direction must be either latitudinal or longitudinal!");const p=3,o=this._lodMeshes[s];o.material=u;const c=u.uniforms,h=this._sizeLods[i]-1,m=isFinite(r)?Math.PI/(2*h):2*Math.PI/(2*hi-1),S=r/m,E=isFinite(r)?1+Math.floor(p*S):hi;E>hi&&Ke(`sigmaRadians, ${r}, is too large and will clip, as it requested ${E} samples when the maximum is set to ${hi}`);const f=[];let _=0;for(let D=0;D<hi;++D){const F=D/S,I=Math.exp(-F*F/2);f.push(I),D===0?_+=I:D<E&&(_+=2*I)}for(let D=0;D<f.length;D++)f[D]=f[D]/_;c.envMap.value=e.texture,c.samples.value=E,c.weights.value=f,c.latitudinal.value=a==="latitudinal",l&&(c.poleAxis.value=l);const{_lodMax:A}=this;c.dTheta.value=m,c.mipInt.value=A-i;const R=this._sizeLods[s],C=3*R*(s>A-qn?s-A+qn:0),L=4*(this._cubeSize-R);wi(t,C,L,3*R,2*R),d.setRenderTarget(t),d.render(o,cs)}}function zE(n){const e=[],t=[],i=[];let s=n;const r=n-qn+1+Ul.length;for(let a=0;a<r;a++){const l=Math.pow(2,s);e.push(l);let d=1/l;a>n-qn?d=Ul[a-n+qn-1]:a===0&&(d=0),t.push(d);const u=1/(l-2),p=-u,o=1+u,c=[p,p,o,p,o,o,p,p,o,o,p,o],h=6,m=6,S=3,E=2,f=1,_=new Float32Array(S*m*h),A=new Float32Array(E*m*h),R=new Float32Array(f*m*h);for(let L=0;L<h;L++){const D=L%3*2/3-1,F=L>2?0:-1,I=[D,F,0,D+2/3,F,0,D+2/3,F+1,0,D,F,0,D+2/3,F+1,0,D,F+1,0];_.set(I,S*m*L),A.set(c,E*m*L);const M=[L,L,L,L,L,L];R.set(M,f*m*L)}const C=new Rt;C.setAttribute("position",new un(_,S)),C.setAttribute("uv",new un(A,E)),C.setAttribute("faceIndex",new un(R,f)),i.push(new At(C,null)),s>qn&&s--}return{lodMeshes:i,sizeLods:e,sigmas:t}}function Bl(n,e,t){const i=new wn(n,e,t);return i.texture.mapping=vr,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function wi(n,e,t,i,s){n.viewport.set(e,t,i,s),n.scissor.set(e,t,i,s)}function KE(n,e,t){return new Bn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:YE,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:yr(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function XE(n,e,t){const i=new Float32Array(hi),s=new w(0,1,0);return new Bn({name:"SphericalGaussianBlur",defines:{n:hi,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:yr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function Hl(){return new Bn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:yr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function Gl(){return new Bn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:yr(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Pn,depthTest:!1,depthWrite:!1})}function yr(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function qE(n){let e=new WeakMap,t=null;function i(l){if(l&&l.isTexture){const d=l.mapping,u=d===Uo||d===wo,p=d===Xi||d===qi;if(u||p){let o=e.get(l);const c=o!==void 0?o.texture.pmremVersion:0;if(l.isRenderTargetTexture&&l.pmremVersion!==c)return t===null&&(t=new Fl(n)),o=u?t.fromEquirectangular(l,o):t.fromCubemap(l,o),o.texture.pmremVersion=l.pmremVersion,e.set(l,o),o.texture;if(o!==void 0)return o.texture;{const h=l.image;return u&&h&&h.height>0||p&&h&&s(h)?(t===null&&(t=new Fl(n)),o=u?t.fromEquirectangular(l):t.fromCubemap(l),o.texture.pmremVersion=l.pmremVersion,e.set(l,o),l.addEventListener("dispose",r),o.texture):null}}}return l}function s(l){let d=0;const u=6;for(let p=0;p<u;p++)l[p]!==void 0&&d++;return d===u}function r(l){const d=l.target;d.removeEventListener("dispose",r);const u=e.get(d);u!==void 0&&(e.delete(d),u.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function ZE(n){const e={};function t(i){if(e[i]!==void 0)return e[i];const s=n.getExtension(i);return e[i]=s,s}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const s=t(i);return s===null&&vs("WebGLRenderer: "+i+" extension not supported."),s}}}function JE(n,e,t,i){const s={},r=new WeakMap;function a(o){const c=o.target;c.index!==null&&e.remove(c.index);for(const m in c.attributes)e.remove(c.attributes[m]);c.removeEventListener("dispose",a),delete s[c.id];const h=r.get(c);h&&(e.remove(h),r.delete(c)),i.releaseStatesOfGeometry(c),c.isInstancedBufferGeometry===!0&&delete c._maxInstanceCount,t.memory.geometries--}function l(o,c){return s[c.id]===!0||(c.addEventListener("dispose",a),s[c.id]=!0,t.memory.geometries++),c}function d(o){const c=o.attributes;for(const h in c)e.update(c[h],n.ARRAY_BUFFER)}function u(o){const c=[],h=o.index,m=o.attributes.position;let S=0;if(h!==null){const _=h.array;S=h.version;for(let A=0,R=_.length;A<R;A+=3){const C=_[A+0],L=_[A+1],D=_[A+2];c.push(C,L,L,D,D,C)}}else if(m!==void 0){const _=m.array;S=m.version;for(let A=0,R=_.length/3-1;A<R;A+=3){const C=A+0,L=A+1,D=A+2;c.push(C,L,L,D,D,C)}}else return;const E=new(wc(c)?Gc:Hc)(c,1);E.version=S;const f=r.get(o);f&&e.remove(f),r.set(o,E)}function p(o){const c=r.get(o);if(c){const h=o.index;h!==null&&c.version<h.version&&u(o)}else u(o);return r.get(o)}return{get:l,update:d,getWireframeAttribute:p}}function QE(n,e,t){let i;function s(c){i=c}let r,a;function l(c){r=c.type,a=c.bytesPerElement}function d(c,h){n.drawElements(i,h,r,c*a),t.update(h,i,1)}function u(c,h,m){m!==0&&(n.drawElementsInstanced(i,h,r,c*a,m),t.update(h,i,m))}function p(c,h,m){if(m===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,r,c,0,m);let E=0;for(let f=0;f<m;f++)E+=h[f];t.update(E,i,1)}function o(c,h,m,S){if(m===0)return;const E=e.get("WEBGL_multi_draw");if(E===null)for(let f=0;f<c.length;f++)u(c[f]/a,h[f],S[f]);else{E.multiDrawElementsInstancedWEBGL(i,h,0,r,c,0,S,0,m);let f=0;for(let _=0;_<m;_++)f+=h[_]*S[_];t.update(f,i,1)}}this.setMode=s,this.setIndex=l,this.render=d,this.renderInstances=u,this.renderMultiDraw=p,this.renderMultiDrawInstances=o}function $E(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,a,l){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=l*(r/3);break;case n.LINES:t.lines+=l*(r/2);break;case n.LINE_STRIP:t.lines+=l*(r-1);break;case n.LINE_LOOP:t.lines+=l*r;break;case n.POINTS:t.points+=l*r;break;default:dt("WebGLInfo: Unknown draw mode:",a);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:i}}function jE(n,e,t){const i=new WeakMap,s=new St;function r(a,l,d){const u=a.morphTargetInfluences,p=l.morphAttributes.position||l.morphAttributes.normal||l.morphAttributes.color,o=p!==void 0?p.length:0;let c=i.get(l);if(c===void 0||c.count!==o){let M=function(){F.dispose(),i.delete(l),l.removeEventListener("dispose",M)};var h=M;c!==void 0&&c.texture.dispose();const m=l.morphAttributes.position!==void 0,S=l.morphAttributes.normal!==void 0,E=l.morphAttributes.color!==void 0,f=l.morphAttributes.position||[],_=l.morphAttributes.normal||[],A=l.morphAttributes.color||[];let R=0;m===!0&&(R=1),S===!0&&(R=2),E===!0&&(R=3);let C=l.attributes.position.count*R,L=1;C>e.maxTextureSize&&(L=Math.ceil(C/e.maxTextureSize),C=e.maxTextureSize);const D=new Float32Array(C*L*4*o),F=new Fc(D,C,L,o);F.type=Dn,F.needsUpdate=!0;const I=R*4;for(let N=0;N<o;N++){const V=f[N],Z=_[N],J=A[N],Q=C*L*4*N;for(let ie=0;ie<V.count;ie++){const j=ie*I;m===!0&&(s.fromBufferAttribute(V,ie),D[Q+j+0]=s.x,D[Q+j+1]=s.y,D[Q+j+2]=s.z,D[Q+j+3]=0),S===!0&&(s.fromBufferAttribute(Z,ie),D[Q+j+4]=s.x,D[Q+j+5]=s.y,D[Q+j+6]=s.z,D[Q+j+7]=0),E===!0&&(s.fromBufferAttribute(J,ie),D[Q+j+8]=s.x,D[Q+j+9]=s.y,D[Q+j+10]=s.z,D[Q+j+11]=J.itemSize===4?s.w:1)}}c={count:o,texture:F,size:new le(C,L)},i.set(l,c),l.addEventListener("dispose",M)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)d.getUniforms().setValue(n,"morphTexture",a.morphTexture,t);else{let m=0;for(let E=0;E<u.length;E++)m+=u[E];const S=l.morphTargetsRelative?1:1-m;d.getUniforms().setValue(n,"morphTargetBaseInfluence",S),d.getUniforms().setValue(n,"morphTargetInfluences",u)}d.getUniforms().setValue(n,"morphTargetsTexture",c.texture,t),d.getUniforms().setValue(n,"morphTargetsTextureSize",c.size)}return{update:r}}function em(n,e,t,i){let s=new WeakMap;function r(d){const u=i.render.frame,p=d.geometry,o=e.get(d,p);if(s.get(o)!==u&&(e.update(o),s.set(o,u)),d.isInstancedMesh&&(d.hasEventListener("dispose",l)===!1&&d.addEventListener("dispose",l),s.get(d)!==u&&(t.update(d.instanceMatrix,n.ARRAY_BUFFER),d.instanceColor!==null&&t.update(d.instanceColor,n.ARRAY_BUFFER),s.set(d,u))),d.isSkinnedMesh){const c=d.skeleton;s.get(c)!==u&&(c.update(),s.set(c,u))}return o}function a(){s=new WeakMap}function l(d){const u=d.target;u.removeEventListener("dispose",l),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:r,dispose:a}}const nu=new Ut,Vl=new zc(1,1),iu=new Fc,su=new Gh,ru=new Yc,kl=[],Yl=[],Wl=new Float32Array(16),zl=new Float32Array(9),Kl=new Float32Array(4);function ns(n,e,t){const i=n[0];if(i<=0||i>0)return n;const s=e*t;let r=kl[s];if(r===void 0&&(r=new Float32Array(s),kl[s]=r),e!==0){i.toArray(r,0);for(let a=1,l=0;a!==e;++a)l+=t,n[a].toArray(r,l)}return r}function Mt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function vt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Lr(n,e){let t=Yl[e];t===void 0&&(t=new Int32Array(e),Yl[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function tm(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function nm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2fv(this.addr,e),vt(t,e)}}function im(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Mt(t,e))return;n.uniform3fv(this.addr,e),vt(t,e)}}function sm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4fv(this.addr,e),vt(t,e)}}function rm(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),vt(t,e)}else{if(Mt(t,i))return;Kl.set(i),n.uniformMatrix2fv(this.addr,!1,Kl),vt(t,i)}}function om(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),vt(t,e)}else{if(Mt(t,i))return;zl.set(i),n.uniformMatrix3fv(this.addr,!1,zl),vt(t,i)}}function am(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),vt(t,e)}else{if(Mt(t,i))return;Wl.set(i),n.uniformMatrix4fv(this.addr,!1,Wl),vt(t,i)}}function lm(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function cm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2iv(this.addr,e),vt(t,e)}}function um(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3iv(this.addr,e),vt(t,e)}}function hm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4iv(this.addr,e),vt(t,e)}}function dm(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function fm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2uiv(this.addr,e),vt(t,e)}}function pm(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3uiv(this.addr,e),vt(t,e)}}function Em(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4uiv(this.addr,e),vt(t,e)}}function mm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r;this.type===n.SAMPLER_2D_SHADOW?(Vl.compareFunction=Uc,r=Vl):r=nu,t.setTexture2D(e||r,s)}function Sm(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture3D(e||su,s)}function Am(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTextureCube(e||ru,s)}function _m(n,e,t){const i=this.cache,s=t.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),t.setTexture2DArray(e||iu,s)}function xm(n){switch(n){case 5126:return tm;case 35664:return nm;case 35665:return im;case 35666:return sm;case 35674:return rm;case 35675:return om;case 35676:return am;case 5124:case 35670:return lm;case 35667:case 35671:return cm;case 35668:case 35672:return um;case 35669:case 35673:return hm;case 5125:return dm;case 36294:return fm;case 36295:return pm;case 36296:return Em;case 35678:case 36198:case 36298:case 36306:case 35682:return mm;case 35679:case 36299:case 36307:return Sm;case 35680:case 36300:case 36308:case 36293:return Am;case 36289:case 36303:case 36311:case 36292:return _m}}function gm(n,e){n.uniform1fv(this.addr,e)}function Tm(n,e){const t=ns(e,this.size,2);n.uniform2fv(this.addr,t)}function Rm(n,e){const t=ns(e,this.size,3);n.uniform3fv(this.addr,t)}function Mm(n,e){const t=ns(e,this.size,4);n.uniform4fv(this.addr,t)}function vm(n,e){const t=ns(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function Im(n,e){const t=ns(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function ym(n,e){const t=ns(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function Lm(n,e){n.uniform1iv(this.addr,e)}function Om(n,e){n.uniform2iv(this.addr,e)}function bm(n,e){n.uniform3iv(this.addr,e)}function Cm(n,e){n.uniform4iv(this.addr,e)}function Dm(n,e){n.uniform1uiv(this.addr,e)}function Pm(n,e){n.uniform2uiv(this.addr,e)}function Nm(n,e){n.uniform3uiv(this.addr,e)}function Um(n,e){n.uniform4uiv(this.addr,e)}function wm(n,e,t){const i=this.cache,s=e.length,r=Lr(t,s);Mt(i,r)||(n.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==s;++a)t.setTexture2D(e[a]||nu,r[a])}function Fm(n,e,t){const i=this.cache,s=e.length,r=Lr(t,s);Mt(i,r)||(n.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==s;++a)t.setTexture3D(e[a]||su,r[a])}function Bm(n,e,t){const i=this.cache,s=e.length,r=Lr(t,s);Mt(i,r)||(n.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==s;++a)t.setTextureCube(e[a]||ru,r[a])}function Hm(n,e,t){const i=this.cache,s=e.length,r=Lr(t,s);Mt(i,r)||(n.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==s;++a)t.setTexture2DArray(e[a]||iu,r[a])}function Gm(n){switch(n){case 5126:return gm;case 35664:return Tm;case 35665:return Rm;case 35666:return Mm;case 35674:return vm;case 35675:return Im;case 35676:return ym;case 5124:case 35670:return Lm;case 35667:case 35671:return Om;case 35668:case 35672:return bm;case 35669:case 35673:return Cm;case 5125:return Dm;case 36294:return Pm;case 36295:return Nm;case 36296:return Um;case 35678:case 36198:case 36298:case 36306:case 35682:return wm;case 35679:case 36299:case 36307:return Fm;case 35680:case 36300:case 36308:case 36293:return Bm;case 36289:case 36303:case 36311:case 36292:return Hm}}class Vm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=xm(t.type)}}class km{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Gm(t.type)}}class Ym{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const l=s[r];l.setValue(e,t[l.id],i)}}}const Eo=/(\w+)(\])?(\[|\.)?/g;function Xl(n,e){n.seq.push(e),n.map[e.id]=e}function Wm(n,e,t){const i=n.name,s=i.length;for(Eo.lastIndex=0;;){const r=Eo.exec(i),a=Eo.lastIndex;let l=r[1];const d=r[2]==="]",u=r[3];if(d&&(l=l|0),u===void 0||u==="["&&a+2===s){Xl(t,u===void 0?new Vm(l,n,e):new km(l,n,e));break}else{let o=t.map[l];o===void 0&&(o=new Ym(l),Xl(t,o)),t=o}}}class pr{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){const r=e.getActiveUniform(t,s),a=e.getUniformLocation(t,r.name);Wm(r,a,this)}}setValue(e,t,i,s){const r=this.map[t];r!==void 0&&r.setValue(e,i,s)}setOptional(e,t,i){const s=t[i];s!==void 0&&this.setValue(e,i,s)}static upload(e,t,i,s){for(let r=0,a=t.length;r!==a;++r){const l=t[r],d=i[l.id];d.needsUpdate!==!1&&l.setValue(e,d.value,s)}}static seqWithValue(e,t){const i=[];for(let s=0,r=e.length;s!==r;++s){const a=e[s];a.id in t&&i.push(a)}return i}}function ql(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const zm=37297;let Km=0;function Xm(n,e){const t=n.split(`
`),i=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let a=s;a<r;a++){const l=a+1;i.push(`${l===e?">":" "} ${l}: ${t[a]}`)}return i.join(`
`)}const Zl=new We;function qm(n){je._getMatrix(Zl,je.workingColorSpace,n);const e=`mat3( ${Zl.elements.map(t=>t.toFixed(4))} )`;switch(je.getTransfer(n)){case mr:return[e,"LinearTransferOETF"];case it:return[e,"sRGBTransferOETF"];default:return Ke("WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function Jl(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=(n.getShaderInfoLog(e)||"").trim();if(i&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const l=parseInt(a[1]);return t.toUpperCase()+`

`+r+`

`+Xm(n.getShaderSource(e),l)}else return r}function Zm(n,e){const t=qm(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function Jm(n,e){let t;switch(e){case dh:t="Linear";break;case fh:t="Reinhard";break;case ph:t="Cineon";break;case Eh:t="ACESFilmic";break;case Sh:t="AgX";break;case Ah:t="Neutral";break;case mh:t="Custom";break;default:Ke("WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const sr=new w;function Qm(){je.getLuminanceCoefficients(sr);const n=sr.x.toFixed(4),e=sr.y.toFixed(4),t=sr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function $m(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ps).join(`
`)}function jm(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function eS(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){const r=n.getActiveAttrib(e,s),a=r.name;let l=1;r.type===n.FLOAT_MAT2&&(l=2),r.type===n.FLOAT_MAT3&&(l=3),r.type===n.FLOAT_MAT4&&(l=4),t[a]={type:r.type,location:n.getAttribLocation(e,a),locationSize:l}}return t}function ps(n){return n!==""}function Ql(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function $l(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const tS=/^[ \t]*#include +<([\w\d./]+)>/gm;function Aa(n){return n.replace(tS,iS)}const nS=new Map;function iS(n,e){let t=qe[e];if(t===void 0){const i=nS.get(e);if(i!==void 0)t=qe[i],Ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return Aa(t)}const sS=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function jl(n){return n.replace(sS,rS)}function rS(n,e,t,i){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function ec(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function oS(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===vc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===zu?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===yn&&(e="SHADOWMAP_TYPE_VSM"),e}function aS(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Xi:case qi:e="ENVMAP_TYPE_CUBE";break;case vr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function lS(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case qi:e="ENVMAP_MODE_REFRACTION";break}return e}function cS(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Ic:e="ENVMAP_BLENDING_MULTIPLY";break;case uh:e="ENVMAP_BLENDING_MIX";break;case hh:e="ENVMAP_BLENDING_ADD";break}return e}function uS(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function hS(n,e,t,i){const s=n.getContext(),r=t.defines;let a=t.vertexShader,l=t.fragmentShader;const d=oS(t),u=aS(t),p=lS(t),o=cS(t),c=uS(t),h=$m(t),m=jm(r),S=s.createProgram();let E,f,_=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(E=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ps).join(`
`),E.length>0&&(E+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(ps).join(`
`),f.length>0&&(f+=`
`)):(E=[ec(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+p:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ps).join(`
`),f=[ec(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.envMap?"#define "+p:"",t.envMap?"#define "+o:"",c?"#define CUBEUV_TEXEL_WIDTH "+c.texelWidth:"",c?"#define CUBEUV_TEXEL_HEIGHT "+c.texelHeight:"",c?"#define CUBEUV_MAX_MIP "+c.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+d:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Zn?"#define TONE_MAPPING":"",t.toneMapping!==Zn?qe.tonemapping_pars_fragment:"",t.toneMapping!==Zn?Jm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",qe.colorspace_pars_fragment,Zm("linearToOutputTexel",t.outputColorSpace),Qm(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(ps).join(`
`)),a=Aa(a),a=Ql(a,t),a=$l(a,t),l=Aa(l),l=Ql(l,t),l=$l(l,t),a=jl(a),l=jl(l),t.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,E=[h,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+E,f=["#define varying in",t.glslVersion===ol?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===ol?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const A=_+E+a,R=_+f+l,C=ql(s,s.VERTEX_SHADER,A),L=ql(s,s.FRAGMENT_SHADER,R);s.attachShader(S,C),s.attachShader(S,L),t.index0AttributeName!==void 0?s.bindAttribLocation(S,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(S,0,"position"),s.linkProgram(S);function D(N){if(n.debug.checkShaderErrors){const V=s.getProgramInfoLog(S)||"",Z=s.getShaderInfoLog(C)||"",J=s.getShaderInfoLog(L)||"",Q=V.trim(),ie=Z.trim(),j=J.trim();let H=!0,Ee=!0;if(s.getProgramParameter(S,s.LINK_STATUS)===!1)if(H=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,S,C,L);else{const re=Jl(s,C,"vertex"),ge=Jl(s,L,"fragment");dt("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(S,s.VALIDATE_STATUS)+`

Material Name: `+N.name+`
Material Type: `+N.type+`

Program Info Log: `+Q+`
`+re+`
`+ge)}else Q!==""?Ke("WebGLProgram: Program Info Log:",Q):(ie===""||j==="")&&(Ee=!1);Ee&&(N.diagnostics={runnable:H,programLog:Q,vertexShader:{log:ie,prefix:E},fragmentShader:{log:j,prefix:f}})}s.deleteShader(C),s.deleteShader(L),F=new pr(s,S),I=eS(s,S)}let F;this.getUniforms=function(){return F===void 0&&D(this),F};let I;this.getAttributes=function(){return I===void 0&&D(this),I};let M=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return M===!1&&(M=s.getProgramParameter(S,zm)),M},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(S),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Km++,this.cacheKey=e,this.usedTimes=1,this.program=S,this.vertexShader=C,this.fragmentShader=L,this}let dS=0;class fS{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new pS(e),t.set(e,i)),i}}class pS{constructor(e){this.id=dS++,this.code=e,this.usedTimes=0}}function ES(n,e,t,i,s,r,a){const l=new Na,d=new fS,u=new Set,p=[],o=s.logarithmicDepthBuffer,c=s.vertexTextures;let h=s.precision;const m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function S(I){return u.add(I),I===0?"uv":`uv${I}`}function E(I,M,N,V,Z){const J=V.fog,Q=Z.geometry,ie=I.isMeshStandardMaterial?V.environment:null,j=(I.isMeshStandardMaterial?t:e).get(I.envMap||ie),H=j&&j.mapping===vr?j.image.height:null,Ee=m[I.type];I.precision!==null&&(h=s.getMaxPrecision(I.precision),h!==I.precision&&Ke("WebGLProgram.getParameters:",I.precision,"not supported, using",h,"instead."));const re=Q.morphAttributes.position||Q.morphAttributes.normal||Q.morphAttributes.color,ge=re!==void 0?re.length:0;let we=0;Q.morphAttributes.position!==void 0&&(we=1),Q.morphAttributes.normal!==void 0&&(we=2),Q.morphAttributes.color!==void 0&&(we=3);let Ve,z,U,v;if(Ee){const et=dn[Ee];Ve=et.vertexShader,z=et.fragmentShader}else Ve=I.vertexShader,z=I.fragmentShader,d.update(I),U=d.getVertexShaderID(I),v=d.getFragmentShaderID(I);const g=n.getRenderTarget(),K=n.state.buffers.depth.getReversed(),oe=Z.isInstancedMesh===!0,k=Z.isBatchedMesh===!0,he=!!I.map,Ae=!!I.matcap,de=!!j,G=!!I.aoMap,T=!!I.lightMap,q=!!I.bumpMap,$=!!I.normalMap,P=!!I.displacementMap,O=!!I.emissiveMap,ae=!!I.metalnessMap,ue=!!I.roughnessMap,Re=I.anisotropy>0,b=I.clearcoat>0,x=I.dispersion>0,Y=I.iridescence>0,se=I.sheen>0,pe=I.transmission>0,ne=Re&&!!I.anisotropyMap,De=b&&!!I.clearcoatMap,Te=b&&!!I.clearcoatNormalMap,Ue=b&&!!I.clearcoatRoughnessMap,Ce=Y&&!!I.iridescenceMap,me=Y&&!!I.iridescenceThicknessMap,_e=se&&!!I.sheenColorMap,ke=se&&!!I.sheenRoughnessMap,He=!!I.specularMap,Oe=!!I.specularColorMap,ze=!!I.specularIntensityMap,B=pe&&!!I.transmissionMap,ye=pe&&!!I.thicknessMap,Me=!!I.gradientMap,ve=!!I.alphaMap,Se=I.alphaTest>0,fe=!!I.alphaHash,Pe=!!I.extensions;let Xe=Zn;I.toneMapped&&(g===null||g.isXRRenderTarget===!0)&&(Xe=n.toneMapping);const lt={shaderID:Ee,shaderType:I.type,shaderName:I.name,vertexShader:Ve,fragmentShader:z,defines:I.defines,customVertexShaderID:U,customFragmentShaderID:v,isRawShaderMaterial:I.isRawShaderMaterial===!0,glslVersion:I.glslVersion,precision:h,batching:k,batchingColor:k&&Z._colorsTexture!==null,instancing:oe,instancingColor:oe&&Z.instanceColor!==null,instancingMorph:oe&&Z.morphTexture!==null,supportsVertexTextures:c,outputColorSpace:g===null?n.outputColorSpace:g.isXRRenderTarget===!0?g.texture.colorSpace:Zi,alphaToCoverage:!!I.alphaToCoverage,map:he,matcap:Ae,envMap:de,envMapMode:de&&j.mapping,envMapCubeUVHeight:H,aoMap:G,lightMap:T,bumpMap:q,normalMap:$,displacementMap:c&&P,emissiveMap:O,normalMapObjectSpace:$&&I.normalMapType===Rh,normalMapTangentSpace:$&&I.normalMapType===Th,metalnessMap:ae,roughnessMap:ue,anisotropy:Re,anisotropyMap:ne,clearcoat:b,clearcoatMap:De,clearcoatNormalMap:Te,clearcoatRoughnessMap:Ue,dispersion:x,iridescence:Y,iridescenceMap:Ce,iridescenceThicknessMap:me,sheen:se,sheenColorMap:_e,sheenRoughnessMap:ke,specularMap:He,specularColorMap:Oe,specularIntensityMap:ze,transmission:pe,transmissionMap:B,thicknessMap:ye,gradientMap:Me,opaque:I.transparent===!1&&I.blending===Wi&&I.alphaToCoverage===!1,alphaMap:ve,alphaTest:Se,alphaHash:fe,combine:I.combine,mapUv:he&&S(I.map.channel),aoMapUv:G&&S(I.aoMap.channel),lightMapUv:T&&S(I.lightMap.channel),bumpMapUv:q&&S(I.bumpMap.channel),normalMapUv:$&&S(I.normalMap.channel),displacementMapUv:P&&S(I.displacementMap.channel),emissiveMapUv:O&&S(I.emissiveMap.channel),metalnessMapUv:ae&&S(I.metalnessMap.channel),roughnessMapUv:ue&&S(I.roughnessMap.channel),anisotropyMapUv:ne&&S(I.anisotropyMap.channel),clearcoatMapUv:De&&S(I.clearcoatMap.channel),clearcoatNormalMapUv:Te&&S(I.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&S(I.clearcoatRoughnessMap.channel),iridescenceMapUv:Ce&&S(I.iridescenceMap.channel),iridescenceThicknessMapUv:me&&S(I.iridescenceThicknessMap.channel),sheenColorMapUv:_e&&S(I.sheenColorMap.channel),sheenRoughnessMapUv:ke&&S(I.sheenRoughnessMap.channel),specularMapUv:He&&S(I.specularMap.channel),specularColorMapUv:Oe&&S(I.specularColorMap.channel),specularIntensityMapUv:ze&&S(I.specularIntensityMap.channel),transmissionMapUv:B&&S(I.transmissionMap.channel),thicknessMapUv:ye&&S(I.thicknessMap.channel),alphaMapUv:ve&&S(I.alphaMap.channel),vertexTangents:!!Q.attributes.tangent&&($||Re),vertexColors:I.vertexColors,vertexAlphas:I.vertexColors===!0&&!!Q.attributes.color&&Q.attributes.color.itemSize===4,pointsUvs:Z.isPoints===!0&&!!Q.attributes.uv&&(he||ve),fog:!!J,useFog:I.fog===!0,fogExp2:!!J&&J.isFogExp2,flatShading:I.flatShading===!0&&I.wireframe===!1,sizeAttenuation:I.sizeAttenuation===!0,logarithmicDepthBuffer:o,reversedDepthBuffer:K,skinning:Z.isSkinnedMesh===!0,morphTargets:Q.morphAttributes.position!==void 0,morphNormals:Q.morphAttributes.normal!==void 0,morphColors:Q.morphAttributes.color!==void 0,morphTargetsCount:ge,morphTextureStride:we,numDirLights:M.directional.length,numPointLights:M.point.length,numSpotLights:M.spot.length,numSpotLightMaps:M.spotLightMap.length,numRectAreaLights:M.rectArea.length,numHemiLights:M.hemi.length,numDirLightShadows:M.directionalShadowMap.length,numPointLightShadows:M.pointShadowMap.length,numSpotLightShadows:M.spotShadowMap.length,numSpotLightShadowsWithMaps:M.numSpotLightShadowsWithMaps,numLightProbes:M.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:I.dithering,shadowMapEnabled:n.shadowMap.enabled&&N.length>0,shadowMapType:n.shadowMap.type,toneMapping:Xe,decodeVideoTexture:he&&I.map.isVideoTexture===!0&&je.getTransfer(I.map.colorSpace)===it,decodeVideoTextureEmissive:O&&I.emissiveMap.isVideoTexture===!0&&je.getTransfer(I.emissiveMap.colorSpace)===it,premultipliedAlpha:I.premultipliedAlpha,doubleSided:I.side===on,flipSided:I.side===Ot,useDepthPacking:I.depthPacking>=0,depthPacking:I.depthPacking||0,index0AttributeName:I.index0AttributeName,extensionClipCullDistance:Pe&&I.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Pe&&I.extensions.multiDraw===!0||k)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:I.customProgramCacheKey()};return lt.vertexUv1s=u.has(1),lt.vertexUv2s=u.has(2),lt.vertexUv3s=u.has(3),u.clear(),lt}function f(I){const M=[];if(I.shaderID?M.push(I.shaderID):(M.push(I.customVertexShaderID),M.push(I.customFragmentShaderID)),I.defines!==void 0)for(const N in I.defines)M.push(N),M.push(I.defines[N]);return I.isRawShaderMaterial===!1&&(_(M,I),A(M,I),M.push(n.outputColorSpace)),M.push(I.customProgramCacheKey),M.join()}function _(I,M){I.push(M.precision),I.push(M.outputColorSpace),I.push(M.envMapMode),I.push(M.envMapCubeUVHeight),I.push(M.mapUv),I.push(M.alphaMapUv),I.push(M.lightMapUv),I.push(M.aoMapUv),I.push(M.bumpMapUv),I.push(M.normalMapUv),I.push(M.displacementMapUv),I.push(M.emissiveMapUv),I.push(M.metalnessMapUv),I.push(M.roughnessMapUv),I.push(M.anisotropyMapUv),I.push(M.clearcoatMapUv),I.push(M.clearcoatNormalMapUv),I.push(M.clearcoatRoughnessMapUv),I.push(M.iridescenceMapUv),I.push(M.iridescenceThicknessMapUv),I.push(M.sheenColorMapUv),I.push(M.sheenRoughnessMapUv),I.push(M.specularMapUv),I.push(M.specularColorMapUv),I.push(M.specularIntensityMapUv),I.push(M.transmissionMapUv),I.push(M.thicknessMapUv),I.push(M.combine),I.push(M.fogExp2),I.push(M.sizeAttenuation),I.push(M.morphTargetsCount),I.push(M.morphAttributeCount),I.push(M.numDirLights),I.push(M.numPointLights),I.push(M.numSpotLights),I.push(M.numSpotLightMaps),I.push(M.numHemiLights),I.push(M.numRectAreaLights),I.push(M.numDirLightShadows),I.push(M.numPointLightShadows),I.push(M.numSpotLightShadows),I.push(M.numSpotLightShadowsWithMaps),I.push(M.numLightProbes),I.push(M.shadowMapType),I.push(M.toneMapping),I.push(M.numClippingPlanes),I.push(M.numClipIntersection),I.push(M.depthPacking)}function A(I,M){l.disableAll(),M.supportsVertexTextures&&l.enable(0),M.instancing&&l.enable(1),M.instancingColor&&l.enable(2),M.instancingMorph&&l.enable(3),M.matcap&&l.enable(4),M.envMap&&l.enable(5),M.normalMapObjectSpace&&l.enable(6),M.normalMapTangentSpace&&l.enable(7),M.clearcoat&&l.enable(8),M.iridescence&&l.enable(9),M.alphaTest&&l.enable(10),M.vertexColors&&l.enable(11),M.vertexAlphas&&l.enable(12),M.vertexUv1s&&l.enable(13),M.vertexUv2s&&l.enable(14),M.vertexUv3s&&l.enable(15),M.vertexTangents&&l.enable(16),M.anisotropy&&l.enable(17),M.alphaHash&&l.enable(18),M.batching&&l.enable(19),M.dispersion&&l.enable(20),M.batchingColor&&l.enable(21),M.gradientMap&&l.enable(22),I.push(l.mask),l.disableAll(),M.fog&&l.enable(0),M.useFog&&l.enable(1),M.flatShading&&l.enable(2),M.logarithmicDepthBuffer&&l.enable(3),M.reversedDepthBuffer&&l.enable(4),M.skinning&&l.enable(5),M.morphTargets&&l.enable(6),M.morphNormals&&l.enable(7),M.morphColors&&l.enable(8),M.premultipliedAlpha&&l.enable(9),M.shadowMapEnabled&&l.enable(10),M.doubleSided&&l.enable(11),M.flipSided&&l.enable(12),M.useDepthPacking&&l.enable(13),M.dithering&&l.enable(14),M.transmission&&l.enable(15),M.sheen&&l.enable(16),M.opaque&&l.enable(17),M.pointsUvs&&l.enable(18),M.decodeVideoTexture&&l.enable(19),M.decodeVideoTextureEmissive&&l.enable(20),M.alphaToCoverage&&l.enable(21),I.push(l.mask)}function R(I){const M=m[I.type];let N;if(M){const V=dn[M];N=jh.clone(V.uniforms)}else N=I.uniforms;return N}function C(I,M){let N;for(let V=0,Z=p.length;V<Z;V++){const J=p[V];if(J.cacheKey===M){N=J,++N.usedTimes;break}}return N===void 0&&(N=new hS(n,M,I,r),p.push(N)),N}function L(I){if(--I.usedTimes===0){const M=p.indexOf(I);p[M]=p[p.length-1],p.pop(),I.destroy()}}function D(I){d.remove(I)}function F(){d.dispose()}return{getParameters:E,getProgramCacheKey:f,getUniforms:R,acquireProgram:C,releaseProgram:L,releaseShaderCache:D,programs:p,dispose:F}}function mS(){let n=new WeakMap;function e(a){return n.has(a)}function t(a){let l=n.get(a);return l===void 0&&(l={},n.set(a,l)),l}function i(a){n.delete(a)}function s(a,l,d){n.get(a)[l]=d}function r(){n=new WeakMap}return{has:e,get:t,remove:i,update:s,dispose:r}}function SS(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function tc(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function nc(){const n=[];let e=0;const t=[],i=[],s=[];function r(){e=0,t.length=0,i.length=0,s.length=0}function a(o,c,h,m,S,E){let f=n[e];return f===void 0?(f={id:o.id,object:o,geometry:c,material:h,groupOrder:m,renderOrder:o.renderOrder,z:S,group:E},n[e]=f):(f.id=o.id,f.object=o,f.geometry=c,f.material=h,f.groupOrder=m,f.renderOrder=o.renderOrder,f.z=S,f.group=E),e++,f}function l(o,c,h,m,S,E){const f=a(o,c,h,m,S,E);h.transmission>0?i.push(f):h.transparent===!0?s.push(f):t.push(f)}function d(o,c,h,m,S,E){const f=a(o,c,h,m,S,E);h.transmission>0?i.unshift(f):h.transparent===!0?s.unshift(f):t.unshift(f)}function u(o,c){t.length>1&&t.sort(o||SS),i.length>1&&i.sort(c||tc),s.length>1&&s.sort(c||tc)}function p(){for(let o=e,c=n.length;o<c;o++){const h=n[o];if(h.id===null)break;h.id=null,h.object=null,h.geometry=null,h.material=null,h.group=null}}return{opaque:t,transmissive:i,transparent:s,init:r,push:l,unshift:d,finish:p,sort:u}}function AS(){let n=new WeakMap;function e(i,s){const r=n.get(i);let a;return r===void 0?(a=new nc,n.set(i,[a])):s>=r.length?(a=new nc,r.push(a)):a=r[s],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function _S(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new w,color:new Qe};break;case"SpotLight":t={position:new w,direction:new w,color:new Qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new w,color:new Qe,distance:0,decay:0};break;case"HemisphereLight":t={direction:new w,skyColor:new Qe,groundColor:new Qe};break;case"RectAreaLight":t={color:new Qe,position:new w,halfWidth:new w,halfHeight:new w};break}return n[e.id]=t,t}}}function xS(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new le,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let gS=0;function TS(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function RS(n){const e=new _S,t=xS(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)i.probe.push(new w);const s=new w,r=new _t,a=new _t;function l(u){let p=0,o=0,c=0;for(let I=0;I<9;I++)i.probe[I].set(0,0,0);let h=0,m=0,S=0,E=0,f=0,_=0,A=0,R=0,C=0,L=0,D=0;u.sort(TS);for(let I=0,M=u.length;I<M;I++){const N=u[I],V=N.color,Z=N.intensity,J=N.distance,Q=N.shadow&&N.shadow.map?N.shadow.map.texture:null;if(N.isAmbientLight)p+=V.r*Z,o+=V.g*Z,c+=V.b*Z;else if(N.isLightProbe){for(let ie=0;ie<9;ie++)i.probe[ie].addScaledVector(N.sh.coefficients[ie],Z);D++}else if(N.isDirectionalLight){const ie=e.get(N);if(ie.color.copy(N.color).multiplyScalar(N.intensity),N.castShadow){const j=N.shadow,H=t.get(N);H.shadowIntensity=j.intensity,H.shadowBias=j.bias,H.shadowNormalBias=j.normalBias,H.shadowRadius=j.radius,H.shadowMapSize=j.mapSize,i.directionalShadow[h]=H,i.directionalShadowMap[h]=Q,i.directionalShadowMatrix[h]=N.shadow.matrix,_++}i.directional[h]=ie,h++}else if(N.isSpotLight){const ie=e.get(N);ie.position.setFromMatrixPosition(N.matrixWorld),ie.color.copy(V).multiplyScalar(Z),ie.distance=J,ie.coneCos=Math.cos(N.angle),ie.penumbraCos=Math.cos(N.angle*(1-N.penumbra)),ie.decay=N.decay,i.spot[S]=ie;const j=N.shadow;if(N.map&&(i.spotLightMap[C]=N.map,C++,j.updateMatrices(N),N.castShadow&&L++),i.spotLightMatrix[S]=j.matrix,N.castShadow){const H=t.get(N);H.shadowIntensity=j.intensity,H.shadowBias=j.bias,H.shadowNormalBias=j.normalBias,H.shadowRadius=j.radius,H.shadowMapSize=j.mapSize,i.spotShadow[S]=H,i.spotShadowMap[S]=Q,R++}S++}else if(N.isRectAreaLight){const ie=e.get(N);ie.color.copy(V).multiplyScalar(Z),ie.halfWidth.set(N.width*.5,0,0),ie.halfHeight.set(0,N.height*.5,0),i.rectArea[E]=ie,E++}else if(N.isPointLight){const ie=e.get(N);if(ie.color.copy(N.color).multiplyScalar(N.intensity),ie.distance=N.distance,ie.decay=N.decay,N.castShadow){const j=N.shadow,H=t.get(N);H.shadowIntensity=j.intensity,H.shadowBias=j.bias,H.shadowNormalBias=j.normalBias,H.shadowRadius=j.radius,H.shadowMapSize=j.mapSize,H.shadowCameraNear=j.camera.near,H.shadowCameraFar=j.camera.far,i.pointShadow[m]=H,i.pointShadowMap[m]=Q,i.pointShadowMatrix[m]=N.shadow.matrix,A++}i.point[m]=ie,m++}else if(N.isHemisphereLight){const ie=e.get(N);ie.skyColor.copy(N.color).multiplyScalar(Z),ie.groundColor.copy(N.groundColor).multiplyScalar(Z),i.hemi[f]=ie,f++}}E>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=Ie.LTC_FLOAT_1,i.rectAreaLTC2=Ie.LTC_FLOAT_2):(i.rectAreaLTC1=Ie.LTC_HALF_1,i.rectAreaLTC2=Ie.LTC_HALF_2)),i.ambient[0]=p,i.ambient[1]=o,i.ambient[2]=c;const F=i.hash;(F.directionalLength!==h||F.pointLength!==m||F.spotLength!==S||F.rectAreaLength!==E||F.hemiLength!==f||F.numDirectionalShadows!==_||F.numPointShadows!==A||F.numSpotShadows!==R||F.numSpotMaps!==C||F.numLightProbes!==D)&&(i.directional.length=h,i.spot.length=S,i.rectArea.length=E,i.point.length=m,i.hemi.length=f,i.directionalShadow.length=_,i.directionalShadowMap.length=_,i.pointShadow.length=A,i.pointShadowMap.length=A,i.spotShadow.length=R,i.spotShadowMap.length=R,i.directionalShadowMatrix.length=_,i.pointShadowMatrix.length=A,i.spotLightMatrix.length=R+C-L,i.spotLightMap.length=C,i.numSpotLightShadowsWithMaps=L,i.numLightProbes=D,F.directionalLength=h,F.pointLength=m,F.spotLength=S,F.rectAreaLength=E,F.hemiLength=f,F.numDirectionalShadows=_,F.numPointShadows=A,F.numSpotShadows=R,F.numSpotMaps=C,F.numLightProbes=D,i.version=gS++)}function d(u,p){let o=0,c=0,h=0,m=0,S=0;const E=p.matrixWorldInverse;for(let f=0,_=u.length;f<_;f++){const A=u[f];if(A.isDirectionalLight){const R=i.directional[o];R.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(E),o++}else if(A.isSpotLight){const R=i.spot[h];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(E),R.direction.setFromMatrixPosition(A.matrixWorld),s.setFromMatrixPosition(A.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(E),h++}else if(A.isRectAreaLight){const R=i.rectArea[m];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(E),a.identity(),r.copy(A.matrixWorld),r.premultiply(E),a.extractRotation(r),R.halfWidth.set(A.width*.5,0,0),R.halfHeight.set(0,A.height*.5,0),R.halfWidth.applyMatrix4(a),R.halfHeight.applyMatrix4(a),m++}else if(A.isPointLight){const R=i.point[c];R.position.setFromMatrixPosition(A.matrixWorld),R.position.applyMatrix4(E),c++}else if(A.isHemisphereLight){const R=i.hemi[S];R.direction.setFromMatrixPosition(A.matrixWorld),R.direction.transformDirection(E),S++}}}return{setup:l,setupView:d,state:i}}function ic(n){const e=new RS(n),t=[],i=[];function s(p){u.camera=p,t.length=0,i.length=0}function r(p){t.push(p)}function a(p){i.push(p)}function l(){e.setup(t)}function d(p){e.setupView(t,p)}const u={lightsArray:t,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:u,setupLights:l,setupLightsView:d,pushLight:r,pushShadow:a}}function MS(n){let e=new WeakMap;function t(s,r=0){const a=e.get(s);let l;return a===void 0?(l=new ic(n),e.set(s,[l])):r>=a.length?(l=new ic(n),a.push(l)):l=a[r],l}function i(){e=new WeakMap}return{get:t,dispose:i}}const vS=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,IS=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function yS(n,e,t){let i=new Wc;const s=new le,r=new le,a=new St,l=new Wd({depthPacking:gh}),d=new zd,u={},p=t.maxTextureSize,o={[mn]:Ot,[Ot]:mn,[on]:on},c=new Bn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new le},radius:{value:4}},vertexShader:vS,fragmentShader:IS}),h=c.clone();h.defines.HORIZONTAL_PASS=1;const m=new Rt;m.setAttribute("position",new un(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const S=new At(m,c),E=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=vc;let f=this.type;this.render=function(L,D,F){if(E.enabled===!1||E.autoUpdate===!1&&E.needsUpdate===!1||L.length===0)return;const I=n.getRenderTarget(),M=n.getActiveCubeFace(),N=n.getActiveMipmapLevel(),V=n.state;V.setBlending(Pn),V.buffers.depth.getReversed()===!0?V.buffers.color.setClear(0,0,0,0):V.buffers.color.setClear(1,1,1,1),V.buffers.depth.setTest(!0),V.setScissorTest(!1);const Z=f!==yn&&this.type===yn,J=f===yn&&this.type!==yn;for(let Q=0,ie=L.length;Q<ie;Q++){const j=L[Q],H=j.shadow;if(H===void 0){Ke("WebGLShadowMap:",j,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;s.copy(H.mapSize);const Ee=H.getFrameExtents();if(s.multiply(Ee),r.copy(H.mapSize),(s.x>p||s.y>p)&&(s.x>p&&(r.x=Math.floor(p/Ee.x),s.x=r.x*Ee.x,H.mapSize.x=r.x),s.y>p&&(r.y=Math.floor(p/Ee.y),s.y=r.y*Ee.y,H.mapSize.y=r.y)),H.map===null||Z===!0||J===!0){const ge=this.type!==yn?{minFilter:Kt,magFilter:Kt}:{};H.map!==null&&H.map.dispose(),H.map=new wn(s.x,s.y,ge),H.map.texture.name=j.name+".shadowMap",H.camera.updateProjectionMatrix()}n.setRenderTarget(H.map),n.clear();const re=H.getViewportCount();for(let ge=0;ge<re;ge++){const we=H.getViewport(ge);a.set(r.x*we.x,r.y*we.y,r.x*we.z,r.y*we.w),V.viewport(a),H.updateMatrices(j,ge),i=H.getFrustum(),R(D,F,H.camera,j,this.type)}H.isPointLightShadow!==!0&&this.type===yn&&_(H,F),H.needsUpdate=!1}f=this.type,E.needsUpdate=!1,n.setRenderTarget(I,M,N)};function _(L,D){const F=e.update(S);c.defines.VSM_SAMPLES!==L.blurSamples&&(c.defines.VSM_SAMPLES=L.blurSamples,h.defines.VSM_SAMPLES=L.blurSamples,c.needsUpdate=!0,h.needsUpdate=!0),L.mapPass===null&&(L.mapPass=new wn(s.x,s.y)),c.uniforms.shadow_pass.value=L.map.texture,c.uniforms.resolution.value=L.mapSize,c.uniforms.radius.value=L.radius,n.setRenderTarget(L.mapPass),n.clear(),n.renderBufferDirect(D,null,F,c,S,null),h.uniforms.shadow_pass.value=L.mapPass.texture,h.uniforms.resolution.value=L.mapSize,h.uniforms.radius.value=L.radius,n.setRenderTarget(L.map),n.clear(),n.renderBufferDirect(D,null,F,h,S,null)}function A(L,D,F,I){let M=null;const N=F.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(N!==void 0)M=N;else if(M=F.isPointLight===!0?d:l,n.localClippingEnabled&&D.clipShadows===!0&&Array.isArray(D.clippingPlanes)&&D.clippingPlanes.length!==0||D.displacementMap&&D.displacementScale!==0||D.alphaMap&&D.alphaTest>0||D.map&&D.alphaTest>0||D.alphaToCoverage===!0){const V=M.uuid,Z=D.uuid;let J=u[V];J===void 0&&(J={},u[V]=J);let Q=J[Z];Q===void 0&&(Q=M.clone(),J[Z]=Q,D.addEventListener("dispose",C)),M=Q}if(M.visible=D.visible,M.wireframe=D.wireframe,I===yn?M.side=D.shadowSide!==null?D.shadowSide:D.side:M.side=D.shadowSide!==null?D.shadowSide:o[D.side],M.alphaMap=D.alphaMap,M.alphaTest=D.alphaToCoverage===!0?.5:D.alphaTest,M.map=D.map,M.clipShadows=D.clipShadows,M.clippingPlanes=D.clippingPlanes,M.clipIntersection=D.clipIntersection,M.displacementMap=D.displacementMap,M.displacementScale=D.displacementScale,M.displacementBias=D.displacementBias,M.wireframeLinewidth=D.wireframeLinewidth,M.linewidth=D.linewidth,F.isPointLight===!0&&M.isMeshDistanceMaterial===!0){const V=n.properties.get(M);V.light=F}return M}function R(L,D,F,I,M){if(L.visible===!1)return;if(L.layers.test(D.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&M===yn)&&(!L.frustumCulled||i.intersectsObject(L))){L.modelViewMatrix.multiplyMatrices(F.matrixWorldInverse,L.matrixWorld);const Z=e.update(L),J=L.material;if(Array.isArray(J)){const Q=Z.groups;for(let ie=0,j=Q.length;ie<j;ie++){const H=Q[ie],Ee=J[H.materialIndex];if(Ee&&Ee.visible){const re=A(L,Ee,I,M);L.onBeforeShadow(n,L,D,F,Z,re,H),n.renderBufferDirect(F,null,Z,re,L,H),L.onAfterShadow(n,L,D,F,Z,re,H)}}}else if(J.visible){const Q=A(L,J,I,M);L.onBeforeShadow(n,L,D,F,Z,Q,null),n.renderBufferDirect(F,null,Z,Q,L,null),L.onAfterShadow(n,L,D,F,Z,Q,null)}}const V=L.children;for(let Z=0,J=V.length;Z<J;Z++)R(V[Z],D,F,I,M)}function C(L){L.target.removeEventListener("dispose",C);for(const F in u){const I=u[F],M=L.target.uuid;M in I&&(I[M].dispose(),delete I[M])}}}const LS={[Lo]:Oo,[bo]:Po,[Co]:No,[Ki]:Do,[Oo]:Lo,[Po]:bo,[No]:Co,[Do]:Ki};function OS(n,e){function t(){let B=!1;const ye=new St;let Me=null;const ve=new St(0,0,0,0);return{setMask:function(Se){Me!==Se&&!B&&(n.colorMask(Se,Se,Se,Se),Me=Se)},setLocked:function(Se){B=Se},setClear:function(Se,fe,Pe,Xe,lt){lt===!0&&(Se*=Xe,fe*=Xe,Pe*=Xe),ye.set(Se,fe,Pe,Xe),ve.equals(ye)===!1&&(n.clearColor(Se,fe,Pe,Xe),ve.copy(ye))},reset:function(){B=!1,Me=null,ve.set(-1,0,0,0)}}}function i(){let B=!1,ye=!1,Me=null,ve=null,Se=null;return{setReversed:function(fe){if(ye!==fe){const Pe=e.get("EXT_clip_control");fe?Pe.clipControlEXT(Pe.LOWER_LEFT_EXT,Pe.ZERO_TO_ONE_EXT):Pe.clipControlEXT(Pe.LOWER_LEFT_EXT,Pe.NEGATIVE_ONE_TO_ONE_EXT),ye=fe;const Xe=Se;Se=null,this.setClear(Xe)}},getReversed:function(){return ye},setTest:function(fe){fe?g(n.DEPTH_TEST):K(n.DEPTH_TEST)},setMask:function(fe){Me!==fe&&!B&&(n.depthMask(fe),Me=fe)},setFunc:function(fe){if(ye&&(fe=LS[fe]),ve!==fe){switch(fe){case Lo:n.depthFunc(n.NEVER);break;case Oo:n.depthFunc(n.ALWAYS);break;case bo:n.depthFunc(n.LESS);break;case Ki:n.depthFunc(n.LEQUAL);break;case Co:n.depthFunc(n.EQUAL);break;case Do:n.depthFunc(n.GEQUAL);break;case Po:n.depthFunc(n.GREATER);break;case No:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}ve=fe}},setLocked:function(fe){B=fe},setClear:function(fe){Se!==fe&&(ye&&(fe=1-fe),n.clearDepth(fe),Se=fe)},reset:function(){B=!1,Me=null,ve=null,Se=null,ye=!1}}}function s(){let B=!1,ye=null,Me=null,ve=null,Se=null,fe=null,Pe=null,Xe=null,lt=null;return{setTest:function(et){B||(et?g(n.STENCIL_TEST):K(n.STENCIL_TEST))},setMask:function(et){ye!==et&&!B&&(n.stencilMask(et),ye=et)},setFunc:function(et,hn,en){(Me!==et||ve!==hn||Se!==en)&&(n.stencilFunc(et,hn,en),Me=et,ve=hn,Se=en)},setOp:function(et,hn,en){(fe!==et||Pe!==hn||Xe!==en)&&(n.stencilOp(et,hn,en),fe=et,Pe=hn,Xe=en)},setLocked:function(et){B=et},setClear:function(et){lt!==et&&(n.clearStencil(et),lt=et)},reset:function(){B=!1,ye=null,Me=null,ve=null,Se=null,fe=null,Pe=null,Xe=null,lt=null}}}const r=new t,a=new i,l=new s,d=new WeakMap,u=new WeakMap;let p={},o={},c=new WeakMap,h=[],m=null,S=!1,E=null,f=null,_=null,A=null,R=null,C=null,L=null,D=new Qe(0,0,0),F=0,I=!1,M=null,N=null,V=null,Z=null,J=null;const Q=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let ie=!1,j=0;const H=n.getParameter(n.VERSION);H.indexOf("WebGL")!==-1?(j=parseFloat(/^WebGL (\d)/.exec(H)[1]),ie=j>=1):H.indexOf("OpenGL ES")!==-1&&(j=parseFloat(/^OpenGL ES (\d)/.exec(H)[1]),ie=j>=2);let Ee=null,re={};const ge=n.getParameter(n.SCISSOR_BOX),we=n.getParameter(n.VIEWPORT),Ve=new St().fromArray(ge),z=new St().fromArray(we);function U(B,ye,Me,ve){const Se=new Uint8Array(4),fe=n.createTexture();n.bindTexture(B,fe),n.texParameteri(B,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(B,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Pe=0;Pe<Me;Pe++)B===n.TEXTURE_3D||B===n.TEXTURE_2D_ARRAY?n.texImage3D(ye,0,n.RGBA,1,1,ve,0,n.RGBA,n.UNSIGNED_BYTE,Se):n.texImage2D(ye+Pe,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Se);return fe}const v={};v[n.TEXTURE_2D]=U(n.TEXTURE_2D,n.TEXTURE_2D,1),v[n.TEXTURE_CUBE_MAP]=U(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),v[n.TEXTURE_2D_ARRAY]=U(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),v[n.TEXTURE_3D]=U(n.TEXTURE_3D,n.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),l.setClear(0),g(n.DEPTH_TEST),a.setFunc(Ki),q(!1),$(el),g(n.CULL_FACE),G(Pn);function g(B){p[B]!==!0&&(n.enable(B),p[B]=!0)}function K(B){p[B]!==!1&&(n.disable(B),p[B]=!1)}function oe(B,ye){return o[B]!==ye?(n.bindFramebuffer(B,ye),o[B]=ye,B===n.DRAW_FRAMEBUFFER&&(o[n.FRAMEBUFFER]=ye),B===n.FRAMEBUFFER&&(o[n.DRAW_FRAMEBUFFER]=ye),!0):!1}function k(B,ye){let Me=h,ve=!1;if(B){Me=c.get(ye),Me===void 0&&(Me=[],c.set(ye,Me));const Se=B.textures;if(Me.length!==Se.length||Me[0]!==n.COLOR_ATTACHMENT0){for(let fe=0,Pe=Se.length;fe<Pe;fe++)Me[fe]=n.COLOR_ATTACHMENT0+fe;Me.length=Se.length,ve=!0}}else Me[0]!==n.BACK&&(Me[0]=n.BACK,ve=!0);ve&&n.drawBuffers(Me)}function he(B){return m!==B?(n.useProgram(B),m=B,!0):!1}const Ae={[ui]:n.FUNC_ADD,[Xu]:n.FUNC_SUBTRACT,[qu]:n.FUNC_REVERSE_SUBTRACT};Ae[Zu]=n.MIN,Ae[Ju]=n.MAX;const de={[Qu]:n.ZERO,[$u]:n.ONE,[ju]:n.SRC_COLOR,[Io]:n.SRC_ALPHA,[rh]:n.SRC_ALPHA_SATURATE,[ih]:n.DST_COLOR,[th]:n.DST_ALPHA,[eh]:n.ONE_MINUS_SRC_COLOR,[yo]:n.ONE_MINUS_SRC_ALPHA,[sh]:n.ONE_MINUS_DST_COLOR,[nh]:n.ONE_MINUS_DST_ALPHA,[oh]:n.CONSTANT_COLOR,[ah]:n.ONE_MINUS_CONSTANT_COLOR,[lh]:n.CONSTANT_ALPHA,[ch]:n.ONE_MINUS_CONSTANT_ALPHA};function G(B,ye,Me,ve,Se,fe,Pe,Xe,lt,et){if(B===Pn){S===!0&&(K(n.BLEND),S=!1);return}if(S===!1&&(g(n.BLEND),S=!0),B!==Ku){if(B!==E||et!==I){if((f!==ui||R!==ui)&&(n.blendEquation(n.FUNC_ADD),f=ui,R=ui),et)switch(B){case Wi:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case tl:n.blendFunc(n.ONE,n.ONE);break;case nl:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case il:n.blendFuncSeparate(n.DST_COLOR,n.ONE_MINUS_SRC_ALPHA,n.ZERO,n.ONE);break;default:dt("WebGLState: Invalid blending: ",B);break}else switch(B){case Wi:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case tl:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE,n.ONE,n.ONE);break;case nl:dt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case il:dt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:dt("WebGLState: Invalid blending: ",B);break}_=null,A=null,C=null,L=null,D.set(0,0,0),F=0,E=B,I=et}return}Se=Se||ye,fe=fe||Me,Pe=Pe||ve,(ye!==f||Se!==R)&&(n.blendEquationSeparate(Ae[ye],Ae[Se]),f=ye,R=Se),(Me!==_||ve!==A||fe!==C||Pe!==L)&&(n.blendFuncSeparate(de[Me],de[ve],de[fe],de[Pe]),_=Me,A=ve,C=fe,L=Pe),(Xe.equals(D)===!1||lt!==F)&&(n.blendColor(Xe.r,Xe.g,Xe.b,lt),D.copy(Xe),F=lt),E=B,I=!1}function T(B,ye){B.side===on?K(n.CULL_FACE):g(n.CULL_FACE);let Me=B.side===Ot;ye&&(Me=!Me),q(Me),B.blending===Wi&&B.transparent===!1?G(Pn):G(B.blending,B.blendEquation,B.blendSrc,B.blendDst,B.blendEquationAlpha,B.blendSrcAlpha,B.blendDstAlpha,B.blendColor,B.blendAlpha,B.premultipliedAlpha),a.setFunc(B.depthFunc),a.setTest(B.depthTest),a.setMask(B.depthWrite),r.setMask(B.colorWrite);const ve=B.stencilWrite;l.setTest(ve),ve&&(l.setMask(B.stencilWriteMask),l.setFunc(B.stencilFunc,B.stencilRef,B.stencilFuncMask),l.setOp(B.stencilFail,B.stencilZFail,B.stencilZPass)),O(B.polygonOffset,B.polygonOffsetFactor,B.polygonOffsetUnits),B.alphaToCoverage===!0?g(n.SAMPLE_ALPHA_TO_COVERAGE):K(n.SAMPLE_ALPHA_TO_COVERAGE)}function q(B){M!==B&&(B?n.frontFace(n.CW):n.frontFace(n.CCW),M=B)}function $(B){B!==Yu?(g(n.CULL_FACE),B!==N&&(B===el?n.cullFace(n.BACK):B===Wu?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):K(n.CULL_FACE),N=B}function P(B){B!==V&&(ie&&n.lineWidth(B),V=B)}function O(B,ye,Me){B?(g(n.POLYGON_OFFSET_FILL),(Z!==ye||J!==Me)&&(n.polygonOffset(ye,Me),Z=ye,J=Me)):K(n.POLYGON_OFFSET_FILL)}function ae(B){B?g(n.SCISSOR_TEST):K(n.SCISSOR_TEST)}function ue(B){B===void 0&&(B=n.TEXTURE0+Q-1),Ee!==B&&(n.activeTexture(B),Ee=B)}function Re(B,ye,Me){Me===void 0&&(Ee===null?Me=n.TEXTURE0+Q-1:Me=Ee);let ve=re[Me];ve===void 0&&(ve={type:void 0,texture:void 0},re[Me]=ve),(ve.type!==B||ve.texture!==ye)&&(Ee!==Me&&(n.activeTexture(Me),Ee=Me),n.bindTexture(B,ye||v[B]),ve.type=B,ve.texture=ye)}function b(){const B=re[Ee];B!==void 0&&B.type!==void 0&&(n.bindTexture(B.type,null),B.type=void 0,B.texture=void 0)}function x(){try{n.compressedTexImage2D(...arguments)}catch(B){B("WebGLState:",B)}}function Y(){try{n.compressedTexImage3D(...arguments)}catch(B){B("WebGLState:",B)}}function se(){try{n.texSubImage2D(...arguments)}catch(B){B("WebGLState:",B)}}function pe(){try{n.texSubImage3D(...arguments)}catch(B){B("WebGLState:",B)}}function ne(){try{n.compressedTexSubImage2D(...arguments)}catch(B){B("WebGLState:",B)}}function De(){try{n.compressedTexSubImage3D(...arguments)}catch(B){B("WebGLState:",B)}}function Te(){try{n.texStorage2D(...arguments)}catch(B){B("WebGLState:",B)}}function Ue(){try{n.texStorage3D(...arguments)}catch(B){B("WebGLState:",B)}}function Ce(){try{n.texImage2D(...arguments)}catch(B){B("WebGLState:",B)}}function me(){try{n.texImage3D(...arguments)}catch(B){B("WebGLState:",B)}}function _e(B){Ve.equals(B)===!1&&(n.scissor(B.x,B.y,B.z,B.w),Ve.copy(B))}function ke(B){z.equals(B)===!1&&(n.viewport(B.x,B.y,B.z,B.w),z.copy(B))}function He(B,ye){let Me=u.get(ye);Me===void 0&&(Me=new WeakMap,u.set(ye,Me));let ve=Me.get(B);ve===void 0&&(ve=n.getUniformBlockIndex(ye,B.name),Me.set(B,ve))}function Oe(B,ye){const ve=u.get(ye).get(B);d.get(ye)!==ve&&(n.uniformBlockBinding(ye,ve,B.__bindingPointIndex),d.set(ye,ve))}function ze(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),a.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),p={},Ee=null,re={},o={},c=new WeakMap,h=[],m=null,S=!1,E=null,f=null,_=null,A=null,R=null,C=null,L=null,D=new Qe(0,0,0),F=0,I=!1,M=null,N=null,V=null,Z=null,J=null,Ve.set(0,0,n.canvas.width,n.canvas.height),z.set(0,0,n.canvas.width,n.canvas.height),r.reset(),a.reset(),l.reset()}return{buffers:{color:r,depth:a,stencil:l},enable:g,disable:K,bindFramebuffer:oe,drawBuffers:k,useProgram:he,setBlending:G,setMaterial:T,setFlipSided:q,setCullFace:$,setLineWidth:P,setPolygonOffset:O,setScissorTest:ae,activeTexture:ue,bindTexture:Re,unbindTexture:b,compressedTexImage2D:x,compressedTexImage3D:Y,texImage2D:Ce,texImage3D:me,updateUBOMapping:He,uniformBlockBinding:Oe,texStorage2D:Te,texStorage3D:Ue,texSubImage2D:se,texSubImage3D:pe,compressedTexSubImage2D:ne,compressedTexSubImage3D:De,scissor:_e,viewport:ke,reset:ze}}function bS(n,e,t,i,s,r,a){const l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,d=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new le,p=new WeakMap;let o;const c=new WeakMap;let h=!1;try{h=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(b,x){return h?new OffscreenCanvas(b,x):Ar("canvas")}function S(b,x,Y){let se=1;const pe=Re(b);if((pe.width>Y||pe.height>Y)&&(se=Y/Math.max(pe.width,pe.height)),se<1)if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&b instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&b instanceof ImageBitmap||typeof VideoFrame<"u"&&b instanceof VideoFrame){const ne=Math.floor(se*pe.width),De=Math.floor(se*pe.height);o===void 0&&(o=m(ne,De));const Te=x?m(ne,De):o;return Te.width=ne,Te.height=De,Te.getContext("2d").drawImage(b,0,0,ne,De),Ke("WebGLRenderer: Texture has been resized from ("+pe.width+"x"+pe.height+") to ("+ne+"x"+De+")."),Te}else return"data"in b&&Ke("WebGLRenderer: Image in DataTexture is too big ("+pe.width+"x"+pe.height+")."),b;return b}function E(b){return b.generateMipmaps}function f(b){n.generateMipmap(b)}function _(b){return b.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:b.isWebGL3DRenderTarget?n.TEXTURE_3D:b.isWebGLArrayRenderTarget||b.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function A(b,x,Y,se,pe=!1){if(b!==null){if(n[b]!==void 0)return n[b];Ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+b+"'")}let ne=x;if(x===n.RED&&(Y===n.FLOAT&&(ne=n.R32F),Y===n.HALF_FLOAT&&(ne=n.R16F),Y===n.UNSIGNED_BYTE&&(ne=n.R8)),x===n.RED_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.R8UI),Y===n.UNSIGNED_SHORT&&(ne=n.R16UI),Y===n.UNSIGNED_INT&&(ne=n.R32UI),Y===n.BYTE&&(ne=n.R8I),Y===n.SHORT&&(ne=n.R16I),Y===n.INT&&(ne=n.R32I)),x===n.RG&&(Y===n.FLOAT&&(ne=n.RG32F),Y===n.HALF_FLOAT&&(ne=n.RG16F),Y===n.UNSIGNED_BYTE&&(ne=n.RG8)),x===n.RG_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RG8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RG16UI),Y===n.UNSIGNED_INT&&(ne=n.RG32UI),Y===n.BYTE&&(ne=n.RG8I),Y===n.SHORT&&(ne=n.RG16I),Y===n.INT&&(ne=n.RG32I)),x===n.RGB_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RGB8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RGB16UI),Y===n.UNSIGNED_INT&&(ne=n.RGB32UI),Y===n.BYTE&&(ne=n.RGB8I),Y===n.SHORT&&(ne=n.RGB16I),Y===n.INT&&(ne=n.RGB32I)),x===n.RGBA_INTEGER&&(Y===n.UNSIGNED_BYTE&&(ne=n.RGBA8UI),Y===n.UNSIGNED_SHORT&&(ne=n.RGBA16UI),Y===n.UNSIGNED_INT&&(ne=n.RGBA32UI),Y===n.BYTE&&(ne=n.RGBA8I),Y===n.SHORT&&(ne=n.RGBA16I),Y===n.INT&&(ne=n.RGBA32I)),x===n.RGB&&(Y===n.UNSIGNED_INT_5_9_9_9_REV&&(ne=n.RGB9_E5),Y===n.UNSIGNED_INT_10F_11F_11F_REV&&(ne=n.R11F_G11F_B10F)),x===n.RGBA){const De=pe?mr:je.getTransfer(se);Y===n.FLOAT&&(ne=n.RGBA32F),Y===n.HALF_FLOAT&&(ne=n.RGBA16F),Y===n.UNSIGNED_BYTE&&(ne=De===it?n.SRGB8_ALPHA8:n.RGBA8),Y===n.UNSIGNED_SHORT_4_4_4_4&&(ne=n.RGBA4),Y===n.UNSIGNED_SHORT_5_5_5_1&&(ne=n.RGB5_A1)}return(ne===n.R16F||ne===n.R32F||ne===n.RG16F||ne===n.RG32F||ne===n.RGBA16F||ne===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function R(b,x){let Y;return b?x===null||x===Si||x===Ts?Y=n.DEPTH24_STENCIL8:x===Dn?Y=n.DEPTH32F_STENCIL8:x===gs&&(Y=n.DEPTH24_STENCIL8,Ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):x===null||x===Si||x===Ts?Y=n.DEPTH_COMPONENT24:x===Dn?Y=n.DEPTH_COMPONENT32F:x===gs&&(Y=n.DEPTH_COMPONENT16),Y}function C(b,x){return E(b)===!0||b.isFramebufferTexture&&b.minFilter!==Kt&&b.minFilter!==$t?Math.log2(Math.max(x.width,x.height))+1:b.mipmaps!==void 0&&b.mipmaps.length>0?b.mipmaps.length:b.isCompressedTexture&&Array.isArray(b.image)?x.mipmaps.length:1}function L(b){const x=b.target;x.removeEventListener("dispose",L),F(x),x.isVideoTexture&&p.delete(x)}function D(b){const x=b.target;x.removeEventListener("dispose",D),M(x)}function F(b){const x=i.get(b);if(x.__webglInit===void 0)return;const Y=b.source,se=c.get(Y);if(se){const pe=se[x.__cacheKey];pe.usedTimes--,pe.usedTimes===0&&I(b),Object.keys(se).length===0&&c.delete(Y)}i.remove(b)}function I(b){const x=i.get(b);n.deleteTexture(x.__webglTexture);const Y=b.source,se=c.get(Y);delete se[x.__cacheKey],a.memory.textures--}function M(b){const x=i.get(b);if(b.depthTexture&&(b.depthTexture.dispose(),i.remove(b.depthTexture)),b.isWebGLCubeRenderTarget)for(let se=0;se<6;se++){if(Array.isArray(x.__webglFramebuffer[se]))for(let pe=0;pe<x.__webglFramebuffer[se].length;pe++)n.deleteFramebuffer(x.__webglFramebuffer[se][pe]);else n.deleteFramebuffer(x.__webglFramebuffer[se]);x.__webglDepthbuffer&&n.deleteRenderbuffer(x.__webglDepthbuffer[se])}else{if(Array.isArray(x.__webglFramebuffer))for(let se=0;se<x.__webglFramebuffer.length;se++)n.deleteFramebuffer(x.__webglFramebuffer[se]);else n.deleteFramebuffer(x.__webglFramebuffer);if(x.__webglDepthbuffer&&n.deleteRenderbuffer(x.__webglDepthbuffer),x.__webglMultisampledFramebuffer&&n.deleteFramebuffer(x.__webglMultisampledFramebuffer),x.__webglColorRenderbuffer)for(let se=0;se<x.__webglColorRenderbuffer.length;se++)x.__webglColorRenderbuffer[se]&&n.deleteRenderbuffer(x.__webglColorRenderbuffer[se]);x.__webglDepthRenderbuffer&&n.deleteRenderbuffer(x.__webglDepthRenderbuffer)}const Y=b.textures;for(let se=0,pe=Y.length;se<pe;se++){const ne=i.get(Y[se]);ne.__webglTexture&&(n.deleteTexture(ne.__webglTexture),a.memory.textures--),i.remove(Y[se])}i.remove(b)}let N=0;function V(){N=0}function Z(){const b=N;return b>=s.maxTextures&&Ke("WebGLTextures: Trying to use "+b+" texture units while this GPU supports only "+s.maxTextures),N+=1,b}function J(b){const x=[];return x.push(b.wrapS),x.push(b.wrapT),x.push(b.wrapR||0),x.push(b.magFilter),x.push(b.minFilter),x.push(b.anisotropy),x.push(b.internalFormat),x.push(b.format),x.push(b.type),x.push(b.generateMipmaps),x.push(b.premultiplyAlpha),x.push(b.flipY),x.push(b.unpackAlignment),x.push(b.colorSpace),x.join()}function Q(b,x){const Y=i.get(b);if(b.isVideoTexture&&ae(b),b.isRenderTargetTexture===!1&&b.isExternalTexture!==!0&&b.version>0&&Y.__version!==b.version){const se=b.image;if(se===null)Ke("WebGLRenderer: Texture marked for update but no image data found.");else if(se.complete===!1)Ke("WebGLRenderer: Texture marked for update but image is incomplete");else{v(Y,b,x);return}}else b.isExternalTexture&&(Y.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D,Y.__webglTexture,n.TEXTURE0+x)}function ie(b,x){const Y=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Y.__version!==b.version){v(Y,b,x);return}else b.isExternalTexture&&(Y.__webglTexture=b.sourceTexture?b.sourceTexture:null);t.bindTexture(n.TEXTURE_2D_ARRAY,Y.__webglTexture,n.TEXTURE0+x)}function j(b,x){const Y=i.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Y.__version!==b.version){v(Y,b,x);return}t.bindTexture(n.TEXTURE_3D,Y.__webglTexture,n.TEXTURE0+x)}function H(b,x){const Y=i.get(b);if(b.version>0&&Y.__version!==b.version){g(Y,b,x);return}t.bindTexture(n.TEXTURE_CUBE_MAP,Y.__webglTexture,n.TEXTURE0+x)}const Ee={[Fo]:n.REPEAT,[Cn]:n.CLAMP_TO_EDGE,[Bo]:n.MIRRORED_REPEAT},re={[Kt]:n.NEAREST,[_h]:n.NEAREST_MIPMAP_NEAREST,[ws]:n.NEAREST_MIPMAP_LINEAR,[$t]:n.LINEAR,[Fr]:n.LINEAR_MIPMAP_NEAREST,[pi]:n.LINEAR_MIPMAP_LINEAR},ge={[Mh]:n.NEVER,[bh]:n.ALWAYS,[vh]:n.LESS,[Uc]:n.LEQUAL,[Ih]:n.EQUAL,[Oh]:n.GEQUAL,[yh]:n.GREATER,[Lh]:n.NOTEQUAL};function we(b,x){if(x.type===Dn&&e.has("OES_texture_float_linear")===!1&&(x.magFilter===$t||x.magFilter===Fr||x.magFilter===ws||x.magFilter===pi||x.minFilter===$t||x.minFilter===Fr||x.minFilter===ws||x.minFilter===pi)&&Ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(b,n.TEXTURE_WRAP_S,Ee[x.wrapS]),n.texParameteri(b,n.TEXTURE_WRAP_T,Ee[x.wrapT]),(b===n.TEXTURE_3D||b===n.TEXTURE_2D_ARRAY)&&n.texParameteri(b,n.TEXTURE_WRAP_R,Ee[x.wrapR]),n.texParameteri(b,n.TEXTURE_MAG_FILTER,re[x.magFilter]),n.texParameteri(b,n.TEXTURE_MIN_FILTER,re[x.minFilter]),x.compareFunction&&(n.texParameteri(b,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(b,n.TEXTURE_COMPARE_FUNC,ge[x.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(x.magFilter===Kt||x.minFilter!==ws&&x.minFilter!==pi||x.type===Dn&&e.has("OES_texture_float_linear")===!1)return;if(x.anisotropy>1||i.get(x).__currentAnisotropy){const Y=e.get("EXT_texture_filter_anisotropic");n.texParameterf(b,Y.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(x.anisotropy,s.getMaxAnisotropy())),i.get(x).__currentAnisotropy=x.anisotropy}}}function Ve(b,x){let Y=!1;b.__webglInit===void 0&&(b.__webglInit=!0,x.addEventListener("dispose",L));const se=x.source;let pe=c.get(se);pe===void 0&&(pe={},c.set(se,pe));const ne=J(x);if(ne!==b.__cacheKey){pe[ne]===void 0&&(pe[ne]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,Y=!0),pe[ne].usedTimes++;const De=pe[b.__cacheKey];De!==void 0&&(pe[b.__cacheKey].usedTimes--,De.usedTimes===0&&I(x)),b.__cacheKey=ne,b.__webglTexture=pe[ne].texture}return Y}function z(b,x,Y){return Math.floor(Math.floor(b/Y)/x)}function U(b,x,Y,se){const ne=b.updateRanges;if(ne.length===0)t.texSubImage2D(n.TEXTURE_2D,0,0,0,x.width,x.height,Y,se,x.data);else{ne.sort((me,_e)=>me.start-_e.start);let De=0;for(let me=1;me<ne.length;me++){const _e=ne[De],ke=ne[me],He=_e.start+_e.count,Oe=z(ke.start,x.width,4),ze=z(_e.start,x.width,4);ke.start<=He+1&&Oe===ze&&z(ke.start+ke.count-1,x.width,4)===Oe?_e.count=Math.max(_e.count,ke.start+ke.count-_e.start):(++De,ne[De]=ke)}ne.length=De+1;const Te=n.getParameter(n.UNPACK_ROW_LENGTH),Ue=n.getParameter(n.UNPACK_SKIP_PIXELS),Ce=n.getParameter(n.UNPACK_SKIP_ROWS);n.pixelStorei(n.UNPACK_ROW_LENGTH,x.width);for(let me=0,_e=ne.length;me<_e;me++){const ke=ne[me],He=Math.floor(ke.start/4),Oe=Math.ceil(ke.count/4),ze=He%x.width,B=Math.floor(He/x.width),ye=Oe,Me=1;n.pixelStorei(n.UNPACK_SKIP_PIXELS,ze),n.pixelStorei(n.UNPACK_SKIP_ROWS,B),t.texSubImage2D(n.TEXTURE_2D,0,ze,B,ye,Me,Y,se,x.data)}b.clearUpdateRanges(),n.pixelStorei(n.UNPACK_ROW_LENGTH,Te),n.pixelStorei(n.UNPACK_SKIP_PIXELS,Ue),n.pixelStorei(n.UNPACK_SKIP_ROWS,Ce)}}function v(b,x,Y){let se=n.TEXTURE_2D;(x.isDataArrayTexture||x.isCompressedArrayTexture)&&(se=n.TEXTURE_2D_ARRAY),x.isData3DTexture&&(se=n.TEXTURE_3D);const pe=Ve(b,x),ne=x.source;t.bindTexture(se,b.__webglTexture,n.TEXTURE0+Y);const De=i.get(ne);if(ne.version!==De.__version||pe===!0){t.activeTexture(n.TEXTURE0+Y);const Te=je.getPrimaries(je.workingColorSpace),Ue=x.colorSpace===Xn?null:je.getPrimaries(x.colorSpace),Ce=x.colorSpace===Xn||Te===Ue?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,x.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,x.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ce);let me=S(x.image,!1,s.maxTextureSize);me=ue(x,me);const _e=r.convert(x.format,x.colorSpace),ke=r.convert(x.type);let He=A(x.internalFormat,_e,ke,x.colorSpace,x.isVideoTexture);we(se,x);let Oe;const ze=x.mipmaps,B=x.isVideoTexture!==!0,ye=De.__version===void 0||pe===!0,Me=ne.dataReady,ve=C(x,me);if(x.isDepthTexture)He=R(x.format===Ms,x.type),ye&&(B?t.texStorage2D(n.TEXTURE_2D,1,He,me.width,me.height):t.texImage2D(n.TEXTURE_2D,0,He,me.width,me.height,0,_e,ke,null));else if(x.isDataTexture)if(ze.length>0){B&&ye&&t.texStorage2D(n.TEXTURE_2D,ve,He,ze[0].width,ze[0].height);for(let Se=0,fe=ze.length;Se<fe;Se++)Oe=ze[Se],B?Me&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,ke,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,He,Oe.width,Oe.height,0,_e,ke,Oe.data);x.generateMipmaps=!1}else B?(ye&&t.texStorage2D(n.TEXTURE_2D,ve,He,me.width,me.height),Me&&U(x,me,_e,ke)):t.texImage2D(n.TEXTURE_2D,0,He,me.width,me.height,0,_e,ke,me.data);else if(x.isCompressedTexture)if(x.isCompressedArrayTexture){B&&ye&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,He,ze[0].width,ze[0].height,me.depth);for(let Se=0,fe=ze.length;Se<fe;Se++)if(Oe=ze[Se],x.format!==ln)if(_e!==null)if(B){if(Me)if(x.layerUpdates.size>0){const Pe=Nl(Oe.width,Oe.height,x.format,x.type);for(const Xe of x.layerUpdates){const lt=Oe.data.subarray(Xe*Pe/Oe.data.BYTES_PER_ELEMENT,(Xe+1)*Pe/Oe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,Xe,Oe.width,Oe.height,1,_e,lt)}x.clearLayerUpdates()}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,me.depth,_e,Oe.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Se,He,Oe.width,Oe.height,me.depth,0,Oe.data,0,0);else Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else B?Me&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,Se,0,0,0,Oe.width,Oe.height,me.depth,_e,ke,Oe.data):t.texImage3D(n.TEXTURE_2D_ARRAY,Se,He,Oe.width,Oe.height,me.depth,0,_e,ke,Oe.data)}else{B&&ye&&t.texStorage2D(n.TEXTURE_2D,ve,He,ze[0].width,ze[0].height);for(let Se=0,fe=ze.length;Se<fe;Se++)Oe=ze[Se],x.format!==ln?_e!==null?B?Me&&t.compressedTexSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,Oe.data):t.compressedTexImage2D(n.TEXTURE_2D,Se,He,Oe.width,Oe.height,0,Oe.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):B?Me&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,Oe.width,Oe.height,_e,ke,Oe.data):t.texImage2D(n.TEXTURE_2D,Se,He,Oe.width,Oe.height,0,_e,ke,Oe.data)}else if(x.isDataArrayTexture)if(B){if(ye&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ve,He,me.width,me.height,me.depth),Me)if(x.layerUpdates.size>0){const Se=Nl(me.width,me.height,x.format,x.type);for(const fe of x.layerUpdates){const Pe=me.data.subarray(fe*Se/me.data.BYTES_PER_ELEMENT,(fe+1)*Se/me.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,fe,me.width,me.height,1,_e,ke,Pe)}x.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,me.width,me.height,me.depth,_e,ke,me.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,He,me.width,me.height,me.depth,0,_e,ke,me.data);else if(x.isData3DTexture)B?(ye&&t.texStorage3D(n.TEXTURE_3D,ve,He,me.width,me.height,me.depth),Me&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,me.width,me.height,me.depth,_e,ke,me.data)):t.texImage3D(n.TEXTURE_3D,0,He,me.width,me.height,me.depth,0,_e,ke,me.data);else if(x.isFramebufferTexture){if(ye)if(B)t.texStorage2D(n.TEXTURE_2D,ve,He,me.width,me.height);else{let Se=me.width,fe=me.height;for(let Pe=0;Pe<ve;Pe++)t.texImage2D(n.TEXTURE_2D,Pe,He,Se,fe,0,_e,ke,null),Se>>=1,fe>>=1}}else if(ze.length>0){if(B&&ye){const Se=Re(ze[0]);t.texStorage2D(n.TEXTURE_2D,ve,He,Se.width,Se.height)}for(let Se=0,fe=ze.length;Se<fe;Se++)Oe=ze[Se],B?Me&&t.texSubImage2D(n.TEXTURE_2D,Se,0,0,_e,ke,Oe):t.texImage2D(n.TEXTURE_2D,Se,He,_e,ke,Oe);x.generateMipmaps=!1}else if(B){if(ye){const Se=Re(me);t.texStorage2D(n.TEXTURE_2D,ve,He,Se.width,Se.height)}Me&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,_e,ke,me)}else t.texImage2D(n.TEXTURE_2D,0,He,_e,ke,me);E(x)&&f(se),De.__version=ne.version,x.onUpdate&&x.onUpdate(x)}b.__version=x.version}function g(b,x,Y){if(x.image.length!==6)return;const se=Ve(b,x),pe=x.source;t.bindTexture(n.TEXTURE_CUBE_MAP,b.__webglTexture,n.TEXTURE0+Y);const ne=i.get(pe);if(pe.version!==ne.__version||se===!0){t.activeTexture(n.TEXTURE0+Y);const De=je.getPrimaries(je.workingColorSpace),Te=x.colorSpace===Xn?null:je.getPrimaries(x.colorSpace),Ue=x.colorSpace===Xn||De===Te?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,x.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,x.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,x.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ue);const Ce=x.isCompressedTexture||x.image[0].isCompressedTexture,me=x.image[0]&&x.image[0].isDataTexture,_e=[];for(let fe=0;fe<6;fe++)!Ce&&!me?_e[fe]=S(x.image[fe],!0,s.maxCubemapSize):_e[fe]=me?x.image[fe].image:x.image[fe],_e[fe]=ue(x,_e[fe]);const ke=_e[0],He=r.convert(x.format,x.colorSpace),Oe=r.convert(x.type),ze=A(x.internalFormat,He,Oe,x.colorSpace),B=x.isVideoTexture!==!0,ye=ne.__version===void 0||se===!0,Me=pe.dataReady;let ve=C(x,ke);we(n.TEXTURE_CUBE_MAP,x);let Se;if(Ce){B&&ye&&t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,ze,ke.width,ke.height);for(let fe=0;fe<6;fe++){Se=_e[fe].mipmaps;for(let Pe=0;Pe<Se.length;Pe++){const Xe=Se[Pe];x.format!==ln?He!==null?B?Me&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe,0,0,Xe.width,Xe.height,He,Xe.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe,ze,Xe.width,Xe.height,0,Xe.data):Ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):B?Me&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe,0,0,Xe.width,Xe.height,He,Oe,Xe.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe,ze,Xe.width,Xe.height,0,He,Oe,Xe.data)}}}else{if(Se=x.mipmaps,B&&ye){Se.length>0&&ve++;const fe=Re(_e[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,ve,ze,fe.width,fe.height)}for(let fe=0;fe<6;fe++)if(me){B?Me&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,_e[fe].width,_e[fe].height,He,Oe,_e[fe].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,ze,_e[fe].width,_e[fe].height,0,He,Oe,_e[fe].data);for(let Pe=0;Pe<Se.length;Pe++){const lt=Se[Pe].image[fe].image;B?Me&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe+1,0,0,lt.width,lt.height,He,Oe,lt.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe+1,ze,lt.width,lt.height,0,He,Oe,lt.data)}}else{B?Me&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,He,Oe,_e[fe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,ze,He,Oe,_e[fe]);for(let Pe=0;Pe<Se.length;Pe++){const Xe=Se[Pe];B?Me&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe+1,0,0,He,Oe,Xe.image[fe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Pe+1,ze,He,Oe,Xe.image[fe])}}}E(x)&&f(n.TEXTURE_CUBE_MAP),ne.__version=pe.version,x.onUpdate&&x.onUpdate(x)}b.__version=x.version}function K(b,x,Y,se,pe,ne){const De=r.convert(Y.format,Y.colorSpace),Te=r.convert(Y.type),Ue=A(Y.internalFormat,De,Te,Y.colorSpace),Ce=i.get(x),me=i.get(Y);if(me.__renderTarget=x,!Ce.__hasExternalTextures){const _e=Math.max(1,x.width>>ne),ke=Math.max(1,x.height>>ne);pe===n.TEXTURE_3D||pe===n.TEXTURE_2D_ARRAY?t.texImage3D(pe,ne,Ue,_e,ke,x.depth,0,De,Te,null):t.texImage2D(pe,ne,Ue,_e,ke,0,De,Te,null)}t.bindFramebuffer(n.FRAMEBUFFER,b),O(x)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,se,pe,me.__webglTexture,0,P(x)):(pe===n.TEXTURE_2D||pe>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&pe<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,se,pe,me.__webglTexture,ne),t.bindFramebuffer(n.FRAMEBUFFER,null)}function oe(b,x,Y){if(n.bindRenderbuffer(n.RENDERBUFFER,b),x.depthBuffer){const se=x.depthTexture,pe=se&&se.isDepthTexture?se.type:null,ne=R(x.stencilBuffer,pe),De=x.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,Te=P(x);O(x)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Te,ne,x.width,x.height):Y?n.renderbufferStorageMultisample(n.RENDERBUFFER,Te,ne,x.width,x.height):n.renderbufferStorage(n.RENDERBUFFER,ne,x.width,x.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,De,n.RENDERBUFFER,b)}else{const se=x.textures;for(let pe=0;pe<se.length;pe++){const ne=se[pe],De=r.convert(ne.format,ne.colorSpace),Te=r.convert(ne.type),Ue=A(ne.internalFormat,De,Te,ne.colorSpace),Ce=P(x);Y&&O(x)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ce,Ue,x.width,x.height):O(x)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ce,Ue,x.width,x.height):n.renderbufferStorage(n.RENDERBUFFER,Ue,x.width,x.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function k(b,x){if(x&&x.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,b),!(x.depthTexture&&x.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const se=i.get(x.depthTexture);se.__renderTarget=x,(!se.__webglTexture||x.depthTexture.image.width!==x.width||x.depthTexture.image.height!==x.height)&&(x.depthTexture.image.width=x.width,x.depthTexture.image.height=x.height,x.depthTexture.needsUpdate=!0),Q(x.depthTexture,0);const pe=se.__webglTexture,ne=P(x);if(x.depthTexture.format===Rs)O(x)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,pe,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,pe,0);else if(x.depthTexture.format===Ms)O(x)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,pe,0,ne):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,pe,0);else throw new Error("Unknown depthTexture format")}function he(b){const x=i.get(b),Y=b.isWebGLCubeRenderTarget===!0;if(x.__boundDepthTexture!==b.depthTexture){const se=b.depthTexture;if(x.__depthDisposeCallback&&x.__depthDisposeCallback(),se){const pe=()=>{delete x.__boundDepthTexture,delete x.__depthDisposeCallback,se.removeEventListener("dispose",pe)};se.addEventListener("dispose",pe),x.__depthDisposeCallback=pe}x.__boundDepthTexture=se}if(b.depthTexture&&!x.__autoAllocateDepthBuffer){if(Y)throw new Error("target.depthTexture not supported in Cube render targets");const se=b.texture.mipmaps;se&&se.length>0?k(x.__webglFramebuffer[0],b):k(x.__webglFramebuffer,b)}else if(Y){x.__webglDepthbuffer=[];for(let se=0;se<6;se++)if(t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer[se]),x.__webglDepthbuffer[se]===void 0)x.__webglDepthbuffer[se]=n.createRenderbuffer(),oe(x.__webglDepthbuffer[se],b,!1);else{const pe=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer[se];n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,pe,n.RENDERBUFFER,ne)}}else{const se=b.texture.mipmaps;if(se&&se.length>0?t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer[0]):t.bindFramebuffer(n.FRAMEBUFFER,x.__webglFramebuffer),x.__webglDepthbuffer===void 0)x.__webglDepthbuffer=n.createRenderbuffer(),oe(x.__webglDepthbuffer,b,!1);else{const pe=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ne=x.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,ne),n.framebufferRenderbuffer(n.FRAMEBUFFER,pe,n.RENDERBUFFER,ne)}}t.bindFramebuffer(n.FRAMEBUFFER,null)}function Ae(b,x,Y){const se=i.get(b);x!==void 0&&K(se.__webglFramebuffer,b,b.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),Y!==void 0&&he(b)}function de(b){const x=b.texture,Y=i.get(b),se=i.get(x);b.addEventListener("dispose",D);const pe=b.textures,ne=b.isWebGLCubeRenderTarget===!0,De=pe.length>1;if(De||(se.__webglTexture===void 0&&(se.__webglTexture=n.createTexture()),se.__version=x.version,a.memory.textures++),ne){Y.__webglFramebuffer=[];for(let Te=0;Te<6;Te++)if(x.mipmaps&&x.mipmaps.length>0){Y.__webglFramebuffer[Te]=[];for(let Ue=0;Ue<x.mipmaps.length;Ue++)Y.__webglFramebuffer[Te][Ue]=n.createFramebuffer()}else Y.__webglFramebuffer[Te]=n.createFramebuffer()}else{if(x.mipmaps&&x.mipmaps.length>0){Y.__webglFramebuffer=[];for(let Te=0;Te<x.mipmaps.length;Te++)Y.__webglFramebuffer[Te]=n.createFramebuffer()}else Y.__webglFramebuffer=n.createFramebuffer();if(De)for(let Te=0,Ue=pe.length;Te<Ue;Te++){const Ce=i.get(pe[Te]);Ce.__webglTexture===void 0&&(Ce.__webglTexture=n.createTexture(),a.memory.textures++)}if(b.samples>0&&O(b)===!1){Y.__webglMultisampledFramebuffer=n.createFramebuffer(),Y.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,Y.__webglMultisampledFramebuffer);for(let Te=0;Te<pe.length;Te++){const Ue=pe[Te];Y.__webglColorRenderbuffer[Te]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,Y.__webglColorRenderbuffer[Te]);const Ce=r.convert(Ue.format,Ue.colorSpace),me=r.convert(Ue.type),_e=A(Ue.internalFormat,Ce,me,Ue.colorSpace,b.isXRRenderTarget===!0),ke=P(b);n.renderbufferStorageMultisample(n.RENDERBUFFER,ke,_e,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Te,n.RENDERBUFFER,Y.__webglColorRenderbuffer[Te])}n.bindRenderbuffer(n.RENDERBUFFER,null),b.depthBuffer&&(Y.__webglDepthRenderbuffer=n.createRenderbuffer(),oe(Y.__webglDepthRenderbuffer,b,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(ne){t.bindTexture(n.TEXTURE_CUBE_MAP,se.__webglTexture),we(n.TEXTURE_CUBE_MAP,x);for(let Te=0;Te<6;Te++)if(x.mipmaps&&x.mipmaps.length>0)for(let Ue=0;Ue<x.mipmaps.length;Ue++)K(Y.__webglFramebuffer[Te][Ue],b,x,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+Te,Ue);else K(Y.__webglFramebuffer[Te],b,x,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0);E(x)&&f(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(De){for(let Te=0,Ue=pe.length;Te<Ue;Te++){const Ce=pe[Te],me=i.get(Ce);let _e=n.TEXTURE_2D;(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(_e=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(_e,me.__webglTexture),we(_e,Ce),K(Y.__webglFramebuffer,b,Ce,n.COLOR_ATTACHMENT0+Te,_e,0),E(Ce)&&f(_e)}t.unbindTexture()}else{let Te=n.TEXTURE_2D;if((b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(Te=b.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(Te,se.__webglTexture),we(Te,x),x.mipmaps&&x.mipmaps.length>0)for(let Ue=0;Ue<x.mipmaps.length;Ue++)K(Y.__webglFramebuffer[Ue],b,x,n.COLOR_ATTACHMENT0,Te,Ue);else K(Y.__webglFramebuffer,b,x,n.COLOR_ATTACHMENT0,Te,0);E(x)&&f(Te),t.unbindTexture()}b.depthBuffer&&he(b)}function G(b){const x=b.textures;for(let Y=0,se=x.length;Y<se;Y++){const pe=x[Y];if(E(pe)){const ne=_(b),De=i.get(pe).__webglTexture;t.bindTexture(ne,De),f(ne),t.unbindTexture()}}}const T=[],q=[];function $(b){if(b.samples>0){if(O(b)===!1){const x=b.textures,Y=b.width,se=b.height;let pe=n.COLOR_BUFFER_BIT;const ne=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,De=i.get(b),Te=x.length>1;if(Te)for(let Ce=0;Ce<x.length;Ce++)t.bindFramebuffer(n.FRAMEBUFFER,De.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,De.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,De.__webglMultisampledFramebuffer);const Ue=b.texture.mipmaps;Ue&&Ue.length>0?t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglFramebuffer[0]):t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglFramebuffer);for(let Ce=0;Ce<x.length;Ce++){if(b.resolveDepthBuffer&&(b.depthBuffer&&(pe|=n.DEPTH_BUFFER_BIT),b.stencilBuffer&&b.resolveStencilBuffer&&(pe|=n.STENCIL_BUFFER_BIT)),Te){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,De.__webglColorRenderbuffer[Ce]);const me=i.get(x[Ce]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,me,0)}n.blitFramebuffer(0,0,Y,se,0,0,Y,se,pe,n.NEAREST),d===!0&&(T.length=0,q.length=0,T.push(n.COLOR_ATTACHMENT0+Ce),b.depthBuffer&&b.resolveDepthBuffer===!1&&(T.push(ne),q.push(ne),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,q)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,T))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),Te)for(let Ce=0;Ce<x.length;Ce++){t.bindFramebuffer(n.FRAMEBUFFER,De.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.RENDERBUFFER,De.__webglColorRenderbuffer[Ce]);const me=i.get(x[Ce]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,De.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ce,n.TEXTURE_2D,me,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,De.__webglMultisampledFramebuffer)}else if(b.depthBuffer&&b.resolveDepthBuffer===!1&&d){const x=b.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[x])}}}function P(b){return Math.min(s.maxSamples,b.samples)}function O(b){const x=i.get(b);return b.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&x.__useRenderToTexture!==!1}function ae(b){const x=a.render.frame;p.get(b)!==x&&(p.set(b,x),b.update())}function ue(b,x){const Y=b.colorSpace,se=b.format,pe=b.type;return b.isCompressedTexture===!0||b.isVideoTexture===!0||Y!==Zi&&Y!==Xn&&(je.getTransfer(Y)===it?(se!==ln||pe!==Un)&&Ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):dt("WebGLTextures: Unsupported texture color space:",Y)),x}function Re(b){return typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement?(u.width=b.naturalWidth||b.width,u.height=b.naturalHeight||b.height):typeof VideoFrame<"u"&&b instanceof VideoFrame?(u.width=b.displayWidth,u.height=b.displayHeight):(u.width=b.width,u.height=b.height),u}this.allocateTextureUnit=Z,this.resetTextureUnits=V,this.setTexture2D=Q,this.setTexture2DArray=ie,this.setTexture3D=j,this.setTextureCube=H,this.rebindTextures=Ae,this.setupRenderTarget=de,this.updateRenderTargetMipmap=G,this.updateMultisampleRenderTarget=$,this.setupDepthRenderbuffer=he,this.setupFrameBufferTexture=K,this.useMultisampledRTT=O}function CS(n,e){function t(i,s=Xn){let r;const a=je.getTransfer(s);if(i===Un)return n.UNSIGNED_BYTE;if(i===va)return n.UNSIGNED_SHORT_4_4_4_4;if(i===Ia)return n.UNSIGNED_SHORT_5_5_5_1;if(i===bc)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===Cc)return n.UNSIGNED_INT_10F_11F_11F_REV;if(i===Lc)return n.BYTE;if(i===Oc)return n.SHORT;if(i===gs)return n.UNSIGNED_SHORT;if(i===Ma)return n.INT;if(i===Si)return n.UNSIGNED_INT;if(i===Dn)return n.FLOAT;if(i===ji)return n.HALF_FLOAT;if(i===Dc)return n.ALPHA;if(i===Pc)return n.RGB;if(i===ln)return n.RGBA;if(i===Rs)return n.DEPTH_COMPONENT;if(i===Ms)return n.DEPTH_STENCIL;if(i===Nc)return n.RED;if(i===ya)return n.RED_INTEGER;if(i===La)return n.RG;if(i===Oa)return n.RG_INTEGER;if(i===ba)return n.RGBA_INTEGER;if(i===cr||i===ur||i===hr||i===dr)if(a===it)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===cr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===ur)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===hr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===dr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===cr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===ur)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===hr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===dr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===Ho||i===Go||i===Vo||i===ko)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===Ho)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Go)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Vo)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===ko)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===Yo||i===Wo||i===zo)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(i===Yo||i===Wo)return a===it?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===zo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===Ko||i===Xo||i===qo||i===Zo||i===Jo||i===Qo||i===$o||i===jo||i===ea||i===ta||i===na||i===ia||i===sa||i===ra)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(i===Ko)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Xo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===qo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Zo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===Jo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===Qo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===$o)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===jo)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===ea)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===ta)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===na)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===ia)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===sa)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===ra)return a===it?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===oa||i===aa||i===la)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(i===oa)return a===it?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===aa)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===la)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===ca||i===ua||i===ha||i===da)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(i===ca)return r.COMPRESSED_RED_RGTC1_EXT;if(i===ua)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===ha)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===da)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===Ts?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}const DS=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,PS=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class NS{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const i=new Kc(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,i=new Bn({vertexShader:DS,fragmentShader:PS,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new At(new ei(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class US extends xi{constructor(e,t){super();const i=this;let s=null,r=1,a=null,l="local-floor",d=1,u=null,p=null,o=null,c=null,h=null,m=null;const S=typeof XRWebGLBinding<"u",E=new NS,f={},_=t.getContextAttributes();let A=null,R=null;const C=[],L=[],D=new le;let F=null;const I=new zt;I.viewport=new St;const M=new zt;M.viewport=new St;const N=[I,M],V=new Qd;let Z=null,J=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(v){let g=C[v];return g===void 0&&(g=new ro,C[v]=g),g.getTargetRaySpace()},this.getControllerGrip=function(v){let g=C[v];return g===void 0&&(g=new ro,C[v]=g),g.getGripSpace()},this.getHand=function(v){let g=C[v];return g===void 0&&(g=new ro,C[v]=g),g.getHandSpace()};function Q(v){const g=L.indexOf(v.inputSource);if(g===-1)return;const K=C[g];K!==void 0&&(K.update(v.inputSource,v.frame,u||a),K.dispatchEvent({type:v.type,data:v.inputSource}))}function ie(){s.removeEventListener("select",Q),s.removeEventListener("selectstart",Q),s.removeEventListener("selectend",Q),s.removeEventListener("squeeze",Q),s.removeEventListener("squeezestart",Q),s.removeEventListener("squeezeend",Q),s.removeEventListener("end",ie),s.removeEventListener("inputsourceschange",j);for(let v=0;v<C.length;v++){const g=L[v];g!==null&&(L[v]=null,C[v].disconnect(g))}Z=null,J=null,E.reset();for(const v in f)delete f[v];e.setRenderTarget(A),h=null,c=null,o=null,s=null,R=null,U.stop(),i.isPresenting=!1,e.setPixelRatio(F),e.setSize(D.width,D.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(v){r=v,i.isPresenting===!0&&Ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(v){l=v,i.isPresenting===!0&&Ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return u||a},this.setReferenceSpace=function(v){u=v},this.getBaseLayer=function(){return c!==null?c:h},this.getBinding=function(){return o===null&&S&&(o=new XRWebGLBinding(s,t)),o},this.getFrame=function(){return m},this.getSession=function(){return s},this.setSession=async function(v){if(s=v,s!==null){if(A=e.getRenderTarget(),s.addEventListener("select",Q),s.addEventListener("selectstart",Q),s.addEventListener("selectend",Q),s.addEventListener("squeeze",Q),s.addEventListener("squeezestart",Q),s.addEventListener("squeezeend",Q),s.addEventListener("end",ie),s.addEventListener("inputsourceschange",j),_.xrCompatible!==!0&&await t.makeXRCompatible(),F=e.getPixelRatio(),e.getSize(D),S&&"createProjectionLayer"in XRWebGLBinding.prototype){let K=null,oe=null,k=null;_.depth&&(k=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,K=_.stencil?Ms:Rs,oe=_.stencil?Ts:Si);const he={colorFormat:t.RGBA8,depthFormat:k,scaleFactor:r};o=this.getBinding(),c=o.createProjectionLayer(he),s.updateRenderState({layers:[c]}),e.setPixelRatio(1),e.setSize(c.textureWidth,c.textureHeight,!1),R=new wn(c.textureWidth,c.textureHeight,{format:ln,type:Un,depthTexture:new zc(c.textureWidth,c.textureHeight,oe,void 0,void 0,void 0,void 0,void 0,void 0,K),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:c.ignoreDepthValues===!1,resolveStencilBuffer:c.ignoreDepthValues===!1})}else{const K={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:r};h=new XRWebGLLayer(s,t,K),s.updateRenderState({baseLayer:h}),e.setPixelRatio(1),e.setSize(h.framebufferWidth,h.framebufferHeight,!1),R=new wn(h.framebufferWidth,h.framebufferHeight,{format:ln,type:Un,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}R.isXRRenderTarget=!0,this.setFoveation(d),u=null,a=await s.requestReferenceSpace(l),U.setContext(s),U.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return E.getDepthTexture()};function j(v){for(let g=0;g<v.removed.length;g++){const K=v.removed[g],oe=L.indexOf(K);oe>=0&&(L[oe]=null,C[oe].disconnect(K))}for(let g=0;g<v.added.length;g++){const K=v.added[g];let oe=L.indexOf(K);if(oe===-1){for(let he=0;he<C.length;he++)if(he>=L.length){L.push(K),oe=he;break}else if(L[he]===null){L[he]=K,oe=he;break}if(oe===-1)break}const k=C[oe];k&&k.connect(K)}}const H=new w,Ee=new w;function re(v,g,K){H.setFromMatrixPosition(g.matrixWorld),Ee.setFromMatrixPosition(K.matrixWorld);const oe=H.distanceTo(Ee),k=g.projectionMatrix.elements,he=K.projectionMatrix.elements,Ae=k[14]/(k[10]-1),de=k[14]/(k[10]+1),G=(k[9]+1)/k[5],T=(k[9]-1)/k[5],q=(k[8]-1)/k[0],$=(he[8]+1)/he[0],P=Ae*q,O=Ae*$,ae=oe/(-q+$),ue=ae*-q;if(g.matrixWorld.decompose(v.position,v.quaternion,v.scale),v.translateX(ue),v.translateZ(ae),v.matrixWorld.compose(v.position,v.quaternion,v.scale),v.matrixWorldInverse.copy(v.matrixWorld).invert(),k[10]===-1)v.projectionMatrix.copy(g.projectionMatrix),v.projectionMatrixInverse.copy(g.projectionMatrixInverse);else{const Re=Ae+ae,b=de+ae,x=P-ue,Y=O+(oe-ue),se=G*de/b*Re,pe=T*de/b*Re;v.projectionMatrix.makePerspective(x,Y,se,pe,Re,b),v.projectionMatrixInverse.copy(v.projectionMatrix).invert()}}function ge(v,g){g===null?v.matrixWorld.copy(v.matrix):v.matrixWorld.multiplyMatrices(g.matrixWorld,v.matrix),v.matrixWorldInverse.copy(v.matrixWorld).invert()}this.updateCamera=function(v){if(s===null)return;let g=v.near,K=v.far;E.texture!==null&&(E.depthNear>0&&(g=E.depthNear),E.depthFar>0&&(K=E.depthFar)),V.near=M.near=I.near=g,V.far=M.far=I.far=K,(Z!==V.near||J!==V.far)&&(s.updateRenderState({depthNear:V.near,depthFar:V.far}),Z=V.near,J=V.far),V.layers.mask=v.layers.mask|6,I.layers.mask=V.layers.mask&3,M.layers.mask=V.layers.mask&5;const oe=v.parent,k=V.cameras;ge(V,oe);for(let he=0;he<k.length;he++)ge(k[he],oe);k.length===2?re(V,I,M):V.projectionMatrix.copy(I.projectionMatrix),we(v,V,oe)};function we(v,g,K){K===null?v.matrix.copy(g.matrixWorld):(v.matrix.copy(K.matrixWorld),v.matrix.invert(),v.matrix.multiply(g.matrixWorld)),v.matrix.decompose(v.position,v.quaternion,v.scale),v.updateMatrixWorld(!0),v.projectionMatrix.copy(g.projectionMatrix),v.projectionMatrixInverse.copy(g.projectionMatrixInverse),v.isPerspectiveCamera&&(v.fov=fa*2*Math.atan(1/v.projectionMatrix.elements[5]),v.zoom=1)}this.getCamera=function(){return V},this.getFoveation=function(){if(!(c===null&&h===null))return d},this.setFoveation=function(v){d=v,c!==null&&(c.fixedFoveation=v),h!==null&&h.fixedFoveation!==void 0&&(h.fixedFoveation=v)},this.hasDepthSensing=function(){return E.texture!==null},this.getDepthSensingMesh=function(){return E.getMesh(V)},this.getCameraTexture=function(v){return f[v]};let Ve=null;function z(v,g){if(p=g.getViewerPose(u||a),m=g,p!==null){const K=p.views;h!==null&&(e.setRenderTargetFramebuffer(R,h.framebuffer),e.setRenderTarget(R));let oe=!1;K.length!==V.cameras.length&&(V.cameras.length=0,oe=!0);for(let de=0;de<K.length;de++){const G=K[de];let T=null;if(h!==null)T=h.getViewport(G);else{const $=o.getViewSubImage(c,G);T=$.viewport,de===0&&(e.setRenderTargetTextures(R,$.colorTexture,$.depthStencilTexture),e.setRenderTarget(R))}let q=N[de];q===void 0&&(q=new zt,q.layers.enable(de),q.viewport=new St,N[de]=q),q.matrix.fromArray(G.transform.matrix),q.matrix.decompose(q.position,q.quaternion,q.scale),q.projectionMatrix.fromArray(G.projectionMatrix),q.projectionMatrixInverse.copy(q.projectionMatrix).invert(),q.viewport.set(T.x,T.y,T.width,T.height),de===0&&(V.matrix.copy(q.matrix),V.matrix.decompose(V.position,V.quaternion,V.scale)),oe===!0&&V.cameras.push(q)}const k=s.enabledFeatures;if(k&&k.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&S){o=i.getBinding();const de=o.getDepthInformation(K[0]);de&&de.isValid&&de.texture&&E.init(de,s.renderState)}if(k&&k.includes("camera-access")&&S){e.state.unbindTexture(),o=i.getBinding();for(let de=0;de<K.length;de++){const G=K[de].camera;if(G){let T=f[G];T||(T=new Kc,f[G]=T);const q=o.getCameraImage(G);T.sourceTexture=q}}}}for(let K=0;K<C.length;K++){const oe=L[K],k=C[K];oe!==null&&k!==void 0&&k.update(oe,g,u||a)}Ve&&Ve(v,g),g.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:g}),m=null}const U=new tu;U.setAnimationLoop(z),this.setAnimationLoop=function(v){Ve=v},this.dispose=function(){}}}const ci=new Fn,wS=new _t;function FS(n,e){function t(E,f){E.matrixAutoUpdate===!0&&E.updateMatrix(),f.value.copy(E.matrix)}function i(E,f){f.color.getRGB(E.fogColor.value,Vc(n)),f.isFog?(E.fogNear.value=f.near,E.fogFar.value=f.far):f.isFogExp2&&(E.fogDensity.value=f.density)}function s(E,f,_,A,R){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(E,f):f.isMeshToonMaterial?(r(E,f),o(E,f)):f.isMeshPhongMaterial?(r(E,f),p(E,f)):f.isMeshStandardMaterial?(r(E,f),c(E,f),f.isMeshPhysicalMaterial&&h(E,f,R)):f.isMeshMatcapMaterial?(r(E,f),m(E,f)):f.isMeshDepthMaterial?r(E,f):f.isMeshDistanceMaterial?(r(E,f),S(E,f)):f.isMeshNormalMaterial?r(E,f):f.isLineBasicMaterial?(a(E,f),f.isLineDashedMaterial&&l(E,f)):f.isPointsMaterial?d(E,f,_,A):f.isSpriteMaterial?u(E,f):f.isShadowMaterial?(E.color.value.copy(f.color),E.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(E,f){E.opacity.value=f.opacity,f.color&&E.diffuse.value.copy(f.color),f.emissive&&E.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(E.map.value=f.map,t(f.map,E.mapTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.bumpMap&&(E.bumpMap.value=f.bumpMap,t(f.bumpMap,E.bumpMapTransform),E.bumpScale.value=f.bumpScale,f.side===Ot&&(E.bumpScale.value*=-1)),f.normalMap&&(E.normalMap.value=f.normalMap,t(f.normalMap,E.normalMapTransform),E.normalScale.value.copy(f.normalScale),f.side===Ot&&E.normalScale.value.negate()),f.displacementMap&&(E.displacementMap.value=f.displacementMap,t(f.displacementMap,E.displacementMapTransform),E.displacementScale.value=f.displacementScale,E.displacementBias.value=f.displacementBias),f.emissiveMap&&(E.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,E.emissiveMapTransform)),f.specularMap&&(E.specularMap.value=f.specularMap,t(f.specularMap,E.specularMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest);const _=e.get(f),A=_.envMap,R=_.envMapRotation;A&&(E.envMap.value=A,ci.copy(R),ci.x*=-1,ci.y*=-1,ci.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(ci.y*=-1,ci.z*=-1),E.envMapRotation.value.setFromMatrix4(wS.makeRotationFromEuler(ci)),E.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,E.reflectivity.value=f.reflectivity,E.ior.value=f.ior,E.refractionRatio.value=f.refractionRatio),f.lightMap&&(E.lightMap.value=f.lightMap,E.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,E.lightMapTransform)),f.aoMap&&(E.aoMap.value=f.aoMap,E.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,E.aoMapTransform))}function a(E,f){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,f.map&&(E.map.value=f.map,t(f.map,E.mapTransform))}function l(E,f){E.dashSize.value=f.dashSize,E.totalSize.value=f.dashSize+f.gapSize,E.scale.value=f.scale}function d(E,f,_,A){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,E.size.value=f.size*_,E.scale.value=A*.5,f.map&&(E.map.value=f.map,t(f.map,E.uvTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest)}function u(E,f){E.diffuse.value.copy(f.color),E.opacity.value=f.opacity,E.rotation.value=f.rotation,f.map&&(E.map.value=f.map,t(f.map,E.mapTransform)),f.alphaMap&&(E.alphaMap.value=f.alphaMap,t(f.alphaMap,E.alphaMapTransform)),f.alphaTest>0&&(E.alphaTest.value=f.alphaTest)}function p(E,f){E.specular.value.copy(f.specular),E.shininess.value=Math.max(f.shininess,1e-4)}function o(E,f){f.gradientMap&&(E.gradientMap.value=f.gradientMap)}function c(E,f){E.metalness.value=f.metalness,f.metalnessMap&&(E.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,E.metalnessMapTransform)),E.roughness.value=f.roughness,f.roughnessMap&&(E.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,E.roughnessMapTransform)),f.envMap&&(E.envMapIntensity.value=f.envMapIntensity)}function h(E,f,_){E.ior.value=f.ior,f.sheen>0&&(E.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),E.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(E.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,E.sheenColorMapTransform)),f.sheenRoughnessMap&&(E.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,E.sheenRoughnessMapTransform))),f.clearcoat>0&&(E.clearcoat.value=f.clearcoat,E.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(E.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,E.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(E.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,E.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(E.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,E.clearcoatNormalMapTransform),E.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Ot&&E.clearcoatNormalScale.value.negate())),f.dispersion>0&&(E.dispersion.value=f.dispersion),f.iridescence>0&&(E.iridescence.value=f.iridescence,E.iridescenceIOR.value=f.iridescenceIOR,E.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],E.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(E.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,E.iridescenceMapTransform)),f.iridescenceThicknessMap&&(E.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,E.iridescenceThicknessMapTransform))),f.transmission>0&&(E.transmission.value=f.transmission,E.transmissionSamplerMap.value=_.texture,E.transmissionSamplerSize.value.set(_.width,_.height),f.transmissionMap&&(E.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,E.transmissionMapTransform)),E.thickness.value=f.thickness,f.thicknessMap&&(E.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,E.thicknessMapTransform)),E.attenuationDistance.value=f.attenuationDistance,E.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(E.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(E.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,E.anisotropyMapTransform))),E.specularIntensity.value=f.specularIntensity,E.specularColor.value.copy(f.specularColor),f.specularColorMap&&(E.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,E.specularColorMapTransform)),f.specularIntensityMap&&(E.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,E.specularIntensityMapTransform))}function m(E,f){f.matcap&&(E.matcap.value=f.matcap)}function S(E,f){const _=e.get(f).light;E.referencePosition.value.setFromMatrixPosition(_.matrixWorld),E.nearDistance.value=_.shadow.camera.near,E.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function BS(n,e,t,i){let s={},r={},a=[];const l=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function d(_,A){const R=A.program;i.uniformBlockBinding(_,R)}function u(_,A){let R=s[_.id];R===void 0&&(m(_),R=p(_),s[_.id]=R,_.addEventListener("dispose",E));const C=A.program;i.updateUBOMapping(_,C);const L=e.render.frame;r[_.id]!==L&&(c(_),r[_.id]=L)}function p(_){const A=o();_.__bindingPointIndex=A;const R=n.createBuffer(),C=_.__size,L=_.usage;return n.bindBuffer(n.UNIFORM_BUFFER,R),n.bufferData(n.UNIFORM_BUFFER,C,L),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,A,R),R}function o(){for(let _=0;_<l;_++)if(a.indexOf(_)===-1)return a.push(_),_;return dt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function c(_){const A=s[_.id],R=_.uniforms,C=_.__cache;n.bindBuffer(n.UNIFORM_BUFFER,A);for(let L=0,D=R.length;L<D;L++){const F=Array.isArray(R[L])?R[L]:[R[L]];for(let I=0,M=F.length;I<M;I++){const N=F[I];if(h(N,L,I,C)===!0){const V=N.__offset,Z=Array.isArray(N.value)?N.value:[N.value];let J=0;for(let Q=0;Q<Z.length;Q++){const ie=Z[Q],j=S(ie);typeof ie=="number"||typeof ie=="boolean"?(N.__data[0]=ie,n.bufferSubData(n.UNIFORM_BUFFER,V+J,N.__data)):ie.isMatrix3?(N.__data[0]=ie.elements[0],N.__data[1]=ie.elements[1],N.__data[2]=ie.elements[2],N.__data[3]=0,N.__data[4]=ie.elements[3],N.__data[5]=ie.elements[4],N.__data[6]=ie.elements[5],N.__data[7]=0,N.__data[8]=ie.elements[6],N.__data[9]=ie.elements[7],N.__data[10]=ie.elements[8],N.__data[11]=0):(ie.toArray(N.__data,J),J+=j.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,V,N.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function h(_,A,R,C){const L=_.value,D=A+"_"+R;if(C[D]===void 0)return typeof L=="number"||typeof L=="boolean"?C[D]=L:C[D]=L.clone(),!0;{const F=C[D];if(typeof L=="number"||typeof L=="boolean"){if(F!==L)return C[D]=L,!0}else if(F.equals(L)===!1)return F.copy(L),!0}return!1}function m(_){const A=_.uniforms;let R=0;const C=16;for(let D=0,F=A.length;D<F;D++){const I=Array.isArray(A[D])?A[D]:[A[D]];for(let M=0,N=I.length;M<N;M++){const V=I[M],Z=Array.isArray(V.value)?V.value:[V.value];for(let J=0,Q=Z.length;J<Q;J++){const ie=Z[J],j=S(ie),H=R%C,Ee=H%j.boundary,re=H+Ee;R+=Ee,re!==0&&C-re<j.storage&&(R+=C-re),V.__data=new Float32Array(j.storage/Float32Array.BYTES_PER_ELEMENT),V.__offset=R,R+=j.storage}}}const L=R%C;return L>0&&(R+=C-L),_.__size=R,_.__cache={},this}function S(_){const A={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(A.boundary=4,A.storage=4):_.isVector2?(A.boundary=8,A.storage=8):_.isVector3||_.isColor?(A.boundary=16,A.storage=12):_.isVector4?(A.boundary=16,A.storage=16):_.isMatrix3?(A.boundary=48,A.storage=48):_.isMatrix4?(A.boundary=64,A.storage=64):_.isTexture?Ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Ke("WebGLRenderer: Unsupported uniform value type.",_),A}function E(_){const A=_.target;A.removeEventListener("dispose",E);const R=a.indexOf(A.__bindingPointIndex);a.splice(R,1),n.deleteBuffer(s[A.id]),delete s[A.id],delete r[A.id]}function f(){for(const _ in s)n.deleteBuffer(s[_]);a=[],s={},r={}}return{bind:d,update:u,dispose:f}}const HS=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let In=null;function GS(){return In===null&&(In=new od(HS,32,32,La,ji),In.minFilter=$t,In.magFilter=$t,In.wrapS=Cn,In.wrapT=Cn,In.generateMipmaps=!1,In.needsUpdate=!0),In}class VS{constructor(e={}){const{canvas:t=Ch(),context:i=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:l=!1,premultipliedAlpha:d=!0,preserveDrawingBuffer:u=!1,powerPreference:p="default",failIfMajorPerformanceCaveat:o=!1,reversedDepthBuffer:c=!1}=e;this.isWebGLRenderer=!0;let h;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");h=i.getContextAttributes().alpha}else h=a;const m=new Set([ba,Oa,ya]),S=new Set([Un,Si,gs,Ts,va,Ia]),E=new Uint32Array(4),f=new Int32Array(4);let _=null,A=null;const R=[],C=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Zn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const L=this;let D=!1;this._outputColorSpace=Nt;let F=0,I=0,M=null,N=-1,V=null;const Z=new St,J=new St;let Q=null;const ie=new Qe(0);let j=0,H=t.width,Ee=t.height,re=1,ge=null,we=null;const Ve=new St(0,0,H,Ee),z=new St(0,0,H,Ee);let U=!1;const v=new Wc;let g=!1,K=!1;const oe=new _t,k=new w,he=new St,Ae={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let de=!1;function G(){return M===null?re:1}let T=i;function q(y,W){return t.getContext(y,W)}try{const y={alpha:!0,depth:s,stencil:r,antialias:l,premultipliedAlpha:d,preserveDrawingBuffer:u,powerPreference:p,failIfMajorPerformanceCaveat:o};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ra}`),t.addEventListener("webglcontextlost",Se,!1),t.addEventListener("webglcontextrestored",fe,!1),t.addEventListener("webglcontextcreationerror",Pe,!1),T===null){const W="webgl2";if(T=q(W,y),T===null)throw q(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(y){throw y("WebGLRenderer: "+y.message),y}let $,P,O,ae,ue,Re,b,x,Y,se,pe,ne,De,Te,Ue,Ce,me,_e,ke,He,Oe,ze,B,ye;function Me(){$=new ZE(T),$.init(),ze=new CS(T,$),P=new GE(T,$,e,ze),O=new OS(T,$),P.reversedDepthBuffer&&c&&O.buffers.depth.setReversed(!0),ae=new $E(T),ue=new mS,Re=new bS(T,$,O,ue,P,ze,ae),b=new kE(L),x=new qE(L),Y=new tf(T),B=new BE(T,Y),se=new JE(T,Y,ae,B),pe=new em(T,se,Y,ae),ke=new jE(T,P,Re),Ce=new VE(ue),ne=new ES(L,b,x,$,P,B,Ce),De=new FS(L,ue),Te=new AS,Ue=new MS($),_e=new FE(L,b,x,O,pe,h,d),me=new yS(L,pe,P),ye=new BS(T,ae,P,O),He=new HE(T,$,ae),Oe=new QE(T,$,ae),ae.programs=ne.programs,L.capabilities=P,L.extensions=$,L.properties=ue,L.renderLists=Te,L.shadowMap=me,L.state=O,L.info=ae}Me();const ve=new US(L,T);this.xr=ve,this.getContext=function(){return T},this.getContextAttributes=function(){return T.getContextAttributes()},this.forceContextLoss=function(){const y=$.get("WEBGL_lose_context");y&&y.loseContext()},this.forceContextRestore=function(){const y=$.get("WEBGL_lose_context");y&&y.restoreContext()},this.getPixelRatio=function(){return re},this.setPixelRatio=function(y){y!==void 0&&(re=y,this.setSize(H,Ee,!1))},this.getSize=function(y){return y.set(H,Ee)},this.setSize=function(y,W,ee=!0){if(ve.isPresenting){Ke("WebGLRenderer: Can't change size while VR device is presenting.");return}H=y,Ee=W,t.width=Math.floor(y*re),t.height=Math.floor(W*re),ee===!0&&(t.style.width=y+"px",t.style.height=W+"px"),this.setViewport(0,0,y,W)},this.getDrawingBufferSize=function(y){return y.set(H*re,Ee*re).floor()},this.setDrawingBufferSize=function(y,W,ee){H=y,Ee=W,re=ee,t.width=Math.floor(y*ee),t.height=Math.floor(W*ee),this.setViewport(0,0,y,W)},this.getCurrentViewport=function(y){return y.copy(Z)},this.getViewport=function(y){return y.copy(Ve)},this.setViewport=function(y,W,ee,te){y.isVector4?Ve.set(y.x,y.y,y.z,y.w):Ve.set(y,W,ee,te),O.viewport(Z.copy(Ve).multiplyScalar(re).round())},this.getScissor=function(y){return y.copy(z)},this.setScissor=function(y,W,ee,te){y.isVector4?z.set(y.x,y.y,y.z,y.w):z.set(y,W,ee,te),O.scissor(J.copy(z).multiplyScalar(re).round())},this.getScissorTest=function(){return U},this.setScissorTest=function(y){O.setScissorTest(U=y)},this.setOpaqueSort=function(y){ge=y},this.setTransparentSort=function(y){we=y},this.getClearColor=function(y){return y.copy(_e.getClearColor())},this.setClearColor=function(){_e.setClearColor(...arguments)},this.getClearAlpha=function(){return _e.getClearAlpha()},this.setClearAlpha=function(){_e.setClearAlpha(...arguments)},this.clear=function(y=!0,W=!0,ee=!0){let te=0;if(y){let X=!1;if(M!==null){const xe=M.texture.format;X=m.has(xe)}if(X){const xe=M.texture.type,Le=S.has(xe),Ne=_e.getClearColor(),be=_e.getClearAlpha(),Ge=Ne.r,Ye=Ne.g,Fe=Ne.b;Le?(E[0]=Ge,E[1]=Ye,E[2]=Fe,E[3]=be,T.clearBufferuiv(T.COLOR,0,E)):(f[0]=Ge,f[1]=Ye,f[2]=Fe,f[3]=be,T.clearBufferiv(T.COLOR,0,f))}else te|=T.COLOR_BUFFER_BIT}W&&(te|=T.DEPTH_BUFFER_BIT),ee&&(te|=T.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),T.clear(te)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Se,!1),t.removeEventListener("webglcontextrestored",fe,!1),t.removeEventListener("webglcontextcreationerror",Pe,!1),_e.dispose(),Te.dispose(),Ue.dispose(),ue.dispose(),b.dispose(),x.dispose(),pe.dispose(),B.dispose(),ye.dispose(),ne.dispose(),ve.dispose(),ve.removeEventListener("sessionstart",Xa),ve.removeEventListener("sessionend",qa),ti.stop()};function Se(y){y.preventDefault(),ll("WebGLRenderer: Context Lost."),D=!0}function fe(){ll("WebGLRenderer: Context Restored."),D=!1;const y=ae.autoReset,W=me.enabled,ee=me.autoUpdate,te=me.needsUpdate,X=me.type;Me(),ae.autoReset=y,me.enabled=W,me.autoUpdate=ee,me.needsUpdate=te,me.type=X}function Pe(y){dt("WebGLRenderer: A WebGL context could not be created. Reason: ",y.statusMessage)}function Xe(y){const W=y.target;W.removeEventListener("dispose",Xe),lt(W)}function lt(y){et(y),ue.remove(y)}function et(y){const W=ue.get(y).programs;W!==void 0&&(W.forEach(function(ee){ne.releaseProgram(ee)}),y.isShaderMaterial&&ne.releaseShaderCache(y))}this.renderBufferDirect=function(y,W,ee,te,X,xe){W===null&&(W=Ae);const Le=X.isMesh&&X.matrixWorld.determinant()<0,Ne=Pu(y,W,ee,te,X);O.setMaterial(te,Le);let be=ee.index,Ge=1;if(te.wireframe===!0){if(be=se.getWireframeAttribute(ee),be===void 0)return;Ge=2}const Ye=ee.drawRange,Fe=ee.attributes.position;let Je=Ye.start*Ge,tt=(Ye.start+Ye.count)*Ge;xe!==null&&(Je=Math.max(Je,xe.start*Ge),tt=Math.min(tt,(xe.start+xe.count)*Ge)),be!==null?(Je=Math.max(Je,0),tt=Math.min(tt,be.count)):Fe!=null&&(Je=Math.max(Je,0),tt=Math.min(tt,Fe.count));const pt=tt-Je;if(pt<0||pt===1/0)return;B.setup(X,te,Ne,ee,be);let Et,ot=He;if(be!==null&&(Et=Y.get(be),ot=Oe,ot.setIndex(Et)),X.isMesh)te.wireframe===!0?(O.setLineWidth(te.wireframeLinewidth*G()),ot.setMode(T.LINES)):ot.setMode(T.TRIANGLES);else if(X.isLine){let Be=te.linewidth;Be===void 0&&(Be=1),O.setLineWidth(Be*G()),X.isLineSegments?ot.setMode(T.LINES):X.isLineLoop?ot.setMode(T.LINE_LOOP):ot.setMode(T.LINE_STRIP)}else X.isPoints?ot.setMode(T.POINTS):X.isSprite&&ot.setMode(T.TRIANGLES);if(X.isBatchedMesh)if(X._multiDrawInstances!==null)vs("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),ot.renderMultiDrawInstances(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount,X._multiDrawInstances);else if($.get("WEBGL_multi_draw"))ot.renderMultiDraw(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount);else{const Be=X._multiDrawStarts,ct=X._multiDrawCounts,$e=X._multiDrawCount,Gt=be?Y.get(be).bytesPerElement:1,Ti=ue.get(te).currentProgram.getUniforms();for(let Vt=0;Vt<$e;Vt++)Ti.setValue(T,"_gl_DrawID",Vt),ot.render(Be[Vt]/Gt,ct[Vt])}else if(X.isInstancedMesh)ot.renderInstances(Je,pt,X.count);else if(ee.isInstancedBufferGeometry){const Be=ee._maxInstanceCount!==void 0?ee._maxInstanceCount:1/0,ct=Math.min(ee.instanceCount,Be);ot.renderInstances(Je,pt,ct)}else ot.render(Je,pt)};function hn(y,W,ee){y.transparent===!0&&y.side===on&&y.forceSinglePass===!1?(y.side=Ot,y.needsUpdate=!0,Us(y,W,ee),y.side=mn,y.needsUpdate=!0,Us(y,W,ee),y.side=on):Us(y,W,ee)}this.compile=function(y,W,ee=null){ee===null&&(ee=y),A=Ue.get(ee),A.init(W),C.push(A),ee.traverseVisible(function(X){X.isLight&&X.layers.test(W.layers)&&(A.pushLight(X),X.castShadow&&A.pushShadow(X))}),y!==ee&&y.traverseVisible(function(X){X.isLight&&X.layers.test(W.layers)&&(A.pushLight(X),X.castShadow&&A.pushShadow(X))}),A.setupLights();const te=new Set;return y.traverse(function(X){if(!(X.isMesh||X.isPoints||X.isLine||X.isSprite))return;const xe=X.material;if(xe)if(Array.isArray(xe))for(let Le=0;Le<xe.length;Le++){const Ne=xe[Le];hn(Ne,ee,X),te.add(Ne)}else hn(xe,ee,X),te.add(xe)}),A=C.pop(),te},this.compileAsync=function(y,W,ee=null){const te=this.compile(y,W,ee);return new Promise(X=>{function xe(){if(te.forEach(function(Le){ue.get(Le).currentProgram.isReady()&&te.delete(Le)}),te.size===0){X(y);return}setTimeout(xe,10)}$.get("KHR_parallel_shader_compile")!==null?xe():setTimeout(xe,10)})};let en=null;function Du(y){en&&en(y)}function Xa(){ti.stop()}function qa(){ti.start()}const ti=new tu;ti.setAnimationLoop(Du),typeof self<"u"&&ti.setContext(self),this.setAnimationLoop=function(y){en=y,ve.setAnimationLoop(y),y===null?ti.stop():ti.start()},ve.addEventListener("sessionstart",Xa),ve.addEventListener("sessionend",qa),this.render=function(y,W){if(W!==void 0&&W.isCamera!==!0){dt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;if(y.matrixWorldAutoUpdate===!0&&y.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),ve.enabled===!0&&ve.isPresenting===!0&&(ve.cameraAutoUpdate===!0&&ve.updateCamera(W),W=ve.getCamera()),y.isScene===!0&&y.onBeforeRender(L,y,W,M),A=Ue.get(y,C.length),A.init(W),C.push(A),oe.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),v.setFromProjectionMatrix(oe,fn,W.reversedDepth),K=this.localClippingEnabled,g=Ce.init(this.clippingPlanes,K),_=Te.get(y,R.length),_.init(),R.push(_),ve.enabled===!0&&ve.isPresenting===!0){const xe=L.xr.getDepthSensingMesh();xe!==null&&Ur(xe,W,-1/0,L.sortObjects)}Ur(y,W,0,L.sortObjects),_.finish(),L.sortObjects===!0&&_.sort(ge,we),de=ve.enabled===!1||ve.isPresenting===!1||ve.hasDepthSensing()===!1,de&&_e.addToRenderList(_,y),this.info.render.frame++,g===!0&&Ce.beginShadows();const ee=A.state.shadowsArray;me.render(ee,y,W),g===!0&&Ce.endShadows(),this.info.autoReset===!0&&this.info.reset();const te=_.opaque,X=_.transmissive;if(A.setupLights(),W.isArrayCamera){const xe=W.cameras;if(X.length>0)for(let Le=0,Ne=xe.length;Le<Ne;Le++){const be=xe[Le];Ja(te,X,y,be)}de&&_e.render(y);for(let Le=0,Ne=xe.length;Le<Ne;Le++){const be=xe[Le];Za(_,y,be,be.viewport)}}else X.length>0&&Ja(te,X,y,W),de&&_e.render(y),Za(_,y,W);M!==null&&I===0&&(Re.updateMultisampleRenderTarget(M),Re.updateRenderTargetMipmap(M)),y.isScene===!0&&y.onAfterRender(L,y,W),B.resetDefaultState(),N=-1,V=null,C.pop(),C.length>0?(A=C[C.length-1],g===!0&&Ce.setGlobalState(L.clippingPlanes,A.state.camera)):A=null,R.pop(),R.length>0?_=R[R.length-1]:_=null};function Ur(y,W,ee,te){if(y.visible===!1)return;if(y.layers.test(W.layers)){if(y.isGroup)ee=y.renderOrder;else if(y.isLOD)y.autoUpdate===!0&&y.update(W);else if(y.isLight)A.pushLight(y),y.castShadow&&A.pushShadow(y);else if(y.isSprite){if(!y.frustumCulled||v.intersectsSprite(y)){te&&he.setFromMatrixPosition(y.matrixWorld).applyMatrix4(oe);const Le=pe.update(y),Ne=y.material;Ne.visible&&_.push(y,Le,Ne,ee,he.z,null)}}else if((y.isMesh||y.isLine||y.isPoints)&&(!y.frustumCulled||v.intersectsObject(y))){const Le=pe.update(y),Ne=y.material;if(te&&(y.boundingSphere!==void 0?(y.boundingSphere===null&&y.computeBoundingSphere(),he.copy(y.boundingSphere.center)):(Le.boundingSphere===null&&Le.computeBoundingSphere(),he.copy(Le.boundingSphere.center)),he.applyMatrix4(y.matrixWorld).applyMatrix4(oe)),Array.isArray(Ne)){const be=Le.groups;for(let Ge=0,Ye=be.length;Ge<Ye;Ge++){const Fe=be[Ge],Je=Ne[Fe.materialIndex];Je&&Je.visible&&_.push(y,Le,Je,ee,he.z,Fe)}}else Ne.visible&&_.push(y,Le,Ne,ee,he.z,null)}}const xe=y.children;for(let Le=0,Ne=xe.length;Le<Ne;Le++)Ur(xe[Le],W,ee,te)}function Za(y,W,ee,te){const{opaque:X,transmissive:xe,transparent:Le}=y;A.setupLightsView(ee),g===!0&&Ce.setGlobalState(L.clippingPlanes,ee),te&&O.viewport(Z.copy(te)),X.length>0&&Ns(X,W,ee),xe.length>0&&Ns(xe,W,ee),Le.length>0&&Ns(Le,W,ee),O.buffers.depth.setTest(!0),O.buffers.depth.setMask(!0),O.buffers.color.setMask(!0),O.setPolygonOffset(!1)}function Ja(y,W,ee,te){if((ee.isScene===!0?ee.overrideMaterial:null)!==null)return;A.state.transmissionRenderTarget[te.id]===void 0&&(A.state.transmissionRenderTarget[te.id]=new wn(1,1,{generateMipmaps:!0,type:$.has("EXT_color_buffer_half_float")||$.has("EXT_color_buffer_float")?ji:Un,minFilter:pi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:je.workingColorSpace}));const xe=A.state.transmissionRenderTarget[te.id],Le=te.viewport||Z;xe.setSize(Le.z*L.transmissionResolutionScale,Le.w*L.transmissionResolutionScale);const Ne=L.getRenderTarget(),be=L.getActiveCubeFace(),Ge=L.getActiveMipmapLevel();L.setRenderTarget(xe),L.getClearColor(ie),j=L.getClearAlpha(),j<1&&L.setClearColor(16777215,.5),L.clear(),de&&_e.render(ee);const Ye=L.toneMapping;L.toneMapping=Zn;const Fe=te.viewport;if(te.viewport!==void 0&&(te.viewport=void 0),A.setupLightsView(te),g===!0&&Ce.setGlobalState(L.clippingPlanes,te),Ns(y,ee,te),Re.updateMultisampleRenderTarget(xe),Re.updateRenderTargetMipmap(xe),$.has("WEBGL_multisampled_render_to_texture")===!1){let Je=!1;for(let tt=0,pt=W.length;tt<pt;tt++){const Et=W[tt],{object:ot,geometry:Be,material:ct,group:$e}=Et;if(ct.side===on&&ot.layers.test(te.layers)){const Gt=ct.side;ct.side=Ot,ct.needsUpdate=!0,Qa(ot,ee,te,Be,ct,$e),ct.side=Gt,ct.needsUpdate=!0,Je=!0}}Je===!0&&(Re.updateMultisampleRenderTarget(xe),Re.updateRenderTargetMipmap(xe))}L.setRenderTarget(Ne,be,Ge),L.setClearColor(ie,j),Fe!==void 0&&(te.viewport=Fe),L.toneMapping=Ye}function Ns(y,W,ee){const te=W.isScene===!0?W.overrideMaterial:null;for(let X=0,xe=y.length;X<xe;X++){const Le=y[X],{object:Ne,geometry:be,group:Ge}=Le;let Ye=Le.material;Ye.allowOverride===!0&&te!==null&&(Ye=te),Ne.layers.test(ee.layers)&&Qa(Ne,W,ee,be,Ye,Ge)}}function Qa(y,W,ee,te,X,xe){y.onBeforeRender(L,W,ee,te,X,xe),y.modelViewMatrix.multiplyMatrices(ee.matrixWorldInverse,y.matrixWorld),y.normalMatrix.getNormalMatrix(y.modelViewMatrix),X.onBeforeRender(L,W,ee,te,y,xe),X.transparent===!0&&X.side===on&&X.forceSinglePass===!1?(X.side=Ot,X.needsUpdate=!0,L.renderBufferDirect(ee,W,te,X,y,xe),X.side=mn,X.needsUpdate=!0,L.renderBufferDirect(ee,W,te,X,y,xe),X.side=on):L.renderBufferDirect(ee,W,te,X,y,xe),y.onAfterRender(L,W,ee,te,X,xe)}function Us(y,W,ee){W.isScene!==!0&&(W=Ae);const te=ue.get(y),X=A.state.lights,xe=A.state.shadowsArray,Le=X.state.version,Ne=ne.getParameters(y,X.state,xe,W,ee),be=ne.getProgramCacheKey(Ne);let Ge=te.programs;te.environment=y.isMeshStandardMaterial?W.environment:null,te.fog=W.fog,te.envMap=(y.isMeshStandardMaterial?x:b).get(y.envMap||te.environment),te.envMapRotation=te.environment!==null&&y.envMap===null?W.environmentRotation:y.envMapRotation,Ge===void 0&&(y.addEventListener("dispose",Xe),Ge=new Map,te.programs=Ge);let Ye=Ge.get(be);if(Ye!==void 0){if(te.currentProgram===Ye&&te.lightsStateVersion===Le)return ja(y,Ne),Ye}else Ne.uniforms=ne.getUniforms(y),y.onBeforeCompile(Ne,L),Ye=ne.acquireProgram(Ne,be),Ge.set(be,Ye),te.uniforms=Ne.uniforms;const Fe=te.uniforms;return(!y.isShaderMaterial&&!y.isRawShaderMaterial||y.clipping===!0)&&(Fe.clippingPlanes=Ce.uniform),ja(y,Ne),te.needsLights=Uu(y),te.lightsStateVersion=Le,te.needsLights&&(Fe.ambientLightColor.value=X.state.ambient,Fe.lightProbe.value=X.state.probe,Fe.directionalLights.value=X.state.directional,Fe.directionalLightShadows.value=X.state.directionalShadow,Fe.spotLights.value=X.state.spot,Fe.spotLightShadows.value=X.state.spotShadow,Fe.rectAreaLights.value=X.state.rectArea,Fe.ltc_1.value=X.state.rectAreaLTC1,Fe.ltc_2.value=X.state.rectAreaLTC2,Fe.pointLights.value=X.state.point,Fe.pointLightShadows.value=X.state.pointShadow,Fe.hemisphereLights.value=X.state.hemi,Fe.directionalShadowMap.value=X.state.directionalShadowMap,Fe.directionalShadowMatrix.value=X.state.directionalShadowMatrix,Fe.spotShadowMap.value=X.state.spotShadowMap,Fe.spotLightMatrix.value=X.state.spotLightMatrix,Fe.spotLightMap.value=X.state.spotLightMap,Fe.pointShadowMap.value=X.state.pointShadowMap,Fe.pointShadowMatrix.value=X.state.pointShadowMatrix),te.currentProgram=Ye,te.uniformsList=null,Ye}function $a(y){if(y.uniformsList===null){const W=y.currentProgram.getUniforms();y.uniformsList=pr.seqWithValue(W.seq,y.uniforms)}return y.uniformsList}function ja(y,W){const ee=ue.get(y);ee.outputColorSpace=W.outputColorSpace,ee.batching=W.batching,ee.batchingColor=W.batchingColor,ee.instancing=W.instancing,ee.instancingColor=W.instancingColor,ee.instancingMorph=W.instancingMorph,ee.skinning=W.skinning,ee.morphTargets=W.morphTargets,ee.morphNormals=W.morphNormals,ee.morphColors=W.morphColors,ee.morphTargetsCount=W.morphTargetsCount,ee.numClippingPlanes=W.numClippingPlanes,ee.numIntersection=W.numClipIntersection,ee.vertexAlphas=W.vertexAlphas,ee.vertexTangents=W.vertexTangents,ee.toneMapping=W.toneMapping}function Pu(y,W,ee,te,X){W.isScene!==!0&&(W=Ae),Re.resetTextureUnits();const xe=W.fog,Le=te.isMeshStandardMaterial?W.environment:null,Ne=M===null?L.outputColorSpace:M.isXRRenderTarget===!0?M.texture.colorSpace:Zi,be=(te.isMeshStandardMaterial?x:b).get(te.envMap||Le),Ge=te.vertexColors===!0&&!!ee.attributes.color&&ee.attributes.color.itemSize===4,Ye=!!ee.attributes.tangent&&(!!te.normalMap||te.anisotropy>0),Fe=!!ee.morphAttributes.position,Je=!!ee.morphAttributes.normal,tt=!!ee.morphAttributes.color;let pt=Zn;te.toneMapped&&(M===null||M.isXRRenderTarget===!0)&&(pt=L.toneMapping);const Et=ee.morphAttributes.position||ee.morphAttributes.normal||ee.morphAttributes.color,ot=Et!==void 0?Et.length:0,Be=ue.get(te),ct=A.state.lights;if(g===!0&&(K===!0||y!==V)){const Dt=y===V&&te.id===N;Ce.setState(te,y,Dt)}let $e=!1;te.version===Be.__version?(Be.needsLights&&Be.lightsStateVersion!==ct.state.version||Be.outputColorSpace!==Ne||X.isBatchedMesh&&Be.batching===!1||!X.isBatchedMesh&&Be.batching===!0||X.isBatchedMesh&&Be.batchingColor===!0&&X.colorTexture===null||X.isBatchedMesh&&Be.batchingColor===!1&&X.colorTexture!==null||X.isInstancedMesh&&Be.instancing===!1||!X.isInstancedMesh&&Be.instancing===!0||X.isSkinnedMesh&&Be.skinning===!1||!X.isSkinnedMesh&&Be.skinning===!0||X.isInstancedMesh&&Be.instancingColor===!0&&X.instanceColor===null||X.isInstancedMesh&&Be.instancingColor===!1&&X.instanceColor!==null||X.isInstancedMesh&&Be.instancingMorph===!0&&X.morphTexture===null||X.isInstancedMesh&&Be.instancingMorph===!1&&X.morphTexture!==null||Be.envMap!==be||te.fog===!0&&Be.fog!==xe||Be.numClippingPlanes!==void 0&&(Be.numClippingPlanes!==Ce.numPlanes||Be.numIntersection!==Ce.numIntersection)||Be.vertexAlphas!==Ge||Be.vertexTangents!==Ye||Be.morphTargets!==Fe||Be.morphNormals!==Je||Be.morphColors!==tt||Be.toneMapping!==pt||Be.morphTargetsCount!==ot)&&($e=!0):($e=!0,Be.__version=te.version);let Gt=Be.currentProgram;$e===!0&&(Gt=Us(te,W,X));let Ti=!1,Vt=!1,is=!1;const ut=Gt.getUniforms(),wt=Be.uniforms;if(O.useProgram(Gt.program)&&(Ti=!0,Vt=!0,is=!0),te.id!==N&&(N=te.id,Vt=!0),Ti||V!==y){O.buffers.depth.getReversed()&&y.reversedDepth!==!0&&(y._reversedDepth=!0,y.updateProjectionMatrix()),ut.setValue(T,"projectionMatrix",y.projectionMatrix),ut.setValue(T,"viewMatrix",y.matrixWorldInverse);const Ft=ut.map.cameraPosition;Ft!==void 0&&Ft.setValue(T,k.setFromMatrixPosition(y.matrixWorld)),P.logarithmicDepthBuffer&&ut.setValue(T,"logDepthBufFC",2/(Math.log(y.far+1)/Math.LN2)),(te.isMeshPhongMaterial||te.isMeshToonMaterial||te.isMeshLambertMaterial||te.isMeshBasicMaterial||te.isMeshStandardMaterial||te.isShaderMaterial)&&ut.setValue(T,"isOrthographic",y.isOrthographicCamera===!0),V!==y&&(V=y,Vt=!0,is=!0)}if(X.isSkinnedMesh){ut.setOptional(T,X,"bindMatrix"),ut.setOptional(T,X,"bindMatrixInverse");const Dt=X.skeleton;Dt&&(Dt.boneTexture===null&&Dt.computeBoneTexture(),ut.setValue(T,"boneTexture",Dt.boneTexture,Re))}X.isBatchedMesh&&(ut.setOptional(T,X,"batchingTexture"),ut.setValue(T,"batchingTexture",X._matricesTexture,Re),ut.setOptional(T,X,"batchingIdTexture"),ut.setValue(T,"batchingIdTexture",X._indirectTexture,Re),ut.setOptional(T,X,"batchingColorTexture"),X._colorsTexture!==null&&ut.setValue(T,"batchingColorTexture",X._colorsTexture,Re));const qt=ee.morphAttributes;if((qt.position!==void 0||qt.normal!==void 0||qt.color!==void 0)&&ke.update(X,ee,Gt),(Vt||Be.receiveShadow!==X.receiveShadow)&&(Be.receiveShadow=X.receiveShadow,ut.setValue(T,"receiveShadow",X.receiveShadow)),te.isMeshGouraudMaterial&&te.envMap!==null&&(wt.envMap.value=be,wt.flipEnvMap.value=be.isCubeTexture&&be.isRenderTargetTexture===!1?-1:1),te.isMeshStandardMaterial&&te.envMap===null&&W.environment!==null&&(wt.envMapIntensity.value=W.environmentIntensity),wt.dfgLUT!==void 0&&(wt.dfgLUT.value=GS()),Vt&&(ut.setValue(T,"toneMappingExposure",L.toneMappingExposure),Be.needsLights&&Nu(wt,is),xe&&te.fog===!0&&De.refreshFogUniforms(wt,xe),De.refreshMaterialUniforms(wt,te,re,Ee,A.state.transmissionRenderTarget[y.id]),pr.upload(T,$a(Be),wt,Re)),te.isShaderMaterial&&te.uniformsNeedUpdate===!0&&(pr.upload(T,$a(Be),wt,Re),te.uniformsNeedUpdate=!1),te.isSpriteMaterial&&ut.setValue(T,"center",X.center),ut.setValue(T,"modelViewMatrix",X.modelViewMatrix),ut.setValue(T,"normalMatrix",X.normalMatrix),ut.setValue(T,"modelMatrix",X.matrixWorld),te.isShaderMaterial||te.isRawShaderMaterial){const Dt=te.uniformsGroups;for(let Ft=0,wr=Dt.length;Ft<wr;Ft++){const ni=Dt[Ft];ye.update(ni,Gt),ye.bind(ni,Gt)}}return Gt}function Nu(y,W){y.ambientLightColor.needsUpdate=W,y.lightProbe.needsUpdate=W,y.directionalLights.needsUpdate=W,y.directionalLightShadows.needsUpdate=W,y.pointLights.needsUpdate=W,y.pointLightShadows.needsUpdate=W,y.spotLights.needsUpdate=W,y.spotLightShadows.needsUpdate=W,y.rectAreaLights.needsUpdate=W,y.hemisphereLights.needsUpdate=W}function Uu(y){return y.isMeshLambertMaterial||y.isMeshToonMaterial||y.isMeshPhongMaterial||y.isMeshStandardMaterial||y.isShadowMaterial||y.isShaderMaterial&&y.lights===!0}this.getActiveCubeFace=function(){return F},this.getActiveMipmapLevel=function(){return I},this.getRenderTarget=function(){return M},this.setRenderTargetTextures=function(y,W,ee){const te=ue.get(y);te.__autoAllocateDepthBuffer=y.resolveDepthBuffer===!1,te.__autoAllocateDepthBuffer===!1&&(te.__useRenderToTexture=!1),ue.get(y.texture).__webglTexture=W,ue.get(y.depthTexture).__webglTexture=te.__autoAllocateDepthBuffer?void 0:ee,te.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(y,W){const ee=ue.get(y);ee.__webglFramebuffer=W,ee.__useDefaultFramebuffer=W===void 0};const wu=T.createFramebuffer();this.setRenderTarget=function(y,W=0,ee=0){M=y,F=W,I=ee;let te=!0,X=null,xe=!1,Le=!1;if(y){const be=ue.get(y);if(be.__useDefaultFramebuffer!==void 0)O.bindFramebuffer(T.FRAMEBUFFER,null),te=!1;else if(be.__webglFramebuffer===void 0)Re.setupRenderTarget(y);else if(be.__hasExternalTextures)Re.rebindTextures(y,ue.get(y.texture).__webglTexture,ue.get(y.depthTexture).__webglTexture);else if(y.depthBuffer){const Fe=y.depthTexture;if(be.__boundDepthTexture!==Fe){if(Fe!==null&&ue.has(Fe)&&(y.width!==Fe.image.width||y.height!==Fe.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Re.setupDepthRenderbuffer(y)}}const Ge=y.texture;(Ge.isData3DTexture||Ge.isDataArrayTexture||Ge.isCompressedArrayTexture)&&(Le=!0);const Ye=ue.get(y).__webglFramebuffer;y.isWebGLCubeRenderTarget?(Array.isArray(Ye[W])?X=Ye[W][ee]:X=Ye[W],xe=!0):y.samples>0&&Re.useMultisampledRTT(y)===!1?X=ue.get(y).__webglMultisampledFramebuffer:Array.isArray(Ye)?X=Ye[ee]:X=Ye,Z.copy(y.viewport),J.copy(y.scissor),Q=y.scissorTest}else Z.copy(Ve).multiplyScalar(re).floor(),J.copy(z).multiplyScalar(re).floor(),Q=U;if(ee!==0&&(X=wu),O.bindFramebuffer(T.FRAMEBUFFER,X)&&te&&O.drawBuffers(y,X),O.viewport(Z),O.scissor(J),O.setScissorTest(Q),xe){const be=ue.get(y.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_CUBE_MAP_POSITIVE_X+W,be.__webglTexture,ee)}else if(Le){const be=W;for(let Ge=0;Ge<y.textures.length;Ge++){const Ye=ue.get(y.textures[Ge]);T.framebufferTextureLayer(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0+Ge,Ye.__webglTexture,ee,be)}}else if(y!==null&&ee!==0){const be=ue.get(y.texture);T.framebufferTexture2D(T.FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,be.__webglTexture,ee)}N=-1},this.readRenderTargetPixels=function(y,W,ee,te,X,xe,Le,Ne=0){if(!(y&&y.isWebGLRenderTarget)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let be=ue.get(y).__webglFramebuffer;if(y.isWebGLCubeRenderTarget&&Le!==void 0&&(be=be[Le]),be){O.bindFramebuffer(T.FRAMEBUFFER,be);try{const Ge=y.textures[Ne],Ye=Ge.format,Fe=Ge.type;if(!P.textureFormatReadable(Ye)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!P.textureTypeReadable(Fe)){dt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=y.width-te&&ee>=0&&ee<=y.height-X&&(y.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Ne),T.readPixels(W,ee,te,X,ze.convert(Ye),ze.convert(Fe),xe))}finally{const Ge=M!==null?ue.get(M).__webglFramebuffer:null;O.bindFramebuffer(T.FRAMEBUFFER,Ge)}}},this.readRenderTargetPixelsAsync=async function(y,W,ee,te,X,xe,Le,Ne=0){if(!(y&&y.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=ue.get(y).__webglFramebuffer;if(y.isWebGLCubeRenderTarget&&Le!==void 0&&(be=be[Le]),be)if(W>=0&&W<=y.width-te&&ee>=0&&ee<=y.height-X){O.bindFramebuffer(T.FRAMEBUFFER,be);const Ge=y.textures[Ne],Ye=Ge.format,Fe=Ge.type;if(!P.textureFormatReadable(Ye))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!P.textureTypeReadable(Fe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Je=T.createBuffer();T.bindBuffer(T.PIXEL_PACK_BUFFER,Je),T.bufferData(T.PIXEL_PACK_BUFFER,xe.byteLength,T.STREAM_READ),y.textures.length>1&&T.readBuffer(T.COLOR_ATTACHMENT0+Ne),T.readPixels(W,ee,te,X,ze.convert(Ye),ze.convert(Fe),0);const tt=M!==null?ue.get(M).__webglFramebuffer:null;O.bindFramebuffer(T.FRAMEBUFFER,tt);const pt=T.fenceSync(T.SYNC_GPU_COMMANDS_COMPLETE,0);return T.flush(),await Dh(T,pt,4),T.bindBuffer(T.PIXEL_PACK_BUFFER,Je),T.getBufferSubData(T.PIXEL_PACK_BUFFER,0,xe),T.deleteBuffer(Je),T.deleteSync(pt),xe}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(y,W=null,ee=0){const te=Math.pow(2,-ee),X=Math.floor(y.image.width*te),xe=Math.floor(y.image.height*te),Le=W!==null?W.x:0,Ne=W!==null?W.y:0;Re.setTexture2D(y,0),T.copyTexSubImage2D(T.TEXTURE_2D,ee,0,0,Le,Ne,X,xe),O.unbindTexture()};const Fu=T.createFramebuffer(),Bu=T.createFramebuffer();this.copyTextureToTexture=function(y,W,ee=null,te=null,X=0,xe=null){xe===null&&(X!==0?(vs("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),xe=X,X=0):xe=0);let Le,Ne,be,Ge,Ye,Fe,Je,tt,pt;const Et=y.isCompressedTexture?y.mipmaps[xe]:y.image;if(ee!==null)Le=ee.max.x-ee.min.x,Ne=ee.max.y-ee.min.y,be=ee.isBox3?ee.max.z-ee.min.z:1,Ge=ee.min.x,Ye=ee.min.y,Fe=ee.isBox3?ee.min.z:0;else{const qt=Math.pow(2,-X);Le=Math.floor(Et.width*qt),Ne=Math.floor(Et.height*qt),y.isDataArrayTexture?be=Et.depth:y.isData3DTexture?be=Math.floor(Et.depth*qt):be=1,Ge=0,Ye=0,Fe=0}te!==null?(Je=te.x,tt=te.y,pt=te.z):(Je=0,tt=0,pt=0);const ot=ze.convert(W.format),Be=ze.convert(W.type);let ct;W.isData3DTexture?(Re.setTexture3D(W,0),ct=T.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(Re.setTexture2DArray(W,0),ct=T.TEXTURE_2D_ARRAY):(Re.setTexture2D(W,0),ct=T.TEXTURE_2D),T.pixelStorei(T.UNPACK_FLIP_Y_WEBGL,W.flipY),T.pixelStorei(T.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),T.pixelStorei(T.UNPACK_ALIGNMENT,W.unpackAlignment);const $e=T.getParameter(T.UNPACK_ROW_LENGTH),Gt=T.getParameter(T.UNPACK_IMAGE_HEIGHT),Ti=T.getParameter(T.UNPACK_SKIP_PIXELS),Vt=T.getParameter(T.UNPACK_SKIP_ROWS),is=T.getParameter(T.UNPACK_SKIP_IMAGES);T.pixelStorei(T.UNPACK_ROW_LENGTH,Et.width),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,Et.height),T.pixelStorei(T.UNPACK_SKIP_PIXELS,Ge),T.pixelStorei(T.UNPACK_SKIP_ROWS,Ye),T.pixelStorei(T.UNPACK_SKIP_IMAGES,Fe);const ut=y.isDataArrayTexture||y.isData3DTexture,wt=W.isDataArrayTexture||W.isData3DTexture;if(y.isDepthTexture){const qt=ue.get(y),Dt=ue.get(W),Ft=ue.get(qt.__renderTarget),wr=ue.get(Dt.__renderTarget);O.bindFramebuffer(T.READ_FRAMEBUFFER,Ft.__webglFramebuffer),O.bindFramebuffer(T.DRAW_FRAMEBUFFER,wr.__webglFramebuffer);for(let ni=0;ni<be;ni++)ut&&(T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ue.get(y).__webglTexture,X,Fe+ni),T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,ue.get(W).__webglTexture,xe,pt+ni)),T.blitFramebuffer(Ge,Ye,Le,Ne,Je,tt,Le,Ne,T.DEPTH_BUFFER_BIT,T.NEAREST);O.bindFramebuffer(T.READ_FRAMEBUFFER,null),O.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else if(X!==0||y.isRenderTargetTexture||ue.has(y)){const qt=ue.get(y),Dt=ue.get(W);O.bindFramebuffer(T.READ_FRAMEBUFFER,Fu),O.bindFramebuffer(T.DRAW_FRAMEBUFFER,Bu);for(let Ft=0;Ft<be;Ft++)ut?T.framebufferTextureLayer(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,qt.__webglTexture,X,Fe+Ft):T.framebufferTexture2D(T.READ_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,qt.__webglTexture,X),wt?T.framebufferTextureLayer(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,Dt.__webglTexture,xe,pt+Ft):T.framebufferTexture2D(T.DRAW_FRAMEBUFFER,T.COLOR_ATTACHMENT0,T.TEXTURE_2D,Dt.__webglTexture,xe),X!==0?T.blitFramebuffer(Ge,Ye,Le,Ne,Je,tt,Le,Ne,T.COLOR_BUFFER_BIT,T.NEAREST):wt?T.copyTexSubImage3D(ct,xe,Je,tt,pt+Ft,Ge,Ye,Le,Ne):T.copyTexSubImage2D(ct,xe,Je,tt,Ge,Ye,Le,Ne);O.bindFramebuffer(T.READ_FRAMEBUFFER,null),O.bindFramebuffer(T.DRAW_FRAMEBUFFER,null)}else wt?y.isDataTexture||y.isData3DTexture?T.texSubImage3D(ct,xe,Je,tt,pt,Le,Ne,be,ot,Be,Et.data):W.isCompressedArrayTexture?T.compressedTexSubImage3D(ct,xe,Je,tt,pt,Le,Ne,be,ot,Et.data):T.texSubImage3D(ct,xe,Je,tt,pt,Le,Ne,be,ot,Be,Et):y.isDataTexture?T.texSubImage2D(T.TEXTURE_2D,xe,Je,tt,Le,Ne,ot,Be,Et.data):y.isCompressedTexture?T.compressedTexSubImage2D(T.TEXTURE_2D,xe,Je,tt,Et.width,Et.height,ot,Et.data):T.texSubImage2D(T.TEXTURE_2D,xe,Je,tt,Le,Ne,ot,Be,Et);T.pixelStorei(T.UNPACK_ROW_LENGTH,$e),T.pixelStorei(T.UNPACK_IMAGE_HEIGHT,Gt),T.pixelStorei(T.UNPACK_SKIP_PIXELS,Ti),T.pixelStorei(T.UNPACK_SKIP_ROWS,Vt),T.pixelStorei(T.UNPACK_SKIP_IMAGES,is),xe===0&&W.generateMipmaps&&T.generateMipmap(ct),O.unbindTexture()},this.initRenderTarget=function(y){ue.get(y).__webglFramebuffer===void 0&&Re.setupRenderTarget(y)},this.initTexture=function(y){y.isCubeTexture?Re.setTextureCube(y,0):y.isData3DTexture?Re.setTexture3D(y,0):y.isDataArrayTexture||y.isCompressedArrayTexture?Re.setTexture2DArray(y,0):Re.setTexture2D(y,0),O.unbindTexture()},this.resetState=function(){F=0,I=0,M=null,O.reset(),B.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return fn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=je._getDrawingBufferColorSpace(e),t.unpackColorSpace=je._getUnpackColorSpace()}}var us=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},mo={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var sc;function kS(){return sc||(sc=1,(function(n){(function(){var e=function(){this.init()};e.prototype={init:function(){var o=this||t;return o._counter=1e3,o._html5AudioPool=[],o.html5PoolSize=10,o._codecs={},o._howls=[],o._muted=!1,o._volume=1,o._canPlayEvent="canplaythrough",o._navigator=typeof window<"u"&&window.navigator?window.navigator:null,o.masterGain=null,o.noAudio=!1,o.usingWebAudio=!0,o.autoSuspend=!0,o.ctx=null,o.autoUnlock=!0,o._setup(),o},volume:function(o){var c=this||t;if(o=parseFloat(o),c.ctx||p(),typeof o<"u"&&o>=0&&o<=1){if(c._volume=o,c._muted)return c;c.usingWebAudio&&c.masterGain.gain.setValueAtTime(o,t.ctx.currentTime);for(var h=0;h<c._howls.length;h++)if(!c._howls[h]._webAudio)for(var m=c._howls[h]._getSoundIds(),S=0;S<m.length;S++){var E=c._howls[h]._soundById(m[S]);E&&E._node&&(E._node.volume=E._volume*o)}return c}return c._volume},mute:function(o){var c=this||t;c.ctx||p(),c._muted=o,c.usingWebAudio&&c.masterGain.gain.setValueAtTime(o?0:c._volume,t.ctx.currentTime);for(var h=0;h<c._howls.length;h++)if(!c._howls[h]._webAudio)for(var m=c._howls[h]._getSoundIds(),S=0;S<m.length;S++){var E=c._howls[h]._soundById(m[S]);E&&E._node&&(E._node.muted=o?!0:E._muted)}return c},stop:function(){for(var o=this||t,c=0;c<o._howls.length;c++)o._howls[c].stop();return o},unload:function(){for(var o=this||t,c=o._howls.length-1;c>=0;c--)o._howls[c].unload();return o.usingWebAudio&&o.ctx&&typeof o.ctx.close<"u"&&(o.ctx.close(),o.ctx=null,p()),o},codecs:function(o){return(this||t)._codecs[o.replace(/^x-/,"")]},_setup:function(){var o=this||t;if(o.state=o.ctx&&o.ctx.state||"suspended",o._autoSuspend(),!o.usingWebAudio)if(typeof Audio<"u")try{var c=new Audio;typeof c.oncanplaythrough>"u"&&(o._canPlayEvent="canplay")}catch{o.noAudio=!0}else o.noAudio=!0;try{var c=new Audio;c.muted&&(o.noAudio=!0)}catch{}return o.noAudio||o._setupCodecs(),o},_setupCodecs:function(){var o=this||t,c=null;try{c=typeof Audio<"u"?new Audio:null}catch{return o}if(!c||typeof c.canPlayType!="function")return o;var h=c.canPlayType("audio/mpeg;").replace(/^no$/,""),m=o._navigator?o._navigator.userAgent:"",S=m.match(/OPR\/(\d+)/g),E=S&&parseInt(S[0].split("/")[1],10)<33,f=m.indexOf("Safari")!==-1&&m.indexOf("Chrome")===-1,_=m.match(/Version\/(.*?) /),A=f&&_&&parseInt(_[1],10)<15;return o._codecs={mp3:!!(!E&&(h||c.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!h,opus:!!c.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!c.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!c.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(c.canPlayType('audio/wav; codecs="1"')||c.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!c.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!c.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(c.canPlayType("audio/x-m4a;")||c.canPlayType("audio/m4a;")||c.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(c.canPlayType("audio/x-m4b;")||c.canPlayType("audio/m4b;")||c.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(c.canPlayType("audio/x-mp4;")||c.canPlayType("audio/mp4;")||c.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!A&&c.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!A&&c.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!c.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(c.canPlayType("audio/x-flac;")||c.canPlayType("audio/flac;")).replace(/^no$/,"")},o},_unlockAudio:function(){var o=this||t;if(!(o._audioUnlocked||!o.ctx)){o._audioUnlocked=!1,o.autoUnlock=!1,!o._mobileUnloaded&&o.ctx.sampleRate!==44100&&(o._mobileUnloaded=!0,o.unload()),o._scratchBuffer=o.ctx.createBuffer(1,1,22050);var c=function(h){for(;o._html5AudioPool.length<o.html5PoolSize;)try{var m=new Audio;m._unlocked=!0,o._releaseHtml5Audio(m)}catch{o.noAudio=!0;break}for(var S=0;S<o._howls.length;S++)if(!o._howls[S]._webAudio)for(var E=o._howls[S]._getSoundIds(),f=0;f<E.length;f++){var _=o._howls[S]._soundById(E[f]);_&&_._node&&!_._node._unlocked&&(_._node._unlocked=!0,_._node.load())}o._autoResume();var A=o.ctx.createBufferSource();A.buffer=o._scratchBuffer,A.connect(o.ctx.destination),typeof A.start>"u"?A.noteOn(0):A.start(0),typeof o.ctx.resume=="function"&&o.ctx.resume(),A.onended=function(){A.disconnect(0),o._audioUnlocked=!0,document.removeEventListener("touchstart",c,!0),document.removeEventListener("touchend",c,!0),document.removeEventListener("click",c,!0),document.removeEventListener("keydown",c,!0);for(var R=0;R<o._howls.length;R++)o._howls[R]._emit("unlock")}};return document.addEventListener("touchstart",c,!0),document.addEventListener("touchend",c,!0),document.addEventListener("click",c,!0),document.addEventListener("keydown",c,!0),o}},_obtainHtml5Audio:function(){var o=this||t;if(o._html5AudioPool.length)return o._html5AudioPool.pop();var c=new Audio().play();return c&&typeof Promise<"u"&&(c instanceof Promise||typeof c.then=="function")&&c.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(o){var c=this||t;return o._unlocked&&c._html5AudioPool.push(o),c},_autoSuspend:function(){var o=this;if(!(!o.autoSuspend||!o.ctx||typeof o.ctx.suspend>"u"||!t.usingWebAudio)){for(var c=0;c<o._howls.length;c++)if(o._howls[c]._webAudio){for(var h=0;h<o._howls[c]._sounds.length;h++)if(!o._howls[c]._sounds[h]._paused)return o}return o._suspendTimer&&clearTimeout(o._suspendTimer),o._suspendTimer=setTimeout(function(){if(o.autoSuspend){o._suspendTimer=null,o.state="suspending";var m=function(){o.state="suspended",o._resumeAfterSuspend&&(delete o._resumeAfterSuspend,o._autoResume())};o.ctx.suspend().then(m,m)}},3e4),o}},_autoResume:function(){var o=this;if(!(!o.ctx||typeof o.ctx.resume>"u"||!t.usingWebAudio))return o.state==="running"&&o.ctx.state!=="interrupted"&&o._suspendTimer?(clearTimeout(o._suspendTimer),o._suspendTimer=null):o.state==="suspended"||o.state==="running"&&o.ctx.state==="interrupted"?(o.ctx.resume().then(function(){o.state="running";for(var c=0;c<o._howls.length;c++)o._howls[c]._emit("resume")}),o._suspendTimer&&(clearTimeout(o._suspendTimer),o._suspendTimer=null)):o.state==="suspending"&&(o._resumeAfterSuspend=!0),o}};var t=new e,i=function(o){var c=this;if(!o.src||o.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}c.init(o)};i.prototype={init:function(o){var c=this;return t.ctx||p(),c._autoplay=o.autoplay||!1,c._format=typeof o.format!="string"?o.format:[o.format],c._html5=o.html5||!1,c._muted=o.mute||!1,c._loop=o.loop||!1,c._pool=o.pool||5,c._preload=typeof o.preload=="boolean"||o.preload==="metadata"?o.preload:!0,c._rate=o.rate||1,c._sprite=o.sprite||{},c._src=typeof o.src!="string"?o.src:[o.src],c._volume=o.volume!==void 0?o.volume:1,c._xhr={method:o.xhr&&o.xhr.method?o.xhr.method:"GET",headers:o.xhr&&o.xhr.headers?o.xhr.headers:null,withCredentials:o.xhr&&o.xhr.withCredentials?o.xhr.withCredentials:!1},c._duration=0,c._state="unloaded",c._sounds=[],c._endTimers={},c._queue=[],c._playLock=!1,c._onend=o.onend?[{fn:o.onend}]:[],c._onfade=o.onfade?[{fn:o.onfade}]:[],c._onload=o.onload?[{fn:o.onload}]:[],c._onloaderror=o.onloaderror?[{fn:o.onloaderror}]:[],c._onplayerror=o.onplayerror?[{fn:o.onplayerror}]:[],c._onpause=o.onpause?[{fn:o.onpause}]:[],c._onplay=o.onplay?[{fn:o.onplay}]:[],c._onstop=o.onstop?[{fn:o.onstop}]:[],c._onmute=o.onmute?[{fn:o.onmute}]:[],c._onvolume=o.onvolume?[{fn:o.onvolume}]:[],c._onrate=o.onrate?[{fn:o.onrate}]:[],c._onseek=o.onseek?[{fn:o.onseek}]:[],c._onunlock=o.onunlock?[{fn:o.onunlock}]:[],c._onresume=[],c._webAudio=t.usingWebAudio&&!c._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(c),c._autoplay&&c._queue.push({event:"play",action:function(){c.play()}}),c._preload&&c._preload!=="none"&&c.load(),c},load:function(){var o=this,c=null;if(t.noAudio){o._emit("loaderror",null,"No audio support.");return}typeof o._src=="string"&&(o._src=[o._src]);for(var h=0;h<o._src.length;h++){var m,S;if(o._format&&o._format[h])m=o._format[h];else{if(S=o._src[h],typeof S!="string"){o._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}m=/^data:audio\/([^;,]+);/i.exec(S),m||(m=/\.([^.]+)$/.exec(S.split("?",1)[0])),m&&(m=m[1].toLowerCase())}if(m||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),m&&t.codecs(m)){c=o._src[h];break}}if(!c){o._emit("loaderror",null,"No codec support for selected audio sources.");return}return o._src=c,o._state="loading",window.location.protocol==="https:"&&c.slice(0,5)==="http:"&&(o._html5=!0,o._webAudio=!1),new s(o),o._webAudio&&a(o),o},play:function(o,c){var h=this,m=null;if(typeof o=="number")m=o,o=null;else{if(typeof o=="string"&&h._state==="loaded"&&!h._sprite[o])return null;if(typeof o>"u"&&(o="__default",!h._playLock)){for(var S=0,E=0;E<h._sounds.length;E++)h._sounds[E]._paused&&!h._sounds[E]._ended&&(S++,m=h._sounds[E]._id);S===1?o=null:m=null}}var f=m?h._soundById(m):h._inactiveSound();if(!f)return null;if(m&&!o&&(o=f._sprite||"__default"),h._state!=="loaded"){f._sprite=o,f._ended=!1;var _=f._id;return h._queue.push({event:"play",action:function(){h.play(_)}}),_}if(m&&!f._paused)return c||h._loadQueue("play"),f._id;h._webAudio&&t._autoResume();var A=Math.max(0,f._seek>0?f._seek:h._sprite[o][0]/1e3),R=Math.max(0,(h._sprite[o][0]+h._sprite[o][1])/1e3-A),C=R*1e3/Math.abs(f._rate),L=h._sprite[o][0]/1e3,D=(h._sprite[o][0]+h._sprite[o][1])/1e3;f._sprite=o,f._ended=!1;var F=function(){f._paused=!1,f._seek=A,f._start=L,f._stop=D,f._loop=!!(f._loop||h._sprite[o][2])};if(A>=D){h._ended(f);return}var I=f._node;if(h._webAudio){var M=function(){h._playLock=!1,F(),h._refreshBuffer(f);var J=f._muted||h._muted?0:f._volume;I.gain.setValueAtTime(J,t.ctx.currentTime),f._playStart=t.ctx.currentTime,typeof I.bufferSource.start>"u"?f._loop?I.bufferSource.noteGrainOn(0,A,86400):I.bufferSource.noteGrainOn(0,A,R):f._loop?I.bufferSource.start(0,A,86400):I.bufferSource.start(0,A,R),C!==1/0&&(h._endTimers[f._id]=setTimeout(h._ended.bind(h,f),C)),c||setTimeout(function(){h._emit("play",f._id),h._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?M():(h._playLock=!0,h.once("resume",M),h._clearTimer(f._id))}else{var N=function(){I.currentTime=A,I.muted=f._muted||h._muted||t._muted||I.muted,I.volume=f._volume*t.volume(),I.playbackRate=f._rate;try{var J=I.play();if(J&&typeof Promise<"u"&&(J instanceof Promise||typeof J.then=="function")?(h._playLock=!0,F(),J.then(function(){h._playLock=!1,I._unlocked=!0,c?h._loadQueue():h._emit("play",f._id)}).catch(function(){h._playLock=!1,h._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),f._ended=!0,f._paused=!0})):c||(h._playLock=!1,F(),h._emit("play",f._id)),I.playbackRate=f._rate,I.paused){h._emit("playerror",f._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}o!=="__default"||f._loop?h._endTimers[f._id]=setTimeout(h._ended.bind(h,f),C):(h._endTimers[f._id]=function(){h._ended(f),I.removeEventListener("ended",h._endTimers[f._id],!1)},I.addEventListener("ended",h._endTimers[f._id],!1))}catch(Q){h._emit("playerror",f._id,Q)}};I.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(I.src=h._src,I.load());var V=window&&window.ejecta||!I.readyState&&t._navigator.isCocoonJS;if(I.readyState>=3||V)N();else{h._playLock=!0,h._state="loading";var Z=function(){h._state="loaded",N(),I.removeEventListener(t._canPlayEvent,Z,!1)};I.addEventListener(t._canPlayEvent,Z,!1),h._clearTimer(f._id)}}return f._id},pause:function(o){var c=this;if(c._state!=="loaded"||c._playLock)return c._queue.push({event:"pause",action:function(){c.pause(o)}}),c;for(var h=c._getSoundIds(o),m=0;m<h.length;m++){c._clearTimer(h[m]);var S=c._soundById(h[m]);if(S&&!S._paused&&(S._seek=c.seek(h[m]),S._rateSeek=0,S._paused=!0,c._stopFade(h[m]),S._node))if(c._webAudio){if(!S._node.bufferSource)continue;typeof S._node.bufferSource.stop>"u"?S._node.bufferSource.noteOff(0):S._node.bufferSource.stop(0),c._cleanBuffer(S._node)}else(!isNaN(S._node.duration)||S._node.duration===1/0)&&S._node.pause();arguments[1]||c._emit("pause",S?S._id:null)}return c},stop:function(o,c){var h=this;if(h._state!=="loaded"||h._playLock)return h._queue.push({event:"stop",action:function(){h.stop(o)}}),h;for(var m=h._getSoundIds(o),S=0;S<m.length;S++){h._clearTimer(m[S]);var E=h._soundById(m[S]);E&&(E._seek=E._start||0,E._rateSeek=0,E._paused=!0,E._ended=!0,h._stopFade(m[S]),E._node&&(h._webAudio?E._node.bufferSource&&(typeof E._node.bufferSource.stop>"u"?E._node.bufferSource.noteOff(0):E._node.bufferSource.stop(0),h._cleanBuffer(E._node)):(!isNaN(E._node.duration)||E._node.duration===1/0)&&(E._node.currentTime=E._start||0,E._node.pause(),E._node.duration===1/0&&h._clearSound(E._node))),c||h._emit("stop",E._id))}return h},mute:function(o,c){var h=this;if(h._state!=="loaded"||h._playLock)return h._queue.push({event:"mute",action:function(){h.mute(o,c)}}),h;if(typeof c>"u")if(typeof o=="boolean")h._muted=o;else return h._muted;for(var m=h._getSoundIds(c),S=0;S<m.length;S++){var E=h._soundById(m[S]);E&&(E._muted=o,E._interval&&h._stopFade(E._id),h._webAudio&&E._node?E._node.gain.setValueAtTime(o?0:E._volume,t.ctx.currentTime):E._node&&(E._node.muted=t._muted?!0:o),h._emit("mute",E._id))}return h},volume:function(){var o=this,c=arguments,h,m;if(c.length===0)return o._volume;if(c.length===1||c.length===2&&typeof c[1]>"u"){var S=o._getSoundIds(),E=S.indexOf(c[0]);E>=0?m=parseInt(c[0],10):h=parseFloat(c[0])}else c.length>=2&&(h=parseFloat(c[0]),m=parseInt(c[1],10));var f;if(typeof h<"u"&&h>=0&&h<=1){if(o._state!=="loaded"||o._playLock)return o._queue.push({event:"volume",action:function(){o.volume.apply(o,c)}}),o;typeof m>"u"&&(o._volume=h),m=o._getSoundIds(m);for(var _=0;_<m.length;_++)f=o._soundById(m[_]),f&&(f._volume=h,c[2]||o._stopFade(m[_]),o._webAudio&&f._node&&!f._muted?f._node.gain.setValueAtTime(h,t.ctx.currentTime):f._node&&!f._muted&&(f._node.volume=h*t.volume()),o._emit("volume",f._id))}else return f=m?o._soundById(m):o._sounds[0],f?f._volume:0;return o},fade:function(o,c,h,m){var S=this;if(S._state!=="loaded"||S._playLock)return S._queue.push({event:"fade",action:function(){S.fade(o,c,h,m)}}),S;o=Math.min(Math.max(0,parseFloat(o)),1),c=Math.min(Math.max(0,parseFloat(c)),1),h=parseFloat(h),S.volume(o,m);for(var E=S._getSoundIds(m),f=0;f<E.length;f++){var _=S._soundById(E[f]);if(_){if(m||S._stopFade(E[f]),S._webAudio&&!_._muted){var A=t.ctx.currentTime,R=A+h/1e3;_._volume=o,_._node.gain.setValueAtTime(o,A),_._node.gain.linearRampToValueAtTime(c,R)}S._startFadeInterval(_,o,c,h,E[f],typeof m>"u")}}return S},_startFadeInterval:function(o,c,h,m,S,E){var f=this,_=c,A=h-c,R=Math.abs(A/.01),C=Math.max(4,R>0?m/R:m),L=Date.now();o._fadeTo=h,o._interval=setInterval(function(){var D=(Date.now()-L)/m;L=Date.now(),_+=A*D,_=Math.round(_*100)/100,A<0?_=Math.max(h,_):_=Math.min(h,_),f._webAudio?o._volume=_:f.volume(_,o._id,!0),E&&(f._volume=_),(h<c&&_<=h||h>c&&_>=h)&&(clearInterval(o._interval),o._interval=null,o._fadeTo=null,f.volume(h,o._id),f._emit("fade",o._id))},C)},_stopFade:function(o){var c=this,h=c._soundById(o);return h&&h._interval&&(c._webAudio&&h._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(h._interval),h._interval=null,c.volume(h._fadeTo,o),h._fadeTo=null,c._emit("fade",o)),c},loop:function(){var o=this,c=arguments,h,m,S;if(c.length===0)return o._loop;if(c.length===1)if(typeof c[0]=="boolean")h=c[0],o._loop=h;else return S=o._soundById(parseInt(c[0],10)),S?S._loop:!1;else c.length===2&&(h=c[0],m=parseInt(c[1],10));for(var E=o._getSoundIds(m),f=0;f<E.length;f++)S=o._soundById(E[f]),S&&(S._loop=h,o._webAudio&&S._node&&S._node.bufferSource&&(S._node.bufferSource.loop=h,h&&(S._node.bufferSource.loopStart=S._start||0,S._node.bufferSource.loopEnd=S._stop,o.playing(E[f])&&(o.pause(E[f],!0),o.play(E[f],!0)))));return o},rate:function(){var o=this,c=arguments,h,m;if(c.length===0)m=o._sounds[0]._id;else if(c.length===1){var S=o._getSoundIds(),E=S.indexOf(c[0]);E>=0?m=parseInt(c[0],10):h=parseFloat(c[0])}else c.length===2&&(h=parseFloat(c[0]),m=parseInt(c[1],10));var f;if(typeof h=="number"){if(o._state!=="loaded"||o._playLock)return o._queue.push({event:"rate",action:function(){o.rate.apply(o,c)}}),o;typeof m>"u"&&(o._rate=h),m=o._getSoundIds(m);for(var _=0;_<m.length;_++)if(f=o._soundById(m[_]),f){o.playing(m[_])&&(f._rateSeek=o.seek(m[_]),f._playStart=o._webAudio?t.ctx.currentTime:f._playStart),f._rate=h,o._webAudio&&f._node&&f._node.bufferSource?f._node.bufferSource.playbackRate.setValueAtTime(h,t.ctx.currentTime):f._node&&(f._node.playbackRate=h);var A=o.seek(m[_]),R=(o._sprite[f._sprite][0]+o._sprite[f._sprite][1])/1e3-A,C=R*1e3/Math.abs(f._rate);(o._endTimers[m[_]]||!f._paused)&&(o._clearTimer(m[_]),o._endTimers[m[_]]=setTimeout(o._ended.bind(o,f),C)),o._emit("rate",f._id)}}else return f=o._soundById(m),f?f._rate:o._rate;return o},seek:function(){var o=this,c=arguments,h,m;if(c.length===0)o._sounds.length&&(m=o._sounds[0]._id);else if(c.length===1){var S=o._getSoundIds(),E=S.indexOf(c[0]);E>=0?m=parseInt(c[0],10):o._sounds.length&&(m=o._sounds[0]._id,h=parseFloat(c[0]))}else c.length===2&&(h=parseFloat(c[0]),m=parseInt(c[1],10));if(typeof m>"u")return 0;if(typeof h=="number"&&(o._state!=="loaded"||o._playLock))return o._queue.push({event:"seek",action:function(){o.seek.apply(o,c)}}),o;var f=o._soundById(m);if(f)if(typeof h=="number"&&h>=0){var _=o.playing(m);_&&o.pause(m,!0),f._seek=h,f._ended=!1,o._clearTimer(m),!o._webAudio&&f._node&&!isNaN(f._node.duration)&&(f._node.currentTime=h);var A=function(){_&&o.play(m,!0),o._emit("seek",m)};if(_&&!o._webAudio){var R=function(){o._playLock?setTimeout(R,0):A()};setTimeout(R,0)}else A()}else if(o._webAudio){var C=o.playing(m)?t.ctx.currentTime-f._playStart:0,L=f._rateSeek?f._rateSeek-f._seek:0;return f._seek+(L+C*Math.abs(f._rate))}else return f._node.currentTime;return o},playing:function(o){var c=this;if(typeof o=="number"){var h=c._soundById(o);return h?!h._paused:!1}for(var m=0;m<c._sounds.length;m++)if(!c._sounds[m]._paused)return!0;return!1},duration:function(o){var c=this,h=c._duration,m=c._soundById(o);return m&&(h=c._sprite[m._sprite][1]/1e3),h},state:function(){return this._state},unload:function(){for(var o=this,c=o._sounds,h=0;h<c.length;h++)c[h]._paused||o.stop(c[h]._id),o._webAudio||(o._clearSound(c[h]._node),c[h]._node.removeEventListener("error",c[h]._errorFn,!1),c[h]._node.removeEventListener(t._canPlayEvent,c[h]._loadFn,!1),c[h]._node.removeEventListener("ended",c[h]._endFn,!1),t._releaseHtml5Audio(c[h]._node)),delete c[h]._node,o._clearTimer(c[h]._id);var m=t._howls.indexOf(o);m>=0&&t._howls.splice(m,1);var S=!0;for(h=0;h<t._howls.length;h++)if(t._howls[h]._src===o._src||o._src.indexOf(t._howls[h]._src)>=0){S=!1;break}return r&&S&&delete r[o._src],t.noAudio=!1,o._state="unloaded",o._sounds=[],o=null,null},on:function(o,c,h,m){var S=this,E=S["_on"+o];return typeof c=="function"&&E.push(m?{id:h,fn:c,once:m}:{id:h,fn:c}),S},off:function(o,c,h){var m=this,S=m["_on"+o],E=0;if(typeof c=="number"&&(h=c,c=null),c||h)for(E=0;E<S.length;E++){var f=h===S[E].id;if(c===S[E].fn&&f||!c&&f){S.splice(E,1);break}}else if(o)m["_on"+o]=[];else{var _=Object.keys(m);for(E=0;E<_.length;E++)_[E].indexOf("_on")===0&&Array.isArray(m[_[E]])&&(m[_[E]]=[])}return m},once:function(o,c,h){var m=this;return m.on(o,c,h,1),m},_emit:function(o,c,h){for(var m=this,S=m["_on"+o],E=S.length-1;E>=0;E--)(!S[E].id||S[E].id===c||o==="load")&&(setTimeout((function(f){f.call(this,c,h)}).bind(m,S[E].fn),0),S[E].once&&m.off(o,S[E].fn,S[E].id));return m._loadQueue(o),m},_loadQueue:function(o){var c=this;if(c._queue.length>0){var h=c._queue[0];h.event===o&&(c._queue.shift(),c._loadQueue()),o||h.action()}return c},_ended:function(o){var c=this,h=o._sprite;if(!c._webAudio&&o._node&&!o._node.paused&&!o._node.ended&&o._node.currentTime<o._stop)return setTimeout(c._ended.bind(c,o),100),c;var m=!!(o._loop||c._sprite[h][2]);if(c._emit("end",o._id),!c._webAudio&&m&&c.stop(o._id,!0).play(o._id),c._webAudio&&m){c._emit("play",o._id),o._seek=o._start||0,o._rateSeek=0,o._playStart=t.ctx.currentTime;var S=(o._stop-o._start)*1e3/Math.abs(o._rate);c._endTimers[o._id]=setTimeout(c._ended.bind(c,o),S)}return c._webAudio&&!m&&(o._paused=!0,o._ended=!0,o._seek=o._start||0,o._rateSeek=0,c._clearTimer(o._id),c._cleanBuffer(o._node),t._autoSuspend()),!c._webAudio&&!m&&c.stop(o._id,!0),c},_clearTimer:function(o){var c=this;if(c._endTimers[o]){if(typeof c._endTimers[o]!="function")clearTimeout(c._endTimers[o]);else{var h=c._soundById(o);h&&h._node&&h._node.removeEventListener("ended",c._endTimers[o],!1)}delete c._endTimers[o]}return c},_soundById:function(o){for(var c=this,h=0;h<c._sounds.length;h++)if(o===c._sounds[h]._id)return c._sounds[h];return null},_inactiveSound:function(){var o=this;o._drain();for(var c=0;c<o._sounds.length;c++)if(o._sounds[c]._ended)return o._sounds[c].reset();return new s(o)},_drain:function(){var o=this,c=o._pool,h=0,m=0;if(!(o._sounds.length<c)){for(m=0;m<o._sounds.length;m++)o._sounds[m]._ended&&h++;for(m=o._sounds.length-1;m>=0;m--){if(h<=c)return;o._sounds[m]._ended&&(o._webAudio&&o._sounds[m]._node&&o._sounds[m]._node.disconnect(0),o._sounds.splice(m,1),h--)}}},_getSoundIds:function(o){var c=this;if(typeof o>"u"){for(var h=[],m=0;m<c._sounds.length;m++)h.push(c._sounds[m]._id);return h}else return[o]},_refreshBuffer:function(o){var c=this;return o._node.bufferSource=t.ctx.createBufferSource(),o._node.bufferSource.buffer=r[c._src],o._panner?o._node.bufferSource.connect(o._panner):o._node.bufferSource.connect(o._node),o._node.bufferSource.loop=o._loop,o._loop&&(o._node.bufferSource.loopStart=o._start||0,o._node.bufferSource.loopEnd=o._stop||0),o._node.bufferSource.playbackRate.setValueAtTime(o._rate,t.ctx.currentTime),c},_cleanBuffer:function(o){var c=this,h=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!o.bufferSource)return c;if(t._scratchBuffer&&o.bufferSource&&(o.bufferSource.onended=null,o.bufferSource.disconnect(0),h))try{o.bufferSource.buffer=t._scratchBuffer}catch{}return o.bufferSource=null,c},_clearSound:function(o){var c=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);c||(o.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var s=function(o){this._parent=o,this.init()};s.prototype={init:function(){var o=this,c=o._parent;return o._muted=c._muted,o._loop=c._loop,o._volume=c._volume,o._rate=c._rate,o._seek=0,o._paused=!0,o._ended=!0,o._sprite="__default",o._id=++t._counter,c._sounds.push(o),o.create(),o},create:function(){var o=this,c=o._parent,h=t._muted||o._muted||o._parent._muted?0:o._volume;return c._webAudio?(o._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),o._node.gain.setValueAtTime(h,t.ctx.currentTime),o._node.paused=!0,o._node.connect(t.masterGain)):t.noAudio||(o._node=t._obtainHtml5Audio(),o._errorFn=o._errorListener.bind(o),o._node.addEventListener("error",o._errorFn,!1),o._loadFn=o._loadListener.bind(o),o._node.addEventListener(t._canPlayEvent,o._loadFn,!1),o._endFn=o._endListener.bind(o),o._node.addEventListener("ended",o._endFn,!1),o._node.src=c._src,o._node.preload=c._preload===!0?"auto":c._preload,o._node.volume=h*t.volume(),o._node.load()),o},reset:function(){var o=this,c=o._parent;return o._muted=c._muted,o._loop=c._loop,o._volume=c._volume,o._rate=c._rate,o._seek=0,o._rateSeek=0,o._paused=!0,o._ended=!0,o._sprite="__default",o._id=++t._counter,o},_errorListener:function(){var o=this;o._parent._emit("loaderror",o._id,o._node.error?o._node.error.code:0),o._node.removeEventListener("error",o._errorFn,!1)},_loadListener:function(){var o=this,c=o._parent;c._duration=Math.ceil(o._node.duration*10)/10,Object.keys(c._sprite).length===0&&(c._sprite={__default:[0,c._duration*1e3]}),c._state!=="loaded"&&(c._state="loaded",c._emit("load"),c._loadQueue()),o._node.removeEventListener(t._canPlayEvent,o._loadFn,!1)},_endListener:function(){var o=this,c=o._parent;c._duration===1/0&&(c._duration=Math.ceil(o._node.duration*10)/10,c._sprite.__default[1]===1/0&&(c._sprite.__default[1]=c._duration*1e3),c._ended(o)),o._node.removeEventListener("ended",o._endFn,!1)}};var r={},a=function(o){var c=o._src;if(r[c]){o._duration=r[c].duration,u(o);return}if(/^data:[^;]+;base64,/.test(c)){for(var h=atob(c.split(",")[1]),m=new Uint8Array(h.length),S=0;S<h.length;++S)m[S]=h.charCodeAt(S);d(m.buffer,o)}else{var E=new XMLHttpRequest;E.open(o._xhr.method,c,!0),E.withCredentials=o._xhr.withCredentials,E.responseType="arraybuffer",o._xhr.headers&&Object.keys(o._xhr.headers).forEach(function(f){E.setRequestHeader(f,o._xhr.headers[f])}),E.onload=function(){var f=(E.status+"")[0];if(f!=="0"&&f!=="2"&&f!=="3"){o._emit("loaderror",null,"Failed loading audio file with status: "+E.status+".");return}d(E.response,o)},E.onerror=function(){o._webAudio&&(o._html5=!0,o._webAudio=!1,o._sounds=[],delete r[c],o.load())},l(E)}},l=function(o){try{o.send()}catch{o.onerror()}},d=function(o,c){var h=function(){c._emit("loaderror",null,"Decoding audio data failed.")},m=function(S){S&&c._sounds.length>0?(r[c._src]=S,u(c,S)):h()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(o).then(m).catch(h):t.ctx.decodeAudioData(o,m,h)},u=function(o,c){c&&!o._duration&&(o._duration=c.duration),Object.keys(o._sprite).length===0&&(o._sprite={__default:[0,o._duration*1e3]}),o._state!=="loaded"&&(o._state="loaded",o._emit("load"),o._loadQueue())},p=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var o=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),c=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),h=c?parseInt(c[1],10):null;if(o&&h&&h<9){var m=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!m&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};n.Howler=t,n.Howl=i,typeof us<"u"?(us.HowlerGlobal=e,us.Howler=t,us.Howl=i,us.Sound=s):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=i,window.Sound=s)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var i=this;if(!i.ctx||!i.ctx.listener)return i;for(var s=i._howls.length-1;s>=0;s--)i._howls[s].stereo(t);return i},HowlerGlobal.prototype.pos=function(t,i,s){var r=this;if(!r.ctx||!r.ctx.listener)return r;if(i=typeof i!="number"?r._pos[1]:i,s=typeof s!="number"?r._pos[2]:s,typeof t=="number")r._pos=[t,i,s],typeof r.ctx.listener.positionX<"u"?(r.ctx.listener.positionX.setTargetAtTime(r._pos[0],Howler.ctx.currentTime,.1),r.ctx.listener.positionY.setTargetAtTime(r._pos[1],Howler.ctx.currentTime,.1),r.ctx.listener.positionZ.setTargetAtTime(r._pos[2],Howler.ctx.currentTime,.1)):r.ctx.listener.setPosition(r._pos[0],r._pos[1],r._pos[2]);else return r._pos;return r},HowlerGlobal.prototype.orientation=function(t,i,s,r,a,l){var d=this;if(!d.ctx||!d.ctx.listener)return d;var u=d._orientation;if(i=typeof i!="number"?u[1]:i,s=typeof s!="number"?u[2]:s,r=typeof r!="number"?u[3]:r,a=typeof a!="number"?u[4]:a,l=typeof l!="number"?u[5]:l,typeof t=="number")d._orientation=[t,i,s,r,a,l],typeof d.ctx.listener.forwardX<"u"?(d.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),d.ctx.listener.forwardY.setTargetAtTime(i,Howler.ctx.currentTime,.1),d.ctx.listener.forwardZ.setTargetAtTime(s,Howler.ctx.currentTime,.1),d.ctx.listener.upX.setTargetAtTime(r,Howler.ctx.currentTime,.1),d.ctx.listener.upY.setTargetAtTime(a,Howler.ctx.currentTime,.1),d.ctx.listener.upZ.setTargetAtTime(l,Howler.ctx.currentTime,.1)):d.ctx.listener.setOrientation(t,i,s,r,a,l);else return u;return d},Howl.prototype.init=(function(t){return function(i){var s=this;return s._orientation=i.orientation||[1,0,0],s._stereo=i.stereo||null,s._pos=i.pos||null,s._pannerAttr={coneInnerAngle:typeof i.coneInnerAngle<"u"?i.coneInnerAngle:360,coneOuterAngle:typeof i.coneOuterAngle<"u"?i.coneOuterAngle:360,coneOuterGain:typeof i.coneOuterGain<"u"?i.coneOuterGain:0,distanceModel:typeof i.distanceModel<"u"?i.distanceModel:"inverse",maxDistance:typeof i.maxDistance<"u"?i.maxDistance:1e4,panningModel:typeof i.panningModel<"u"?i.panningModel:"HRTF",refDistance:typeof i.refDistance<"u"?i.refDistance:1,rolloffFactor:typeof i.rolloffFactor<"u"?i.rolloffFactor:1},s._onstereo=i.onstereo?[{fn:i.onstereo}]:[],s._onpos=i.onpos?[{fn:i.onpos}]:[],s._onorientation=i.onorientation?[{fn:i.onorientation}]:[],t.call(this,i)}})(Howl.prototype.init),Howl.prototype.stereo=function(t,i){var s=this;if(!s._webAudio)return s;if(s._state!=="loaded")return s._queue.push({event:"stereo",action:function(){s.stereo(t,i)}}),s;var r=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof i>"u")if(typeof t=="number")s._stereo=t,s._pos=[t,0,0];else return s._stereo;for(var a=s._getSoundIds(i),l=0;l<a.length;l++){var d=s._soundById(a[l]);if(d)if(typeof t=="number")d._stereo=t,d._pos=[t,0,0],d._node&&(d._pannerAttr.panningModel="equalpower",(!d._panner||!d._panner.pan)&&e(d,r),r==="spatial"?typeof d._panner.positionX<"u"?(d._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),d._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),d._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):d._panner.setPosition(t,0,0):d._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),s._emit("stereo",d._id);else return d._stereo}return s},Howl.prototype.pos=function(t,i,s,r){var a=this;if(!a._webAudio)return a;if(a._state!=="loaded")return a._queue.push({event:"pos",action:function(){a.pos(t,i,s,r)}}),a;if(i=typeof i!="number"?0:i,s=typeof s!="number"?-.5:s,typeof r>"u")if(typeof t=="number")a._pos=[t,i,s];else return a._pos;for(var l=a._getSoundIds(r),d=0;d<l.length;d++){var u=a._soundById(l[d]);if(u)if(typeof t=="number")u._pos=[t,i,s],u._node&&((!u._panner||u._panner.pan)&&e(u,"spatial"),typeof u._panner.positionX<"u"?(u._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.positionY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.positionZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setPosition(t,i,s)),a._emit("pos",u._id);else return u._pos}return a},Howl.prototype.orientation=function(t,i,s,r){var a=this;if(!a._webAudio)return a;if(a._state!=="loaded")return a._queue.push({event:"orientation",action:function(){a.orientation(t,i,s,r)}}),a;if(i=typeof i!="number"?a._orientation[1]:i,s=typeof s!="number"?a._orientation[2]:s,typeof r>"u")if(typeof t=="number")a._orientation=[t,i,s];else return a._orientation;for(var l=a._getSoundIds(r),d=0;d<l.length;d++){var u=a._soundById(l[d]);if(u)if(typeof t=="number")u._orientation=[t,i,s],u._node&&(u._panner||(u._pos||(u._pos=a._pos||[0,0,-.5]),e(u,"spatial")),typeof u._panner.orientationX<"u"?(u._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),u._panner.orientationY.setValueAtTime(i,Howler.ctx.currentTime),u._panner.orientationZ.setValueAtTime(s,Howler.ctx.currentTime)):u._panner.setOrientation(t,i,s)),a._emit("orientation",u._id);else return u._orientation}return a},Howl.prototype.pannerAttr=function(){var t=this,i=arguments,s,r,a;if(!t._webAudio)return t;if(i.length===0)return t._pannerAttr;if(i.length===1)if(typeof i[0]=="object")s=i[0],typeof r>"u"&&(s.pannerAttr||(s.pannerAttr={coneInnerAngle:s.coneInnerAngle,coneOuterAngle:s.coneOuterAngle,coneOuterGain:s.coneOuterGain,distanceModel:s.distanceModel,maxDistance:s.maxDistance,refDistance:s.refDistance,rolloffFactor:s.rolloffFactor,panningModel:s.panningModel}),t._pannerAttr={coneInnerAngle:typeof s.pannerAttr.coneInnerAngle<"u"?s.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof s.pannerAttr.coneOuterAngle<"u"?s.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof s.pannerAttr.coneOuterGain<"u"?s.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof s.pannerAttr.distanceModel<"u"?s.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof s.pannerAttr.maxDistance<"u"?s.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof s.pannerAttr.refDistance<"u"?s.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof s.pannerAttr.rolloffFactor<"u"?s.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof s.pannerAttr.panningModel<"u"?s.pannerAttr.panningModel:t._panningModel});else return a=t._soundById(parseInt(i[0],10)),a?a._pannerAttr:t._pannerAttr;else i.length===2&&(s=i[0],r=parseInt(i[1],10));for(var l=t._getSoundIds(r),d=0;d<l.length;d++)if(a=t._soundById(l[d]),a){var u=a._pannerAttr;u={coneInnerAngle:typeof s.coneInnerAngle<"u"?s.coneInnerAngle:u.coneInnerAngle,coneOuterAngle:typeof s.coneOuterAngle<"u"?s.coneOuterAngle:u.coneOuterAngle,coneOuterGain:typeof s.coneOuterGain<"u"?s.coneOuterGain:u.coneOuterGain,distanceModel:typeof s.distanceModel<"u"?s.distanceModel:u.distanceModel,maxDistance:typeof s.maxDistance<"u"?s.maxDistance:u.maxDistance,refDistance:typeof s.refDistance<"u"?s.refDistance:u.refDistance,rolloffFactor:typeof s.rolloffFactor<"u"?s.rolloffFactor:u.rolloffFactor,panningModel:typeof s.panningModel<"u"?s.panningModel:u.panningModel};var p=a._panner;p||(a._pos||(a._pos=t._pos||[0,0,-.5]),e(a,"spatial"),p=a._panner),p.coneInnerAngle=u.coneInnerAngle,p.coneOuterAngle=u.coneOuterAngle,p.coneOuterGain=u.coneOuterGain,p.distanceModel=u.distanceModel,p.maxDistance=u.maxDistance,p.refDistance=u.refDistance,p.rolloffFactor=u.rolloffFactor,p.panningModel=u.panningModel}return t},Sound.prototype.init=(function(t){return function(){var i=this,s=i._parent;i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,t.call(this),i._stereo?s.stereo(i._stereo):i._pos&&s.pos(i._pos[0],i._pos[1],i._pos[2],i._id)}})(Sound.prototype.init),Sound.prototype.reset=(function(t){return function(){var i=this,s=i._parent;return i._orientation=s._orientation,i._stereo=s._stereo,i._pos=s._pos,i._pannerAttr=s._pannerAttr,i._stereo?s.stereo(i._stereo):i._pos?s.pos(i._pos[0],i._pos[1],i._pos[2],i._id):i._panner&&(i._panner.disconnect(0),i._panner=void 0,s._refreshBuffer(i)),t.call(this)}})(Sound.prototype.reset);var e=function(t,i){i=i||"spatial",i==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()})(mo)),mo}var YS=kS();function Ei(n){return n[Math.floor(Math.random()*n.length)]}function ou(n,e=10){const t=1/(1+Math.exp(e*.5)),i=1/(1+Math.exp(-e*.5));return(1/(1+Math.exp(-e*(n-.5)))-t)/(i-t)}function WS(n){let e=n.length,t;for(;e>0;)t=Math.floor(Math.random()*e),e--,[n[e],n[t]]=[n[t],n[e]];return n}const zS=["click_002.ogg"],rc=["spinner","sound-effects","letter-geometries","word-geometries","title-image","title-base-layer","title-side-layer","title-dilate-0","title-dilate-1","title-dilate-2","title-dilate-3","title-dilate-4","title-dilate-5","title-dilate-6","title-dilate-7","title-dilate-8","title-dilate-9","title-top-layer","title-finalize"],oc={spinner:0,"sound-effects":10,"letter-geometries":204,"word-geometries":204,"title-image":6,"title-base-layer":437,"title-side-layer":408,"title-dilate-0":16,"title-dilate-1":20,"title-dilate-2":20,"title-dilate-3":18,"title-dilate-4":17,"title-dilate-5":13,"title-dilate-6":13,"title-dilate-7":12,"title-dilate-8":12,"title-dilate-9":13,"title-top-layer":427,"title-finalize":4},au=new Map;function ac(){return new Promise(n=>{requestAnimationFrame(()=>n())})}function _n(n,e){au.set(n,e)}async function KS(n){const e=rc.reduce((s,r)=>s+(oc[r]??0),0);let t=0;const i=new Map;for(const s of rc){const r=au.get(s),a=performance.now();r&&await r();const l=performance.now()-a;i.set(s,Math.round(l)),t+=oc[s]??l,e>0&&(n(Math.round(100*t/e)),await ac())}n(100),await ac()}const lc=new Map;_n("sound-effects",XS);async function XS(){zS.map(async n=>{lc.set(n,new YS.Howl({src:[`sounds/${n}`],format:["ogg"]}))}),await Promise.all(Object.values(lc).map(n=>new Promise((e,t)=>{const i=n;i.once("load",e),i.once("loaderror",()=>{t()})})))}const qS=`aback
abaft
abase
abate
abbey
abbot
abhor
abide
abler
abode
about
above
abuse
abyss
ached
aches
acids
acorn
acres
acrid
acted
actor
acute
adage
adapt
added
adder
adept
adieu
admit
adobe
adopt
adore
adorn
adult
aegis
aeons
affix
afire
afoot
after
again
agape
agate
agent
agile
aging
aglow
agony
agree
ahead
aided
aides
ailed
aimed
aired
aisle
alarm
album
alder
alert
alias
alibi
alien
alike
alive
allay
alley
allot
allow
alloy
aloes
aloft
alone
along
aloof
aloud
alpha
altar
alter
altos
amass
amaze
amber
amble
amend
amigo
amiss
amity
among
amour
ample
amply
amuse
angel
anger
angle
angry
angst
anime
ankle
annex
annoy
annul
antes
antic
anvil
apace
apart
aping
appal
apple
apply
apron
aptly
areas
arena
argue
arise
armed
aroma
arose
array
arrow
arson
ashen
ashes
aside
asked
askew
aspen
assay
asses
asset
atlas
atoll
atoms
atone
attic
audio
audit
auger
aught
augur
aunts
auras
autos
avail
avert
avoid
avows
await
awake
award
aware
awful
awoke
axiom
axles
azure
babel
babes
backs
bacon
badge
badly
baggy
baits
baize
baked
baker
bales
balls
balmy
banal
bands
bandy
bangs
banjo
banks
barbs
bards
bared
barge
barks
barns
baron
basal
based
baser
bases
basic
basil
basin
basis
baste
batch
bated
bathe
baths
baton
bayou
beach
beads
beady
beaks
beams
beans
beard
bears
beast
beaux
beech
beets
befit
began
begat
beget
begin
begot
begun
being
belie
belle
bells
belly
below
belts
bench
bends
bergs
berry
berth
beryl
beset
bevel
bible
bides
bight
bigot
bilge
bills
billy
binds
biped
birch
birds
birth
bison
bites
black
blade
blame
bland
blank
blare
blast
blaze
bleak
bleat
bleed
blend
bless
blest
blind
blink
bliss
block
blond
blood
bloom
blots
blown
blows
bluer
blues
bluff
blunt
blurt
blush
board
boars
boast
boats
boded
bodes
boggy
bogus
boils
boles
bolts
bombs
bonds
boned
bones
bonny
bonus
booby
books
booms
boons
boors
boost
booth
boots
booty
booze
borax
bored
bores
bosom
bough
bound
bouts
bowed
bowel
bower
bowls
boxed
boxer
boxes
brace
brags
braid
brain
brake
brand
brass
brats
brave
bravo
brawl
brawn
bread
break
breed
briar
bribe
brick
bride
brief
brier
brigs
brims
brine
bring
brink
briny
brisk
broad
broil
broke
brood
brook
broom
broth
brown
brows
bruin
brunt
brush
brute
bucks
budge
buggy
bugle
build
built
bulbs
bulge
bulks
bulky
bulls
bully
bumps
bunch
bunks
buoys
burly
burns
burnt
burrs
burst
bushy
busts
butte
butts
buxom
buyer
cabal
cabby
cabin
cable
cacao
cache
cadet
cadre
caged
cages
cairn
caked
cakes
calls
calms
camel
cameo
camps
canal
candy
canes
canny
canoe
canon
canto
caper
capes
capon
cards
cared
cares
cargo
carol
carry
carts
carve
cased
cases
casks
caste
casts
catch
cater
cause
caved
caves
cavil
cease
cedar
ceded
cells
cents
chafe
chaff
chain
chair
chalk
champ
chant
chaos
chaps
charm
chart
chary
chase
chasm
chats
cheap
cheat
check
cheek
cheer
chefs
chess
chest
chick
chide
chief
child
chill
chime
china
chink
chins
chips
chirp
choir
choke
chops
chord
chose
chuck
chump
chums
chunk
churn
chute
cider
cigar
cinch
circa
cited
cites
civic
civil
clack
claim
clamp
clams
clang
clank
clans
claps
clash
clasp
class
claws
clean
clear
clefs
cleft
clerk
clews
click
cliff
climb
clime
cling
clink
clips
cloak
clock
clods
clogs
close
cloth
cloud
clout
clove
clown
clubs
cluck
clues
clump
clung
coach
coals
coast
coats
cobra
cocks
cocoa
codes
coils
coins
colds
colic
colon
colts
combs
comer
comes
comet
comic
comma
conch
cones
conic
cooed
cooks
cools
copse
coral
cords
cores
corks
corns
corps
costs
couch
cough
could
count
coupe
coups
court
cover
coves
covet
cowed
cower
coyly
crabs
crack
craft
crags
cramp
crane
crank
crape
crash
crass
crate
crave
crawl
craze
crazy
creak
cream
credo
creed
creek
creep
crepe
crept
cress
crest
crews
cribs
crick
cried
crier
cries
crime
crimp
crisp
croak
crock
crone
crony
crook
crops
cross
croup
crowd
crown
crows
crude
cruel
crumb
crush
crust
crypt
cubes
cubic
cubit
cuffs
cults
curds
cured
cures
curls
curly
curry
curse
curve
cycle
cynic
daddy
daily
dairy
daisy
dales
dally
dames
damps
dance
dandy
dared
dares
darts
dated
dates
datum
daubs
daunt
dawns
dazed
deals
dealt
deans
dears
death
debar
debit
debts
debut
decay
decks
decoy
decry
deeds
deems
deeps
defer
deign
deity
delay
dells
delta
delve
demon
demur
dense
dents
depot
depth
derby
desks
deter
deuce
devil
diary
diced
dices
dicta
diets
digit
dikes
dimes
dimly
dined
diner
dines
dingy
dirge
dirty
disks
ditch
ditto
ditty
divan
dived
diver
dives
dizzy
docks
dodge
doers
dogma
doing
doled
dolls
domed
domes
donor
dooms
doors
dosed
doses
doted
dotes
doubt
dough
doves
downs
downy
dowry
dozed
dozen
draft
drags
drain
drake
drama
drams
drank
drape
drawl
drawn
draws
dread
dream
dregs
dress
dried
drier
dries
drift
drill
drily
drink
drips
drive
droll
drone
droop
drops
dross
drove
drown
drugs
drums
drunk
dryly
ducks
ducts
duels
duets
dukes
dully
dummy
dumps
dumpy
dunce
dunes
duped
dupes
dusky
dusty
dwarf
dwell
dwelt
dying
dykes
eager
eagle
earls
early
earns
earth
eased
easel
eases
eaten
eater
eaves
ebbed
ebony
edged
edges
edict
edify
eerie
egged
eight
eject
elate
elbow
elder
elect
elegy
elfin
elite
elope
elude
elves
email
emits
empty
enact
ended
endow
enemy
enjoy
ensue
enter
entry
envoy
epics
epoch
equal
equip
erase
erect
erred
error
essay
ether
ethic
evade
event
every
evils
evoke
exact
exalt
excel
exert
exile
exist
exits
expel
extol
extra
exult
fable
faced
faces
facts
faded
fades
fails
faint
fairs
fairy
faith
falls
false
famed
fancy
fangs
farce
fared
fares
farms
fasts
fatal
fated
fates
fatty
fault
fauna
fauns
fawns
fears
feast
feats
feeds
feels
feign
feint
fells
felon
fence
feral
ferns
ferry
fetch
fetid
fetus
feuds
fever
fewer
fiefs
field
fiend
fiery
fifes
fifth
fifty
fight
filch
filed
files
filet
fills
filly
films
filmy
filth
final
finch
finds
fined
finer
fines
fired
fires
firms
first
fishy
fists
fitly
fives
fixed
fixer
fixes
fjord
flags
flail
flair
flake
flaky
flame
flank
flaps
flare
flash
flask
flats
flaws
fleas
fleck
flees
fleet
flesh
flick
flier
flies
fling
flint
flirt
flits
float
flock
floes
flood
floor
flora
floss
flour
flout
flown
flows
flues
fluff
fluid
fluke
flume
flung
flush
flute
flyer
foams
foamy
focal
focus
foggy
foils
foist
folds
folio
folks
folly
foods
fools
foray
force
fords
forge
forgo
forks
forms
forte
forth
forts
forty
forum
found
fount
fours
fowls
foxes
foyer
frail
frame
franc
frank
fraud
freak
freed
freer
frees
fresh
frets
friar
fried
frill
frisk
frock
frogs
front
frost
froth
frown
froze
fruit
fudge
fuels
fugue
fully
fumed
fumes
funds
fungi
funny
furry
furze
fused
fuses
fussy
fuzzy
gable
gaily
gains
gales
galls
games
gamin
gamma
gamut
gangs
gaped
gapes
gases
gasps
gates
gaudy
gauge
gaunt
gauze
gauzy
gavel
gawky
gayer
gayly
gazed
gazer
gazes
gears
geese
genie
genre
gents
genus
germs
ghost
giant
gibes
giddy
gifts
gilds
gills
gimme
girds
girls
girth
given
gives
glade
gland
glare
glass
glaze
gleam
glean
glens
glide
glint
gloat
globe
gloom
glory
gloss
glove
glows
glued
gnash
gnats
gnaws
gnome
goads
goals
goats
godly
going
golly
gongs
gonna
goods
goody
goose
gored
gorge
gouge
gourd
gowns
grabs
grace
grade
graft
grain
grams
grand
grant
grape
graph
grasp
grass
grate
grave
gravy
graze
great
greed
green
greet
greys
grief
grill
grime
grimy
grind
grins
gripe
grips
groan
groin
groom
grope
gross
group
grove
growl
grown
grows
grubs
gruel
gruff
grunt
guano
guard
guess
guest
guide
guild
guile
guilt
guise
gulch
gulfs
gulls
gully
gummy
gusto
gusts
gusty
habit
hacks
hails
hairs
hairy
haled
halls
halts
halve
hands
handy
hangs
happy
hardy
harem
hares
harms
harps
harpy
harry
harsh
harts
haste
hasty
hatch
hated
hater
hauls
haven
havoc
hawks
hazel
heads
heady
heals
heaps
heard
hears
heart
heath
heats
heave
heavy
hedge
heeds
heels
heirs
helix
hello
helms
helps
hence
herbs
herds
heron
heros
hewed
hides
hills
hilly
hilts
hinds
hinge
hints
hired
hires
hitch
hives
hoard
hoary
hobby
hoist
holds
holes
holly
homes
honey
hoods
hoofs
hooks
hoops
hoots
hoped
hopes
horde
horns
horny
horse
hosts
hotel
hotly
hound
hours
house
hovel
hover
howls
hulks
hulls
human
humid
humps
humus
hunch
hunts
hurls
hurry
hurts
husks
husky
hussy
hydra
hyena
hymns
icily
icing
ideal
ideas
idiom
idiot
idled
idler
idols
idyll
igloo
image
imbue
impel
imply
inane
incur
index
inept
inert
infer
ingot
inlet
inner
inter
inure
irate
irked
irons
irony
isles
islet
issue
items
ivory
jacks
jaded
jails
jaunt
jeans
jeers
jelly
jerks
jerky
jests
jetty
jewel
jiffy
joins
joint
joked
joker
jokes
jolly
joust
joyed
judge
juice
juicy
jumps
junks
junta
juror
karma
keels
keeps
keyed
khaki
kicks
kills
kinds
kings
kiosk
kites
knack
knave
knead
kneel
knees
knell
knelt
knife
knits
knobs
knock
knoll
knots
known
knows
label
laced
laces
lacks
laden
ladle
lager
lairs
laity
lakes
lambs
lamed
lames
lamps
lance
lands
lanes
lanky
lapel
lapse
larch
large
largo
larks
larva
lasso
lasts
latch
later
lathe
laugh
lawns
layer
leads
leafy
leaks
leaky
leans
leaps
leapt
learn
lease
leash
least
leave
ledge
leech
leeks
legal
lemme
lemon
lends
leper
levee
level
lever
liars
libel
licks
liege
liens
lifts
light
liked
liken
liker
likes
lilac
limbo
limbs
limes
limit
lined
linen
liner
lines
lingo
links
lions
lists
lithe
lived
liver
lives
livid
llama
loads
loamy
loans
loath
lobby
lobes
local
locks
locus
lodge
lofty
logic
login
loins
longs
looks
looms
loons
loops
loose
lords
loser
loses
lotus
louse
lousy
loved
lover
loves
lowed
lower
lowly
loyal
lucid
lucky
lulls
lumps
lumpy
lunar
lunch
lunge
lungs
lurch
lured
lures
lurid
lurks
lusts
lusty
lutes
lying
lymph
lynch
lyric
maces
madam
madly
magic
maids
mails
maize
major
maker
makes
males
mamma
manes
manga
mange
mango
mangy
mania
manly
manor
maple
march
mares
marks
marry
marsh
marts
masks
mason
masts
match
mated
mates
mauve
maxim
maybe
mayor
mazes
meals
mealy
means
meant
meats
medal
media
meets
melon
melts
memes
mends
menus
mercy
meres
merge
merit
merry
mesas
metal
meted
meter
mewed
midst
miens
might
miles
milky
mills
mimes
mimic
mince
minds
mined
miner
mines
minor
mints
minus
mirth
miser
mists
mites
mixed
mixes
moans
moats
mocks
model
modem
modes
mogul
moist
molar
moles
momma
money
monks
month
moods
moody
moons
moors
moose
moped
moral
mores
mossy
motes
moths
motif
motor
motto
mound
mount
mourn
mouse
mouth
moved
mover
moves
movie
mowed
mower
mucus
muddy
mules
mummy
mumps
munch
mural
murky
mused
muses
music
musky
musty
muted
mutes
myrrh
myths
nails
naive
naked
named
names
nasal
nasty
natal
natty
naval
navel
naves
nears
necks
needs
needy
neigh
nerve
nests
never
newer
newly
nicer
niche
niece
night
ninny
noble
nobly
noise
noisy
nomad
nonce
nooks
noose
north
nosed
noses
notch
noted
notes
nouns
novel
nudge
nurse
nymph
oaken
oases
oasis
oaten
oaths
obese
obeys
occur
ocean
ochre
odder
oddly
odium
offer
often
oiled
olden
older
omens
omits
onion
onset
oozed
oozes
opals
opens
opera
opine
opium
optic
orbit
order
organ
other
otter
ought
ounce
outdo
outer
ovals
ovary
ovens
overt
owing
owned
owner
oxide
ozone
paces
packs
paddy
padre
pagan
pages
pails
pains
paint
pairs
paled
paler
pales
palms
palmy
palsy
panel
panes
pangs
panic
pansy
pants
papal
papas
paper
pared
parka
parks
parry
parse
parts
party
paste
pasty
patch
pates
paths
patio
pause
paved
pawed
pawns
payed
payer
peace
peach
peaks
peals
pearl
pears
pecks
pedal
peeps
peers
pelts
penal
pence
penny
peons
perch
peril
pesky
pesos
pests
petal
petty
phase
phial
phone
photo
piano
picks
piece
piers
piety
pigmy
pikes
piled
piles
pills
pilot
pinch
pined
pines
pinks
pinto
pints
pious
piped
piper
pipes
pique
pitch
pithy
pivot
place
plaid
plain
plait
plane
plank
plans
plant
plate
plays
plaza
plead
pleas
plied
plies
plots
pluck
plugs
plumb
plume
plums
plush
podia
poems
poesy
poets
point
poise
poked
poker
pokes
polar
poles
polka
polls
ponds
pools
popes
poppa
poppy
porch
pored
pores
ports
posed
poser
poses
posse
posts
pouch
pound
pours
power
prank
prate
prays
press
preys
price
prick
pride
pried
pries
prime
print
prior
prism
privy
prize
probe
prone
proof
props
prose
prosy
proud
prove
prowl
prows
proxy
prude
prune
psalm
pshaw
pudgy
puffs
puffy
pulls
pulpy
pulse
pumps
punch
pupil
puppy
puree
purer
purge
purse
pussy
putty
quack
quaff
quail
quake
qualm
quart
quasi
quays
queen
queer
quell
query
quest
queue
quick
quiet
quill
quilt
quips
quire
quite
quits
quota
quote
quoth
rabbi
rabid
raced
racer
races
racks
radii
radio
rafts
raged
rages
raids
rails
rains
rainy
raise
rajah
raked
rakes
rally
ranch
range
ranks
rapid
rarer
rares
rated
rates
ratio
raved
raven
raves
rayon
razed
razor
reach
react
reads
ready
realm
reals
reams
reaps
rears
rebel
rebus
rebut
recur
reeds
reedy
reefs
reeks
reels
reeve
refer
refit
regal
reign
reins
relax
relay
relic
remit
rends
renew
rents
repay
repel
reply
reset
resin
rests
revel
rhyme
rider
rides
ridge
rifle
rifts
right
rigid
riled
rimes
rings
rinse
riots
ripen
riper
risen
riser
rises
risks
risky
rites
rival
riven
river
rivet
roads
roams
roars
roast
robed
robes
robin
rocks
rocky
rogue
roles
rolls
roman
roofs
rooks
rooms
roomy
roost
roots
roped
ropes
roses
rosin
rouge
rough
round
rouse
route
routs
roved
rover
rowdy
rowed
royal
ruder
ruins
ruled
ruler
rules
runes
rungs
rupee
rural
ruses
sable
sabre
sacks
sadly
safer
sagas
sages
sails
saint
salad
sales
sally
salon
salsa
salts
salty
salve
salvo
sands
sandy
saner
sated
satin
satyr
sauce
saucy
saved
saves
sawed
scald
scale
scalp
scaly
scans
scant
scare
scarf
scars
scene
scent
scion
scoff
scold
scoop
scope
score
scorn
scour
scout
scowl
scrap
screw
scrip
scrub
scull
seals
seams
seamy
seats
sects
seeds
seedy
seeks
seems
seers
seize
sells
sends
sense
serfs
serum
serve
seven
sever
sewed
sewer
sexes
shack
shade
shady
shaft
shake
shaky
shale
shall
shalt
shame
shams
shank
shape
share
shark
sharp
shave
shawl
sheaf
shear
sheds
sheen
sheep
sheer
sheet
sheik
shelf
shell
shied
shift
shine
shins
shiny
ships
shire
shirk
shirt
shoal
shock
shoes
shone
shook
shoon
shoot
shops
shore
shorn
short
shots
shout
shove
shown
shows
showy
shred
shrew
shrub
shrug
shuns
shuts
shyly
sided
sides
siege
sieve
sighs
sight
sigma
signs
silks
silky
sills
silly
since
sinew
singe
sings
sinks
siren
sires
sites
sixes
sixth
sixty
sized
sizes
skate
skies
skiff
skill
skims
skins
skips
skirt
skulk
skull
skunk
slabs
slack
slags
slain
slang
slant
slaps
slash
slate
slats
slave
slays
sleds
sleek
sleep
sleet
slept
slice
slick
slide
slime
slimy
sling
slink
slips
slits
slope
sloth
slugs
slump
slums
slung
slush
slyly
smack
small
smart
smash
smear
smell
smelt
smile
smirk
smite
smith
smock
smoke
smoky
smote
snack
snags
snail
snake
snaky
snaps
snare
snarl
sneak
sneer
sniff
snipe
snobs
snore
snort
snout
snows
snowy
soapy
soars
sober
socks
sofas
soggy
soils
solar
soles
solid
solos
solve
songs
sonny
sooth
sooty
sores
sorry
sorts
souls
sound
soups
south
sowed
sower
space
spade
spank
spans
spare
spark
spars
spasm
spawn
speak
spear
speck
speed
spell
spelt
spend
spent
sperm
spice
spicy
spied
spies
spike
spill
spilt
spine
spins
spiny
spire
spite
spits
split
spoil
spoke
spook
spool
spoon
spore
sport
spots
spout
spray
spree
sprig
spunk
spurn
spurs
spurt
squad
squat
squaw
stabs
stack
staff
stage
stags
staid
stain
stair
stake
stale
stalk
stall
stamp
stand
stank
stare
stark
stars
start
state
stave
stays
stead
steak
steal
steam
steed
steel
steep
steer
stems
steps
stern
stews
stick
stiff
stile
still
sting
stink
stint
stirs
stock
stoic
stole
stone
stony
stood
stool
stoop
stops
store
stork
storm
story
stout
stove
strap
straw
stray
strew
strip
strut
stuck
studs
study
stuff
stump
stung
stunt
style
suave
sucks
sugar
suing
suite
suits
sulks
sulky
sully
sunny
super
surer
surge
surly
swain
swamp
swans
sward
swarm
sways
swear
sweat
sweep
sweet
swell
swept
swift
swill
swims
swine
swing
swirl
swish
swoon
swoop
sword
swore
sworn
swung
syrup
tabby
table
taboo
tacit
tacks
tails
taint
taken
takes
tales
talks
tally
talon
tamed
tamer
tanks
taper
tapes
tardy
tarry
tarts
tasks
taste
tasty
taunt
tawny
taxed
taxes
teach
teams
tears
tease
teems
teens
teeth
tells
tempo
tends
tenet
tenor
tense
tenth
tents
tepid
terms
terse
tests
testy
texts
thank
theft
their
theme
there
these
thick
thief
thigh
thine
thing
think
third
thong
thorn
those
three
threw
throb
throe
throw
thumb
thump
thyme
tiara
tibia
ticks
tidal
tides
tiers
tiger
tight
tilde
tiled
tiles
tills
tilts
timed
times
timid
tinge
tints
tipsy
tired
tires
tithe
title
toads
toast
today
toddy
toils
token
tolls
tombs
tomes
toned
tones
tongs
tonic
tools
tooth
topaz
topic
torch
torso
total
totem
touch
tough
tours
towed
towel
tower
towns
toxic
toyed
trace
track
tract
trade
trail
train
trait
tramp
trams
traps
trash
trays
tread
treat
treed
trees
trend
tress
triad
trial
tribe
trice
trick
tried
tries
trill
tripe
trips
trite
troll
troop
troth
trots
trout
truce
truck
truer
truly
trump
trunk
truss
trust
truth
tryst
tubes
tufts
tulip
tulle
tuned
tunes
tunic
turns
tusks
tutor
twain
twang
tweed
twice
twigs
twine
twins
twirl
twist
tying
typed
types
udder
ulcer
ultra
uncle
uncut
under
undid
undue
unfit
union
unite
units
unity
unsay
untie
until
upper
upset
urban
urged
urges
urine
usage
users
usher
using
usual
usurp
utter
vague
vales
valet
valid
value
valve
vanes
vapid
vases
vault
vaunt
veils
veins
veldt
venom
vents
venue
verbs
verge
verse
verve
vests
vexed
vexes
vials
vicar
vices
video
views
vigil
viler
villa
vines
viola
viper
virus
visit
visor
vista
vital
vivid
vixen
vizor
vocal
vodka
vogue
voice
voile
volts
vomit
voted
voter
votes
vouch
vowed
vowel
vying
waded
wafer
wafts
waged
wager
wages
wagon
waifs
wails
waist
waits
waive
waked
waken
wakes
walks
walls
waltz
wands
waned
wanes
wants
wards
wares
warms
warns
warts
wasps
waste
watch
water
waved
waver
waves
waxed
waxen
waxes
wears
weary
weave
wedge
weeds
weedy
weeks
weeps
weigh
weird
welch
wells
wench
whack
whale
wharf
wheat
wheel
whelp
where
which
whiff
while
whims
whine
whips
whirl
whisk
white
whole
whoop
whose
wicks
widen
wider
widow
width
wield
wight
wilds
wiles
wills
wince
winch
winds
windy
wines
wings
winks
wiped
wipes
wired
wires
wiser
wisps
witch
witty
wives
woman
women
woods
woody
wooed
wooer
words
wordy
works
world
worms
worry
worse
worst
worth
would
wound
wrack
wraps
wrapt
wrath
wreak
wreck
wrest
wring
wrist
write
writs
wrong
wrote
wroth
yacht
yards
yarns
yawns
yearn
years
yeast
yells
yelps
yield
yoked
yokes
yolks
young
yours
youth
zebra
zones`,So=["ASKEWB N RU O ISATINE S G","FITLYI E OF A KTERSEY S D","WRESTA L ATUFTSC I THONEY","GALESL E TI A ANEVERT E T","HEARDA I EW L FK E ES D R","PAWEDO  T SIGHSS  I EPICS","VALESE O UR O IVISITE E S","CIDERH O AA O PS M IMUSED","VASESA H  LUREDU E  ENDOW","FIFESO R PX I IEXALTS R E","STARTP B UI H RTHORNE R S","CHUCKL  U O  L WORTHN  S ","MEETSA X KC I UEASELS T L","STALKP    OASISR    TOADS","OWNEDO   IZ   KELITED   S","PAVEDL I AA X MI E PTENTS","HEWEDO E OTOASTE V EL E D","RULESE U LPURSEL E PY S T","TRITEO G IM L GEPOCHS O T","STORYT V EE E AERRORP T S","OASISA T HTHEREH A AS M F","INNERS   OLINGOE   STIGHT","LAMPSA  A REAPSG  E OVARY","AROSEU   ADALESI   EOWNED","DREAMU A ILIGHTL E EYARDS","SCOURL   IAWARDT   ESEXES","SPURTO N EGASESG A TY Y Y","FLOSSE   HW   IEAGERR   E","STOVEL  I ABLERN  W TRASH","BASINL T  USERSE R  RANCH","ROOSTE U AE T MLADLES O D","NECKSU O CR M OS E LEASED","ADMITM E AE A SN N TD S E","PEACHL L EALTARY A OSIREN","WEEKSO    ROAMSD    SQUAW","LOGICO U  WASPSE T  DRYLY","SPICYP  U AWARER  S KEYED","LINEDU E RC V II E EDARES","MASONI H ESHAREE R DROPES","CHUMPH   OASSESI   SROUGE","SLEETE  Q ENSUER  A STILL","GRANDR   OUNCLEB   RSKIMS","GLEANA  C S  R PANELS  S ","KINGSN  U EQUALL  N LEMON","BORAXL  C AFOOTZ  R EARNS","LUCKYA U ON B KKNIFEY C S","NEARSE  A STUNTT  C SIGHS","SEAMSK  O IGLOOR  R TORSO","BOREDO O AD U REIGHTD H S","WOMENO E EM N EADDEDN S Y","DRAMSW L LE O ULANEST E H","WAFERA   ESCRUBP   USOULS","ALPHAL A XD N LE I ERACKS","RATEDE I IELDERK E GS S E","TWICER D EU Y RS L ITILDE","BRICKE    GOINGU    NOOKS","KIOSKN  L E  O LEAPSL  E ","LATHEU   RNEVERG   ESPIED","SLOPEN    ABOUTR    LOANS","FILEDL E RU A YNAVALG E Y","VALETO    MAJORI    TRUMP","FOODSO O II Z GSPERMT S A","BUTTSR O KO N UW G LNASAL","CRYPTH   RE   OF   OSLEEP","THUMBA N OK I REXTRAS E X","PLANSL T LA O UCOMBSE S H","DELVEO A MC R PK G TSEEDY","LOYALU  T S  O TRAMSS  S ","PRUDEO N DL C ILILACS E T","PODIAA E MY T IE E TDIRTY","BROILA P  KITESE I  RACED","BIRDSE A IAUGHTD E ESIDES","GREEDO X OR T WGROWNE L S","SINEWH    OUGHTW    YOUNG","DENTSO A HZ T OEATERN Y N","GRILLO S UW S MN U PSHEDS","CAGESL  V ISLESN  N GUSTY","GALLSR E TINANEE S AF E M","SOOTYO  A W  R EMITSR  S ","IRONSN D  EPICSP U  TOMBS","GROWSL N  OMITSW O  SONGS","HANDSE   AALIENT   DSOFAS","KNIFEI   ETUTORE   ISTARE","COCOAO  U LODGED  H SLATS","DAMESE O IBROODA S EREELS","GRATEU  I L  M FILESS  D ","GUIDEI G VR L OD O KSTOLE","SPERML Q OA U IGRAMSS L T","STILLE  O ERRORD  K SPASM","PROWSO P HW I AEQUALR M E","PASTEA U APIPERE E NRARES","LUREDA  D M  I EDIFYS  Y ","MAMMAI U IN D SE D LD Y E","OBESEI N QL J UE O AD Y L","KEYEDN  A EVERYE  N LOUSY","TEACHA  U L  R OWNEDN  S ","QUITEU G LOILEDT O EAMOUR","GAMMAN  I A  M TOXICS  C ","FEINTL R UALOFTS N OK S R","QUOTHU C AOTHERT R EE E S","FREES E  H B  O E  UCLEFT","STEAL R  E A  ASCARF K  Y","LYMPH O  A L  TSKATE S  D","PURSE P N OPTIC E F GRUFF","EAVES L V  T O YOLKS S E ","BALLS L  P I  I B  NSINGS","SKULK N Y  E R BASIS D C ","NEIGH X  OLIVER S  NSTIRS","FELLS L   AVOID E   USUAL","FLUID I  IONION G  EFOYER","SPANK I  A K  RSERUM S  A","PATHS G A VAULT P E SENDS","PHASE O  L O  ESTING S  Y","EDIFY O L VOTER M E  S T ","CAPER M L  O D RUNES R R ","RABBI P  T A  EPRISM T  S","GRAFT A  E T  ANEEDS D  E","WALLS G  LVILLA N  IAGAIN","QUITE S   GAUZY G   RELIC","STUMP U A EBONY E I USUAL","NOBLY V O  E W  R E STARE","AMIGO O  VBOOZE S  NRESTS","TAMER N V KNEAD E D AXLES","POETS A I ASKED I R  S S ","FOAMS V   LEEKS R   ATTIC","NURSE N  LSCENE L  CRESET","DROLL I E  G V  H E STEEP","BILLY C O GILDS N G AGREE","OVARY I O  X U  E S KNEES","PIVOT C  R I  EKNOTS G  S","HURTS N  L C  ALUMPY T  S","SCARE H  N O  AOPTIC S  T","CHEFS A R KNEAD D I CYCLE","LOBES L  AADMIT E  EUNDID","CURLY L A  C D HELLO R E ","MEANT R O  E U SCENE T S ","MEETS V   CONIC K   CEDAR","SWAMP O  ISMELT E  HENEMY","SLEDS I  H N  O E  TISLES","CLICK O A AWAKE E E  D D ","FORDS F I STATE E T ANNOY","DIVER N  UANGEL E  ETREED","FURRY N E  I S ETHIC E N ","PUSSY N P ADMIT U T REPEL","GRASP A P  P U PIERS D N ","PANTS X   BLAND E   PSALM","SPENT L O  U V ASKED H L ","PITCH C L  I A SNOWS G S ","WIGHT N  R G  ALOFTY T  S","KNOBS O L ISLET E N ASIDE","FORTE Z R  O E UNSAY E D ","PLUSH U O PSALM T V DYKES","HYENA O A  K I  E V ASHES","MANGO M  BSPADE L  YDEEMS","CARDS C  T T  OMOTTO R  L","SPECK L  NLINGO E  WEDGES","MOVER A   ASSET I   ISLET","SHORN A O  V C ROOKS C Y ","SKULL I I ACUTE K H ASHEN","OLDER A S AMUSE B A  S Y ","DRAFT O  E V  M E  PBRAVO","HEARS N O STRUT R G TYPED","SECTS A  OTRAIL N  AUSHER","JERKY L  O B  U O  TSWISH","PILED S   SLOTH E   STREW","NOVEL L   ADDER E   ENACT","SHOON O  O A  SPRATE D  D","SIGHS N  T D  OJEWEL X  E","CARRY U   AGENT H   STILE","HEROS X  P I  I L  TGEESE","LYING O  A U  WCROAK S  Y","GOALS P  PDINER U  IAMONG","SIGMA N  PINEPT E  LBRINY","FUDGE N   ADEPT U   VESTS","FAUNA L E MIMIC B G LIGHT","RAVES R R  R R LOVER W D ","HOSTS T A  T P MEWED R S ","FARCE R H  S I NOBLY N L ","EVOKE A A  G R MUMMY E A ","VYING E  UFLITS P  TASSAY","EIGHT R  WHORDE N  ETYPED","QUITS N  LEDIFY I  LODDLY","MURKY S N  A O AGILE E L ","MUMPS R U AGILE E S ADIEU","FUZZY S   LIMES N   IGLOO","TRIAD E  UUSURP I  ESNAPS","CHIRP O O DRAWN D D BERYL","LIEGE V R MOLAR R Z TYPES","FOLLY W A  N M FEVER R S ","DOZED P N  T T DIARY C Y ","WITTY N   HERDS P   ATLAS","CORDS L  W D  ADECAY N  S","STATE R H PIOUS T M DEEPS","CONES W  M N  O E  KEDIFY","THESE A  X Z  I E  TALOES","BRIER O  U U  SSTOVE E  S","REGAL A  U S  TPENCE D  S","BEGOT N   ADAPT O   SWISH","TRITE O I RAJAH S R STRAW","LIKEN N N  D V BELOW X Y ","OOZESV E  ABBEYR R  YEARS","PULLS  A EDEMUR  B UBOSOM","FLING  D ISHEAF  A TFISTS","GAZESL E TO B AWORRYS A S","FANGSO O AL I LL S TY Y Y","YELLS  O  FINDS  G  RISES","DREGS  N T  J E  O AIDYLL","ULTRA  R  CHUMS  S  MUTED","RUINSE R TS A AINTERN E E","CADREO R AA I RTHEFTS S H","SONNY  I  DIGIT  H  HATER","CORKSL A HA N OC K RK S N","LARVA  E WALPHA  L RRHYME","TWICEA S TR L HD E IY S C","ROVERO O AP C JE A AS L H","WILLS  I  MOVES  E  PADRE","TILDEH O QR D UE G IWHELP","SWELLE X IR I LU T AMUSIC","COACHA L  RELAXR O  YAWNS","OAKEN  I E  N EWADED  S Y","COSTSE A  DRINKA N  RATES","STAREA I VD M AL E DY D E","HUMPSO A  POKESE E  SPREE","DREAMR X  I U  FILMYT T  ","GIRDSU O ME V OSPEAKS D E","CREAMO D AU G LPIECEE S S","TONICR I RI E ELUCIDL E O","MARES  E AQUIET  G ELINED","TOWER  H  GUILT  M  DUSTY","RINSEO A  CAVEDK E  SALTS","LADLE  A X  Z T  E RPODIA","CARTSO I EVIPERE E USERUM","FLOSSA P TTRITEE U WDAMPS","HATERU U AM F VI T ED S N","COCOAO H NICINGN P ES S L","TROTSE C CRACERM U USCRUB","FILESU E WMOVIEE E PSWEET","SMEARH R IA R FDWELTY D S","SOWERH A OO T UP E GSERVE","MOORSI P ISPENDT N ES S S","QUARTU M IA A RS Z EI E D","SALTS  I  DANDY  K  CASES","VAULTA S AUSHERN E DTARDY","GLADEH I  OILEDS E  TODDY","OILEDM O RI C ETEAMSS L S","HORNYI A ON N UG C RE H S","WARMSR I  ELVESS E  TUTOR","SWEPTE J IN E GS C HE T T","SIEVEA R VN E IEXCELR T S","BROWNA V OTREESC R EHATED","SCENTP L RU E IN G EKEYED","HAVEN  I  UNSAY  T  BRACE","HURTSE I WL S AMAKERS S D","PILEDU A RP R OPACKSY H S","FLIES  S ATILED  E LUNSAY","TRAMPU R RT O EOASISR E S","TIGERI A EN U AGAZERE Y S","PEONSO N LI I USHOPSE N H","MANGOA I MR C ISWEATH R S","SLAVE  B DSWUNG  S EDEEMS","VERSE  I X  M CREEVE  S L","ELITES M AS A TARGUEY E R","YELPSO O AUNFITT T YH Y R","CRESSR N EABASEG C DSITES","HINTSE I IA C GTEETHH R T","FLOWS  B  SPECK  S  ERECT","HACKSA A  RUNGSP D  SHYLY","GLENS  A ACORAL  N TMUSKY","AVOWSM N LI S USHEENS T G","ENACTV I OO R UK E RE D S","LAITYU S  CASKSI U  DREGS","RISENO P IA E CD E ES D R","FIELDA Q RN U ECHIPSY P S","LOGINE U  A S  NATTYS S  ","FANGSI E EN E EAIDEDL Y Y","KITESN A CO S ALIKENL S T","FIEND  B  GROUP  N  LAYER","SPURTU N IR C MLOUSEY T S","FOOLSL W HU N AF E KFORGE","AURAST O TTABOOI I NCANOE","MUTESA A HN I OG N OOATEN","SLASHO G  FAITHA L  STEWS","WENCHI I OCREDOK C TSHEDS","CALLSA A ER C ERAKEDY S S","HUSKS  H  PRIVY  R  POKER","SURERP A IU J SR A KS H Y","CAKESH E TU E URULEDN S S","THINKA D  SLYLYT L  YOLKS","SNAILM B OI H AT O NHERBS","ABAFTF B ITRAILE C ERAKED","CURLSH I TA V UF E NFIRST","DRIVE  N XERECT  R OHOTEL","MANIA  E  SOWER  E  KARMA","CLAIM  E ALAGER  I TPESTS","QUASIU B DOVARYT F LEXTOL","STEELL R  AMENDI C  NATAL","MOTESA H LR R UROOTSY E H","DEPOTR A RA I AN N SK T H","FLIRTE D AROYALN L KSALES","LEADSO W AD F WGAUZEE L D","POINT D E EDGES E D CRASH","DODGE C U  C I CURLY R E ","SCALE H I HOOTS P H ISLET","TIMEDW  T I  H GENIES  C ","PRESS I P  G A SHOWY T N ","ODIUM R N FIRST E A GREYS","FISTSI  A G  P HOVELT  S ","THESE E E CLEWS L E HOODS","SLEEPT  A I  S FUMESF  L ","UDDER E R  M A NOISE N E ","MUNCHA  H R  E CLOCKH  K ","ELVES E J  A E WRACK N T ","GOUGEA  A BALMYL  I EBONY","ROCKS A N  S O CINCH S K ","EARLSM  O POINTT  G YEAST","DROWN A A AVERT E T  D S ","CUBICY  N NEEDSI  E C  X ","FIFES G R  L A BOOST O E ","PAPER I D  D G LEVER D S ","MARSH   T ENJOY   O ADULT","TERMS   E SMIRK   E MOUSE","JUNTA N A  I P DOTES N S ","WEDGEI  A N  P EASEDS  S ","RESETE  X SAVEDI  R NASTY","HILLSI  E V  M E  O SCENT","LEPERI  D LONGSA  E COLDS","BOUTSA  O R  L NOBLES  S ","CARRY L E  P F  H I LASTS","SPOON R A LOUSY S I LEASE","MEDIAA  D N  E GLEAMY  S ","STANDL  I O  G T  H HOOTS","AFFIXP  N A  D RAKEDT  X ","HARRY T E FLOES A K  S S ","BOOST O K  Z U FEELS D K ","QUILT N O VITAL T M  S Y ","WAGON L M  L E BONNY W S ","WIPES R A SKATE E E ADORN","ADAGE R O AURAS M D  S S ","PAINTA  A PLUMSE  E READY","RARESO  A O  T FILETS  R ","CALMSR  O O  V UDDERP  D ","FANGS P L BIGOT N V EGGED","GAINS P O PROOF O K ANGST","ORDER O N  S J TENOR S Y ","DREAMA  D TALONE  P SLATE","AMAZEN  E I  B MARRYE  A ","TRYST E I  A X TROTH S Y ","CUFFS D I  D N REVEL R D ","REPLYI  U MOMMAE  P SWAYS","WARMS L A  D M  E M CROAK","STAFF W L PILOT C O MERRY","DROWNI  O CHARTE  R STAYS","ACORN A O  P S MOVED N S ","AUGUR   N CLASS   A BUOYS","SCOREN  E ABAFTK  I YOUTH","SEERSO  O L  W O  D SATYR","FANGS X L GLOAT E S  S S ","UPPER   A CARTS   E OVARY","SCARSH  I ALIVEK  E YOUTH","PAINS L I  T C YACHT R E ","WEARYH  A ADAGEC  E KINDS","TITHE D U GENRE A L  S S ","SEEDYM  A O  W T  N EXIST","AMONGG  O IGLOON  K GUISE","BIRCH N L  F O BEAUX R T ","WAGES L A CLASP O E  W D ","CRUDE   I HALVE   E INURE","WORDS L O  D M  E E ARISE","SHOALU  S L  I KINDSS  E ","ACUTE H H PEARL E O GRUBS","GOODS   E FUSED   M GUEST","BLUSH   T ACTOR   R RULER","APPLY A E  G A  A S UNITY","BRINEA  E B  W EXILEL  Y ","SOLAR N L  I I SOLVE N E ","STEEDK  L I  F N  I STAND","WAKESR  P ALTOSC  C K  H ","COUPS R H IDIOT E T TROOP","PESTS A O  R N PLAIT Y C ","CAROL   C KNACK   U OPERA","TOYEDH  N RAIDSO  O W  W ","GONGS C L  H O GRAVY E E ","SALTS S H  S I GAZED Y F ","BLARE   I WORLD   E WINDY","FINCH N O  C C  U K CRISP","FOXESL  D A  G PLIESS  D ","GNOMEO  I A  L TASKSS  Y ","ASSET T R FINAL N S SKIES","EATER   A DRAGS   L MANES","PITHYI  O L  S LUSTYS  S ","BOXED   X PUPPY   E MILLS","SMELTK  I A  C TALKSE  S ","CYCLEH  U AMUSEM  T PRAYS","FLAPS I R UNTIE G O BOORS","CRONEO  A U  V GREATH  L ","TEAMSY  A I  U NAIVEG  E ","CORNS   O SLIMY   A BIRDS","LYMPH O E PLANK K N  S Y ","QUIREU  O A  B RIDERT  D ","WROTH A A  Z M BOLES R D ","HANDYE O ON T LCLERKE D S","PEARL S  U S  CRADII Y  D","GRIEF    OMAMMA    MFORAY","BRAID A  IABOVE B  TGILDS","ISLET W  A E  MSPIRE T  D","PINKSR E TO E EWIDERL Y N","BRICK    ITEMPO    SBLEAK","PALMS M  CFOLIO N  PAGATE","WEIRDH N AO U USHRUBE E S","HYMNSA O PBOOZEI D NT S D","WOULD U  AAGENT H  ESTEAD","ZEBRA  L BDRAMA  D FWHEAT","VINES D  TZEBRA A  GPLUGS","KNELTE X UY T RE O NDELLS","BROTH    ERABBI    RBABES","CROWSH W HAMIGOI N RROGUE","FISTSI L HF A OTABOOH S K","QUERY N  E I  ACOVER N  S","SIZEDA   RBAYOUL   NE   K","FIEFS D  C E  RBAYOU L  B","SPRAY I  I V  ETOWEL T  D","BATHSR R AA I VV B EE E S","SPREE L  JSABRE Y  CASSET","PLEASA A UR V PTHERES S R","JETTY G  O G  L E  KIDEAS","LOVED F  U F  C E  TPROWS","CORES  E UMASON  I NPANSY","NOBLY  R OSTOOL  I KCALLS","COAST R  R G  U A  CKNOCK","ROSESO K HO I ISUPERT S E","SHUNS I  T N  O D  LUSAGE","PALERR I EO N NO E DFINES","WROTEA A XF T AETHICR S T","BUCKSU L LM O APLUMBS D S","SQUADT   EO   CVODKAE   Y","DREAMA   ITOKENU   UMEMES","SKIPSE D ON I CSHOOKE M S","BLANDE E AI G UN I BGASES","MUDDY L  E T  LBROIL A  S","FADEDR Y IA I VN N ECAGED","SCREW H  ACAIRN S  EJERKS","HOPES R  Q D  UMEDIA R  W","BRACEI M ND O TE N ESUGAR","DEFER V  ADAILY D  OMELON","PRUDE  N XUNFIT  I OPETAL","RABBI  R NDOING  D OFLEET","SWAMP R  A E  GSCENE K  S","MOVESA I HN S RGUILEY T D","TABOO T  P O  EAMOUR S  A","LARKSA I OW F UN T TS S H","ITEMSC M TI P AN T KG Y E","TOWERA O ASCRAPT D IY Y D","CLAMS I  P T  ICHURN E  Y","NATTYA R OM E UEXACTS D H","ARMEDV A IO M VW M ASLAIN","UNION    OVAULT    ECOLDS","LAMPS L  E D  NKEYED R  S","TOUCH V  A A  CSLICK S  S","SIRENN   OA   BG   LSHADE","SANDYE E ONAVALS E KEARNS","LYMPH O  ASKULL E  EEDGED","SCOOP O  O L  ELOONS N  Y","ROUTEA N NY D EOPIUMN D Y","STOVEE R DRABBIF I FS T Y","POKER T  O T  B E  EBRAND","FLEAS E  LCANTO F  PCYCLE","FLOOD  F IOTTER  E GMINCE","CAPER D  A I  G E  ESUCKS","LUNARI   AM   LBROILO   Y","CLUES  D MRADIO  E KFORTE","AGREEB O QA U UF T AT S L","FETUSE R ITHINGU P HSTEWS","BAREDA   RSIGMAE   WDRAWL","PRANK O  I C  OSKINS Y  K","BEAKS  F NPATIO  E BGERMS","CAVES V  K E  ICREAM T  S","LUMPY R  A G  R E  NUSERS","SHAMSA   TCAMEOK   RSPIKE","FOLLYL   OABACKG   ESIDED","SPANSH B TO O AO U VTITHE","SOGGYO   AFRANCA   HSPILT","TOILSH N HI C AE U CF R K","ASHES  O TULTRA  E IIDLED","GIANTU W RL O ELIKENS E D","RESTSH E KY N IMADAME S S","MELONA E OJ E BO K LRISKY","SHARPN V IO O NBLINKS D S","RAPID N  I N  MLEVEL X  Y","FOGGYA R OSNAILT N KSIDES","QUASI    NFINAL    ESMELT","RAKESI   CGONNAI   LDOLED","MINESE A IWHILEE L VD S E","ANTES Y  E M  V P  ESHORN","GREENR   OA   NCUBICE   E","PRICK U  IKNOWN E  GISLES","TABOOU E ISMALLK D ES Y D","GONNA    RCLAMS    OCANON","DUKESO   EUSHERG   VHEDGE","SIZEDP O EI N BR E UE S T","CHOPSA U EN G XOCHREN T S","A C TPROXYT R PL A EYELPS","P  B OUTERW  L ELBOWR  W ","S Z ALEEKSA B IT R DEVADE","A E OFIXEDI U DR L LENTRY","B  T APRONY  I ODDLYU  S ","A H ITRUSST M SI I UCADRE","S E ATUNESI D HREEVES D N","R   TALDERG   IE   EDUCTS","U   SSHOREU   XR   EPLIES","A  O CHAINT  L E  E DEEDS","C A AHALEDA P OR H RTWAIN","S  A CABBYE  O NEEDSE  E ","A B HSCENES G AENACTS T H","S  J MENUSE  D L  G LEPER","O  E FLINGT  V ERRORN  Y ","S T  CHESSA N  NASTYT E  ","E L TDOUGHG N IE C CS H K","A  O FAITHO  H O  E THORN","P A TENVOYT A PT I EYOLKS","U K ISKIMSI L LN L EGUSTS","P C SABACKL N IM E RS S T","A E SLOATHO R OU L AD Y L","A T PSHALLK I UE N SWITCH","A H MSMOTES R LAUDIOY E N","S L SCREEPU A ULEPERL T S","I M TDRIERI N UO U SMASKS","O D AVEINSA C SR T EYEAST","A S OFETIDO R DO U LT T Y","T K RRANGEA E IPLAINS D S","O  E FIENDF  E ENEMYR  Y ","O   ACLAMSH   KR   EEDGED","A A CBABELA O OF V TTEETH","S  H TOPAZU  P DRAPES  Y ","A L TGNASHI S EN S SGROVE","D   IROLESA   SM   UABUSE","W A TRISKYI S PSTAVET Y S","A  G SWINGH  A ELATES  S ","O  S NOVELI  I O  Z NOTES","O M UBOORSE O EY R RS S S","S  R HAVOCA  U ROUTSP  E ","E  O TRIPEH  T I  I CATCH","C A WLASSOI S OC A EKEYED","C  D LUREDU  F NOSEDG  R ","D A IRUNESU N SM E US X E","S V OPLAIDE L DEQUALD E Y","S D  KIOSKU M  LIENSK S  ","E   KDEMONG   OE   WDOZEN","W A UHUMUSA I URISERF S P","O  I FOAMYT  P EASESN  L ","S  L TIMESA  A LEASEE  T ","U  R SIZEDE  G R  A SURLY","S A IURGEDI O LNONCEG Y R","A  B POSESI  A NURSEG  T ","A F UFOODSI W URULERE S P","S F AWARTSE A KA N ERACED","E  A VERSEE  S ROPESY  T ","A S ITAKENO I ALINENL S E","T  P ROYALI  N B  E EXILE","E T BSNAILS R EALTOSY S T","U  A SCOUTU  R REPAYP  S ","S S AMATESE A KLARGEL E W","S  A PAINTI  G N  S SORTS","S B ATILEDO A OR N RM D N","I O FGAZERL O OO N GOMENS","L F SABOUTT O IELDERR S S","R I LASSAYT S NE U CD E H","K O ANAVALE A TE R ALAYER","F  B ONSETR  A TARRYY  S ","A  S COUCHR  O EVERYS  E ","E S  DUPESI E  FUNDSY D  ","B M AREALMA N UN G SDRAPE","A B KGREENR A OE S WEATEN","I   MDUMMYY   RLIVERL   H","S Q SMAUVEO O AK T TYEARS","G  A LUNCHO  T O  O MOORS","P S TLIKERU I EG P NS S D","U L SSNEAKU M AADMITL E E","A S PMOTESI I HT L AY L W","A  A FLAPST  A E  R ROUTS","R   TENDOWA   ID   NSIGNS","S B SPRINTE L OC G OKNELL","U R TNOISEI V AT E MYARDS","E  R ROBEDE  I C  G TAUNT","S D SCRESTA C AR K IEASED","F  S JUMPSO  E ROUNDD  D ","A S CPOPPYA O CRURALT E E","A C RSLATEH D NERREDN E S","R  S OOZEDA  R SCOFFT  S ","S G CPALERI A INONCES D R","A P SBUILTB N OO E CT S K","A  A DRAFTU  O L  O TESTY","W K THEAVYI R PF M EFLAWS","E H BDWELLI R ECROWST S S","E  B NOBLEE  O MEANSY  D ","S A LCACHEA H VL E EELDER","C A TRENEWE N IAREASM X T","E  C SHALES  I A  P YEAST","S  E TILTSO  H REPELM  R ","E  M VOTEDI  R LIVIDS  T ","T  P REALMO  I TIMESS  S "," R F TODAY L L NEWLY S S "," G B FLORA E A RABID N N "," G T AIRED V A LEMME S S "," S A SIXTH R L BEGAN S S "," M   BASED R    C   SHRUG"," W  VRATIO T  WTENSE R  L"," G  TGAUGE M  P M  ICASED"," D S NIECE N E  G N TYPES"," N S HULLS D A  G I PENNY"," C A THESE O K UPSET S W "," P   TICKS V   COOKS T   "," O  CEXPEL I  AIDOLS E  P"," Q   LUCKY I   PLAID L   "," I   SCOFF I   ELEGY Y   "," W F HALED R I IMAGE S N "," R L REBUS E C AFFIX S D "," V S TOOLS W A BEACH D K "," A  VSMITE O  R U  GBRIDE"," C  ERUNGS F  S F  AASSAY"," D  AMEMES F  I E  DDROVE"," C  WFLESH I  I M  LABODE"," K  IMEMES Y  L E  EIDIOT"," P  RFORGO U  PGNOME D  D"," T A HOBBY Y O REBUS D T "," D  SWIGHT V  RZEBRA S  W"," T S HEELS E Y STALE H Y "," P  SRIVEN L  OCEDAR S  E"," B  LGLORY O  NATTIC S  H"," C  AGROWS E  KSPINE E  D"," S S LIENS R I DEEPS S E "," S W LOGIC A L CRIER S S "," M  UDOMES M  I M  N A  G"," O G FARED K N NEARS N E "," S   ULTRA Y    L   SYRUP"," M T SORRY O O  D T  S H "," W S SHOTS I O  N R JEWEL"," P S GRIPE I U  Z R DEATH"," C  BBAYOU B  T A  TELUDE"," E  ADAWNS R  S N  EASSES"," D S FACTS I O FLOOD Y D "," B  CLEECH A  U M  RASHEN"," N S TARTS K E  E A IDYLL"," W  EPINTS D  SZEBRA N  Y"," D A COLDS G O  M R EATEN"," E  UCALMS R  AALONG S  E"," D  SWREAK U  I N  FSKIFF"," W  WPARKA N  K T  EUSERS"," L  ADAMES T  P H  EYEARN"," C  CPORCH V  A E  ISTERN"," A E DRILL S V BOXED N S "," D  MREEVE U  ASCION E  T"," M  OFIXED N  DEERIE R  R"," B S WALKS L A EMPTY Y E "," L  HQUOTE N  D A  GCRANE"," B   BONES O   GNAWS S   "," C  NBASTE V  C E  KIDOLS"," A D ASKEW I C IDIOM E Y "," T M BRUIN U T USHER S S "," A  PQUAYS G  ABERYL R  M"," V  UTOILS D  U K  R A  P"," G B PROUD A L  P G SHREW"," W A VERGE E I SPILL S E "," B N LABEL R A SEERS D S "," F E WILDS N I SCOFF H Y "," Q  UCURES I  UBLUER T  P"," R  EREAPS A  S C  ASHOWY"," T W DOWRY W A REAPS L S "," R S SALTS C E LEPER S P "," T A JOLLY N E MERRY S T "," O J ACRES E R WALKS N S "," M  ASOILS T  S E  AESSAY"," N S BOLTS I A  S I LYING"," B  EREVEL A  VUNITE S  S"," P A GLIDE E I WAVED S U "," T S MATCH B A  L R LEASE"," F T DAIRY T I CABBY L E "," F A CRABS A A GIRTH L E "," L  SRIGHT A  U R  MUSURP"," C  AVASES P  P E  EGROIN"," B  FLASSO S  U I  NFLOAT"," S  ANOTES N  HAGILE S  N"," I  SKNAVE T  I E  ZGRIME"," S P WADED G O PEONS S S "," R  ABOARD U  IAGREE E  U"," G  APROWS O  H V  ETEEMS"," C P ALLEY U N  E A PSALM"," G  ACLUBS O  HARGUE Y  S"," F  ACRUMB O  O Z  DREEVE"," S  SAPPLE A  R R  VUSAGE"," N  CPENAL A  AFRANC S  K"," B  CSLYLY A  C R  LDEUCE"," E F AVAIL O N SKIES E R "," D A TERMS L O YARNS Y G "," P  ABEARS N  PSNIPE Y  N"," F U LIENS R S PSHAW T Y "," S  SBLAST I  ASPEAR S  S"," B  CCARGO D  O G  KLEAKS"," B S GROWN O E  O A ADORE"," A W FRUIT E E UNCLE A D "," S D RITES D T  E E USERS","  U  BURLY  G    E  MUSKY","A R  BLONDI G  DOUGHE E  ","  C  PARKS  O  GANGS  E  ","G L  LAITYO V  V E  ENDOW","S A  POSERA K  SMEARM D  ","I W SSKIRTL P UE E NS S T","O F RPARSEE I AN A PSERFS","  U WSINCE  T D  I GVALVE","  C TTHROW  E E  S EACTED","  B  SHINS  R  BATHS  H  ","D U RWASTEE A ML G ITREAT","  Y MGRATE  C T  H EALTER","  W UMARKS  A U  P ABASAL","  C LOZONE  R M  K MISSUE","E F SMOISTP R UTREADY D S","S F DPRICEE F AC T LK H T","C G EHIRESA A SR N ATODDY","W W  ICINGS C  POKESS S  ","A S ABATEDL A UE B LRESET","  P  SHEAR  A  BIRTH  L  ","C A FLABELU U OBASESS E S","  G  JERKS  A  MINES  T  ","A A IBABESA A LT F EE T S","S A  COMETO E  PINKSE D  ","S T TTARRYA A PTHYMEE S S","U T  SLANGU R  A D  LOYAL","  F JSHAVE  M LSMELL  D Y","  M ACHARM  R I  T THUSSY","I A AGRINDL D DOBESEO S R","L A EINDEXM M II I LTITLE","T A ARABIDA B OCHOIRT T E","B T COTHERA R EROOTSD B S","S M ATHINGA M ICLEANK S G","  G OSHIED  V I  E UBOSOM","P A NLASSOU K OS E SHEDGE","S A SWIGHTA E OMINORP T E","  I ADAMPS  B I  U DOBESE","  F SCHUMP  N AVINES  Y M","A S PVICARE A IR N STOTEM","A A  MINUSI I  GAMUTO E  ","A L LDAILYU E NL N CT S H","B A AEDGESG E KI N ENOTED","  Z STREAT  B ESURGE  A D","A P ASNIFFP L OE L ON S T","  R  PRISM  V  BREED  R  ","O E WCOBRAH B FR E EELDER","  L DCRIER  L AKHAKI  C N","  F AFARED  E OSPEAR  D N","S I EWAGONI L ESTORMH O Y","  B  QUACK  R  TABOO  S  ","A A GSABREK A AE C RDIKES","  A ASTUFF  D I  I RBUTTE","A C  FILEDI A  RUINSE M  ","E C SBARGEO A ENOMADY P S","B F DLOAMYO C IOFTEND S G","E S  SILKYS I  ANNEXY K  ","  H  BRUNT  N  LOCKS  H  ","A I  BEGOTA L  TOOTHE O  ","B S ARUNESU E STIARAE K Y","A E  TAPERO O  NICERE H  ","C D SLOYALE I AA N NNIGHT","  S DFATTY  A K  I EMODES","F A AROSESI S KA E ERATED","A K ACANESH O SE T ED S T","  A IFUNDS  N L  E EWAXES","C W ULEARNO G IAVERTK S E","  A ATACKS  H ISTEED  D E","B S IROMANA O CT K USWEAR","S F  KILLSA A  TASTYE K  ","O C CFOLIOT A NE S CN S H","A P SSTRIPK O EE S LDWELL","A E ANAVALI E LM N EENTRY","A A FDOGMAO I CR N EEDGED","E V FDRAWLG G IE U ESHEER","A S AGOWNSA A KI M EN P W","M P  ABAFTR C  SEEMSH S  ","G A ALEGALO O AOWNERM Y M","E S HNICHED U AO L RWELLS","  I  SINGS  L  SLEDS  T  ","E H ITEEMSH A LI V ECREPT","A A SDIGITO L ABROILE W K","A F TFLESHT I RE G ERENEW","P S  REPLYA R  Y E  STERN","  E  MOVER  E    R  BAYOU","A B TMURKYI A PS C ESPEND","E S HDUMMYI E MF A NYARNS","  A SAUGHT  A O  I RBONNY","S N PTHEREU V ACLEARK R S","  G MCARGO  O T  W ECALLS","S M UWRAPSE I EABLERT S S","A S  DUCTSA A  PELTST E  ","I H DSHAMEL I CE L AS S Y","S C STILDEI A EN S MGAPES","U A ASIGHSU L HAWOKEL W N","C F  ROUNDU M  SHEDST S  ","  U  POSTS  H    E  BORAX","S U  TUNEDA I  GOODSE N  ","O S  DALESI U  UNSAYM H  ","A F OFEINTI L TR T EETHER","A S UBACKSO A HVALVEE P R","S  I PIGMYR  P IMPLYG  Y "," T A LOUSY D I  D D TYPES","S  C CHARMA  O LARCHE  K "," D G FREAK I Y  F E START"," S T STARS I A SNACK K T ","S  S CORKSO  I PULLSE  L "," F T BROWS A A LIENS L G "," A S SMITE O R KNEAD G P "," B S GRATE O R FOCAL K Y "," L A FIRST N K  G E GOADS","S  T WAVESI  S NORTHE  Y "," C R BRAID E G  D I MOODY"," V R MAJOR N B VEXES S S "," M A READS A D ANTES T D "," D S JERKS L U CABLE Y K ","I  F STARTS  E UPPERE  S ","C  O HEADYE  I SNOUTS  M ","A  A BOOBYA  H THROBE  R ","T  S EXACTN  E DRINKS  E ","I  A CROWNI  A N  R GIBES","S  M HOLESA  W LEVELT  D "," G S VOTES R C AGATE E S ","D  B WOMENE  A LEEKST  S "," R B DECAY B S  U E STORK"," F B HUMUS R G BRAGS Y Y "," B A GRABS A Y  V S COAST"," B N TREAT I M NAKED R D ","A  E FILMSO  I O  T TERSE"," M B TAPES R G STRAY S N "," R B CABIN I G ENJOY Y T "," U S KNOTS D R DECAY R W "," J P OUTER N N STEAL A L ","E  I SWINGS  G A  O YOUTH","S  S TUNESA  A B  T SALSA","A  O BUILDB  D O  E THINK"," W S LADLE X A FERNS D G "," R A SIEGE V O EARNS L Y "," P S TURNS L I  S P TENET"," S A STINK O K KNELT E E "," S G SPELL I I STANK E T "," S S STINK O A SOUPS P S "," A W AMBER O E  U K TRESS","T  G HEELSE  O REARSE  Y ","C  B LOVEDI  V F  E FEELS","V  C ANGERL  N UNITSE  S "," V J WIRES G W DINES L L "," E F DEBAR R D WILES E S ","U  I STEMSH  B E  U RITES","C  G ACRIDM  F PELTSS  S ","   U JEERS   I SHINE   E "," T G WOUND R A  S T ROUSE","A  S STUMPS  A A  R YOUTH"," G E CAUSE Y S  E A GREYS","S  S NASTYA  E R  A ENEMY","L  A ENACTD  H GAYERE  S ","S  A PROSEI  H K  E EVENT"," B S PARKA Y I  O R PUTTY","S  D TIMESR  A E  T WIGHT"," M M JOKED V A FITLY E S ","O  L CAMEOC  M U  O RAINS","A  C GUILTE  A N  I THYME","P  F ACRESG  A ANGRYN  S "," A A BRAVO O O  M W LAPSE"," R P OUTER D S RENTS R S "," S C SIREN N A  K S ASPEN"," H A SONGS U R ASKED E E ","A  O FARMSO  I OMITST  S "," V T DOSED C S LAITY L S ","S  U CRASSO  U FORAYF  L "," F S CLUCK O A  R L TARDY","   P SKULL   O    T BURST"," M D LAIRS M Y  M L SATYR","L  C ISLETK  A E  S RISES"," C S CROCK I O SCORE K N "," B A MERCY L I LORDS W S "," T A MISTS D O VAULT L L "," P A LINGO O E GUANO S T ","A  P PRIEDI  L N  T GUISE"," W D SHOOT I C  C K WHISK","S  L CAROLA  W LULLSE  Y ","A  A SURGEK  A EERIEW  N "," O T FLAIR D R  E E GRADE","S  B TOLLSA  U K  F EDIFY"," R E VELDT A G PLIES S D ","O  O FROZEF  O E  N RAGES"," M T HEIRS D U  I C LAMED","S  G HILLYO  O VIEWSE  S "," L S PINTO M I  B C LOCKS","A  P CHAOSR  P E  P SLAYS"," D S DEUCE E A IDOLS S E ","B  E AMIGOT  G CEDEDH  D "," C A WHIPS A A  S R SMOTE","S  O THIRDA  G Y  A SOUND"," G S CROCK I A ANGRY D S "," B S REACT G O  U O INEPT"," A B AFIRE O A NOISE T S "," V T TILED S N WIDOW T R "," S S ELITE Y E GLEAM Y L "," T A TRESS E H RAZED T S "," K F UNCUT O M SWEET S S ","C C TABHORT A IC S AHUMID"," M  ALURED R  UCABAL L  T","S L VWRITEI M NFLINTT T S","C R SERECTA E OSAFERE S Y","A B CFLAILI I OR T GEASES","S S UKITESI A AN I GSENSE","A A FFEVERO O EOMITST D H","B G SEQUIPA I RU L EX D E"," M  ISIZED D  L S  ESTEER","S S CMETERA I OC F NK F Y"," W  USOUPS M  U E  ASNAIL"," P  ISIZES O  LPURSE S  T","A F SDRUNKO R IP Z MTEEMS"," T  PTRILL U  E L  AHYMNS"," L  EFILET S  HATONE S  R"," G  UKNOTS O  U M  APERIL","A L SSTOUTP U EE S AN E M"," S  SCHALK A  I K  MDYKES"," E  OSQUAW U  N A  EBLEED"," F  ABLOOM A  BSMELL E  E","S H WPHOTOL O RI K RTASTY"," S  WGIRTH G  I M  NPAUSE","F E LAPTLYN H MG I PS C H"," H  APAINS V  IBODED C  E","M C IEVILSE V LTRIPES C T","T U DRUPEEU P CT E OHURRY","  S ITOWNS  I L  S EASHES","S   AKEYEDA   UTOTALE   T","U   USKIESU   IA   NLYING","A V TDRIERU L UL L STEAMS","O G AUNITSN L HCADREE S N"," C  SPLAIT E  IOFTEN S  K"," B  IBOILS M  S B  UUSAGE","U   HNATTYC   DUSHERT   A"," P  HDANDY Y  E E  NAROMA","N D AOPENSS L PE T EDRAIN","  A LGAUDY  G N  U CBERTH","Q   AURGEDI   OTAMERE   N","S C SCROCKR C IALOOFP A F"," E  SEQUAL U  OGAUNT L  H"," A  AABYSS H  S O  EPREYS"," S  AFAUNS L  K V  EDOMED"," S  AOMITS A  S C  ESKIPS","C I CHANDYA D NR E ITOXIC","I A PSOLESL L HE O AT Y W"," R  STIGHT V  OMANGO L  D","A C IBOARSA N LCRATEK L T","O S MPENCEI O LN R TE E S","  K UGANGS  O ICABIN  S G","  N EBLAND  T GGRAZE  L D","C R AREALMA D PPHIALE I E","S B BTWICEU R ADICEDS H Y","R   TEAGERN   UT   TSMASH","S B AHOLDSO E SVISTAE S Y","A C WBOOTHA U IFARMST T K","  B UJAILS  L HEAGLE  E R","T S OHATEDI A DRIVALD E Y"," B  UREEDS R  USTAIR H  P","A L KDROWNE S EPIECET R S","O F UCOLONH A TR G IEASEL","J   SUNFITM   OPINTOS   D"," T  SQUICK L  I I  PEPICS","S U HMUSKYI H DR E RKARMA","S F UTALKSE A UW I RSCRAP","B I VLEMMEU B NFAULTF E S","  T EFEAST  M HGEESE  D R"," B  ECAROL T  B H  OBELOW","S A SCAMELO O IUSURPT R S","S E UPIVOTA A TR D ESPEAR","I S IMULESP I LLAPSEY S S","  A MCIRCA  E X  N IQUALM","A M UDEEDSM A EIDLERT Y S"," T  TGIRTH T  IFLIER E  D"," P  NFORTE D  S I  TGAINS"," I  SADOPT I  ALOCAL M  E"," T  AFORMS X  K I  ESCALD"," D  AREARS A  H T  ESHORN"," P  ALOOPS R  SREEVE S  T","S M ACLODSR L SADAGEP R S","Y S GALTERC O AH N FTRYST"," L  IKINDS S  L T  EUSERS","I G ACONICI A TLASSOY H R","A C PGROSSI A HL C AE H W","M   WANGLEY   EO   PRULES"," T  SFILMY D  R A  UCLAMP","O A ABIRDSE E HSHAPEE S N","B B SINLETL O OG C RE K M","  D UBLISS  G H  I EALTER","  D DGLAZE  T TGAUGE  M R","G T TRAINYE A IAPRONT A G","A P ASORESP I KE E ENOSED","A T ASCRUBI U AD S SENSUE","G S IROCKSI O SN U US T E"," A  LAGATE I  ACLEAN E  S","N M PALIBIS G EA H RLUTES","  B HWEEDY  L D  I RARENA","A S CLATCHO A IFELONT L K","  N SFAINT  N ILINEN  Y T"," L  PMACES T  H C  ATHROW","  V BSPILL  D A  E ZAWOKE","M P CU O ATALKSE A EDARES","FOXESO   MCANTOU   TSLIDE","P A RI L OQUILLU B EEXITS","RISERA H  CLOTHE E  RUSES","OUTERC   AHATERR   EEMITS","ANNEXU O  GAUZYH N  TASTE","HUMPSU  A STAYSS  E YEARN","PILLSE  O TWISTT  E YEARS","CIGARA U IRILEDG C EOTHER","O S FA Q RTRUCEE A AN W K","EDIFYJ  A EXERTC  C TREED","E T PN U OJUNKSO E TY D S","WHIFFA   OFEWERE   TRENTS","BADGEE I ALIVERL E LY S S","C A CH G OIDEALP N OSATIN","BRINGA  I BOXERE  C LOVER","P   QO   USPIKEE   ERECUR","R P HA E UTICKSI K KO S Y","PRAYSO D  PIOUSE B  STEAM","PAGANS  S HAWKSA  E W  W ","EARTHT I  HASTYE K  ROYAL","LAWNSO H  COILSA P  LOSES","SALVOO A ABUMPSE P IRESTS","PALMSE I  SAVEST E  S S  ","DEEMSE  A BANJOT  O STARK","O D UC A NHINDSR C AEVERY","A S RP T APLANKL R EYOKED","FLUSHO   AWASPSL   TSIEGE","S T EO R NWRISTE E ERIDER","MAKERO N  TWEEDH L  SATED","F D BO I ULATERI T SO Y T","FLECKA  H RAKEDC  S ERASE","M L LU E ISPANKT S EY E R","TUTORI I IMUMPSI E KDUSKY","BLASTE   OFIERYI   ETRIAD","E  W A  I GRANDE  C RACED","ETHERT O IHEROSE D ER E R","WHELPA R IVERGEE O CDIRGE","D F II O SCOINSE L UD S E","BONEDE    AWAKES    TENOR","JEERSE N HENJOYR O LSHYLY","BEVELU E  GIRTHL S  ELEGY","SORTSU   IPILOTE   EROUTS","GUSTYR  R ASSAYV  P ERASE","AMBERS R ESKATEE T DS S Y","REACHE  L SURERI  A NEARS","CAGESU A  FLUSHF D  SLYLY","EMPTYX L  PRANKE Z  LEASH","TOTALE  N AMIGOC  E HURRY","VENOMI   ELEAVEE   TRIFTS","R F CE I OFIFTYI E LTASTY","PLUMBI   APIERSE   EROWED","I   FD   IYARDSL   HLAITY","BOORSU  O GRUBSG  E YARDS","P M BI O ACOVESK I ASWELL","MOOSEI P LTWEEDE R ESTAIR","SWOOPP C OOCHRER R TTEEMS","W S CR I UORDERT E VHEDGE","DAUNTU S RSAUCYT R SY P T","MAYBEA  U COULDE  L SLAYS","VOLTSO  I CRATEA  H LOSER","NERVEO  I TABOOE  L SQUAW","GULCHI  A FLAKYT  E SPASM","REAMSA N  YOKESO L  NEEDS","PIQUEO  N KNOCKE  L RIPER","LOBBYE  O GRANTA  U LOUSE","LATCHO  H AFFIXM  L YIELD","BLOTSE  R LOCUSL  S EMPTY","FLOSSI   IRIVALS   LTALLY","F T BI A ARIPENE E KDARES","DITTYE    TOASTE    REFIT","M B HU O ISCOURI S ECITES","REMITO A UBORESE R KS Y S","M R FO A UTUBESO I SR D Y","FRIEDA M ATOPAZE L ES Y D","BOLTSR  O ARGUEC  G EIGHT","WHARFI  O LOOPSD  E SLUSH","RARERE E ISHEENE V GTREES","ERECTM    PATHST    YOUNG","R G ME E UPAREDE M DLUSTY","VIDEOI R  SHEIKT S  ASSET","PICKSI H  QUAYSU I  EARLY","MOMMAO   USOLIDS   IYACHT","M P ME A AWIRESE T TD Y S","SHAKEI    GREATM    ANGLE","P O TE P ISLEPTT R HSTAKE","FISTSA U HCHIMET T ES S T","OILEDV O EEQUALR S VTHERE","T O UI W DTRIADH N EEAGER","COBRAE E CLARCHL Y ESALAD","S J FE A LCAUSET N ESITES","RACERI L ESCARFE N INIGHT","BEFITE A  GOREDA M  TASTE","RAISEE  M BREEDE  L LULLS","BOGGYA U  STINTI D  NIECE","LOSERI   OCOINSK   ESOUPS","CAPONA H ESMOKET N DSTEWS","SMOTEO  A LEAKYO  E SHANK","SLABSO  E USERST  Y HEALS","FLOSSI  C SNORTT  I STOPS","ACIDS O I OMITS E T  S O "," B  U O  NTOWED N  UUSAGE"," M  C A  ASLEDS E  EASKED","SPASM I W OCCUR K N USAGE","SWISH A  ETIGER F  OASPEN","SIDES V N TORSO R U DYKES"," F G  O L CUBES R A USING","FINES N  IFLING E  NSTARS","OFTEN E  AHERBS D  TESSAY","AMPLE O Y SWAIN E N BRAGS"," C  C I  ABROWN C  TBANJO","SCALY A  OABACK L  ESEWED","STALL E   BEAST N   ESSAY","KARMA C   PHOTO E   ASKEW","STARK O   SWORD E   CLEWS","AFIRE A I SLITS L E  S S ","AGREE R A QUITE F E AFIRE","SCRUB H  AFOXES S  ETEPID"," C C  O R TRAIN A E SLEDS"," S T  N E FADES R M CEASE"," P  B I  EULTRA O  DSTARS","EGGED R  OCOOLS O  EAMISS"," Y B  O L TUTOR T O SHADY","SPENT R U TILDE N G OTHER","SPELT R  ELOTUS W  TCLUES"," M  C E  OGAILY N  LSTRAY"," B B  L L GAVEL D N SEEDY"," G R  I I ELUDE L E USURP"," B  V O  AKNELL N  VCYCLE","SKIES N A PIETY T E USURP"," A W  V I JOLLY W E  S S ","SPLIT R N MEATS Y E USURP","ADDER E   APING T   THIEF","PLAIT A N KNELT K E  Y T "," S Q  P U METAL N R STATE","AFOOT L P GORED O R BROAD","AMISS O O TOOLS D A HYDRA"," A  B S  ATHONG E  GESSAY","DOLLS T A CHARM E G CREEP","PSALM O U WRIST R T  Y Y ","SHAWL E   ANTIC C   FENCE","STOOD E  RPARKA C  KWHALE"," S T  L O MURKY N E AGENT"," F M  L U SEAMS C P  K S ","SPASM A N SWAIN E P EDGES"," L  O Y  VNIECE N  RAGENT","WHERE A  EUNDER G  IUSAGE","STAVE H E FEINT R O HELMS","SPEED I  ESTALE C  DSHAMS","CRUDE O E PLUMB E O USING","AGATE U  AELDER L  NHYMNS","CLUMP U U CRESS E K  S Y ","STRAW I  ACLUCK E  EISLES","SWEAR I  AUNDER G  EUSHER"," G B  L R POKES B E HEADS","SWIFT E I SERFS D T MYTHS"," S C  T O TOUCH O K  D S ","SCARS H U SEEDY E E SKIRT","ADULT R   TARRY W   CLAIM","USUAL O  ACLACK O  EISLES","SWAIN R  EHOUSE T  DSHINY","ETHIC A  ACRAFT D  E Y  R","USHER T   JACKS K   HELLO","USERS C A DRAKE U E ABIDE","ABACK A   GROAN N   ESSAY"," S  B P  AVEXES R  I M  C","ABYSS L H LOVER W L PSALM"," M  P E  ASLUGS T  TASSAY","USERS P A HAIRY R E  S S ","ADORN E O DRUGS B U TYPES","SHAPE O U TRAMP N P  S S ","ISSUE H S WIRES N R  Y S ","ACIDS A  TFLAIR L  IUSURP","ADIEU R   HELPS S   ASIDE","GEARS T I SHUNS I S ACTED","SWOOP A T WRITS M E USURP"," S F  H O DUELS T K  S S "," P P  O O SPEED E T  S S ","CACHE L   ALIEN O   STALK","BIRDS N   LUMPS R   VENUE"," A  B C  EMUSES T  EBEGOT"," K  R N  ACOLIC L  KPLIES","PHONE O E BRACE N K  S S ","SHAVE U   CRANE T   PSHAW","BUDGE N R ASHES A E DYING","USURP O   HURRY L   ISSUE","SCALY L A JOINS U D  D S ","CHAFE A R AVOID E A ANGRY"," S  O T  NCORES R  E Y  T","CLUCK I A PLANK A O SCANT","SOLOS V A FEATS R E STANK","ABYSS I  PBRAVO C  ISHOAL"," B  L E  ISALVE C  GRHYME","AFTER I  IBEANS N  EIDLER","ABOUT I   CLANS L   SYRUP","GASPS S O SHIRK E T  S S ","THIRD O  ACROWN N  CASIDE"," S T  H E NYMPH L I  Y D ","USAGE W   WIRES S   CHAIN","SPASM S T CHEER A M TWIST","DUSKYE E  BEETSA R  RISKS","TESTSO H AKNOLLE V ENEEDS","VISOR  A  SALES  L  BAYOU","REPEL  I UCLAMS  N TPROSY","  L M  A AAMBER  E EBALLS","P B BA O ITEXTSC E OHERON","O B PF R OFLICKE E ER R D","SOFASL R  ALIKET A  STREW","GASESA T IYIELDL R EY N S","SMELL  A IFORTE  L NGUSTS","YIELDO L EUNDUET E PHARTS","MAMMAI I CMONTHI D ECASKS","  P M  E IBASIS  K EPAYER","GAPEDU E OISLETL T EDOSED","M B CA O ADOWNSA E TMERES","L F FA I UWAXESN E ES S S","HUSSY  L OCRACK  P EFASTS","PAVED  A OBELOW  V RSEEDY","L S CI N IGRANTH K ETEENS","VISTA  E SFIXES  E EVESTS","DECKS  H LAMAZE  F EGREET","ALTERF R AFLOUTI U EX T S","B M VO A OMIMICB M ASMALL","M N BO Y AMIMICM P OASHEN","LOGINI L  MOODYB V  STEEP","ETHIC  A ACAVES  O EROCKS","MUSIC  T RPROVE  O PFUDGE","CIDERR O OISLESE E ESIDES","SABLE  E  PAVED  E  HULKS","LYRICI E UMINORB T EOASIS","A T OL H UIDIOTB E EINFER","SCRIP  A AULCER  E EBARED","D H GO I ATALESE L PDOSES","INLETN E  GRAZEO P  TESTY","HOWLS  I ILOVED  E EBASIS","KICKS  O  GOWNS  E  YARDS","STAIR  P IABAFT  R EBUTTS","OPENS  M PPRIZE  T NBASED","CIGAR  N  LEAPT  T  ONSET","BASIC  T ACRAMP  B EGASES","BIRDS  O  LACED  K  BAYOU","S S SI H PGLAREH N LS K L","POPPYA H  TOASTI S  OCEAN","G C  R E  ENDOWE E  NUDGE","ACRESW E  FIFESU E  LYRIC","WISPSA N ASTOICT W KEASES","RAFTSA O  DICEDI U  ISSUE","MEDALI O AEAVESN E TS S S","BOWLSA R ATROUTO T YN H R","SPOTSL V PERASEE L NK S T","AWFUL  R USAILS  E TPUDGY","PEEPS  R  CURLS  O  CARRY","L V PE E AMANGYO T ENOSED","Y C NA R OWHEATN E CS P H","LATCHA R  SOUTHS S  OUTER","RACKS  U  DARTS  D  BASER","D S AI N MCHIRPE F LS F Y","C L LA U AMEMESE P SLASSO","P R CL O RAGONYN K PS S T","MIMIC  O OGROWN  N EBASES","JACKSI L  FLAPSF W  Y S  ","LACKS  A  BLUSH  S  PIECE","FATESO I AROBEDG I LE A Y","RISERI O ISELLSE V ESHEDS","C C BO A EBANKSR O EAGENT","PSHAWA A  DECOYD K  Y S  ","GASPSR P TAWOKEI T ENASAL","B D AA R USTAIDI K ICREDO","S Q CM U RELITEA T SRESTS","BASTEI P TGNASHH W ITUNIC","AISLE  C XPRATE  L RMIDST","DUPESU O UMUSICM S KY E S","PUDGYR W EIDEALV L LYELPS","PIQUEI U  CHICKK L  SALSA","VILER  A IGERMS  C EASHEN","R W NI I OSIGHTK H ESITES","N D PE A USPINST L SSLYLY","HULLSA A HTIGERE E EDARED","FIFTY  R  FAITH  A  CORPS","N H RO O ESWOOPE D ADUSTY","  M I  U DCAMEL  M EFOYER","LASSO  C  AROSE  L  WADED","S D BI W AGRASSM R AAWFUL","T C WO O OWAVERN E LSHRED","V S CE L RSMITET P DS S O","  G U  A NNAMED  U IFATED","COMESR O IANNULN T KK H S","CACAOO L  CLANSO M  APPLY","RUDERU E IREELSA M KLUSTS","BASES  C  GOODS  U  WATCH","RACEDO A  WENCHE D  DRYLY","ZEBRA  O IPROUD  T EMUSES","PUSSY  K  POINT  P  PUSSY","CABIN  O  BROOD  Z  GLEAM","L G BI I ELEVEEA E TCASES","F M FL I OALLOWP K LS Y S","FATED  E  DUPES  I  OLDER","BOSOMI N ISHOWSO R TNEEDS","MOSSYA P  LYINGE T  S S  ","M P UA O SCHUTEE C RS H S","PATHS C E STUDS E G EDGES","LARGEI  U SWELLT  F SLASH","VISTAA  H LINESE  S TAMER","ROMAN   F IRATE   E WORRY"," S C  P O SIGMA L I STACK","BLINDU  E CIRCAK  K SALSA","CANALA  L LOOPSM  H STEAD","BASTEA  E STOLEI  L CRASS","BOMBS   R TIRED   A LORDS","LARCH   A NEEDS   R FINED","POPPYA  E STALKT  T ERASE"," V C  I R SCRAP A F WRITE","SLOPE   I TWICE   K GNASH","U  P N  O FLASKI  E TIERS","JIFFY   I HIVES   N WILDS","TWIGS H A TIMID L N BEAST","LIENSA  I SLICET  E SNARE","TRADE   U SLIMY   P GUESS"," S C  W O REBUT A C  R H ","MUMMYO  A THINEI  G FREAK","CURSEI  P TROOPE  U SOOTY","PRIDE   E SCARF   B QUAYS","CHUMP O O DRIVE S E BERRY","ADMIT   M CRABS   U VIPER","DRIFT   I LEAFY   T TRAYS","STATE R U CUFFS S T  S S ","OCEAN L N LOFTY S I MERCY","OUGHT   O SHOUT   S LAYER","CATERL  X OATENU  R DUSTY"," F S  O A BRAVO G E BEAST","PUFFY S O WALLS G K LEAST","AGAPE R A HURLS N E STORY"," G B  U I SEEDY S E  T S ","COUGHI  A TRAYSE  E START","PULPYA  A CARVEK  E STUDS","SCARF Y O SCOUR L G REVEL"," F F  O U CRUST G E POISE"," J P  U O CRIED O T CRUST","TOURS Z A NONCE N K LEASE","FUDGE   O STEAD   L ROUSE"," D W  E H PLIED T A CASTS","MINUS R R BARGE T E REEDS"," W D  R E PIECE N K  G S "," C B  A I CRIBS G L FOXES","POUCH L O ADAPT E S BREED"," N Y  O O RISKS S E HEADS","OCEAN O B SMEAR M C PARKA","LEASH   I SULLY   K ABYSS"," G C  A L TIRES N R  S K "," G H  L O FOAMY V E CEASE","BALMYE  E GRIMEO  E TEASE","MAYBEA  E GROANI  K COAST","ASIDE W I GIMME S E PHASE","FAITH G E CAIRN P S MEMES","ISSUE C N HERDS N I RENDS","SMOCK   O BOOMS   B PURSE","WAIFS S O CHICK E A PSALM","ESSAYT  N HINGEI  E CARRY","SHOOTA  L BLADEL  E EARNS","SMACKU  I PONDSE  E ROARS","DWELT   A EPOCH   E CARDS","ANNOYS  W SWAINE  N SOGGY","CLUBS E A LEASH C I CHEST"," C G  O O SOLOS E D  D S ","WHEAT A B STOOP E D BRIEF","EPICS R H FUSED N A HEAPS","CINCHA  A BOOSTB  T YOKES","TRYST A T PIPER L E ASIDE","SCORN L O DATUM I G  M H ","SHOPS   I VERVE   O FISTS","HOOFS P L REBUS R K OAKEN","SMEAR A U SKATE E O FROST","STIRSC  O RECURE  N WEEDY","LILACO  R CAGEDA  N LOCAL","ELOPE   O SENSE   E GOADS","U  S N  T FEWERI  R TYING","FOIST   E DOLED   K POESY","ADOBE   E FLEAS   K FRISK","TRAMSI  A CLICKK  E SLUSH","PRESS   T SCOOP   V FILED","TIERSH  E OWINGN  T GEESE","CORKS V N CANOE R T  Y S ","LARCHO  H STAINE  M SIZED"," P H  A E SWELL E M  D S ","STOPS E R ENDOW O B DRIER","JOUST Z A GOUGE N E DENSE","VILLA   U PULLS   L WORSE","JAILS D O DIARY E D CURSE","AMUSE O L IMBUE M M SALSA"," W H  H U REALS E K FLASH","FIRST D T BOXER L R USING","HARSHO  M OWNEDT  L SPITS"," P P  L A HALVE N E  K D "," F W  A A HUSKY N E PALSY","ELUDET  I HUNCHE  E ROAST","BURSTR  W URGEDT  A ELATE","ATOLL A U SMACK E I GRADE"," Q T  U I LEADS U A REPLY","PINTO   A PARSE   T THIEF","ACTOR H B METED F S ASKEW","LAPEL H  YREALM A  P D  H","VISTA  A LLIBEL  L EWEEDY","STRAPU E OREEDSE K TRUSES","MOMMA T  FCHIEF E  I R  X","MOMMA  O SFACTS  K EONSET","TASTE  P ASHOPS  O ETILED","Q S CU H HAWAREF D SF Y T","USUAL P  UPECKS N  TODDLY"," Q  E U  NTEAMS E  UTRIBE","  F Q  E UGRAZE  S EOTTER","PLUMBU   IDYKESG   OYEARN"," G  S R  AFAULT S  YUPPER","ULTRA    PAUGHT    LSADLY","POPPAU L GPRIDEI E NL D T"," A  B L  OFINED B  EYIELD","GOINGA   RPRUNEE   ADEBUT","BOSOM  O ACUBIT  E EWIRED","M G QA R UJUICEO M ERAYON","RATIO    UCADET    DFORGO","CRANEA   TMATCHE   ELATER","DATUMI R OVEINSE A SSADLY","A A BP B AROARSO S EN E R","TAMED  A UWAKES  E KMERRY","O B FC R UHOARDR C GE E E","  K G  N AFROST  C EPIKES","INCUR    ULUCID    ECOWER","KNOLL  O ODIZZY  E APEDAL","SATINO O EBINDSE G TRESTS","FOIST    RJUICY    SPIVOT","LLAMA    IPEAKS    LWROTE","SCREW O  AINEPT C  ECHAIR","NASAL  T IBRISK  R EVISOR","FORUM P  UBATHS L  I S  C","DOSED  M OSHAFT  C EPIKES","FAULTU   OSCOUTE   ADRAWL"," B  M O  IMALES T  TISLES","A F SP L HPRIVYL T LY S Y","SCOPE U  MGROUP D  TASSAY","PLUMB    AREPLY    OBAYOU","AROMA E  LFLIRT A  OEXITS","CLIMBA M LTIBIAE U ZREEVE","PHASE E  NRANKS T  UCHIDE","L H PO I OBONDSE G ESHEER","LEMME  E RNERVE  E CVISIT","SPANK E  ESADLY C  EBEARD","AVOID I  IELVES L  KHARPS","COWEDU E EBODESI G KCLEWS","L F EI I TMARCHE E ES S R","AFOOT U  HUNSAY G  MGIMME","WHARF    LSHADY    EBUYER","MUSIC  T USHEAF  M FOASIS","T   UO   NWOOEDE   IDOZED","TYPEDA I UPINESE E TSADLY","OWING    LPROSE    AMAXIM","SHRUG    AVELDT    EFLOES","REALSI   LDAILYG   LENVOY","UNCUTR   RGLAZEE   ESEWED","DEPOTU L ASPAWNK N KYOKES","B N MU Y AMUMMYP P BS H E","LIBELI A OLUREDA E GCADRE","A C GN L UGRAZEE I SLAMES","O R VU E ITIMEDD I EOUTDO","L   BU   LSPADET   ESIZED"," S  O Q  BDUNCE A  YEDGES","CIDERO R UCLAMPO N EANKLE","HOBBYU E OLEVELK E KSALTS","CRUMB    EDICTA    KNAILS","W P UI I NDUETSO T AW Y Y","LEVERO I ISCARFE L TRESTS","S C PL U AAIREDN S RTHEME","AXIOM  D EJUICE  O TMEMES","S W VA A EFELONE L UR S E","  F J  U EKINDS  G TTOILS","D L MI E OCOATST S SA H Y"," S  F N  AMOPED B  EASKED","FROTHI W EFINERT E OHERON","SCOUT H  AWASPS I  TGRAVY","O M HI I ALONGSE T TDUSTY","COCOA  L UAWAIT  N OJOKES","UNCUT  I ERIVER  I SNICHE","B M VA A EBINDSE O TSORTS","D T TO E ASTREWE S ND E Y","BOOTSI P TPLAZAE L RD S E"," F  A A  BBUNCH L  OETHER"," G  F O  ICLANS L  H Y  Y","RATIO X  LSIZED O  E M  N","C M PA U ONOSESO I SNICHE"," A  P G  OCAVIL I  K N  A","U M PN O UFROSTI N TTASTY","TRAMP I  ABOAST T  I S  O"," E  P T  ECHURN E  ABROIL","NASAL    IGLOOM    IGUILT","RACER  H OSLAPS  M IASPEN","J F PE L ASMOKYT U ESATYR"," L  C E  OWAGER F  A Y  L"," T  A H  SPUNCH M  EABYSS","USURP N  UHAZEL R  SGLIDE","W B BA R AGLASSE V ISTOIC","HAREM P  ASPICY L  BBELIE","EXPELL I AFILMYI E EN S R","S   LLEMMEI   PPROBES   R","S A GTIGERU A IFRILLF N L","S  A MATCHE  R ACRIDR  D ","CRAZEH U VA G OSHEIKE R E","M O LA N IN I FGHOSTE N S","BEGATE  M G  B INDEXN  R ","C S HULTRAF A LFORCES K D","RACESE L HE E YDRAWLY R Y","L A TORDERU I OSTEELE U L","G N MN E AA R RSAVESH E H","T T SI R ET I NHOPESE E E","I  S REAPSA  I TWINSE  E ","D O CORDERU I AGRUFFH M T","WICKSA O LG S AENTRYD S S","GAPESU R AL O TCABBYH E R","L A GA B UN A EDATESS E S","PAIRSU  O S  O SENSEY  T ","B S PIDOLSR A ACAROLH S M","ELBOWN A IA T GCLOTHT N T","B S BL C AU A BFORTEF F L","BRUSHA  W N  E JOYEDO  T ","GODLYE A EN W ARENTSE S T","G S  RACKSA O  PAWNSH L  ","CLIPSA M IC B NHOUSEE E W","TWANGE U AN T STROOPS S S","W R  OPENSR M  SPINST T  ","PROUDR C OO E NPIANOS N R","C F LA R IB E TBEACHY K E","DOERSE I TP G EOTHERT T N","LISTSE U MA G ADRAWSS R H","DEPTHA R OU I IBANDSS T T","PRESSU N UP S RPAUSEY E R","P  G AMBLEL  O MARSHY  S ","H  S OUGHTO  O PINCHS  K ","G  L RAKEDA  E BLOCKS  H ","C  B RARESI  L BELLES  S ","BARBSE  A G  D APTLYN  Y ","LAIRSO  A C  B ALIBIL  I ","A   AVIVIDO   OWOOERS   N","GLASSU  P L  A FURRYS  E ","Q S CU T UA E RCURLSK N E","F C SADAPTC B ATRAILS L L","C  T OASESU  M CREPEH  O ","HOURSO  E P  N ELVESS  W ","MARRYI  I G  O HINTST  S ","L F TEARTHA E ESPEARE R E","SPELLT L EO O AROPESM E H","F  B LILACA  G WEDGES  Y ","TASTEO  O P  U AMIGOZ  H ","LOYALE   UA   SSMARTE   S","TIGHTH R RI O UCHATSK N T","Y  Y ALTOSC  L HAWKST  S ","B D URARESO A EWAGERN S S","O  M VISITA  D LEASHS  T ","P  I LORDSU  L SHEENH  D ","D   RUNDUEE   ILEMONS   S","MINCEY  L T  A HEAPSS  S ","BLEATL V AE E KSINCET T N","NASTYE  A E  R DANDYS  Y ","CEASEL  L A  A COINSK  T ","I  J MINUSP  M LUMPYY  S ","GOODSU P AI I BLUNARD E E","FORTEA  U N  L GROINS  P ","ASIDER  A O  L MIXEDA  S ","C A BLIBELE H EFLOESS R T","HOSTSA  I I  G RAGEDS  R ","P N WLEAVEU I ASEVERH E Y","R A BIMPELG T UHOLEST Y H","V T VO R AC I UAVAILL D T","D  B ADMITI  N ROADSY  S ","A V  MAIDSI N  TEETHY S  ","LLAMAO U RC T OKNOTSS S E","H  H ENVOYR  P OILEDS  S ","ADOBEV  O E  G RECURT  S ","W A LHYDRAI O PFORMSF N E","S  B ENJOYR  X FLIERS  R ","B M EO E MM R IBIGOTS E S","TRAYSA  O S  K TOYEDE  S ","WADEDI R RE A OLAWNSD S S","RENEWE Y AA M IPAPASS H T","GIRLSU A LE Y ASTONYT N S","TRYSTR  W O  O TEARSH  E ","T S NI K UG U RHINDST K E","E   HAUDIOV   OENDEDS   S","S S PCAPERO I ORELAXE T Y","Y S OA P UR E GNORTHS M T","T S DOCHREA O ESOWEDT Y S","BALESO O KM C IBAKERS S T","C  J RECURA  N FORKST  S ","COASTR  O A  R BESETS  S ","CRIBSR  A A  D PANGSE  E ","C H SAROMAR R LDINESS S A","I  S NOUNSE  E PENALT  K ","S  A NAMESO  G RADIIT  S ","R A FORDERO M OSUINGT T S","TIDALR W II A GPORCHS F T","I  S DIVEDY  C LUSTYL  S ","GIBESU A MI B ESPELLE L L","S S  WEEDSA A  YELPSS S  ","F C SLARVAO O LSHONES K S"," T T HUMAN T I LOWLY R S ","SCALE A A  C W CHUNK E S "," K  TSNORE O  NOBESE S  T"," A S SWOON A L PRIVY D E "," S  BSCORE A  RENTRY T  L"," C  CLYMPH N  OKINDS C  E"," S  SSTOOP O  APINTS C  M","STREW A  A L  VFORCE N  R","STAVE A I  L O COALS N A "," B  WLASSO T  RSHOOK E  S"," E  PPENCE R  AMINER E  S","SCORE O I  L D SIEGE C E "," H R LABEL V N SOWED C W "," T C BIGHT A U WRATH A E "," S  B P  O I  OOTHER S  S"," C T MOORS L U LOSES N R ","KNITS I I  C E SHARK E S "," R G WORLD G I FUNDS E E "," G  ASLUMS A  SGROVE E  T","VAGUE N T  N T VOTES Y R "," C  HBRAVO Y  USPOON T  D"," G S LEAKS N I STEPS S S "," A M OFFER O R GOUGE T E ","OBEYS U  T M  ASPINY S  S"," Y R SAWED C S SHIED T T "," A R FRIED E P BALLS S Y "," M  J O  U U  NCREAK N  S"," S  HHASTY T  DRECUR D  A","RABBI B R  O U QUEST T H "," B S FENCE G R FATED T W "," S  FMERGE X  WVERSE S  R"," G R FLOOD I O EDIFY E S ","SNOWS A  I M  RGEESE D  S"," R  LMOTTO L  OBLOCK S  S","CARVE C E  R N GIRTH D S "," H J REBEL R R BOOKS N Y ","STORK O O  P L PAYER Z S ","STINT U  R L  AALLAY E  S"," F  MFLAME A  LSKIRT Y  S"," B H SALAD C I GOURD N S "," F B SLEET E L TALON S W ","SMOCK Y A  R B GRAIN H N "," T R ERROR I W WADED L D "," G  APRISM O  IRUSES P  S"," C E COMIC R G OATHS L T "," S  CCHILL O  ODOTES T  E"," S  APLIED A  OSPEAR S  N"," S A ACIDS A O SLABS Y E "," W  HCIRCA G  ISHEER T  Y"," A  WFLESH T  IBOILS S  K"," A  HCREDO R  RWAVED Y  E","ABATE A E  T E POEMS N S "," G V WILES L R ADAGE S E "," F  PPLANE E  TJAUNT S  Y"," C  SVAULT B  ABANAL L  L"," G  B R  U O  OLOUSY M  S"," S  MSTAGE O  RBOXER L  Y","SPECK L L  U O AMOUR E T ","GOOSE V  D A  GTRIBE Y  S"," I M ANNUL D S REFER X D ","STAFF R O  I R PLUGS L O "," F  LGRATE I  APANES R  E"," B P BRUIN E N TASKS K S ","TAMED U  W D  AWISER O  F"," S F SPIED R T RADIO Y D "," B S WRACK A R TWAIN L P ","AFOOT R  A A  RAUGER D  Y"," S R STRAP R C SUCKS T S ","PAWNS C I  U N ATONE E Y ","DAISY X L  I A FORTE M E "," Y G GIBES E E CLOSE D E ","STUFF O U  T Z MAIZE L Y "," B  WTEMPO A  RRULES X  T"," P S BROTH O O EXTRA Y M ","EMAIL E  E L  ACOMBS N  E"," P P CANOE L I LEASH D E ","ABYSS A A  B T BERYL S R "," D N RELAY M V AURAS R L "," M J PINES N E TEARS R S ","FJORD E O  L V ALIEN Y D "," F G FOWLS R A CANDY Y E ","ACIDS A R  B I DIVED N S "," E L ANNEX J M COLON Y N "," M A SEAMY D B FARES L R ","LARCH U H  G A CHEFS T F "," B  VEERIE G  RLIFTS N  E"," F  BDUNCE G  RPUDGY E  L","ACRES L  W U  OAMOUR P  N"," E  BLABEL G  EALIEN E  D"," G  S R  Q A  UVIOLA N  D"," W  BGIMME D  ALORDS W  T","AFFIX E    T   JUNKS S   "," W B WHILE E A PRIDE E E "," B S MOTHS O I GRINS S E "," V  G I  U R  APURER S  D"," M C SURER R D RACED L D "," P  SHARSH S  RSTATE Y  W"," A C SPLIT R D MOVER N R "," C A LANCE B T FADED L D "," S I STING O A YOUNG D E ","C W GABHORM E OPLEASS L S","LIFTSA J WT O AHARRYE D S","COMERR U AO L KSIEGES S D","CRATEO U XU R ICLASSH S T","B A FL T UA L NSLAINT S Y","ROSESE W AE I NDOSEDS H Y","CUBESO O WL A ATASTYS T S","LOADSA I MI D ITHEFTY D E","  V STRASH  G ASKULK  E Y","T S WETHERA R ISOUPSE G T","O P GBRAWLE P OSWAYSE S S","CAKEDL N AO O IGULLSS L Y","VYINGE N NR A ABENDSS E H","T G CA O OL O AOASESN E T","S S SI N AX E VTRADEY K D","T E  HALLSI U  GIDDYH E  ","B T AETHICR O URESETY E E","O T TNEWLYI A POPINEN N S","LOCALI A IM V EBRINGS L E","A B  PULPYP E  LIARSY K  ","NICHE  A R  D AWARDS  E E","PACKSI A ET R NHIVESY E E","CAPERO A IY P GLEASHY L T","C A WA L AG I IEAVESD E T","FLUESO N PR T IGLIDEO E S","BIPEDL R EO O NCLOGSK F E","THROBR E RU A ESPREES S D","  S  VAPID  I  BORES  E  ","A B LNEEDYG G ISWAINT N G","S C BPALERO I IROPESE S K","LILACA O RT Y OHEATSE L S","ALPHA  L C  A UQUIET  T E","S A APILESI E STERSEE T S","ABBEYB I  O S  VIOLAE N  ","M P BOCHRET O GHINGES E T","OCHREO A NZ N TEAGERS S Y","S S APALERR A MELITEE N D","  S GSCORN  F OSPASM  S E","G B DR O AO O DWIREDS S Y","CASESH L HA E AFIELDF K E","  F  GRINS  X  SEEMS  S  ","A H MDRAKEO R AREPELN Y Y","A D FWORSEF E EURGEDL S S","LEPERY O EN K ACHEAPH S S","TABBYW I OI G KNOOSEE T S","  A JMEDIA  O UHERON  E T","TASTEA T AB E GBRACEY K R","  D  CHURN  P  YIELD  D  ","DOOMSR B EO E ELAYERL S S","LEMMEA I RS R RTITHES H D","C S YABOVEN U AAUTOSL H T","ROMAN  A U  G RJOINS  C E","E P  LULLSI A  TENTSE E  ","W I CA M OI P AFELLSS Y T","MARESA I LY G UOMITSR D H","HACKSO O IU R GSLASHE L T","LATHEE O RA T ASCARST L E","BODEDU E ER R NREBUSS Y E","PRIDEE G LN L UCLOUDE O E","L R MAMIGOM O TPITCHS S S","FISHYL E EE V ACHEFSK R T","F L WL O HA O AMUSICE E K","V L KI A NT U EANGELL H T","PAPASO R PO I ALOVESS Y M","B F GU R LR O OSAGAST S S","H F TO L RB A IBEGOTY S E","BELLSU A WR R IRACESS H H","U S ISAWEDU A OROYALP S S","EXALTE G RR A AICILYE N S","OCHREP E AA L SLAPSES S S","  L LQUASI  S TWITCH  S E","SUPERT S OA A AMOLESP M T","PICKSR R PO E IVISITE S E","PACESU L TF E RFLAMEY N W","  B SSPERM  I AKINDS  G H","  P ESHRED  O ITOXIC  Y T","POPPYR L EI A ANAILST T T","  S TMOWER  O ABROOD  N E","P D FA E LW N ONOSESS E S","  U FFINAL  I OWOOER  N A","  M CDROLL  U ANOTES  H P","S M SEQUIPN R ASWAINE L S","C W GAMOURL R ALURIDS Y E","GOADSR V HA A EDRIEDE L S","STRAPI E RG F OHEIRST T E","Q P CU R OI O ATOXICS Y H","B M AUSERSS N SHOUSEY S T","  B APARSE  A OGIVEN  E S","CASTER I XO E IWAVESN E T","BESETL H RA E ISPITET K S","H W SELATEA I ERAVEDD E Y","CARRYO E OA B UCOUNTH S H","T T AO R GA I ADEPOTS E E","ASHESB A AO B FVOICEE T R","LOCALO H  O A  SLIMYE R  ","LOBESE U PG C AASKEWL S N","VIPERI O OT P MALPHAL Y N","K C PETHERE A IPOSEDS E E","SOWERH I OA N UDECKSY H E","L D HARENAP N TENSUEL E D","S  P LOYALI  T MOTHSE  S ","S  F HABITO  F ASHENL  S ","F  T LAIRSU  A MANIAE  N ","LOOMS A I  S S PIPES S R "," B C PITHY G A SHIPS T S ","ANNOYL  V O  A FOURST  Y ","O  H BOXEDE  N STUCKE  E ","W  R RAYONA  A TIPSYH  T "," C G CHEAT E U HANGS P E "," S C START E E DAISY M T ","U  D STAYSE  K RILEDS  S ","SLOPE O A  C L CURES S D ","   F SPERM   O THICK   K ","MOTHS C A  C R BUMPS R S ","SNOBSE  R R  I FLUSHS  K ","POPPA O A  Z C PECKS S S ","T  S HITCHE  A MEALYE  E ","S  C PENALA  B WOMANN  L "," A T MUSIC G L THIEF T S ","CRESTO  O R  L ABHORL  S ","FINCHO  O O  M LOWEDS  R ","ADOBER  O O  N MODELA  S "," R C FOWLS G O QUEUE E T "," B G MERIT L D WORDY W Y "," D R TRIES A B AMOUR S T ","S  L KNEADI  T PLACES  H ","HINDS C I  I V INNER G D "," F M PIVOT L A VENTS D S "," S F SPRIG I L LLAMA T S ","REEFSO  A W  D DARESY  D ","GHOSTI  A F  N TIGERS  R "," S C SHORE I I DERBY D S "," R G COLON Y U MARRY L D ","H  M ONIONI  N SEEKST  S ","S  L PLAINA  N SONGSM  O ","REIGN A A  T S TEMPO R S "," S C SPURS O E BODED K D "," S M SCRAP O T ROWED P S "," V F LEMON R U EVENT E D ","   F SQUAT   I TWINS   T ","HENCEA  R C  I KNOBSS  S ","S  W HUMANO  G ROPEDN  D ","DOORSO  E C  E KICKSS  S "," P B DIVAN T N SHEDS Y Y ","S  S OMITSL  R ALTARR  Y ","SHEAFM  W I  A TIERSE  D ","NIGHT N Y  E D SPERM T A ","A  F GLAREA  A TRAITE  L ","   B EVERY   I WORMS   S "," L S SEAMY A A SPARS T T "," P B FREES O N OXIDE Y S ","SLIMY A O  N O BEARD S S "," S B STYLE A A SLANT L K ","G  C LILACO  P RARESY  S ","A  G STARTI  I DUMMYE  Y ","S  D CRIEDO  E WHIPSL  S ","OVARYB  A E  I STUNGE  Y "," R S AEGIS L G FISHY C S ","LIFTSO  R C  O AXIOML  P ","W  A ROUGHE  E SIGNST  T ","SEERSA  E N  G DREAMY  L ","RIGHT V A  O V TREED Y N "," F C CLOAK O R BADGE T O ","L  S OUGHTO  I PLANSS  Y ","G  M RAVESA  D BRIARS  L ","SCION A A  B K PARED L N "," T H TONIC I R FLUES S D ","POPPAO  U P  N PLACEY  H "," P R AREAS I I EVADE Y S ","STATE R I  I M ATTIC E D ","S  B PAIRSA  I REACHK  K ","WOMANH  F E  I AWARET  E ","S  D IMBUEE  N VOWELE  S "," C F NAVAL D C DRIED E S ","D  S UNITYN  U CLAMSE  P "," B H HERON A M EDGED S S ","HAPPY R R  R O CARVE Y E ","SALSAH  N A  I CAMPSK  E ","BOOMSU  A M  N PILOTS  R ","ROADSE  A E  N FINDSS  Y ","T  F RAILSU  A CLINGK  K ","PUTTYA  R N  U GRASPS  T ","MILLSE  I A  N LONGSS  O ","VOILEI  I E  N WIDERS  N ","CUBITO  M S  P TALLYS  Y "," A R RISES S A SLICK E T ","SNAPSP  I A  N CREEPE  S "," D A DRAMS A I TWIST S S "," L T MINOR L K GAMES C N ","BASILL  D A  L SOBERT  D ","T  E APPLYP  E EXACTR  T "," M C PAPAS Y B TODAY R L ","HOBBYO  L R  U SHIRKE  T ","REFIT A R  R A STATE H E "," A D ALTOS E U BRIGS T H "," V R NAVAL P V SINEW D S ","   Q FETUS   A CHAFF   F ","K  Q IMBUEO  I SHOTSK  E ","WAISTO  C R  R RIGIDY  P ","AMUSE Y T  T I THANK S K ","B M HO I AO L RBILLSY S H","S W TH H EA I RMARTSE L E","E V GBRIERO E ENEWLYY S S","SALSAE A LA W LMANIAY S Y","MIMICI O RR O OTARTSH S S"," M  RSABRE N  FAGILE E  R","VISITY E II A TNYMPHG Y E","E U TTENORH D OIDIOTC D H","LOCALL R UA I RMUSICA P H","POPPAU A LL I PPUNCHY T A","  V FPEACE  L UPLIED  D S","AWARD A  A G  NBOUND N  Y","A H GTRUCEO S ELAKESL Y E"," M  TTEMPO N  DLUCID S  Y","S A KWAGONE O OPENALT Y L","SWARMO U AL N IVITALE S S","STAYS A  T B  OABHOR Y  K","V V VALIBIL R LUSUALE S A","VOCAL  R E  O APAWNS  S T","VISITE U OR L ASALTSE Y T","C B HRAISEO S AWHOOPD N S","SINEWP A HI T ITRAMPS L S","T T NR E IA E GCONCHT S T"," A  F M  U P  SFLAPS E  Y","R   DELDERE   OVEXESE   S","S W JT O UI O NCLERKK D S"," I  G V  R O  IGREEN Y  D"," A  KAFIRE I  EGRUEL E  S","D P GU L RN A ACLIMBE T S","AVOID A  A G  DDUPED E  Y","M G SY A MT I AHALTSS Y H","W H QH O UE O ERUDERE S Y","PERILR E IA B EYOUNGS S E","PSHAWA I OR R OKNEADA D Y","W S TINNERN E ACLAWSH K H"," A  PFLUSH T  OVAULT R  O","ANNULL O EI M ABOARDI D S"," B  SHATCH T  ICHOSE S  D"," S  USPINS E  UINTER D  P","A S BBUTTEI A RDAISYE N L","S T PALIBIG E AAPRONS S O","G B WA O IS O NPOKEDS S Y","B M FE I AN M UCHILLH C T","HOARDI L OL O ELUNARS G S","P C LE E ET N AACTORL S N","FAUNAO N BR D UTAILSS D E","WRONGO N UO I EDOORSS N T","B H TA Y RN D AJERKYO A S","SWISH H  O O  UBLOWS E  E","ENDOW O  H S  OREARS D  E","SERUMO A AR I RTENTSS Y H","USUAL I  I G  NSHIRE S  S","OWING I  L S  OUPPER S  Y"," P  CFAITH P  EHARES L  T","THUMB I  O R  XMERGE S  D","GROOM E  A L  ICASED X  S","FLOATL B RA E AGUSTYS E S","  C CSTAIR  R UWAGES  O H"," O  GSCENE E  EMACES N  E","SCRUB O  E C  ETOAST A  S","WAIFS L  T T  ACANAL R  E"," M  B E  I D  NMIXED A  S"," R  ASEWER L  IPANGS Y  E","G N CR E HI A AMORESE S M","SHIREP D XE E ICHARTK L S"," U  YGNOME S  AWARNS Y  T","WHARFO R OU E LLINEDD A S","G D CROUGEI C AMOTESY S E","MOTIFO H LU E URIFTSN T H","  D PCIRCA  U RCAMPS  S E","PSHAWU A IF I GFORTHS Y T","D L CARENAL A DELDERS S E","D C SEARTHC O AKNOCKS K Y","FIEFSI L HR O ISUPERT E E","QUITSU M WI P IPALESS Y H","W F JIGLOOS A KPRIMES R D","  Y CDROLL  K ISPERM  S B","STOUTM   OA   ASIGNSH   T","SHUTSH   LA   AFUZZYT   S","FAUNAU   DL   OLEVERY   N","ROMANI A OG D OHULKST Y E","O   TPAYERE   ARATESA   H","B G VI R IB A LLAPELE H A","CIVICL   RI   UFIRMSF   T","IDEAL A  O R  USTARS S  Y","CLERK A  I I  LTRIAL S  S","C S NHYENAI C KLITHEL S D","C T MR O OA A TBADGES S S"," S  FPHIAL O  ADOTES K  K","  B JCREDO  I USINKS  G T","M B BAWOKEJ X ROVERTR S H","V F WI O AE R RWADEDS S S","WAXENA   EI   EFETIDS   Y","DICTAO R SL E PLIEGES D N","S D TKHAKII U GLYNCHL T T","OBEYS R  P U  ARINGS N  M","CLIMBH   EE   GADIEUT   N","ROMAN N  E I  AROVER N  S"," D  Q E  U B  ASULLY T  S","E O MMEDIAI I YTHUMBS M E","H   SYACHTE   EN   PACIDS","G S AATLASU U SG N EEIGHT","OATHSP H  TOUGHI M  CABLE","W R IHEADSA T LR I EFRONT","KINDSI  I NINNYG  E SWISH","HATERA    UTTERL    STICK","TABLEH A  RISENE E  WASTE","TRIALI  L DELAYA  R LEMME","SWISHM  T AGLOWS  O HORDE","U   WNAIVEI   IT   REBBED","C  S ABATEK  A E  V SIZES","RELAXE    GIBESA    LINEN","TILEDH E UU V CM E TPORTS","T  S REAPSA  I M  T PALES","SNAILT    OVALSI    CHAFE","TEMPOR  R ONIONO  P PUSSY","HAVOCO O OUDDERN K NDEARS","V C CO R ID O VK U IAPPAL","MOGULA  L DEITYA  R METAL","MORESI   EMELONI   DCRASS","S M ST A EANNULF O LFORKS","DREGSI R OT R RT E RODDLY","BLUNTR   EITEMSN   TGRIMY","D S PEXTRAL R RT A KALPHA","CHAMPO L  MOODSM O  AFFIX","CEASEY U AN D GI I ECHOIR","C S BO P AMEATSI W ICYNIC","PUPILL    ASSETZ    ALIBI","PAUSEO  C SERUMT  L SHYLY","ALOOFG   ILABELO   CWRATH","C   HANGLEV   AI   PLURES","BASILU W IN I VC F IHATED","BIRTHE A  LADLEL I  SPICE","TABLEO E AX G VI U ECENTS","DROLLW N AA I PR O EFINAL","KEEPSN  R AFFIXC  D KEYED","USUALS   EULTRAA   DLIMES","UTTERP  R PAIRSE  E READS","W A HHYDRAI O SF R TFENCE","A P MM H AATOMSS T OSCORN","T A  RULEDO I  T B  STINK","CRAFTL  R IDEALC  N KNOCK","SOGGYC  R ORGANF  P FACED","C S RO U AM G VM A EAIRED","DIARYA  O TROUTU  T MILES","WRECKH  H ANVILR  L FOLDS","O C SPAINTE V IR I NALLOT","L   CEATERE   IK   MSPACE","S   SHAVOCO   UO   LNAVEL","C   BOWNERN   UI   SCLOTH","T U SUPSETN H OI E RCARRY","S  G PIOUSI  S R  T ENVOY","M B HI R EX A AE I DSANDY","MAKERO H  GRAPEU K  LYING","SWISHT  O EARLYP  A SOARS","R  Q E  U AEGISC  R HIDES","A G ALINEST A HE W ERESIN","CREEPA   ARARERG   EOOZED","MOISTO M IV B LE U TDEEDS","T C AHURTSU A SM T EBLEST","W B GR R UALARMT T MHASTY","L  P ICILYN  U E  M RABBI","ACRESL I PI N OB S UINEPT","A A ILISTSA H LR E EMINTS","BASERE W OE O LC R EHINDS","S   IHEEDSR   LU   EGUILT","T   AYAWNSI   KN   EGRIND","SADLYP A  EXTRAN U  DIMLY","CLAPSA    PALMSE    ROUGH","R  F AGILEG  I E  C SHAKY","VESTSI    OFTENL    AFFIX","SAGESY O ER N AU N MPRAYS","TAPESH E UUTTERM A GBELLE","PANGSA  A YOUTHE  E ROAST","TENTHH  A RABBIO  O BACON","S D  HOOFSE Z  A E  FUNGI","PLUCKL  A ARENAZ  O AMONG","SAVESW I HA L AN L MSLAYS","C    LOFTYI    M    BROOM","A  S BROWSO  I D  L EAGLE","CRAPEH M NAWAITM S RPUSSY","TOMESA I KK N UE E LNASAL","C  A HANDSA  A F  G FLEET","SUPERP L  LEASHI Z  TRAIT","PLUGSL N CUNTIEM I NBELIE","D  D OCEANG  M M  E ABYSS","SHEERP X IOATHSO R ELEARN","FASTSO W  LOOPSI O  OWNED","SHARKT  O USAGEM  U PUREE","STOOPT  A EXISTA  I MOOSE","ACRESX I HI V OO E EMERES","STRUTT A IOLDENO I GPROSE","SHEAFI  W GLEAMM  R AIMED","BILGER  A I  Y N  E GLARE","B C  EVADEF N  I T  TROOP","MUMPSI  A MOOSEI  T CASED","V M CE A YI N CN I LSTATE","T M BH O ORITESO E OBOSOM","THANKE  E E  V T  E HOARY","THUMBU   RN   II   BCRONE","ABOUT R  RVILLA E  CFRANK","SCOWL R   BEVEL D   BORAX","STOOP I  E B  A I  CCACHE","GRADE A O  B G  B M DIVAN"," P M  H E JOLLY T O DOING"," T S HASTY B E  O R FOUNT","TRAPS A A EBONY B I CINCH","AVERT O  H W  O E  NSLANG"," F  B U  AONION G  JPINTO","APPAL O  UBIGOT N  EATLAS"," D  STRAIN A  O M  WSAGES"," A  ISTEAD T  E I  ASCANS","SMOKY O   STRAW T   MOSSY"," C B COILS M O  E C BROKE"," I  AIDEAS Y  H L  ECLEAN"," B G HAIRS Y A  O I SUING","SPECK A A GUIDE S E VESTS","QUACK N   STARS I   BEGIN"," B  C A  ATYING O  EMUCUS","SKUNK H  NRADIO K  TAIDES","GRATE E O  V P  E A PLAZA"," Z  ADEVIL B  L R  OBALMY","SPIES O L PLAID K T TALES","CABLE V   BELOW R   STRAW"," B M FRIAR U D  I A ANIME"," O  SEATEN T  O E  WKNITS"," F N MODEM R V  T E SHORT"," Q P CURED A N  L A SMELT","MAMMA R  CTORCH M  EJADED"," L Q FORUM N O  G T ASSAY"," P  FBAIZE D  A R  SRESET","PLAIN E  OAVERT E  EPECKS","CLOAK E R FERRY C O SHOWN","CASES L  THILLY B  LNIECE","CRICK A A  B R  B V VIXEN"," M  ICOATS U  L S  EBEAST","SCOUT L  HTENSE A  MPROBE","ABIDE O   EXIST E   PRICK","ASSET C  EBEANS N  TSTONY"," M Q  A U SNEAK I S VAPID"," P  ASIGHS A  S N  EYOURS","SIZED G   FLYER O   MOLAR","WROTE A R ADMIT I B RITES"," E B AXIOM P O  E T PLUSH"," L  ARACES Y  K E  EURGED"," G  ILUSTS I  L S  ELEAST"," A  UGLASS I  E B  RCITES"," Z  FSERVE B  I R  GPAGAN"," G  BGROWL A  O P  CCHECK","OFFER U A AGATE U E WEARS","ADORE E O BLUSH T I YAWNS","NATTY M W OPTIC L N SEWER"," A E BRAGS O G  S E HERDS","CANNY M   ABUSE E   BRIAR","EQUAL U  IPACKS S  TMIMES"," P S SAUCE T E  I N ROVED"," C  FDRAMA E  I P  TWENCH"," T S  I P HATER R A CARRY","PODIA U  BSTOOL D  ECOWER","STRAP A  OABACK O  ECORKS","FUGUE T R STABS E A TRUNK","APPLE O  AUPPER P  TRAJAH","APACE O O ALIAS K C PATHS"," D  CCREDO A  U M  PCARVE"," T I HOODS R L  S E COURT","EGGED A A IMAGE M L CADET","TACKS D   WINDS E   DUCKS","PAIRS T O MOSSY L I SLUNG","USING L   SEWER E   STICK","FARED D  RCIRCA E  KQUOTE","STYLE I  AATOMS H  ELEEKS","WATER D  EFINAL E  ITUNIC","PRESS A  PABHOR B  ETILDE","SCOWL H I LIONS N C OATHS","AGAIN U N PAINT N E COURT"," K  P H  U A  F K  FSITES"," T  RMOOSE R  A S  DWORRY"," T  AFILMS B  I I  DWAIVE","IDEAS E  K T  U E  LTRAIL"," Q O  U N PAUSE S E PINTS"," V R DIVAN L N  L G LAYER","USUAL I  I X  N T  ESHORN"," R  GROMAN Y  A A  SFLASH"," F  P L  AVALET I  HCRIES"," U Q ODIUM D E  E E FRANC"," M S HATED N I  G Z RACES"," M  RTORSO T  S O  IGRAIN","ACUTE O  NSMART M  RPARRY","AMITY A   AMPLE M   DALLY"," S  Q H  UMEDIA E  CCRANK","ABYSS A  TUNTIE J  MLOOMS"," A A SLIME I E  K N DEEDS"," P  OMOUND L  I K  UMADAM","SKILL H  EMANGA K  VTILDE","ABAFT A U KNEES J L HORSE","FRANK I  I D  O E  SCRICK","ACORN A I  M P  E E GONNA"," P  STILDE N  R C  VWHALE"," S  SBACON B  A R  GDEARS","STATE O H FREER S R JOKER","COACH  D  JOINT  E  SHUTS","M G SI U AN S IT T NSTOUT","P B  LEAFYU Y  M O  BLUER","F V BA I AU S RN I DALTOS","SNAKE  M DSWING  G EWOODS","STEEL  A  MUTED  E  SUNNY","H M VO O ILOVESE I OSHEAR","  A SSALON  I E  B EBRIER","  S B  W OWHIRL  N TAEGIS","B P SA L QT U UH M AELBOW","  O UFOCUS  C U  U RSCRAP","COCKSO R EBOOZER U DAMPLY","GRANTU C HL U AL T NSPEAK","B Q  A U  SLABSI S  CHIEF","LOGICI U ON A UG N POZONE","VICARI R ESMITET S VAMPLE","  F  TRUMP  N    G  ADIEU","TIBIA  R  QUACK  W  PINES","S B  HEADSO Y  A O  LAUGH","SERUMC O AR A LU S EBATHS","S C BHORSER E AU D SBOOST","  A DBALMY  I K  B EPAINS","  C SWEAVE  N A  O MWEEDY","DIARYU D  KNITSE E  SPUNK","C P AIDLEDN U MC M IHABIT","A C ACOOLSI M PD M ESWAIN","PIQUE  U  STAGE  S  CHIPS","  A SLADEN  I A  E GCHUMS","J G KO U NI S ON T BSHOWS","E R ML A IB B NO B UWAITS","ADMITS O  HATCHE T  SHOAL","MOTOR  R ECRUEL  M AAPPLY","  C G  A AFAIRY  R LMONEY","FRANC  L ERIPEN  H TGLASS","MISTSO M TO I AN L KSCENE","TIMIDY O AI T TN T UGLOOM","STRIPP A EU D TR I TSPINY","F A SREFITA T AN E TCURVE","  O  LOBES  E    S  CHEEK","SIGNS  R  THERE  A  WITCH","CROPSA F CDEFERE E ETHROW","VIRUSO A LDODGEK I DAMISS","CADET  A OSOWED  N DLUSTY","M R CA A AN D II I RALIEN","SKATET D  OWINGI E  COUCH","GNATS  D AGRIEF  E EBLUER","MOPED  I UGOADS  N TMOODY","LABEL  L UGRAIN  N AOLDER","ETHIC  A LFURZE  R APAYER","NEWER  A E  K A  E LFADES","  S UBITES  E H  R EMINOR","COMBSO O TULTRAN H RTASTE","MYTHSO A UT C CI I KFETUS","L H FU A UCIVILI O LDECRY","S R FH A LE B OL B SFLIES","V P BY O EI P AN P KGRASS","I M PD O ELAMESE M ODRAMS","  F  BOOTS  L    I  BROTH","S R VL A EINDEXN I EGRIND","GOWNSR A HI N AL E LLADLE","PUPIL  R EURINE  N KRITES","  M HSPARE  N N  G CQUAKE","RACER  A EVENOM  T IABOUT","ALBUM  L ADROWN  O GVODKA","ULCER  U  BARED  V  FIEND","IMPLYN O OE L KP A ETIRED","S C FC L IO A VO S EPIPES","  B GTHORN  W A  E SBIRTH","S Q FT U OU I RF R DFEELS","L Q BI U ONEARSG S OODIUM","B E WA N ICEDEDO O ENEWER","APPLYU A  NOTEST I  SNOWS","DECRYI O  CURVET P  ARSON","FORCEL A LI B ON B PGUIDE","O B HF A OFOYERE O SROUGE","CABBYO A AMAYORB O DSTUDS","HIDES  E  BATON  E  BERYL","  S PPOPPA  R C  I EWAGES","BEANS  V CPLAZA  I NWALKS","AWFULR U  OWNEDM G  AMITY","  B  CLANK  Y    O  VOUCH","BOWEL  H EDRAMA  L PGREAT","A C SSAINTH R OE C NSPARE","WOOED  T  LATCH  E  BURNT","UNCUTL O UT V BR E EAUTOS","RATES  I  CUBIC  I  FEAST","LIFTS  A ESPURN  N STRADE","C A VHEDGEA I RR E VMAUVE","C A DOLDERN I EE E ASOUND","  A CDEFER  F I  I EBOXES","FUSSY  T  SCALP  I  ANNEX","C S ROCHREM E LM L AAFFIX","B K SETHICA A AS K NTRIPS","D K FO H UCHARMK K ESWIMS","S S FK T EI R LF U LFETUS","  B DTRUER  I A  L IOFTEN","  T BVIOLA  W N  E KHORNS","  W T  H ASWELL  L KHOPES","HOARDU D UNAIVEC E THOURS","ABBOTP E OP A PL C IETHIC","PAGAN   P MOVIE   N GOUGE","FILCHI  U FJORDE  V SIREN","M  C EXULTT  A A  N LUNGE","AGAPEN  L TROUTI  M CABBY","LIARS   A BARBS   B PUPIL","RAISEE  W I  I G  N NEIGH","WAIST L T LIVES E A GNOME","BLAST U C BROAD C R SHIFT","BANJOE  U FLUMEI  P TENSE"," F A  L X PANIC S O CHAMP"," G G  U A PLUMB C I CHUNK","PATHS U A  G V  U O PRICE"," G B SORES N G  N I BARNS","L  C IDIOTN  U G  C OUGHT","BURNSE  A NORTHC  A HILLS","B  S AWAKET  U C  L HULLS","U  Z NOSESD  B E  R RELAY","MAIDSI  E MAPLEI  T CREAK","S  S HILLYA  A R  N PUDGY","S  R METALE  D L  I TIMID"," K S SNAPS O E  W N ASIDE","STUFFT  A IRATEC  A KNELL","TACKSR  N UNIONE  W ROUND","SPASM A N ANTIC E F CLIFF","CROUPR  N ERECTP  L ERRED","BOOTY   O DEEPS   I PUNCH"," G G  U A DATUM N Z SORES","SPILT I O ONION T S GORED","BIRCHA  U TRIBEH  I SINCE","SHOWYT  A USINGF  D FRISK","SOLAR C D DEBIT A E UNDUE","LILACL  R AILEDM  N AHEAD","S  C CLOUTO  B O  I PERCH","MAPLE   I TOMBS   E CHILL","SMOCK A O BIBLE Z I FETCH","M  G OCHREN  E T  E HORNS","BANAL   W DRIFT   U HILLY","ADORN R O PAPAS M S MARTS","TONICH  N ROOFSO  E BLURT","ROUSE   U GRAPE   E GLARE","ROARSA  I DAMPSI  E IVORY","ABACK A I STOVE C I SHACK","POUCH   A GRAND   A VILLA","G  R RURALU  B N  B THEIR"," M G MENUS D E  I S PANSY"," G C GOLLY O I  S C WEEKS"," G C FULLY S A  T I POEMS"," F D PALED U U  N C MATED","SMASHT  K ORBITO  P PLUSH"," T R BEGAT M B  P B COMIC","CLAPS I O ENTRY G E GOADS","NOSED P A STATE I E SCARS"," F A PROUD A D  N I SCION"," M A GOLLY U I  S B BELIE","ELBOW   W MOVIE   N BUDGE"," F V PLAIT A S  I I PLOTS"," F C FAIRY U U  N M CABBY","B  A LASTSE  T A  I TRICE","SPASM R H FIERY O U CRIBS"," C C  H H RIGID N D NAMED","WRISTO  L MORALE  N NORTH"," K S FATAL R U  M C DAZED","ADOBE   R STRIP   S JERKS","SPITE A W STAID I R HOWLS"," R A BARDS Y I  O E UNDUE","STAKE H I TEXTS I E PRISM"," S L ONION I G  P I LEECH"," H S LYNCH E A  N L RAVED","S  T IDIOTG  U M  R ARISE","MUNCHE  O MAILSE  I SMOCK","FORKS F I  F L  E L TRESS"," G S  A A AMBLE M V WAVED"," Z P YEAST B A  R L HARMS"," B Q CROUP A A  V S VOMIT"," B C VALUE N B  J I VOUCH","A  F COOLSH  A E  R DIKES","TRIPSO  R TRAINE  S MOMMA","DUMPSU  R PIVOTE  O SHAFT","CLEFSI  O GENREA  T ROUSE","UNCUT   L TWICE   E SORRY","S  S PESTSI  A L  L LACES","SPITE L R RADII Z A FALLS","GUISER  T ENVOYE  L DUPED","C  G LEARNI  U F  E FITLY","DITCH   I LEAVE   I GIRLS","ATOLL I Y STORE H I PEACH","POISE   T GENUS   F GULFS","TEACHE  Y MINCEP  L OOZES","T  V H  Y OPTICN  N GANGS","A  C SNEAKS  C E  H TOTEM","BUTTS   R DEMON   U UNITS"," E K SQUAW U R  A M BLEAK","PATHS R A GENRE N E BALMY","TRIPEH  A INERTN  K KNEAD"," B R NATAL Y B  O B LUCID","BOUGHA  U SORESI  S CHATS"," Q G  U R DONOR T W THINE","TOAST B W PESOS S R BEGET","HASTY   Y FETID   N LINGO","SCRAP A U AMIGO E E GLARE","SHRUB  A OTABOO  B NJOINS","CUBES  R OADIEU  B TBEECH","SHRUB Y  OBEAUX N  EPAPER","H L CA E UVIGILO A TCOLDS"," B  C A  HHYDRA O  FQUAFF","DAUBSI N WS T IK I LSPELL","C G JI O ERENEWC N EAVAIL","S R MPROBEI U LN G OSTERN","U D BSCULLH C UE T ERISER","USERS H  HMAMMA R  WBEVEL","SOLID D  R D  A E  KGRADE","  W RFRAME  G I  E GSIREN","RACED  R ESPERM  D OBROWN","COACHL   OIGLOOM   FBLOTS","SNIFF E  L V  O E  CBRICK","CHORD Y  AREACT N  ERAFTS","  F G  U AFUNGI  G NCLIPS","WAFER D  A I  Z E  OTUTOR","QUOTH    OMOTTO    KPAINS","  T GBAYOU  I I  N SFUGUE","DOMESO U NS S OE I BDUCTS","FROST    EAWFUL    LPEONS"," S  C T  H O  U O  NBLEAK","M F WO U RM N IM G TAGILE","ASSET  N RCREDO  E TWORKS","JUICEA   IICINGL   HSPORT"," L  PFUNGI N  V A  OFRONT"," M  ELARVA T  G C  ECHEER","CLIMBO   ULIGHTI   TCROWS","A S PMAKERE U IN L EDALES","  D EVOWEL  E O  L PBATHE","STOICA P HI E AN R ITRAIN","CLIMB E  AHATER P  OSTERN"," D  BDICTA T  R T  EMOWED","CUFFS  E HFOLIO  L RBISON","E   TNEWERD   UO   TWHICH"," P  F I  ESEVEN R  CUSAGE","S M DQUASIU N CA I TTIARA","SCRUB    UPANIC    KMORES","A F FB E AA W IF E RTURNS"," L  MLINGO N  A G  NLOVES","LARVA    CBLUER    ETENTS","WEEDS X  L C  U E  NFLING","F A GL L LA E ER R AEATEN","  H PSWEAR  R A  O YBENDS"," D  SGRAFT A  O F  OSTRIP","EPOCH L  AWAKEN N  DDECRY","FAUNAA R BD B BE A ESUNNY"," F  PBAYOU L  R S  EVERSE","LILACA L LKHAKIE M CSNACK","WHARF E  O L  C L  AVOWEL","AMOUR O  IEMITS M  KGAYLY","MAMMA  A TLINGO  G NCRONE"," R  QBAYOU D  I I  EPIVOT","BASIC L  OVIDEO B  LGIFTS","OBESE R  XMAMMA V  LPOINT","AWFULD U OI N AE G MUNITY","BINDS    PKHAKI    RHALVE","BASINE   OR   UG   NSHUTS","CACHE  R LGAUZE  M CCUBIT","GAUNTR N IO F LO I TMUTES","THUMB    OHELIX    ETILED","CHEAPH   LO   II   ERIFTS","A   SBUNCHY   AS   PSLATE","  H SSCALP  R I  E NVASES","S D HIMAGEN T RE U OWOMAN","S G AHELIXI O LR B EKEELS","TULIP    ASQUAW    NPATES"," A  G L  OWOMEN N  GFEATS","NYMPH  O IJEWEL  E LBURLY","G F FU U II N NL G EDRIED","FLING    RVODKA    ICAPON","FORCE U  XSTOIC D  ENOVEL"," L  BFORGO Y  N A  EBLAND","TALON L  EVILLA B  RLIVES"," A  F D  ARISEN E  CDUSTY"," B  TLEDGE L  E I  NNEARS","SHELF Y  IPEARL N  TEARTH","C P WH I AASPENF E EFIRES","JAILS    URADII    TBUDGE"," U  BFLAIL T  O R  OTAMED","CAVES U  OIDYLL I  OMOCKS"," D  CNEVER V  U I  SFLUSH"," H  FSOBER T  E E  AFLOCK","RISEN  C ASHOUT  U TPETTY","EVADE I  XHOIST L  OBASIL","FIEND G  RALIVE O  ASOUND","EXTRAA I MR B BT I LHEAVE","TROOPO U ET T NE D CMOOSE"," W  LNIECE S  A E  SBROTH"," R  WHELLO F  M E  EGREEN","RIPEN  I EAGLOW  O LFITLY","G R TU E II A NL L TDAMPS","OBEYS    TOUTDO    LGOUGE"," B  LLARVA Y  I O  RHURLS","W R MI A UN B MC B PHAILS","TIARA S  C S  O U  RLEMON"," Q  BGUANO E  W L  EFLAIL","P A PL T UALOOFT N FEVERY","M B SAWAITX Y EI O AMOUND"],mt=1,yt=.2,lu=.3,Ln=.15,rn=mt+yt,ht=lu,Gi=lu-Ln,En=.88,ZS=.12;function $n(n){return new jn(n)}const _i=5,_r=En,Os=.15,cu=_r+Os,uu=_i*cu+Os,hu=_r+Os*2,du=.18,JS=.28,QS=.18;function Jt(n,e,t,i,s,r){const a=n.length/3;n.push(...t,...i,...s,...r),e.push(a,a+1,a+2,a,a+2,a+3)}function cc(n,e){const t=new Rt;return t.setAttribute("position",new Tt(n,3)),t.setIndex(e),t.computeVertexNormals(),t}function $S(){const n=[],e=[],t=[],i=[],s=uu,r=hu,a=du,l=a+JS,d=QS;Jt(n,e,[0,a,0],[s,a,0],[s,a,r],[0,a,r]),Jt(t,i,[0,0,0],[s,0,0],[s,0,r],[0,0,r]),Jt(t,i,[s,0,0],[0,0,0],[0,a,0],[s,a,0]),Jt(t,i,[0,0,r],[s,0,r],[s,a,r],[0,a,r]),Jt(t,i,[0,0,0],[0,0,r],[0,a,r],[0,a,0]),Jt(t,i,[s,0,r],[s,0,0],[s,a,0],[s,a,r]),Jt(n,e,[0,l,r],[s,l,r],[s,l,r+d],[0,l,r+d]),Jt(t,i,[0,0,r],[s,0,r],[s,0,r+d],[0,0,r+d]),Jt(t,i,[s,a,r],[0,a,r],[0,l,r],[s,l,r]),Jt(t,i,[0,0,r+d],[s,0,r+d],[s,l,r+d],[0,l,r+d]),Jt(t,i,[0,0,r],[0,0,r+d],[0,l,r+d],[0,l,r]),Jt(t,i,[s,0,r+d],[s,0,r],[s,l,r],[s,l,r+d]);const u=$n({color:13421772,side:on}),p=$n({color:0,side:on}),o=new At(cc(n,e),u);o.geometry.translate(-s/2,0,0);const c=new At(cc(t,i),p);c.geometry.translate(-s/2,0,0);const h=new jt;return h.add(o,c),h}function jS(n){const e=n*cu+Os+_r,t=Os+_r;return new w(e-uu/2-.42,du,t-hu/2+.3)}const fu=qS.split(/\r?\n/).map(n=>n.trim()).filter(Boolean);function e0(n){if(So.length===0)throw new Error("No puzzles available — run build-puzzles first.");const e=[...So[Math.floor(Math.random()*So.length)]],t=[],i=n._board.nRows*n._board.nCols;for(;e.length<i;)e.push(" ");for(let s=0;s<i;s++){const r=e[s];if(r===" ")continue;const a=t0(s);let l=0;for(const d of a)e[d]!==" "&&l++;if(l>2&&(t.push(r),e[s]=" ",t.length===_i))break}for(WS(t);t.length<_i;)Math.random()>.5?t.unshift(" "):t.push(" ");return[...t,...e].join("")}const Fi=[];function t0(n){Fi.length=0;const e=Math.floor(n/5),t=n%5;return t>0&&Fi.push(n-1),t<4&&Fi.push(n+1),e>0&&Fi.push(n-5),e<4&&Fi.push(n+5),Fi}const hs=[];function uc(n){if(n._focusedTile){n._queueReturnFocusedTile();return}if(n.puzzleHistory.length<2)return;const e=n.puzzleHistory.pop(),t=n.puzzleHistory.at(-1),i=e.length;hs.length=0;for(let s=0;s<i;s++){const r=e.charAt(s),a=t.charAt(s);r!==a&&hs.push(s)}if(hs.length===2){const s=n._scrabbleTiles[hs[0]],r=n._scrabbleTiles[hs[1]];_a=!0,s.glyph===" "?(n._mouseDownOnTile(r),n.mouseUp(),n._mouseDownOnTile(s)):(n._mouseDownOnTile(s),n.mouseUp(),n._mouseDownOnTile(r)),_a=!1}}function pu(n){n.puzzleHistory.length=0;let e=0;const t=e0(n);for(const i of n._scrabbleTiles)i.isHovered=!1,i.targetGlowing=!1,i.isGlowing=!1,i.slotPos=n.slotPos[e],i.slotQuat=n.slotQuat[e],i.group.position.copy(i.slotPos),i.group.quaternion.copy(i.slotQuat),i.setLetter(t[e++]);Va(n)}let _a=!1;function Va(n){const e=new Set;let t="";const i=n._scrabbleTiles.length;for(let s=0;s<i;s++){const r=n._scrabbleTiles[s];r.targetGlowing=!1,n._scrabbleTiles[s].glowDelay=s*10,r.glyph!==" "&&e.add(s),t+=r.glyph}t!==n.puzzleHistory.at(-1)&&!_a&&n.puzzleHistory.push(t);for(let s=0;s<n._board.nRows;s++)if(n0(n,s))for(let r=0;r<n._board.nCols;r++){const a=xr(n,s,r);n._scrabbleTiles[a].targetGlowing=!0,n._scrabbleTiles[a].glowDelay=r*50,e.delete(a)}for(let s=0;s<n._board.nCols;s++)if(i0(n,s))for(let r=0;r<n._board.nRows;r++){const a=xr(n,r,s);n._scrabbleTiles[a].targetGlowing=!0,n._scrabbleTiles[a].glowDelay=r*50,e.delete(a)}return e.size===0}function xr(n,e,t){return _i+e*n._board.nCols+t}function n0(n,e){var s;const t=[];for(let r=0;r<n._board.nCols;r++){const a=n._scrabbleTiles[xr(n,e,r)],l=a===((s=n._focusedTile)==null?void 0:s.tile)?" ":a.glyph;if(l===" ")return!1;t.push(l)}const i=t.join("").toLowerCase();return fu.includes(i)}function i0(n,e){var s;const t=[];for(let r=0;r<n._board.nRows;r++){const a=n._scrabbleTiles[xr(n,r,e)],l=a===((s=n._focusedTile)==null?void 0:s.tile)?" ":a.glyph;if(l===" ")return!1;t.push(l)}const i=t.join("").toLowerCase();return fu.includes(i)}const Cs="#cccccc",Ao=new Qe(0),_o=new Qe(5592405),hc=new Qe(4482696),dc=new Qe(14544639),s0=11184810,Eu=0,Bi=[];function r0(n){return Bi.length=0,n<12&&Bi.push(n+4),n>4&&Bi.push(n-4),n%4>0&&Bi.push(n-1),n%4<3&&Bi.push(n+1),Bi}function o0(n){const e=[];let t=15;for(let i=0;i<n;i++){const s=r0(t);e.length>0&&s.includes(e.at(-1).to)&&s.splice(s.indexOf(e.at(-1).to),1);const r=Ei(s);e.push({from:r,to:t}),t=r}for(const i of[...e].reverse())e.push({from:i.to,to:i.from});return e}function Ds(n){const e=document.getElementById(n);if(!e)throw new Error(`missing ${n} element`);return e}function a0(n,e,t){return new Promise(i=>{const s=n.getContext("2d"),r=new Image;r.onload=function(){const a=t,l=t;n.width=a,n.height=l,s.fillStyle="white",s.fillRect(0,0,a,l),s.drawImage(r,(a-r.width)/2,(l-r.height)/2),i()},r.src=e})}function l0(n,e=1){const t=n.getContext("2d"),{width:i,height:s}=n,a=t.getImageData(0,0,i,s).data,l=new Uint8ClampedArray(a),d=(u,p)=>(p*i+u)*4;for(let u=0;u<s;u++)for(let p=0;p<i;p++){let o=255;for(let h=-e;h<=e;h++)for(let m=-e;m<=e;m++){const S=p+m,E=u+h;if(S<0||E<0||S>=i||E>=s)continue;const f=a[d(S,E)];f<o&&(o=f)}const c=d(p,u);l[c]=o,l[c+1]=o,l[c+2]=o,l[c+3]=255}t.putImageData(new ImageData(l,i,s),0,0)}function c0(n,e,t,i,s=0){const r=new ei(t,t,i,i),a=r.getAttribute("position"),d=n.getContext("2d").getImageData(0,0,n.width,n.height).data;for(let u=0;u<a.count;u++){const p=a.getX(u)/t+.5,o=-a.getY(u)/t+.5,c=Math.round(p*n.width),h=Math.round(o*n.height);d[(h*n.width+c)*4]<100?a.setZ(u,e+s):a.setZ(u,s)}return u0(r)}function u0(n){const e=n.attributes.position,t=n.index;if(!e)throw new Error("PlaneGeometry must have a position attribute.");const i=[-1,0,1],s=[-1,0,1],r=[-1/0,...i,1/0],a=[-1/0,...s,1/0],l=Array.from({length:16},()=>new Rt),d=Array.from({length:16},()=>new Map),u=Array.from({length:16},()=>[]),p=Array.from({length:16},()=>[]);function o(h,m){let S=0,E=0;for(;S<4&&h>=r[S+1];)S++;for(;E<4&&m>=a[E+1];)E++;return S>3&&(S=3),E>3&&(E=3),E*4+S}function c(h,m){const S=d[h];if(S.has(m))return S.get(m);const E=u[h].length/3;return u[h].push(e.getX(m),e.getY(m),e.getZ(m)),S.set(m,E),E}if(t)for(let h=0;h<t.count;h+=3){const m=t.getX(h),S=t.getX(h+1),E=t.getX(h+2),f=e.getX(m),_=e.getY(m),A=e.getX(S),R=e.getY(S),C=e.getX(E),L=e.getY(E),D=o((f+A+C)/3,(_+R+L)/3),F=c(D,m),I=c(D,S),M=c(D,E);p[D].push(F,I,M)}else for(let h=0;h<e.count;h+=3){const m=e.getX(h),S=e.getY(h),E=e.getX(h+1),f=e.getY(h+1),_=e.getX(h+2),A=e.getY(h+2),R=o((m+E+_)/3,(S+f+A)/3),C=c(R,h),L=c(R,h+1),D=c(R,h+2);p[R].push(C,L,D)}for(let h=0;h<16;h++){const m=new Rt;m.setAttribute("position",new Tt(u[h],3)),m.setIndex(p[h]),m.computeVertexNormals(),l[h]=m}return l}const Qn=new jt,Or=new jt;Or.rotateX(-Math.PI/2);Qn.add(Or);const ka=new At(new ei(10,10),new jn({color:Cs}));ka.position.set(0,-.2,0);ka.rotateX(-Math.PI/2+.2);Qn.add(ka);const br=new zt;br.position.set(-2,5,5);br.lookAt(0,-1,0);let mu=!1,rr=0;const h0=1e3;function d0(){mu=!0}let xo=0,Hi=0;const Su=200,Au=50,fc=o0(Au),bn=Array.from({length:16},()=>new jt);Or.add(...bn);const gr=[],f0=650,p0=4,E0=200,Ps="title-canvas",m0="images/title.png";function _u(n){if(mu&&(rr=Math.min(1,rr+n/h0),Or.position.y=-rr*1,rr>=1))return!0;if(Hi<1){const{from:e,to:t}=fc[xo];if(Hi=Math.min(1,Hi+n/Su),bn[e].position.copy(gr[e]).lerp(gr[t],Hi),Hi>=1){const s=bn[e];bn[e]=bn[t],bn[t]=s,xo++,xo<fc.length&&(Hi=0)}}return!1}function S0(){return a0(Ds(Ps),m0,f0)}function A0(){Ya(Ds(Ps),0,Cs,.2)}function _0(){Ya(Ds(Ps),.4,Eu)}function x0(){const n=Ds(Ps);l0(n,1)}function g0(){const n=Ds(Ps);Ya(n,.3,7829367)}function T0(){gr.length=0;for(const n of bn){const t=n.children[0].geometry.getAttribute("position"),i=t.getX(0),s=t.getY(0),r=t.getZ(0);for(const l of n.children)l.geometry.translate(-i,-s,-r);const a=new w(i,s,r);a.multiplyScalar(1.03),n.position.copy(a),gr.push(a)}bn[15].visible=!1;for(let n=0;n<Au;n++)_u(2*Su)}function Ya(n,e,t,i=0){const s=c0(n,e,p0,E0,i),r=new jn({color:t});for(let a=0;a<16;a++)bn[a].add(new At(s[a],r))}_n("title-image",S0);_n("title-base-layer",A0);_n("title-side-layer",_0);for(let n=0;n<10;n++)_n(`title-dilate-${n}`,x0);_n("title-top-layer",g0);_n("title-finalize",T0);const pc={type:"change"},Wa={type:"start"},xu={type:"end"},or=new Pa,Ec=new On,R0=Math.cos(70*Nh.DEG2RAD),gt=new w,Ht=2*Math.PI,rt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},go=1e-6;class M0 extends jd{constructor(e,t=null){super(e,t),this.state=rt.NONE,this.target=new w,this.cursor=new w,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Yi.ROTATE,MIDDLE:Yi.DOLLY,RIGHT:Yi.PAN},this.touches={ONE:Vi.ROTATE,TWO:Vi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new w,this._lastQuaternion=new Sn,this._lastTargetPosition=new w,this._quat=new Sn().setFromUnitVectors(e.up,new w(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Dl,this._sphericalDelta=new Dl,this._scale=1,this._panOffset=new w,this._rotateStart=new le,this._rotateEnd=new le,this._rotateDelta=new le,this._panStart=new le,this._panEnd=new le,this._panDelta=new le,this._dollyStart=new le,this._dollyEnd=new le,this._dollyDelta=new le,this._dollyDirection=new w,this._mouse=new le,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=I0.bind(this),this._onPointerDown=v0.bind(this),this._onPointerUp=y0.bind(this),this._onContextMenu=N0.bind(this),this._onMouseWheel=b0.bind(this),this._onKeyDown=C0.bind(this),this._onTouchStart=D0.bind(this),this._onTouchMove=P0.bind(this),this._onMouseDown=L0.bind(this),this._onMouseMove=O0.bind(this),this._interceptControlDown=U0.bind(this),this._interceptControlUp=w0.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(pc),this.update(),this.state=rt.NONE}update(e=null){const t=this.object.position;gt.copy(t).sub(this.target),gt.applyQuaternion(this._quat),this._spherical.setFromVector3(gt),this.autoRotate&&this.state===rt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(i)&&isFinite(s)&&(i<-Math.PI?i+=Ht:i>Math.PI&&(i-=Ht),s<-Math.PI?s+=Ht:s>Math.PI&&(s-=Ht),i<=s?this._spherical.theta=Math.max(i,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+s)/2?Math.max(i,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const a=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=a!=this._spherical.radius}if(gt.setFromSpherical(this._spherical),gt.applyQuaternion(this._quatInverse),t.copy(this.target).add(gt),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let a=null;if(this.object.isPerspectiveCamera){const l=gt.length();a=this._clampDistance(l*this._scale);const d=l-a;this.object.position.addScaledVector(this._dollyDirection,d),this.object.updateMatrixWorld(),r=!!d}else if(this.object.isOrthographicCamera){const l=new w(this._mouse.x,this._mouse.y,0);l.unproject(this.object);const d=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=d!==this.object.zoom;const u=new w(this._mouse.x,this._mouse.y,0);u.unproject(this.object),this.object.position.sub(u).add(l),this.object.updateMatrixWorld(),a=gt.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;a!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(a).add(this.object.position):(or.origin.copy(this.object.position),or.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(or.direction))<R0?this.object.lookAt(this.target):(Ec.setFromNormalAndCoplanarPoint(this.object.up,this.target),or.intersectPlane(Ec,this.target))))}else if(this.object.isOrthographicCamera){const a=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),a!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>go||8*(1-this._lastQuaternion.dot(this.object.quaternion))>go||this._lastTargetPosition.distanceToSquared(this.target)>go?(this.dispatchEvent(pc),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?Ht/60*this.autoRotateSpeed*e:Ht/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){gt.setFromMatrixColumn(t,0),gt.multiplyScalar(-e),this._panOffset.add(gt)}_panUp(e,t){this.screenSpacePanning===!0?gt.setFromMatrixColumn(t,1):(gt.setFromMatrixColumn(t,0),gt.crossVectors(this.object.up,gt)),gt.multiplyScalar(e),this._panOffset.add(gt)}_pan(e,t){const i=this.domElement;if(this.object.isPerspectiveCamera){const s=this.object.position;gt.copy(s).sub(this.target);let r=gt.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/i.clientHeight,this.object.matrix),this._panUp(2*t*r/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const i=this.domElement.getBoundingClientRect(),s=e-i.left,r=t-i.top,a=i.width,l=i.height;this._mouse.x=s/a*2-1,this._mouse.y=-(r/l)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-Ht*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._rotateStart.set(i,s)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panStart.set(i,s)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const i=this._getSecondPointerPosition(e),s=.5*(e.pageX+i.x),r=.5*(e.pageY+i.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(Ht*this._rotateDelta.x/t.clientHeight),this._rotateUp(Ht*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panEnd.set(i,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),i=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(i*i+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const a=(e.pageX+t.x)*.5,l=(e.pageY+t.y)*.5;this._updateZoomParameters(a,l)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new le,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,i={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}}function v0(n){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(n.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(n)&&(this._addPointer(n),n.pointerType==="touch"?this._onTouchStart(n):this._onMouseDown(n)))}function I0(n){this.enabled!==!1&&(n.pointerType==="touch"?this._onTouchMove(n):this._onMouseMove(n))}function y0(n){switch(this._removePointer(n),this._pointers.length){case 0:this.domElement.releasePointerCapture(n.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(xu),this.state=rt.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function L0(n){let e;switch(n.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Yi.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(n),this.state=rt.DOLLY;break;case Yi.ROTATE:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}break;case Yi.PAN:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=rt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=rt.PAN}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Wa)}function O0(n){switch(this.state){case rt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(n);break;case rt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(n);break;case rt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(n);break}}function b0(n){this.enabled===!1||this.enableZoom===!1||this.state!==rt.NONE||(n.preventDefault(),this.dispatchEvent(Wa),this._handleMouseWheel(this._customWheelEvent(n)),this.dispatchEvent(xu))}function C0(n){this.enabled!==!1&&this._handleKeyDown(n)}function D0(n){switch(this._trackPointer(n),this._pointers.length){case 1:switch(this.touches.ONE){case Vi.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(n),this.state=rt.TOUCH_ROTATE;break;case Vi.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(n),this.state=rt.TOUCH_PAN;break;default:this.state=rt.NONE}break;case 2:switch(this.touches.TWO){case Vi.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(n),this.state=rt.TOUCH_DOLLY_PAN;break;case Vi.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(n),this.state=rt.TOUCH_DOLLY_ROTATE;break;default:this.state=rt.NONE}break;default:this.state=rt.NONE}this.state!==rt.NONE&&this.dispatchEvent(Wa)}function P0(n){switch(this._trackPointer(n),this.state){case rt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(n),this.update();break;case rt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(n),this.update();break;case rt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(n),this.update();break;case rt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(n),this.update();break;default:this.state=rt.NONE}}function N0(n){this.enabled!==!1&&n.preventDefault()}function U0(n){n.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function w0(n){n.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}class gu{constructor(e){ce(this,"_canvas");ce(this,"_renderer");ce(this,"_camera");this.app=e,this._canvas=e._canvas,this._renderer=e._renderer,this._camera=e._camera}}class F0 extends gu{constructor(){super(...arguments);ce(this,"_pix",1);ce(this,"_renderSize",new le)}onResize(){this._updateCam(this._camera),this._updateCam(this.app._nextCamera),this._updateCam(br),this._applyRendererResolution()}_updateCam(t){t.aspect=window.innerWidth/window.innerHeight,t.updateProjectionMatrix()}_applyRendererResolution(){const i=(window.devicePixelRatio||1)/this.app._renderPixelScale;this._pix=i,this._renderer.setPixelRatio(i),this._renderer.setSize(window.innerWidth,window.innerHeight),this._positionControlOverlays()}_positionControlOverlays(){const t=document.getElementById("overlay-canvas"),i=t.getContext("2d");t.width=this._renderSize.x,t.height=this._renderSize.y,i.imageSmoothingEnabled=!1}}class za{constructor(){ce(this,"duration",3e3);ce(this,"hasRenderedScene",!1);ce(this,"shouldSkipTileExit",!1)}getMaskCount(e){return this.getMasks(e).length}initMeshes(e){}updateMeshes(e,t){}cleanupMeshes(e){}}const Ss={entrance:new WeakMap,exit:new WeakMap},Tr={entrance:new WeakSet,exit:new WeakSet},B0=new WeakMap,H0=new WeakMap;function Cr(n){return n?"exit":"entrance"}function Dr(n,e){const t=e==="exit"?H0:B0;let i=t.get(n);return i||(i=[],t.set(n,i)),i}function pn(n){return Math.max(0,Math.min(1,n))}function G0(n){const e=pn(n.startScanIndex/(n.w*n.h));if(n.activeCompId<0)return e;const t=pn(n.bfsReadIndex/Math.max(1,n.bfsQueue.length));return pn(e*.85+t*.15)}function V0(n){if(n.phase==="prepare-color")return 0;if(n.phase==="scan-color-mask")return pn(n.maskScanIndex/Math.max(1,n.flipped.length)*.45);if(n.phase==="components")return pn(.45+G0(n)*.4);if(n.phase==="build-regions"){const e=pn(n.buildCompIndex/Math.max(1,n.compBounds.length));return pn(.85+e*.15)}return 0}function k0(n){if(Dr(n.app,n.kind).length>=100)return 100;const e=Math.max(1,n.flipped.length);if(n.phase==="render")return 1;if(n.phase==="flip")return 2+18*pn(n.flipY/Math.max(1,n.h));if(n.phase==="collect-colors")return 20+15*pn(n.colorScanIndex/e);if(n.phase==="done")return 100;const t=Math.max(1,n.colors.length,n.colorSet.size),i=65/t,s=Math.min(n.colorIndex,t)*i,r=V0(n)*i;return pn((35+s+r)/100)*100}function Y0(n,e){const t=window.innerWidth,i=window.innerHeight;return{app:n,kind:e,w:t,h:i,phase:"render",pixels:new Uint8Array(t*i*4),flipped:new Uint8ClampedArray(t*i*4),flipY:0,colorSet:new Set,colorScanIndex:0,colors:[],colorIndex:0,targetHex:0,filterColor:at._MASK_FILTER_COLORS[0],maskData:null,md:null,maskScanIndex:0,componentMap:new Int32Array(t*i).fill(-1),compBounds:[],compSamples:[],startScanIndex:0,bfsQueue:[],bfsReadIndex:0,activeCompId:-1,activeBounds:null,buildCompIndex:0,raycaster:new Ga,rayNdc:new le}}function W0(n){const{w:e,h:t}=n;n.targetHex=n.colors[n.colorIndex],n.filterColor=at._MASK_FILTER_COLORS[n.colorIndex%at._MASK_FILTER_COLORS.length],n.maskData=new ImageData(e,t),n.md=n.maskData.data,n.maskScanIndex=0,n.componentMap.fill(-1),n.compBounds=[],n.compSamples=[],n.startScanIndex=0,n.bfsQueue.length=0,n.bfsReadIndex=0,n.activeCompId=-1,n.activeBounds=null,n.buildCompIndex=0}function z0(n,e){const{app:t,w:i,h:s,compBounds:r,componentMap:a,md:l,filterColor:d}=n,u=1.5*Math.hypot(i/2,s/2),p=Dr(t,n.kind);if(!l)return;const o=r[e],c=o.maxX-o.minX+1,h=o.maxY-o.minY+1;if(c===i&&h===s)return;const m=new OffscreenCanvas(c,h),S=m.getContext("2d"),E=S.createImageData(c,h),f=E.data;for(let D=o.minY;D<=o.maxY;D++)for(let F=o.minX;F<=o.maxX;F++)if(a[D*i+F]===e){const I=((D-o.minY)*c+(F-o.minX))*4,M=(D*i+F)*4;f[I]=l[M],f[I+1]=l[M+1],f[I+2]=l[M+2],f[I+3]=l[M+3]}S.putImageData(E,0,0);const _=new w(0,0,0);let A=0,R=0,C=0,L=0;if(_){const D=_.clone().project(t._nextCamera),F=(D.x+1)/2*i,I=(1-D.y)/2*s;A=o.minX-(F-m.width/2),R=o.minY-(I-m.height/2);const M=(o.minX+o.maxX)/2,N=(o.minY+o.maxY)/2,V=M-i/2,Z=N-s/2;let J=2*Math.hypot(V,Z)+Math.random()*100;J=Math.max(J,u);const Q=Math.atan2(Z,V);C=J*Math.cos(Q),L=J*Math.sin(Q)}p.length>=100||p.push({filterColor:d,canvas:m,x:o.minX,y:o.minY,worldPos:_,restOffsetX:A,restOffsetY:R,animOffsetX:C,animOffsetY:L,restAngle:-Math.PI+2*Math.random()*Math.PI})}function K0(n){const{app:e,w:t,h:i}=n,s=new wn(t,i);s.texture.colorSpace=Nt,e._renderer.setRenderTarget(s);const r=e._scrabbleTiles.some(a=>a.isVisible);if(r)for(const a of e._allTiles)a.hide();if(Qn.visible=!1,e._renderer.render(e._scene,n.kind==="entrance"?e._nextCamera:e._camera),Qn.visible=!0,r)for(const a of e._allTiles)a.show();e._renderer.setRenderTarget(null),e._renderer.readRenderTargetPixels(s,0,0,t,i,n.pixels),s.dispose(),n.phase="flip"}function X0(n,e){const{w:t,h:i}=n;for(;n.flipY<i;n.flipY++){const a=(i-1-n.flipY)*t*4,l=n.flipY*t*4;if(n.flipped.set(n.pixels.subarray(a,a+t*4),l),(n.flipY&31)===0&&performance.now()>=e)return!1}const s=document.getElementById("buffer-canvas");s.width=t,s.height=i;const r=Uint8ClampedArray.from(n.flipped);return s.getContext("2d").putImageData(new ImageData(r,t,i),0,0),n.phase="collect-colors",!0}function q0(n,e){for(;n.colorScanIndex<n.flipped.length;n.colorScanIndex+=4)if(!(n.flipped[n.colorScanIndex]>150)&&(n.colorSet.add(n.flipped[n.colorScanIndex]<<16|n.flipped[n.colorScanIndex+1]<<8|n.flipped[n.colorScanIndex+2]),(n.colorScanIndex&4095)===0&&performance.now()>=e))return!1;if(n.colorSet.size>5)throw new Error(`Expected ≤5 unique colors, got ${n.colorSet.size}`);return n.colors=[...n.colorSet],n.colorIndex=0,n.phase="prepare-color",!0}function Z0(n,e){const t=n.md;if(!t)throw new Error("maskData not initialized");for(;n.maskScanIndex<n.flipped.length;n.maskScanIndex+=4)if((n.flipped[n.maskScanIndex]<<16|n.flipped[n.maskScanIndex+1]<<8|n.flipped[n.maskScanIndex+2])===n.targetHex&&(t[n.maskScanIndex]=n.flipped[n.maskScanIndex],t[n.maskScanIndex+1]=n.flipped[n.maskScanIndex+1],t[n.maskScanIndex+2]=n.flipped[n.maskScanIndex+2],t[n.maskScanIndex+3]=255),(n.maskScanIndex&4095)===0&&performance.now()>=e)return!1;return n.phase="components",!0}function J0(n,e){const{w:t,h:i}=n,s=n.md,r=n.activeBounds;if(!s)throw new Error("maskData not initialized");if(!r)throw new Error("active component bounds missing");let a=0;for(;n.bfsReadIndex<n.bfsQueue.length;){const u=n.bfsQueue[n.bfsReadIndex++],p=u%t,o=u/t|0;if(p<r.minX&&(r.minX=p),p>r.maxX&&(r.maxX=p),o<r.minY&&(r.minY=o),o>r.maxY&&(r.maxY=o),p>0&&n.componentMap[u-1]===-1&&s[(u-1)*4+3]>0&&(n.componentMap[u-1]=n.activeCompId,n.bfsQueue.push(u-1)),p<t-1&&n.componentMap[u+1]===-1&&s[(u+1)*4+3]>0&&(n.componentMap[u+1]=n.activeCompId,n.bfsQueue.push(u+1)),o>0&&n.componentMap[u-t]===-1&&s[(u-t)*4+3]>0&&(n.componentMap[u-t]=n.activeCompId,n.bfsQueue.push(u-t)),o<i-1&&n.componentMap[u+t]===-1&&s[(u+t)*4+3]>0&&(n.componentMap[u+t]=n.activeCompId,n.bfsQueue.push(u+t)),a++,(a&255)===0&&performance.now()>=e)return!1}const l=[],d=Math.max(1,Math.floor(n.bfsQueue.length/5));for(let u=0;u<n.bfsQueue.length&&l.length<5;u+=d)l.push(n.bfsQueue[u]);return n.compSamples.push(l),n.activeCompId=-1,n.activeBounds=null,n.bfsQueue.length=0,n.bfsReadIndex=0,!0}function Q0(n,e){const{w:t,h:i}=n,s=n.md;if(!s)throw new Error("maskData not initialized");let r=-1;for(;n.startScanIndex<t*i;n.startScanIndex++){if(s[n.startScanIndex*4+3]>0&&n.componentMap[n.startScanIndex]===-1){r=n.startScanIndex,n.startScanIndex++;break}if((n.startScanIndex&1023)===0&&performance.now()>=e)return!1}if(r<0)return n.phase="build-regions",!0;const a=n.compBounds.length,l={minX:t,maxX:-1,minY:i,maxY:-1};return n.compBounds.push(l),n.activeCompId=a,n.activeBounds=l,n.bfsQueue.length=0,n.bfsReadIndex=0,n.bfsQueue.push(r),n.componentMap[r]=a,!0}function $0(n,e){for(;performance.now()<e;){if(n.activeCompId>=0){if(!J0(n,e))return!1;continue}if(!Q0(n,e))return!1;if(n.phase==="build-regions")return!0}return!1}function j0(n,e){for(;n.buildCompIndex<n.compBounds.length;){if(performance.now()>=e)return!1;z0(n,n.buildCompIndex),n.buildCompIndex++}return n.colorIndex++,n.phase="prepare-color",!0}function eA(n,e){for(;performance.now()<e;){if(n.phase==="render"){K0(n);continue}if(n.phase==="flip"){if(!X0(n,e))return!1;continue}if(n.phase==="collect-colors"){if(!q0(n,e))return!1;continue}if(n.phase==="prepare-color"){if(n.colorIndex>=n.colors.length){n.phase="done";continue}W0(n),n.phase="scan-color-mask";continue}if(n.phase==="scan-color-mask"){if(!Z0(n,e))return!1;continue}if(n.phase==="components"){if(!$0(n,e))return!1;continue}if(n.phase==="build-regions"){if(!j0(n,e))return!1;continue}if(n.phase==="done")return!0}return n.phase==="done"}function Tu(n,e=!1){const t=Cr(e);Dr(n,t).length=0,Tr[t].delete(n),Ss[t].set(n,Y0(n,t))}function tA(n,e=5,t=!1){const i=Cr(t);if(!Ss[i].has(n)){if(Tr[i].has(n))return!0;Tu(n,t)}const s=Ss[i].get(n);if(!s)return!0;const r=Number.isFinite(e)?Math.max(0,e):Number.POSITIVE_INFINITY,a=performance.now()+r,l=eA(s,a);return l&&(Ss[i].delete(n),Tr[i].add(n)),l}function nA(n,e=!1){const t=Cr(e);if(Tr[t].has(n))return 100;const i=Ss[t].get(n);if(!i)return 0;const s=k0(i);return Math.max(0,Math.min(100,s))}function iA(n,e=!1){return Dr(n,Cr(e))}class sA extends za{constructor(e){super(),this._isExit=e}begin(e){Tu(e,this._isExit)}incremental(e,t=5){return tA(e,t,this._isExit)}getPercentComplete(e){return nA(e,this._isExit)}getMasks(e){return iA(e,this._isExit)}}const mc=["KeyA","ArrowLeft","KeyD","ArrowRight","Space"];class rA extends gu{constructor(){super(...arguments);ce(this,"_cpDummy",[0,0])}wireUiInput(){const t=this.app._canvas;window.addEventListener("keydown",i=>{mc.includes(i.code)&&this._routeKeyDown(i.code)&&(i.preventDefault(),i.stopPropagation())}),window.addEventListener("keyup",i=>{mc.includes(i.code)&&this._routeKeyUp(i.code)&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousedown",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerDown("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mousemove",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerMove("mouse",s[0],s[1])}),t.addEventListener("mouseup",i=>{const s=this._toCanvasPoint(t,i);s&&this._routePointerUp("mouse",s[0],s[1])&&(i.preventDefault(),i.stopPropagation())}),t.addEventListener("mouseleave",i=>{this._routePointerLeave("mouse")}),t.addEventListener("touchstart",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerDown(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchmove",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerMove(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchend",i=>{for(const s of Array.from(i.changedTouches)){const r=this._toCanvasPoint(t,s);if(!r)return;this._routePointerUp(s.identifier,r[0],r[1])}i.preventDefault()},{passive:!1}),t.addEventListener("touchcancel",i=>{for(const s of Array.from(i.changedTouches))this._routePointerLeave(s.identifier);i.preventDefault()},{passive:!1})}_toCanvasPoint(t,i){const s=t.getBoundingClientRect();return s.width<=0||s.height<=0?null:(this._cpDummy[0]=(i.clientX-s.left)*(t.width/s.width),this._cpDummy[1]=(i.clientY-s.top)*(t.height/s.height),this._cpDummy)}_routePointerMove(t,i,s){this.app.mouseMove(i,s)}_routeKeyDown(t){return!1}_routeKeyUp(t){return!1}_routePointerDown(t,i,s){return this.app.mouseMove(i,s),this.app.mouseDown(),!1}_routePointerUp(t,i,s){return this.app.mouseUp(),!1}_routePointerLeave(t){this.app.mouseUp(),document.documentElement.style.cursor="default"}}const oA=Nt;class Rr extends Ha{constructor(e){super(e),this.defaultDPI=90,this.defaultUnit="px"}load(e,t,i,s){const r=this,a=new Zd(r.manager);a.setPath(r.path),a.setRequestHeader(r.requestHeader),a.setWithCredentials(r.withCredentials),a.load(e,function(l){try{t(r.parse(l))}catch(d){s?s(d):console.error(d),r.manager.itemError(e)}},i,s)}parse(e){const t=this;function i(z,U){if(z.nodeType!==1)return;const v=R(z);let g=!1,K=null;switch(z.nodeName){case"svg":U=m(z,U);break;case"style":r(z);break;case"g":U=m(z,U);break;case"path":U=m(z,U),z.hasAttribute("d")&&(K=s(z));break;case"rect":U=m(z,U),K=d(z);break;case"polygon":U=m(z,U),K=u(z);break;case"polyline":U=m(z,U),K=p(z);break;case"circle":U=m(z,U),K=o(z);break;case"ellipse":U=m(z,U),K=c(z);break;case"line":U=m(z,U),K=h(z);break;case"defs":g=!0;break;case"use":U=m(z,U);const he=(z.getAttributeNS("http://www.w3.org/1999/xlink","href")||"").substring(1),Ae=z.viewportElement.getElementById(he);Ae?i(Ae,U):console.warn("SVGLoader: 'use node' references non-existent node id: "+he);break}K&&(U.fill!==void 0&&U.fill!=="none"&&K.color.setStyle(U.fill,oA),L(K,ge),V.push(K),K.userData={node:z,style:U});const oe=z.childNodes;for(let k=0;k<oe.length;k++){const he=oe[k];g&&he.nodeName!=="style"&&he.nodeName!=="defs"||i(he,U)}v&&(J.pop(),J.length>0?ge.copy(J[J.length-1]):ge.identity())}function s(z){const U=new ai,v=new le,g=new le,K=new le;let oe=!0,k=!1;const he=z.getAttribute("d");if(he===""||he==="none")return null;const Ae=he.match(/[a-df-z][^a-df-z]*/ig);for(let de=0,G=Ae.length;de<G;de++){const T=Ae[de],q=T.charAt(0),$=T.slice(1).trim();oe===!0&&(k=!0,oe=!1);let P;switch(q){case"M":P=E($);for(let O=0,ae=P.length;O<ae;O+=2)v.x=P[O+0],v.y=P[O+1],g.x=v.x,g.y=v.y,O===0?U.moveTo(v.x,v.y):U.lineTo(v.x,v.y),O===0&&K.copy(v);break;case"H":P=E($);for(let O=0,ae=P.length;O<ae;O++)v.x=P[O],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"V":P=E($);for(let O=0,ae=P.length;O<ae;O++)v.y=P[O],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"L":P=E($);for(let O=0,ae=P.length;O<ae;O+=2)v.x=P[O+0],v.y=P[O+1],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"C":P=E($);for(let O=0,ae=P.length;O<ae;O+=6)U.bezierCurveTo(P[O+0],P[O+1],P[O+2],P[O+3],P[O+4],P[O+5]),g.x=P[O+2],g.y=P[O+3],v.x=P[O+4],v.y=P[O+5],O===0&&k===!0&&K.copy(v);break;case"S":P=E($);for(let O=0,ae=P.length;O<ae;O+=4)U.bezierCurveTo(S(v.x,g.x),S(v.y,g.y),P[O+0],P[O+1],P[O+2],P[O+3]),g.x=P[O+0],g.y=P[O+1],v.x=P[O+2],v.y=P[O+3],O===0&&k===!0&&K.copy(v);break;case"Q":P=E($);for(let O=0,ae=P.length;O<ae;O+=4)U.quadraticCurveTo(P[O+0],P[O+1],P[O+2],P[O+3]),g.x=P[O+0],g.y=P[O+1],v.x=P[O+2],v.y=P[O+3],O===0&&k===!0&&K.copy(v);break;case"T":P=E($);for(let O=0,ae=P.length;O<ae;O+=2){const ue=S(v.x,g.x),Re=S(v.y,g.y);U.quadraticCurveTo(ue,Re,P[O+0],P[O+1]),g.x=ue,g.y=Re,v.x=P[O+0],v.y=P[O+1],O===0&&k===!0&&K.copy(v)}break;case"A":P=E($,[3,4],7);for(let O=0,ae=P.length;O<ae;O+=7){if(P[O+5]==v.x&&P[O+6]==v.y)continue;const ue=v.clone();v.x=P[O+5],v.y=P[O+6],g.x=v.x,g.y=v.y,a(U,P[O],P[O+1],P[O+2],P[O+3],P[O+4],ue,v),O===0&&k===!0&&K.copy(v)}break;case"m":P=E($);for(let O=0,ae=P.length;O<ae;O+=2)v.x+=P[O+0],v.y+=P[O+1],g.x=v.x,g.y=v.y,O===0?U.moveTo(v.x,v.y):U.lineTo(v.x,v.y),O===0&&K.copy(v);break;case"h":P=E($);for(let O=0,ae=P.length;O<ae;O++)v.x+=P[O],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"v":P=E($);for(let O=0,ae=P.length;O<ae;O++)v.y+=P[O],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"l":P=E($);for(let O=0,ae=P.length;O<ae;O+=2)v.x+=P[O+0],v.y+=P[O+1],g.x=v.x,g.y=v.y,U.lineTo(v.x,v.y),O===0&&k===!0&&K.copy(v);break;case"c":P=E($);for(let O=0,ae=P.length;O<ae;O+=6)U.bezierCurveTo(v.x+P[O+0],v.y+P[O+1],v.x+P[O+2],v.y+P[O+3],v.x+P[O+4],v.y+P[O+5]),g.x=v.x+P[O+2],g.y=v.y+P[O+3],v.x+=P[O+4],v.y+=P[O+5],O===0&&k===!0&&K.copy(v);break;case"s":P=E($);for(let O=0,ae=P.length;O<ae;O+=4)U.bezierCurveTo(S(v.x,g.x),S(v.y,g.y),v.x+P[O+0],v.y+P[O+1],v.x+P[O+2],v.y+P[O+3]),g.x=v.x+P[O+0],g.y=v.y+P[O+1],v.x+=P[O+2],v.y+=P[O+3],O===0&&k===!0&&K.copy(v);break;case"q":P=E($);for(let O=0,ae=P.length;O<ae;O+=4)U.quadraticCurveTo(v.x+P[O+0],v.y+P[O+1],v.x+P[O+2],v.y+P[O+3]),g.x=v.x+P[O+0],g.y=v.y+P[O+1],v.x+=P[O+2],v.y+=P[O+3],O===0&&k===!0&&K.copy(v);break;case"t":P=E($);for(let O=0,ae=P.length;O<ae;O+=2){const ue=S(v.x,g.x),Re=S(v.y,g.y);U.quadraticCurveTo(ue,Re,v.x+P[O+0],v.y+P[O+1]),g.x=ue,g.y=Re,v.x=v.x+P[O+0],v.y=v.y+P[O+1],O===0&&k===!0&&K.copy(v)}break;case"a":P=E($,[3,4],7);for(let O=0,ae=P.length;O<ae;O+=7){if(P[O+5]==0&&P[O+6]==0)continue;const ue=v.clone();v.x+=P[O+5],v.y+=P[O+6],g.x=v.x,g.y=v.y,a(U,P[O],P[O+1],P[O+2],P[O+3],P[O+4],ue,v),O===0&&k===!0&&K.copy(v)}break;case"Z":case"z":U.currentPath.autoClose=!0,U.currentPath.curves.length>0&&(v.copy(K),U.currentPath.currentPoint.copy(v),oe=!0);break;default:console.warn(T)}k=!1}return U}function r(z){if(!(!z.sheet||!z.sheet.cssRules||!z.sheet.cssRules.length))for(let U=0;U<z.sheet.cssRules.length;U++){const v=z.sheet.cssRules[U];if(v.type!==1)continue;const g=v.selectorText.split(/,/gm).filter(Boolean).map(K=>K.trim());for(let K=0;K<g.length;K++){const oe=Object.fromEntries(Object.entries(v.style).filter(([,k])=>k!==""));Z[g[K]]=Object.assign(Z[g[K]]||{},oe)}}}function a(z,U,v,g,K,oe,k,he){if(U==0||v==0){z.lineTo(he.x,he.y);return}g=g*Math.PI/180,U=Math.abs(U),v=Math.abs(v);const Ae=(k.x-he.x)/2,de=(k.y-he.y)/2,G=Math.cos(g)*Ae+Math.sin(g)*de,T=-Math.sin(g)*Ae+Math.cos(g)*de;let q=U*U,$=v*v;const P=G*G,O=T*T,ae=P/q+O/$;if(ae>1){const Te=Math.sqrt(ae);U=Te*U,v=Te*v,q=U*U,$=v*v}const ue=q*O+$*P,Re=(q*$-ue)/ue;let b=Math.sqrt(Math.max(0,Re));K===oe&&(b=-b);const x=b*U*T/v,Y=-b*v*G/U,se=Math.cos(g)*x-Math.sin(g)*Y+(k.x+he.x)/2,pe=Math.sin(g)*x+Math.cos(g)*Y+(k.y+he.y)/2,ne=l(1,0,(G-x)/U,(T-Y)/v),De=l((G-x)/U,(T-Y)/v,(-G-x)/U,(-T-Y)/v)%(Math.PI*2);z.currentPath.absellipse(se,pe,U,v,ne,ne+De,oe===0,g)}function l(z,U,v,g){const K=z*v+U*g,oe=Math.sqrt(z*z+U*U)*Math.sqrt(v*v+g*g);let k=Math.acos(Math.max(-1,Math.min(1,K/oe)));return z*g-U*v<0&&(k=-k),k}function d(z){const U=A(z.getAttribute("x")||0),v=A(z.getAttribute("y")||0),g=A(z.getAttribute("rx")||z.getAttribute("ry")||0),K=A(z.getAttribute("ry")||z.getAttribute("rx")||0),oe=A(z.getAttribute("width")),k=A(z.getAttribute("height")),he=1-.551915024494,Ae=new ai;return Ae.moveTo(U+g,v),Ae.lineTo(U+oe-g,v),(g!==0||K!==0)&&Ae.bezierCurveTo(U+oe-g*he,v,U+oe,v+K*he,U+oe,v+K),Ae.lineTo(U+oe,v+k-K),(g!==0||K!==0)&&Ae.bezierCurveTo(U+oe,v+k-K*he,U+oe-g*he,v+k,U+oe-g,v+k),Ae.lineTo(U+g,v+k),(g!==0||K!==0)&&Ae.bezierCurveTo(U+g*he,v+k,U,v+k-K*he,U,v+k-K),Ae.lineTo(U,v+K),(g!==0||K!==0)&&Ae.bezierCurveTo(U,v+K*he,U+g*he,v,U+g,v),Ae}function u(z){function U(oe,k,he){const Ae=A(k),de=A(he);K===0?g.moveTo(Ae,de):g.lineTo(Ae,de),K++}const v=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new ai;let K=0;return z.getAttribute("points").replace(v,U),g.currentPath.autoClose=!0,g}function p(z){function U(oe,k,he){const Ae=A(k),de=A(he);K===0?g.moveTo(Ae,de):g.lineTo(Ae,de),K++}const v=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,g=new ai;let K=0;return z.getAttribute("points").replace(v,U),g.currentPath.autoClose=!1,g}function o(z){const U=A(z.getAttribute("cx")||0),v=A(z.getAttribute("cy")||0),g=A(z.getAttribute("r")||0),K=new mi;K.absarc(U,v,g,0,Math.PI*2);const oe=new ai;return oe.subPaths.push(K),oe}function c(z){const U=A(z.getAttribute("cx")||0),v=A(z.getAttribute("cy")||0),g=A(z.getAttribute("rx")||0),K=A(z.getAttribute("ry")||0),oe=new mi;oe.absellipse(U,v,g,K,0,Math.PI*2);const k=new ai;return k.subPaths.push(oe),k}function h(z){const U=A(z.getAttribute("x1")||0),v=A(z.getAttribute("y1")||0),g=A(z.getAttribute("x2")||0),K=A(z.getAttribute("y2")||0),oe=new ai;return oe.moveTo(U,v),oe.lineTo(g,K),oe.currentPath.autoClose=!1,oe}function m(z,U){U=Object.assign({},U);let v={};if(z.hasAttribute("class")){const k=z.getAttribute("class").split(/\s/).filter(Boolean).map(he=>he.trim());for(let he=0;he<k.length;he++)v=Object.assign(v,Z["."+k[he]])}z.hasAttribute("id")&&(v=Object.assign(v,Z["#"+z.getAttribute("id")]));function g(k,he,Ae){Ae===void 0&&(Ae=function(G){return G.startsWith("url")&&console.warn("SVGLoader: url access in attributes is not implemented."),G}),z.hasAttribute(k)&&(U[he]=Ae(z.getAttribute(k))),v[k]&&(U[he]=Ae(v[k])),z.style&&z.style[k]!==""&&(U[he]=Ae(z.style[k]))}function K(k){return Math.max(0,Math.min(1,A(k)))}function oe(k){return Math.max(0,A(k))}return g("fill","fill"),g("fill-opacity","fillOpacity",K),g("fill-rule","fillRule"),g("opacity","opacity",K),g("stroke","stroke"),g("stroke-opacity","strokeOpacity",K),g("stroke-width","strokeWidth",oe),g("stroke-linejoin","strokeLineJoin"),g("stroke-linecap","strokeLineCap"),g("stroke-miterlimit","strokeMiterLimit",oe),g("visibility","visibility"),U}function S(z,U){return z-(U-z)}function E(z,U,v){if(typeof z!="string")throw new TypeError("Invalid input: "+typeof z);const g={WHITESPACE:/[ \t\r\n]/,DIGIT:/[\d]/,SIGN:/[-+]/,POINT:/\./,COMMA:/,/,EXP:/e/i,FLAGS:/[01]/},K=0,oe=1,k=2,he=3;let Ae=K,de=!0,G="",T="";const q=[];function $(ue,Re,b){const x=new SyntaxError('Unexpected character "'+ue+'" at index '+Re+".");throw x.partial=b,x}function P(){G!==""&&(T===""?q.push(Number(G)):q.push(Number(G)*Math.pow(10,Number(T)))),G="",T=""}let O;const ae=z.length;for(let ue=0;ue<ae;ue++){if(O=z[ue],Array.isArray(U)&&U.includes(q.length%v)&&g.FLAGS.test(O)){Ae=oe,G=O,P();continue}if(Ae===K){if(g.WHITESPACE.test(O))continue;if(g.DIGIT.test(O)||g.SIGN.test(O)){Ae=oe,G=O;continue}if(g.POINT.test(O)){Ae=k,G=O;continue}g.COMMA.test(O)&&(de&&$(O,ue,q),de=!0)}if(Ae===oe){if(g.DIGIT.test(O)){G+=O;continue}if(g.POINT.test(O)){G+=O,Ae=k;continue}if(g.EXP.test(O)){Ae=he;continue}g.SIGN.test(O)&&G.length===1&&g.SIGN.test(G[0])&&$(O,ue,q)}if(Ae===k){if(g.DIGIT.test(O)){G+=O;continue}if(g.EXP.test(O)){Ae=he;continue}g.POINT.test(O)&&G[G.length-1]==="."&&$(O,ue,q)}if(Ae===he){if(g.DIGIT.test(O)){T+=O;continue}if(g.SIGN.test(O)){if(T===""){T+=O;continue}T.length===1&&g.SIGN.test(T)&&$(O,ue,q)}}g.WHITESPACE.test(O)?(P(),Ae=K,de=!1):g.COMMA.test(O)?(P(),Ae=K,de=!0):g.SIGN.test(O)?(P(),Ae=oe,G=O):g.POINT.test(O)?(P(),Ae=k,G=O):$(O,ue,q)}return P(),q}const f=["mm","cm","in","pt","pc","px"],_={mm:{mm:1,cm:.1,in:1/25.4,pt:72/25.4,pc:6/25.4,px:-1},cm:{mm:10,cm:1,in:1/2.54,pt:72/2.54,pc:6/2.54,px:-1},in:{mm:25.4,cm:2.54,in:1,pt:72,pc:6,px:-1},pt:{mm:25.4/72,cm:2.54/72,in:1/72,pt:1,pc:6/72,px:-1},pc:{mm:25.4/6,cm:2.54/6,in:1/6,pt:72/6,pc:1,px:-1},px:{px:1}};function A(z){let U="px";if(typeof z=="string"||z instanceof String)for(let g=0,K=f.length;g<K;g++){const oe=f[g];if(z.endsWith(oe)){U=oe,z=z.substring(0,z.length-oe.length);break}}let v;return U==="px"&&t.defaultUnit!=="px"?v=_.in[t.defaultUnit]/t.defaultDPI:(v=_[U][t.defaultUnit],v<0&&(v=_[U].in*t.defaultDPI)),v*parseFloat(z)}function R(z){if(!(z.hasAttribute("transform")||z.nodeName==="use"&&(z.hasAttribute("x")||z.hasAttribute("y"))))return null;const U=C(z);return J.length>0&&U.premultiply(J[J.length-1]),ge.copy(U),J.push(U),U}function C(z){const U=new We,v=Q;if(z.nodeName==="use"&&(z.hasAttribute("x")||z.hasAttribute("y"))){const g=A(z.getAttribute("x")||0),K=A(z.getAttribute("y")||0);U.translate(g,K)}if(z.hasAttribute("transform")){const g=z.getAttribute("transform").split(")");for(let K=g.length-1;K>=0;K--){const oe=g[K].trim();if(oe==="")continue;const k=oe.indexOf("("),he=oe.length;if(k>0&&k<he){const Ae=oe.slice(0,k),de=E(oe.slice(k+1));switch(v.identity(),Ae){case"translate":if(de.length>=1){const G=de[0];let T=0;de.length>=2&&(T=de[1]),v.translate(G,T)}break;case"rotate":if(de.length>=1){let G=0,T=0,q=0;G=de[0]*Math.PI/180,de.length>=3&&(T=de[1],q=de[2]),ie.makeTranslation(-T,-q),j.makeRotation(G),H.multiplyMatrices(j,ie),ie.makeTranslation(T,q),v.multiplyMatrices(ie,H)}break;case"scale":if(de.length>=1){const G=de[0];let T=G;de.length>=2&&(T=de[1]),v.scale(G,T)}break;case"skewX":de.length===1&&v.set(1,Math.tan(de[0]*Math.PI/180),0,0,1,0,0,0,1);break;case"skewY":de.length===1&&v.set(1,0,0,Math.tan(de[0]*Math.PI/180),1,0,0,0,1);break;case"matrix":de.length===6&&v.set(de[0],de[2],de[4],de[1],de[3],de[5],0,0,1);break}}U.premultiply(v)}}return U}function L(z,U){function v(k){re.set(k.x,k.y,1).applyMatrix3(U),k.set(re.x,re.y)}function g(k){const he=k.xRadius,Ae=k.yRadius,de=Math.cos(k.aRotation),G=Math.sin(k.aRotation),T=new w(he*de,he*G,0),q=new w(-Ae*G,Ae*de,0),$=T.applyMatrix3(U),P=q.applyMatrix3(U),O=Q.set($.x,P.x,0,$.y,P.y,0,0,0,1),ae=ie.copy(O).invert(),b=j.copy(ae).transpose().multiply(ae).elements,x=N(b[0],b[1],b[4]),Y=Math.sqrt(x.rt1),se=Math.sqrt(x.rt2);if(k.xRadius=1/Y,k.yRadius=1/se,k.aRotation=Math.atan2(x.sn,x.cs),!((k.aEndAngle-k.aStartAngle)%(2*Math.PI)<Number.EPSILON)){const ne=ie.set(Y,0,0,0,se,0,0,0,1),De=j.set(x.cs,x.sn,0,-x.sn,x.cs,0,0,0,1),Te=ne.multiply(De).multiply(O),Ue=Ce=>{const{x:me,y:_e}=new w(Math.cos(Ce),Math.sin(Ce),0).applyMatrix3(Te);return Math.atan2(_e,me)};k.aStartAngle=Ue(k.aStartAngle),k.aEndAngle=Ue(k.aEndAngle),D(U)&&(k.aClockwise=!k.aClockwise)}}function K(k){const he=I(U),Ae=M(U);k.xRadius*=he,k.yRadius*=Ae;const de=he>Number.EPSILON?Math.atan2(U.elements[1],U.elements[0]):Math.atan2(-U.elements[3],U.elements[4]);k.aRotation+=de,D(U)&&(k.aStartAngle*=-1,k.aEndAngle*=-1,k.aClockwise=!k.aClockwise)}const oe=z.subPaths;for(let k=0,he=oe.length;k<he;k++){const de=oe[k].curves;for(let G=0;G<de.length;G++){const T=de[G];T.isLineCurve?(v(T.v1),v(T.v2)):T.isCubicBezierCurve?(v(T.v0),v(T.v1),v(T.v2),v(T.v3)):T.isQuadraticBezierCurve?(v(T.v0),v(T.v1),v(T.v2)):T.isEllipseCurve&&(Ee.set(T.aX,T.aY),v(Ee),T.aX=Ee.x,T.aY=Ee.y,F(U)?g(T):K(T))}}}function D(z){const U=z.elements;return U[0]*U[4]-U[1]*U[3]<0}function F(z){const U=z.elements,v=U[0]*U[3]+U[1]*U[4];if(v===0)return!1;const g=I(z),K=M(z);return Math.abs(v/(g*K))>Number.EPSILON}function I(z){const U=z.elements;return Math.sqrt(U[0]*U[0]+U[1]*U[1])}function M(z){const U=z.elements;return Math.sqrt(U[3]*U[3]+U[4]*U[4])}function N(z,U,v){let g,K,oe,k,he;const Ae=z+v,de=z-v,G=Math.sqrt(de*de+4*U*U);return Ae>0?(g=.5*(Ae+G),he=1/g,K=z*he*v-U*he*U):Ae<0?K=.5*(Ae-G):(g=.5*G,K=-.5*G),de>0?oe=de+G:oe=de-G,Math.abs(oe)>2*Math.abs(U)?(he=-2*U/oe,k=1/Math.sqrt(1+he*he),oe=he*k):Math.abs(U)===0?(oe=1,k=0):(he=-.5*oe/U,oe=1/Math.sqrt(1+he*he),k=he*oe),de>0&&(he=oe,oe=-k,k=he),{rt1:g,rt2:K,cs:oe,sn:k}}const V=[],Z={},J=[],Q=new We,ie=new We,j=new We,H=new We,Ee=new le,re=new w,ge=new We,we=new DOMParser().parseFromString(e,"image/svg+xml");return i(we.documentElement,{fill:"#000",fillOpacity:1,strokeOpacity:1,strokeWidth:1,strokeLineJoin:"miter",strokeLineCap:"butt",strokeMiterLimit:4}),{paths:V,xml:we.documentElement}}static createShapes(e){const i={ORIGIN:0,DESTINATION:1,BETWEEN:2,LEFT:3,RIGHT:4,BEHIND:5,BEYOND:6},s={loc:i.ORIGIN,t:0};function r(S,E,f,_){const A=S.x,R=E.x,C=f.x,L=_.x,D=S.y,F=E.y,I=f.y,M=_.y,N=(L-C)*(D-I)-(M-I)*(A-C),V=(R-A)*(D-I)-(F-D)*(A-C),Z=(M-I)*(R-A)-(L-C)*(F-D),J=N/Z,Q=V/Z;if(Z===0&&N!==0||J<=0||J>=1||Q<0||Q>1)return null;if(N===0&&Z===0){for(let ie=0;ie<2;ie++)if(a(ie===0?f:_,S,E),s.loc==i.ORIGIN){const j=ie===0?f:_;return{x:j.x,y:j.y,t:s.t}}else if(s.loc==i.BETWEEN){const j=+(A+s.t*(R-A)).toPrecision(10),H=+(D+s.t*(F-D)).toPrecision(10);return{x:j,y:H,t:s.t}}return null}else{for(let H=0;H<2;H++)if(a(H===0?f:_,S,E),s.loc==i.ORIGIN){const Ee=H===0?f:_;return{x:Ee.x,y:Ee.y,t:s.t}}const ie=+(A+J*(R-A)).toPrecision(10),j=+(D+J*(F-D)).toPrecision(10);return{x:ie,y:j,t:J}}}function a(S,E,f){const _=f.x-E.x,A=f.y-E.y,R=S.x-E.x,C=S.y-E.y,L=_*C-R*A;if(S.x===E.x&&S.y===E.y){s.loc=i.ORIGIN,s.t=0;return}if(S.x===f.x&&S.y===f.y){s.loc=i.DESTINATION,s.t=1;return}if(L<-Number.EPSILON){s.loc=i.LEFT;return}if(L>Number.EPSILON){s.loc=i.RIGHT;return}if(_*R<0||A*C<0){s.loc=i.BEHIND;return}if(Math.sqrt(_*_+A*A)<Math.sqrt(R*R+C*C)){s.loc=i.BEYOND;return}let D;_!==0?D=R/_:D=C/A,s.loc=i.BETWEEN,s.t=D}function l(S,E){const f=[],_=[];for(let A=1;A<S.length;A++){const R=S[A-1],C=S[A];for(let L=1;L<E.length;L++){const D=E[L-1],F=E[L],I=r(R,C,D,F);I!==null&&f.find(M=>M.t<=I.t+Number.EPSILON&&M.t>=I.t-Number.EPSILON)===void 0&&(f.push(I),_.push(new le(I.x,I.y)))}}return _}function d(S,E,f){const _=new le;E.getCenter(_);const A=[];return f.forEach(R=>{R.boundingBox.containsPoint(_)&&l(S,R.points).forEach(L=>{A.push({identifier:R.identifier,isCW:R.isCW,point:L})})}),A.sort((R,C)=>R.point.x-C.point.x),A}function u(S,E,f,_,A){(A==null||A==="")&&(A="nonzero");const R=new le;S.boundingBox.getCenter(R);const C=[new le(f,R.y),new le(_,R.y)],L=d(C,S.boundingBox,E);L.sort((V,Z)=>V.point.x-Z.point.x);const D=[],F=[];L.forEach(V=>{V.identifier===S.identifier?D.push(V):F.push(V)});const I=D[0].point.x,M=[];let N=0;for(;N<F.length&&F[N].point.x<I;)M.length>0&&M[M.length-1]===F[N].identifier?M.pop():M.push(F[N].identifier),N++;if(M.push(S.identifier),A==="evenodd"){const V=M.length%2===0,Z=M[M.length-2];return{identifier:S.identifier,isHole:V,for:Z}}else if(A==="nonzero"){let V=!0,Z=null,J=null;for(let Q=0;Q<M.length;Q++){const ie=M[Q];V?(J=E[ie].isCW,V=!1,Z=ie):J!==E[ie].isCW&&(J=E[ie].isCW,V=!0)}return{identifier:S.identifier,isHole:V,for:Z}}else console.warn('fill-rule: "'+A+'" is currently not implemented.')}let p=999999999,o=-999999999,c=e.subPaths.map(S=>{const E=S.getPoints();let f=-999999999,_=999999999,A=-999999999,R=999999999;for(let C=0;C<E.length;C++){const L=E[C];L.y>f&&(f=L.y),L.y<_&&(_=L.y),L.x>A&&(A=L.x),L.x<R&&(R=L.x)}return o<=A&&(o=A+1),p>=R&&(p=R-1),{curves:S.curves,points:E,isCW:cn.isClockWise(E),identifier:-1,boundingBox:new $d(new le(R,_),new le(A,f))}});c=c.filter(S=>S.points.length>1);for(let S=0;S<c.length;S++)c[S].identifier=S;const h=c.map(S=>u(S,c,p,o,e.userData?e.userData.style.fillRule:void 0)),m=[];return c.forEach(S=>{if(!h[S.identifier].isHole){const f=new Jn;f.curves=S.curves,h.filter(A=>A.isHole&&A.for===S.identifier).forEach(A=>{const R=c[A.identifier],C=new mi;C.curves=R.curves,f.holes.push(C)}),m.push(f)}}),m}static getStrokeStyle(e,t,i,s,r){return e=e!==void 0?e:1,t=t!==void 0?t:"#000",i=i!==void 0?i:"miter",s=s!==void 0?s:"butt",r=r!==void 0?r:4,{strokeColor:t,strokeWidth:e,strokeLineJoin:i,strokeLineCap:s,strokeMiterLimit:r}}static pointsToStroke(e,t,i,s){const r=[],a=[],l=[];if(Rr.pointsToStrokeWithBuffers(e,t,i,s,r,a,l)===0)return null;const d=new Rt;return d.setAttribute("position",new Tt(r,3)),d.setAttribute("normal",new Tt(a,3)),d.setAttribute("uv",new Tt(l,2)),d}static pointsToStrokeWithBuffers(e,t,i,s,r,a,l,d){const u=new le,p=new le,o=new le,c=new le,h=new le,m=new le,S=new le,E=new le,f=new le,_=new le,A=new le,R=new le,C=new le,L=new le,D=new le,F=new le,I=new le;i=i!==void 0?i:12,s=s!==void 0?s:.001,d=d!==void 0?d:0,e=de(e);const M=e.length;if(M<2)return 0;const N=e[0].equals(e[M-1]);let V,Z=e[0],J;const Q=t.strokeWidth/2,ie=1/(M-1);let j=0,H,Ee,re,ge,we=!1,Ve=0,z=d*3,U=d*2;v(e[0],e[1],u).multiplyScalar(Q),E.copy(e[0]).sub(u),f.copy(e[0]).add(u),_.copy(E),A.copy(f);for(let G=1;G<M;G++){V=e[G],G===M-1?N?J=e[1]:J=void 0:J=e[G+1];const T=u;if(v(Z,V,T),o.copy(T).multiplyScalar(Q),R.copy(V).sub(o),C.copy(V).add(o),H=j+ie,Ee=!1,J!==void 0){v(V,J,p),o.copy(p).multiplyScalar(Q),L.copy(V).sub(o),D.copy(V).add(o),re=!0,o.subVectors(J,Z),T.dot(o)<0&&(re=!1),G===1&&(we=re),o.subVectors(J,V),o.normalize();const q=Math.abs(T.dot(o));if(q>Number.EPSILON){const $=Q/q;o.multiplyScalar(-$),c.subVectors(V,Z),h.copy(c).setLength($).add(o),F.copy(h).negate();const P=h.length(),O=c.length();c.divideScalar(O),m.subVectors(J,V);const ae=m.length();switch(m.divideScalar(ae),c.dot(F)<O&&m.dot(F)<ae&&(Ee=!0),I.copy(h).add(V),F.add(V),ge=!1,Ee?re?(D.copy(F),C.copy(F)):(L.copy(F),R.copy(F)):oe(),t.strokeLineJoin){case"bevel":k(re,Ee,H);break;case"round":he(re,Ee),re?K(V,R,L,H,0):K(V,D,C,H,1);break;case"miter":case"miter-clip":default:const ue=Q*t.strokeMiterLimit/P;if(ue<1)if(t.strokeLineJoin!=="miter-clip"){k(re,Ee,H);break}else he(re,Ee),re?(m.subVectors(I,R).multiplyScalar(ue).add(R),S.subVectors(I,L).multiplyScalar(ue).add(L),g(R,H,0),g(m,H,0),g(V,H,.5),g(V,H,.5),g(m,H,0),g(S,H,0),g(V,H,.5),g(S,H,0),g(L,H,0)):(m.subVectors(I,C).multiplyScalar(ue).add(C),S.subVectors(I,D).multiplyScalar(ue).add(D),g(C,H,1),g(m,H,1),g(V,H,.5),g(V,H,.5),g(m,H,1),g(S,H,1),g(V,H,.5),g(S,H,1),g(D,H,1));else Ee?(re?(g(f,j,1),g(E,j,0),g(I,H,0),g(f,j,1),g(I,H,0),g(F,H,1)):(g(f,j,1),g(E,j,0),g(I,H,1),g(E,j,0),g(F,H,0),g(I,H,1)),re?L.copy(I):D.copy(I)):re?(g(R,H,0),g(I,H,0),g(V,H,.5),g(V,H,.5),g(I,H,0),g(L,H,0)):(g(C,H,1),g(I,H,1),g(V,H,.5),g(V,H,.5),g(I,H,1),g(D,H,1)),ge=!0;break}}else oe()}else oe();!N&&G===M-1&&Ae(e[0],_,A,re,!0,j),j=H,Z=V,E.copy(L),f.copy(D)}if(!N)Ae(V,R,C,re,!1,H);else if(Ee&&r){let G=I,T=F;we!==re&&(G=F,T=I),re?(ge||we)&&(T.toArray(r,0),T.toArray(r,9),ge&&G.toArray(r,3)):(ge||!we)&&(T.toArray(r,3),T.toArray(r,9),ge&&G.toArray(r,0))}return Ve;function v(G,T,q){return q.subVectors(T,G),q.set(-q.y,q.x).normalize()}function g(G,T,q){r&&(r[z]=G.x,r[z+1]=G.y,r[z+2]=0,a&&(a[z]=0,a[z+1]=0,a[z+2]=1),z+=3,l&&(l[U]=T,l[U+1]=q,U+=2)),Ve+=3}function K(G,T,q,$,P){u.copy(T).sub(G).normalize(),p.copy(q).sub(G).normalize();let O=Math.PI;const ae=u.dot(p);Math.abs(ae)<1&&(O=Math.abs(Math.acos(ae))),O/=i,o.copy(T);for(let ue=0,Re=i-1;ue<Re;ue++)c.copy(o).rotateAround(G,O),g(o,$,P),g(c,$,P),g(G,$,.5),o.copy(c);g(c,$,P),g(q,$,P),g(G,$,.5)}function oe(){g(f,j,1),g(E,j,0),g(R,H,0),g(f,j,1),g(R,H,0),g(C,H,1)}function k(G,T,q){T?G?(g(f,j,1),g(E,j,0),g(R,H,0),g(f,j,1),g(R,H,0),g(F,H,1),g(R,q,0),g(L,q,0),g(F,q,.5)):(g(f,j,1),g(E,j,0),g(C,H,1),g(E,j,0),g(F,H,0),g(C,H,1),g(C,q,1),g(F,q,0),g(D,q,1)):G?(g(R,q,0),g(L,q,0),g(V,q,.5)):(g(C,q,1),g(D,q,0),g(V,q,.5))}function he(G,T){T&&(G?(g(f,j,1),g(E,j,0),g(R,H,0),g(f,j,1),g(R,H,0),g(F,H,1),g(R,j,0),g(V,H,.5),g(F,H,1),g(V,H,.5),g(L,j,0),g(F,H,1)):(g(f,j,1),g(E,j,0),g(C,H,1),g(E,j,0),g(F,H,0),g(C,H,1),g(C,j,1),g(F,H,0),g(V,H,.5),g(V,H,.5),g(F,H,0),g(D,j,1)))}function Ae(G,T,q,$,P,O){switch(t.strokeLineCap){case"round":P?K(G,q,T,O,.5):K(G,T,q,O,.5);break;case"square":if(P)u.subVectors(T,G),p.set(u.y,-u.x),o.addVectors(u,p).add(G),c.subVectors(p,u).add(G),$?(o.toArray(r,3),c.toArray(r,0),c.toArray(r,9)):(o.toArray(r,3),l[7]===1?c.toArray(r,9):o.toArray(r,9),c.toArray(r,0));else{u.subVectors(q,G),p.set(u.y,-u.x),o.addVectors(u,p).add(G),c.subVectors(p,u).add(G);const ae=r.length;$?(o.toArray(r,ae-3),c.toArray(r,ae-6),c.toArray(r,ae-12)):(c.toArray(r,ae-6),o.toArray(r,ae-3),c.toArray(r,ae-12))}break}}function de(G){let T=!1;for(let $=1,P=G.length-1;$<P;$++)if(G[$].distanceTo(G[$+1])<s){T=!0;break}if(!T)return G;const q=[];q.push(G[0]);for(let $=1,P=G.length-1;$<P;$++)G[$].distanceTo(G[$+1])>=s&&q.push(G[$]);return q.push(G[G.length-1]),q}}}function $i(n,e=!1){const t=n[0].index!==null,i=new Set(Object.keys(n[0].attributes)),s=new Set(Object.keys(n[0].morphAttributes)),r={},a={},l=n[0].morphTargetsRelative,d=new Rt;let u=0;for(let p=0;p<n.length;++p){const o=n[p];let c=0;if(t!==(o.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const h in o.attributes){if(!i.has(h))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+'. All geometries must have compatible attributes; make sure "'+h+'" attribute exists among all geometries, or in none of them.'),null;r[h]===void 0&&(r[h]=[]),r[h].push(o.attributes[h]),c++}if(c!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". Make sure all geometries have the same number of attributes."),null;if(l!==o.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const h in o.morphAttributes){if(!s.has(h))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+".  .morphAttributes must be consistent throughout all geometries."),null;a[h]===void 0&&(a[h]=[]),a[h].push(o.morphAttributes[h])}if(e){let h;if(t)h=o.index.count;else if(o.attributes.position!==void 0)h=o.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+p+". The geometry must have either an index or a position attribute"),null;d.addGroup(u,h,p),u+=h}}if(t){let p=0;const o=[];for(let c=0;c<n.length;++c){const h=n[c].index;for(let m=0;m<h.count;++m)o.push(h.getX(m)+p);p+=n[c].attributes.position.count}d.setIndex(o)}for(const p in r){const o=Sc(r[p]);if(!o)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" attribute."),null;d.setAttribute(p,o)}for(const p in a){const o=a[p][0].length;if(o===0)break;d.morphAttributes=d.morphAttributes||{},d.morphAttributes[p]=[];for(let c=0;c<o;++c){const h=[];for(let S=0;S<a[p].length;++S)h.push(a[p][S][c]);const m=Sc(h);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+p+" morphAttribute."),null;d.morphAttributes[p].push(m)}}return d}function Sc(n){let e,t,i,s=-1,r=0;for(let u=0;u<n.length;++u){const p=n[u];if(e===void 0&&(e=p.array.constructor),e!==p.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=p.itemSize),t!==p.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=p.normalized),i!==p.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=p.gpuType),s!==p.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=p.count*t}const a=new e(r),l=new un(a,t,i);let d=0;for(let u=0;u<n.length;++u){const p=n[u];if(p.isInterleavedBufferAttribute){const o=d/t;for(let c=0,h=p.count;c<h;c++)for(let m=0;m<t;m++){const S=p.getComponent(c,m);l.setComponent(c+o,m,S)}}else a.set(p.array,d);d+=p.count*t}return s!==void 0&&(l.gpuType=s),l}const Ru={A:{horizAdvX:1325,d:"M1108 0l-162 435h-573l-160 -435h-213l558 1468h210l555 -1468h-215zM889 613l-154 431q-7 22 -21.5 66t-29 91t-23.5 78q-10 -41 -23 -86.5t-25.5 -85t-20.5 -63.5l-156 -431h453z"},B:{horizAdvX:1336,d:"M196 1462h424q279 0 420 -82t141 -281q0 -85 -31 -152t-90 -111t-145 -60v-10q90 -15 160 -54t110.5 -110.5t40.5 -183.5q0 -134 -63 -227.5t-178.5 -142t-274.5 -48.5h-514v1462zM401 847h255q177 0 245 58t68 169q0 115 -81 165.5t-257 50.5h-230v-443zM401 678v-505 h279q181 0 255.5 71t74.5 191q0 76 -33.5 130.5t-108.5 83.5t-202 29h-265z"},C:{horizAdvX:1294,d:"M820 1306q-113 0 -202.5 -39.5t-151.5 -115t-95 -181.5t-33 -239q0 -177 52.5 -306t158.5 -199t267 -70q96 0 183.5 17.5t174.5 45.5v-176q-84 -32 -173.5 -47.5t-209.5 -15.5q-224 0 -372.5 93t-221.5 261.5t-73 397.5q0 166 46 303.5t135 238t218.5 155t298.5 54.5 q110 0 214.5 -23.5t192.5 -65.5l-76 -171q-73 33 -156.5 58t-176.5 25z"},D:{horizAdvX:1494,d:"M1370 745q0 -247 -91 -412.5t-263.5 -249t-418.5 -83.5h-401v1462h446q224 0 387 -81.5t252 -241t89 -394.5zM1155 739q0 188 -61 310t-179 181.5t-289 59.5h-225v-1116h189q283 0 424 142t141 423z"},E:{horizAdvX:1140,d:"M1017 0h-821v1462h821v-176h-616v-435h579v-174h-579v-500h616v-177z"},F:{horizAdvX:1074,d:"M400 0h-204v1462h820v-176h-616v-496h578v-175h-578v-615z"},G:{horizAdvX:1488,d:"M804 780h528v-721q-115 -39 -237 -59t-274 -20q-226 0 -381 90t-235.5 258t-80.5 404q0 227 89 396t259 262t410 93q120 0 230.5 -23t203.5 -64l-74 -173q-78 35 -172.5 59.5t-195.5 24.5q-168 0 -288.5 -71t-185 -200t-64.5 -306q0 -173 54 -302t169 -201t296 -72 q91 0 155.5 10t118.5 24v412h-325v179z"},H:{horizAdvX:1524,d:"M1327 0h-205v675h-721v-675h-205v1462h205v-610h721v610h205v-1462z"},I:{horizAdvX:599,d:"M196 0v1462h205v-1462h-205z"},J:{horizAdvX:582,d:"M0 -396q-53 0 -93 7t-68 18v173q32 -9 69 -15t79 -6q56 0 102 22t73 76t27 150v1433h206v-1423q0 -149 -48.5 -245.5t-137.5 -143t-209 -46.5z"},K:{horizAdvX:1281,d:"M1281 0h-239l-491 687l-150 -128v-559h-205v1462h205v-714q51 60 103.5 119t104.5 119l419 476h235l-564 -637z"},L:{horizAdvX:1091,d:"M196 0v1462h205v-1284h635v-178h-840z"},M:{horizAdvX:1864,d:"M833 0l-456 1257h-8q3 -41 6.5 -105.5t6 -140t2.5 -148.5v-863h-188v1462h295l433 -1191h7l444 1191h293v-1462h-198v875q0 66 2 137.5t5.5 136t6.5 106.5h-9l-467 -1255h-175z"},N:{horizAdvX:1573,d:"M1378 0h-246l-757 1198h-8q3 -54 7 -118.5t6.5 -135t3.5 -142.5v-802h-188v1462h244l754 -1192h7q-2 44 -5 109t-5.5 137.5t-2.5 137.5v808h190v-1462z"},O:{horizAdvX:1602,d:"M1479 733q0 -169 -43 -307.5t-127.5 -238t-211 -153.5t-295.5 -54q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5t152 -200t261.5 -70.5q161 0 263 70.5 t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},P:{horizAdvX:1246,d:"M599 1462q283 0 413.5 -113t130.5 -321q0 -94 -30 -178.5t-97.5 -149t-177.5 -102t-270 -37.5h-167v-561h-205v1462h403zM583 1290h-182v-556h145q127 0 213 28.5t130 91.5t44 166q0 136 -85 203t-265 67z"},Q:{horizAdvX:1602,d:"M1479 733q0 -176 -46.5 -319t-139 -243.5t-230.5 -149.5l346 -369h-282l-279 330q-12 0 -23 -1t-23 -1q-172 0 -299.5 54t-211.5 154t-125.5 239t-41.5 308q0 225 74 394t225.5 262.5t381.5 93.5q222 0 372 -93t226 -261.5t76 -397.5zM339 733q0 -178 49.5 -307.5 t152 -200t261.5 -70.5q161 0 263 70.5t150 200t48 307.5q0 270 -110 422.5t-348 152.5q-160 0 -263 -69.5t-153 -198t-50 -307.5z"},R:{horizAdvX:1286,d:"M599 1462q185 0 305.5 -45.5t179.5 -138t59 -234.5q0 -112 -41 -189t-107.5 -126t-142.5 -77l409 -652h-235l-356 598h-269v-598h-205v1462h403zM586 1288h-185v-519h199q173 0 253 67.5t80 199.5q0 137 -85 194.5t-262 57.5z"},S:{horizAdvX:1124,d:"M1031 393q0 -130 -64.5 -222.5t-181.5 -141.5t-278 -49q-81 0 -154.5 8.5t-136.5 24.5t-114 40v194q83 -34 192 -63.5t225 -29.5q101 0 169.5 27.5t103.5 77.5t35 120t-34 117.5t-107.5 87.5t-192.5 85q-83 30 -151 68.5t-117.5 88.5t-76.5 117.5t-27 155.5 q0 121 59.5 207t166.5 131.5t248 45.5q116 0 216.5 -23t191.5 -63l-65 -170q-85 35 -171 57t-178 22q-85 0 -143.5 -25t-89 -71t-30.5 -109q0 -71 32 -118t101 -85t180 -81q125 -48 212.5 -102t133.5 -130t46 -192z"},T:{horizAdvX:1143,d:"M674 0h-206v1285h-444v177h1093v-177h-443v-1285z"},U:{horizAdvX:1507,d:"M1323 1462v-946q0 -154 -63.5 -275t-191.5 -191t-322 -70q-275 0 -419.5 147.5t-144.5 392.5v942h206v-934q0 -185 92.5 -279t275.5 -94q126 0 206 45.5t118.5 129t38.5 198.5v934h204z"},V:{horizAdvX:1249,d:"M1249 1462l-518 -1462h-213l-518 1462h212l325 -940q18 -49 34 -103.5t30 -108.5t23 -99q9 45 22.5 99t30.5 109.5t34 105.5l324 937h214z"},W:{horizAdvX:1913,d:"M1891 1462l-386 -1462h-217l-267 930q-11 37 -22 80t-21.5 85.5t-17.5 76.5t-10 52q-2 -18 -8.5 -51.5t-15.5 -75.5t-20 -85.5t-22 -82.5l-261 -929h-216l-384 1462h209l223 -887q11 -44 21.5 -89.5t19.5 -91t16 -88t13 -80.5q5 39 13 83.5t17.5 90.5t20.5 91t23 86 l250 885h205l259 -890q12 -42 23.5 -88t21 -92t17 -88t13.5 -78q7 50 17.5 108t24.5 120t28 122l223 886h210z"},X:{horizAdvX:1229,d:"M1224 0h-234l-381 621l-386 -621h-218l486 760l-453 702h227l353 -569l352 569h219l-454 -704z"},Y:{horizAdvX:1178,d:"M590 762l368 700h220l-486 -894v-568h-205v559l-487 903h224z"},Z:{horizAdvX:1176,d:"M1104 0h-1033v146l765 1138h-740v178h988v-146l-766 -1138h786v-178z"},GREATER:{horizAdvX:1171,d:"M99 403l759 319l-759 357v171l970 -481v-107l-970 -429v170z"}},Mr=3e3,Er=new Map;_n("letter-geometries",aA);async function aA(){Er.clear(),Er.set(" ",{side:new Rt,back:new Rt});for(const[n,e]of Object.entries(Ru)){const t=lA(cA(e.d,e.horizAdvX));Er.set(n,t)}}function xa(n){const e=n.toUpperCase(),t=Er.get(e);if(!t)throw new Error(`Tile symbol geometry not preloaded for letter: ${e}`);return t}function lA(n){const t=new Rr().parse(n),i=[],s=[],r=new Jn;r.moveTo(0,0),r.lineTo(24,0),r.lineTo(24,24),r.lineTo(0,24),r.closePath(),t.paths.forEach(m=>{Rr.createShapes(m).forEach(E=>{const f=new Fa(E,{depth:.1*Mr,bevelEnabled:!1}),{side:_,back:A}=uA(f);i.push(_),s.push(A),r.holes.push(new mi(E.getPoints(12))),E.holes.forEach(R=>{const C=new Jn(R.getPoints(12));new Ba(C).translate(0,0,2)})})});const a=Ac(i,"side"),l=Ac(s,"back"),d=En/Mr;a.scale(d,-d,d),l.scale(d,-d,d),a.rotateX(Math.PI/2),l.rotateX(Math.PI/2),a.computeBoundingBox();const u=a.boundingBox;if(!u)throw new Error("Failed to compute symbol bounds");const p=new w;u.getCenter(p);const o=-En/2-p.x,c=-u.max.y,h=-En/2-p.z;return a.translate(o,c,h),l.translate(o,c,h),{side:a,back:l}}function cA(n,e){return`
    <svg width="800px" height="800px" viewBox="0 0 ${Mr} ${Mr}" 
    version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <title>font_fill</title>
        <g fill-rule="evenodd">
            <path d="${n}">
          /path>
        </g>
    </svg>
  `}function uA(n){const t=n.toNonIndexed().getAttribute("position"),i=[],s=[],r=new w,a=new w,l=new w,d=new w,u=new w,p=new w;let o=-1/0;for(let m=0;m<t.count;m+=1)o=Math.max(o,t.getZ(m));for(let m=0;m<t.count;m+=3){if(r.fromBufferAttribute(t,m),a.fromBufferAttribute(t,m+1),l.fromBufferAttribute(t,m+2),d.subVectors(a,r),u.subVectors(l,r),p.crossVectors(d,u).normalize(),!(Math.abs(p.z)>.9)){i.push(r.x,r.y,r.z,a.x,a.y,a.z,l.x,l.y,l.z);continue}const E=(r.z+a.z+l.z)/3;Math.abs(E-o)<=.001&&s.push(r.x,r.y,r.z,a.x,a.y,a.z,l.x,l.y,l.z)}const c=new Rt;c.setAttribute("position",new Tt(i,3)),c.computeVertexNormals();const h=new Rt;return h.setAttribute("position",new Tt(s,3)),h.computeVertexNormals(),{side:c,back:h}}function Ac(n,e){const t=$i(n);if(!t)throw new Error(`Failed to merge ${e} SVG geometries`);return t}const hA=100;function _c(n,e=hA){return Math.max(1,Math.ceil(n/e))}function Lt(n,e,t,i,s,r=0,a=0,l=0,d=!1){const u=_c(n),p=_c(e),o=new ei(n*(d?1:-1),e,u,p);return o.rotateX(r),o.rotateY(a),o.rotateZ(l),o.translate(t,i,s),o}const Mu=["RESET","UNDO","SKIP"],ga=new Map,dA=3e3,fA={RESET:.02,UNDO:.02,SKIP:.02};_n("word-geometries",pA);async function pA(){ga.clear();for(const n of Mu){const e=mA(n);ga.set(n,e)}}function EA(n){const e=n.toUpperCase(),t=ga.get(e);if(!t)throw new Error(`geometry not preloaded for UI word: ${e}`);return t}function mA(n){const e=[],t=[],i=[...n],s=i.map(u=>SA(u)),r=En*fA[n],a=s.reduce((u,p)=>u+p,0),l=r*Math.max(0,i.length-1);let d=-(a+l)/2;for(let u=0;u<i.length;u+=1){const p=xa(i[u]);if(!p)throw new Error(`Tile symbol geometry missing for letter: ${i[u]}`);const o=d+s[u]/2,c=p.side.clone();c.translate(o,0,0),e.push(c);const h=p.back.clone();h.translate(o,0,0),t.push(h),d+=s[u]+r}return{side:xc(e,`word side (${n})`),back:xc(t,`word back (${n})`)}}function SA(n){const e=Ru[n];if(!e)throw new Error(`Missing glyph metrics for letter: ${n}`);return e.horizAdvX/dA*En}function xc(n,e){const t=$i(n);if(!t)throw new Error(`Failed to merge ${e} geometries`);return t}const AA=$n({color:s0,side:Ot}),_A=$n({color:Eu}),st=En,Qt=ZS,vu=$i([Lt(st,st,st*.5,Qt,st*.5,-Math.PI/2,0,0)],!1);vu.translate(-st/2,0,-st/2);const Iu=$i([Lt(st,Qt,st*.5,Qt*.5,0,0,0,0),Lt(st,Qt,st*.5,Qt*.5,st,0,Math.PI,0),Lt(st,Qt,0,Qt*.5,st*.5,0,Math.PI/2,0),Lt(st,Qt,st,Qt*.5,st*.5,0,-Math.PI/2,0),Lt(st,st,st*.5,0,st*.5,Math.PI/2,0,0)],!1);Iu.translate(-st/2,0,-st/2);const To=.08,yu=new gi(st+To*2,Qt+To*2,st+To*2);yu.translate(0,Qt/2,0);const xs=class xs{constructor(e,t=1){ce(this,"uiAction",null);ce(this,"group");ce(this,"pickableMesh");ce(this,"_topMesh");ce(this,"_sideMesh");ce(this,"_symbolSideMesh");ce(this,"_symbolBackMesh");ce(this,"_symbolGroup");ce(this,"slotPos");ce(this,"slotQuat");ce(this,"glowDelay",0);ce(this,"targetGlowing",!1);ce(this,"isGlowing",!1);ce(this,"savedBackColor",null);ce(this,"savedSideColor",null);ce(this,"_isVisible",!1);ce(this,"animOffset",0);this.glyph=e,this.width=t;const i=$n({color:Ao,depthTest:!1,depthWrite:!1,side:mn}),s=$n({color:_o,depthTest:!1,depthWrite:!1,side:mn}),r=new At(vu,AA),a=new At(Iu,_A),l=Mu.includes(e)?EA(e):xa(e),d=new At(l.side,i),u=new At(l.back,s),p=new jt;p.add(u,d),p.position.set(st/2,Qt+1e-4,st/2),this._symbolGroup=p;const o=new jn({color:16777215,depthTest:!1,depthWrite:!1,visible:!1}),c=new At(yu,o);c.userData.glyph=e,r.scale.x=t,a.scale.x=t,c.scale.x=t;const h=new jt;h.add(r,a,p,c),h.position.set(-st/2,0,-st/2);const m=!1;for(const S of[r,a,p])S.visible=m;this.group=h,this._symbolSideMesh=d,this._symbolBackMesh=u,this._topMesh=r,this._sideMesh=a,this.pickableMesh=c,this.pickableMesh.userData["scrabble-tile"]=this,this.updateRenderOrder()}updateRenderOrder(e=0){this.pickableMesh.renderOrder=7,this._sideMesh.renderOrder=8+e,this._topMesh.renderOrder=9+e,this._symbolSideMesh.renderOrder=11+e,this._symbolBackMesh.renderOrder=12+e}updateGlow(e){if(this.glowDelay>0){this.glowDelay-=e;return}this.isGlowing=this.targetGlowing;const t=.02*e;this._symbolBackMesh.material.color.lerp(this.isGlowing?dc:_o,t),this._symbolSideMesh.material.color.lerp(this.isGlowing?hc:Ao,t)}saveGlow(){this.savedBackColor=this._symbolBackMesh.material.color,this.savedSideColor=this._symbolSideMesh.material.color,this._symbolBackMesh.material.color=this.targetGlowing?dc:_o,this._symbolSideMesh.material.color=this.targetGlowing?hc:Ao}restoreGlow(){this._symbolBackMesh.material.color=this.savedBackColor,this._symbolSideMesh.material.color=this.savedSideColor}randomizeLetter(){const e=xs._LETTERS[Math.floor(Math.random()*xs._LETTERS.length)];this.setLetter(e)}setLetter(e){this.glyph=e,this.pickableMesh.userData.glyph=e;const t=xa(e);t&&(this._symbolSideMesh.geometry=t.side,this._symbolBackMesh.geometry=t.back)}get isVisible(){return this._isVisible}set isVisible(e){this._isVisible=e,this.glyph===" "&&(e=!1);for(const t of this.group.children)t.visible=e;this.pickableMesh.visible=!0}set isHovered(e){this.pickableMesh.material.visible=e}toggle(){this._isVisible?this.hide():this.show()}hide(){this.isVisible=!1}show(){this.isVisible=!0}set anim(e){e+=this.animOffset;const t=-.3;e=t+e*(1-2*t),e=Math.max(0,Math.min(1,e));const i=(1-e)*30,s=-(1-e)*30;this.group.position.y=this.slotPos.y+i,this.group.position.z=this.slotPos.z+s}};ce(xs,"_LETTERS","ABCDEFGHIJKLMNOPQRSTUVWXYZ");let As=xs;const ar=Math.PI*2;function Wt(n){const e=Math.sin(n*127.1+311.7)*43758.5453123;return e-Math.floor(e)}function gc(n,e,t){return Math.max(e,Math.min(t,n))}const ki=class ki{constructor(){ce(this,"_seeds",[]);ce(this,"_timeMs",0);ce(this,"_blend",1)}update(e,t,i){if(this._ensureMaskSeeds(i),this._timeMs+=e,t){this._blend=Math.min(1,this._blend+e/ki._BLEND_IN_DURATION);return}this._blend=Math.max(0,this._blend-e/ki._BLEND_OUT_DURATION)}getBlend(){return 0}getMaskPose(e,t,i,s,r){const a=this._seeds[e];if(!a||t<=0||i<=0)return{x:0,y:0,angle:0};const l=this._timeMs*1e-4,d=a.anchorXNorm*t+Math.sin(l*a.freqX+a.phaseX)*a.ampXNorm*t+Math.sin(l*a.driftFreq+a.driftPhase)*.03*t,u=a.anchorYNorm*i+Math.cos(l*a.freqY+a.phaseY)*a.ampYNorm*i+Math.cos(l*(a.driftFreq*.73)+a.driftPhase)*.025*i,p=s*.5,o=r*.5,c=8,h=gc(d,p+c,t-p-c),m=gc(u,o+c,i-o-c),S=Math.sin(l*a.spinFreq+a.spinPhase)*a.spinAmpRad;return{x:h-p,y:m-o,angle:S}}_ensureMaskSeeds(e){for(let t=this._seeds.length;t<e;t+=1)this._seeds.push(this._buildSeed(t))}_buildSeed(e){const t=(e+1)*17*Math.random();return{anchorXNorm:.2+Wt(t+1)*.6,anchorYNorm:.2+Wt(t+2)*.6,ampXNorm:.05+Wt(t+3)*.1,ampYNorm:.04+Wt(t+4)*.09,freqX:.45+Wt(t+5)*.95,freqY:.4+Wt(t+6)*.85,phaseX:Wt(t+7)*ar,phaseY:Wt(t+8)*ar,driftFreq:.15+Wt(t+9)*.35,driftPhase:Wt(t+10)*ar,spinFreq:.55+Wt(t+11)*.8,spinPhase:Wt(t+12)*ar,spinAmpRad:.18+Wt(t+13)*.36}}};ce(ki,"_BLEND_IN_DURATION",350),ce(ki,"_BLEND_OUT_DURATION",2e3);let Ta=ki;class xA{}class gA extends xA{update(e,t){let s=0;for(const r of e._scrabbleTiles){let a=t;a-=.43,a/=1-2*.43;const l=s-_i,d=Math.floor(l/5),u=l%5;a+=(4-d-u)*.3,a=Math.max(0,Math.min(1,a)),a=1-Math.cos(a*Math.PI*2),r.group.position.y=r.slotPos.y+a*.2,s++}}}class TA{get totalWidth(){return this.nCols*rn+yt}get totalHeight(){return this.nRows*rn+yt}}class RA extends TA{constructor(){super();ce(this,"nRows",5);ce(this,"nCols",5)}buildEmptyBoard(){return vA(this)}getSlotPos(t,i){return MA(t,i)}getSlotQuat(t,i){return new Sn}}const di=6,Lu=(di-1)*(di-1),Ou=Lu+2+3,fi=[],bs=[];function MA(n,e){const t=e*rn+yt+mt/2,i=n*rn+yt+mt/2;return new w(t,Gi,i)}function vA(n,e){const t=[],i=[],s=n.nCols,r=n.nRows,a=n.totalWidth,l=n.totalHeight,d=-a/2,u=-l/2-1;for(let _=0;_<=r;_++)for(let A=0;A<=s;A++)fi.push(new w(d+yt/2+A*(mt+yt),ht,u+yt/2+_*(mt+yt)));for(let _=0;_<Lu;_++){const A=Math.floor(_/(di-1)),R=_%(di-1),C=A*di+R,L=[fi[C],fi[C+1],fi[C+di+1],fi[C+di]];bs.push(L)}IA(),yA();for(let _=0;_<=r;_++){const A=_*rn;t.push(Lt(a,yt,a/2,ht,A+yt/2,-Math.PI/2))}for(let _=0;_<=s;_++){const A=_*rn;for(let R=0;R<r;R++){const C=R*rn+yt;t.push(Lt(yt,mt,A+yt/2,ht,C+mt/2,-Math.PI/2))}}for(let _=0;_<r;_++)for(let A=0;A<s;A++){const R=A*rn+yt,C=_*rn+yt;t.push(Lt(mt,mt,R+mt/2,Gi,C+mt/2,-Math.PI/2))}i.push(Lt(-a,ht,a/2,ht/2,0)),i.push(Lt(-a,ht,a/2,ht/2,l,0,Math.PI,0)),i.push(Lt(-a,ht,0,ht/2,l/2,0,Math.PI/2,0)),i.push(Lt(-a,ht,a,ht/2,l/2,0,-Math.PI/2,0));for(let _=0;_<r;_++)for(let A=0;A<s;A++){const R=A*rn+yt,C=_*rn+yt,L=R+mt,D=C+mt;i.push(Lt(mt,Ln,R+mt/2,Gi+Ln/2,C)),i.push(Lt(mt,Ln,R+mt/2,Gi+Ln/2,D,0,Math.PI,0)),i.push(Lt(mt,Ln,R,Gi+Ln/2,C+mt/2,0,Math.PI/2,0)),i.push(Lt(mt,Ln,L,Gi+Ln/2,C+mt/2,0,-Math.PI/2,0))}const p=$i(t,!1),o=$i(i,!1),c=$n({color:Cs,side:Ot}),h=$n({color:0,side:Ot}),m=new At(p,c),S=new At(o,h),E=new jt;E.add(m,S);const f=0;return E.position.set(d+f,0,u+f),E}function IA(){const n=[2.5,3.2,4.5],e=fi[0].x,t=fi.at(-1).x,i=[new w(e,ht,n[0]),new w(t,ht,n[0]),new w(t,ht,n[1]),new w(e,ht,n[1])];bs.push(i);const s=[new w(e,ht,n[1]),new w(t,ht,n[1]),new w(t,ht,n[2]),new w(e,ht,n[2])];bs.push(s)}function yA(){const n=[-7,-4.5],e=[-5,-2,2,5];for(let t=0;t<3;t++)bs.push([new w(e[t],ht,n[0]),new w(e[t+1],ht,n[0]),new w(e[t+1],ht,n[1]),new w(e[t],ht,n[1])])}new w;new w;new w;const _s={entrance:new WeakMap,exit:new WeakMap},LA={entrance:new WeakMap,exit:new WeakMap};function Pr(n){return n?"exit":"entrance"}function Nr(n,e){const t=LA[e];let i=t.get(n);return i||(i=[],t.set(n,i)),i}function OA(n,e){const t=window.innerWidth,i=window.innerHeight;return{app:n,kind:e,w:t,h:i,phase:"render",pixels:new Uint8Array(t*i*4),flipped:new Uint8ClampedArray(t*i*4),flipY:0,quadIndex:0,coveredNonBg:new Uint8Array(t*i)}}function bA(n,e,t){return n===204&&e===204&&t===204}function CA(n){return n.phase==="render"?1:n.phase==="flip"?20*Math.min(1,n.flipY/Math.max(1,n.h)):n.phase==="build-quads"?20+80*Math.min(1,n.quadIndex/Ou):100}function DA(n){const{app:e,w:t,h:i}=n,s=new wn(t,i);if(s.texture.colorSpace=Nt,e._renderer.setRenderTarget(s),n.kind==="entrance"){for(const r of e._allTiles)r.hide();e._renderer.render(e._scene,e._nextCamera);for(const r of e._allTiles)r.show()}else{for(const r of e._allTiles)r.saveGlow();e._renderer.render(e._scene,e._camera);for(const r of e._allTiles)r.restoreGlow()}e._renderer.setRenderTarget(null),e._renderer.readRenderTargetPixels(s,0,0,t,i,n.pixels),s.dispose(),n.phase="flip"}function PA(n,e){const{w:t,h:i}=n;for(;n.flipY<i;n.flipY++){const a=(i-1-n.flipY)*t*4,l=n.flipY*t*4;if(n.flipped.set(n.pixels.subarray(a,a+t*4),l),(n.flipY&31)===0&&performance.now()>=e)return!1}const s=document.getElementById("buffer-canvas");s.width=t,s.height=i;const r=Uint8ClampedArray.from(n.flipped);return s.getContext("2d").putImageData(new ImageData(r,t,i),0,0),n.phase="build-quads",n.quadIndex=0,!0}function NA(n,e,t,i){const s=n.clone().project(e);return new le((s.x+1)/2*t,(1-s.y)/2*i)}function Tc(n,e,t,i,s){const r=s.x-t.x,a=s.y-t.y,l=i.x-t.x,d=i.y-t.y,u=n-t.x,p=e-t.y,o=r*r+a*a,c=r*l+a*d,h=r*u+a*p,m=l*l+d*d,S=l*u+d*p,E=o*m-c*c;if(E===0)return!1;const f=1/E,_=(m*h-c*S)*f,A=(o*S-c*h)*f;return _>=0&&A>=0&&_+A<=1}function UA(n,e,t){return Tc(n,e,t[0],t[1],t[2])||Tc(n,e,t[0],t[2],t[3])}function wA(n,e){const{app:t,w:i,h:s,flipped:r}=n,a=1.5*Math.hypot(i/2,s/2),l=n.kind,d=Nr(t,l),u=l==="entrance"?t._nextCamera:t._camera,p=bs[e];if(p.some(re=>!re))return null;const o=p.map(re=>NA(re,u,i,s)),c=Math.max(0,Math.floor(Math.min(...o.map(re=>re.x)))),h=Math.max(0,Math.floor(Math.min(...o.map(re=>re.y)))),m=Math.min(i-1,Math.ceil(Math.max(...o.map(re=>re.x)))),S=Math.min(s-1,Math.ceil(Math.max(...o.map(re=>re.y))));if(m<c||S<h)return null;const E=m-c+1,f=S-h+1,_=new OffscreenCanvas(E,f),A=_.getContext("2d"),R=A.createImageData(E,f),C=R.data;for(let re=h;re<=S;re++)for(let ge=c;ge<=m;ge++){if(!UA(ge+.5,re+.5,o))continue;const we=((re-h)*E+(ge-c))*4,Ve=(re*i+ge)*4,z=r[Ve],U=r[Ve+1],v=r[Ve+2],g=r[Ve+3];C[we]=z,C[we+1]=U,C[we+2]=v,C[we+3]=g,bA(z,U,v)?C[we+3]=0:n.coveredNonBg[re*i+ge]=1}A.putImageData(R,0,0);const L=new w;for(const re of p)L.add(re);L.divideScalar(p.length);const D=(c+m)/2,F=(h+S)/2,I=new Ga,M=new le,N=Math.floor(D),V=Math.floor(F);M.set(N/i*2-1,-(V/s)*2+1),I.setFromCamera(M,u);const Z=[],J=Z.length>0?Z[0].point.clone():L;let Q=0,ie=0,j=0,H=0;if(J){const re=J.clone().project(u),ge=(re.x+1)/2*i,we=(1-re.y)/2*s;Q=c-(ge-_.width/2),ie=h-(we-_.height/2);const Ve=D-i/2,z=F-s/2;let U=2*Math.hypot(Ve,z)+Math.random()*100;U=Math.max(U,a);const v=Math.atan2(z,Ve),g=v+Math.PI/2,K=1e3;j=U*Math.cos(v)+K*Math.cos(g),H=U*Math.sin(v)+K*Math.sin(g)}const Ee={filterColor:"#ffffff",canvas:_,x:c,y:h,worldPos:J,restOffsetX:Q,restOffsetY:ie,animOffsetX:j,animOffsetY:H,restAngle:-Math.PI+2*Math.random()*Math.PI};return d.push(Ee),Ee}function FA(n,e){for(;n.quadIndex<Ou;n.quadIndex++){if(performance.now()>=e)return!1;wA(n,n.quadIndex)}return n.phase="done",!0}function BA(n,e){for(;performance.now()<e;){if(n.phase==="render"){DA(n);continue}if(n.phase==="flip"){if(!PA(n,e))return!1;continue}if(n.phase==="build-quads"){if(!FA(n,e))return!1;continue}if(n.phase==="done")return!0}return n.phase==="done"}function bu(n,e=!1){const t=Pr(e);Nr(n,t).length=0,_s[t].set(n,OA(n,t))}function HA(n,e=5,t=!1){const i=Pr(t);_s[i].has(n)||bu(n,t);const s=_s[i].get(n);if(!s)return!0;const r=BA(s,performance.now()+Math.max(0,e));return r&&_s[i].delete(n),r}function GA(n,e=!1){const t=Pr(e),i=_s[t].get(n);return i?CA(i):Nr(n,t).length>0?100:0}function VA(n,e=!1){return Nr(n,Pr(e))}class kA extends za{constructor(t){super();ce(this,"shouldSkipTileExit",!0);this._isExit=t}begin(t){bu(t,this._isExit)}incremental(t,i=5){return HA(t,i,this._isExit)}getPercentComplete(t){return GA(t,this._isExit)}getMasks(t){return VA(t,this._isExit)}}const Ka=new ei(10,10);Ka.rotateX(-Math.PI/2-.05);Ka.rotateZ(.01);const YA=new jn({color:Cs}),ds=new At(Ka,YA);class WA extends za{constructor(){super();ce(this,"hasRenderedScene",!0);ce(this,"duration",500)}begin(t){}initMeshes(t){t._scene.add(ds),ds.visible=!1}updateMeshes(t,i){ds.visible=!0,ds.position.y=.6-i*1}cleanupMeshes(t){ds.visible=!1}incremental(t,i){return!0}getPercentComplete(t){return 100}getMasks(t){return[]}}const zA=[{glyph:"SKIP",offset:4,width:2,action:n=>{n._didSolvePuzzle=!0,n._isGotoNextLevelQueued=!0,n._tileCelebrationT=1}},{glyph:"UNDO",offset:0,width:2.5,action:n=>{uc(n)}},{glyph:"RESET",offset:-3,width:2.5,action:n=>{for(;n.puzzleHistory.length>1;)uc(n)}}],nt=class nt{constructor(){ce(this,"gameState","loading");ce(this,"_allBoards",[new RA]);ce(this,"_board");ce(this,"_appGfx");ce(this,"_canvas");ce(this,"_renderer");ce(this,"_scene");ce(this,"_boardGroup");ce(this,"_trayGroup");ce(this,"_allTilesGroup");ce(this,"_uiTiles",[]);ce(this,"_scrabbleTiles",[]);ce(this,"_allTiles");ce(this,"_pickableMeshes",[]);ce(this,"_raycaster",new Ga);ce(this,"_pointer",new le);ce(this,"_hoveredPickable",null);ce(this,"_camera");ce(this,"_nextCamera");ce(this,"_controls");ce(this,"_renderPixelScale",1);ce(this,"_entranceTransition");ce(this,"_allEntranceTransitions");ce(this,"_allCelebrations");ce(this,"_allExitTransitions");ce(this,"_celebration");ce(this,"_exitTransition");ce(this,"_animVec",new w);ce(this,"_trayVisibilityBounds",new ts(nt._TRAY_VISIBILITY_BOX_MIN.clone(),nt._TRAY_VISIBILITY_BOX_MAX.clone()));ce(this,"_trayCorner",new w);ce(this,"_cameraOffset",new w);ce(this,"_trayBoundsDebugMesh");ce(this,"_focusTargetPos",new w);ce(this,"_titleScreenDance",new Ta);ce(this,"_entranceT",0);ce(this,"_camT",0);ce(this,"_tileT",0);ce(this,"_nextEntranceT",0);ce(this,"_nextExitT",0);ce(this,"_tileCelebrationT",0);ce(this,"_tileExitT",1);ce(this,"_exitT",0);ce(this,"_canGotoNextLevel",!1);ce(this,"_isGotoNextLevelQueued",!1);ce(this,"_focusTimeMs",0);ce(this,"_focusedTile",null);ce(this,"_returningTiles",[]);ce(this,"slotPos");ce(this,"slotQuat");ce(this,"puzzleHistory",[]);ce(this,"_dragStartTime",0);ce(this,"_dragStartPos",new le);ce(this,"_isDragging",!1);ce(this,"_draggingPos",new w(0,0,0));ce(this,"_targetIntersection",new w);ce(this,"_dragPlane",new On(new w(0,-1,0),2));ce(this,"dt",0);ce(this,"_didFinishEntrance",!1);ce(this,"_didSolvePuzzle",!1);const e=document.getElementById("app-canvas");if(!e)throw new Error("Missing #app-canvas");this._canvas=e,this._renderer=new VS({canvas:e,antialias:!1}),this._renderer.setSize(window.innerWidth,window.innerHeight),this._canvas.style.imageRendering="crisp-edges",this._canvas.style.imageRendering="pixelated",this._scene=new rd,this._scene.background=new Qe(Cs),this._camera=nt.newCamera(),this._camera.position.copy(nt._CAM_START),this._camera.lookAt(0,0,0),this._nextCamera=this._camera,this._controls=new M0(this._camera,this._canvas),this._controls.enableDamping=!0,this._controls.dampingFactor=.08,this._controls.maxPolarAngle=Math.PI*.48,this._controls.target.set(0,0,0),this._controls.enabled=!1,this._appGfx=new F0(this),this._appGfx.onResize(),this._board=Ei(this._allBoards),this._boardGroup=this._board.buildEmptyBoard(),this._trayGroup=$S(),this._trayGroup.position.set(0,.5,3),this._trayGroup.rotateX(.4),this._allTilesGroup=new jt,this._scene.add(this._allTilesGroup);const t=new w().subVectors(nt._TRAY_VISIBILITY_BOX_MAX,nt._TRAY_VISIBILITY_BOX_MIN),i=new w().addVectors(nt._TRAY_VISIBILITY_BOX_MIN,nt._TRAY_VISIBILITY_BOX_MAX).multiplyScalar(.5);this._trayBoundsDebugMesh=new At(new gi(t.x,t.y,t.z),new jn({color:3388927,transparent:!0,opacity:.18,depthWrite:!1,visible:!1})),this._trayBoundsDebugMesh.position.copy(i);for(let a=0;a<_i;a++){const l=new As(" ");l.animOffset=a*.1,this._scrabbleTiles.push(l);const d=jS(a);l.group.position.copy(d),this._trayGroup.add(l.group),this._pickableMeshes.push(l.pickableMesh)}for(let a=0;a<this._board.nRows;a++)for(let l=0;l<this._board.nCols;l++){const u=new As(" ");u.animOffset=(a+l)*.1,this._scrabbleTiles.push(u);const p=this._board.getSlotPos(a,l);u.group.position.copy(p),this._boardGroup.add(u.group),this._pickableMeshes.push(u.pickableMesh)}const s=[],r=[];this.slotPos=s,this.slotQuat=r;for(const[a,l]of this._scrabbleTiles.entries()){s.push(l.group.getWorldPosition(new w));const d=a-_i;if(d>=0){const u=Math.floor(d/this._board.nCols),p=d%this._board.nCols;r.push(this._board.getSlotQuat(u,p))}else r.push(l.group.getWorldQuaternion(new Sn))}for(const[a,l]of this._scrabbleTiles.entries())this._allTilesGroup.add(l.group),l.group.position.copy(s[a]),l.group.quaternion.copy(r[a]),l.slotPos=s[a],l.slotQuat=r[a],this._allTilesGroup.add(l.pickableMesh),l.pickableMesh.position.copy(s[a]),l.pickableMesh.quaternion.copy(r[a]);for(const{glyph:a,offset:l,action:d,width:u}of zA){const p=new As(a,u);this._allTilesGroup.add(p.group),this._pickableMeshes.push(p.pickableMesh);const o=new w(-En/2+l,0,-6);p.group.position.copy(o),p.slotPos=o,p.slotQuat=new Sn,p.uiAction=d,this._uiTiles.push(p)}this._allTiles=[...this._scrabbleTiles,...this._uiTiles],pu(this),this._allEntranceTransitions=[new sA(!1)];for(const a of this._allEntranceTransitions)a.initMeshes(this);this._entranceTransition=Ei(this._allEntranceTransitions),this._entranceTransition.initMeshes(this),this._allExitTransitions=[new kA(!0),new WA];for(const a of this._allExitTransitions)a.initMeshes(this);this._exitTransition=Ei(this._allExitTransitions),this._allCelebrations=[new gA],this._celebration=Ei(this._allCelebrations)}static randomCamStart(){return new w(3,.8,0).lerp(new w(-6,3,6),Math.random())}static newCamera(){return new zt(60,window.innerWidth/window.innerHeight,.1,1e6)}mouseUp(){const e=performance.now()-this._dragStartTime<200,t=this._dragStartPos.distanceTo(this._pointer)<.01;if(e&&t){this._isDragging=!1;return}if(this._isDragging&&this._hoveredPickable&&this._hoveredPickable.userData["scrabble-tile"].glyph===" "){this.mouseDown(),this._isDragging=!1;return}this._isDragging=!1,this._queueReturnFocusedTile(),this.mouseMove(null,null)}mouseDown(){if(this.gameState==="title-screen"){d0();return}if(this._hoveredPickable){const e=this._hoveredPickable.userData["scrabble-tile"];this._mouseDownOnTile(e)}else this._queueReturnFocusedTile()}_mouseDownOnTile(e){var t;if(e&&e.uiAction){e.uiAction(this);return}if(e&&e.glyph!==" ")this._focusedTile?((t=this._focusedTile)==null?void 0:t.tile)===e&&this._queueReturnFocusedTile():(this._focusTile(e),this._isDragging=!0,document.documentElement.style.cursor="grabbing",this._dragStartTime=performance.now(),this._dragStartPos.copy(this._pointer));else if(this._focusedTile&&e&&e.glyph===" "){const i=this._scrabbleTiles.indexOf(this._focusedTile.tile),s=this._scrabbleTiles.indexOf(e);this._scrabbleTiles[i]=e,this._scrabbleTiles[s]=this._focusedTile.tile,this._focusedTile.slotIndex=s,this._queueReturnFocusedTile(),this.mouseMove(null,null),e.group.position.copy(this.slotPos[i]),e.group.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[i].slotPos=this.slotPos[i],this._scrabbleTiles[i].slotQuat=this.slotQuat[i],this._scrabbleTiles[s].slotPos=this.slotPos[s],this._scrabbleTiles[s].slotQuat=this.slotQuat[s],this._scrabbleTiles[i].pickableMesh.position.copy(this.slotPos[i]),this._scrabbleTiles[i].pickableMesh.quaternion.copy(this.slotQuat[i]),this._scrabbleTiles[s].pickableMesh.position.copy(this.slotPos[s]),this._scrabbleTiles[s].pickableMesh.quaternion.copy(this.slotQuat[s])}}mouseMove(e,t){this._isDragging||(document.documentElement.style.cursor="default");const i=this._didFinishEntrance&&!this._didSolvePuzzle;let s=null;if(i&&e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.intersectObjects(this._pickableMeshes,!1);r.length>0&&(s=r[0].object)}if(s&&!this._focusedTile&&s.userData["scrabble-tile"].glyph===" "&&(s=null),s&&!this._isDragging&&(document.documentElement.style.cursor="pointer"),this._hoveredPickable&&(this._hoveredPickable.userData["scrabble-tile"].isHovered=!1),this._hoveredPickable=s,s&&(s.userData["scrabble-tile"].isHovered=!0),e!==null&&t!==null){this._pointer.set(e/this._canvas.width*2-1,-(t/this._canvas.height)*2+1),this._raycaster.setFromCamera(this._pointer,this._camera);const r=this._raycaster.ray.intersectPlane(this._dragPlane,this._targetIntersection);r&&(this._draggingPos.copy(r),this._draggingPos.x-=En/2,this._draggingPos.z-=En/2)}}_focusTile(e){var r;if(((r=this._focusedTile)==null?void 0:r.tile)===e){this._queueReturnFocusedTile();return}this._queueReturnFocusedTile();const t=this._returningTiles.findIndex(a=>a.tile===e),i=t>=0?this._returningTiles[t]:null;t>=0&&this._returningTiles.splice(t,1);const s=this._scrabbleTiles.indexOf(e);this._focusedTile={tile:e,position:((i==null?void 0:i.position)??e.group.position).clone(),quaternion:((i==null?void 0:i.quaternion)??e.group.quaternion).clone(),slotIndex:s},Va(this),e.updateRenderOrder(20),this._focusTimeMs=0}_queueReturnFocusedTile(){if(!this._focusedTile)return;const e=this._focusedTile;this._returningTiles.push({tile:e.tile,position:e.position,quaternion:e.quaternion,slotIndex:e.slotIndex}),e.tile.updateRenderOrder(10),this._focusedTile=null}async init(){this._scene.add(Qn),this._scene.add(this._boardGroup),this._scene.add(this._trayGroup),this._scene.add(this._trayBoundsDebugMesh),this.gameState="title-screen",this._entranceTransition.begin(this),this._entranceTransition.incremental(this,Number.POSITIVE_INFINITY),new rA(this).wireUiInput()}onResize(){this._appGfx.onResize(),this.gameState!=="title-screen"&&(this._entranceT<1&&(this._boardGroup.visible=!0,this._trayGroup.visible=!0,this._entranceTransition.begin(this),this._entranceTransition.incremental(this,Number.POSITIVE_INFINITY),this._entranceT=0),this._exitT===0&&this._didFinishEntrance&&(this._entranceTransition.begin(this),this._exitTransition.begin(this),this._nextEntranceT=0,this._nextExitT=0))}cycleRenderPixelScale(){this.setRenderPixelScale(this._renderPixelScale%6+1)}getRenderPixelScale(){return this._renderPixelScale}setRenderPixelScale(e){this._renderPixelScale!==e&&(this._renderPixelScale=e,this._appGfx.onResize())}};ce(nt,"_ANIM_MAX_ROTATION",Math.PI*.4),ce(nt,"_CAM_DURATION",2e3),ce(nt,"_TILE_DURATION",800),ce(nt,"_TILE_CELEBRATION_DURATION",2e3),ce(nt,"_TILE_EXIT_DURATION",1e3),ce(nt,"_CAM_START",nt.randomCamStart()),ce(nt,"_CAM_END",new w(0,8,4)),ce(nt,"_FOCUS_POS",new w(0,3.1,3)),ce(nt,"_FOCUS_LERP_ALPHA",.4),ce(nt,"_FOCUS_OSC_AMP",.07),ce(nt,"_FOCUS_OSC_SPEED",.006),ce(nt,"_POST_ENTRANCE_ZOOM_OUT_SPEED",.0055),ce(nt,"_POST_ENTRANCE_MAX_CAMERA_DISTANCE",30),ce(nt,"_TRAY_VISIBILITY_NDC_LIMIT",.98),ce(nt,"_TRAY_VISIBILITY_BOX_MIN",new w(-2.4,0,3)),ce(nt,"_TRAY_VISIBILITY_BOX_MAX",new w(2.4,1,4.5)),ce(nt,"_MASK_FILTER_COLORS",["#ff4466","#44ffaa","#4488ff","#ffcc00","#cc44ff"]);let at=nt;function lr(n,e,t){return(1-t)*n+t*e}const Kn=100,KA=40,zn=50;let Cu,Rc=0;const XA=.02;function qA(n,e){Rc+=n.dt*XA;const t=window.innerWidth-zn,i=window.innerHeight-zn;e.save(),e.translate(t+zn/2,i+zn/2),e.rotate(Rc),e.drawImage(Cu,0,0,Kn,Kn,-zn/2,-zn/2,zn,zn),e.restore()}async function ZA(){const n=document.createElement("canvas"),e=n.getContext("2d");n.width=Kn,n.height=Kn,e.clearRect(0,0,Kn,Kn),e.fillStyle="black",e.beginPath(),e.arc(Kn/2,Kn/2,KA,0,Math.PI),e.closePath(),e.fill(),Cu=n}_n("spinner",ZA);function JA(n){QA(n);const e=document.getElementById("overlay-canvas");(e.width!==window.innerWidth||e.height!==window.innerHeight)&&(e.width=window.innerWidth,e.height=window.innerHeight);const t=e.getContext("2d");if(t.clearRect(0,0,e.width,e.height),n._entranceT<1){const i=n._entranceT;n._entranceTransition.updateMeshes(n,i),Mc(n,t,e.width,e.height,i)}else if(n._exitT>0&&n._exitT<1){let i=1-n._exitT;n._exitTransition.updateMeshes(n,i),i=Math.pow(i,1/4),Mc(n,t,e.width,e.height,i,!0)}(n._nextEntranceT>0&&n._nextEntranceT<1||n._nextExitT>0&&n._nextExitT<1)&&qA(n,t)}function QA(n){const e=n._entranceT===1&&(n._exitT===0||n._exitTransition.hasRenderedScene);n._boardGroup.visible=e,n._trayGroup.visible=e,n._allTilesGroup.visible=e;for(const i of n._scrabbleTiles)i.updateGlow(n.dt);const t=n.gameState==="title-screen";n._renderer.render(n._scene,t?br:n._camera)}function Mc(n,e,t,i,s,r=!1){const a=t,l=i,d=ou(s,5),u=(1-d)*at._ANIM_MAX_ROTATION,p=Math.cos(u),o=Math.sin(u),c=n._titleScreenDance.getBlend();e.globalAlpha=1;const h=r?n._exitTransition.getMasks(n):n._entranceTransition.getMasks(n);for(let m=0;m<h.length;m+=1){const S=h[m];let E=S.x,f=S.y;if(S.worldPos){n._animVec.set(S.worldPos.x*p+S.worldPos.z*o,S.worldPos.y,-S.worldPos.x*o+S.worldPos.z*p).project(n._camera);const A=(n._animVec.x+1)/2*a,R=(1-n._animVec.y)/2*l;E=A-S.canvas.width/2+S.restOffsetX+S.animOffsetX*(1-s),f=R-S.canvas.height/2+S.restOffsetY+S.animOffsetY*(1-s)}let _=lr(S.restAngle,0,d);if(c>0){const A=n._titleScreenDance.getMaskPose(m,a,l,S.canvas.width,S.canvas.height);E=lr(E,A.x,c),f=lr(f,A.y,c),_=lr(_,A.angle,c)}e.save(),e.translate(E+S.canvas.width/2,f+S.canvas.height/2),e.rotate(_),e.drawImage(S.canvas,-S.canvas.width/2,-S.canvas.height/2),e.restore()}}function $A(n,e){n.dt=e;const t=n.gameState==="title-screen";if(n._titleScreenDance.update(e,t,n._entranceTransition.getMaskCount(n)),_u(e)&&(n._scene.remove(Qn),n.gameState="playing"),t){const s=performance.now();Qn.rotateZ(Math.sin(s*5e-4)*.001),Qn.rotateY(Math.sin(s*568164e-9)*.001)}else n._entranceT=Math.min(1,n._entranceT+e/n._entranceTransition.duration),n._entranceT>=1&&n._entranceTransition.cleanupMeshes(n);if(n._entranceT>=1&&n._camT<1){n._camT=Math.min(1,n._camT+e/at._CAM_DURATION);const s=ou(n._camT,10);n._camera.position.lerpVectors(at._CAM_START,at._CAM_END,s)}if(n._entranceT>=1&&n._camT>=1&&n._tileT<1){n._tileT=Math.min(1,n._tileT+e/at._TILE_DURATION);for(const s of n._allTiles)s.show(),s.anim=n._tileT}const i=n._exitTransition.shouldSkipTileExit;if(!n._didFinishEntrance&&n._tileT>=1){n._didFinishEntrance=!0;for(const s of n._allTiles)s.show(),s.anim=1;n._nextCamera=at.newCamera(),n._nextCamera.position.copy(at.randomCamStart()),n._nextCamera.lookAt(0,0,0),n._entranceTransition.begin(n),n._nextEntranceT=0,n._nextExitT=0,n._tileCelebrationT=0,n._tileExitT=0,n._exitT=0}else if(n._didFinishEntrance&&n._nextEntranceT<1)n._entranceTransition.incremental(n),n._nextEntranceT=n._entranceTransition.getPercentComplete(n)/100;else if(n._didFinishEntrance&&n._nextExitT<1&&n._didSolvePuzzle)n._exitTransition.incremental(n,5),n._nextExitT=n._exitTransition.getPercentComplete(n)/100,n._nextExitT>=1&&(n._canGotoNextLevel=!0);else if(n._didSolvePuzzle&&n._tileCelebrationT<1)n._tileCelebrationT=Math.min(1,n._tileCelebrationT+e/at._TILE_CELEBRATION_DURATION),n._celebration.update(n,n._tileCelebrationT);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._tileExitT<1&&!i&&n._isGotoNextLevelQueued&&n._tileCelebrationT===1)if(n._tileExitT=Math.min(1,n._tileExitT+e/at._TILE_EXIT_DURATION),n._tileExitT>=1)for(const s of n._allTiles)s.hide();else for(const s of n._allTiles)s.anim=1-n._tileExitT;else if(n._nextEntranceT>=1&&n._nextExitT>=1&&(n._tileExitT>=1||i)&&n._exitT<1&&n._isGotoNextLevelQueued)n._exitT=Math.min(1,n._exitT+e/n._exitTransition.duration);else if(n._nextEntranceT>=1&&n._nextExitT>=1&&n._exitT>=1){n._didFinishEntrance=!1,n._didSolvePuzzle=!1,n._canGotoNextLevel=!1,n._isGotoNextLevelQueued=!1,n._entranceT=0,n._camT=0,n._tileT=0,n._nextEntranceT=0,n._nextExitT=0,n._tileCelebrationT=0,n._tileExitT=0,n._exitT=0,at._CAM_START.copy(n._nextCamera.position),n._camera.position.copy(n._nextCamera.position),n._camera.quaternion.copy(n._nextCamera.quaternion);for(const s of n._allTiles)s.hide();n._exitTransition.cleanupMeshes(n),n._exitTransition=Ei(n._allExitTransitions),n._entranceTransition=Ei(n._allEntranceTransitions),pu(n)}jA(n,e),t_(n,e),n._controls.update(),JA(n)}function jA(n,e){if(n._focusedTile){n._focusTimeMs+=e;const t=Math.sin(n._focusTimeMs*at._FOCUS_OSC_SPEED)*at._FOCUS_OSC_AMP;n._focusTargetPos.copy(n._isDragging?n._draggingPos:at._FOCUS_POS),n._focusTargetPos.y+=t,n._focusedTile.tile.group.position.lerp(n._focusTargetPos,at._FOCUS_LERP_ALPHA)}for(let t=n._returningTiles.length-1;t>=0;t-=1){const i=n._returningTiles[t],s=n.slotPos[i.slotIndex],r=n.slotQuat[i.slotIndex];i.tile.group.position.lerp(s,at._FOCUS_LERP_ALPHA),i.tile.group.quaternion.slerp(r,at._FOCUS_LERP_ALPHA);const a=i.tile.group.position.distanceToSquared(s)<1e-4,l=Math.abs(i.tile.group.quaternion.dot(r))>.999;!a||!l||(i.tile.group.position.copy(s),i.tile.group.quaternion.copy(r),n._returningTiles.splice(t,1),i.tile.updateRenderOrder(),Va(n)&&(n._didSolvePuzzle=!0,n.mouseMove(null,null),n._tileCelebrationT=0,n._isGotoNextLevelQueued=!0,n._exitTransition.begin(n)))}}const Ro=[0,0],Mo=[0,0],vo=[0,0];function e_(n){if(n._trayVisibilityBounds.isEmpty())return!0;const{min:e,max:t}=n._trayVisibilityBounds,i=at._TRAY_VISIBILITY_NDC_LIMIT;Ro[0]=e.x,Ro[1]=t.x,Mo[0]=e.y,Mo[1]=t.y,vo[0]=e.z,vo[1]=t.z;for(const s of Ro)for(const r of Mo)for(const a of vo)if(n._trayCorner.set(s,r,a).project(n._camera),!Number.isFinite(n._trayCorner.x)||!Number.isFinite(n._trayCorner.y)||!Number.isFinite(n._trayCorner.z)||Math.abs(n._trayCorner.x)>i||Math.abs(n._trayCorner.y)>i||n._trayCorner.z<-1||n._trayCorner.z>1)return!1;return!0}function t_(n,e){if(n._camT<1||e_(n))return;n._cameraOffset.copy(n._camera.position).sub(n._controls.target);const t=n._cameraOffset.length();if(t===0||t>=at._POST_ENTRANCE_MAX_CAMERA_DISTANCE)return;n._cameraOffset.divideScalar(t);const i=at._POST_ENTRANCE_ZOOM_OUT_SPEED*e,s=at._POST_ENTRANCE_MAX_CAMERA_DISTANCE-t;n._camera.position.addScaledVector(n._cameraOffset,Math.min(i,s))}async function n_(){const n=document.getElementById("startup-loading-label"),e=document.getElementById("startup-loading-screen");await KS(r=>{n&&(n.innerHTML=`LOADING (${r}%)`)});const t=new at;await t.init(),e==null||e.classList.add("hidden"),window.addEventListener("resize",()=>t.onResize());let i=performance.now();const s=()=>{requestAnimationFrame(s);const r=performance.now(),a=Math.min(30,r-i);i=r,$A(t,a)};requestAnimationFrame(s)}n_();
