/**
 * @file training gui layout
 */
TRAINING_LAYOUT = {

  // config buttons at top
  _config: {
    height: 0.12,
    top: 0.01,
    left: 0.13,
  },
  configBtns: {
    parent: '_config',
    width: 0.4,
    repeat: 'right',
    margin: 0.01,
  },

  // exercise title
  title: {
    height: 0.1,
    width: 0.4,
    left: 'auto',
    top: 0.1,
  },

  // exercise text prompt
  prompt: {

    height: 0.1,
    width: 0.8,
    left: 'auto',

    // top: 0.225,
    bottom: 0.02,
  },

  // play training sounds like intervals
  playBtn: {

    height: 0.1,
    width: 0.4,
    left: 'auto',
    top: 0.35,
  },

  // exercise multiple choice options
  // options: {
  //   width: '8.3%',
  //   repeat: 'right',
  //   margin: 0.01,
  //   height: 'gold-sax',
  //   bottom: .02,
  // },
  // midOptions: {
  //   parent: '_optionsContainer',
  //   width: .8/6,
  //   height: .3/2,
  //   top:'auto',
  //   repeat: 'right',
  //   margin: 0.01,
  // },
  // topOptions: {
  //   parent: '_optionsContainer',
  //   width: .8/6,
  //   height: .3/2,
  //   repeat: 'right',
  //   margin: 0.01,
  // },
  // bottomOptions: {
  //   parent: '_optionsContainer',
  //   width: .8/6,
  //   height: .3/2,
  //   bottom: 0,
  //   repeat: 'right',
  //   margin: 0.01,
  // },

  // next exercise on bottom right
  nextBtn: {
    width: 0.2,
    height: 0.1,
    bottom: 0.02,
    right: 0.02,
  },
};
