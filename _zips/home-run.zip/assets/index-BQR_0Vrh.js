var Qc=Object.defineProperty;var zc=(i,e,t)=>e in i?Qc(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var Y=(i,e,t)=>zc(i,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const A of r)if(A.type==="childList")for(const o of A.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function t(r){const A={};return r.integrity&&(A.integrity=r.integrity),r.referrerPolicy&&(A.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?A.credentials="include":r.crossOrigin==="anonymous"?A.credentials="omit":A.credentials="same-origin",A}function n(r){if(r.ep)return;r.ep=!0;const A=t(r);fetch(r.href,A)}})();const Gc={NAMES:["start-menu","main-menu","training-menu","playing-gui","replay-gui","tutorial-gui"]},Il={NAMES:["bat","flail"]},Hr={NAMES:["baseball","crystal"]},Hc={NAMES:["ok","foul","perfect","debug-effect"]},yi=10;let Vr=0,jr=0;const kl=new Float32Array(yi),Ul=new Float32Array(yi),Pl=new Float32Array(yi);function Vc(i,e,t){const n=Vr;kl[n]=i,Ul[n]=e,Pl[n]=t,Vr=(Vr+1)%yi,jr=Math.min(yi,jr+1)}class $n{constructor(e){Y(this,"isPitchMeterFull",!1);Y(this,"gravity",1400);Y(this,"damping",.997);Y(this,"tipDamping",.997);Y(this,"constraintIterations",1);Y(this,"label","");Y(this,"segmentLength",100);Y(this,"relativeLength",1.5);Y(this,"mousex",1);Y(this,"mousey",1);Y(this,"points");Y(this,"angle",0);Y(this,"physicsSprites",[]);Y(this,"isUpright",!1);Y(this,"uprightHeldDelay",.01);Y(this,"uprightHeldCountdown",this.uprightHeldDelay);Y(this,"isHeldUpright",!1);this.pointCount=e,this.points=Array.from({length:this.pointCount},(t,n)=>{const r=this.mousex,A=this.mousey+n*this.segmentLength;return{x:r,y:A,prevX:r,prevY:A}})}simulate(e){const{points:t,mousex:n,mousey:r,damping:A,tipDamping:o,gravity:l,constraintIterations:f,segmentLength:c}=this,g=t[0];g.x=g.prevX=n,g.y=g.prevY=r;for(let u=1;u<t.length;u++){const h=t[u],m=u==t.length-1?o:A,p=(h.x-h.prevX)*m,d=(h.y-h.prevY)*m;h.prevX=h.x,h.prevY=h.y,h.x+=p,h.y+=d+l*e*e}for(let u=0;u<f;u++){t[0].x=n,t[0].y=r;for(let h=0;h<t.length-1;h++){const m=t[h],p=t[h+1],d=p.x-m.x,R=p.y-m.y,E=Math.hypot(d,R)||1e-4,v=(E-c)/E,w=d*v,y=R*v;h===0?(p.x-=w,p.y-=y):(m.x+=w*.5,m.y+=y*.5,p.x-=w*.5,p.y-=y*.5)}}const s=t.at(-1),a=Math.atan2(s.y-r,s.x-n);Vc(n,r,a),this.angle,this.isPitchMeterFull?(this.isUpright=!0,this.uprightHeldCountdown-=e,this.uprightHeldCountdown<=0&&(this.isHeldUpright=!0)):(this.isUpright=!1,this.isHeldUpright=!1,this.uprightHeldCountdown=this.uprightHeldDelay),this.angle=a}static register(e,t){if(console.log(`registering swingable ${e}`),e in this._registered)throw new Error(`swingable already registered: ${e}`);this._registered[e]=t}static create(e){const t=this._registered[e];if(!t)throw new Error(`swingable not registered: ${e}`);return t.factory()}static async preloadAll(){for(const e of Il.NAMES){const t=this._registered[e];if(!t)throw new Error(`swingable not registered: ${e}`);await t.preload()}}}Y($n,"_registered",{});class Wc{constructor(){Y(this,"dpr",1);Y(this,"w",1);Y(this,"h",1);Y(this,"targetRadius",1)}resize(){this.dpr=window.devicePixelRatio,this.w=window.innerWidth*this.dpr,this.h=window.innerHeight*this.dpr,this.targetRadius=1.5*(Math.min(this.w,this.h)/5)/6}}const qe=new Wc,Kc=document.getElementById("app"),oa="LuckiestGuy",Xc="greenyellow",Va="#000",Zc="#000",qc="#000",Yc="#fff",Dl=900,$r=new Map;function Wa(i,e,t,n,r,A){i.beginPath(),i.moveTo(e+A,t),i.arcTo(e+n,t,e+n,t+r,A),i.arcTo(e+n,t+r,e,t+r,A),i.arcTo(e,t+r,e,t,A),i.arcTo(e,t,e+n,t,A),i.closePath()}function Jc(i,e,t,n,r){const A=t/20,o=t/5,l=qe.targetRadius/5;Wa(i,A,A+l,e-2*A,t-2*A-l,o),i.fillStyle=Zc,i.fill(),Wa(i,A,A,e-2*A,t-2*A-l,o),i.fillStyle=Xc,i.fill(),i.lineWidth=qe.targetRadius/10,i.strokeStyle=Va,i.stroke(),n&&(i.font=`${r}px ${oa}`,i.textAlign="center",i.textBaseline="middle",i.fillStyle=Va,i.fillText(n,e/2,t/2))}function jc(i,e,t,n,r){if(!n)return;i.font=`${r}px ${oa}`,i.textAlign="center",i.textBaseline="middle",i.lineJoin="round",i.lineWidth=r*.15,i.strokeStyle=qc;const A=t/2;i.strokeText(n,e/2,A),i.fillStyle=Yc,i.fillText(n,e/2,A)}function qi(i,e){const t=$r.get(i);if(!t)return;const{canvas:n,ctx:r,variant:A}=t,o=n.width,l=n.height;r.clearRect(0,0,o,l);const f=l*.4;A==="label"?jc(r,o,l,e,f):Jc(r,o,l,e,f)}function $c(i,e){const{id:t,label:n,style:r,variant:A="button"}=i;if(document.getElementById(t))throw new Error(`element with id ${t} already rendered`);const o=document.createElement("canvas");o.id=t,o.className="gui-element",o.style.cssText=r,o.onclick=()=>i.onclick(e),Kc.append(o);const l=window.devicePixelRatio||1,f=o.clientWidth||parseFloat(o.style.width)||100,c=o.clientHeight||parseFloat(o.style.height)||100;o.width=Math.round(f*l),o.height=Math.round(c*l);const g=o.getContext("2d");g.scale(l,l);const s=document.createElement("canvas");s.width=o.width,s.height=o.height;const a=s.getContext("2d");return a.globalCompositeOperation="copy",a.drawImage(o,0,0),a.globalCompositeOperation="source-over",$r.set(t,{canvas:o,base:s,ctx:g,variant:A}),qi(t,n),o}function or(i,e,t=1){const n=i.match(new RegExp(String.raw`\b${e}\s*:\s*([-+]?\d*\.?\d+)\s*%`,"i"));if(!n){const r=i.match(new RegExp(String.raw`\b${e}\s*:\s*([-+]?\d*\.?\d+)\s*px`,"i"));if(!r)throw new Error("No percentage or px top value found");return Number(r[1])/(Dl*t)}return Number(n[1])/100}class ft{constructor(e){Y(this,"_elements");Y(this,"_rendered");Y(this,"_bounceIndex",0);this._elements=this.elements(),this._rendered=this._elements.map(t=>$c(t,e));for(const t of this._rendered)t.classList.add("hidden")}setLabel(e,t){const n=this._elements.find(r=>r.id===e);if(!n)throw new Error(`no such element: ${e}`);n.label=t,qi(e,t)}hide(e){var t;for(const{id:n}of this._elements)(t=document.getElementById(n))==null||t.classList.add("hidden");this.onClose(e)}show(e){var t;for(const{id:n}of this._elements)(t=document.getElementById(n))==null||t.classList.remove("hidden");this.resizeElements(),this.onOpen(e)}scalePx(e,t){return e.replace(/(-?\d*\.?\d+)px\b/g,(n,r)=>`${Math.round(r*t)}px`)}updateIdleBounce(e,t){const r=Math.floor(performance.now()/468.75)%2;if(r!==this._bounceIndex){this._bounceIndex=r;for(const A of this._elements){const o=$r.get(A.id);if(!o)return;let l=Math.floor(window.innerHeight*or(A.style,"top"));l+=r*2,o.canvas.style.setProperty("top",`${l}px`);const f=Math.floor(window.innerWidth*or(A.style,"left",window.innerWidth/window.innerHeight));o.canvas.style.setProperty("left",`${f}px`)}}}updateAnimations(e,t){}updateFilmStrips(e,t){for(const n of this._elements)if(n.filmstrip){const r=$r.get(n.id);if(!r)return;const{frameWidth:A,frameHeight:o,nFrames:l,frameIndex:f}=n.filmstrip,c=Math.floor(performance.now()/468.75)%l;if(c===f)continue;n.filmstrip.frameIndex=c;const{canvas:g,ctx:s,variant:a}=r;qi(n.id,n.label),s.imageSmoothingEnabled=!0,s.drawImage(n.filmstrip.canvas,0,c*o,A,o,0,0,g.height,g.height)}}resizeElements(){const{w:e,h:t,dpr:n}=qe,A=Math.min(e,t)/Dl;for(const{id:o,style:l,label:f}of this._elements){const c=document.getElementById(o);c.style.cssText=l;const g=c.clientWidth,s=c.clientHeight,a=Math.round(g*A),u=Math.round(s*A);c.style.width=`${Math.round(a/n)}px`,c.style.height=`${Math.round(u/n)}px`,c.width=c.clientWidth*n,c.height=c.clientHeight*n;const h=Math.floor(window.innerHeight*or(l,"top"));c.style.setProperty("top",`${h}px`);const m=Math.floor(window.innerWidth*or(l,"left",window.innerWidth/window.innerHeight));c.style.setProperty("left",`${m}px`),qi(o,f)}}static register(e,t){if(console.log(`registering effect ${e}`),e in this._registered)throw new Error(`gui already registered: ${e}`);this._registered[e]=t}static create(e,t){const n=this._registered[e];if(!n)throw new Error(`gui not registered: ${e}`);return this._instantiated[e]||(this._instantiated[e]=n.factory(t)),this._instantiated[e]}static async preloadAll(){await document.fonts.load(`90px ${oa}`);for(const e of Gc.NAMES){const t=this._registered[e];if(!t)throw new Error(`gui not registered: ${e}`);await t.preload()}}}Y(ft,"_registered",{}),Y(ft,"_instantiated",{});function eu(i){return i[Math.floor(Math.random()*i.length)]}function Ol(i){let e=i.length,t;for(;e>0;)t=Math.floor(Math.random()*e),e--,[i[e],i[t]]=[i[t],i[e]];return i}var Ni=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},mA={};/*!
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */var Ka;function tu(){return Ka||(Ka=1,(function(i){(function(){var e=function(){this.init()};e.prototype={init:function(){var s=this||t;return s._counter=1e3,s._html5AudioPool=[],s.html5PoolSize=10,s._codecs={},s._howls=[],s._muted=!1,s._volume=1,s._canPlayEvent="canplaythrough",s._navigator=typeof window<"u"&&window.navigator?window.navigator:null,s.masterGain=null,s.noAudio=!1,s.usingWebAudio=!0,s.autoSuspend=!0,s.ctx=null,s.autoUnlock=!0,s._setup(),s},volume:function(s){var a=this||t;if(s=parseFloat(s),a.ctx||g(),typeof s<"u"&&s>=0&&s<=1){if(a._volume=s,a._muted)return a;a.usingWebAudio&&a.masterGain.gain.setValueAtTime(s,t.ctx.currentTime);for(var u=0;u<a._howls.length;u++)if(!a._howls[u]._webAudio)for(var h=a._howls[u]._getSoundIds(),m=0;m<h.length;m++){var p=a._howls[u]._soundById(h[m]);p&&p._node&&(p._node.volume=p._volume*s)}return a}return a._volume},mute:function(s){var a=this||t;a.ctx||g(),a._muted=s,a.usingWebAudio&&a.masterGain.gain.setValueAtTime(s?0:a._volume,t.ctx.currentTime);for(var u=0;u<a._howls.length;u++)if(!a._howls[u]._webAudio)for(var h=a._howls[u]._getSoundIds(),m=0;m<h.length;m++){var p=a._howls[u]._soundById(h[m]);p&&p._node&&(p._node.muted=s?!0:p._muted)}return a},stop:function(){for(var s=this||t,a=0;a<s._howls.length;a++)s._howls[a].stop();return s},unload:function(){for(var s=this||t,a=s._howls.length-1;a>=0;a--)s._howls[a].unload();return s.usingWebAudio&&s.ctx&&typeof s.ctx.close<"u"&&(s.ctx.close(),s.ctx=null,g()),s},codecs:function(s){return(this||t)._codecs[s.replace(/^x-/,"")]},_setup:function(){var s=this||t;if(s.state=s.ctx&&s.ctx.state||"suspended",s._autoSuspend(),!s.usingWebAudio)if(typeof Audio<"u")try{var a=new Audio;typeof a.oncanplaythrough>"u"&&(s._canPlayEvent="canplay")}catch{s.noAudio=!0}else s.noAudio=!0;try{var a=new Audio;a.muted&&(s.noAudio=!0)}catch{}return s.noAudio||s._setupCodecs(),s},_setupCodecs:function(){var s=this||t,a=null;try{a=typeof Audio<"u"?new Audio:null}catch{return s}if(!a||typeof a.canPlayType!="function")return s;var u=a.canPlayType("audio/mpeg;").replace(/^no$/,""),h=s._navigator?s._navigator.userAgent:"",m=h.match(/OPR\/(\d+)/g),p=m&&parseInt(m[0].split("/")[1],10)<33,d=h.indexOf("Safari")!==-1&&h.indexOf("Chrome")===-1,R=h.match(/Version\/(.*?) /),E=d&&R&&parseInt(R[1],10)<15;return s._codecs={mp3:!!(!p&&(u||a.canPlayType("audio/mp3;").replace(/^no$/,""))),mpeg:!!u,opus:!!a.canPlayType('audio/ogg; codecs="opus"').replace(/^no$/,""),ogg:!!a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),oga:!!a.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),wav:!!(a.canPlayType('audio/wav; codecs="1"')||a.canPlayType("audio/wav")).replace(/^no$/,""),aac:!!a.canPlayType("audio/aac;").replace(/^no$/,""),caf:!!a.canPlayType("audio/x-caf;").replace(/^no$/,""),m4a:!!(a.canPlayType("audio/x-m4a;")||a.canPlayType("audio/m4a;")||a.canPlayType("audio/aac;")).replace(/^no$/,""),m4b:!!(a.canPlayType("audio/x-m4b;")||a.canPlayType("audio/m4b;")||a.canPlayType("audio/aac;")).replace(/^no$/,""),mp4:!!(a.canPlayType("audio/x-mp4;")||a.canPlayType("audio/mp4;")||a.canPlayType("audio/aac;")).replace(/^no$/,""),weba:!!(!E&&a.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),webm:!!(!E&&a.canPlayType('audio/webm; codecs="vorbis"').replace(/^no$/,"")),dolby:!!a.canPlayType('audio/mp4; codecs="ec-3"').replace(/^no$/,""),flac:!!(a.canPlayType("audio/x-flac;")||a.canPlayType("audio/flac;")).replace(/^no$/,"")},s},_unlockAudio:function(){var s=this||t;if(!(s._audioUnlocked||!s.ctx)){s._audioUnlocked=!1,s.autoUnlock=!1,!s._mobileUnloaded&&s.ctx.sampleRate!==44100&&(s._mobileUnloaded=!0,s.unload()),s._scratchBuffer=s.ctx.createBuffer(1,1,22050);var a=function(u){for(;s._html5AudioPool.length<s.html5PoolSize;)try{var h=new Audio;h._unlocked=!0,s._releaseHtml5Audio(h)}catch{s.noAudio=!0;break}for(var m=0;m<s._howls.length;m++)if(!s._howls[m]._webAudio)for(var p=s._howls[m]._getSoundIds(),d=0;d<p.length;d++){var R=s._howls[m]._soundById(p[d]);R&&R._node&&!R._node._unlocked&&(R._node._unlocked=!0,R._node.load())}s._autoResume();var E=s.ctx.createBufferSource();E.buffer=s._scratchBuffer,E.connect(s.ctx.destination),typeof E.start>"u"?E.noteOn(0):E.start(0),typeof s.ctx.resume=="function"&&s.ctx.resume(),E.onended=function(){E.disconnect(0),s._audioUnlocked=!0,document.removeEventListener("touchstart",a,!0),document.removeEventListener("touchend",a,!0),document.removeEventListener("click",a,!0),document.removeEventListener("keydown",a,!0);for(var v=0;v<s._howls.length;v++)s._howls[v]._emit("unlock")}};return document.addEventListener("touchstart",a,!0),document.addEventListener("touchend",a,!0),document.addEventListener("click",a,!0),document.addEventListener("keydown",a,!0),s}},_obtainHtml5Audio:function(){var s=this||t;if(s._html5AudioPool.length)return s._html5AudioPool.pop();var a=new Audio().play();return a&&typeof Promise<"u"&&(a instanceof Promise||typeof a.then=="function")&&a.catch(function(){console.warn("HTML5 Audio pool exhausted, returning potentially locked audio object.")}),new Audio},_releaseHtml5Audio:function(s){var a=this||t;return s._unlocked&&a._html5AudioPool.push(s),a},_autoSuspend:function(){var s=this;if(!(!s.autoSuspend||!s.ctx||typeof s.ctx.suspend>"u"||!t.usingWebAudio)){for(var a=0;a<s._howls.length;a++)if(s._howls[a]._webAudio){for(var u=0;u<s._howls[a]._sounds.length;u++)if(!s._howls[a]._sounds[u]._paused)return s}return s._suspendTimer&&clearTimeout(s._suspendTimer),s._suspendTimer=setTimeout(function(){if(s.autoSuspend){s._suspendTimer=null,s.state="suspending";var h=function(){s.state="suspended",s._resumeAfterSuspend&&(delete s._resumeAfterSuspend,s._autoResume())};s.ctx.suspend().then(h,h)}},3e4),s}},_autoResume:function(){var s=this;if(!(!s.ctx||typeof s.ctx.resume>"u"||!t.usingWebAudio))return s.state==="running"&&s.ctx.state!=="interrupted"&&s._suspendTimer?(clearTimeout(s._suspendTimer),s._suspendTimer=null):s.state==="suspended"||s.state==="running"&&s.ctx.state==="interrupted"?(s.ctx.resume().then(function(){s.state="running";for(var a=0;a<s._howls.length;a++)s._howls[a]._emit("resume")}),s._suspendTimer&&(clearTimeout(s._suspendTimer),s._suspendTimer=null)):s.state==="suspending"&&(s._resumeAfterSuspend=!0),s}};var t=new e,n=function(s){var a=this;if(!s.src||s.src.length===0){console.error("An array of source files must be passed with any new Howl.");return}a.init(s)};n.prototype={init:function(s){var a=this;return t.ctx||g(),a._autoplay=s.autoplay||!1,a._format=typeof s.format!="string"?s.format:[s.format],a._html5=s.html5||!1,a._muted=s.mute||!1,a._loop=s.loop||!1,a._pool=s.pool||5,a._preload=typeof s.preload=="boolean"||s.preload==="metadata"?s.preload:!0,a._rate=s.rate||1,a._sprite=s.sprite||{},a._src=typeof s.src!="string"?s.src:[s.src],a._volume=s.volume!==void 0?s.volume:1,a._xhr={method:s.xhr&&s.xhr.method?s.xhr.method:"GET",headers:s.xhr&&s.xhr.headers?s.xhr.headers:null,withCredentials:s.xhr&&s.xhr.withCredentials?s.xhr.withCredentials:!1},a._duration=0,a._state="unloaded",a._sounds=[],a._endTimers={},a._queue=[],a._playLock=!1,a._onend=s.onend?[{fn:s.onend}]:[],a._onfade=s.onfade?[{fn:s.onfade}]:[],a._onload=s.onload?[{fn:s.onload}]:[],a._onloaderror=s.onloaderror?[{fn:s.onloaderror}]:[],a._onplayerror=s.onplayerror?[{fn:s.onplayerror}]:[],a._onpause=s.onpause?[{fn:s.onpause}]:[],a._onplay=s.onplay?[{fn:s.onplay}]:[],a._onstop=s.onstop?[{fn:s.onstop}]:[],a._onmute=s.onmute?[{fn:s.onmute}]:[],a._onvolume=s.onvolume?[{fn:s.onvolume}]:[],a._onrate=s.onrate?[{fn:s.onrate}]:[],a._onseek=s.onseek?[{fn:s.onseek}]:[],a._onunlock=s.onunlock?[{fn:s.onunlock}]:[],a._onresume=[],a._webAudio=t.usingWebAudio&&!a._html5,typeof t.ctx<"u"&&t.ctx&&t.autoUnlock&&t._unlockAudio(),t._howls.push(a),a._autoplay&&a._queue.push({event:"play",action:function(){a.play()}}),a._preload&&a._preload!=="none"&&a.load(),a},load:function(){var s=this,a=null;if(t.noAudio){s._emit("loaderror",null,"No audio support.");return}typeof s._src=="string"&&(s._src=[s._src]);for(var u=0;u<s._src.length;u++){var h,m;if(s._format&&s._format[u])h=s._format[u];else{if(m=s._src[u],typeof m!="string"){s._emit("loaderror",null,"Non-string found in selected audio sources - ignoring.");continue}h=/^data:audio\/([^;,]+);/i.exec(m),h||(h=/\.([^.]+)$/.exec(m.split("?",1)[0])),h&&(h=h[1].toLowerCase())}if(h||console.warn('No file extension was found. Consider using the "format" property or specify an extension.'),h&&t.codecs(h)){a=s._src[u];break}}if(!a){s._emit("loaderror",null,"No codec support for selected audio sources.");return}return s._src=a,s._state="loading",window.location.protocol==="https:"&&a.slice(0,5)==="http:"&&(s._html5=!0,s._webAudio=!1),new r(s),s._webAudio&&o(s),s},play:function(s,a){var u=this,h=null;if(typeof s=="number")h=s,s=null;else{if(typeof s=="string"&&u._state==="loaded"&&!u._sprite[s])return null;if(typeof s>"u"&&(s="__default",!u._playLock)){for(var m=0,p=0;p<u._sounds.length;p++)u._sounds[p]._paused&&!u._sounds[p]._ended&&(m++,h=u._sounds[p]._id);m===1?s=null:h=null}}var d=h?u._soundById(h):u._inactiveSound();if(!d)return null;if(h&&!s&&(s=d._sprite||"__default"),u._state!=="loaded"){d._sprite=s,d._ended=!1;var R=d._id;return u._queue.push({event:"play",action:function(){u.play(R)}}),R}if(h&&!d._paused)return a||u._loadQueue("play"),d._id;u._webAudio&&t._autoResume();var E=Math.max(0,d._seek>0?d._seek:u._sprite[s][0]/1e3),v=Math.max(0,(u._sprite[s][0]+u._sprite[s][1])/1e3-E),w=v*1e3/Math.abs(d._rate),y=u._sprite[s][0]/1e3,b=(u._sprite[s][0]+u._sprite[s][1])/1e3;d._sprite=s,d._ended=!1;var _=function(){d._paused=!1,d._seek=E,d._start=y,d._stop=b,d._loop=!!(d._loop||u._sprite[s][2])};if(E>=b){u._ended(d);return}var x=d._node;if(u._webAudio){var K=function(){u._playLock=!1,_(),u._refreshBuffer(d);var H=d._muted||u._muted?0:d._volume;x.gain.setValueAtTime(H,t.ctx.currentTime),d._playStart=t.ctx.currentTime,typeof x.bufferSource.start>"u"?d._loop?x.bufferSource.noteGrainOn(0,E,86400):x.bufferSource.noteGrainOn(0,E,v):d._loop?x.bufferSource.start(0,E,86400):x.bufferSource.start(0,E,v),w!==1/0&&(u._endTimers[d._id]=setTimeout(u._ended.bind(u,d),w)),a||setTimeout(function(){u._emit("play",d._id),u._loadQueue()},0)};t.state==="running"&&t.ctx.state!=="interrupted"?K():(u._playLock=!0,u.once("resume",K),u._clearTimer(d._id))}else{var T=function(){x.currentTime=E,x.muted=d._muted||u._muted||t._muted||x.muted,x.volume=d._volume*t.volume(),x.playbackRate=d._rate;try{var H=x.play();if(H&&typeof Promise<"u"&&(H instanceof Promise||typeof H.then=="function")?(u._playLock=!0,_(),H.then(function(){u._playLock=!1,x._unlocked=!0,a?u._loadQueue():u._emit("play",d._id)}).catch(function(){u._playLock=!1,u._emit("playerror",d._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction."),d._ended=!0,d._paused=!0})):a||(u._playLock=!1,_(),u._emit("play",d._id)),x.playbackRate=d._rate,x.paused){u._emit("playerror",d._id,"Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.");return}s!=="__default"||d._loop?u._endTimers[d._id]=setTimeout(u._ended.bind(u,d),w):(u._endTimers[d._id]=function(){u._ended(d),x.removeEventListener("ended",u._endTimers[d._id],!1)},x.addEventListener("ended",u._endTimers[d._id],!1))}catch(O){u._emit("playerror",d._id,O)}};x.src==="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA"&&(x.src=u._src,x.load());var B=window&&window.ejecta||!x.readyState&&t._navigator.isCocoonJS;if(x.readyState>=3||B)T();else{u._playLock=!0,u._state="loading";var F=function(){u._state="loaded",T(),x.removeEventListener(t._canPlayEvent,F,!1)};x.addEventListener(t._canPlayEvent,F,!1),u._clearTimer(d._id)}}return d._id},pause:function(s){var a=this;if(a._state!=="loaded"||a._playLock)return a._queue.push({event:"pause",action:function(){a.pause(s)}}),a;for(var u=a._getSoundIds(s),h=0;h<u.length;h++){a._clearTimer(u[h]);var m=a._soundById(u[h]);if(m&&!m._paused&&(m._seek=a.seek(u[h]),m._rateSeek=0,m._paused=!0,a._stopFade(u[h]),m._node))if(a._webAudio){if(!m._node.bufferSource)continue;typeof m._node.bufferSource.stop>"u"?m._node.bufferSource.noteOff(0):m._node.bufferSource.stop(0),a._cleanBuffer(m._node)}else(!isNaN(m._node.duration)||m._node.duration===1/0)&&m._node.pause();arguments[1]||a._emit("pause",m?m._id:null)}return a},stop:function(s,a){var u=this;if(u._state!=="loaded"||u._playLock)return u._queue.push({event:"stop",action:function(){u.stop(s)}}),u;for(var h=u._getSoundIds(s),m=0;m<h.length;m++){u._clearTimer(h[m]);var p=u._soundById(h[m]);p&&(p._seek=p._start||0,p._rateSeek=0,p._paused=!0,p._ended=!0,u._stopFade(h[m]),p._node&&(u._webAudio?p._node.bufferSource&&(typeof p._node.bufferSource.stop>"u"?p._node.bufferSource.noteOff(0):p._node.bufferSource.stop(0),u._cleanBuffer(p._node)):(!isNaN(p._node.duration)||p._node.duration===1/0)&&(p._node.currentTime=p._start||0,p._node.pause(),p._node.duration===1/0&&u._clearSound(p._node))),a||u._emit("stop",p._id))}return u},mute:function(s,a){var u=this;if(u._state!=="loaded"||u._playLock)return u._queue.push({event:"mute",action:function(){u.mute(s,a)}}),u;if(typeof a>"u")if(typeof s=="boolean")u._muted=s;else return u._muted;for(var h=u._getSoundIds(a),m=0;m<h.length;m++){var p=u._soundById(h[m]);p&&(p._muted=s,p._interval&&u._stopFade(p._id),u._webAudio&&p._node?p._node.gain.setValueAtTime(s?0:p._volume,t.ctx.currentTime):p._node&&(p._node.muted=t._muted?!0:s),u._emit("mute",p._id))}return u},volume:function(){var s=this,a=arguments,u,h;if(a.length===0)return s._volume;if(a.length===1||a.length===2&&typeof a[1]>"u"){var m=s._getSoundIds(),p=m.indexOf(a[0]);p>=0?h=parseInt(a[0],10):u=parseFloat(a[0])}else a.length>=2&&(u=parseFloat(a[0]),h=parseInt(a[1],10));var d;if(typeof u<"u"&&u>=0&&u<=1){if(s._state!=="loaded"||s._playLock)return s._queue.push({event:"volume",action:function(){s.volume.apply(s,a)}}),s;typeof h>"u"&&(s._volume=u),h=s._getSoundIds(h);for(var R=0;R<h.length;R++)d=s._soundById(h[R]),d&&(d._volume=u,a[2]||s._stopFade(h[R]),s._webAudio&&d._node&&!d._muted?d._node.gain.setValueAtTime(u,t.ctx.currentTime):d._node&&!d._muted&&(d._node.volume=u*t.volume()),s._emit("volume",d._id))}else return d=h?s._soundById(h):s._sounds[0],d?d._volume:0;return s},fade:function(s,a,u,h){var m=this;if(m._state!=="loaded"||m._playLock)return m._queue.push({event:"fade",action:function(){m.fade(s,a,u,h)}}),m;s=Math.min(Math.max(0,parseFloat(s)),1),a=Math.min(Math.max(0,parseFloat(a)),1),u=parseFloat(u),m.volume(s,h);for(var p=m._getSoundIds(h),d=0;d<p.length;d++){var R=m._soundById(p[d]);if(R){if(h||m._stopFade(p[d]),m._webAudio&&!R._muted){var E=t.ctx.currentTime,v=E+u/1e3;R._volume=s,R._node.gain.setValueAtTime(s,E),R._node.gain.linearRampToValueAtTime(a,v)}m._startFadeInterval(R,s,a,u,p[d],typeof h>"u")}}return m},_startFadeInterval:function(s,a,u,h,m,p){var d=this,R=a,E=u-a,v=Math.abs(E/.01),w=Math.max(4,v>0?h/v:h),y=Date.now();s._fadeTo=u,s._interval=setInterval(function(){var b=(Date.now()-y)/h;y=Date.now(),R+=E*b,R=Math.round(R*100)/100,E<0?R=Math.max(u,R):R=Math.min(u,R),d._webAudio?s._volume=R:d.volume(R,s._id,!0),p&&(d._volume=R),(u<a&&R<=u||u>a&&R>=u)&&(clearInterval(s._interval),s._interval=null,s._fadeTo=null,d.volume(u,s._id),d._emit("fade",s._id))},w)},_stopFade:function(s){var a=this,u=a._soundById(s);return u&&u._interval&&(a._webAudio&&u._node.gain.cancelScheduledValues(t.ctx.currentTime),clearInterval(u._interval),u._interval=null,a.volume(u._fadeTo,s),u._fadeTo=null,a._emit("fade",s)),a},loop:function(){var s=this,a=arguments,u,h,m;if(a.length===0)return s._loop;if(a.length===1)if(typeof a[0]=="boolean")u=a[0],s._loop=u;else return m=s._soundById(parseInt(a[0],10)),m?m._loop:!1;else a.length===2&&(u=a[0],h=parseInt(a[1],10));for(var p=s._getSoundIds(h),d=0;d<p.length;d++)m=s._soundById(p[d]),m&&(m._loop=u,s._webAudio&&m._node&&m._node.bufferSource&&(m._node.bufferSource.loop=u,u&&(m._node.bufferSource.loopStart=m._start||0,m._node.bufferSource.loopEnd=m._stop,s.playing(p[d])&&(s.pause(p[d],!0),s.play(p[d],!0)))));return s},rate:function(){var s=this,a=arguments,u,h;if(a.length===0)h=s._sounds[0]._id;else if(a.length===1){var m=s._getSoundIds(),p=m.indexOf(a[0]);p>=0?h=parseInt(a[0],10):u=parseFloat(a[0])}else a.length===2&&(u=parseFloat(a[0]),h=parseInt(a[1],10));var d;if(typeof u=="number"){if(s._state!=="loaded"||s._playLock)return s._queue.push({event:"rate",action:function(){s.rate.apply(s,a)}}),s;typeof h>"u"&&(s._rate=u),h=s._getSoundIds(h);for(var R=0;R<h.length;R++)if(d=s._soundById(h[R]),d){s.playing(h[R])&&(d._rateSeek=s.seek(h[R]),d._playStart=s._webAudio?t.ctx.currentTime:d._playStart),d._rate=u,s._webAudio&&d._node&&d._node.bufferSource?d._node.bufferSource.playbackRate.setValueAtTime(u,t.ctx.currentTime):d._node&&(d._node.playbackRate=u);var E=s.seek(h[R]),v=(s._sprite[d._sprite][0]+s._sprite[d._sprite][1])/1e3-E,w=v*1e3/Math.abs(d._rate);(s._endTimers[h[R]]||!d._paused)&&(s._clearTimer(h[R]),s._endTimers[h[R]]=setTimeout(s._ended.bind(s,d),w)),s._emit("rate",d._id)}}else return d=s._soundById(h),d?d._rate:s._rate;return s},seek:function(){var s=this,a=arguments,u,h;if(a.length===0)s._sounds.length&&(h=s._sounds[0]._id);else if(a.length===1){var m=s._getSoundIds(),p=m.indexOf(a[0]);p>=0?h=parseInt(a[0],10):s._sounds.length&&(h=s._sounds[0]._id,u=parseFloat(a[0]))}else a.length===2&&(u=parseFloat(a[0]),h=parseInt(a[1],10));if(typeof h>"u")return 0;if(typeof u=="number"&&(s._state!=="loaded"||s._playLock))return s._queue.push({event:"seek",action:function(){s.seek.apply(s,a)}}),s;var d=s._soundById(h);if(d)if(typeof u=="number"&&u>=0){var R=s.playing(h);R&&s.pause(h,!0),d._seek=u,d._ended=!1,s._clearTimer(h),!s._webAudio&&d._node&&!isNaN(d._node.duration)&&(d._node.currentTime=u);var E=function(){R&&s.play(h,!0),s._emit("seek",h)};if(R&&!s._webAudio){var v=function(){s._playLock?setTimeout(v,0):E()};setTimeout(v,0)}else E()}else if(s._webAudio){var w=s.playing(h)?t.ctx.currentTime-d._playStart:0,y=d._rateSeek?d._rateSeek-d._seek:0;return d._seek+(y+w*Math.abs(d._rate))}else return d._node.currentTime;return s},playing:function(s){var a=this;if(typeof s=="number"){var u=a._soundById(s);return u?!u._paused:!1}for(var h=0;h<a._sounds.length;h++)if(!a._sounds[h]._paused)return!0;return!1},duration:function(s){var a=this,u=a._duration,h=a._soundById(s);return h&&(u=a._sprite[h._sprite][1]/1e3),u},state:function(){return this._state},unload:function(){for(var s=this,a=s._sounds,u=0;u<a.length;u++)a[u]._paused||s.stop(a[u]._id),s._webAudio||(s._clearSound(a[u]._node),a[u]._node.removeEventListener("error",a[u]._errorFn,!1),a[u]._node.removeEventListener(t._canPlayEvent,a[u]._loadFn,!1),a[u]._node.removeEventListener("ended",a[u]._endFn,!1),t._releaseHtml5Audio(a[u]._node)),delete a[u]._node,s._clearTimer(a[u]._id);var h=t._howls.indexOf(s);h>=0&&t._howls.splice(h,1);var m=!0;for(u=0;u<t._howls.length;u++)if(t._howls[u]._src===s._src||s._src.indexOf(t._howls[u]._src)>=0){m=!1;break}return A&&m&&delete A[s._src],t.noAudio=!1,s._state="unloaded",s._sounds=[],s=null,null},on:function(s,a,u,h){var m=this,p=m["_on"+s];return typeof a=="function"&&p.push(h?{id:u,fn:a,once:h}:{id:u,fn:a}),m},off:function(s,a,u){var h=this,m=h["_on"+s],p=0;if(typeof a=="number"&&(u=a,a=null),a||u)for(p=0;p<m.length;p++){var d=u===m[p].id;if(a===m[p].fn&&d||!a&&d){m.splice(p,1);break}}else if(s)h["_on"+s]=[];else{var R=Object.keys(h);for(p=0;p<R.length;p++)R[p].indexOf("_on")===0&&Array.isArray(h[R[p]])&&(h[R[p]]=[])}return h},once:function(s,a,u){var h=this;return h.on(s,a,u,1),h},_emit:function(s,a,u){for(var h=this,m=h["_on"+s],p=m.length-1;p>=0;p--)(!m[p].id||m[p].id===a||s==="load")&&(setTimeout((function(d){d.call(this,a,u)}).bind(h,m[p].fn),0),m[p].once&&h.off(s,m[p].fn,m[p].id));return h._loadQueue(s),h},_loadQueue:function(s){var a=this;if(a._queue.length>0){var u=a._queue[0];u.event===s&&(a._queue.shift(),a._loadQueue()),s||u.action()}return a},_ended:function(s){var a=this,u=s._sprite;if(!a._webAudio&&s._node&&!s._node.paused&&!s._node.ended&&s._node.currentTime<s._stop)return setTimeout(a._ended.bind(a,s),100),a;var h=!!(s._loop||a._sprite[u][2]);if(a._emit("end",s._id),!a._webAudio&&h&&a.stop(s._id,!0).play(s._id),a._webAudio&&h){a._emit("play",s._id),s._seek=s._start||0,s._rateSeek=0,s._playStart=t.ctx.currentTime;var m=(s._stop-s._start)*1e3/Math.abs(s._rate);a._endTimers[s._id]=setTimeout(a._ended.bind(a,s),m)}return a._webAudio&&!h&&(s._paused=!0,s._ended=!0,s._seek=s._start||0,s._rateSeek=0,a._clearTimer(s._id),a._cleanBuffer(s._node),t._autoSuspend()),!a._webAudio&&!h&&a.stop(s._id,!0),a},_clearTimer:function(s){var a=this;if(a._endTimers[s]){if(typeof a._endTimers[s]!="function")clearTimeout(a._endTimers[s]);else{var u=a._soundById(s);u&&u._node&&u._node.removeEventListener("ended",a._endTimers[s],!1)}delete a._endTimers[s]}return a},_soundById:function(s){for(var a=this,u=0;u<a._sounds.length;u++)if(s===a._sounds[u]._id)return a._sounds[u];return null},_inactiveSound:function(){var s=this;s._drain();for(var a=0;a<s._sounds.length;a++)if(s._sounds[a]._ended)return s._sounds[a].reset();return new r(s)},_drain:function(){var s=this,a=s._pool,u=0,h=0;if(!(s._sounds.length<a)){for(h=0;h<s._sounds.length;h++)s._sounds[h]._ended&&u++;for(h=s._sounds.length-1;h>=0;h--){if(u<=a)return;s._sounds[h]._ended&&(s._webAudio&&s._sounds[h]._node&&s._sounds[h]._node.disconnect(0),s._sounds.splice(h,1),u--)}}},_getSoundIds:function(s){var a=this;if(typeof s>"u"){for(var u=[],h=0;h<a._sounds.length;h++)u.push(a._sounds[h]._id);return u}else return[s]},_refreshBuffer:function(s){var a=this;return s._node.bufferSource=t.ctx.createBufferSource(),s._node.bufferSource.buffer=A[a._src],s._panner?s._node.bufferSource.connect(s._panner):s._node.bufferSource.connect(s._node),s._node.bufferSource.loop=s._loop,s._loop&&(s._node.bufferSource.loopStart=s._start||0,s._node.bufferSource.loopEnd=s._stop||0),s._node.bufferSource.playbackRate.setValueAtTime(s._rate,t.ctx.currentTime),a},_cleanBuffer:function(s){var a=this,u=t._navigator&&t._navigator.vendor.indexOf("Apple")>=0;if(!s.bufferSource)return a;if(t._scratchBuffer&&s.bufferSource&&(s.bufferSource.onended=null,s.bufferSource.disconnect(0),u))try{s.bufferSource.buffer=t._scratchBuffer}catch{}return s.bufferSource=null,a},_clearSound:function(s){var a=/MSIE |Trident\//.test(t._navigator&&t._navigator.userAgent);a||(s.src="data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA")}};var r=function(s){this._parent=s,this.init()};r.prototype={init:function(){var s=this,a=s._parent;return s._muted=a._muted,s._loop=a._loop,s._volume=a._volume,s._rate=a._rate,s._seek=0,s._paused=!0,s._ended=!0,s._sprite="__default",s._id=++t._counter,a._sounds.push(s),s.create(),s},create:function(){var s=this,a=s._parent,u=t._muted||s._muted||s._parent._muted?0:s._volume;return a._webAudio?(s._node=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),s._node.gain.setValueAtTime(u,t.ctx.currentTime),s._node.paused=!0,s._node.connect(t.masterGain)):t.noAudio||(s._node=t._obtainHtml5Audio(),s._errorFn=s._errorListener.bind(s),s._node.addEventListener("error",s._errorFn,!1),s._loadFn=s._loadListener.bind(s),s._node.addEventListener(t._canPlayEvent,s._loadFn,!1),s._endFn=s._endListener.bind(s),s._node.addEventListener("ended",s._endFn,!1),s._node.src=a._src,s._node.preload=a._preload===!0?"auto":a._preload,s._node.volume=u*t.volume(),s._node.load()),s},reset:function(){var s=this,a=s._parent;return s._muted=a._muted,s._loop=a._loop,s._volume=a._volume,s._rate=a._rate,s._seek=0,s._rateSeek=0,s._paused=!0,s._ended=!0,s._sprite="__default",s._id=++t._counter,s},_errorListener:function(){var s=this;s._parent._emit("loaderror",s._id,s._node.error?s._node.error.code:0),s._node.removeEventListener("error",s._errorFn,!1)},_loadListener:function(){var s=this,a=s._parent;a._duration=Math.ceil(s._node.duration*10)/10,Object.keys(a._sprite).length===0&&(a._sprite={__default:[0,a._duration*1e3]}),a._state!=="loaded"&&(a._state="loaded",a._emit("load"),a._loadQueue()),s._node.removeEventListener(t._canPlayEvent,s._loadFn,!1)},_endListener:function(){var s=this,a=s._parent;a._duration===1/0&&(a._duration=Math.ceil(s._node.duration*10)/10,a._sprite.__default[1]===1/0&&(a._sprite.__default[1]=a._duration*1e3),a._ended(s)),s._node.removeEventListener("ended",s._endFn,!1)}};var A={},o=function(s){var a=s._src;if(A[a]){s._duration=A[a].duration,c(s);return}if(/^data:[^;]+;base64,/.test(a)){for(var u=atob(a.split(",")[1]),h=new Uint8Array(u.length),m=0;m<u.length;++m)h[m]=u.charCodeAt(m);f(h.buffer,s)}else{var p=new XMLHttpRequest;p.open(s._xhr.method,a,!0),p.withCredentials=s._xhr.withCredentials,p.responseType="arraybuffer",s._xhr.headers&&Object.keys(s._xhr.headers).forEach(function(d){p.setRequestHeader(d,s._xhr.headers[d])}),p.onload=function(){var d=(p.status+"")[0];if(d!=="0"&&d!=="2"&&d!=="3"){s._emit("loaderror",null,"Failed loading audio file with status: "+p.status+".");return}f(p.response,s)},p.onerror=function(){s._webAudio&&(s._html5=!0,s._webAudio=!1,s._sounds=[],delete A[a],s.load())},l(p)}},l=function(s){try{s.send()}catch{s.onerror()}},f=function(s,a){var u=function(){a._emit("loaderror",null,"Decoding audio data failed.")},h=function(m){m&&a._sounds.length>0?(A[a._src]=m,c(a,m)):u()};typeof Promise<"u"&&t.ctx.decodeAudioData.length===1?t.ctx.decodeAudioData(s).then(h).catch(u):t.ctx.decodeAudioData(s,h,u)},c=function(s,a){a&&!s._duration&&(s._duration=a.duration),Object.keys(s._sprite).length===0&&(s._sprite={__default:[0,s._duration*1e3]}),s._state!=="loaded"&&(s._state="loaded",s._emit("load"),s._loadQueue())},g=function(){if(t.usingWebAudio){try{typeof AudioContext<"u"?t.ctx=new AudioContext:typeof webkitAudioContext<"u"?t.ctx=new webkitAudioContext:t.usingWebAudio=!1}catch{t.usingWebAudio=!1}t.ctx||(t.usingWebAudio=!1);var s=/iP(hone|od|ad)/.test(t._navigator&&t._navigator.platform),a=t._navigator&&t._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),u=a?parseInt(a[1],10):null;if(s&&u&&u<9){var h=/safari/.test(t._navigator&&t._navigator.userAgent.toLowerCase());t._navigator&&!h&&(t.usingWebAudio=!1)}t.usingWebAudio&&(t.masterGain=typeof t.ctx.createGain>"u"?t.ctx.createGainNode():t.ctx.createGain(),t.masterGain.gain.setValueAtTime(t._muted?0:t._volume,t.ctx.currentTime),t.masterGain.connect(t.ctx.destination)),t._setup()}};i.Howler=t,i.Howl=n,typeof Ni<"u"?(Ni.HowlerGlobal=e,Ni.Howler=t,Ni.Howl=n,Ni.Sound=r):typeof window<"u"&&(window.HowlerGlobal=e,window.Howler=t,window.Howl=n,window.Sound=r)})();/*!
 *  Spatial Plugin - Adds support for stereo and 3D audio where Web Audio is supported.
 *  
 *  howler.js v2.2.4
 *  howlerjs.com
 *
 *  (c) 2013-2020, James Simpson of GoldFire Studios
 *  goldfirestudios.com
 *
 *  MIT License
 */(function(){HowlerGlobal.prototype._pos=[0,0,0],HowlerGlobal.prototype._orientation=[0,0,-1,0,1,0],HowlerGlobal.prototype.stereo=function(t){var n=this;if(!n.ctx||!n.ctx.listener)return n;for(var r=n._howls.length-1;r>=0;r--)n._howls[r].stereo(t);return n},HowlerGlobal.prototype.pos=function(t,n,r){var A=this;if(!A.ctx||!A.ctx.listener)return A;if(n=typeof n!="number"?A._pos[1]:n,r=typeof r!="number"?A._pos[2]:r,typeof t=="number")A._pos=[t,n,r],typeof A.ctx.listener.positionX<"u"?(A.ctx.listener.positionX.setTargetAtTime(A._pos[0],Howler.ctx.currentTime,.1),A.ctx.listener.positionY.setTargetAtTime(A._pos[1],Howler.ctx.currentTime,.1),A.ctx.listener.positionZ.setTargetAtTime(A._pos[2],Howler.ctx.currentTime,.1)):A.ctx.listener.setPosition(A._pos[0],A._pos[1],A._pos[2]);else return A._pos;return A},HowlerGlobal.prototype.orientation=function(t,n,r,A,o,l){var f=this;if(!f.ctx||!f.ctx.listener)return f;var c=f._orientation;if(n=typeof n!="number"?c[1]:n,r=typeof r!="number"?c[2]:r,A=typeof A!="number"?c[3]:A,o=typeof o!="number"?c[4]:o,l=typeof l!="number"?c[5]:l,typeof t=="number")f._orientation=[t,n,r,A,o,l],typeof f.ctx.listener.forwardX<"u"?(f.ctx.listener.forwardX.setTargetAtTime(t,Howler.ctx.currentTime,.1),f.ctx.listener.forwardY.setTargetAtTime(n,Howler.ctx.currentTime,.1),f.ctx.listener.forwardZ.setTargetAtTime(r,Howler.ctx.currentTime,.1),f.ctx.listener.upX.setTargetAtTime(A,Howler.ctx.currentTime,.1),f.ctx.listener.upY.setTargetAtTime(o,Howler.ctx.currentTime,.1),f.ctx.listener.upZ.setTargetAtTime(l,Howler.ctx.currentTime,.1)):f.ctx.listener.setOrientation(t,n,r,A,o,l);else return c;return f},Howl.prototype.init=(function(t){return function(n){var r=this;return r._orientation=n.orientation||[1,0,0],r._stereo=n.stereo||null,r._pos=n.pos||null,r._pannerAttr={coneInnerAngle:typeof n.coneInnerAngle<"u"?n.coneInnerAngle:360,coneOuterAngle:typeof n.coneOuterAngle<"u"?n.coneOuterAngle:360,coneOuterGain:typeof n.coneOuterGain<"u"?n.coneOuterGain:0,distanceModel:typeof n.distanceModel<"u"?n.distanceModel:"inverse",maxDistance:typeof n.maxDistance<"u"?n.maxDistance:1e4,panningModel:typeof n.panningModel<"u"?n.panningModel:"HRTF",refDistance:typeof n.refDistance<"u"?n.refDistance:1,rolloffFactor:typeof n.rolloffFactor<"u"?n.rolloffFactor:1},r._onstereo=n.onstereo?[{fn:n.onstereo}]:[],r._onpos=n.onpos?[{fn:n.onpos}]:[],r._onorientation=n.onorientation?[{fn:n.onorientation}]:[],t.call(this,n)}})(Howl.prototype.init),Howl.prototype.stereo=function(t,n){var r=this;if(!r._webAudio)return r;if(r._state!=="loaded")return r._queue.push({event:"stereo",action:function(){r.stereo(t,n)}}),r;var A=typeof Howler.ctx.createStereoPanner>"u"?"spatial":"stereo";if(typeof n>"u")if(typeof t=="number")r._stereo=t,r._pos=[t,0,0];else return r._stereo;for(var o=r._getSoundIds(n),l=0;l<o.length;l++){var f=r._soundById(o[l]);if(f)if(typeof t=="number")f._stereo=t,f._pos=[t,0,0],f._node&&(f._pannerAttr.panningModel="equalpower",(!f._panner||!f._panner.pan)&&e(f,A),A==="spatial"?typeof f._panner.positionX<"u"?(f._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),f._panner.positionY.setValueAtTime(0,Howler.ctx.currentTime),f._panner.positionZ.setValueAtTime(0,Howler.ctx.currentTime)):f._panner.setPosition(t,0,0):f._panner.pan.setValueAtTime(t,Howler.ctx.currentTime)),r._emit("stereo",f._id);else return f._stereo}return r},Howl.prototype.pos=function(t,n,r,A){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"pos",action:function(){o.pos(t,n,r,A)}}),o;if(n=typeof n!="number"?0:n,r=typeof r!="number"?-.5:r,typeof A>"u")if(typeof t=="number")o._pos=[t,n,r];else return o._pos;for(var l=o._getSoundIds(A),f=0;f<l.length;f++){var c=o._soundById(l[f]);if(c)if(typeof t=="number")c._pos=[t,n,r],c._node&&((!c._panner||c._panner.pan)&&e(c,"spatial"),typeof c._panner.positionX<"u"?(c._panner.positionX.setValueAtTime(t,Howler.ctx.currentTime),c._panner.positionY.setValueAtTime(n,Howler.ctx.currentTime),c._panner.positionZ.setValueAtTime(r,Howler.ctx.currentTime)):c._panner.setPosition(t,n,r)),o._emit("pos",c._id);else return c._pos}return o},Howl.prototype.orientation=function(t,n,r,A){var o=this;if(!o._webAudio)return o;if(o._state!=="loaded")return o._queue.push({event:"orientation",action:function(){o.orientation(t,n,r,A)}}),o;if(n=typeof n!="number"?o._orientation[1]:n,r=typeof r!="number"?o._orientation[2]:r,typeof A>"u")if(typeof t=="number")o._orientation=[t,n,r];else return o._orientation;for(var l=o._getSoundIds(A),f=0;f<l.length;f++){var c=o._soundById(l[f]);if(c)if(typeof t=="number")c._orientation=[t,n,r],c._node&&(c._panner||(c._pos||(c._pos=o._pos||[0,0,-.5]),e(c,"spatial")),typeof c._panner.orientationX<"u"?(c._panner.orientationX.setValueAtTime(t,Howler.ctx.currentTime),c._panner.orientationY.setValueAtTime(n,Howler.ctx.currentTime),c._panner.orientationZ.setValueAtTime(r,Howler.ctx.currentTime)):c._panner.setOrientation(t,n,r)),o._emit("orientation",c._id);else return c._orientation}return o},Howl.prototype.pannerAttr=function(){var t=this,n=arguments,r,A,o;if(!t._webAudio)return t;if(n.length===0)return t._pannerAttr;if(n.length===1)if(typeof n[0]=="object")r=n[0],typeof A>"u"&&(r.pannerAttr||(r.pannerAttr={coneInnerAngle:r.coneInnerAngle,coneOuterAngle:r.coneOuterAngle,coneOuterGain:r.coneOuterGain,distanceModel:r.distanceModel,maxDistance:r.maxDistance,refDistance:r.refDistance,rolloffFactor:r.rolloffFactor,panningModel:r.panningModel}),t._pannerAttr={coneInnerAngle:typeof r.pannerAttr.coneInnerAngle<"u"?r.pannerAttr.coneInnerAngle:t._coneInnerAngle,coneOuterAngle:typeof r.pannerAttr.coneOuterAngle<"u"?r.pannerAttr.coneOuterAngle:t._coneOuterAngle,coneOuterGain:typeof r.pannerAttr.coneOuterGain<"u"?r.pannerAttr.coneOuterGain:t._coneOuterGain,distanceModel:typeof r.pannerAttr.distanceModel<"u"?r.pannerAttr.distanceModel:t._distanceModel,maxDistance:typeof r.pannerAttr.maxDistance<"u"?r.pannerAttr.maxDistance:t._maxDistance,refDistance:typeof r.pannerAttr.refDistance<"u"?r.pannerAttr.refDistance:t._refDistance,rolloffFactor:typeof r.pannerAttr.rolloffFactor<"u"?r.pannerAttr.rolloffFactor:t._rolloffFactor,panningModel:typeof r.pannerAttr.panningModel<"u"?r.pannerAttr.panningModel:t._panningModel});else return o=t._soundById(parseInt(n[0],10)),o?o._pannerAttr:t._pannerAttr;else n.length===2&&(r=n[0],A=parseInt(n[1],10));for(var l=t._getSoundIds(A),f=0;f<l.length;f++)if(o=t._soundById(l[f]),o){var c=o._pannerAttr;c={coneInnerAngle:typeof r.coneInnerAngle<"u"?r.coneInnerAngle:c.coneInnerAngle,coneOuterAngle:typeof r.coneOuterAngle<"u"?r.coneOuterAngle:c.coneOuterAngle,coneOuterGain:typeof r.coneOuterGain<"u"?r.coneOuterGain:c.coneOuterGain,distanceModel:typeof r.distanceModel<"u"?r.distanceModel:c.distanceModel,maxDistance:typeof r.maxDistance<"u"?r.maxDistance:c.maxDistance,refDistance:typeof r.refDistance<"u"?r.refDistance:c.refDistance,rolloffFactor:typeof r.rolloffFactor<"u"?r.rolloffFactor:c.rolloffFactor,panningModel:typeof r.panningModel<"u"?r.panningModel:c.panningModel};var g=o._panner;g||(o._pos||(o._pos=t._pos||[0,0,-.5]),e(o,"spatial"),g=o._panner),g.coneInnerAngle=c.coneInnerAngle,g.coneOuterAngle=c.coneOuterAngle,g.coneOuterGain=c.coneOuterGain,g.distanceModel=c.distanceModel,g.maxDistance=c.maxDistance,g.refDistance=c.refDistance,g.rolloffFactor=c.rolloffFactor,g.panningModel=c.panningModel}return t},Sound.prototype.init=(function(t){return function(){var n=this,r=n._parent;n._orientation=r._orientation,n._stereo=r._stereo,n._pos=r._pos,n._pannerAttr=r._pannerAttr,t.call(this),n._stereo?r.stereo(n._stereo):n._pos&&r.pos(n._pos[0],n._pos[1],n._pos[2],n._id)}})(Sound.prototype.init),Sound.prototype.reset=(function(t){return function(){var n=this,r=n._parent;return n._orientation=r._orientation,n._stereo=r._stereo,n._pos=r._pos,n._pannerAttr=r._pannerAttr,n._stereo?r.stereo(n._stereo):n._pos?r.pos(n._pos[0],n._pos[1],n._pos[2],n._id):n._panner&&(n._panner.disconnect(0),n._panner=void 0,r._refreshBuffer(n)),t.call(this)}})(Sound.prototype.reset);var e=function(t,n){n=n||"spatial",n==="spatial"?(t._panner=Howler.ctx.createPanner(),t._panner.coneInnerAngle=t._pannerAttr.coneInnerAngle,t._panner.coneOuterAngle=t._pannerAttr.coneOuterAngle,t._panner.coneOuterGain=t._pannerAttr.coneOuterGain,t._panner.distanceModel=t._pannerAttr.distanceModel,t._panner.maxDistance=t._pannerAttr.maxDistance,t._panner.refDistance=t._pannerAttr.refDistance,t._panner.rolloffFactor=t._pannerAttr.rolloffFactor,t._panner.panningModel=t._pannerAttr.panningModel,typeof t._panner.positionX<"u"?(t._panner.positionX.setValueAtTime(t._pos[0],Howler.ctx.currentTime),t._panner.positionY.setValueAtTime(t._pos[1],Howler.ctx.currentTime),t._panner.positionZ.setValueAtTime(t._pos[2],Howler.ctx.currentTime)):t._panner.setPosition(t._pos[0],t._pos[1],t._pos[2]),typeof t._panner.orientationX<"u"?(t._panner.orientationX.setValueAtTime(t._orientation[0],Howler.ctx.currentTime),t._panner.orientationY.setValueAtTime(t._orientation[1],Howler.ctx.currentTime),t._panner.orientationZ.setValueAtTime(t._orientation[2],Howler.ctx.currentTime)):t._panner.setOrientation(t._orientation[0],t._orientation[1],t._orientation[2])):(t._panner=Howler.ctx.createStereoPanner(),t._panner.pan.setValueAtTime(t._stereo,Howler.ctx.currentTime)),t._panner.connect(t._node),t._paused||t._parent.pause(t._id,!0).play(t._id,!0)}})()})(mA)),mA}var nu=tu();const iu=new Map;function ru(i,e){iu.set(i,e)}const Au=["click_002.ogg","impactGeneric_light_002.ogg","floraphonic-punch-6-166699.ogg","floraphonic-cartoon-slap-1-189830.ogg","universfield-whip-06-487886.ogg","dragon-studio-simple-whoosh-382724.ogg","floraphonic-baby-squeak-toy-2-183912.ogg","floraphonic-happy-pop-2-185287.ogg","floraphonic-90s-game-ui-3-185096.ogg","ikoliks_aj-elevator-elevator-music-342629.ogg","alex-morgan-organ-jazz-rainy-night-music-564284.ogg","surprising_media-sax-organ-jazz-400-303939.ogg","floraphonic-you-win-sequence-2-183949.ogg"],ss=new Map;function tr(i){return ss.get(i)}ru("sound-effects",Nl);async function Nl(){Au.map(async i=>{ss.set(i,new nu.Howl({src:[`sounds/${i}`],format:["ogg"]}))}),await Promise.all(Object.values(ss).map(i=>new Promise((e,t)=>{const n=i;n.once("load",e),n.once("loaderror",()=>{t()})})))}const su={buttonClick:{url:"floraphonic-happy-pop-2-185287.ogg",volume:.1},whoosh:{url:"dragon-studio-simple-whoosh-382724.ogg",volume:.2,skip:0},streakHit:{url:"floraphonic-90s-game-ui-3-185096.ogg",volume:.2,skip:0},powHit:{url:"floraphonic-punch-6-166699.ogg",volume:.3,skip:.2},powHitB:{url:"floraphonic-cartoon-slap-1-189830.ogg",volume:.3,skip:.3},powHitC:{url:"universfield-whip-06-487886.ogg",volume:.1,skip:.3},okHit:{url:"impactGeneric_light_002.ogg",volume:.3},foulHit:{url:"floraphonic-baby-squeak-toy-2-183912.ogg",volume:.3}};function au(...i){const e=Math.floor(Math.random()*i.length);gn(i[e])}function gn(i){const{url:e,volume:t,skip:n=0}=su[i],r=tr(Array.isArray(e)?eu(e):e);r.volume(t),r.seek(n),r.play()}const lr={svgString:`
<svg fill="#000000" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 496.926 496.926" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M227.831,233.153c-17.891,32.025-36.395,65.14-44.667,77.982c-6.072,9.438-28.018,41.875-98.063,142.75 c-5.737-1.33-11.915,1.004-15.673,6.473c-2.228,3.242-3.05,7.145-2.333,11.008c0.717,3.854,2.907,7.199,6.139,9.428l19.699,13.541 c2.467,1.691,5.345,2.592,8.329,2.592h0.01c4.838,0,9.362-2.383,12.431-6.848c3.471-5.049,3.347-11.59,0.115-16.467 c13.091-19.258,83.299-122.496,98.13-142.711c9.018-12.316,33.287-41.424,56.744-69.566 c19.298-23.151,37.514-45.021,46.244-56.314c19.106-24.729,50.213-66.909,50.624-67.454l58.379-84.943 c11.839-17.222,3.979-30.208-2.036-34.817L400.052,2.792C399.583,2.505,395.299,0,389.188,0c-5.871,0-14.487,2.343-22.156,13.512 L308.558,98.58c-0.277,0.44-28.506,44.6-44.753,71.298C256.375,182.061,242.51,206.875,227.831,233.153z"></path> </g> </g> </g></svg>
`,base:{x:111,y:446},tip:{x:225,y:283},pixelsPerViewBoxUnit:1.5},ou={svgString:`
<svg fill="#000000" viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg">
<g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round">
</g><g id="SVGRepo_iconCarrier"> <title>chain</title> <path d="M0 22.944q0 2.464 1.76 4.224l3.072 3.104q1.76 1.728 4.224 1.728t4.256-1.728l2.688-2.976q1.376-1.344 1.664-3.232t-0.512-3.552l-6.784 6.784q-0.576 0.576-1.408 0.576t-1.44-0.576l-2.816-2.816q-0.576-0.608-0.576-1.408t0.576-1.408l6.784-6.816q-1.632-0.8-3.52-0.512t-3.264 1.664l-2.944 2.72q-1.76 1.76-1.76 4.224zM9.792 20.256q0 0.832 0.576 1.408t1.408 0.576 1.408-0.576l8.48-8.48q0.576-0.576 0.576-1.408t-0.576-1.408q-0.608-0.576-1.44-0.576t-1.408 0.576l-8.448 8.48q-0.576 0.576-0.576 1.408z"></path> </g></svg>
`,base:{x:7,y:25},tip:{x:20,y:12},pixelsPerViewBoxUnit:10},lu={svgString:`
<svg version="1.1" id="Icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 32 32" xml:space="preserve">
<style type="text/css">
	.st0{fill:none;stroke:#000000;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}
</style>
<g>
	<path d="M25.9,6.1C23.4,8.9,22,12.3,22,16c0,3.7,1.4,7.1,3.9,9.9c2.6-2.5,4.1-6,4.1-9.9C30,12.1,28.4,8.6,25.9,6.1z"/>
	<path d="M20,16c0-4.2,1.5-8.1,4.3-11.2C22,3,19.1,2,16,2c-3.1,0-6,1-8.3,2.8C10.5,7.9,12,11.8,12,16c0,4.2-1.5,8.1-4.3,11.2
		C10,29,12.9,30,16,30c3.1,0,6-1,8.3-2.8C21.5,24.1,20,20.2,20,16z"/>
	<path d="M6.1,25.9C8.6,23.1,10,19.7,10,16c0-3.7-1.4-7.1-3.9-9.9C3.6,8.6,2,12.1,2,16C2,19.9,3.6,23.4,6.1,25.9z"/>
</g>
</svg>
`,base:{x:16,y:16},tip:{x:24,y:16},pixelsPerViewBoxUnit:10},Xa={svgString:`
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M5.51971 11.6679C5.38628 12.0125 4.9682 12.1706 4.61602 12.0587C4.26384 11.9468 4.07911 11.593 4.17097 11.2351L4.30609 10.7086C4.41418 10.2874 4.80736 10.021 5.22175 10.1526C5.63614 10.2843 5.87297 10.7555 5.71598 11.161L5.51971 11.6679Z" fill="#0F0F0F"></path> <path d="M8.01677 12.9936C7.80606 13.2969 7.37725 13.3614 7.06167 13.1697C6.74609 12.9779 6.63437 12.5827 6.80738 12.2565L7.06187 11.7766C7.26583 11.392 7.72803 11.2343 8.10009 11.4604C8.47215 11.6864 8.57514 12.1901 8.32672 12.5476L8.01677 12.9936Z" fill="#0F0F0F"></path> <path d="M9.17133 14.8286C8.90951 14.5668 8.88327 14.1441 9.12924 13.8673L9.48892 13.4626C9.77806 13.1372 10.2777 13.1066 10.5855 13.4144C10.8933 13.7222 10.8627 14.2218 10.5373 14.511L10.1326 14.8707C9.85584 15.1166 9.43315 15.0904 9.17133 14.8286Z" fill="#0F0F0F"></path> <path d="M11.7434 17.1925C11.4172 17.3655 11.022 17.2538 10.8302 16.9382C10.6385 16.6227 10.7031 16.1939 11.0063 15.9831L11.4523 15.6732C11.8098 15.4248 12.3135 15.5278 12.5395 15.8998C12.7656 16.2719 12.6079 16.7341 12.2233 16.938L11.7434 17.1925Z" fill="#0F0F0F"></path> <path d="M12.7648 19.8289C12.4069 19.9208 12.0531 19.7361 11.9412 19.3839C11.8293 19.0317 11.9874 18.6136 12.332 18.4802L12.839 18.2839C13.2444 18.1269 13.7156 18.3638 13.8473 18.7782C13.979 19.1926 13.7125 19.5857 13.2913 19.6938L12.7648 19.8289Z" fill="#0F0F0F"></path> <path d="M19.829 12.7649C19.9209 12.407 19.7362 12.0532 19.384 11.9413C19.0318 11.8294 18.6137 11.9875 18.4803 12.3321L18.284 12.839C18.127 13.2445 18.3639 13.7157 18.7782 13.8474C19.1926 13.979 19.5858 13.7126 19.6939 13.2914L19.829 12.7649Z" fill="#0F0F0F"></path> <path d="M17.1926 11.7435C17.3656 11.4173 17.2539 11.0221 16.9383 10.8303C16.6228 10.6386 16.1939 10.7031 15.9832 11.0064L15.6733 11.4524C15.4249 11.8099 15.5279 12.3136 15.8999 12.5396C16.272 12.7657 16.7342 12.608 16.9381 12.2234L17.1926 11.7435Z" fill="#0F0F0F"></path> <path d="M14.8708 10.1327C15.1167 9.85592 15.0905 9.43324 14.8287 9.17142C14.5668 8.9096 14.1442 8.88336 13.8674 9.12932L13.4627 9.489C13.1373 9.77815 13.1067 10.2778 13.4145 10.5856C13.7223 10.8934 14.2219 10.8628 14.5111 10.5374L14.8708 10.1327Z" fill="#0F0F0F"></path> <path d="M12.9937 8.01685C13.2969 7.80615 13.3615 7.37733 13.1698 7.06175C12.978 6.74618 12.5828 6.63446 12.2566 6.80746L11.7767 7.06195C11.3921 7.26592 11.2344 7.72812 11.4605 8.10017C11.6865 8.47223 12.1902 8.57523 12.5477 8.32681L12.9937 8.01685Z" fill="#0F0F0F"></path> <path d="M11.668 5.51979C12.0126 5.38637 12.1707 4.96829 12.0588 4.61611C11.9469 4.26393 11.5931 4.0792 11.2352 4.17106L10.7087 4.30618C10.2875 4.41426 10.021 4.80745 10.1527 5.22184C10.2844 5.63623 10.7556 5.87306 11.161 5.71606L11.668 5.51979Z" fill="#0F0F0F"></path> <path fill-rule="evenodd" clip-rule="evenodd" d="M22.9999 11.9998C22.9999 18.0749 18.075 22.9998 11.9999 22.9998C5.92478 22.9998 0.999908 18.0749 0.999908 11.9998C0.999908 5.92462 5.92478 0.999756 11.9999 0.999756C18.075 0.999756 22.9999 5.92462 22.9999 11.9998ZM3.00674 11.9998C3.00674 16.9665 7.03312 20.9929 11.9999 20.9929C16.9667 20.9929 20.9931 16.9665 20.9931 11.9998C20.9931 7.03297 16.9667 3.00659 11.9999 3.00659C7.03312 3.00659 3.00674 7.03297 3.00674 11.9998Z" fill="#0F0F0F"></path> </g></svg>
`,base:{x:12,y:12},tip:{x:12,y:10},pixelsPerViewBoxUnit:5},cu={svgString:`
  <svg version="1.0" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24" xml:space="preserve" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g id="Guides"> <g id="_x32_0_px_2_"> </g> <g id="_x32_0px"> </g> <g id="_x34_0px"> </g> <g id="_x34_4_px"> </g> <g id="_x34_8px"> <g id="_x31_6px"> </g> <g id="square_4px"> <g id="_x32_8_px"> <g id="square_4px_2_"> </g> <g id="square_4px_3_"> </g> <g id="square_4px_1_"> </g> <g id="_x32_4_px_2_"> </g> <g id="_x31_2_px"> </g> </g> </g> </g> <g id="Icons"> </g> <g id="_x32_0_px"> </g> <g id="square_6px"> <g id="_x31_2_PX"> </g> </g> <g id="_x33_6_px"> <g id="_x33_2_px"> <g id="_x32_8_px_1_"> <g id="square_6px_1_"> </g> <g id="_x32_0_px_1_"> <g id="_x31_2_PX_2_"> </g> <g id="_x34_8_px"> <g id="_x32_4_px"> </g> <g id="_x32_4_px_1_"> </g> </g> </g> </g> </g> </g> <g id="_x32_0_px_3_"> </g> <g id="_x32_0_px_4_"> </g> <g id="New_Symbol_8"> <g id="_x32_4_px_3_"> </g> </g> </g> <g id="Artboard"> </g> <g id="Free_Icons"> <g> <polygon style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" points="6,21.5 0.5,12 6,2.5 18,2.5 23.5,12 18,21.5 "></polygon> <polygon style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" points="23.5,12 16,7.5 6,2.5 5,13.5 6,21.5 16.5,19.5 "></polygon> <polygon style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" points="16,7.5 5,13.5 16.5,19.5 "></polygon> <line style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" x1="18" y1="21.5" x2="16.5" y2="19.5"></line> <line style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" x1="0.5" y1="12" x2="5" y2="13.5"></line> <line style="fill:none;stroke:#000000;stroke-linejoin:round;stroke-miterlimit:10;" x1="18" y1="2.5" x2="16" y2="7.5"></line> </g> </g> </g></svg>
  `,base:{x:12,y:12},tip:{x:12,y:10},pixelsPerViewBoxUnit:5},uu={svgString:`
  

  <svg viewBox="0 -14.61 213.12 213.12" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <defs> <style>.cls-1{fill:#ffffff;}</style> </defs> <g id="Layer_2" data-name="Layer 2"> <g id="Layer_1-2" data-name="Layer 1"> <path d="M61.92,15.94c4.87-5,9.49-9.22,15.35-11.9C84.2.88,91.41-.68,99,.28a34.79,34.79,0,0,1,9,2.4,77.15,77.15,0,0,1,22.32,14.89c13.18-8.54,27.05-8.49,39.81-.9,12.46,7.41,21.49,18.21,20.36,34.46,2.76,1.45,5.23,2.83,7.78,4.06,5.65,2.75,9.57,7.23,12.49,12.61,3.07,5.67,3,11.66.55,17.45-1.59,3.84-2.94,7.45-.86,11.48a3.68,3.68,0,0,1,.39,1.66c-.21,8.61-.81,17.14-4.83,25a29.3,29.3,0,0,1-16.71,14.53c-.15,1.71-.37,3.35-.43,5-.34,8.27-3.43,15.58-7.94,22.36a27,27,0,0,1-19,12.08c-9.19,1.42-18.3,1.12-26.83-3.32l-4.17-2.13a53.1,53.1,0,0,0-4.75,3.31c-8.56,7.39-18.08,10.34-29.43,7.74-8.32-1.91-15.81-5-21.64-11.08-6.23-.37-12.21-.69-18.18-1.07-6.79-.42-12.67-3.36-18.33-6.82-6.27-3.83-9.17-10.07-11.47-16.61a73.71,73.71,0,0,1-4.4-25.79,62.39,62.39,0,0,0-7.34-4,17,17,0,0,1-8.46-7C2.46,103.4-.49,95.69.07,87.06a16.19,16.19,0,0,1,1.45-6.64c3.57-6.48,6.29-13.59,12.2-18.54C16,60,16.27,57.85,15.91,55c-1.72-13.6,4.41-23.95,14.64-31.93a34.57,34.57,0,0,1,25-7.44C57.5,15.82,59.5,15.83,61.92,15.94ZM129,27.07c-1.41-.79-2.66-1.45-3.87-2.18-5.87-3.54-11.55-7.47-17.63-10.6a30.11,30.11,0,0,0-38.34,8.86c-2.86,3.84-5.9,5.16-10.22,4.08a27.4,27.4,0,0,0-13.59.47c-12.07,3.13-20.58,11.42-19,24.56a47.22,47.22,0,0,1,.28,8.57c-.21,3.17-1,6.15-4.48,7.63-5.48,2.36-8.07,7.35-9.77,12.46-3.14,9.47.32,22.36,9.54,27a43.83,43.83,0,0,1,6.68,3.87c2.29,1.71,4.77,3.93,3.92,7.06-1.75,6.49.43,12.54,1.74,18.59a26.5,26.5,0,0,0,11.61,17.34,33.26,33.26,0,0,0,25.41,5c5-1,8.69.12,12,4.21a20.43,20.43,0,0,0,8.16,6c10.88,4.14,21.34,3.83,30.39-4.68.84-.79,1.7-1.54,2.59-2.27,4.73-3.91,6.09-4.05,11.5-1.16,1.26.67,2.45,1.46,3.73,2.1,8.51,4.3,17.16,3.71,25.8.47a17.06,17.06,0,0,0,9.95-10.07c2.39-5.9,4-11.93,3.45-18.39-.33-3.9,1.62-6.55,5-8.23,2-1,4.2-1.81,6.27-2.8,6.8-3.24,10.58-8.62,10.84-16.18.17-4.84.47-9.69-.94-14.49-1-3.31-1.15-6.87.83-10,3.55-5.59,1.51-10.28-2-14.92A33.89,33.89,0,0,0,189.1,61c-5.25-3.25-8.14-7.84-8.32-14.1-.29-9.66-6.29-16.21-13.64-20.63-10.54-6.33-22-7.55-33.44-1.13A40.35,40.35,0,0,1,129,27.07Z"></path> <path class="cls-1" d="M129,27.07a40.35,40.35,0,0,0,4.73-2c11.39-6.42,22.9-5.2,33.44,1.13,7.35,4.42,13.35,11,13.64,20.63.18,6.26,3.07,10.85,8.32,14.1a33.89,33.89,0,0,1,9.74,8.31c3.48,4.64,5.52,9.33,2,14.92-2,3.11-1.81,6.67-.83,10,1.41,4.8,1.11,9.65.94,14.49-.26,7.56-4,12.94-10.84,16.18-2.07,1-4.23,1.77-6.27,2.8-3.35,1.68-5.3,4.33-5,8.23.55,6.46-1.06,12.49-3.45,18.39a17.06,17.06,0,0,1-9.95,10.07c-8.64,3.24-17.29,3.83-25.8-.47-1.28-.64-2.47-1.43-3.73-2.1-5.41-2.89-6.77-2.75-11.5,1.16-.89.73-1.75,1.48-2.59,2.27-9,8.51-19.51,8.82-30.39,4.68a20.43,20.43,0,0,1-8.16-6c-3.33-4.09-7-5.19-12-4.21a33.26,33.26,0,0,1-25.41-5,26.5,26.5,0,0,1-11.61-17.34c-1.31-6-3.49-12.1-1.74-18.59.85-3.13-1.63-5.35-3.92-7.06a43.83,43.83,0,0,0-6.68-3.87c-9.22-4.59-12.68-17.48-9.54-26.95,1.7-5.11,4.29-10.1,9.77-12.46C25.56,67,26.39,64,26.6,60.83a47.22,47.22,0,0,0-.28-8.57c-1.58-13.14,6.93-21.43,19-24.56a27.4,27.4,0,0,1,13.59-.47c4.32,1.08,7.36-.24,10.22-4.08a30.11,30.11,0,0,1,38.34-8.86c6.08,3.13,11.76,7.06,17.63,10.6C126.31,25.62,127.56,26.28,129,27.07Z"></path> </g> </g> </g></svg>
  
  
  
  `,base:{x:106,y:106},tip:{x:106,y:107},pixelsPerViewBoxUnit:5};async function jt(i){var p;const{svgString:e,base:t,tip:n,pixelsPerViewBoxUnit:r=2}=i,A=new DOMParser().parseFromString(e,"image/svg+xml"),o=A.querySelector("parsererror");if(o)throw new Error(`Invalid SVG: ${o.textContent}`);const l=A.documentElement,f=(p=l.getAttribute("viewBox"))==null?void 0:p.trim().split(/[\s,]+/).map(Number);if(!f||f.length!==4||f.some(Number.isNaN))throw new Error("SVG needs a valid viewBox: minX minY width height");const[c,g,s,a]=f;if(t.x<c||t.x>c+s||t.y<g||t.y>g+a||n.x<c||n.x>c+s||n.y<g||n.y>g+a)throw new Error("base and tip must be expressed in SVG viewBox coordinates");l.setAttribute("width",String(s*r)),l.setAttribute("height",String(a*r));const u=new XMLSerializer().serializeToString(A),h=new Blob([u],{type:"image/svg+xml;charset=utf-8"}),m=URL.createObjectURL(h);try{const d=new Image;d.src=m,await d.decode();const R=document.createElement("canvas");R.width=Math.ceil(s*r),R.height=Math.ceil(a*r);const E=R.getContext("2d");if(!E)throw new Error("Could not create 2D canvas context");E.imageSmoothingEnabled=!0,E.drawImage(d,0,0,R.width,R.height);const v=n.x-t.x,w=n.y-t.y;if(v===0&&w===0)throw new Error("base and tip cannot be the same point");const y=Math.atan2(w,v),b={x:(t.x-c)*r,y:(t.y-g)*r},_={x:(n.x-c)*r,y:(n.y-g)*r};return{buffer:R,base:t,tip:n,baseBuffer:b,tipBuffer:_,viewBox:{x:c,y:g,width:s,height:a,pixelsPerViewBoxUnit:r},canonicalAngle:y,draw(x,K,T,B,F=1){x.save(),x.translate(K,T),x.rotate(B-y),x.scale(F,F),x.drawImage(R,-b.x,-b.y),x.restore()}}}finally{URL.revokeObjectURL(m)}}const Ca=class Ca extends $n{constructor(){super(...arguments);Y(this,"physicsSprites",[{get sprite(){return Pn},scale:MA,basePointIndex:0,directionPointIndex:1,directionSign:1,velocityPointIndex:1,massRatio:2}]);Y(this,"label","bat");Y(this,"chargeAnim",0);Y(this,"chargeDuration",1)}simulate(t){super.simulate(t),this.isHeldUpright?(this.chargeAnim+=t/this.chargeDuration,this.chargeAnim=Math.min(this.chargeAnim,1)):this.chargeAnim<.3?(this.chargeAnim-=5*t/this.chargeDuration,this.chargeAnim<=0&&(this.chargeAnim=0,eA())):this.chargeAnim===0||(this.chargeAnim+=t/this.chargeDuration,this.chargeAnim=Math.min(this.chargeAnim,1))}draw(t,n){!n&&this.chargeAnim>0&&fu(Pn,Za,this.chargeAnim);const{points:r,mousex:A,mousey:o}=this,l=1,f=1;if(n)for(let g=0;g<jr;g++){const s=(Vr+g)%yi;t.globalAlpha=Math.pow(g/jr,2)*l,cr.draw(t,kl[s],Ul[s],Pl[s],MA)}else this.chargeAnim>=1;t.globalAlpha=n?f:1,(n?ur:Pn).draw(t,A,o,this.angle,MA),t.globalAlpha=1}};$n.register("bat",{factory:()=>new Ca(2),preload:async()=>{Ll=await jt(lr),Pn=await jt(lr),Za=hu(Pn.buffer),ur=await jt(lr);const{width:t,height:n}=ur.buffer;let r=ur.buffer.getContext("2d");r.globalCompositeOperation="source-atop",r.fillStyle="#aaa",r.fillRect(0,0,t,n),cr=await jt(lr),r=cr.buffer.getContext("2d"),r.save(),r.globalCompositeOperation="source-atop",r.fillStyle="#aaa",r.fillRect(0,0,t,n);const A=cr.baseBuffer;r.fillStyle="black",r.globalCompositeOperation="destination-out";const o=20,l=400;for(let f=0;f<o;f++){const c=l*f/o;r.globalAlpha=1-f/o,r.beginPath(),r.arc(A.x,A.y,c,0,2*Math.PI),r.fill()}r.restore()}});let as=Ca,Ll,Pn,Za,cr,ur;const MA=.5,fr=.3,RA=.6;function eA(){const i=Pn.buffer.getContext("2d"),{width:e,height:t}=Pn.buffer;i.globalCompositeOperation="source-over",i.clearRect(0,0,e,t),i.drawImage(Ll.buffer,0,0)}function fu(i,e,t){const n=i.buffer.getContext("2d"),{width:r,height:A}=i.buffer;if(t<fr){const o=t/fr;n.globalCompositeOperation="source-atop",n.fillStyle="black",n.fillRect(0,0,r,A),n.fillStyle="white";const l=A/20;n.fillRect(0,-l+(A+2*l)*o,r,2*l)}else{const o=(t-fr)/(1-fr),l=Math.floor(o*e.length);dr>l&&(dr=0),n.globalCompositeOperation="source-over";const f=Math.floor(e.length/2);for(let c=dr;c<l;c++){let g;c%1===1?g=f+Math.floor(c/2):g=f-Math.floor(c/2),g=(g%e.length+e.length)%e.length;const s=e[g];n.fillStyle="red",n.fillRect(s.x-3,s.y-3,6,6)}if(dr=l,o>RA){const c=(o-RA)/(1-RA),g=Math.atan2(i.tipBuffer.y-i.baseBuffer.y,i.tipBuffer.x-i.baseBuffer.x);n.globalCompositeOperation="source-atop",n.strokeStyle="white";const s=du.filter(a=>qa<a.anim&&c>=a.anim);for(const a of s){const u=a.distFromBase,h=i.baseBuffer.x+Math.cos(g)*u,m=i.baseBuffer.y+Math.sin(g)*u,p=50,d=g+Math.PI/2,R=Math.cos(d)*p,E=Math.sin(d)*p;n.beginPath(),n.moveTo(h-R,m-E),n.lineTo(h+R,m+E),n.lineWidth=a.lineWidth,n.stroke()}}else qa=0}}let qa=0;const du=[{anim:.1,distFromBase:100,lineWidth:5},{anim:.3,distFromBase:150,lineWidth:10},{anim:.5,distFromBase:250,lineWidth:10},{anim:.7,distFromBase:300,lineWidth:10},{anim:.9,distFromBase:350,lineWidth:10}];let dr=0;const _A=[{x:-1,y:0},{x:-1,y:-1},{x:0,y:-1},{x:1,y:-1},{x:1,y:0},{x:1,y:1},{x:0,y:1},{x:-1,y:1}];function hu(i,{blackThreshold:e=16,alphaThreshold:t=16}={}){const n=i.getContext("2d",{willReadFrequently:!0});if(!n)throw new Error("Could not create a 2D canvas context.");const{width:r,height:A}=i,o=n.getImageData(0,0,r,A),{data:l}=o,f=(d,R,E)=>{if(R<0||R>=r||E<0||E>=A)return!1;const v=(E*r+R)*4;return d[v+3]>t};let c;e:for(let d=0;d<A;d++)for(let R=0;R<r;R++)if(f(l,R,d)&&!f(l,R-1,d)){c={x:R,y:d};break e}if(!c)return[];const g=(d,R)=>d.x===R.x&&d.y===R.y,s=(d,R)=>{const E=R.x-d.x,v=R.y-d.y;return _A.findIndex(w=>w.x===E&&w.y===v)};let a=c,u={x:c.x-1,y:c.y};const h=[c];let m;const p=r*A*8;for(let d=0;d<p;d++){const R=s(a,u);if(R===-1)throw new Error("Invalid contour state.");let E,v;for(let w=1;w<=8;w++){const y=(R+w)%8,b=_A[y],_={x:a.x+b.x,y:a.y+b.y};if(f(l,_.x,_.y)){E=_;const x=_A[(y+7)%8];v={x:a.x+x.x,y:a.y+x.y};break}}if(!E||!v)return h;if(!m)m=E;else if(g(a,c)&&g(E,m))break;h.push(E),a=E,u=v}return h.length>1&&g(h.at(-1),c)&&h.pop(),h}function pu({sprite:i,scale:e,targetRadius:t,cellSize:n,alphaThreshold:r=1}){if(e<=0)throw new Error("scale must be positive");const A=t/e,o=n??Math.max(8,Math.round(A/6)),{buffer:l,baseBuffer:f,tipBuffer:c}=i,g=l.getContext("2d"),s=c.x-f.x,a=c.y-f.y,u=s*s+a*a||1;if(!g)throw new Error("Could not read bat sprite buffer");const h=g.getImageData(0,0,l.width,l.height),m=Ru(h.data,l.width,l.height,r),p=A+o,d=Math.floor((m.minX-f.x-p)/o)*o,R=Math.floor((m.minY-f.y-p)/o)*o,E=Math.ceil((m.maxX-f.x+p)/o)*o,v=Math.ceil((m.maxY-f.y+p)/o)*o,w=Math.max(1,Math.ceil((E-d)/o)),y=Math.max(1,Math.ceil((v-R)/o)),b=new Uint8Array(w*y),_=new Float32Array(w*y),x=new Float32Array(w*y),K=new Float32Array(w*y),T=new Float32Array(w*y),B=new Float32Array(w*y),F=[];for(let H=0;H<y;H++){const O=R+(H+.5)*o;for(let Q=0;Q<w;Q++){const D=d+(Q+.5)*o,j=D+f.x,J=O+f.y,ae=H*w+Q;_[ae]=D,x[ae]=O,B[ae]=(D*s+O*a)/u,_u({alpha:h.data,width:l.width,height:l.height,centerX:j,centerY:J,radius:A,alphaThreshold:r})?b[ae]=1:F.push({x:D,y:O})}}if(F.length===0)throw new Error("Collision grid has no separating cells");for(let H=0;H<y;H++){const O=R+(H+.5)*o;for(let Q=0;Q<w;Q++){const D=d+(Q+.5)*o,j=H*w+Q;if(b[j]!==1)continue;const J=Mu(D,O,F),ae=J.x-D,he=J.y-O,ue=Math.hypot(ae,he)||1;_[j]=J.x,x[j]=J.y,K[j]=ae/ue,T[j]=he/ue}}return mu({hits:b,normalXs:K,normalYs:T,columns:w,rows:y}),{cellSize:o,columns:w,rows:y,minX:d,minY:R,localTargetRadius:A,hits:b,escapeXs:_,escapeYs:x,normalXs:K,normalYs:T,spineRatios:B}}function gu(i,e,t){const n=Math.floor((e-i.minX)/i.cellSize),r=Math.floor((t-i.minY)/i.cellSize);if(n<0||n>=i.columns||r<0||r>=i.rows)return null;const A=r*i.columns+n;return{hit:i.hits[A]===1,centerX:i.minX+(n+.5)*i.cellSize,centerY:i.minY+(r+.5)*i.cellSize,escapeX:i.escapeXs[A],escapeY:i.escapeYs[A],normalX:i.normalXs[A],normalY:i.normalYs[A],spineRatio:i.spineRatios[A]}}function mu({hits:i,normalXs:e,normalYs:t,columns:n,rows:r,iterations:A=2}){const o=new Float32Array(e.length),l=new Float32Array(t.length);for(let f=0;f<A;f++){o.set(e),l.set(t);for(let c=0;c<r;c++)for(let g=0;g<n;g++){const s=c*n+g;if(i[s]!==1)continue;let a=e[s]*2,u=t[s]*2,h=2;for(let p=-1;p<=1;p++)for(let d=-1;d<=1;d++){if(d===0&&p===0)continue;const R=g+d,E=c+p;if(R<0||R>=n||E<0||E>=r)continue;const v=E*n+R;i[v]===1&&(a+=e[v],u+=t[v],h+=1)}if(h===0)continue;const m=Math.hypot(a,u);m!==0&&(o[s]=a/m,l[s]=u/m)}e.set(o),t.set(l)}}function Mu(i,e,t){let n=t[0],r=Number.POSITIVE_INFINITY;for(const A of t){const o=A.x-i,l=A.y-e,f=o*o+l*l;f>=r||(r=f,n=A)}return n}function Ru(i,e,t,n){let r=e,A=t,o=0,l=0,f=!1;for(let c=0;c<t;c++)for(let g=0;g<e;g++)i[(c*e+g)*4+3]<n||(f=!0,r=Math.min(r,g),A=Math.min(A,c),o=Math.max(o,g+1),l=Math.max(l,c+1));if(!f)throw new Error("Bat sprite contains no opaque pixels");return{minX:r,minY:A,maxX:o,maxY:l}}function _u({alpha:i,width:e,height:t,centerX:n,centerY:r,radius:A,alphaThreshold:o}){const l=A*A,f=Math.max(0,Math.floor(n-A)),c=Math.min(e-1,Math.ceil(n+A)),g=Math.max(0,Math.floor(r-A)),s=Math.min(t-1,Math.ceil(r+A));for(let a=g;a<=s;a++)for(let u=f;u<=c;u++){if(i[(a*e+u)*4+3]<o)continue;const h=u+.5-n,m=a+.5-r;if(h*h+m*m<=l)return!0}return!1}let ri;const xa=class xa extends ft{constructor(){super(...arguments);Y(this,"playingMode","freeplay")}static updateStreakLabel(t){qi("playingModeStreak",`STREAK: ${t.powStreak}`)}onOpen(){ri||(ri=tr("surprising_media-sax-organ-jazz-400-303939.ogg")),ri.loop(!0),ri.volume(.2),ri.play()}onClose(){ri.stop()}elements(){return[{id:"playingModeDisplay",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 50%;
          pointer-events: none;
        `,label:"FREEPLAY",variant:"label",onclick:()=>{}},{id:"playingModeStreak",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 75%;
          pointer-events: none;
        `,label:"STREAK: 0",variant:"label",onclick:()=>{}},{id:"playingBackBtn",style:`
          width: 50px;
          height: 50px;
          left: 25px;
          top: 25px;
        `,onclick:t=>{t.switchToGui("main-menu")},label:"BACK"}]}};ft.register("playing-gui",{factory:t=>new xa(t),preload:async()=>{}});let os=xa;const ls=[`


AECxRACg2UP4SBnAAIA4wgCg5kMAAAAAAECxRACg2UPQ6hjAAIA4wgCg5kMAAAAAAECxRACg2UN8jRjAAIA4wgCg5kMAAAAAAECxRACg2UP6MBjAAIA4wgCg5kMAAAAAAECxRACg2UNJ1RfAAIA4wgCg5kMAAAAAAECxRACg2UNoehfAAIA4wgCg5kMAAAAAAECxRACg2UNVIBfAAIA4wgCg5kMAAAAAAECxRACg2UMPxxbAAIA4wgCg5kMAAAAAAECxRACg2UOUbhbAAIA4wgCg5kMAAAAAAECxRACg2UPjFhbAAIA4wgCg5kMAAAAAAECxRACg2UP8vxXAAIA4wgCg5kMAAAAAAECxRACg2UPbaRXAAIA4wgCg5kMAAAAAAECxRACg2UOBFBXAAIA4wgCg5kMAAAAAAECxRACg2UPrvxTAAIA4wgCg5kMAAAAAgkWxRACg2UOQcxTAAIA4wgCg5kMAAAAABEuxRACg2UP3JxTAAIA4wgCg5kMAAAAAhlCxRACg2UMf3RPAAIA4wgCg5kMAAAAAB1axRACg2UMGkxPAAIA4wgCg5kMAAAAAAWCxRACg2UPTTxPAAIA4wgCg5kMAAAAAT4OxRMcS2UPhWxPAAIA4wgCg5kMAAAAAnqaxRI2F2EOsaBPAAIA4wgCg5kMAAAAA7MmxRFP410M0dhPAAIA4wgCg5kMAAAAAOu2xRBlr10N5hBPAAIA4wgCg5kMAAAAAiRCyRN/d1kN5kxPAAIA4wgCg5kMAAAAAAECyRAAg1kP9whPAAIA4wgCg5kMAAAAAEluyRB1d1UPq2BPAAIA4wgCg5kMAAAAAI3ayRDqa1EOS7xPAAIA4wgCg5kMAAAAANJGyRFfX00P1BhTAAIA4wgCg5kMAAAAARqyyRHMU00MSHxTAAIA4wgCg5kMAAAAAAOCyRACg0UNMkRTAAIA4wgCg5kMAAAAAAOCyRLhk0UOaWxTAAIA4wgCg5kMAAAAAAOCyRHEp0UOhJhTAAIA4wgCg5kMAAAAAAOCyRCnu0ENg8hPAAIA4wgCg5kMAAAAAAOCyROKy0EPWvhPAAIA4wgCg5kMAAAAAAOCyRJp30EMCjBPAAIA4wgCg5kMAAAAAAOCyRAAg0EOkYhPAAIA4wgCg5kMAAAAAAOCyRAAg0EMFHxPAAIA4wgCg5kMAAAAAAOCyRAAg0EMY3BLAAIA4wgCg5kMAAAAAAOCyRAAg0EPdmRLAAIA4wgCg5kMAAAAAAOCyRAAg0ENSWBLAAIA4wgCg5kMAAAAAAOCyRAAg0EN2FxLAAIA4wgCg5kMAAAAAAOCyRAAg0ENJ1xHAAIA4wgCg5kMAAAAAAOCyRJHbz0NPrBHAAIA4wgCg5kMAAAAAAOCyRCGXz0MAghHAAIA4wgCg5kMAAAAAAOCyRLJSz0NdWBHAAIA4wgCg5kMAAAAAAOCyREIOz0NkLxHAAIA4wgCg5kMAAAAAAOCyRACgzkN7ExHAAIA4wgCg5kMAAAAAAOCyRACgzkOu1xDAAIA4wgCg5kMAAAAAAOCyRACgzkOHnBDAAIA4wgCg5kMAAAAAAOCyRACgzkMIYhDAAIA4wgCg5kMAAAAAAOCyRACgzkMtKBDAAIA4wgCg5kMAAAAAAOCyRACgzkP37g/AAIA4wgCg5kMAAAAAAOCyRACgzkNltg/AAIA4wgCg5kMAAAAAAOCyRACgzkN1fg/AAIA4wgCg5kMAAAAAAOCyRACgzkMmRw/AAIA4wgCg5kMAAAAAAOCyRACgzkN4EA/AAIA4wgCg5kMAAAAAAOCyRACgzkNp2g7AAIA4wgCg5kMAAAAAAOCyRACgzkP4pA7AAIA4wgCg5kMAAAAAAOCyRDl3zkOlew7AAIA4wgCg5kMAAAAAAOCyRHFOzkPtUg7AAIA4wgCg5kMAAAAAAOCyRKolzkPSKg7AAIA4wgCg5kMAAAAAAOCyROP8zUNSAw7AAIA4wgCg5kMAAAAAAOCyRBvUzUNr3A3AAIA4wgCg5kMAAAAAAOCyRACgzUNDuQ3AAIA4wgCg5kMAAAAAe8+yRACgzUPKbw3AAIA4wgCg5kMAAAAA9r6yRACgzUPpJg3AAIA4wgCg5kMAAAAAca6yRACgzUOe3gzAAIA4wgCg5kMAAAAA7J2yRACgzUPolgzAAIA4wgCg5kMAAAAAAICyRACgzUOZOwzAAIA4wgCg5kMAAAAA6nWyRACgzUPL/gvAAIA4wgCg5kMAAAAA02uyRACgzUOPwgvAAIA4wgCg5kMAAAAAvWGyRACgzUPihgvAAIA4wgCg5kMAAAAAp1eyRACgzUPFSwvAAIA4wgCg5kMAAAAAkE2yRACgzUM1EQvAAIA4wgCg5kMAAAAAAECyRACgzUPj0QrAAIA4wgCg5kMAAAAAhR+yRKi1zUN7cArAAIA4wgCg5kMAAAAACv+xRE/LzUOdDwrAAIA4wgCg5kMAAAAAj96xRPfgzUNJrwnAAIA4wgCg5kMAAAAAE76xRJ72zUN8TwnAAIA4wgCg5kMAAAAAAICxRAEgzkMZvQjAAIA4wgCg5kMAAAAALnGxRIZHzkOydQjAAIA4wgCg5kMAAAAAXGKxRAtvzkPOLgjAAIA4wgCg5kMAAAAAilOxRI+WzkNs6AfAAIA4wgCg5kMAAAAAuESxRBS+zkOLogfAAIA4wgCg5kMAAAAA5jWxRJnlzkMpXQfAAIA4wgCg5kMAAAAAACCxRAAgz0OMCAfAAIA4wgCg5kMAAAAAACCxRAAgz0MO5QbAAIA4wgCg5kMAAAAAACCxRAAgz0MNwgbAAIA4wgCg5kMAAAAAACCxRAAgz0OInwbAAIA4wgCg5kMAAAAAACCxRAAgz0N+fQbAAIA4wgCg5kMAAAAAACCxRAAgz0PvWwbAAIA4wgCg5kMAAAAAACCxRAAgz0PZOgbAAIA4wgCg5kMAAAAAACCxRAAgz0M8GgbAAIA4wgCg5kMAAAAAACCxRAAgz0MY+gXAAIA4wgCg5kMAAAAAACCxRAAgz0Ns2gXAAIA4wgCg5kMAAAAAACCxRAAgz0M2uwXAAIA4wgCg5kMAAAAAACCxRAAgz0N3nAXAAIA4wgCg5kMAAAAAACCxRAAgz0MufgXAAIA4wgCg5kMAAAAAACCxRAAgz0NZYAXAAIA4wgCg5kMAAAAAACCxRAAgz0P5QgXAAIA4wgCg5kMAAAAAACCxRAAgz0MNJgXAAIA4wgCg5kMAAAAAACCxRAAgz0OUCQXAAIA4wgCg5kMAAAAAACCxRAAgz0OO7QTAAIA4wgCg5kMAAAAAACCxRAAgz0P50QTAAIA4wgCg5kMAAAAAACCxRAAgz0PVtgTAAIA4wgCg5kMAAAAAACCxRAAgz0MinATAAIA4wgCg5kMAAAAAACCxRAAgz0PfgQTAAIA4wgCg5kMAAAAAACCxRAAgz0MMaATAAIA4wgCg5kMAAAAAACCxRH9dz0MgQQTAAIA4wgCg5kMAAAAAACCxRP2az0OiGgTAAIA4wgCg5kMAAAAAACCxRHzYz0OR9APAAIA4wgCg5kMAAAAAACCxRPsV0EPuzgPAAIA4wgCg5kMAAAAAACCxRHpT0EO2qQPAAIA4wgCg5kMAAAAAACCxRAGg0EOtgQPAAIA4wgCg5kMAAAAAxf6wRHfi0EOgJQPAAIA4wgCg5kMAAAAAit2wRO0k0UP8yQLAAIA4wgCg5kMAAAAAT7ywRGNn0UPAbgLAAIA4wgCg5kMAAAAAFJuwRNmp0UPsEwLAAIA4wgCg5kMAAAAAAGCwRAAg0kMIhAHAAIA4wgCg5kMAAAAAyEawROGE0kN2MAHAAIA4wgCg5kMAAAAAkC2wRMHp0kNG3QDAAIA4wgCg5kMAAAAAWBSwRKFO00N4igDAAIA4wgCg5kMAAAAAIPuvRIGz00MKOADAAIA4wgCg5kMAAAAA6OGvRGEY1EP4y/+/AIA4wgCg5kMAAAAAAMCvRACg1EMg/v6/AIA4wgCg5kMAAAAAFqWvRKoL1UMeU/6/AIA4wgCg5kMAAAAALIqvRFR31UPVqP2/AIA4wgCg5kMAAAAAQW+vRP7i1UNC//y/AIA4wgCg5kMAAAAAV1SvRKhO1kNjVvy/AIA4wgCg5kMAAAAAACCvRAAg10NdM/u/AIA4wgCg5kMAAAAAJAyvRFCD10O+pvq/AIA4wgCg5kMAAAAAR/iuRJ/m10PLGvq/AIA4wgCg5kMAAAAAauSuRO9J2EODj/m/AIA4wgCg5kMAAAAAjdCuRD6t2EPjBPm/AIA4wgCg5kMAAAAAsLyuRI4Q2UPrevi/AIA4wgCg5kMAAAAAAKCuRACg2UOExPe/AIA4wgCg5kMAAAAAy1quRHkK2kMdjva/AIA4wgCg5kMAAAAAlxWuRPF02kNaWPW/AIA4wgCg5kMAAAAAY9CtRGnf2kM4I/S/AIA4wgCg5kMAAAAALoutROFJ20Oz7vK/AIA4wgCg5kMAAAAA+kWtRFm020PGuvG/AIA4wgCg5kMAAAAAAQCtRAAg3ENkhPC/AIA4wgCg5kMAAAAA2NesRKTA3ENYqe+/AIA4wgCg5kMAAAAAr6+sREdh3UPYzu6/AIA4wgCg5kMAAAAAhoesROoB3kPh9O2/AIA4wgCg5kMAAAAAXV+sRI2i3kNxG+2/AIA4wgCg5kMAAAAAACCsRAGg30PF2Ou/AIA4wgCg5kMAAAAAIfGrRIDe30PL/+q/AIA4wgCg5kMAAAAAQsKrRP4c4ENPJ+q/AIA4wgCg5kMAAAAAY5OrRH1b4ENPT+m/AIA4wgCg5kMAAAAAhGSrRPyZ4EPId+i/AIA4wgCg5kMAAAAApDWrRHvY4EO4oOe/AIA4wgCg5kMAAAAAAACrRAAg4UPPr+a/AIA4wgCg5kMAAAAAR82qRFvU4UOIs+W/AIA4wgCg5kMAAAAAjpqqRLWI4kOwt+S/AIA4wgCg5kMAAAAA1GeqRA8940NFvOO/AIA4wgCg5kMAAAAAGzWqRGnx40NEweK/AIA4wgCg5kMAAAAAAeCpRAAg5UOENOG/AIA4wgCg5kMAAAAAhMapRPOF5UMFo+C/AIA4wgCg5kMAAAAACK2pROXr5UPmEeC/AIA4wgCg5kMAAAAAi5OpRNdR5kMmgd+/AIA4wgCg5kMAAAAADnqpRMq35kPE8N6/AIA4wgCg5kMAAAAAkmCpRLwd50O8YN6/AIA4wgCg5kMAAAAAAUCpRACg50P/st2/AIA4wgCg5kMAAAAA/TSpRACg50NqZ92/AIA4wgCg5kMAAAAA+impRACg50MrHN2/AIA4wgCg5kMAAAAA9h6pRACg50ND0dy/AIA4wgCg5kMAAAAA8hOpRACg50Ouhty/AIA4wgCg5kMAAAAAAACpRACg50O8G9y/AIA4wgCg5kMAAAAA9fqoRC2050Pu5Nu/AIA4wgCg5kMAAAAA6vWoRFrI50Nwrtu/AIA4wgCg5kMAAAAA3vCoRIfc50NDeNu/AIA4wgCg5kMAAAAA0+uoRLPw50NlQtu/AIA4wgCg5kMAAAAAyOaoROAE6EPWDNu/AIA4wgCg5kMAAAAAAOCoRAAg6ENU0Nq/AIA4wgCg5kMAAAAAAOCoRAAg6ENrsNq/AIA4wgCg5kMAAAAAAOCoRAAg6EPOkNq/AIA4wgCg5kMAAAAAAOCoRAAg6EN9cdq/AIA4wgCg5kMAAAAAAOCoRAAg6EN3Utq/AIA4wgCg5kMAAAAAAOCoRAAg6EO8M9q/AIA4wgCg5kMAAAAAAOCoRAAg6ENMFdq/AIA4wgCg5kMAAAAAAOCoRAAg6EMl99m/AIA4wgCg5kMAAAAAAOCoRAAg6ENH2dm/AIA4wgCg5kMAAAAAAOCoRAAg6EOyu9m/AIA4wgCg5kMAAAAAAOCoRAAg6ENlntm/AIA4wgCg5kMAAAAAAOCoRAAg6ENfgdm/AIA4wgCg5kMAAAAAAOCoRAAg6EOgZNm/AIA4wgCg5kMAAAAAAOCoRAAg6EMoSNm/AIA4wgCg5kMAAAAAAOCoRAAg6EP1K9m/AIA4wgCg5kMAAAAAAOCoRAAg6EMIENm/AIA4wgCg5kMAAAAAAOCoRAAg6ENf9Ni/AIA4wgCg5kMAAAAAAOCoRAAg6EP72Ni/AIA4wgCg5kMAAAAAAOCoRAAg6EPavdi/AIA4wgCg5kMAAAAAAOCoRAAg6EP9oti/AIA4wgCg5kMAAAAAAOCoRAAg6ENiiNi/AIA4wgCg5kMAAAAAAOCoRAAg6EMJbti/AIA4wgCg5kMAAAAAAOCoRAAg6EPyU9i/AIA4wgCg5kMAAAAAAOCoRAAg6EMcOti/AIA4wgCg5kMAAAAAAOCoRAAg6EOHINi/AIA4wgCg5kMAAAAAAOCoRAAg6EMyB9i/AIA4wgCg5kMAAAAAAOCoRAAg6EMd7te/AIA4wgCg5kMAAAAAAOCoRAAg6ENH1de/AIA4wgCg5kMAAAAAAOCoRAAg6EOwvNe/AIA4wgCg5kMAAAAAAOCoRAAg6ENXpNe/AIA4wgCg5kMAAAAAAOCoRAAg6EM8jNe/AIA4wgCg5kMAAAAAAOCoRAAg6ENfdNe/AIA4wgCg5kMAAAAAAOCoRAAg6EO+XNe/AIA4wgCg5kMAAAAAAOCoRAAg6ENaRde/AIA4wgCg5kMAAAAAAOCoRAAg6EMxLte/AIA4wgCg5kMAAAAAAOCoRAAg6ENFF9e/AIA4wgCg5kMAAAAAAOCoRAAg6EOTANe/AIA4wgCg5kMAAAAAAOCoRAAg6EMc6ta/AIA4wgCg5kMAAAAAAOCoRAAg6EPf09a/AIA4wgCg5kMAAAAAAOCoRAAg6EPdvda/AIA4wgCg5kMAAAAAAOCoRAAg6EMTqNa/AIA4wgCg5kMAAAAAAOCoRAAg6EODkta/AIA4wgCg5kMAAAAAAOCoRAAg6EMrfda/AIA4wgCg5kMAAAAAAOCoRAAg6EMLaNa/AIA4wgCg5kMAAAAAAOCoRAAg6EMjU9a/AIA4wgCg5kMAAAAAAOCoRAAg6ENyPta/AIA4wgCg5kMAAAAAAOCoRAAg6EP4Kda/AIA4wgCg5kMAAAAAAOCoRAAg6EO1Fda/AIA4wgCg5kMAAAAAAOCoRAAg6EOoAda/AIA4wgCg5kMAAAAAAOCoRAAg6EPQ7dW/AIA4wgCg5kMAAAAAAOCoRAAg6EMu2tW/AIA4wgCg5kMAAAAAAOCoRAAg6EPBxtW/AIA4wgCg5kMAAAAAAOCoRAAg6EOJs9W/AIA4wgCg5kMAAAAAAOCoRAAg6EOEoNW/AIA4wgCg5kMAAAAAAOCoRAAg6EO0jdW/AIA4wgCg5kMAAAAAAOCoRAAg6EMXe9W/AIA4wgCg5kMAAAAAAOCoRCyX6EMYXtW/AIA4wgCg5kMAAAAAAOCoRFgO6UNLQdW/AIA4wgCg5kMAAAAAAOCoRIWF6UOxJNW/AIA4wgCg5kMAAAAAAOCoRLH86UNICNW/AIA4wgCg5kMAAAAAAOCoRN1z6kMR7NS/AIA4wgCg5kMAAAAAAOCoRAAg60OOy9S/M7MtwnH15UMAAAAACNCoROJf60NLedS/ZuYiwghM5UMAAAAAEMCoRMSf60M2J9S/mhkYwsej5EMAAAAAF7CoRKbf60NQ1dO/zUwNwqz840MAAAAAH6CoRIcf7EOXg9O/AIACwrhW40MAAAAAJpCoRGlf7EMLMtO/Zmbvweyx4kMAAAAAAICoRACg7EP139K/zczZwUYO4kMAAAAAAICoRHDk7ENZydK/MzPEwcdr4UMAAAAAAICoRN8o7UPnstK/mpmuwW/K4EMAAAAAAICoRE9t7UOfnNK/AACZwT0q4EMAAAAAAICoRL6x7UOBhtK/ZmaDwTOL30MAAAAAAICoRAAg7kO4bdK/mplbwVDt3kMAAAAAy3qoRH9e7kMNRdK/ZmYwwZNQ3kMAAAAAlnWoRP6c7kOJHNK/MzMFwf603UMAAAAAYHCoRHzb7kMu9NG/AAC0wI8a3UMAAAAAK2uoRPsZ70P5y9G/MzM7wEiB3EMAAAAA9mWoRHpY70Pso9G/ZmZmvifp20MAAAAAAGCoRACg70OxeNG/ZmYeQC1S20MAAAAAdUmoRLgQ8EP9DdG/mpmlQFq82kMAAAAA6TKoRHCB8ENuo9C/AAD8QK4n2kMAAAAAXhyoRCny8EMBOdC/MzMpQSmU2UMAAAAA0wWoROFi8UO2zs+/ZmZUQcsB2UMAAAAAAOCnRAAg8kO2KM+/mpl/QZNw2EMAAAAAodCnRH9d8kMn286/ZmaVQYPg10MAAAAAQcGnRP2a8kO4jc6/AACrQZpR10MAAAAA4bGnRHzY8kNmQM6/mpnAQdfD1kMAAAAAgaKnRPsV80Mw882/MzPWQTs31kMAAAAAIpOnRHpT80MXps2/zczrQcer1UMAAAAAAICnRAGg80O9Ss2/M7MAQnkh1UMAAAAAe2+nRBz480PS+My/AIALQlKY1EMAAAAA9l6nRDdQ9EMAp8y/zUwWQlIQ1EMAAAAAcE6nRFOo9ENGVcy/mhkhQnmJ00MAAAAA6z2nRG4A9UOkA8y/ZuYrQscD00MAAAAAACCnRACg9UNDf8u/M7M2Qjt/0kMAAAAA0wunRIbc9UOAIMu/AIBBQtf70UMAAAAApvemRA0Z9kPRwcq/zUxMQpp50UMAAAAAeeOmRJNV9kM1Y8q/mhlXQoP40EMAAAAATc+mRBqS9kOrBMq/ZuZhQpN40EMAAAAAILumRKDO9kMypsm/M7NsQsv5z0MAAAAAAKCmRAAg90MOLsm/AIB3Qil8z0MAAAAAAKCmRAAg90NcGsm/ZiaBQq7/zkMAAAAAAKCmRAAg90O5Bsm/zYyGQlqEzkMAAAAAAKCmRAAg90Ml88i/M/OLQi0KzkMAAAAAAKCmRAAg90Of38i/mlmRQieRzUMAAAAAAKCmRAAg90MozMi/AMCWQkgZzUMAAAAAAKCmRAAg90O+uMi/ZiacQo+izEMAAAAAAKCmRAAg90Nipci/zYyhQv4szEMAAAAAAKCmRAAg90MUksi/M/OmQpO4y0MAAAAAAKCmRAAg90PSfsi/mlmsQlBFy0MAAAAAAKCmRAAg90Oea8i/AMCxQjPTykMAAAAAAKCmRAAg90N2WMi/Zia3Qj1iykMAAAAAAKCmRAAg90NaRci/zYy8Qm/yyUMAAAAAAKCmRAAg90NLMsi/M/PBQseDyUMAAAAAAKCmRAAg90NHH8i/mlnHQkYWyUMAAAAAAKCmRAAg90NPDMi/AMDMQuypyEMAAAAAAKCmRAAg90Nj+ce/ZibSQrg+yEMAAAAAAKCmRAAg90OB5se/zYzXQqzUx0MAAAAAAKCmRAAg90Oq08e/M/PcQsdrx0MAAAAAAKCmRAAg90PewMe/mlniQggEx0MAAAAAAKCmRAAg90Mcrse/AMDnQnGdxkMAAAAAAKCmRAAg90Nkm8e/ZibtQgA4xkMAAAAAAKCmRAAg90O2iMe/zYzyQrbTxUMAAAAAAKCmRAAg90MSdse/M/P3QpNwxUMAAAAAAKCmRAAg90N2Y8e/mln9QpgOxUMAAAAAAKCmRAAg90PkUMe/AGABQ8OtxEMAAAAAAKCmRAAg90NbPse/MxMEQxROxEMAAAAAAKCmRAAg90PaK8e/ZsYGQ43vw0MAAAAAAKCmRAAg90NiGce/mnkJQy2Sw0MAAAAAAKCmRAAg90PyBse/zSwMQ/Q1w0MAAAAAAKCmRAAg90OK9Ma/AOAOQ+HawkMAAAAAAKCmRAAg90Mp4sa/M5MRQ/aAwkMAAAAAAKCmRAAg90PQz8a/ZkYUQzEowkMAAAAAAKCmRAAg90N+vca/mvkWQ5PQwUMAAAAAAKCmRAAg90Mzq8a/zawZQx16wUMAAAAAAKCmRAAg90PumMa/AGAcQ80kwUMAAAAAAKCmRAAg90Owhsa/MxMfQ6TQwEMAAAAAAKCmRAAg90N4dMa/ZsYhQ6J9wEMAAAAAAKCmRAAg90NHYsa/mnkkQ8crwEMAAAAAAKCmRAAg90MbUMa/zSwnQxLbv0MAAAAAAKCmRAAg90P0Pca/AOApQ4WLv0MAAAAAAKCmRAAg90PTK8a/M5MsQx89v0MAAAAAAKCmRAAg90O3Gca/ZkYvQ9/vvkMAAAAAAKCmRAAg90OgB8a/mvkxQ8ejvkMAAAAAAKCmRAAg90ON9cW/zaw0Q9VYvkMAAAAAAKCmRAAg90N/48W/AGA3QwoPvkMAAAAAAKCmRAAg90N10cW/MxM6Q2bGvUMAAAAAAKCmRAAg90Nvv8W/ZsY8Q+l+vUMAAAAAAKCmRAAg90NtrcW/mnk/Q5M4vUMAAAAAAKCmRAAg90Num8W/zSxCQ2TzvEMAAAAAAKCmRAAg90NzicW/AOBEQ1yvvEMAAAAAAKCmRAAg90N7d8W/M5NHQ3tsvEMAAAAAAKCmRAAg90OFZcW/ZkZKQ8EqvEMAAAAAAKCmRAAg90OSU8W/mvlMQy3qu0MAAAAAAKCmRAAg90OiQcW/zaxPQ8Gqu0MAAAAAAKCmRAAg90O0L8W/AGBSQ3tsu0MAAAAAAKCmRAAg90PIHcW/MxNVQ1wvu0MAAAAAAKCmRAAg90PeC8W/ZsZXQ2TzukMAAAAAAKCmRAAg90P1+cS/mnlaQ5O4ukMAAAAAAKCmRAAg90MN6MS/zSxdQ+l+ukMAAAAAAKCmRAAg90Mn1sS/AOBfQ2ZGukMAAAAAAKCmRAAg90NCxMS/M5NiQwoPukMAAAAAAKCmRAAg90NdssS/ZkZlQ9XYuUMAAAAAAKCmRAAg90N5oMS/mvlnQ8ejuUMAAAAAAKCmRAAg90OVjsS/zaxqQ99vuUMAAAAAAKCmRAAg90OyfMS/AGBtQx89uUMAAAAAAKCmRAAg90POasS/MxNwQ4ULuUMAAAAAAKCmRAAg90PqWMS/ZsZyQxLbuEMAAAAAAKCmRAAg90MFR8S/mnl1Q8eruEMAAAAAAKCmRAAg90MfNcS/zSx4Q6J9uEMAAAAAAKCmRAAg90M5I8S/AOB6Q6RQuEMAAAAAAKCmRAAg90NSEcS/M5N9Q80kuEMAAAAAAKCmRAAg90Np/8O/MyOAQx36t0MAAAAAAKCmRAAg90N+7cO/zXyBQ5PQt0MAAAAAAKCmRAAg90OS28O/ZtaCQzGot0MAAAAAAKCmRAAg90OkycO/ADCEQ/aAt0MAAAAAAKCmRAAg90O0t8O/momFQ+Fat0MAAAAAAKCmRAAg90PBpcO/M+OGQ/Q1t0MAAAAAAKCmRAAg90PMk8O/zTyIQy0St0MAAAAAAKCmRAAg90PUgcO/ZpaJQ43vtkMAAAAAAKCmRAAg90PZb8O/APCKQxTOtkMAAAAAAKCmRAAg90PbXcO/mkmMQ8OttkMAAAAAAKCmRAAg90PZS8O/M6ONQ5iOtkMAAAAAAKCmRAAg90PUOcO/zfyOQ5NwtkMAAAAAAKCmRAAg90PLJ8O/ZlaQQ7ZTtkMAAAAAAKCmRAAg90O+FcO/ALCRQwA4tkMAAAAAAKCmRAAg90OtA8O/mgmTQ3EdtkMAAAAAAKCmRAAg90OX8cK/M2OUQwgEtkMAAAAAAKCmRAAg90N938K/zbyVQ8frtUMAAAAAAKCmRAAg90NfzcK/ZhaXQ6zUtUMAAAAABKumRCKO90PU6MK/AHCYQ7i+tUMAAAAAB7amRET890NGBMO/msmZQ+yptUMAAAAACsGmRGdq+EO0H8O/MyObQ0aWtUMAAAAADsymRInY+EMeO8O/zXycQ8eDtUMAAAAAAOCmRACg+UMke8O/ZtadQ29ytUMAAAAAAOCmRGsY+kM1bsO/ADCfQz1itUMAAAAAAOCmRNaQ+kNDYcO/momgQzNTtUMAAAAAAOCmREEJ+0NOVMO/M+OhQ1BFtUMAAAAAAOCmRKyB+0NVR8O/zTyjQ5M4tUMAAAAAAOCmRBj6+0NYOsO/ZpakQ/4stUMAAAAAAOCmRACg/ENGL8O/APClQ48itUMAAAAAAOCmRN2M/UM4J8O/mkmnQ0gZtUMAAAAAAOCmRLl5/kMnH8O/M6OoQycRtUMAAAAAAOCmRJVm/0MRF8O/zfypQy0KtUMAAAAAAOCmRLgpAET4DsO/ZlarQ1oEtUMAAAAAAOCmRAAQAUSMEMO/ALCsQ67/tEMAAAAAAOCmRApfAUTnBMO/mgmuQyn8tEMAAAAAAOCmRBSuAUQ/+cK/M2OvQ8v5tEMAAAAAAOCmRB79AUST7cK/zbywQ5P4tEMAAAAAAOCmRChMAkTj4cK/ZhayQ4P4tEMAAAAAAOCmRDKbAkQv1sK/AHCzQ5r5tEMAAAAAAOCmRAAQA0ThzcK/msm0Q9f7tEMAAAAAHtCmRDykA0TSjcK/MyO2Qzv/tEMAAAAAPMCmRHk4BES+TcK/zXy3Q8cDtUMAAAAAWrCmRLXMBESkDcK/Zta4Q3kJtUMAAAAAeKCmRPJgBUSGzcG/ADC6Q1IQtUMAAAAAlpCmRC71BURhjcG/mom7Q1IYtUMAAAAAAICmRAGQBkRZS8G/M+O8Q3khtUMAAAAAkDumRFeWB0RuV8C/zTy+Q8crtUMAAAAAIfelRK2cCESAY7+/Zpa/Qzs3tUMAAAAAsbKlRAOjCUSNb76/APDAQ9dDtUMAAAAAQm6lRFmpCkSXe72/mknCQ5pRtUMAAAAAAAClRABQDETJC7y/M6PDQ4NgtUMAAAAATbKkRG98DUTq+rq/zfzEQ5NwtUMAAAAAm2SkRN2oDkQM6rm/ZlbGQ8uBtUMAAAAA6BakREzVD0Qu2bi/ALDHQymUtUMAAAAANcmjRLoBEURSyLe/mgnJQ66ntUMAAAAAg3ujRCkuEkR5t7a/M2PKQ1q8tUMAAAAAACCjRACQE0Qng7W/zbzLQy3StUMAAAAAh5miRJK+FERUorO/ZhbNQyfptUMAAAAADROiRCPtFUSdwbG/AHDOQ0gBtkMAAAAAlIyhRLUbF0QE4a+/msnPQ48atkMAAAAAGgahREZKGESLAK6/MyPRQ/40tkMAAAAAACCgRABQGkRCJKu/zXzSQ5NQtkMAAAAAi9OfROzoGkSbzKm/ZtbTQ1BttkMAAAAAFYefRNiBG0QLdai/ADDVQzOLtkMAAAAAnzqfRMMaHESPHae/monWQz2qtkMAAAAAKe6eRK+zHEQnxqW/M+PXQ2/KtkMAAAAAs6GeRJpMHUTRbqS/zTzZQ8frtkMAAAAAAECeRAAQHkSH46K/ZpbaQ0YOt0MAAAAA14WdRN0LH0RHQqC/APDbQ+wxt0MAAAAArsucRLoHIERaoZ2/mkndQ7hWt0MAAAAAhRGcRJcDIUTDAJu/M6PeQ6x8t0MAAAAAXVebRHT/IUSFYJi/zfzfQ8ejt0MAAAAAAACaRADQI0SMSZS/ZlbhQwjMt0MAAAAAcl+ZRIZmJESqpZG/ALDiQ3H1t0MAAAAA476YRAz9JEQ0Ao+/mgnkQwAguEMAAAAAVB6YRJKTJUQsX4y/M2PlQ7ZLuEMAAAAAxX2XRBcqJkSRvIm/zbzmQ5N4uEMAAAAANt2WRJ3AJkRmGoe/ZhboQ5imuEMAAAAAAACWRACQJ0RX7oO/AHDpQ8PVuEMAAAAANT6VRPcbKET11YC/msnqQxQGuUMAAAAAaXyURO2nKER1fHu/MyPsQ403uUMAAAAAnrqTROQzKURUTnW/zXztQy1quUMAAAAA0/iSRNq/KUSOIW+/ZtbuQ/SduUMAAAAAAICRRAHQKkSDA2a/ADDwQ+HSuUMAAAAA4RORRM8UK0TzAmG/monxQ/YIukMAAAAAwaeQRJ1ZK0RyA1y/M+PyQzFAukMAAAAAojuQRGueK0QABVe/zTz0Q5N4ukMAAAAAgs+PRDnjK0SaB1K/Zpb1Qx2yukMAAAAAY2OPRAcoLERAC02/APD2Q83sukMAAAAAAMCORACQLER6TUe/mkn4Q6Qou0MAAAAAyRyORB+6LEQT60C/M6P5Q6Jlu0MAAAAAkXmNRD7kLERMijq/zfz6Q8eju0MAAAAAWdaMRF0OLUQpKzS/Zlb8QxLju0MAAAAAITOMRHw4LUSxzS2/ALD9Q4UjvEMAAAAA6Y+LRJtiLUTpcSe/mgn/Qx9lvEMAAAAAAOCKRACQLURy6iC/mjEARN+nvEMAAAAAPWiKRACQLUS/xhq/Zt4ARMfrvEMAAAAAevCJRACQLUS2pBS/M4sBRNUwvUMAAAAAtniJRACQLURYhA6/ADgCRAp3vUMAAAAA8wCJRACQLUSoZQi/zeQCRGa+vUMAAAAAAECIRACQLUTRQgG/mpEDROkGvkMAAAAAOdOHRACQLUTzhPa+Zj4ERJNQvkMAAAAAcmaHRACQLUSuh+q+M+sERGSbvkMAAAAAq/mGRACQLUTZjd6+AJgFRFznvkMAAAAA5IyGRACQLUR7l9K+zUQGRHs0v0MAAAAAHiCGRACQLUSepMa+mvEGRMGCv0MAAAAAAKCFRACQLUR6T7q+Zp4HRC3Sv0MAAAAAKVeFRACQLUQ/EK++M0sIRMEiwEMAAAAAUg6FRACQLURa1KO+APgIRHt0wEMAAAAAe8WERACQLUTQm5i+zaQJRFzHwEMAAAAAo3yERACQLUSjZo2+mlEKRGQbwUMAAAAAAACERACQLUQqdYG+Zv4KRJNwwUMAAAAAvL2DRNwfLUTlPma+M6sLROnGwUMAAAAAeHuDRLivLER2nUm+AFgMRGYewkMAAAAANDmDRJQ/LEQOBi2+zQQNRAp3wkMAAAAA8PaCRHDPK0S1eBC+mrENRNXQwkMAAAAArLSCREtfK0Tz6ue9Zl4ORMcrw0MAAAAAAGCCRAHQKkTdB6u9MwsPRN+Hw0MAAAAAXOyBRLLSKUQHZkK9ALgPRB/lw0MAAAAAuHiBRGPVKESRBTy8zWQQRIVDxEMAAAAAFAWBRBTYJ0RTOsg8mhERRBKjxEMAAAAAcJGARMXaJkSA9HY9Zr4RRMcDxUMAAAAAAYB/RAAQJUTVC9o9M2sSRKJlxUMAAAAAjf1+RGllJESzAw4+ABgTRKTIxUMAAAAAGXt+RNG6I0Sr8S4+zcQTRM0sxkMAAAAApfh9RDoQI0Sfz08+mnEURB2SxkMAAAAAMXZ9RKJlIkRXnXA+Zh4VRJP4xkMAAAAAvfN8RAq7IURLrYg+M8sVRDFgx0MAAAAAAEB8RAHQIERJXpo+AHgWRPbIx0MAAAAAZ/97RApEIESsg6o+zSQXROEyyEMAAAAAzr57RBS4H0SKoLo+mtEXRPSdyEMAAAAANX57RB0sH0TKtMo+Zn4YRC0KyUMAAAAAnD17RCegHkRSwNo+MysZRI13yUMAAAAAAMB6RACQHUReY+0+ANgZRBTmyUMAAAAAAMB6ROzxHERx0f4+zYQaRMNVykMAAAAAAMB6RNhTHESUGgg/mjEbRJjGykMAAAAAAMB6RMO1G0Q2xxA/Zt4bRJM4y0MAAAAAAMB6RK8XG0SPbhk/M4scRLary0MAAAAAAMB6RJt5GkSQECI/ADgdRAAgzEMAAAAAAMB6RACQGUTxhys/zeQdRHGVzEMAAAAAxN96RKaxGESxJTU/mpEeRAgMzUMAAAAAiP96REzTF0TavD4/Zj4fRMeDzUMAAAAASx97RPL0FkRWTUg/M+sfRKz8zUMAAAAADz97RJcWFkQP11E/AJggRLh2zkMAAAAA0157RD04FUTtWVs/zUQhROzxzkMAAAAAAIB7RAFQFETE8GQ/mvEhREZuz0MAAAAAfzZ8RGS1EkTHwXE/Zp4iRMfrz0MAAAAA/ux8RMcaEUSYhn4/M0sjRG9q0EMAAAAAfKN9RCmAD0SKn4U/APgjRD3q0EMAAAAA+1l+RIzlDUSK9Ys/zaQkRDNr0UMAAAAAAYB/RABQC0TQvJM/mlElRFDt0UMAAAAA6giARDBBCkT+dZk/Zv4lRJNw0kMAAAAA01GARGAyCUSZKZ8/M6smRP700kMAAAAAvJqARI8jCESQ16Q/AFgnRI9600MAAAAApeOARL8UB0TTf6o/zQQoREgB1EMAAAAAjyyBRO4FBkROIrA/mrEoRCeJ1EMAAAAAAICBRADQBEQl8LU/Zl4pRC0S1UMAAAAAPcOBRELOA0QHcrs/MwsqRFqc1UMAAAAAegaCRITMAkQG7sA/ALgqRK4n1kMAAAAAtkmCRMXKAUQOZMY/zWQrRCm01kMAAAAA84yCRAfJAEQO1Ms/mhEsRMtB10MAAAAAAACDRAAg/kPr1tE/Zr4sRJPQ10MAAAAAyCiDRDeI/ENs8dY/M2stRINg2EMAAAAAj1GDRG3w+kMCBtw/ABguRJrx2EMAAAAAVnqDRKNY+UOdFOE/zcQuRNeD2UMAAAAAHaODRNrA90MuHeY/mnEvRDsX2kMAAAAA5cuDRBAp9kOoH+s/Zh4wRMer2kMAAAAAAACERAAg9ENxJPA/M8swRHlB20MAAAAAzSuEREkD80MUUPU/AHgxRFLY20MAAAAAm1eERJLm8UMxdfo/zSQyRFJw3EMAAAAAaIOERNvJ8EO+k/8/mtEyRHkJ3UMAAAAANq+ERCSt70PZVQJAZn4zRMej3UMAAAAAAACFRACg7UOB5ARAMys0RDs/3kMAAAAAHyOFRGDr7ENNegdAANg0RNfb3kMAAAAAPkaFRL827EOnDApAzYQ1RJp530MAAAAAXmmFRB+C60ONmwxAmjE2RIMY4EMAAAAAfYyFRH7N6kP8Jg9AZt42RJO44EMAAAAAnK+FRN0Y6kPzrhFAM4s3RMtZ4UMAAAAAAOCFRAAg6UMZMBRAADg4RCn84UMAAAAAmSCGRKxI6EPjzRZAzeQ4RK6f4kMAAAAAMmGGRFlx50MJaBlAmpE5RFpE40MAAAAAy6GGRAWa5kOI/htAZj46RC3q40MAAAAAZeKGRLHC5UNdkR5AM+s6RCeR5EMAAAAAAGCHRAAg5ENAFiFAAJg7REg55UMAAAAAYb2HRHbl4kO2niNAzUQ8RI/i5UMAAAAAwhqIROyq4UN7IyZAmvE8RP6M5kMAAAAAI3iIRGJw4EOMpChAZp49RJM450MAAAAAhNWIRNg130PkIStAM0s+RFDl50MAAAAA5TKJRE773UODmy1AAPg+RDOT6EMAAAAAAMCJRAAg3EOK7i9AzaQ/RD1C6UMAAAAAedqJRHng20P5pzJAmlFARG/y6UMAAAAA8fSJRPKg20NQXTVAzEc/RBIy6kMAAAAAag+KRGph20N1FzZArI0+RBpJ50MAAAAA4imKROMh20ND0DZAjNM9REph5EMAAAAAW0SKRFvi2kO5hzdAbBk9RKF64UMAAAAAAGCKRAGg2kMnPThATF88RB6V3kMAAAAAHHGKRJFb2kNx6zhALKU7RMKw20MAAAAAOIKKRCEX2kNlmDlADOs6RI7N2EMAAAAAVJOKRLLS2UMDRDpA7DA6RIDr1UMAAAAAcKSKREKO2UNM7jpAzHY5RJkK00MAAAAAAMCKRAAg2UNmiDtArLw4RNkq0EMAAAAAAMCKRAAg2UMLSTxAjAI4REBMzUMAAAAAAMCKRAAg2UNZCD1AbEg3RM5uykMAAAAAAMCKRAAg2UNRxj1ATI42RIOSx0MAAAAAAMCKRAAg2UP1gj5ALNQ1RF63xEMAAAAAAMCKRAAg2UNFPj9ADBo1RGHdwUMAAAAAAMCKRAAg2UNB+D9A7F80RIoEv0MAAAAANcuKRJYJ2UNcqUBAy6UzRNssvEMAAAAAataKRC3z2EMmWUFAq+syRFJWuUMAAAAAn+GKRMPc2EOfB0JAizEyRPCAtkMAAAAA0+yKRFrG2EPKtEJAa3cxRLass0MAAAAAAACLRACg2EOeWkNAS70wRKLZsEMAAAAAGQWLREYR2EPmzENAKwMwRLUHrkMAAAAAMgqLRI2C10PlPURAC0kvRO42q0MAAAAASw+LRNPz1kObrURA644uRE9nqEMAAAAAZBSLRBll1kMJHEVAy9QtRNeYpUMAAAAAfRmLRF/W1UMwiUVAqxotRIbLokMAAAAAACCLRAAg1UPi4kVAi2AsRFv/n0MAAAAAEVeLRMJZ1EP4N0ZAa6YrRFg0nUMAAAAAI46LRIWT00PJi0ZAS+wqRHtqmkMAAAAANMWLREfN0kNX3kZAKzIqRMWhl0MAAAAARfyLRAoH0kOjL0dAC3gpRDbalEMAAAAAAGCMRAGg0EO3N0dA670oRM8TkkMAAAAAKI2MRIQT0ENXoUdAywMoRI5Oj0MAAAAAUbqMRAeHz0O0CUhAq0knRHOKjEMAAAAAeeeMRIr6zkPQcEhAi48mRIDHiUMAAAAAoRSNRA1uzkOq1khAa9UlRLQFh0MAAAAAyUGNRJDhzUNw5EjASxslRA9FhEMAAAAAAICNRAAgzUPbmUjAK2EkRJCFgUMAAAAAJ5CNRN/JzEOTHUjAC6cjRHKOfUMAAAAATaCNRL1zzEOLokfA6+wiRBAUeEMAAAAAc7CNRJwdzEPBKEfAyzIiRP2bckMAAAAAmcCNRHrHy0M0sEbAq3ghRDcmbUMAAAAAAOCNRAAgy0OqX0bAi74gRMCyZ0MAAAAA4emNRD4My0MXykXAawQgRJZBYkMAAAAAw/ONRHv4ykPANUXAS0ofRLrSXEMAAAAApP2NRLnkykOlokTAK5AeRCtmV0MAAAAAhQeORPbQykPEEETAC9YdROv7UUMAAAAAZxGORDS9ykMdgEPA6xsdRPiTTEMAAAAAACCORACgykPb9ULAy2EcRFMuR0MAAAAAACCORACgykOQXELAq6cbRPzKQUMAAAAAACCORACgykN7xEHAi+0aRPNpPEMAAAAAACCORACgykOcLUHAazMaRDgLN0MAAAAAACCORACgykPyl0DAS3kZRMuuMUMAAAAAACCORACgykN7A0DAK78YRKtULEMAAAAAACCORACgykM1cD/ACwUYRNn8JkMAAAAAACCORACgykMg3j7A6koXRFWnIUMAAAAAACCORACgykM7TT7AypAWRB9UHEMAAAAAACCORACgykOEvT3AqtYVRDYDF0MAAAAAACCORACgykP5Lj3AihwVRJy0EUMAAAAAACCORACgykOboTzAamIURE9oDEMAAAAAACCORACgykNmFTzASqgTRFAeB0MAAAAAACCORACgykNbijvAKu4SRJ/WAUMAAAAAACCORACgykN3ADvACjQSRHgi+UIAAAAAACCORACgykO5dzrA6nkRRE2c7kIAAAAAACCORACgykMh8DnAyr8QRL4a5EIAAAAAACCORACgykOsaTnAqgUQRMqd2UIAAAAAACCORACgykNa5DjAiksPRHIlz0IAAAAAACCORACgykMpYDjAapEORLaxxEIAAAAAACCORACgykMY3TfAStcNRJVCukIAAAAAACCORACgykMlWzfAKh0NRBDYr0IAAAAAACCORACgykNQ2jbACmMMRCdypUIAAAAAACCORACgykOWWjbA6qgLRNkQm0IAAAAAACCORACgykP32zXAyu4KRCe0kEIAAAAAACCORACgykNxXjXAqjQKRBFchkIAAAAAACCORACgykMC4jTAinoJRCwReEIAAAAAACCORACgykOqZjTAasAIRG5zY0IAAAAAACCORACgykNo7DPASgYIROfeTkIAAAAAeiWORACgykOTdjPAKkwHRJdTOkIAAAAA9CqORACgykPRATPACpIGRH/RJUIAAAAAbTCORACgykMhjjLA6tcFRJ5YEUIAAAAA5zWORACgykOAGzLAyh0FROnR+UEAAAAAAECORACgykP8rDHAqmMERAQF0UEAAAAACUqORCTIykMwLjHAiqkDRI1KqEEAAAAAElSOREjwykNysDDAau8CRAxFf0EAAAAAG16ORGwYy0O/MzDASjUCRNkZLkEAAAAAJGiORI9Ay0MWuC/AKnsBRAknukAAAAAALXKORLNoy0N1PS/ACsEARMwgQz8AAAAAAICORAGgy0M9wC7A6gYARBwVicAAAAAAAICORAGgy0MJUS7Ak5n+Q0siFcEAAAAAAICORAGgy0Pb4i3AUyX9QyuVZcEAAAAAAICORAGgy0OvdS3AE7H7Q5fxmsEAAAAAAICORAGgy0OGCS3A0zz6QyoGw8EAAAAAAICORAGgy0NdnizAk8j4Q04I68EAAAAAAICORAGgy0M0NCzAU1T3QwJ8CcIAAAAAAICORAGgy0MJyyvAE+D1Q6ZqHcIAAAAAAICORAGgy0PaYivA02v0QxJQMcIAAAAAAICORAGgy0On+yrAk/fyQ0csRcIAAAAAAICORAGgy0NulSrAU4PxQ0X/WMIAAAAAAICORAGgy0MtMCrAAIA4wgCg5kMAAAAAAICORAGgy0PkyynAAIA4wgCg5kMAAAAAAICORAGgy0OQaCnAAIA4wgCg5kMAAAAAAICORAGgy0MyBinAAIA4wgCg5kMAAAAAAICORAGgy0PHpCjAAIA4wgCg5kMAAAAAAICORAGgy0NORCjAAIA4wgCg5kMAAAAAAICORAGgy0PG5CfAAIA4wgCg5kMAAAAAAICORAGgy0MthifAAIA4wgCg5kMAAAAAAICORAGgy0ODKCfAAIA4wgCg5kMAAAAAAICORAGgy0PGyybAAIA4wgCg5kMAAAAAAICORAGgy0P0bybAAIA4wgCg5kMAAAAAAICORAGgy0MNFSbAAIA4wgCg5kMAAAAAAICORAGgy0MOuyXAAIA4wgCg5kMAAAAAAICORAGgy0P4YSXAAIA4wgCg5kMAAAAAAICORAGgy0PICSXAAIA4wgCg5kMAAAAAAICORAGgy0N+siTAAIA4wgCg5kMAAAAAAICORAGgy0MXXCTAAIA4wgCg5kMAAAAAAICORAGgy0OUBiTAAIA4wgCg5kMAAAAAAICORAGgy0PysSPAAIA4wgCg5kMAAAAAAICORAGgy0MwXiPAAIA4wgCg5kMAAAAAAICORAGgy0NNCyPAAIA4wgCg5kMAAAAAAICORAGgy0NJuSLAAIA4wgCg5kMAAAAAAICORAGgy0MhaCLAAIA4wgCg5kMAAAAAAICORAGgy0PUFyLAAIA4wgCg5kMAAAAAAICORAGgy0NiyCHAAIA4wgCg5kMAAAAAAICORAGgy0PJeSHAAIA4wgCg5kMAAAAAAICORAGgy0MILCHAAIA4wgCg5kMAAAAAAICORAGgy0Md3yDAAIA4wgCg5kMAAAAAAICORAGgy0MIkyDAAIA4wgCg5kMAAAAAAICORAGgy0PIRyDAAIA4wgCg5kMAAAAAAICORAGgy0Na/R/AAIA4wgCg5kMAAAAAAICORAGgy0O+sx/AAIA4wgCg5kMAAAAAAICORAGgy0P0ah/AAIA4wgCg5kMAAAAAAICORAGgy0P5Ih/AAIA4wgCg5kMAAAAABIWORBO0y0Mm2h7AAIA4wgCg5kMAAAAACYqORCTIy0Mikh7AAIA4wgCg5kMAAAAADY+ORDbcy0PpSh7AAIA4wgCg5kMAAAAAEpSOREjwy0N8BB7AAIA4wgCg5kMAAAAAFpmORFoEzEPZvh3AAIA4wgCg5kMAAAAAAKCORAAgzEN7eR3AAIA4wgCg5kMAAAAAAKCORAAgzEO0Nh3AAIA4wgCg5kMAAAAAAKCORAAgzEO09BzAAIA4wgCg5kMAAAAAAKCORAAgzEN6sxzAAIA4wgCg5kMAAAAAAKCORAAgzEMFcxzAAIA4wgCg5kMAAAAAAKCORAAgzENUMxzAAIA4wgCg5kMAAAAA8aSORIVHzENn7BvAAIA4wgCg5kMAAAAA4amORApvzEM8phvAAIA4wgCg5kMAAAAA0q6ORJCWzEPRYBvAAIA4wgCg5kMAAAAAw7OORBW+zEMmHBvAAIA4wgCg5kMAAAAAs7iORJrlzEM52BrAAIA4wgCg5kMAAAAAAMCORAAgzUNpkRrAAIA4wgCg5kMAAAAAAMCORAAgzUN0VhrAAIA4wgCg5kMAAAAAAMCORAAgzUM6HBrAAIA4wgCg5kMAAAAAAMCORAAgzUO64hnAAIA4wgCg5kMAAAAAAMCORAAgzUP0qRnAAIA4wgCg5kMAAAAAAMCORAAgzUPmcRnAAIA4wgCg5kMAAAAAAMCORAAgzUOPOhnAAIA4wgCg5kMAAAAAesuORPM2zUOlChnAAIA4wgCg5kMAAAAA89aOROZNzUNv2xjAAIA4wgCg5kMAAAAAbOKORNhkzUPvrBjAAIA4wgCg5kMAAAAA5u2ORMt7zUMifxjAAIA4wgCg5kMAAAAAAACPRACgzUMOVhjAAIA4wgCg5kMAAAAANQWPRH/ezUNfFBjAAIA4wgCg5kMAAAAAawqPRP4czkNi0xfAAIA4wgCg5kMAAAAAoA+PRHxbzkMVkxfAAIA4wgCg5kMAAAAA1RSPRPuZzkN3UxfAAIA4wgCg5kMAAAAAChqPRHrYzkOHFBfAAIA4wgCg5kMAAAAAACCPRAAgz0NN1BbAAIA4wgCg5kMAAAAANSuPRGk2z0OmqxbAAIA4wgCg5kMAAAAAajaPRNNMz0OrgxbAAIA4wgCg5kMAAAAAn0GPRD1jz0NaXBbAAIA4wgCg5kMAAAAA00yPRKd5z0OzNRbAAIA4wgCg5kMAAAAAAGCPRACgz0MYFRbAAIA4wgCg5kMAAAAAS2+PRMjIz0M37xXAAIA4wgCg5kMAAAAA


`.trim(),`

lJdWRBvq70PUiIW/zaxqQ9mOlkMAAAAAcF9WRHkt8ENQa4e/AGBtQz0GlkMAAAAAAABWRACg8ENuIIm/MxNwQ8l+lUMAAAAA3K1VRBLJ8EMgyYq/ZsZyQ3v4lEMAAAAAuVtVRCTy8ENwb4y/mnl1Q1RzlEMAAAAAlQlVRDYb8UNlE46/zSx4Q1Tvk0MAAAAAcrdUREdE8UMEtY+/AOB6Q3tsk0MAAAAATmVURFlt8UNTVJG/M5N9Q8nqkkMAAAAAAABURACg8UOq1JK/MyOAQz1qkkMAAAAAn4ZTRCTM8UNPLpS/zXyBQ9nqkUMAAAAAPg1TREf48UO6hZW/ZtaCQ5xskUMAAAAA3ZNSRGok8kPt2pa/ADCEQ4XvkEMAAAAAfBpSRI5Q8kPvLZi/momFQ5ZzkEMAAAAAAUBRRACg8kO145i/M+OGQ834j0MAAAAAUr1QRBu08kNGG5q/zTyIQyt/j0MAAAAApDpQRDbI8kOzUJu/ZpaJQ7AGj0MAAAAA9rdPRFHc8kP/g5y/APCKQ1yPjkMAAAAARzVPRGvw8kMvtZ2/mkmMQy8ZjkMAAAAAmbJORIYE80NI5J6/M6ONQymkjUMAAAAAAABORAAg80Nlv5+/zfyOQ0owjUMAAAAAx3NNREt280PG7KC/ZlaQQ5G9jEMAAAAAjedMRJbM80MbGKK/ALCRQwBMjEMAAAAAU1tMROEi9ENnQaO/mgmTQ5bbi0MAAAAAGs9LRCt59EOvaKS/M2OUQ1Jsi0MAAAAAAMBKRAAg9UNnuqS/zbyVQzX+ikMAAAAAklJKRLFb9UNeD6a/ZhaXQz+RikMAAAAAJOVJRGGX9UNYYqe/AHCYQ3ElikMAAAAAtndJRBLT9UNZs6i/msmZQ8m6iUMAAAAASApJRMIO9kNlAqq/MyObQ0hRiUMAAAAA2ZxIRHJK9kOCT6u/zXycQ+7oiEMAAAAAAABIRACg9kOFSqy/ZtadQ7qBiEMAAAAAAMBHRKsK90Ou762/ADCfQ64biEMAAAAAAIBHRFZ190Pskq+/momgQ8m2h0MAAAAAAEBHRADg90NFNLG/M+OhQwpTh0MAAAAAAABHRKtK+EO907K/zTyjQ3PwhkMAAAAAAMBGRFa1+ENbcbS/ZpakQwKPhkMAAAAAAIBGRAAg+UMjDba/APClQ7guhkMAAAAACvZFRPep+UOpI7e/mkmnQ5bPhUMAAAAAE2xFRO4z+kNtOLi/M6OoQ5pxhUMAAAAAHOJEROS9+kNyS7m/zfypQ8UUhUMAAAAAJVhERNtH+0O8XLq/ZlarQxe5hEMAAAAAAYBDRAAg/EOM5Lq/ALCsQ49ehEMAAAAAs2BDRFmI/EMTtby/mgmuQy8FhEMAAAAAZUFDRLLw/EPXg76/M2OvQ/asg0MAAAAAFyJDRAtZ/UPfUMC/zbywQ+NVg0MAAAAAyQJDRGTB/UMxHMK/ZhayQ/j/gkMAAAAAe+NCRL0p/kPS5cO/AHCzQzOrgkMAAAAAAMBCRACg/kNopsW/msm0Q5ZXgkMAAAAAW1pCRHiY/0P87Ma/MyO2Qx8FgkMAAAAAtfRBRHhIAET7Mci/zXy3Q8+zgUMAAAAAD49BRLXEAERodcm/Zta4Q6ZjgUMAAAAAaSlBRPFAAURHt8q/ADC6Q6QUgUMAAAAAAIBARAAQAkRkd8u/mom7Q8nGgEMAAAAA7lZARPGAAkThKM2/M+O8QxR6gEMAAAAA3C1AROLxAkTN2M6/zTy+Q4cugEMAAAAAygRARNNiA0Qth9C/Zpa/Q0LIf0MAAAAAuds/RMTTA0QFNNK/APDAQ8M1f0MAAAAAp7I/RLVEBERa39O/mknCQ5GlfkMAAAAAAIA/RADQBETVctW/M6PDQ64XfkMAAAAA3VM/RN3jBURz9da/zfzEQxmMfUMAAAAAuSc/RLn3BkSadti/ZlbGQ9ECfUMAAAAAlvs+RJYLCERN9tm/ALDHQ9d7fEMAAAAAc88+RHMfCUSMdNu/mgnJQyv3e0MAAAAAAYA+RAAQC0Qvc9y/M2PKQ810e0MAAAAAAYA+RBrjC0S/WN6/zbzLQ7z0ekMAAAAAAYA+RDO2DETPPOC/ZhbNQ/p2ekMAAAAAAYA+RE2JDURfH+K/AHDOQ4X7eUMAAAAAAYA+RGZcDkR0AOS/msnPQ16CeUMAAAAAAYA+RIAvD0QO4OW/MyPRQ4ULeUMAAAAAAYA+RABQEERanOe/zXzSQ/qWeEMAAAAAAYA+RGgIEUSGh+m/ZtbTQ7wkeEMAAAAAAYA+RNDAEUQ8ceu/ADDVQ820d0MAAAAAAYA+RDl5EkSAWe2/monWQytHd0MAAAAAAYA+RKExE0RUQO+/M+PXQ9fbdkMAAAAAAYA+RACQFEQAyPC/zTzZQ9FydkMAAAAAfbE+RAtMFUSjBfO/ZpbaQxkMdkMAAAAA+eI+RBUIFkTKQfW/APDbQ66ndUMAAAAAdRQ/RCDEFkR3fPe/mkndQ5FFdUMAAAAA8UU/RCuAF0Sutfm/M6PeQ8PldEMAAAAAbXc/RDY8GERy7fu/zfzfQ0KIdEMAAAAAAcA/RAFQGUSaCf6/ZlbhQw4tdEMAAAAAqypARFflGUQMYADAALDiQynUc0MAAAAAVpVARKx6GkSDugHAmgnkQ5F9c0MAAAAAAQBBRAEQG0QzFAPAM2PlQ0gpc0MAAAAAq2pBRFalG0QcbQTAzbzmQ0zXckMAAAAAVtVBRKs6HERCxQXAZhboQ56HckMAAAAAAUBCRADQHESmHAfAAHDpQz06ckMAAAAA+ptCRHhOHUQKcwjAmsnqQyvvcUMAAAAA9PdCRPDMHUSuyAnAMyPsQ2amcUMAAAAA7lNDRGhLHkSWHQvAzXztQ/BfcUMAAAAA6K9DRN/JHkTCcQzAZtbuQ8cbcUMAAAAAAEBERAGQH0Tvww3AADDwQ+zZcEMAAAAAC4lERHzjH0Q0Iw/AmonxQ16acEMAAAAAF9JERPY2IES8gRDAM+PyQx9dcEMAAAAAIhtFRHCKIESM3xHAzTz0Qy0icEMAAAAALWRFROrdIESlPBPAZpb1Q4npb0MAAAAAOK1FRGQxIUQJmRTAAPD2QzOzb0MAAAAAAQBGRACQIUQA9BXAmkn4Qyt/b0MAAAAAJThGRK+xIUQ5ZRfAM6P5Q3FNb0MAAAAASXBGRF7TIUS81RjAzfz6QwQeb0MAAAAAbahGRA71IUSLRRrAZlb8Q+XwbkMAAAAAkOBGRL0WIkSptBvAALD9QxTGbkMAAAAAAUBHRABQIkQ+KR3Amgn/Q5GdbkMAAAAAilRHRABQIkQ3nB7AmjEARFx3bkMAAAAAEmlHRABQIkSFDiDAZt4ARHVTbkMAAAAAm31HRABQIkQrgCHAM4sBRNsxbkMAAAAAJJJHRABQIkQq8SLAADgCRI8SbkMAAAAAraZHRABQIkSHYSTAzeQCRJH1bUMAAAAAAMBHRABQIkSW0yXAmpEDROHabUMAAAAAPg1IRABQIkQlXSfAZj4ERH/CbUMAAAAAfFpIRABQIkQO5ijAM+sERGqsbUMAAAAAuadIRABQIkRTbirAAJgFRKSYbUMAAAAA9/RIRABQIkT09SvAzUQGRCuHbUMAAAAAAIBJRABQIkS9lC3AmvEGRAB4bUMAAAAAorxJRABQIkQ9Fi/AZp4HRCNrbUMAAAAAQ/lJRABQIkQflzDAM0sIRJNgbUMAAAAA5TVKRABQIkRmFzLAAPgIRFJYbUMAAAAAh3JKRABQIkQSlzPAzaQJRF5SbUMAAAAAKa9KRABQIkQlFjXAmlEKRLhObUMAAAAAAQBLRABQIkTxmTbAZv4KRGBNbUMAAAAAoWFLRABQIkQxITjAM6sLRFZObUMAAAAAQcNLRABQIkTWpznAAFgMRJpRbUMAAAAA4iRMRABQIkTgLTvAzQQNRCtXbUMAAAAAgoZMRABQIkRPszzAmrENRApfbUMAAAAAAEBNRABQIkTDRT7AZl4ORDdpbUMAAAAA+KJNRGooIkRy8D/AMwsPRLJ1bUMAAAAA8AVORNQAIkRxmkHAALgPRHuEbUMAAAAA6GhORD3ZIUTAQ0PAzWQQRJGVbUMAAAAA4MtORKexIURe7ETAmhERRPaobUMAAAAA2C5PRBCKIURMlEbAZr4RRKi+bUMAAAAAAMBPRABQIUQdTUjAM2sSRKjWbUMAAAAAVfVPRFYlIUSLJ0hAABgTRPbwbUMAAAAAqipQRKv6IEQ0fUZAzcQTRJENbkMAAAAAAGBQRADQIESU00RAmnEURHssbkMAAAAAVZVQRFWlIESqKkNAZh4VRLJNbkMAAAAAqspQRKt6IER5gkFAM8sVRDdxbkMAAAAAAABRRABQIEQA2z9AAHgWRAqXbkMAAAAAfiJRRIFEIES/TT5AzSQXRCu/bkMAAAAA+0RRRAI5IEQswTxAmtEXRJrpbkMAAAAAeWdRRIItIERHNTtAZn4YRFYWb0MAAAAA94lRRAMiIEQSqjlAMysZRGBFb0MAAAAAAMBRRAAQIER3HjhAANgZRLh2b0MAAAAALfRRRNTbH0TPdDZAzYQaRF6qb0MAAAAAWShSRKenH0TpyzRAmjEbRFLgb0MAAAAAhlxSRHtzH0TIIzNAZt4bRJMYcEMAAAAAspBSRE4/H0RtfDFAM4scRCNTcEMAAAAA38RSRCILH0Tc1S9AADgdRACQcEMAAAAAAABTRADQHkTWLC5AzeQdRCvPcEMAAAAAJDhTRFGuHkSqmCxAmpEeRKQQcUMAAAAASHBTRKKMHkRGBStAZj4fRGpUcUMAAAAAbKhTRPNqHkSrcilAM+sfRH+acUMAAAAAkOBTRERJHkTd4CdAAJggROHicUMAAAAAAEBURAAQHkT5TyZAzUQhRJEtckMAAAAAzl5URKrcHURSpCRAmvEhRI96ckMAAAAAm31URFSpHUSN+SJAZp4iRNvJckMAAAAAaZxURP51HUSuTyFAM0sjRHUbc0MAAAAANrtURKdCHUS3ph9AAPgjRFxvc0MAAAAAA9pURFEPHUSr/h1AzaQkRJHFc0MAAAAAAQBVRADQHERZUxxAmlElRBQedEMAAAAAZSxVRIOYHERSshpAZv4lROV4dEMAAAAAylhVRAVhHEQ8EhlAM6smRATWdEMAAAAALoVVRIcpHEQbcxdAAFgnRHE1dUMAAAAAk7FVRAnyG0T01BVAzQQoRCuXdUMAAAAAAABWRACQG0RBNBRAmrEoRDP7dUMAAAAAbChWRA41G0RsfhJAZl4pRIlhdkMAAAAA11BWRBzaGkSqyRBAMwsqRC3KdkMAAAAAQ3lWRCl/GkQAFg9AALgqRB81d0MAAAAAr6FWRDckGkRxYw1AzWQrRF6id0MAAAAAG8pWREXJGUQCsgtAmhEsROwReEMAAAAAAABXRAFQGUSf/AlAZr4sRMeDeEMAAAAAFkFXRK/YGEQhUghAM2stRPD3eEMAAAAAK4JXRFxhGETPqAZAABguRGZueUMAAAAAQcNXRArqF0SwAAVAzcQuRCvneUMAAAAAVwRYRLdyF0TIWQNAmnEvRD1iekMAAAAAAIBYRACQFkT/uAFAZh4wRJ7fekMAAAAA2J1YRFBUFkT7CgBAM8swRExfe0MAAAAAsLtYRJ8YFkSIvPw/AHgxREjhe0MAAAAAidlYRO/cFUS+Zfk/zSQyRJFlfEMAAAAAYfdYRD6hFUSgEfY/mtEyRCnsfEMAAAAAORVZRI5lFUQ1wPI/Zn4zRA51fUMAAAAAAEBZRAAQFUQ7eu8/Mys0REIAfkMAAAAAAKBZRKt6FER4dew/ANg0RMONfkMAAAAAAABaRFXlE0Rjc+k/zYQ1RJEdf0MAAAAAAGBaRABQE0QHdOY/mjE2RK6vf0MAAAAAAMBaRKu6EkRvd+M/Zt42RAwigEMAAAAAACBbRFYlEkSmfeA/M4s3RGhtgEMAAAAAAIBbRACQEUS3ht0/ADg4ROy5gEMAAAAAfblbRIY/EURFXdo/zeQ4RJYHgUMAAAAA+fJbRAvvEETYNtc/mpE5RGZWgUMAAAAAdSxcRJCeEER5E9Q/Zj46RF6mgUMAAAAA8WVcRBZOEEQx89A/M+s6RH33gUMAAAAAAMBcRADQD0TsDs4/AJg7RMNJgkMAAAAA9P5cRKAyD0S5+so/zUQ8RC+dgkMAAAAA5z1dRD+VDkS36cc/mvE8RMPxgkMAAAAA23xdRN/3DUTv28Q/Zp49RH1Hg0MAAAAAzrtdRH5aDURs0cE/M0s+RF6eg0MAAAAAwfpdRB69DEQ4yr4/APg+RGb2g0MAAAAAAEBeRAAQDETy1Ls/zaQ/RJZPhEMAAAAAAEBeRDzMC0SnSrg/mlFAROyphEMAAAAAAEBeRHmIC0QQxLQ/Zv5ARGgFhUMAAAAAAEBeRLVEC0Q1QbE/M6tBRAxihUMAAAAAAEBeRPEAC0Qdwq0/AFhCRNe/hUMAAAAAAEBeRACQCkSnWqo/zQRDRMkehkMAAAAAAEBeRCFICkTz4qY/mrFDROF+hkMAAAAAAEBeREIACkQab6M/Zl5ERCHghkMAAAAAAEBeRGO4CUQj/58/MwtFRIdCh0MAAAAAAEBeRIRwCUQWk5w/ALhFRBSmh0MAAAAAAEBeRKUoCUT6Kpk/zWRGRMkKiEMAAAAAAEBeRADQCETq0pU/mhFHRKRwiEMAAAAAAEBeRADQCETAOpI/Zr5HRKbXiEMAAAAAAEBeRADQCES5po4/M2tIRM8/iUMAAAAAAEBeRADQCETZFos/ABhJRB+piUMAAAAAAEBeRADQCEQki4c/zcRJRJYTikMAAAAAAEBeRADQCESdA4Q/mnFKRDN/ikMAAAAAeg1eRJWnCES+WYA/Zh5LRPjrikMAAAAA89pdRCl/CEReaHk/M8tLRONZi0MAAAAAbKhdRL1WCETnJXI/AHhMRPbIi0MAAAAA5XVdRFIuCEQj7Go/zSRNRC85jEMAAAAAX0NdROYFCEQbu2M/mtFNRI+qjEMAAAAAAABdRAHQB0QNhFw/Zn5ORBcdjUMAAAAADSdcRAHQB0RsOFM/MytPRMWQjUMAAAAAGk5bRAHQB0Rv90k/ANhPRJoFjkMAAAAAJ3VaRAHQB0QnwUA/zYRQRJZ7jkMAAAAANJxZRAHQB0SllTc/mjFRRLjyjkMAAAAAAABYRAHQB0RTsiw/Zt5RRAJrj0MAAAAAtptWRAHQB0RrViI/M4tSRHPkj0MAAAAAbTdVRAHQB0QIBxg/ADhTRApfkEMAAAAAI9NTRAHQB0RExA0/zeRTRMnakEMAAAAA2W5SRAHQB0Q3jgM/mpFURK5XkUMAAAAAjwpRRAHQB0T2yfI+Zj5VRLrVkUMAAAAAAABPRAHQB0RWkNw+M+tVRO5UkkMAAAAA/NZNRHD6B0Rgy8c+AJhWREjVkkMAAAAA+K1MRN4kCER+IbM+zURXRMlWk0MAAAAA9IRLRExPCETMkp4+mvFXRHHZk0MAAAAA71tKRLp5CERiH4o+Zp5YRD9dlEMAAAAA6zJJRCikCESwjms+M0tZRDXilEMAAAAAAABIRADQCERS5UI+APhZRFJolUMAAAAAEuxGRHsgCUT0nxg+zaRaRJbvlUMAAAAAJdhFRPVwCUSiKN09mlFbRAB4lkMAAAAAN8RERHDBCUTvhIk9Zv5bRJEBl0MAAAAASbBDROsRCkStU9k8M6tcREqMl0MAAAAAAABCRACQCkQYfoW8AFhdRCkYmEMAAAAAIVhBRPi5CkR1KWG9zQReRC+lmEMAAAAAQ7BARPDjCkScWb+9mrFeRFwzmUMAAAAAZQhAROcNC0RD1wa+Zl5fRLDCmUMAAAAAhmA/RN83C0TsyS2+MwtgRCtTmkMAAAAAqLg+RNdhC0T+hFS+ALhgRM3kmkMAAAAAAAA+RAGQC0SkCHu+zWRhRJZ3m0MAAAAAHt49ROOxC0Toi5G+mhFiRIULnEMAAAAAPbw9RMXTC0Qnd6W+Zr5iRJygnEMAAAAAW5o9RKb1C0RPRrm+M2tjRNk2nUMAAAAAeXg9RIgXDESj+cy+ABhkRD3OnUMAAAAAAUA9RABQDER84eC+zcRkRMlmnkMAAAAAvDU9RBJ5DETG5fS+mnFlRHsAn0MAAAAAeCs9RCSiDEQ2ZwS/Zh5mRFSbn0MAAAAAMyE9RDbLDETdTQ6/M8tmRFQ3oEMAAAAA7hY9REf0DEQAJxi/AHhnRHvUoEMAAAAAqgw9RFkdDUTF8iG/zSRoRMlyoUMAAAAAAAA9RABQDUSNxyu/mtFoRD0SokMAAAAAgsg8RH6HDUTfNTW/qyZpRHTbnEMAAAAABJE8RPy+DURPMze/t8hoRAv8mUMAAAAAhlk8RHr2DUQBLTm/w2poRMkdl0MAAAAACSI8RPctDkT6Iju/zwxoRK5AlEMAAAAAAMA7RACQDkSgHz2/265nRLpkkUMAAAAAyqs7RDakDkSlCD+/5lBnRO2JjkMAAAAAlJc7RGy4DkQA7kC/8vJmREewi0MAAAAAXoM7RKLMDkS5z0K//pRmRMfXiEMAAAAAKG87RNjgDkTWrUS/CjdmRG8AhkMAAAAA81o7RA71DkRciEa/FdllRD0qg0MAAAAAAEA7RAAQD0RrX0i/IXtlRDNVgEMAAAAAGDU7RLswD0QobEq/LR1lRJ4Ce0MAAAAALyo7RHVRD0RgdUy/Ob9kRCRddUMAAAAARh87RC9yD0QZe06/RGFkRPi5b0MAAAAAXhQ7ROmSD0RYfVC/UANkRBoZakMAAAAAAAA7RADQD0TgqVK/XKVjRIp6ZEMAAAAAUOI6RLHtD0QXa1S/aEdjREjeXkMAAAAAn8Q6RGILEETpKFa/c+liRFREWUMAAAAA7qY6RBMpEERd41e/f4tiRK2sU0MAAAAAPYk6RMRGEER5mlm/iy1iRFQXTkMAAAAAjGs6RHVkEERBTlu/l89hREmESEMAAAAAAEA6RAGQEEQa+Vy/onFhRIzzQkMAAAAAqyo6RKyaEETzkF6/rhNhRBxlPUMAAAAAVhU6RFalEESLJWC/urVgRPvYN0MAAAAAAAA6RAGwEETntmG/xldgRCdPMkMAAAAAq+o5RKu6EEQMRWO/0flfRKHHLEMAAAAAVtU5RFXFEEQC0GS/3ZtfRGlCJ0MAAAAAAMA5RADQEETNV2a/6T1fRH+/IUMAAAAAAMA5RH/bEESBHGi/9d9eROM+HEMAAAAAAMA5RP7mEEQV3mm/AYJeRJTAFkMAAAAAAMA5RH7yEESQnGu/DCReRJNEEUMAAAAAAMA5RP39EET4V22/GMZdRODKC0MAAAAAAMA5RAAQEUSoHm+/JGhdRHtTBkMAAAAAAMA5RAAQEUQIu3C/MApdRGTeAEMAAAAAAMA5RAAQEURpVHK/O6xcRDXX9kIAAAAAAMA5RAAQEUTR6nO/R05cRD3260IAAAAAAMA5RAAQEURGfnW/U/BbROIZ4UIAAAAAAMA5RAAQEUTPDne/X5JbRCJC1kIAAAAAAMA5RAAQEURxnHi/ajRbRP1uy0IAAAAAtbQ5RJcmEURLM3q/dtZaRHSgwEIAAAAAaqk5RC09EURKx3u/gnhaRIfWtUIAAAAAH545RMRTEUR0WH2/jhpaRDYRq0IAAAAA1JI5RFtqEUTP5n6/mbxZRIBQoEIAAAAAAYA5RACQEUR2PIC/pV5ZRGaUlUIAAAAAAYA5RACQEURo/IC/sQBZROjcikIAAAAAAYA5RACQEUT6uoG/vaJYRAUqgEIAAAAAAYA5RACQEUQweIK/yERYRHv3akIAAAAAAYA5RACQEUQNNIO/1OZXRCSkVUIAAAAAAYA5RACQEUSU7oO/4IhXRARaQEIAAAAAAYA5RACQEUTHp4S/7CpXRBwZK0IAAAAAAYA5RACQEUSqX4W/98xWRGvhFUIAAAAAAYA5RACQEURAFoa/A29WRPGyAEIAAAAAAYA5RACQEUSKy4a/DxFWRFwb10EAAAAAAYA5RACQEUSNf4e/G7NVREbjrEEAAAAAAYA5RACQEURLMoi/JlVVRJ69gkEAAAAAAYA5RACQEUTH44i/MvdURMlUMUEAAAAAAYA5RACQEUQElIm/PplURGamukAAAAAAAYA5RACQEUQEQ4q/SjtURKhnFz8AAAAAAYA5RACQEUTK8Iq/Vt1TRMKClMAAAAAAAYA5RACQEURZnYu/YX9TRF/UHcEAAAAAAYA5RACQEUSzSIy/bSFTRIBCccEAAAAAAYA5RACQEUTc8oy/ecNSROJFosEAAAAAAYA5RACQEUTWm42/hWVSRBXYy8EAAAAAAYA5RACQEUSkQ46/kAdSRNpX9cEAAAAAAYA5RACQEURI6o6/nKlRRJhiD8IAAAAAAYA5RACQEUTFj4+/qEtRRAwQJMIAAAAAAYA5RACQEUQeNJC/tO1QREi0OMIAAAAAAYA5RACQEURW15C/v49QRE1PTcIAAAAAAYA5RACQEURueZG/yzFQRBvhYcIAAAAAAYA5RACQEURqGpK/19NPRLJpdsIAAAAAAYA5RACQEURMupK/43VPRIh0hcIAAAAAAYA5RACQEUQWWZO/AIA4wgCg5kMAAAAAAYA5RACQEUTM9pO/AIA4wgCg5kMAAAAAAYA5RACQEURvk5S/AIA4wgCg5kMAAAAAAYA5RACQEUQDL5W/AIA4wgCg5kMAAAAAAYA5RACQEUSJyZW/AIA4wgCg5kMAAAAAAYA5RACQEUQEY5a/AIA4wgCg5kMAAAAAAYA5RACQEUR3+5a/AIA4wgCg5kMAAAAAAYA5RJKbEUT1mpe/AIA4wgCg5kMAAAAAAYA5RCOnEURvOZi/AIA4wgCg5kMAAAAAAYA5RLSyEUTo1pi/AIA4wgCg5kMAAAAAAYA5REW+EURic5m/AIA4wgCg5kMAAAAAAYA5RAHQEUT5Epq/AIA4wgCg5kMAAAAAAYA5RAHQEUTypZq/AIA4wgCg5kMAAAAAAYA5RAHQEUT0N5u/AIA4wgCg5kMAAAAAAYA5RAHQEUQAyZu/AIA4wgCg5kMAAAAAAYA5RAHQEUQZWZy/AIA4wgCg5kMAAAAAAYA5RAHQEURC6Jy/AIA4wgCg5kMAAAAAAYA5RAHQEUR9dp2/AIA4wgCg5kMAAAAAAYA5RAHQEUTMA56/AIA4wgCg5kMAAAAAAYA5RAHQEUQxkJ6/AIA4wgCg5kMAAAAAAYA5RAHQEUSvG5+/AIA4wgCg5kMAAAAAAYA5RAHQEURHpp+/AIA4wgCg5kMAAAAAAYA5RAHQEUT9L6C/AIA4wgCg5kMAAAAAAYA5RAHQEUTSuKC/AIA4wgCg5kMAAAAAAYA5RAHQEUTIQKG/AIA4wgCg5kMAAAAAAYA5RAHQEUTix6G/AIA4wgCg5kMAAAAAAYA5RAHQEUQiTqK/AIA4wgCg5kMAAAAAAYA5RAHQEUSJ06K/AIA4wgCg5kMAAAAAAYA5RAHQEUQbWKO/AIA4wgCg5kMAAAAAAYA5RAHQEUTZ26O/AIA4wgCg5kMAAAAAAYA5RAHQEUTFXqS/AIA4wgCg5kMAAAAAAYA5RAHQEUTh4KS/AIA4wgCg5kMAAAAAAYA5RAHQEUQwYqW/AIA4wgCg5kMAAAAAAYA5RAHQEUS04qW/AIA4wgCg5kMAAAAAAYA5RAHQEURuYqa/AIA4wgCg5kMAAAAAAYA5RAHQEURh4aa/AIA4wgCg5kMAAAAAAYA5RAHQEUSOX6e/AIA4wgCg5kMAAAAAAYA5RAHQEUT43Ke/AIA4wgCg5kMAAAAAAYA5RAHQEUShWai/AIA4wgCg5kMAAAAAAYA5RAHQEUSK1ai/AIA4wgCg5kMAAAAAAYA5RAHQEUS2UKm/AIA4wgCg5kMAAAAAAYA5RAHQEUQny6m/AIA4wgCg5kMAAAAAAYA5RAHQEUTeRKq/AIA4wgCg5kMAAAAAAYA5RAHQEUTevaq/AIA4wgCg5kMAAAAAAYA5RAHQEUQoNqu/AIA4wgCg5kMAAAAAAYA5RMzjEUQRtqu/AIA4wgCg5kMAAAAAAYA5RJf3EURINay/AIA4wgCg5kMAAAAAAYA5RGMLEkTQs6y/AIA4wgCg5kMAAAAAAYA5RC4fEkSpMa2/AIA4wgCg5kMAAAAAAYA5RPkyEkTWrq2/AIA4wgCg5kMAAAAAAYA5RABQEkTpLq6/AIA4wgCg5kMAAAAAAYA5RABQEkRRo66/AIA4wgCg5kMAAAAAAYA5RABQEkQSF6+/AIA4wgCg5kMAAAAAAYA5RABQEkQuiq+/AIA4wgCg5kMAAAAAAYA5RABQEkSn/K+/AIA4wgCg5kMAAAAAAYA5RABQEkR/brC/AIA4wgCg5kMAAAAAAYA5RABQEkS337C/AIA4wgCg5kMAAAAAI5c5RABQEkRkerG/AIA4wgCg5kMAAAAARK45RABQEkR2FLK/AIA4wgCg5kMAAAAAZsU5RABQEkTurbK/AIA4wgCg5kMAAAAAiNw5RABQEkTPRrO/AIA4wgCg5kMAAAAAAAA6RABQEkSg9bO/AIA4wgCg5kMAAAAAAAA6RABQEkQZY7S/AIA4wgCg5kMAAAAAAAA6RABQEkQC0LS/AIA4wgCg5kMAAAAAAAA6RABQEkRcPLW/AIA4wgCg5kMAAAAAAAA6RABQEkQqqLW/AIA4wgCg5kMAAAAAAAA6RABQEkRrE7a/AIA4wgCg5kMAAAAAAAA6RABQEkQjfra/AIA4wgCg5kMAAAAASws6RABQEkQC/ba/AIA4wgCg5kMAAAAAlxY6RABQEkRbe7e/AIA4wgCg5kMAAAAA4iE6RABQEkQv+be/AIA4wgCg5kMAAAAALS06RABQEkSBdri/AIA4wgCg5kMAAAAAAEA6RABQEkQlAbm/AIA4wgCg5kMAAAAApVQ6RABQEkSijrm/AIA4wgCg5kMAAAAAS2k6RABQEkSiG7q/AIA4wgCg5kMAAAAA8H06RABQEkQoqLq/AIA4wgCg5kMAAAAAlZI6RABQEkQ2NLu/AIA4wgCg5kMAAAAAOqc6RABQEkTMv7u/AIA4wgCg5kMAAAAAAcA6RABQEkSIUry/AIA4wgCg5kMAAAAAAcA6RABQEkQyt7y/AIA4wgCg5kMAAAAAAcA6RABQEkRqG72/AIA4wgCg5kMAAAAAAcA6RABQEkQzf72/AIA4wgCg5kMAAAAAAcA6RABQEkSO4r2/AIA4wgCg5kMAAAAAAcA6RABQEkR8Rb6/AIA4wgCg5kMAAAAAAcA6RABQEkT/p76/AIA4wgCg5kMAAAAAAcA6RABQEkQYCr+/AIA4wgCg5kMAAAAAAcA6RABQEkTJa7+/AIA4wgCg5kMAAAAAAcA6RABQEkQTzb+/AIA4wgCg5kMAAAAAAcA6RABQEkT3LcC/AIA4wgCg5kMAAAAAAcA6RABQEkR4jsC/AIA4wgCg5kMAAAAAi+A6RABQEkStKsG/AIA4wgCg5kMAAAAAFgE7RABQEkSCxsG/AIA4wgCg5kMAAAAAoSE7RABQEkT5YcK/AIA4wgCg5kMAAAAALEI7RABQEkQT/cK/AIA4wgCg5kMAAAAAAIA7RABQEkT3zcO/AIA4wgCg5kMAAAAAAIA7RABQEkQ1LMS/AIA4wgCg5kMAAAAAAIA7RABQEkQdisS/AIA4wgCg5kMAAAAAAIA7RABQEkSw58S/AIA4wgCg5kMAAAAAAIA7RABQEkTwRMW/AIA4wgCg5kMAAAAAAIA7RABQEkTdocW/AIA4wgCg5kMAAAAAAIA7RABQEkR6/sW/AIA4wgCg5kMAAAAAAKA7RABQEkT5lca/AIA4wgCg5kMAAAAAAMA7RABQEkQrLce/AIA4wgCg5kMAAAAAAOA7RABQEkQRxMe/AIA4wgCg5kMAAAAAAAA8RABQEkSuWsi/AIA4wgCg5kMAAAAAACA8RABQEkQE8ci/AIA4wgCg5kMAAAAAAEA8RABQEkQUh8m/AIA4wgCg5kMAAAAAgEs8RABQEkTy9sm/AIA4wgCg5kMAAAAA/1Y8RABQEkSPZsq/AIA4wgCg5kMAAAAAfmI8RABQEkTq1cq/AIA4wgCg5kMAAAAA/W08RABQEkQHRcu/AIA4wgCg5kMAAAAAAIA8RABQEkTzv8u/AIA4wgCg5kMAAAAAep88RABQEkSLU8y/AIA4wgCg5kMAAAAA9L48RABQEkTo5sy/AIA4wgCg5kMAAAAAbt48RABQEkQNes2/AIA4wgCg5kMAAAAA5/08RABQEkT9DM6/AIA4wgCg5kMAAAAAYR09RABQEkS3n86/AIA4wgCg5kMAAAAAAUA9RABQEkQROM+/AIA4wgCg5kMAAAAATEs9RABQEkQfpc+/AIA4wgCg5kMAAAAAl1Y9RABQEkT+EdC/AIA4wgCg5kMAAAAA4mE9RABQEkSvftC/AIA4wgCg5kMAAAAALm09RABQEkQ069C/AIA4wgCg5kMAAAAAAIA9RABQEkR0ZdG/AIA4wgCg5kMAAAAAV7M9RABQEkSMG9K/AIA4wgCg5kMAAAAAreY9RABQEkR90dK/AIA4wgCg5kMAAAAAAxo+RABQEkRIh9O/AIA4wgCg5kMAAAAAWU0+RABQEkTwPNS/AIA4wgCg5kMAAAAAsIA+RABQEkR38tS/AIA4wgCg5kMAAAAAAMA+RABQEkTtvdW/AIA4wgCg5kMAAAAAZew+ROdEEkSZaNa/AIA4wgCg5kMAAAAAyhg/RM45EkQqE9e/AIA4wgCg5kMAAAAAL0U/RLUuEkSjvde/AIA4wgCg5kMAAAAAk3E/RJsjEkQGaNi/AIA4wgCg5kMAAAAAAcA/RAAQEkTKUtm/AIA4wgCg5kMAAAAAh/I/ROUFEkT+B9q/AIA4wgCg5kMAAAAADiVARMr7EUQjvdq/AIA4wgCg5kMAAAAAlVdARLDxEUQ7ctu/AIA4wgCg5kMAAAAAHIpARJXnEURJJ9y/AIA4wgCg5kMAAAAAorxARHrdEURO3Ny/AIA4wgCg5kMAAAAAAQBBRAHQEUQPsd2/AIA4wgCg5kMAAAAAuyBBRAHQEUR5Qt6/AIA4wgCg5kMAAAAA

`.trim(),`

AICyRAEg3UO6j+4/AIA4wgCg5kMAAAAAAICyRAEg3UMXxvE/AIA4wgCg5kMAAAAAAICyRAEg3UP4+PQ/AIA4wgCg5kMAAAAAAICyRAEg3UNZKPg/AIA4wgCg5kMAAAAAAICyRAEg3UM2VPs/AIA4wgCg5kMAAAAAAICyRAEg3UOKfP4/AIA4wgCg5kMAAAAAAICyRAEg3UOo0ABAAIA4wgCg5kMAAAAAwIWyRAfE3EOqVwJAAIA4wgCg5kMAAAAAgIuyRA1o3EPl3ANAAIA4wgCg5kMAAAAAP5GyRBMM3ENWYAVAAIA4wgCg5kMAAAAA/5ayRBmw20P84QZAAIA4wgCg5kMAAAAAAaCyRAAg20MkWghAAIA4wgCg5kMAAAAA37SyREP22kPp/AlAAIA4wgCg5kMAAAAAvsmyRIbM2kPKnQtAAIA4wgCg5kMAAAAAnN6yRMii2kPDPA1AAIA4wgCg5kMAAAAAe/OyRAt52kPU2Q5AAIA4wgCg5kMAAAAAWQizRE5P2kP5dBBAAIA4wgCg5kMAAAAAACCzRAAg2kNoEBJAAIA4wgCg5kMAAAAA2DCzRKLc2UNYmhNAAIA4wgCg5kMAAAAAr0GzREOZ2UNdIhVAAIA4wgCg5kMAAAAAh1KzROVV2UN1qBZAAIA4wgCg5kMAAAAAX2OzRIcS2UOfLBhAAIA4wgCg5kMAAAAAAICzRACg2EN2rRlAAIA4wgCg5kMAAAAAI4WzRHeL2EOSMBtAAIA4wgCg5kMAAAAARYqzRO922EO7sRxAAIA4wgCg5kMAAAAAZ4+zRGZi2EPuMB5AAIA4wgCg5kMAAAAAiZSzRN1N2EMsrh9AAIA4wgCg5kMAAAAAq5mzRFQ52EN1KSFAAIA4wgCg5kMAAAAAAKCzRAEg2EM0oiJAAIA4wgCg5kMAAAAAjbCzRAEg2EMZLSRAAIA4wgCg5kMAAAAAGsGzRAEg2EP/tSVAAIA4wgCg5kMAAAAAqNGzRAEg2EPkPCdAAIA4wgCg5kMAAAAANeKzRAEg2EPKwShAAIA4wgCg5kMAAAAAAAC0RAEg2EP/TypAAIA4wgCg5kMAAAAAFA+0RAEg2EMt0CtAAIA4wgCg5kMAAAAAKB60RAEg2ENaTi1AAIA4wgCg5kMAAAAAPC20RAEg2EOGyi5AAIA4wgCg5kMAAAAAUTy0RAEg2EOxRDBAAIA4wgCg5kMAAAAAZUu0RAEg2EPcvDFAAIA4wgCg5kMAAAAAAGC0RAEg2ENzNjNAAIA4wgCg5kMAAAAALnC0RCZL2ENuvjRAAIA4wgCg5kMAAAAAXIC0REt22ENhRDZAAIA4wgCg5kMAAAAAipC0RHCh2ENOyDdAAIA4wgCg5kMAAAAAuaC0RJbM2EM0SjlAAIA4wgCg5kMAAAAAAMC0RAAg2UNi4jpAAIA4wgCg5kMAAAAA5sm0RMOW2UPQgDxAAIA4wgCg5kMAAAAAzNO0RIcN2kMuHT5AAIA4wgCg5kMAAAAAsd20REqE2kN7tz9AAIA4wgCg5kMAAAAAl+e0RA372kO5T0FAAIA4wgCg5kMAAAAAfPG0RNFx20Pr5UJAAIA4wgCg5kMAAAAAAAC1RAAg3EM6lERAAIA4wgCg5kMAAAAAAAC1RKsK3UM9W0ZAAIA4wgCg5kMAAAAAAAC1RFb13UMfIEhAAIA4wgCg5kMAAAAAAAC1RADg3kPUPEjAAIA4wgCg5kMAAAAAAAC1RKvK30MtfEbAAIA4wgCg5kMAAAAAAAC1RFW14EOhvUTAAIA4wgCg5kMAAAAAAAC1RACg4UMqAUPAAIA4wgCg5kMAAAAAAAC1ROzK4kNOKUHAAIA4wgCg5kMAAAAAAAC1RNj140OUUz/AAIA4wgCg5kMAAAAAAAC1RMQg5UP3fz3AAIA4wgCg5kMAAAAAAAC1RLBL5kN2rjvAAIA4wgCg5kMAAAAAAAC1RAAg6EMLkznAAIA4wgCg5kMAAAAAAAC1RKeX6UMnozfAAIA4wgCg5kMAAAAAAAC1RE4P60NqtTXAAIA4wgCg5kMAAAAAAAC1RPWG7EPQyTPAAIA4wgCg5kMAAAAAAAC1RJz+7UNV4DHAAIA4wgCg5kMAAAAAAAC1REN270P3+C/AAIA4wgCg5kMAAAAAAAC1RAEg8UOW/i3AAIA4wgCg5kMAAAAABbe0RN1n80PfiCvAAIA4wgCg5kMAAAAACW60RLmv9UO3FSnAAIA4wgCg5kMAAAAADiW0RJX390MXpSbAAIA4wgCg5kMAAAAAEtyzRHE/+kP4NiTAAIA4wgCg5kMAAAAAAGCzRAAg/kMN+yDAAIA4wgCg5kMAAAAA3Q2zRKCR/0NN1R7AAIA4wgCg5kMAAAAAubuyRKCBAES0sRzAAIA4wgCg5kMAAAAAlmmyRHA6AUQ6kBrAAIA4wgCg5kMAAAAAcheyREDzAUTXcBjAAIA4wgCg5kMAAAAAT8WxRBCsAkSEUxbAAIA4wgCg5kMAAAAAAWCxRACQA0QxAxTAAIA4wgCg5kMAAAAAqPGwRHMfBEQk2xHAAIA4wgCg5kMAAAAAUIOwROWuBEQbtQ/AAIA4wgCg5kMAAAAA+BSwRFg+BUQOkQ3AAIA4wgCg5kMAAAAAoKavRMvNBUT0bgvAAIA4wgCg5kMAAAAAAeCuRADQBkQ0jAjAAIA4wgCg5kMAAAAAOEmuRMlmB0RgKgbAAIA4wgCg5kMAAAAAb7KtRJL9B0SiygPAAIA4wgCg5kMAAAAAphutRFuUCETubAHAAIA4wgCg5kMAAAAA3YSsRCQrCUR3Iv6/AIA4wgCg5kMAAAAAFO6rRO3BCUQBb/m/AIA4wgCg5kMAAAAAASCrRACQCkTl3PO/AIA4wgCg5kMAAAAAszKqRFywCkQCPe6/AIA4wgCg5kMAAAAAZUWpRLjQCkT3oei/AIA4wgCg5kMAAAAAF1ioRBTxCkSlC+O/AIA4wgCg5kMAAAAAymqnRHARC0Tued2/AIA4wgCg5kMAAAAAAKClRABQC0TuuNS/AIA4wgCg5kMAAAAAPSmlRABQC0RX7dC/AIA4wgCg5kMAAAAAerKkRABQC0Q+JM2/AIA4wgCg5kMAAAAAtjukRABQC0SVXcm/AIA4wgCg5kMAAAAA88SjRABQC0RMmcW/AIA4wgCg5kMAAAAAME6jRABQC0RW18G/AIA4wgCg5kMAAAAAAKCiRABQC0SbS72/AIA4wgCg5kMAAAAADVuiRABQC0QJRbq/AIA4wgCg5kMAAAAAGhaiRABQC0RCQLe/AIA4wgCg5kMAAAAAJ9GhRABQC0Q6PbS/AIA4wgCg5kMAAAAAM4yhRABQC0ToO7G/AIA4wgCg5kMAAAAAQEehRABQC0RCPK6/AIA4wgCg5kMAAAAAAAChRABQC0T4Nau/AIA4wgCg5kMAAAAA3MagRABQC0TEY6i/AIA4wgCg5kMAAAAAt42gRABQC0QPk6W/AIA4wgCg5kMAAAAAk1SgRABQC0TRw6K/AIA4wgCg5kMAAAAAbhugRABQC0QB9p+/AIA4wgCg5kMAAAAAAMCfRABQC0RTspy/AIA4wgCg5kMAAAAAC5GfRJFFC0S8Apq/AIA4wgCg5kMAAAAAFmKfRCI7C0RwVJe/AIA4wgCg5kMAAAAAIjOfRLIwC0Rop5S/AIA4wgCg5kMAAAAALQSfREMmC0Sc+5G/AIA4wgCg5kMAAAAAONWeRNQbC0QDUY+/AIA4wgCg5kMAAAAAAKCeRAAQC0TMkYy/AIA4wgCg5kMAAAAAeW2eRKLMCkS0q4m/AIA4wgCg5kMAAAAA8zqeREOJCkTNxoa/AIA4wgCg5kMAAAAAbAieROVFCkQP44O/AIA4wgCg5kMAAAAA5dWdRIcCCkRwAIG/AIA4wgCg5kMAAAAAAICdRACQCURoA3u/AIA4wgCg5kMAAAAAiEedRDNxCUSTbHW/AIA4wgCg5kMAAAAADw+dRGZSCUS712+/AIA4wgCg5kMAAAAAl9acRJgzCUTVRGq/AIA4wgCg5kMAAAAAHp6cRMsUCUTTs2S/AIA4wgCg5kMAAAAApmWcRP71CESpJF+/AIA4wgCg5kMAAAAAACCcRADQCESZPFm/AIA4wgCg5kMAAAAAy92bRLp3CETA6lK/AIA4wgCg5kMAAAAAlpubRHMfCETsmky/AIA4wgCg5kMAAAAAYVmbRCzHB0QPTUa/AIA4wgCg5kMAAAAALBebROZuB0QbAUC/AIA4wgCg5kMAAAAAAKCaRADQBkSR8De/AIA4wgCg5kMAAAAADkWaRA11BkR0KTG/AIA4wgCg5kMAAAAAG+qZRBsaBkReZCq/AIA4wgCg5kMAAAAAKY+ZRCi/BURHoSO/AIA4wgCg5kMAAAAANjSZRDZkBUQo4By/AIA4wgCg5kMAAAAARNmYREQJBUT6IBa/AIA4wgCg5kMAAAAAAGCYRACQBEQRjg6/AIA4wgCg5kMAAAAAdi+YROwuBESkWwi/AIA4wgCg5kMAAAAA7P6XRNjNA0TUKgK/AIA4wgCg5kMAAAAAYs6XRMRsA0Qy9/e+AIA4wgCg5kMAAAAA2J2XRLALA0TWm+u+AIA4wgCg5kMAAAAAAECXRABQAkRIy9u+AIA4wgCg5kMAAAAAdxOXRAjtAUT1ec++AIA4wgCg5kMAAAAA7eaWRBCKAUSZK8O+AIA4wgCg5kMAAAAAZLqWRBgnAUQp4La+AIA4wgCg5kMAAAAA242WRCDEAESbl6q+AIA4wgCg5kMAAAAAUmGWRChhAETpUZ6+AIA4wgCg5kMAAAAAACCWRACg/0NhcZC+AIA4wgCg5kMAAAAARPCVRFtg/0NLAYa+AIA4wgCg5kMAAAAAiMCVRLUg/0OwJne+AIA4wgCg5kMAAAAAzJCVRBDh/kMPT2K+AIA4wgCg5kMAAAAAEGGVRGqh/kO3e02+AIA4wgCg5kMAAAAAVDGVRMVh/kOrrDi+AIA4wgCg5kMAAAAAAACVRAAg/kPzyiO+AIA4wgCg5kMAAAAACI2URBfH/EMN8QW+AIA4wgCg5kMAAAAAEBqURC5u+0MIQNC9AIA4wgCg5kMAAAAAF6eTREUV+kMTsJS9AIA4wgCg5kMAAAAAHzSTRFy8+ENQZTK9AIA4wgCg5kMAAAAAAICSRACg9kPp3BK8AIA4wgCg5kMAAAAAyXqSREN29kOCbUA8AIA4wgCg5kMAAAAAkXWSRIZM9kPu1gQ9AIA4wgCg5kMAAAAAWXCSRMgi9kNxe1k9AIA4wgCg5kMAAAAAIWuSRAv59UN0BJc9AIA4wgCg5kMAAAAA6mWSRE7P9UOnP8E9AIA4wgCg5kMAAAAAAGCSRACg9UNZvOs9AIA4wgCg5kMAAAAAPyKSRPyo9EP25Q8+AIA4wgCg5kMAAAAAfuSRRPex80PA5Sk+AIA4wgCg5kMAAAAAvaaRRPO68kNb3UM+AIA4wgCg5kMAAAAA+2iRRO7D8UOazF0+AIA4wgCg5kMAAAAAAACRRAAg8EP6VHs+AIA4wgCg5kMAAAAA5fqQRE3O70OTOok+AIA4wgCg5kMAAAAAyvWQRJl870PMxpQ+AIA4wgCg5kMAAAAArvCQROUq70MgT6A+AIA4wgCg5kMAAAAAk+uQRDHZ7kOG06s+AIA4wgCg5kMAAAAAeOaQRH2H7kPzU7c+AIA4wgCg5kMAAAAAAOCQRAAg7kOrE8M+AIA4wgCg5kMAAAAA7smQRGFZ7UNit88+AIA4wgCg5kMAAAAA3bOQRMKS7ENzVtw+AIA4wgCg5kMAAAAAy52QRCTM60PH8Og+AIA4wgCg5kMAAAAAuYeQRIUF60NIhvU+AIA4wgCg5kMAAAAAAGCQRAGg6UPZzAE/AIA4wgCg5kMAAAAA5VWQRL0m6UOzyQc/AIA4wgCg5kMAAAAAykuQRHqt6EMcxA0/AIA4wgCg5kMAAAAAr0GQRDY06EMLvBM/AIA4wgCg5kMAAAAAlDeQRPO650N1sRk/AIA4wgCg5kMAAAAAeS2QRK9B50NPpB8/AIA4wgCg5kMAAAAAACCQRACg5kMlwSU/AIA4wgCg5kMAAAAAACCQRJx05kOdbSs/AIA4wgCg5kMAAAAAACCQRDhJ5kOAFzE/AIA4wgCg5kMAAAAAACCQRNQd5kPFvjY/AIA4wgCg5kMAAAAAACCQRHHy5UNjYzw/AIA4wgCg5kMAAAAAACCQRACg5UO3OUI/AIA4wgCg5kMAAAAA2S6QRKYB5UMlvkg/AIA4wgCg5kMAAAAAsT2QRExj5ENmP08/AIA4wgCg5kMAAAAAiUyQRPPE40NsvVU/AIA4wgCg5kMAAAAAYluQRJkm40MqOFw/AIA4wgCg5kMAAAAAOmqQRD+I4kOUr2I/AIA4wgCg5kMAAAAAAICQRACg4UOzn2k/AIA4wgCg5kMAAAAAToWQRMmK4UNgQm8/AIA4wgCg5kMAAAAAnIqQRJJ14UPp4XQ/AIA4wgCg5kMAAAAA6Y+QRFtg4UNEfno/AIA4wgCg5kMAAAAAN5WQRCRL4UOzC4A/AIA4wgCg5kMAAAAAhZqQRO014UOi1oI/AIA4wgCg5kMAAAAAAKCQRAAg4UPQoIU/AIA4wgCg5kMAAAAAgKuQRAit4ENKpog/AIA4wgCg5kMAAAAA/7aQRBA64EP4qYs/AIA4wgCg5kMAAAAAfsKQRBfH30PRq44/AIA4wgCg5kMAAAAA/c2QRB9U30PQq5E/AIA4wgCg5kMAAAAAAOCQRACg3kPu15Q/AIA4wgCg5kMAAAAATv+QRGVh3kMHB5g/AIA4wgCg5kMAAAAAnB6RRMki3kMYNJs/AIA4wgCg5kMAAAAA6j2RRC3k3UMYX54/AIA4wgCg5kMAAAAAOF2RRJGl3UMBiKE/AIA4wgCg5kMAAAAAhnyRRPZm3UPMrqQ/AIA4wgCg5kMAAAAAAKCRRAEg3UNZ5Kc/AIA4wgCg5kMAAAAAiMeRRNTy3EO+IKs/AIA4wgCg5kMAAAAAD++RRKbF3EPkWq4/AIA4wgCg5kMAAAAAlxaSRHmY3EPEkrE/AIA4wgCg5kMAAAAAHj6SRExr3ENXyLQ/AIA4wgCg5kMAAAAAAICSRAAg3EPTX7g/AIA4wgCg5kMAAAAAHIWSRAAg3EPHDbs/M7Mtwpaf5UMAAAAAN4qSRAAg3EORub0/ZuYiwlKg5EMAAAAAUo+SRAAg3EMqY8A/mhkYwjWi40MAAAAAbZSSRAAg3EOOCsM/zUwNwj+l4kMAAAAAiJmSRAAg3EO2r8U/AIACwnGp4UMAAAAAAKCSRAAg3EOmV8g/Zmbvwcmu4EMAAAAAlruSRMzd20NUSss/zczZwUi130MAAAAALNeSRJeb20OWOs4/MzPEwe683kMAAAAAwvKSRGJZ20NlKNE/mpmuwbrF3UMAAAAAWQ6TRC0X20O6E9Q/AACZwa7P3EMAAAAAAECTRAGg2kM6SNc/ZmaDwcna20MAAAAAB0WTROaL2kN24tk/mplbwQrn2kMAAAAADkqTRMt32kM/etw/ZmYwwXP02UMAAAAAFE+TRLBj2kOOD98/MzMFwQID2UMAAAAAG1STRJVP2kNgouE/AAC0wLgS2EMAAAAAIlmTRHo72kOvMuQ/MzM7wJYj10MAAAAAAGCTRAAg2kOHxeY/ZmZmvpo11kMAAAAAi4CTRAAg2kMZuOk/ZmYeQMVI1UMAAAAAFqGTRAAg2kPyp+w/mpmlQBdd1EMAAAAAocGTRAAg2kMNle8/AAD8QI9y00MAAAAAK+KTRAAg2kNjf/I/MzMpQS+J0kMAAAAAACCURAAg2kOxzPU/ZmZUQfag0UMAAAAA2C6URAAg2kMKdfg/mpl/QeO50EMAAAAAsT2URAAg2kOlGvs/ZmaVQfjTz0MAAAAAiUyURAAg2kN7vf0/AACrQTPvzkMAAAAAYluURAAg2kPELgBAmpnAQZYLzkMAAAAAOmqURAAg2kNkfQFAMzPWQR8pzUMAAAAAAICURAAg2kMD1gJAzczrQc9HzEMAAAAAN5WURAAg2kNKLARAM7MAQqZny0MAAAAAb6qURAAg2kMggQVAAIALQqSIykMAAAAApr+URAAg2kOE1AZAzUwWQsmqyUMAAAAA3dSURAAg2kNzJghAmhkhQhTOyEMAAAAAFOqURAAg2kPrdglAZuYrQofyx0MAAAAAAACVRAAg2kP+xgpAM7M2QiEYx0MAAAAAgAuVRAAg2kPdBQxAAIBBQuE+xkMAAAAA/xaVRAAg2kNEQw1AzUxMQslmxUMAAAAAfiKVRAAg2kMyfw5AmhlXQtePxEMAAAAA/S2VRAAg2kOkuQ9AZuZhQgy6w0MAAAAAAECVRAAg2kPc+xBAM7NsQmjlwkMAAAAA31SVRAAg2kORQBJAAIB3QuwRwkMAAAAAvWmVRAAg2kPCgxNAZiaBQpY/wUMAAAAAnH6VRAAg2kNuxRRAzYyGQmZuwEMAAAAAe5OVRAAg2kOUBRZAM/OLQl6ev0MAAAAAWaiVRAAg2kMxRBdAmlmRQn3PvkMAAAAAAMCVRAAg2kPPhBhAAMCWQsMBvkMAAAAAO8uVRAAg2kNktBlAZiacQi81vUMAAAAAddaVRAAg2kNv4hpAzYyhQsNpvEMAAAAAr+GVRAAg2kPyDhxAM/OmQn2fu0MAAAAA6uyVRAAg2kPqOR1AmlmsQl7WukMAAAAAAACWRAAg2kNTbB5AAMCxQmYOukMAAAAAAACWRAAg2kPYhx9AZia3QpZHuUMAAAAAAACWRAAg2kPUoSBAzYy8QuyBuEMAAAAAAACWRAAg2kNGuiFAM/PBQmi9t0MAAAAAAACWRAAg2kMu0SJAmlnHQgz6tkMAAAAAAACWRAAg2kOM5iNAAMDMQtc3tkMAAAAAAACWRAAg2kNf+iRAZibSQsl2tUMAAAAASyGWRAAg2kOVLCZAzYzXQuG2tEMAAAAAl0KWRAAg2kM3XSdAM/PcQiH4s0MAAAAA4mOWRAAg2kNFjChAmlniQoc6s0MAAAAALoWWRAAg2kO+uSlAAMDnQhR+skMAAAAAAMCWRAAg2kMC+ypAZibtQsnCsUMAAAAAQ9mWRAAg2kOMHyxAzYzyQqQIsUMAAAAAh/KWRAAg2kN+Qi1AM/P3QqZPsEMAAAAAyguXRAAg2kPbYy5Amln9Qs+Xr0MAAAAADSWXRAAg2kOfgy9AAGABQx/hrkMAAAAAUT6XRAAg2kPNoTBAMxMEQ5YrrkMAAAAAAGCXRAAg2kPuwzFAZsYGQzN3rUMAAAAAi4CXRLI12kMv7TJAmnkJQ/jDrEMAAAAAFqGXRGRL2kPUFDRAzSwMQ+MRrEMAAAAAocGXRBZh2kPeOjVAAOAOQ/Zgq0MAAAAALOKXRMh22kNLXzZAM5MRQy+xqkMAAAAAACCYRAGg2kNmmTdAZkYUQ48CqkMAAAAApEKYRJfH2kN5xDhAmvkWQxdVqUMAAAAASGWYRC3v2kPt7TlAzawZQ8WoqEMAAAAA64eYRMQW20PBFTtAAGAcQ5r9p0MAAAAAj6qYRFo+20P2OzxAMxMfQ5ZTp0MAAAAAMs2YRPBl20OMYD1AZsYhQ7iqpkMAAAAAAACZRACg20PSkD5AmnkkQwIDpkMAAAAAABCZRFW120M6pT9AzSwnQ3NcpUMAAAAAACCZRKvK20MGuEBAAOApQwq3pEMAAAAAADCZRADg20M5yUFAM5MsQ8kSpEMAAAAAAECZRFb120PS2EJAZkYvQ65vo0MAAAAAAFCZRKsK3EPT5kNAmvkxQ7rNokMAAAAAAGCZRAAg3EM880RAzaw0Q+4sokMAAAAAvnyZRP1N3EOOCkZAAGA3Q0iNoUMAAAAAfZmZRPp73ENIIEdAMxM6Q8nuoEMAAAAAO7aZRPep3ENrNEhAZsY8Q3FRoEMAAAAA+dKZRPTX3EO/2EjAmnk/Qz+1n0MAAAAAAACaRAEg3UNdvEfAzSxCQzUan0MAAAAAOAWaRN803UOFtkbAAOBEQ1KAnkMAAAAAcAqaRL5J3UM+skXAM5NHQ5bnnUMAAAAApw+aRJxe3UOIr0TAZkZKQwBQnUMAAAAA3xSaRHtz3UNgrkPAmvlMQ5G5nEMAAAAAFxqaRFmI3UPFrkLAzaxPQ0oknEMAAAAAACCaRACg3UOUr0HAAGBSQymQm0MAAAAAPDyaRPEQ3kN5jkDAMxNVQy/9mkMAAAAAeViaROKB3kPubj/AZsZXQ1xrmkMAAAAAtXSaRNPy3kPyUD7AmnlaQ7DamUMAAAAA8ZCaRMRj30ODND3AzSxdQytLmUMAAAAAAMCaRAAg4EOY/jvAAOBfQ828mEMAAAAAZ8+aRBJJ4EPk/zrAM5NiQ5YvmEMAAAAAzd6aRCRy4EO0AjrAZkZlQ4Wjl0MAAAAANO6aRDab4EMGBznAmvlnQ5wYl0MAAAAAm/2aREjE4EPYDDjAzaxqQ9mOlkMAAAAAAQ2bRFnt4EMpFDfAAGBtQz0GlkMAAAAAACCbRAAg4UOqGjbAMxNwQ8l+lUMAAAAAjTCbRFmO4UP/BjXAZsZyQ3v4lEMAAAAAGkGbRLH84UPT9DPAmnl1Q1RzlEMAAAAAqFGbRAlr4kMj5DLAzSx4Q1Tvk0MAAAAANWKbRGLZ4kPv1DHAAOB6Q3tsk0MAAAAAAICbRACg40NsqjDAM5N9Q8nqkkMAAAAAFI+bRIcE5EOxoC/AMyOAQz1qkkMAAAAAKJ6bRA1p5ENrmC7AzXyBQ9nqkUMAAAAAPa2bRJPN5EOXkS3AZtaCQ5xskUMAAAAAUbybRBky5UM0jCzAADCEQ4XvkEMAAAAAZcubRJ+W5UM/iCvAmomFQ5ZzkEMAAAAAAOCbRAAg5kNHeyrAM+OGQ834j0MAAAAAbeWbRCyi5kNVZSnAzTyIQyt/j0MAAAAA2eqbRFck50POUCjAZpaJQ7AGj0MAAAAARvCbRIKm50OxPSfAAPCKQ1yPjkMAAAAAsvWbRK4o6EP6KybAmkmMQy8ZjkMAAAAAAACcRAAg6UO28iTAM6ONQymkjUMAAAAA8wmcRGGX6UP56yPAzfyOQ0owjUMAAAAA5hOcRMIO6kOb5iLAZlaQQ5G9jEMAAAAA2B2cRCOG6kOX4iHAALCRQwBMjEMAAAAAyyecRIT96kPs3yDAmgmTQ5bbi0MAAAAAvjGcROV060OY3h/AM2OUQ1Jsi0MAAAAAAECcRAEg7EOW0B7AzbyVQzX+ikMAAAAAq0qcRFa17EOaxx3AZhaXQz+RikMAAAAAVVWcRKtK7UPvvxzAAHCYQ3ElikMAAAAAAGCcRADg7UOSuRvAmsmZQ8m6iUMAAAAAq2qcRFV17kOBtBrAMyObQ0hRiUMAAAAAVnWcRKsK70O6sBnAzXycQ+7oiEMAAAAAAICcRACg70M5rhjAZtadQ7qBiEMAAAAAP5GcRO+c8EM0kxfAADCfQ64biEMAAAAAfqKcRN6Z8UN2eRbAmomgQ8m2h0MAAAAAvbOcRM6W8kP9YBXAM+OhQwpTh0MAAAAA/MScRL2T80PHSRTAzTyjQ3PwhkMAAAAAAOCcRAAg9UNBFRPAZpakQwKPhkMAAAAAAOCcRJEF9kNL7hHAAPClQ7guhkMAAAAAAOCcRCLr9kOWyBDAmkmnQ5bPhUMAAAAAAOCcRLLQ90MfpA/AM6OoQ5pxhUMAAAAAAOCcREO2+EPigA7AzfypQ8UUhUMAAAAAAOCcRNSb+UPeXg3AZlarQxe5hEMAAAAAAOCcRACg+kPXNQzAALCsQ49ehEMAAAAAAOCcREtr+0PtHAvAmgmuQy8FhEMAAAAAAOCcRJc2/EMyBQrAM2OvQ/asg0MAAAAAAOCcROIB/UOi7gjAzbywQ+NVg0MAAAAAAOCcRC7N/UM72QfAZhayQ/j/gkMAAAAAAOCcRAAg/0MhpQbAAHCzQzOrgkMAAAAAAOCcRNDY/0NclQXAmsm0Q5ZXgkMAAAAAAOCcRNBIAES3hgTAMyO2Qx8FgkMAAAAAAOCcRDilAEQveQPAzXy3Q8+zgUMAAAAAAOCcRKABAUTAbALAZta4Q6ZjgUMAAAAAAOCcRAheAURpYQHAADC6Q6QUgUMAAAAAAOCcRADQAUTDTgDAmom7Q8nGgEMAAAAAAOCcRDUSAkRFnv6/M+O8QxR6gEMAAAAAAOCcRGpUAkQdofy/zTy+Q4cugEMAAAAAAOCcRJ+WAkQJpvq/Zpa/Q0LIf0MAAAAAAOCcRNTYAkQBrfi/APDAQ8M1f0MAAAAAAOCcRABQA0Tkk/a/mknCQ5GlfkMAAAAAAOCcRHmqA0SBjvS/M6PDQ64XfkMAAAAAAOCcRPEEBEQdi/K/zfzEQxmMfUMAAAAAAOCcRGpfBESxifC/ZlbGQ9ECfUMAAAAAAOCcROO5BEQ6iu6/ALDHQ9d7fEMAAAAAAOCcRFsUBUSwjOy/mgnJQyv3e0MAAAAAAOCcRACQBUQ1geq/M2PKQ810e0MAAAAAJ9WcRKHxBURXXOi/zbzLQ7z0ekMAAAAATsqcREFTBkRfOea/ZhbNQ/p2ekMAAAAAdb+cROK0BkRHGOS/AHDOQ4X7eUMAAAAAnLScRIMWB0QI+eG/msnPQ16CeUMAAAAAAKCcRAHQB0SVm9+/MyPRQ4ULeUMAAAAANYycRPkyCERAXN2/zXzSQ/qWeEMAAAAAanicRPKVCES9Htu/ZtbTQ7wkeEMAAAAAn2ScROr4CEQF49i/ADDVQ820d0MAAAAA01CcROJbCUQRqda/monWQytHd0MAAAAACD2cRNq+CUTdcNS/M+PXQ9fbdkMAAAAAACCcRAFQCkRKEtK/zTzZQ9FydkMAAAAAVQWcRKy6CkTpwc+/ZpbaQxkMdkMAAAAAq+qbRFclC0Q9c82/APDbQ66ndUMAAAAAANCbRAGQC0Q/Jsu/mkndQ5FFdUMAAAAAVbWbRKz6C0Tp2si/M6PeQ8PldEMAAAAAq5qbRFdlDEQ2kca/zfzfQ0KIdEMAAAAAAICbRAHQDEQhScS/ZlbhQw4tdEMAAAAAw1ebRHo3DUQt0MG/ALDiQynUc0MAAAAAhi+bRPOeDUTYWL+/mgnkQ5F9c0MAAAAASAebRGwGDkQb47y/M2PlQ0gpc0MAAAAAC9+aROVtDkTwbrq/zbzmQ0zXckMAAAAAAKCaRAAQD0Rnt7e/ZhboQ56HckMAAAAACXaaRGmDD0QuQbW/AHDpQz06ckMAAAAAEUyaRNP2D0R6zLK/msnqQyvvcUMAAAAAGSKaRDxqEERFWbC/MyPsQ2amcUMAAAAAIviZRKXdEESK562/zXztQ/BfcUMAAAAAKs6ZRA5REURDd6u/ZtbuQ8cbcUMAAAAAAKCZRAHQEUSt/qi/ADDwQ+zZcEMAAAAALW2ZRPJAEkT8b6a/monxQ16acEMAAAAAWjqZROOxEkS64qO/M+PyQx9dcEMAAAAAiAeZRNQiE0TkVqG/zTz0Qy0icEMAAAAAtdSYRMWTE0RzzJ6/Zpb1Q4npb0MAAAAAAICYRAFQFETH/Zu/APD2QzOzb0MAAAAAqkyYRGmsFEQIY5m/mkn4Qyt/b0MAAAAAVBmYRNEIFUSoyZa/M6P5Q3FNb0MAAAAA/eWXRDllFUSjMZS/zfz6QwQeb0MAAAAAp7KXRKHBFUT0mpG/Zlb8Q+XwbkMAAAAAUX+XRAkeFkSWBY+/ALD9QxTGbkMAAAAAAECXRACQFkRPXIy/mgn/Q5GdbkMAAAAAwvKWRFDzFkQleom/mjEARFx3bkMAAAAAhKWWRJ9WF0RbmYa/Zt4ARHVTbkMAAAAAR1iWRO+5F0TtuYO/M4sBRNsxbkMAAAAACQuWRD4dGETZ24C/ADgCRI8SbkMAAAAAAICVRADQGETCJXu/zeQCRJH1bUMAAAAAUT6VRFHuGERzFnW/mpEDROHabUMAAAAAovyURKIMGUTpCW+/Zj4ERH/CbUMAAAAA87qURPIqGUQaAGm/M+sERGqsbUMAAAAAQ3mURENJGUT7+GK/AJgFRKSYbUMAAAAAlDeURJRnGUSD9Fy/zUQGRCuHbUMAAAAAAOCTRACQGURDk1a/mvEGRAB4bUMAAAAAfpmTRGS7GUQomFC/Zp4HRCNrbUMAAAAA/FKTRMjmGUSan0q/M0sIRJNgbUMAAAAAegyTRCwSGkSTqUS/APgIRFJYbUMAAAAA98WSRJA9GkQMtj6/zaQJRF5SbUMAAAAAAECSRAGQGkSs/De/mlEKRLhObUMAAAAArP+RRMyjGkTm3TG/Zv4KRGBNbUMAAAAAV7+RRJe3GkSpwSu/M6sLRFZObUMAAAAAA3+RRGPLGkTwpyW/AFgMRJpRbUMAAAAArj6RRC7fGkS0kB+/zQQNRCtXbUMAAAAAWv6QRPnyGkTwexm/mrENRApfbUMAAAAAAKCQRAAQG0SnDRO/Zl4ORDdpbUMAAAAAq4qQRAAQG0TiYQ2/MwsPRLJ1bUMAAAAAVnWQRAAQG0ReuAe/ALgPRHuEbUMAAAAAAGCQRAAQG0QREQK/zWQQRJGVbUMAAAAAq0qQRAAQG0Tm1/i+mhERRPaobUMAAAAAVjWQRAAQG0T6ke2+Zr4RRKi+bUMAAAAAACCQRAAQG0ROUOK+M2sSRKjWbUMAAAAAw/ePRAAQG0T8oNa+ABgTRPbwbUMAAAAAhc+PRAAQG0T/9cq+zcQTRJENbkMAAAAASKePRAAQG0RNT7++mnEURHssbkMAAAAAC3+PRAAQG0TgrLO+Zh4VRLJNbkMAAAAAAECPRAAQG0Q3oqe+M8sVRDdxbkMAAAAABCuPRAAQG0T/Vpy+AHgWRAqXbkMAAAAACBaPRAAQG0TdD5G+zSQXRCu/bkMAAAAADQGPRAAQG0TIzIW+mtEXRJrpbkMAAAAAEeyORAAQG0RvG3W+Zn4YRFYWb0MAAAAAFdeORAAQG0RKpV6+MysZRGBFb0MAAAAAAMCORAAQG0QEK0i+ANgZRLh2b0MAAAAAUZ6ORBfjGkSX9C6+zYQaRF6qb0MAAAAAonyORC22GkQ1xxW+mjEbRFLgb0MAAAAA81qOREOJGkSwRfm9Zt4bRJMYcEMAAAAAQzmORFpcGkT/Dse9M4scRCNTcEMAAAAAAACORAAQGkT+55C9ADgdRACQcEMAAAAA7taNRJizGUTGSDK9zeQdRCvPcEMAAAAA3K2NRDBXGUTH14W8mpEeRKQQcUMAAAAAy4SNRMj6GET6GTE8Zj4fRGpUcUMAAAAAuVuNRGCeGEQpThs9M+sfRH+acUMAAAAApzKNRPhBGERsFYU9AJggROHicUMAAAAAAACNRADQF0RotL49zUQhRJEtckMAAAAAQeSMRLk/F0RmXPw9mvEhRI96ckMAAAAAgsiMRHKvFkQn9Rw+Zp4iRNvJckMAAAAAxKyMRCsfFkT6rjs+M0sjRHUbc0MAAAAABZGMROSOFUSRW1o+APgjRFxvc0MAAAAAAGCMRACQFERYkX4+zaQkRJHFc0MAAAAAykuMRA01FESWQI0+mlElRBQedEMAAAAAlDeMRBvaE0R6Mps+Zv4lROV4dEMAAAAAXyOMRCh/E0RKHqk+M6smRATWdEMAAAAAKQ+MRDYkE0T2A7c+AFgnRHE1dUMAAAAA8/qLRETJEkRq48Q+zQQoRCuXdUMAAAAAAOCLRABQEkTyYdM+mrEoRDP7dUMAAAAAJ9WLRK7YEUSIMuI+Zl4pRIlhdkMAAAAATsqLRFthEUQL/PA+MwsqRC3KdkMAAAAAdb+LRAnqEERlvv8+ALgqRB81d0MAAAAAnLSLRLZyEES+PAc/zWQrRF6id0MAAAAAAKCLRACQD0Q5wA8/mhEsROwReEMAAAAAAKCLRKbxDkSiwhc/Zr4sRMeDeEMAAAAAAKCLRE1TDkS+wB8/M2stRPD3eEMAAAAAAKCLRPO0DUR+uic/ABguRGZueUMAAAAAAKCLRJoWDUTRry8/zcQuRCvneUMAAAAAAKCLREB4DESloDc/mnEvRD1iekMAAAAAAKCLRAGQC0SFVEA/Zh4wRJ7fekMAAAAAAKCLRKwaC0Rd1Uc/M8swRExfe0MAAAAAAKCLRFalCkTDUU8/AHgxREjhe0MAAAAAAKCLRAEwCkSlyVY/zSQyRJFlfEMAAAAAAKCLRKu6CUTxPF4/mtEyRCnsfEMAAAAAAKCLRFZFCUSXq2U/Zn4zRA51fUMAAAAAAKCLRADQCESCFW0/Mys0REIAfkMAAAAAAKCLRAhdCESVdXQ/ANg0RMONfkMAAAAAAKCLRBDqB0TK0Hs/zYQ1RJEdf0MAAAAAAKCLRBd3B0SIk4E/mjE2RK6vf0MAAAAAAKCLRB8EB0QpPIU/Zt42RAwigEMAAAAAAKCLRABQBkTxG4k/M4s3RGhtgEMAAAAAAKCLRHuzBUQ35Yw/ADg4ROy5gEMAAAAAAKCLRPUWBUS+q5A/zeQ4RJYHgUMAAAAAAKCLRHB6BER7b5Q/mpE5RGZWgUMAAAAAAKCLROrdA0RhMJg/Zj46RF6mgUMAAAAAAKCLRGVBA0Rk7ps/M+s6RH33gUMAAAAAAKCLRACQAkS1tZ8/AJg7RMNJgkMAAAAApqWLRMQTAkSGcaM/zUQ8RC+dgkMAAAAATKuLRIiXAURMKqc/mvE8RMPxgkMAAAAA8bCLREsbAUT736o/Zp49RH1Hg0MAAAAAl7aLRA+fAESJkq4/M0s+RF6eg0MAAAAAAMCLRACg/0OOarI/APg+RGb2g0MAAAAAAMCLROe8/kMzA7Y/zaQ/RJZPhEMAAAAAAMCLRM/Z/UOemLk/mlFAROyphEMAAAAAAMCLRLb2/EPEKr0/Zv5ARGgFhUMAAAAAAMCLRJ0T/EObucA/M6tBRAxihUMAAAAAAMCLRIUw+0MYRcQ/AFhCRNe/hUMAAAAAAMCLRAAg+kOZzcc/zQRDRMkehkMAAAAAAMCLRJab+UP3VMs/mrFDROF+hkMAAAAAAMCLRCwX+UPb2M4/Zl5ERCHghkMAAAAAAMCLRMKS+EM9WdI/MwtFRIdCh0MAAAAAAMCLRFgO+EMV1tU/ALhFRBSmh0MAAAAAAMCLRAAg90P+Qtk/zWRGRMkKiEMAAAAAKc+LRIeS9kOL8dw/mhFHRKRwiEMAAAAAUd6LRA4F9kNPnOA/Zr5HRKbXiEMAAAAAee2LRJR39UNDQ+Q/M2tIRM8/iUMAAAAAovyLRBvq9ENf5uc/ABhJRB+piUMAAAAAyguMRKJc9EOZhes/zcRJRJYTikMAAAAAACCMRAGg80P/Je8/mnFKRDN/ikMAAAAAsjWMRMDc8kOuxfI/Zh5LRPjrikMAAAAAZEuMRH4Z8kNdYfY/M8tLRONZi0MAAAAAFmGMRD1W8UMD+fk/AHhMRPbIi0MAAAAAyHaMRPyS8EOYjP0/zSRNRC85jEMAAAAAAKCMRAAg70NNjABAmtFNRI+qjEMAAAAAt9aMRPil7UMNZQJAZn5ORBcdjUMAAAAAbg2NRPAr7EOnOwRAMytPRMWQjUMAAAAAJUSNROix6kMWEAZAANhPRJoFjkMAAAAA3HqNROA36UNT4gdAzYRQRJZ7jkMAAAAAk7GNRNi950NZsglAmjFRRLjyjkMAAAAAAACORACg5UPTeAtAZt5RRAJrj0MAAAAAq2qORADg4kOMOg1AM4tSRHPkj0MAAAAAVdWORAAg4EP9+Q5AADhTRApfkEMAAAAAAECPRABg3UMetxBAzeRTRMnakEMAAAAAq6qPRACg2kPncRJAmpFURK5XkUMAAAAAVRWQRADg10NOKhRAZj5VRLrVkUMAAAAAAICQRAAg1UNL4BVAM+tVRO5UkkMAAAAAcHGRREjn0ENaxBdAAJhWREjVkkMAAAAA4GKSRJCuzEPJpRlAzURXRMlWk0MAAAAAUFSTRNh1yEOKhBtAmvFXRHHZk0MAAAAAwEWURCA9xEOOYB1AZp5YRD9dlEMAAAAAAMCVRACgvUN/9B5AM0tZRDXilEMAAAAATleWRDg9vEMhiyFAAPhZRFJolUMAAAAAnO6WRG/aukMfHiRAzaRaRJbvlUMAAAAA6oWXRKd3uUNyrSZAmlFbRAB4lkMAAAAAOB2YRN8UuEMVOSlAZv5bRJEBl0MAAAAAhrSYRBeytkMAwStAM6tcREqMl0MAAAAAAGCZRAEgtUNiQC5AAFhdRCkYmEMAAAAAagmaRPIQtEPi8jBAzQReRC+lmEMAAAAA07KaROMBs0NZoTNAmrFeRFwzmUMAAAAAPVybRNPysUPCSzZAZl5fRLDCmUMAAAAApgWcRMTjsEMY8jhAMwtgRCtTmkMAAAAAACCdRAAgr0PhbjtAALhgRM3kmkMAAAAAV1OdRN3NrkN2SD5AzWRhRJZ3m0MAAAAArYadRLl7rkObHUFAmhFiRIULnEMAAAAAA7qdRJUprkNW7kNAKEZjRMQLmEMAAAAAWe2dRHLXrUPnlkRAbXJjRBkLlEMAAAAAsCCeRE6FrUMbPkVAsp5jRJULkEMAAAAAAGCeRAAgrUMz3EVA98pjRDgNjEMAAAAAv3ueRAAgrUNEpUZAPPdjRAIQiEMAAAAAfpeeRAAgrUP1bEdAgSNkRPMThEMAAAAAPbOeRAAgrUNGM0hAxk9kRAoZgEMAAAAA/M6eRAAgrUM5+EhAC3xkRJE+eEMAAAAAAACfRAAgrUNQZEjAUKhkRFxNcEMAAAAARBmfRHmtrUPzX0fAldRkRHVeaEMAAAAAhzKfRPM6rkP8XEbA2gBlRNtxYEMAAAAAykufRGzIrkNrW0XAHy1lRI+HWEMAAAAADmWfROVVr0M/W0TAZFllRJGfUEMAAAAAUX6fRF/jr0N3XEPAqYVlROG5SEMAAAAAAKCfRACgsEMIS0LA7rFlRH/WQEMAAAAAAKCfRNEQskNr4EDAM95lRGr1OEMAAAAAAKCfRKGBs0NNdz/AeApmRKQWMUMAAAAAAKCfRHHytEOsDz7AvTZmRCs6KUMAAAAAAKCfREJjtkOGqTzAAmNmRABgIUMAAAAAAKCfRAAguUNArzrAR49mRCOIGUMAAAAAAKCfRCOGukNNUDnAjLtmRJSyEUMAAAAAAKCfREXsu0PO8jfA0edmRFLfCUMAAAAAAKCfRGhSvUPCljbAFxRnRF4OAkMAAAAAAKCfRIq4vkMlPDXAXEBnRHF/9EIAAAAAAKCfRK0ewEP24jPAoWxnRMHm5EIAAAAAAKCfRAAgwkPzRzLA5phnRKxS1UIAAAAAAKCfRFb1wkOVLzHAK8VnRDTDxUIAAAAAAKCfRKvKw0OPGDDAcPFnRFY4tkIAAAAAAKCfRACgxEPdAi/AtR1oRBWypkIAAAAAAKCfRFZ1xUN+7i3A+kloRG8wl0IAAAAAAKCfRKtKxkNv2yzAP3ZoRGWzh0IAAAAAAKCfRAAgx0OuySvAhKJoRO11cEIAAAAAAKCfRPPux0PauyrAyc5oREeOUUIAAAAAAKCfROW9yENQrynADvtoRNivMkIAAAAAAKCfRNeMyUMMpCjAUydpRKHaE0IAAAAAAKCfRMlbykMOmifAmFNpREMd6kEAAAAAAKCfRAGgy0PeYibA3X9pRLGXrEEAAAAAAKCfRPTey0OskyXAIqxpRB5JXkEAAAAAAKCfROcdzEOwxSTAZ9hpRGsPx0AAAAAAAKCfRNtczEPn+CPArARqRKymuL8AAAAAAKCfRM6bzENQLSPA8TBqRIOMEcEAAAAAAKCfRMLazEPoYiLANl1qRKrvhcEAAAAAAKCfRAAgzUNMlyHAe4lqRKQGw8EAAAAAAKCfRMRjzUNqzSDAwLVqRJcFAMIAAAAAAKCfRIinzUOvBCDABeJqRKZ+HsIAAAAAAKCfREzrzUMcPR/ASg5rRH3uPMIAAAAAAKCfRA8vzkOsdh7AjzprRBxVW8IAAAAAAKCfRACgzkMboR3AAIA4wgCg5kMAAAAAAKCfRIm0zkOj7RzAAIA4wgCg5kMAAAAAAKCfRBLJzkNHOxzAAIA4wgCg5kMAAAAAAKCfRJvdzkMEihvAAIA4wgCg5kMAAAAAAKCfRCTyzkPY2RrAAIA4wgCg5kMAAAAAAKCfRKwGz0PCKhrAAIA4wgCg5kMAAAAAAKCfRAAgz0MdexnAAIA4wgCg5kMAAAAAAKCfRAAgz0MS1RjAAIA4wgCg5kMAAAAAAKCfRAAgz0MWMBjAAIA4wgCg5kMAAAAAAKCfRAAgz0MljBfAAIA4wgCg5kMAAAAAAKCfRAAgz0M+6RbAAIA4wgCg5kMAAAAAAKCfRAAgz0NdRxbAAIA4wgCg5kMAAAAAAKCfRGxIz0OKmRXAAIA4wgCg5kMAAAAAAKCfRNdwz0O67BTAAIA4wgCg5kMAAAAAAKCfREOZz0PrQBTAAIA4wgCg5kMAAAAAAKCfRK/Bz0MclhPAAIA4wgCg5kMAAAAAAKCfRBvqz0NK7BLAAIA4wgCg5kMAAAAAAKCfRAAg0ENdPxLAAIA4wgCg5kMAAAAAAKCfRAAg0EOQoxHAAIA4wgCg5kMAAAAAAKCfRAAg0EO4CBHAAIA4wgCg5kMAAAAAAKCfRAAg0EPTbhDAAIA4wgCg5kMAAAAAAKCfRAAg0EPf1Q/AAIA4wgCg5kMAAAAAAKCfRAAg0EPbPQ/AAIA4wgCg5kMAAAAAAKCfRAAg0EPDpg7AAIA4wgCg5kMAAAAAAKCfRAAg0EOXEA7AAIA4wgCg5kMAAAAAAKCfRAAg0ENSew3AAIA4wgCg5kMAAAAAAKCfRAAg0EP05gzAAIA4wgCg5kMAAAAAAKCfRAAg0EN7UwzAAIA4wgCg5kMAAAAAAKCfRAAg0EPjwAvAAIA4wgCg5kMAAAAAAKCfRAAg0EMsLwvAAIA4wgCg5kMAAAAAAKCfRAAg0ENSngrAAIA4wgCg5kMAAAAAAKCfRAAg0ENUDgrAAIA4wgCg5kMAAAAAAKCfRAAg0EMwfwnAAIA4wgCg5kMAAAAAAKCfRAAg0EPj8AjAAIA4wgCg5kMAAAAAAKCfRAAg0ENsYwjAAIA4wgCg5kMAAAAAAKCfRAAg0EPJ1gfAAIA4wgCg5kMAAAAAAKCfRAAg0EP2SgfAAIA4wgCg5kMAAAAAAKCfRAAg0EPzvwbAAIA4wgCg5kMAAAAAAKCfRAAg0EO9NQbAAIA4wgCg5kMAAAAAAKCfRAAg0ENTrAXAAIA4wgCg5kMAAAAAAKCfRAAg0EOxIwXAAIA4wgCg5kMAAAAAAKCfRAAg0EPXmwTAAIA4wgCg5kMAAAAAAKCfRAAg0EPBFATAAIA4wgCg5kMAAAAAAKCfRAAg0ENvjgPAAIA4wgCg5kMAAAAAAKCfRAAg0EPeCAPAAIA4wgCg5kMAAAAAAKCfRAAg0EMLhALAAIA4wgCg5kMAAAAAAKCfRAAg0EP2/wHAAIA4wgCg5kMAAAAAAKCfRAAg0EOcfAHAAIA4wgCg5kMAAAAAAKCfRAAg0EP7+QDAAIA4wgCg5kMAAAAAAKCfRAAg0EMReADAAIA4wgCg5kMAAAAAAKCfRAAg0EO67f+/AIA4wgCg5kMAAAAAAKCfRAAg0EO37P6/AIA4wgCg5kMAAAAAAKCfRAAg0EMX7f2/AIA4wgCg5kMAAAAAAKCfRAAg0EPW7vy/AIA4wgCg5kMAAAAAAKCfRAAg0EPw8fu/AIA4wgCg5kMAAAAAAKCfRAAg0ENh9vq/AIA4wgCg5kMAAAAAAKCfRAAg0EMm/Pm/AIA4wgCg5kMAAAAAAKCfRAAg0EM6A/m/AIA4wgCg5kMAAAAAAKCfRAAg0EOaC/i/AIA4wgCg5kMAAAAAAKCfRAAg0ENDFfe/AIA4wgCg5kMAAAAAAKCfRAAg0EMvIPa/AIA4wgCg5kMAAAAAAKCfRAAg0ENdLPW/AIA4wgCg5kMAAAAAAKCfRAAg0EPHOfS/AIA4wgCg5kMAAAAAAKCfRAAg0ENrSPO/AIA4wgCg5kMAAAAAAKCfRAAg0ENEWPK/AIA4wgCg5kMAAAAAAKCfRAAg0ENQafG/AIA4wgCg5kMAAAAAAKCfRAAg0EOKe/C/AIA4wgCg5kMAAAAAAKCfRAAg0EPvju+/AIA4wgCg5kMAAAAAAKCfRAAg0EN8o+6/AIA4wgCg5kMAAAAAAKCfRAAg0EMsue2/AIA4wgCg5kMAAAAAAKCfRAAg0EP9z+y/AIA4wgCg5kMAAAAAAKCfRAAg0EPq5+u/AIA4wgCg5kMAAAAAAKCfRAAg0EPxAOu/AIA4wgCg5kMAAAAAAKCfRAAg0EMNG+q/AIA4wgCg5kMAAAAAAKCfRAAg0EM8Num/AIA4wgCg5kMAAAAAAKCfRAAg0EN6Uui/AIA4wgCg5kMAAAAAAKCfRAAg0EPDb+e/AIA4wgCg5kMAAAAAAKCfRAAg0EMUjua/AIA4wgCg5kMAAAAAAKCfRAAg0ENqreW/AIA4wgCg5kMAAAAAAKCfRAAg0EPBzeS/AIA4wgCg5kMAAAAAAKCfRAAg0EMX7+O/AIA4wgCg5kMAAAAAAKCfRAAg0ENnEeO/AIA4wgCg5kMAAAAAAKCfRAAg0EOuNOK/AIA4wgCg5kMAAAAAAKCfRAAg0EPqWOG/AIA4wgCg5kMAAAAAAKCfRAAg0EMWfuC/AIA4wgCg5kMAAAAAAKCfRAAg0EMwpN+/AIA4wgCg5kMAAAAAAKCfRAAg0EM0y96/AIA4wgCg5kMAAAAAAKCfRAAg0EMf892/AIA4wgCg5kMAAAAAAKCfRAAg0EPvG92/AIA4wgCg5kMAAAAAAKCfRAAg0EOeRdy/AIA4wgCg5kMAAAAAAKCfRAAg0EMscNu/AIA4wgCg5kMAAAAAAKCfRAAg0EOUm9q/AIA4wgCg5kMAAAAAAKCfRAAg0EPTx9m/AIA4wgCg5kMAAAAAAKCfRAAg0EPm9Ni/AIA4wgCg5kMAAAAAAKCfRAAg0EPLIti/AIA4wgCg5kMAAAAAAKCfRAAg0EN9Ude/AIA4wgCg5kMAAAAAAKCfRAAg0EP7gNa/AIA4wgCg5kMAAAAAAKCfRAAg0ENAsdW/AIA4wgCg5kMAAAAAAKCfRAAg0ENK4tS/AIA4wgCg5kMAAAAAAKCfRAAg0EMWFNS/AIA4wgCg5kMAAAAAAKCfRAAg0EOhRtO/AIA4wgCg5kMAAAAAAKCfRAAg0EPoedK/AIA4wgCg5kMAAAAAAKCfRAAg0EPordG/AIA4wgCg5kMAAAAAAKCfRAAg0EOe4tC/AIA4wgCg5kMAAAAAAKCfRAAg0EMHGNC/AIA4wgCg5kMAAAAAAKCfRAAg0EMgTs+/AIA4wgCg5kMAAAAAAKCfRAAg0EPmhM6/AIA4wgCg5kMAAAAA6aqfRHRh0ENl4s2/AIA4wgCg5kMAAAAA0rWfROmi0EOMQM2/AIA4wgCg5kMAAAAAusCfRF3k0ENYn8y/AIA4wgCg5kMAAAAAo8ufRNEl0UPI/su/AIA4wgCg5kMAAAAAAOCfRACg0UPTgMu/AIA4wgCg5kMAAAAAAOCfRACg0UOeucq/AIA4wgCg5kMAAAAAAOCfRACg0UMG88m/AIA4wgCg5kMAAAAAAOCfRACg0UMKLcm/AIA4wgCg5kMAAAAAAOCfRACg0UOlZ8i/AIA4wgCg5kMAAAAAAOCfRACg0UPVose/AIA4wgCg5kMAAAAAAOCfRACg0UOY3sa/AIA4wgCg5kMAAAAA6AqgRIyK0UNIuca/AIA4wgCg5kMAAAAAzzWgRBh10UOGlMa/AIA4wgCg5kMAAAAAt2CgRKRf0UNTcMa/AIA4wgCg5kMAAAAAn4ugRDFK0UOtTMa/AIA4wgCg5kMAAAAAAOCgRAAg0UOswsa/AIA4wgCg5kMAAAAA4BWhRHOq0EMjx8a/AIA4wgCg5kMAAAAAwUuhROY00EMozMa/AIA4wgCg5kMAAAAAooGhRFm/z0O50ca/AIA4wgCg5kMAAAAAg7ehRMxJz0PY18a/AIA4wgCg5kMAAAAAY+2hRD/UzkOC3sa/AIA4wgCg5kMAAAAAAECiRAEgzkM/T8e/AIA4wgCg5kMAAAAAtXmiRBHMzUOMZce/AIA4wgCg5kMAAAAAabOiRCJ4zUNlfMe/AIA4wgCg5kMAAAAAHu2iRDMkzUPMk8e/AIA4wgCg5kMAAAAA0iajRETQzEPAq8e/AIA4wgCg5kMAAAAAh2CjRFR8zENBxMe/AIA4wgCg5kMAAAAAAaCjRAAgzEOY8se/AIA4wgCg5kMAAAAAAQCkRB4+y0Njmci/AIA4wgCg5kMAAAAAAWCkRDxcykO/QMm/AIA4wgCg5kMAAAAAAcCkRFt6yUOt6Mm/AIA4wgCg5kMAAAAAASClRHmYyEMwkcq/AIA4wgCg5kMAAAAAAMClRAAgx0NrKsy/AIA4wgCg5kMAAAAA+H6mRACgxEOWQM6/AIA4wgCg5kMAAAAA8D2nRAAgwkNQV9C/AIA4wgCg5kMAAAAA6PynRACgv0OlbtK/AIA4wgCg5kMAAAAA37uoRAEgvUOhhtS/AIA4wgCg5kMAAAAA13qpRAGgukNSn9a/AIA4wgCg5kMAAAAAAGCqRAGgt0PrU9m/AIA4wgCg5kMAAAAA

`.trim(),`


p6dWROttDETRrsO9zSx4Q1Tvk0MAAAAA3zRWRDmNDERTbuC9AOB6Q3tsk0MAAAAAF8JVRIesDEQhAP29M5N9Q8nqkkMAAAAAAEBVRAHQDERK0Ay+MyOAQz1qkkMAAAAABv1URFXmDETw1Rq+zXyBQ9nqkUMAAAAADLpURKj8DETfxCi+ZtaCQ5xskUMAAAAAEndURPsSDUQmnTa+ADCEQ4XvkEMAAAAAGDRURE4pDUTYXkS+momFQ5ZzkEMAAAAAAcBTRABQDUTpYlK+M+OGQ834j0MAAAAA8IxTRBGDDUSJ1WG+zTyIQyt/j0MAAAAA4FlTRCG2DUR4MXG+ZpaJQ7AGj0MAAAAA0CZTRDHpDURnO4C+APCKQ1yPjkMAAAAAv/NSREIcDkTR0oe+mkmMQy8ZjkMAAAAAr8BSRFJPDkQEX4++M6ONQymkjUMAAAAAAYBSRACQDkQgI5e+zfyOQ0owjUMAAAAAHlRSRNzGDkTNxZ6+ZlaQQ5G9jEMAAAAAOyhSRLf9DkRfXaa+ALCRQwBMjEMAAAAAWPxRRJM0D0Ti6a2+mgmTQ5bbi0MAAAAAdtBRRG5rD0Rja7W+M2OUQ1Jsi0MAAAAAAIBRRADQD0Q3u72+zbyVQzX+ikMAAAAAvU1RRF4WEET9hMW+ZhaXQz+RikMAAAAAehtRRLxcEETVQ82+AHCYQ3ElikMAAAAAN+lQRBqjEETM99S+msmZQ8m6iUMAAAAA9LZQRHjpEETwoNy+MyObQ0hRiUMAAAAAsYRQRNUvEURNP+S+zXycQ+7oiEMAAAAAAEBQRACQEUQqQey+ZtadQ7qBiEMAAAAApB9QRCa7EUR4VvO+ADCfQ64biEMAAAAASP9PREvmEUQ7Yfq+momgQ8m2h0MAAAAA7N5PRHAREkTBsAC/M+OhQwpTh0MAAAAAkL5PRJY8EkSvKwS/zTyjQ3PwhkMAAAAAAIBPRACQEkRU6Qe/ZpakQwKPhkMAAAAAxU5PRO3UEkSEjQu/APClQ7guhkMAAAAAih1PRNkZE0SMLA+/mkmnQ5bPhUMAAAAAT+xORMZeE0R1xhK/M6OoQ5pxhUMAAAAAFLtORLKjE0REWxa/zfypQ8UUhUMAAAAA2YlORJ/oE0QD6xm/ZlarQxe5hEMAAAAAAEBORAFQFEQuqR2/ALCsQ49ehEMAAAAALSBORDhlFEStxyC/mgmuQy8FhEMAAAAAWwBORG96FEQ+4SO/M2OvQ/asg0MAAAAAiOBNRKaPFETr9Sa/zbywQ+NVg0MAAAAAtsBNRN2kFES7BSq/ZhayQ/j/gkMAAAAA46BNRBS6FES3EC2/AHCzQzOrgkMAAAAAAYBNRADQFERvFjC/msm0Q5ZXgkMAAAAAk3RNRAAgFUSm7jO/MyO2Qx8FgkMAAAAAJWlNRABwFUQHwje/zXy3Q8+zgUMAAAAAt11NRADAFUSckDu/Zta4Q6ZjgUMAAAAASVJNRAAQFkRuWj+/ADC6Q6QUgUMAAAAAAEBNRACQFkQ1jkO/mom7Q8nGgEMAAAAA3SBNRCOvFkQnnEa/M+O8QxR6gEMAAAAAuwFNREbOFkSJpUm/zTy+Q4cugEMAAAAAmOJMRGjtFkRjqky/Zpa/Q0LIf0MAAAAAdsNMRIsMF0TAqk+/APDAQ8M1f0MAAAAAU6RMRK0rF0SnplK/mknCQ5GlfkMAAAAAAIBMRABQF0TOnFW/M6PDQ64XfkMAAAAAAIBMRDtbF0S0tVi/zfzEQxmMfUMAAAAAAIBMRHVmF0Q9ylu/ZlbGQ9ECfUMAAAAAAIBMRK9xF0Rz2l6/ALDHQ9d7fEMAAAAAAIBMROp8F0Ri5mG/mgnJQyv3e0MAAAAAAIBMRACQF0RGAGW/M2PKQ810e0MAAAAAk2tMRNq4F0QcDGi/zbzLQ7z0ekMAAAAAJldMRLThF0THE2u/ZhbNQ/p2ekMAAAAAuUJMRI4KGERRF26/AHDOQ4X7eUMAAAAATC5MRGgzGETEFnG/msnPQ16CeUMAAAAA3xlMREJcGEQoEnS/MyPRQ4ULeUMAAAAAAABMRACQGEToD3e/zXzSQ/qWeEMAAAAAM7NLRL7yGEQXz3m/ZtbTQ7wkeEMAAAAAZmZLRHxVGURViny/ADDVQ820d0MAAAAAmhlLRDu4GUSoQX+/monWQytHd0MAAAAAzcxKRPkaGkSL+oC/M+PXQ9fbdkMAAAAAAEBKRADQGkSWPYK/zTzZQ9FydkMAAAAAAEBKREMCG0SU4YO/ZpbaQxkMdkMAAAAAAEBKRIY0G0Shg4W/APDbQ66ndUMAAAAAAEBKRMlmG0TDI4e/mkndQ5FFdUMAAAAAAEBKRAyZG0T/wYi/M6PeQ8PldEMAAAAAAEBKRE/LG0RZXoq/zfzfQ0KIdEMAAAAAAEBKRAAQHER9CIy/ZlbhQw4tdEMAAAAApB9KRBRxHETPko2/ALDiQynUc0MAAAAASP9JRCnSHERQG4+/mgnkQ5F9c0MAAAAA7N5JRD0zHUQDopC/M2PlQ0gpc0MAAAAAkL5JRFGUHUTtJpK/zbzmQ0zXckMAAAAAAIBJRAFQHkTPupO/ZhboQ56HckMAAAAAAIBJRN+8HkQ4fpW/AHDpQz06ckMAAAAAAIBJRLwpH0TbP5e/msnqQyvvcUMAAAAAAIBJRJqWH0S7/5i/MyPsQ2amcUMAAAAAAIBJRHgDIETevZq/zXztQ/BfcUMAAAAAAIBJRFVwIERHepy/ZtbuQ8cbcUMAAAAAAIBJRAAQIUTIU56/ADDwQ+zZcEMAAAAAAIBJRBR6IURaDKC/monxQ16acEMAAAAAAIBJRCjkIUQ/w6G/M+PyQx9dcEMAAAAAAIBJRDxOIkR9eKO/zTz0Qy0icEMAAAAAAIBJRFC4IkQXLKW/Zpb1Q4npb0MAAAAAAIBJRGQiI0QR3qa/APD2QzOzb0MAAAAAAIBJRACQI0QWkKi/mkn4Qyt/b0MAAAAAAIBJRACAJESaeaq/M6P5Q3FNb0MAAAAAAIBJRABwJUSCYay/zfz6QwQeb0MAAAAAAIBJRABgJkTOR66/Zlb8Q+XwbkMAAAAAAIBJRABQJ0SDLLC/ALD9QxTGbkMAAAAAAIBJRADQKETaPrK/mgn/Q5GdbkMAAAAAAIBJRJKfKURgGrS/mjEARFx3bkMAAAAAAIBJRCNvKkRT9LW/Zt4ARHVTbkMAAAAAAIBJRLQ+K0S0zLe/M4sBRNsxbkMAAAAAAIBJREUOLESHo7m/ADgCRI8SbkMAAAAAAIBJRNfdLETPeLu/zeQCRJH1bUMAAAAAAIBJRADQLURqUr2/mpEDROHabUMAAAAAAIBJRO6YLkSWJL+/Zj4ERH/CbUMAAAAAAIBJRN1hL0Q+9cC/M+sERGqsbUMAAAAAAIBJRMsqMERlxMK/AJgFRKSYbUMAAAAAAIBJRLnzMEQNksS/zUQGRCuHbUMAAAAAAIBJRAFQMkTpY8a/mvEGRAB4bUMAAAAAAIBJRDLpMkTWMci/Zp4HRCNrbUMAAAAAAIBJRGOCM0RL/sm/M0sIRJNgbUMAAAAAAIBJRJQbNERKycu/APgIRFJYbUMAAAAAAIBJRMW0NETYks2/zaQJRF5SbUMAAAAAAIBJRPZNNUT4Ws+/mlEKRLhObUMAAAAAAIBJRAEQNkTtHNG/Zv4KRGBNbUMAAAAA8ZVJRL9yNkS5E9O/M6sLRFZObUMAAAAA46tJRH3VNkQbCdW/AFgMRJpRbUMAAAAA1MFJRDs4N0QY/da/zQQNRCtXbUMAAAAAxtdJRPmaN0Sz79i/mrENRApfbUMAAAAAAABKRABQOERF7dq/Zl4ORDdpbUMAAAAAAB5KRABuOEQlAt2/MwsPRLJ1bUMAAAAAADxKRACMOESsFd+/ALgPRHuEbUMAAAAAAFpKRACqOEThJ+G/zWQQRJGVbUMAAAAAAHhKRADIOETKOOO/mhERRPaobUMAAAAAAJZKRADmOERuSOW/Zr4RRKi+bUMAAAAAAMBKRAAQOUQvZ+e/M2sSRKjWbUMAAAAA7vVKRCY7OUSImem/ABgTRPbwbUMAAAAA3StLREtmOUSnyuu/zcQTRJENbkMAAAAAzGFLRHGROUSS+u2/mnEURHssbkMAAAAAu5dLRJa8OURPKfC/Zh4VRLJNbkMAAAAAAABMRAAQOkRkl/K/M8sVRDdxbkMAAAAA5glMRMwjOkTmhvS/AHgWRAqXbkMAAAAAyxNMRJc3OkRWdfa/zSQXRCu/bkMAAAAAsR1MRGJLOkS7Yvi/mtEXRJrpbkMAAAAAlydMRC1fOkQbT/q/Zn4YRFYWb0MAAAAAfTFMRPhyOkR7Ovy/MysZRGBFb0MAAAAAAUBMRACQOkTQJf6/ANgZRLh2b0MAAAAAOFVMRACQOkTvGADAzYQaRF6qb0MAAAAAb2pMRACQOkR8HgHAmjEbRFLgb0MAAAAApn9MRACQOkSRIwLAZt4bRJMYcEMAAAAA3ZRMRACQOkQzKAPAM4scRCNTcEMAAAAAFKpMRACQOkRjLATAADgdRACQcEMAAAAAAMBMRACQOkS4MAXAzeQdRCvPcEMAAAAAt+1MRG6bOkRVQgbAmpEeRKQQcUMAAAAAbhtNRNumOkSHUwfAZj4fRGpUcUMAAAAAJUlNREmyOkRQZAjAM+sfRH+acUMAAAAA3HZNRLe9OkSzdAnAAJggROHicUMAAAAAAMBNRADQOkQplgrAzUQhRJEtckMAAAAA39RNRADQOkRQmQvAmvEhRI96ckMAAAAAvulNRADQOkQbnAzAZp4iRNvJckMAAAAAnP5NRADQOkSNng3AM0sjRHUbc0MAAAAAexNORADQOkSpoA7AAPgjRFxvc0MAAAAAWShORADQOkRxog/AzaQkRJHFc0MAAAAAAEBORADQOkTkpRDAmlElRBQedEMAAAAAp2xORADQOkTOtxHAZv4lROV4dEMAAAAATZlORADQOkRpyRLAM6smRATWdEMAAAAA9MVORADQOkS32hPAAFgnRHE1dUMAAAAAm/JORADQOkS56xTAzQQoRCuXdUMAAAAAAEBPRADQOkQaEhbAmrEoRDP7dUMAAAAAEXNPRADQOkQQJxfAZl4pRIlhdkMAAAAAIaZPRADQOkS/OxjAMwsqRC3KdkMAAAAAMdlPRADQOkQsUBnAALgqRB81d0MAAAAAQgxQRADQOkRWZBrAzWQrRF6id0MAAAAAUj9QRADQOkRBeBvAmhEsROwReEMAAAAAAIBQRADQOkT+kxzAZr4sRMeDeEMAAAAANcJQRADQOkRfsB3AM2stRPD3eEMAAAAAagRRRADQOkSEzB7AABguRGZueUMAAAAAn0ZRRADQOkRu6B/AzcQuRCvneUMAAAAA1IhRRADQOkQfBCHAmnEvRD1iekMAAAAAAABSRADQOkSFOyLAZh4wRJ7fekMAAAAAeVpSRMqnOkTygiPAM8swRExfe0MAAAAA8bRSRJV/OkQeyiTAAHgxREjhe0MAAAAAag9TRF9XOkQKESbAzSQyRJFlfEMAAAAA42lTRCovOkS4VyfAmtEyRCnsfEMAAAAAW8RTRPQGOkQpnijAZn4zRA51fUMAAAAAAEBURAHQOUS+/inAMys0REIAfkMAAAAAuIBUREiPOUS0TivAANg0RMONfkMAAAAAcMFURJBOOURtnizAzYQ1RJEdf0MAAAAAKAJVRNgNOUTs7S3AmjE2RK6vf0MAAAAA4EJVRCDNOEQyPS/AZt42RAwigEMAAAAAAMBVRABQOETJ1DDAM4s3RGhtgEMAAAAAfPFVRLkKOEQwIzLAADg4ROy5gEMAAAAA+CJWRHHFN0RgcTPAzeQ4RJYHgUMAAAAAdFRWRCqAN0RbvzTAmpE5RGZWgUMAAAAA8IVWROM6N0QiDTbAZj46RF6mgUMAAAAAbLdWRJz1NkS3WjfAM+s6RH33gUMAAAAAAABXRACQNkRmyjjAAJg7RMNJgkMAAAAAgpRXRHTGNUSZozrAzUQ8RC+dgkMAAAAABClYROj8NERXfDzAmvE8RMPxgkMAAAAAhr1YRFwzNESiVD7AZp49RH1Hg0MAAAAACVJZRNBpM0R3LEDAM0s+RF6eg0MAAAAAi+ZZRESgMkTWA0LAAPg+RGb2g0MAAAAAAIBaRADQMURM4UPAzaQ/RJZPhEMAAAAASfJaRLcNMUR1r0XAmlFAROyphEMAAAAAk2RbRG5LMEQnfUfAZv5ARGgFhUMAAAAA3NZbRCWJL0RS1UhAM6tBRAxihUMAAAAAJUlcRNzGLkSQCEdAAFhCRNe/hUMAAAAAAABdRACQLUT21ERAzQRDRMkehkMAAAAAyWddRPPpLEScIENAmrFDROF+hkMAAAAAks9dROVDLES2bEFAZl5ERCHghkMAAAAAWjdeRNedK0RHuT9AMwtFRIdCh0MAAAAAI59eRMn3KkRQBj5AALhFRBSmh0MAAAAA6wZfRLxRKkTWUzxAzWRGRMkKiEMAAAAAAIBfRAGQKUSFjDpAmhFHRKRwiEMAAAAA09lfRM/yKEQ63zhAZr5HRKbXiEMAAAAApzNgRJ5VKERzMjdAM2tIRM8/iUMAAAAAeo1gRGy4J0QyhjVAABhJRB+piUMAAAAATedgRDsbJ0R82jNAzcRJRJYTikMAAAAAAYBhRAAQJkTJ5DFAmnFKRDN/ikMAAAAAtNFhRAaBJURaQTBAZh5LRPjrikMAAAAAaCNiRAvyJER/ni5AM8tLRONZi0MAAAAAHHViRBFjJEQ6/CxAAHhMRPbIi0MAAAAAz8ZiRBbUI0SRWitAzSRNRC85jEMAAAAAgxhjRBxFI0SHuSlAmtFNRI+qjEMAAAAAAIBjRACQIkRrBChAZn5ORBcdjUMAAAAAWO5jRJ8WIkSfgiZAMytPRMWQjUMAAAAAsVxkRD6dIURxASVAANhPRJoFjkMAAAAACctkRN0jIUTmgCNAzYRQRJZ7jkMAAAAAYTllRHyqIEQBASJAmjFRRLjyjkMAAAAAAABmRADQH0TwaSBAZt5RRAJrj0MAAAAAeVpmRG1hH0RH5R5AM4tSRHPkj0MAAAAA8bRmRNnyHkRXYR1AADhTRApfkEMAAAAAag9nREaEHkQm3htAzeRTRMnakEMAAAAA42lnRLMVHkS3WxpAmpFURK5XkUMAAAAAW8RnRCCnHUQP2hhAZj5VRLrVkUMAAAAAAEBoRAEQHUT6UxdAM+tVRO5UkkMAAAAAeqxoRCR4HEQqxBVAAJhWREjVkkMAAAAA8xhpREbgG0Q5NRRAzURXRMlWk0MAAAAAbYVpRGlIG0QqpxJAmvFXRHHZk0MAAAAA5vFpRIuwGkQFGhFAZp5YRD9dlEMAAAAAAMBqRACQGUTQhQ9AM0tZRDXilEMAAAAAxQ5rRCcGGUSO6A1AAPhZRFJolUMAAAAAil1rRE98GERRTAxAzaRaRJbvlUMAAAAAT6xrRHbyF0QgsQpAmlFbRAB4lkMAAAAAFPtrRJ5oF0QAFwlAZv5bRJEBl0MAAAAA2UlsRMXeFkT1fQdAM6tcREqMl0MAAAAAAcBsRAAQFkTd5QVAAFhdRCkYmEMAAAAAeR9tRIiwFUSqbQRAzQReRC+lmEMAAAAA8X5tRBBRFUSQ9gJAmrFeRFwzmUMAAAAAad5tRJfxFESUgAFAZl5fRLDCmUMAAAAA4T1uRB+SFES7CwBAMwtgRCtTmkMAAAAAWZ1uRKcyFEQRMP0/ALhgRM3kmkMAAAAAAABvRADQE0RETvo/zWRhRJZ3m0MAAAAAkkRvRCVpE0QNOPc/mhFiRIULnEMAAAAAJYlvREkCE0RZJPQ/Zr5iRJygnEMAAAAAt81vRG6bEkQvE/E/M2tjRNk2nUMAAAAAShJwRJM0EkSaBO4/ABhkRD3OnUMAAAAAAYBwRACQEUQBJOs/zcRkRMlmnkMAAAAAwpRwRNcdEURWvOc/mnFlRHsAn0MAAAAAhKlwRK2rEESPV+Q/Zh5mRFSbn0MAAAAARr5wRIQ5EES39eA/M8tmRFQ3oEMAAAAAB9NwRFrHD0TXlt0/AHhnRHvUoEMAAAAAyedwRDFVD0T7Oto/zSRoRMlyoUMAAAAAAABxRADQDkS85NY/mtFoRD0SokMAAAAAAABxRKKMDkTPbtM/Zn5pRNmyokMAAAAAAABxRENJDkQW/M8/MytqRJxUo0MAAAAAAABxROUFDkSXjMw/ANhqRIX3o0MAAAAAAABxRIfCDUReIMk/zYRrRJabpEMAAAAAAABxRABQDUS2ucU/mjFsRM1ApUMAAAAAM+FwRMvUDERnHsI/Zt5sRCvnpUMAAAAAZcJwRJZZDESZhr4/M4ttRLCOpkMAAAAAmKNwRGHeC0RY8ro/ADhuRFw3p0MAAAAAy4RwRCtjC0StYbc/zeRuRC/hp0MAAAAA/WVwRPbnCkSl1LM/mpFvRCmMqEMAAAAAAEBwRAFQCkR4SLA/Zj5wREo4qUMAAAAAUMdvRC0OCkRDB6w/M+twRJHlqUMAAAAAoU5vRFnMCURayqc/AJhxRACUqkMAAAAA8dVuRIWKCUTEkaM/zURyRJZDq0MAAAAAQl1uRLBICUSNXZ8/mvFyRFL0q0MAAAAAAIBtRADQCETxo5o/Zp5zRDWmrEMAAAAA9LZsROa7CEQ6yZU/M0t0RD9ZrUMAAAAA6O1rRMunCESu85A/APh0RHENrkMAAAAA3CRrRLCTCERXI4w/zaR1RMnCrkMAAAAA0FtqRJV/CEQ+WIc/mlF2REh5r0MAAAAAxJJpRHprCERskoI/Zv52RO4wsEMAAAAAAIBoRABQCETW0Ho/M6t3RLrpsEMAAAAAfJ1nRABQCES83HA/AFh4RK6jsUMAAAAA97pmRABQCET582Y/zQR5RMleskMAAAAAc9hlRABQCESeFl0/mrF5RAobs0MAAAAA7/VkRABQCES8RFM/Zl56RHPYs0MAAAAAAEBjRABQCETJWUc/Mwt7RAKXtEMAAAAAnOVhREiVCESIoTs/ALh7RLhWtUMAAAAAOItgRI/aCETI9y8/zWR8RJYXtkMAAAAA0zBfRNYfCUSaXCQ/mhF9RJrZtkMAAAAAb9ZdRB1lCUQQ0Bg/Zr59RMWct0MAAAAAC3xcRGWqCUQ5Ug0/M2t+RBdhuEMAAAAAAIBaRAAQCkSTWwA/ABh/RI8muUMAAAAAM2xZRIKkCkRdpug+zcR/RC/tuUMAAAAAZlhYRAQ5C0STtdA+zTiARPa0ukMAAAAAmURXRIfNC0TJ5Lg+M4+ARON9u0MAAAAAzDBWRAliDET/M6E+muWARPhHvEMAAAAA/xxVRIv2DEQ3o4k+ADyBRDMTvUMAAAAAAABURACQDUSa/2M+ZpKBRJbfvUMAAAAASjJTRAAwDkSyaDU+zeiBRB+tvkMAAAAAk2RSRADQDkSdEQc+Mz+CRM97v0MAAAAA3JZRRABwD0Rp9LE9mpWCRKZLwEMAAAAAJclQRAAQEERKiSw9AOyCRKQcwUMAAAAAAIBPRAAQEURZP/67ZkKDRMnuwUMAAAAA9TZPRAtZEUTln0O9zZiDRBTCwkMAAAAA6u1ORBeiEUTkSbO9M++DRIeWw0MAAAAA36RORCLrEUQ/KQK+mkWERCFsxEMAAAAA1FtORC00EkQ7dSq+AJyEROFCxUMAAAAAyRJORDh9EkRGiVK+ZvKERMkaxkMAAAAAAMBNRADQEkR4znq+zUiFRNfzxkMAAAAA81pNRJkeE0SIKpG+M5+FRAzOx0MAAAAA5fVMRDJtE0R30qS+mvWFRGipyEMAAAAA2JBMRMq7E0Q2X7i+AEyGROyFyUMAAAAAyitMRGMKFET00Mu+3R+GRLPDyUMAAAAAAIBLRACQFEQJG9G+LjGGRFfBxkMAAAAAgzhLRBDDFER3WtW+gEKGRCPAw0MAAAAABvFKRCH2FESAkdm+0VOGRBXAwEMAAAAAialKRDEpFUQswN2+I2WGRC/BvUMAAAAAC2JKREFcFUSE5uG+dHaGRG/DukMAAAAAjhpKRFKPFUSPBOa+xoeGRNbGt0MAAAAAAcBJRADQFURuNuq+F5mGRGTLtEMAAAAAw3JJRFAzFkQ0ce++aaqGRBnRsUMAAAAAhSVJRJ+WFkSwo/S+uruGRPXXrkMAAAAAR9hIRO/5FkTszfm+DM2GRPjfq0MAAAAACYtIRD9dF0Tu7/6+Xd6GRCHpqEMAAAAAAABIRAEQGETElQK/r++GRHLzpUMAAAAAorlHRGxgGESl8QS/AAGHROn+okMAAAAARXNHRNewGER2SQe/UhKHRIgLoEMAAAAA5yxHREIBGUQ7nQm/oyOHRE0ZnUMAAAAAieZGRK1RGUT57Au/9TSHRDoomkMAAAAAK6BGRBiiGUS0OA6/RkaHRE04l0MAAAAAAEBGRAAQGkR2qRC/mFeHRIdJlEMAAAAAYN5FRO9bGkStqRK/6WiHROhbkUMAAAAAv3xFRN6nGkTxpRS/O3qHRHBvjkMAAAAAHxtFRM3zGkRFnha/jIuHRB+Ei0MAAAAAfrlERLw/G0Stkhi/3pyHRPSZiEMAAAAAAABERAHQG0Swmhq/L66HRPGwhUMAAAAAduJDRGT3G0SmrBy/gb+HRBTJgkMAAAAA7MRDRMYeHES6uh6/0tCHRL7Ef0MAAAAAYqdDRChGHETxxCC/JOKHRKH5eUMAAAAA2YlDRIttHERPyyK/dfOHRNEwdEMAAAAAT2xDRO2UHETbzSS/xwSIRFBqbkMAAAAAAEBDRADQHERe5Sa/GBaIRBymaEMAAAAAAEBDRNPvHEQFDim/aieIRDbkYkMAAAAAAEBDRKYPHUTqMiu/uziIRJ4kXUMAAAAAAEBDRHkvHUQSVC2/DUqIRFRnV0MAAAAAAEBDREtPHUSFcS+/XluIRFesUUMAAAAAAEBDRB5vHURJizG/sGyIRKjzS0MAAAAAAEBDRACQHURkpDO/AX6IREg9RkMAAAAA2wZDRCXJHURgdDW/U4+IRDWJQEMAAAAAt81CREkCHkTCQDe/pKCIRHDXOkMAAAAAkpRCRG47HkSOCTm/9rGIRPgnNUMAAAAAbVtCRJN0HkTJzjq/R8OIRM96L0MAAAAAAABCRADQHkQzmTy/mdSIRPPPKUMAAAAAAABCRADQHkT4Sz6/6uWIRGUnJEMAAAAAAABCRADQHkQ7+z+/PPeIRCWBHkMAAAAAAABCRADQHkQCp0G/jQiJRDPdGEMAAAAAAABCRADQHkRVT0O/3xmJRI47E0MAAAAAAABCRADQHkQ49ES/MCuJRDicDUMAAAAAAABCRADQHkSylUa/gjyJRC//B0MAAAAAAABCRADQHkTKM0i/002JRHRkAkMAAAAAAABCRADQHkSEzkm/JV+JRA6Y+UIAAAAAAABCRADQHkToZUu/dnCJRNBr7kIAAAAAAABCRADQHkT8+Uy/yIGJRC1E40IAAAAAAABCRADQHkTEik6/GZOJRCUh2EIAAAAAAABCRADQHkRIGFC/a6SJRLoCzUIAAAAAAABCRADQHkSOolG/vLWJROrowUIAAAAAAABCRADQHkSaKVO/DseJRLbTtkIAAAAAAABCRADQHkR0rVS/X9iJRB3Dq0IAAAAAAABCRADQHkQgLla/semJRCC3oEIAAAAAAABCRADQHkSmq1e/AvuJRL6vlUIAAAAAAABCRADQHkQKJlm/VAyKRPmsikIAAAAAAABCRADQHkRSnVq/pR2KRJ1df0IAAAAAAABCRADQHkSEEVy/9y6KRIBqaUIAAAAAAABCRADQHkSngl2/SECKRJuAU0IAAAAAAABCRADQHkS+8F6/mlGKRO2fPUIAAAAAAABCRADQHkTRW2C/62KKRHbIJ0IAAAAAAABCRADQHkTlw2G/PXSKRDb6EUIAAAAAAABCRADQHkT/KGO/joWKRFtq+EEAAAAAAABCRADQHkQli2S/4JaKRLnyzEEAAAAAAABCRADQHkRc6mW/MaiKRIWNoUEAAAAAAABCRADQHkSrRme/g7mKRIF1bEEAAAAAAABCRNnaHkS/uGi/1MqKRNT0FUEAAAAAAABCRLLlHkT1J2q/JtyKRBJkfkAAAAAAAABCRIvwHkRSlGu/d+2KRG/vtL8AAAAAAABCRGT7HkTc/Wy/yf6KRAZg2cAAAAAAAABCRAAQH0Qlem6/GhCLRDudQsEAAAAAAABCRAAQH0R2xm+/bCGLRMsyjMEAAAAAAABCRAAQH0QEEHG/vTKLRIoEt8EAAAAAAABCRAAQH0TUVnK/DkSLRNrD4cEAAAAAAABCRAAQH0TsmnO/YFWLRF44BsIAAAAAAABCRAAQH0RR3HS/sWaLRJeFG8IAAAAAAABCRAAQH0QIG3a/A3iLRJrJMMIAAAAAAABCRDclH0Srg3e/VImLRGUERsIAAAAAAABCRG86H0Sp6Xi/ppqLRPg1W8IAAAAAAABCRKZPH0QJTXq/96uLRFVecMIAAAAAAABCRN5kH0TPrXu/Sb2LRL2+gsIAAAAAAABCRBV6H0QBDH2/ms6LRLRJjcIAAAAAAABCRAGQH0QRaX6/AIA4wgCg5kMAAAAAAABCRAGQH0Snl3+/AIA4wgCg5kMAAAAAAABCRAGQH0TcYYC/AIA4wgCg5kMAAAAAAABCRAGQH0Sk9oC/AIA4wgCg5kMAAAAAAABCRAGQH0QvioG/AIA4wgCg5kMAAAAAAABCRAGQH0R/HIK/AIA4wgCg5kMAAAAAAABCRAGQH0SWrYK/AIA4wgCg5kMAAAAAAABCRAGQH0R3PYO/AIA4wgCg5kMAAAAAAABCRAGQH0QkzIO/AIA4wgCg5kMAAAAAAABCRAGQH0SfWYS/AIA4wgCg5kMAAAAAAABCRAGQH0Tr5YS/AIA4wgCg5kMAAAAAAABCRAGQH0QLcYW/AIA4wgCg5kMAAAAAAABCRAGQH0T/+oW/AIA4wgCg5kMAAAAAAABCRAGQH0TMg4a/AIA4wgCg5kMAAAAAAABCRAGQH0RyC4e/AIA4wgCg5kMAAAAAAABCRAGQH0T1kYe/AIA4wgCg5kMAAAAAAABCRAGQH0RWF4i/AIA4wgCg5kMAAAAAAABCRAGQH0SXm4i/AIA4wgCg5kMAAAAAAABCRAGQH0S8Hom/AIA4wgCg5kMAAAAAAABCRAGQH0TGoIm/AIA4wgCg5kMAAAAAAABCRAGQH0S3IYq/AIA4wgCg5kMAAAAAAABCRAGQH0SRoYq/AIA4wgCg5kMAAAAAAABCRAGQH0RYIIu/AIA4wgCg5kMAAAAAAABCRAGQH0QMnou/AIA4wgCg5kMAAAAAAABCRAGQH0SwGoy/AIA4wgCg5kMAAAAAAABCRAGQH0RGloy/AIA4wgCg5kMAAAAAAABCRAGQH0TQEI2/AIA4wgCg5kMAAAAAAABCRAGQH0RQio2/AIA4wgCg5kMAAAAAAABCRAGQH0TJAo6/AIA4wgCg5kMAAAAAAABCRAGQH0Q7eo6/AIA4wgCg5kMAAAAAAABCRAGQH0Sq8I6/AIA4wgCg5kMAAAAAAABCRAGQH0QYZo+/AIA4wgCg5kMAAAAAAABCRAGQH0SG2o+/AIA4wgCg5kMAAAAAAABCRAGQH0T2TZC/AIA4wgCg5kMAAAAAAABCRAGQH0RrwJC/AIA4wgCg5kMAAAAAAABCRAGQH0TmMZG/AIA4wgCg5kMAAAAAAABCRAGQH0RpopG/AIA4wgCg5kMAAAAAAABCRAGQH0T2EZK/AIA4wgCg5kMAAAAAAABCRAGQH0SPgJK/AIA4wgCg5kMAAAAAAABCRAGQH0Q37pK/AIA4wgCg5kMAAAAAAABCRAGQH0TuWpO/AIA4wgCg5kMAAAAAAABCRAGQH0S3xpO/AIA4wgCg5kMAAAAAAABCRAGQH0SUMZS/AIA4wgCg5kMAAAAAAABCRAGQH0SGm5S/AIA4wgCg5kMAAAAAAABCRAGQH0SPBJW/AIA4wgCg5kMAAAAAAABCRAGQH0SybJW/AIA4wgCg5kMAAAAAAABCRAGQH0Tv05W/AIA4wgCg5kMAAAAAAABCRAGQH0RJOpa/AIA4wgCg5kMAAAAAAABCRAGQH0TCn5a/AIA4wgCg5kMAAAAAAABCRAGQH0RbBJe/AIA4wgCg5kMAAAAAAABCRAGQH0QWaJe/AIA4wgCg5kMAAAAAAABCRAGQH0T1ype/AIA4wgCg5kMAAAAAAABCRAGQH0T5LJi/AIA4wgCg5kMAAAAAAABCRAGQH0Qljpi/AIA4wgCg5kMAAAAAAABCRAGQH0R57pi/AIA4wgCg5kMAAAAAAABCRAGQH0T4TZm/AIA4wgCg5kMAAAAAAABCRAGQH0SkrJm/AIA4wgCg5kMAAAAAAABCRAGQH0R9Cpq/AIA4wgCg5kMAAAAAAABCRAGQH0SGZ5q/AIA4wgCg5kMAAAAAAABCRAGQH0TAw5q/AIA4wgCg5kMAAAAAAABCRAGQH0QtH5u/AIA4wgCg5kMAAAAAAABCRAGQH0TOeZu/AIA4wgCg5kMAAAAAAABCRLCxH0Qt6Zu/AIA4wgCg5kMAAAAAAABCRF/TH0TDV5y/AIA4wgCg5kMAAAAAAABCRA71H0STxZy/AIA4wgCg5kMAAAAAAABCRL0WIESeMp2/AIA4wgCg5kMAAAAAAABCRABQIERnrZ2/AIA4wgCg5kMAAAAARApCRERaIES+HJ6/AIA4wgCg5kMAAAAAiRRCRIlkIERUi56/AIA4wgCg5kMAAAAAzh5CRM1uIEQs+Z6/AIA4wgCg5kMAAAAAEilCRBJ5IERIZp+/AIA4wgCg5kMAAAAAVzNCRFaDIESp0p+/AIA4wgCg5kMAAAAAAUBCRACQIETrQ6C/AIA4wgCg5kMAAAAAAUBCRACQIETolqC/AIA4wgCg5kMAAAAAAUBCRACQIEQw6aC/AIA4wgCg5kMAAAAAAUBCRACQIETDOqG/AIA4wgCg5kMAAAAAAUBCRACQIESji6G/AIA4wgCg5kMAAAAAAUBCRACQIETS26G/AIA4wgCg5kMAAAAADkpCRBukIEQqSKK/AIA4wgCg5kMAAAAAG1RCRDa4IETUs6K/AIA4wgCg5kMAAAAAKV5CRFHMIETSHqO/AIA4wgCg5kMAAAAANmhCRGvgIEQkiaO/AIA4wgCg5kMAAAAARHJCRIb0IETO8qO/AIA4wgCg5kMAAAAAAIBCRAAQIUQ0ZqS/AIA4wgCg5kMAAAAAspVCRAAQIUTm2KS/AIA4wgCg5kMAAAAAZKtCRAAQIUT1SqW/AIA4wgCg5kMAAAAAFsFCRAAQIURgvKW/AIA4wgCg5kMAAAAAyNZCRAAQIUQrLaa/AIA4wgCg5kMAAAAAAABDRAAQIUQtwKa/AIA4wgCg5kMAAAAAw3ZDRAAQIUQ93ae/AIA4wgCg5kMAAAAAh+1DRAAQIUSw+ai/AIA4wgCg5kMAAAAASmRERAAQIUSMFaq/AIA4wgCg5kMAAAAADttERAAQIUTVMKu/AIA4wgCg5kMAAAAA0VFFRAAQIUSOS6y/AIA4wgCg5kMAAAAAAQBGRAAQIUTyya2/AIA4wgCg5kMAAAAAq4pGRAAQIURvB6+/AIA4wgCg5kMAAAAAVhVHRAAQIURoRLC/AIA4wgCg5kMAAAAAAKBHRAAQIUTigLG/AIA4wgCg5kMAAAAAqypIRAAQIUThvLK/AIA4wgCg5kMAAAAAVbVIRAAQIURp+LO/AIA4wgCg5kMAAAAAAEBJRAAQIUSAM7W/AIA4wgCg5kMAAAAAADBKRAAQIUTKJ7e/AIA4wgCg5kMAAAAAACBLRAAQIUSaG7m/AIA4wgCg5kMAAAAAABBMRAAQIUT2Dru/AIA4wgCg5kMAAAAAAABNRAAQIUTjAb2/AIA4wgCg5kMAAAAAAIBORAAQIUQc/r+/AIA4wgCg5kMAAAAAC7lPRAAQIUSldsK/AIA4wgCg5kMAAAAAFvJQRAAQIUS97sS/AIA4wgCg5kMAAAAAIStSRAAQIURsZse/AIA4wgCg5kMAAAAALGRTRAAQIUS43cm/AIA4wgCg5kMAAAAAN51URAAQIUSrVMy/AIA4wgCg5kMAAAAAAABWRAAQIURmGM+/AIA4wgCg5kMAAAAAwX1XRBfjIERYE9K/AIA4wgCg5kMAAAAAgvtYRC22IETdDdW/AIA4wgCg5kMAAAAAQ3laRESJIET9B9i/AIA4wgCg5kMAAAAABPdbRFpcIETCAdu/AIA4wgCg5kMAAAAAAIBeRAAQIETV69+/AIA4wgCg5kMAAAAAz8ZfRPDcH0SBg+K/AIA4wgCg5kMAAAAAng1hROCpH0QRG+W/AIA4wgCg5kMAAAAAbVRiRM92H0SNsue/AIA4wgCg5kMAAAAAPJtjRL9DH0T8Seq/AIA4wgCg5kMAAAAAC+JkRK8QH0Rj4ey/AIA4wgCg5kMAAAAAAYBmRADQHkQVGvC/AIA4wgCg5kMAAAAAsVxnRLp3HkQcDfK/AIA4wgCg5kMAAAAAYjloRHMfHkRVAPS/AIA4wgCg5kMAAAAAEhZpRCzHHUTG8/W/AIA4wgCg5kMAAAAAw/JpROZuHUR05/e/AIA4wgCg5kMAAAAAAYBrRADQHEQZO/u/AIA4wgCg5kMAAAAAXsZrROa7HET7/fu/AIA4wgCg5kMAAAAAvAxsRMunHEREwfy/AIA4wgCg5kMAAAAAGlNsRLCTHETzhP2/AIA4wgCg5kMAAAAAeJlsRJV/HEQMSf6/AIA4wgCg5kMAAAAA1d9sRHprHESQDf+/AIA4wgCg5kMAAAAAAEBtRABQHETKAQDAAIA4wgCg5kMAAAAAgsZuRA13G0StvgHAAIA4wgCg5kMAAAAABU1wRBqeGkR9ewPAAIA4wgCg5kMAAAAAh9NxRCfFGUQ+OAXAAIA4wgCg5kMAAAAACVpzRDTsGET19AbAAIA4wgCg5kMAAAAAAEB2RABQF0QfJArAAIA4wgCg5kMAAAAA+8F3RNudFkSkyAvAAIA4wgCg5kMAAAAA9kN5RLbrFUQ5bQ3AAIA4wgCg5kMAAAAA8MV6RJE5FUTfEQ/AAIA4wgCg5kMAAAAA60d8RG2HFESathDAAIA4wgCg5kMAAAAA5sl9REjVE0RpWxLAAIA4wgCg5kMAAAAAAACARADQEkRmrhTAAIA4wgCg5kMAAAAAoDOBRM/GEUR5IxfAAIA4wgCg5kMAAAAAQGeCRJ29EET8lxnAAIA4wgCg5kMAAAAA4JqDRGy0D0TsCxzAAIA4wgCg5kMAAAAAgM6ERDqrDkRHfx7AAIA4wgCg5kMAAAAAHwKGRAmiDUQK8iDAAIA4wgCg5kMAAAAAAECHRACQDER8dSPAAIA4wgCg5kMAAAAA


`.trim()];Ol(ls);let hr=0;function Cu(){return hr++,hr=hr%ls.length,ls[hr]}const xi=1e3,Gt=6,Ya=xi*Gt;class xu{constructor(){Y(this,"indexInBuffer",0);Y(this,"buffer",new Float32Array(Ya));Y(this,"replayLength",0);Y(this,"playbackStartFrame",0);Y(this,"playbackEndFrame",-1)}pushSnapshot(e){var t,n,r;this.buffer[this.indexInBuffer++]=e.activeSwingable.mousex,this.buffer[this.indexInBuffer++]=e.activeSwingable.mousey,this.buffer[this.indexInBuffer++]=e.activeSwingable.angle,this.buffer[this.indexInBuffer++]=(t=e.targets[0])==null?void 0:t.x,this.buffer[this.indexInBuffer++]=(n=e.targets[0])==null?void 0:n.y,this.buffer[this.indexInBuffer++]=(r=e.targets[0])==null?void 0:r.angle,this.indexInBuffer=this.indexInBuffer%Ya,this.replayLength=Math.min(this.replayLength+1,xi)}reset(){this.replayLength=0}exportReplay(){const e=this.playbackEndFrame-this.playbackStartFrame,t=new Float32Array(e*Gt);for(let o=0;o<e;o++)this._encodeSnapshot(t,o*Gt,o+this.playbackStartFrame);const n=t,A=new Uint8Array(n.buffer,n.byteOffset,n.byteLength).toBase64();console.log(A)}importReplay(){const e=Uint8Array.from(atob(Cu()),n=>n.charCodeAt(0)),t=new Float32Array(e.buffer);this.replayLength=Math.floor(t.length/Gt),this.playbackEndFrame=this.replayLength;for(let n=0;n<this.replayLength*Gt;n++)this.buffer[n]=t[n];this.indexInBuffer=this.replayLength*Gt}_encodeSnapshot(e,t,n){let r=Math.floor(this.indexInBuffer/Gt)-(this.replayLength-n);r+=xi,r=r%xi,r*=Gt;for(let A=0;A<Gt;A++)e[t+A]=this.buffer[r+A]}restoreSnapshot(e,t){let n=Math.floor(this.indexInBuffer/Gt)-(this.replayLength-t);n+=xi,n=n%xi,n*=Gt,e.activeSwingable.mousex=this.buffer[n++],e.activeSwingable.mousey=this.buffer[n++],e.activeSwingable.angle=this.buffer[n++],e.targets[0]||(e.targets[0]=e.nextTarget()),e.targets[0].x=this.buffer[n++],e.targets[0].y=this.buffer[n++],e.targets[0].angle=this.buffer[n++]}}const Eu="home-run-v0.1";let $t={tutorialIndex:0};const Ja=localStorage.getItem(Eu);Ja&&($t=JSON.parse(Ja));class An{constructor(){Y(this,"x",0);Y(this,"y",0);Y(this,"angle",0);Y(this,"duration",1);Y(this,"countdown",1);Y(this,"isFirstDraw",!0)}draw(e,t){if(this.isFirstDraw)this.countdown=this.duration,this.isFirstDraw=!1;else if(this.countdown-=t,this.countdown<=0)return!1;const n=Math.min(1,Math.max(0,1-this.countdown/this.duration));return this._draw(e,n),!0}static register(e,t){if(console.log(`registering effect ${e}`),e in this._registered)throw new Error(`effect already registered: ${e}`);this._registered[e]=t}static create(e){const t=this._registered[e];if(!t)throw new Error(`effect not registered: ${e}`);return t.factory()}static async preloadAll(){for(const e of Hc.NAMES){const t=this._registered[e];if(!t)throw new Error(`effect not registered: ${e}`);await t.preload()}}}Y(An,"_registered",{});const ja=200,$a=100,pr=document.createElement("canvas");let Fl;const Ea=class Ea extends An{_draw(e){e.save(),e.globalAlpha=this.countdown/this.duration,e.translate(this.x,this.y),e.rotate(this.angle),e.drawImage(pr,-ja,-$a,2*ja,2*$a),e.restore()}};An.register("foul",{factory:()=>new Ea,preload:async()=>{pr.width=Bl,pr.height=Ql;const e=pr.getContext("2d");await document.fonts.load("500px LuckiestGuy"),Fl=await jt(uu),vu(e)}});let cs=Ea;const Bl=2e3,Ql=1e3;function vu(i){const e=Bl,t=Ql,n=e/2,r=t/2;i.drawImage(Fl.buffer,n/2,0),i.font="500px LuckiestGuy",i.textAlign="center",i.textBaseline="middle",i.fillStyle="red",i.fillText("FOUL",n,r+80)}const eo=200,to=100,gr=document.createElement("canvas"),va=class va extends An{_draw(e){e.save(),e.globalAlpha=this.countdown/this.duration,e.translate(this.x,this.y),e.rotate(this.angle),e.drawImage(gr,-eo,-to,2*eo,2*to),e.restore()}};An.register("ok",{factory:()=>new va,preload:async()=>{gr.width=zl,gr.height=Gl;const e=gr.getContext("2d");await document.fonts.load("500px LuckiestGuy"),Su(e)}});let us=va;const zl=2e3,Gl=1e3;function Su(i){const e=zl,t=Gl,n=e/2,r=t/2,A=600,o=300,l=30,f=[];for(let c=0;c<l;c++){const s=c%2==0?.9+.1*Math.random():1.4+.2*Math.random(),a=2*Math.PI*c/l+.05*Math.random(),u=n+A*s*Math.cos(a),h=r+o*s*Math.sin(a);f.push([u,h])}i.beginPath();for(const[c,g]of f)i.lineTo(c-50,g-50);i.closePath(),i.fillStyle="black",i.fill(),i.strokeStyle="black",i.lineWidth=20,i.stroke(),i.beginPath();for(const[c,g]of f)i.lineTo(c,g);i.closePath(),i.fillStyle="white",i.fill(),i.strokeStyle="black",i.lineWidth=20,i.stroke(),i.font="500px LuckiestGuy",i.textAlign="center",i.textBaseline="middle",i.fillStyle="black",i.fillText("OK",n,r+80)}const no=200,io=100,mr=document.createElement("canvas"),Sa=class Sa extends An{_draw(e){e.save(),e.globalAlpha=this.countdown/this.duration,e.translate(this.x,this.y),e.rotate(this.angle),e.drawImage(mr,-no,-io,2*no,2*io),e.restore()}};An.register("perfect",{factory:()=>new Sa,preload:async()=>{mr.width=Hl,mr.height=Vl;const e=mr.getContext("2d");await document.fonts.load("500px LuckiestGuy"),wu(e)}});let tA=Sa;const Hl=2e3,Vl=1e3;function wu(i){const e=Hl,t=Vl,n=e/2,r=t/2,A=600,o=300,l=30,f=[];for(let c=0;c<l;c++){const s=c%2==0?.9+.1*Math.random():1.4+.2*Math.random(),a=2*Math.PI*c/l+.05*Math.random(),u=n+A*s*Math.cos(a),h=r+o*s*Math.sin(a);f.push([u,h])}i.beginPath();for(const[c,g]of f)i.lineTo(c-50,g-50);i.closePath(),i.fillStyle="black",i.fill(),i.strokeStyle="black",i.lineWidth=20,i.stroke(),i.beginPath();for(const[c,g]of f)i.lineTo(c,g);i.closePath(),i.fillStyle="white",i.fill(),i.strokeStyle="black",i.lineWidth=20,i.stroke(),i.font="500px LuckiestGuy",i.textAlign="center",i.textBaseline="middle",i.fillStyle="black",i.fillText("POW",n,r+80)}function yu(i,e,t){const n=Wl(i),r=Kl(e);let A;return n==="handle"?(A=new cs,gn("foulHit")):n==="good"&&r==="strong"?(A=new tA,gn("powHitC"),gn("powHit"),t.powStreak>=2&&gn("streakHit")):(A=new us,au("powHitB")),A}function Wl(i){return i>2.65?"glanced":i>1.35?"good":i>.7?"neck":"handle"}function Kl(i){return i>4e3?"strong":i<2e3?"weak":"ok"}const ro=200,Ao=100,wa=class wa extends An{constructor(){super(...arguments);Y(this,"spineRatio",0);Y(this,"power",0);Y(this,"duration",5)}_draw(t){t.save(),t.globalAlpha=this.countdown/this.duration,t.translate(this.x,this.y),t.strokeStyle="red",t.lineWidth=2,t.strokeRect(-ro,-Ao,2*ro,2*Ao),t.font="50px Sans Serif",t.textAlign="center",t.fillText(`spine: ${this.spineRatio.toFixed(2)} (${Wl(this.spineRatio)})`,0,-30),t.fillText(`power: ${this.power.toFixed(2)} (${Kl(this.power)})`,0,30),t.restore()}};An.register("debug-effect",{factory:()=>new wa,preload:async()=>{}});let so=wa;const Tu=100;let CA=0;function bu(i,e){if(CA>0){CA--;return}i>.03&&e>10&&(gn("whoosh"),CA=Tu)}let Ai;const xA=[{label:"Swing the Bat"},{label:"Hit the target"},{label:"Hit the ball"}],ya=class ya extends ft{onOpen(e){Ai||(Ai=tr("ikoliks_aj-elevator-elevator-music-342629.ogg")),Ai.loop(!0),Ai.volume(.2),Ai.play()}onClose(){Ai.stop()}static advanceTutorial(e){if($t.tutorialIndex===xA.length-1){e.switchToGui("main-menu");return}$t.tutorialIndex++,ft.create("tutorial-gui",e).setLabel("tutorialDisplay",xA[$t.tutorialIndex].label)}elements(){return[{id:"tutorialDisplay",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 50%;
          font-size: 90px;
          pointer-events: none;
        `,label:xA[$t.tutorialIndex].label,variant:"label",onclick:()=>{}},{id:"tutorialBackBtn",style:`
          width: 50px;
          height: 50px;
          left: 25px;
          top: 25px;
        `,onclick:e=>{e.switchToGui("main-menu")},label:"BACK"}]}};ft.register("tutorial-gui",{factory:e=>new ya(e),preload:async()=>{}});let Ji=ya;const fs={x:0,y:1e3},Wr=.003;let ao=0;function oo(i,e,t){return i*(1-t)+e*t}let lo=0;function Iu(i,e){const{mousex:t,mousey:n}=e;i+=lo;const{activeSwingable:r}=e,A=r.mousex,o=r.mousey,l=t,f=n;let c=i;for(;c>Wr;)r.mousex=oo(A,l,1-c/i),r.mousey=oo(o,f,1-c/i),ku(Wr,e),ao++,e.instantReplay.pushSnapshot(e),c-=Wr;if(lo=c,r.mousex=t,r.mousey=n,ao<100){const g=r.points[0],s=r.points[1];s.x=g.x,s.y=g.y+r.segmentLength,s.prevX=s.x,s.prevY=s.y,rA(Math.PI/2)}}function ku(i,e){const{activeSwingable:t,targets:n,collisionGrids:r}=e,A=1;for(const a of n){if(a.spawnCountdown>0){if(!e.activeSwingable.isPitchMeterFull)continue;a.spawnCountdown-=i,a.spawnCountdown<=0&&e.ghostCtx.clearRect(0,0,qe.w,qe.h);continue}a.dx*=A,a.dy*=A,(e.currentGui!=="tutorial-gui"||$t.tutorialIndex>1)&&(a.dx+=fs.x*i,a.dy+=fs.y*i),a.x+=i*a.dx,a.y+=i*a.dy,a.angle+=i*a.da}const o=t.points.at(-1),l=o.x,f=o.y,c=t.angle;t.simulate(i);const g=t.angle-c,s=Math.hypot(o.x-l,o.y-f);bu(g,s);for(const a of t.physicsSprites){const u=r.get(a);if(u){for(const h of n)if(!(h.spawnCountdown>0)&&!h.hasBeenHit&&Uu(h,t,a,u,i)){e.currentGui==="tutorial-gui"&&($t.tutorialIndex===1||$t.tutorialIndex===2)&&Ji.advanceTutorial(e),h.hasBeenHit=!0;const m=Yt.spineRatio,d=yu(m,Xl,e);d.x=nA.x,d.y=nA.y,d.angle=(.1+.1*Math.random())*(Math.random()>.5?1:-1),e.activeEffects.push(d),e.currentGui==="playing-gui"&&d instanceof tA&&(e.powStreak++,h.hasBeenPowHit=!0),e.activeSwingable.draw(e.ghostCtx,!0),h.draw(e.ghostCtx,!0),e.activeSwingable instanceof as;return}}}}let Yt=null,Xl=0,nA=null;function Uu(i,e,t,n,r){const A=Ou(e,t),o=Nu(i.x,i.y,A,t);if(Yt=gu(n,o.x,o.y),!(Yt!=null&&Yt.hit))return!1;nA={x:i.x,y:i.y};const l=Lu(Yt.escapeX,Yt.escapeY,A,t),f=Fu(Yt.normalX,Yt.normalY,A,t),c=n.localTargetRadius*t.scale;nA={x:l.x-f.x*c,y:l.y-f.y*c},i.x=l.x,i.y=l.y;const g=e.points[t.velocityPointIndex],s=Pu(g,r),a=i.dx*f.x+i.dy*f.y,u=s.x*f.x+s.y*f.y,h=a-u;if(h>=0)return!1;const m=1+t.massRatio,p=((1-t.massRatio)*a+2*t.massRatio*u)/m,d=((t.massRatio-1)*u+2*a)/m;Xl=Math.abs(h);let R=.5;h>-2e3&&(R=1),i.dx+=R*(p-a)*f.x,i.dy+=R*(p-a)*f.y;const E=Math.min(1,Yt.spineRatio);return Du(g,s.x+E*(d-u)*f.x,s.y+E*(d-u)*f.y,r),i.angle+=r*i.da,!0}function Pu(i,e){return{x:(i.x-i.prevX)/e,y:(i.y-i.prevY)/e}}function Du(i,e,t,n){i.prevX=i.x-e*n,i.prevY=i.y-t*n}function Ou(i,e){const t=i.points[e.basePointIndex],n=i.points[e.directionPointIndex],r=(n.x-t.x)*e.directionSign,A=(n.y-t.y)*e.directionSign;return{x:t.x,y:t.y,angle:Math.atan2(A,r)}}function Nu(i,e,t,n){const r=t.angle-n.sprite.canonicalAngle,A=i-t.x,o=e-t.y,l=Math.cos(r),f=Math.sin(r);return{x:(A*l+o*f)/n.scale,y:(-A*f+o*l)/n.scale}}function Lu(i,e,t,n){const r=t.angle-n.sprite.canonicalAngle,A=i*n.scale,o=e*n.scale,l=Math.cos(r),f=Math.sin(r);return{x:t.x+A*l-o*f,y:t.y+A*f+o*l}}function Fu(i,e,t,n){const r=t.angle-n.sprite.canonicalAngle,A=Math.cos(r),o=Math.sin(r);return{x:i*A-e*o,y:i*o+e*A}}class ei{constructor(){Y(this,"spawnCountdown",0);Y(this,"x",0);Y(this,"y",0);Y(this,"dx",0);Y(this,"dy",0);Y(this,"angle",0);Y(this,"da",0);Y(this,"hasBeenHit",!1);Y(this,"hasBeenPowHit",!1)}static register(e,t){if(console.log(`registering target ${e}`),e in this._registered)throw new Error(`target already registered: ${e}`);this._registered[e]=t}static create(e){const t=this._registered[e];if(!t)throw new Error(`target not registered: ${e}`);return t.factory()}static async preloadAll(){for(const e of Hr.NAMES){const t=this._registered[e];if(!t)throw new Error(`target not registered: ${e}`);await t.preload()}}}Y(ei,"_registered",{});let co,Mr;const Ta=class Ta extends ei{draw(e,t){(t?Mr:co).draw(e,this.x,this.y,this.angle)}};ei.register("baseball",{factory:()=>new Ta,preload:async()=>{co=await jt(Xa),Mr=await jt(Xa);const{width:e,height:t}=Mr.buffer,n=Mr.buffer.getContext("2d");n.globalCompositeOperation="source-atop",n.fillStyle="#aaa",n.fillRect(0,0,e,t)}});let ds=Ta;const Zl=2;let uo=!1;class Bu{constructor(e,t,n){Y(this,"instantReplay",new xu);Y(this,"mousex",1);Y(this,"mousey",1);Y(this,"_powStreak",0);Y(this,"isTouchDevice",!1);Y(this,"activeGui");Y(this,"collisionGrids",new Map);Y(this,"activeSwingable");Y(this,"allSwingables",[]);Y(this,"activeEffects",[]);Y(this,"targets",[new ds]);Y(this,"_currentGui","start-menu");Y(this,"currentTarget","baseball");if(this.cvs=e,this.ghostCvs=t,this.ghostCtx=n,uo)throw new Error("app already constructed");uo=!0,this.allSwingables.push(...Il.NAMES.map(r=>$n.create(r))),this.activeSwingable=this.allSwingables[0],this.activeGui=ft.create(this._currentGui,this),this.switchToGui(this._currentGui)}get powStreak(){return this._powStreak}set powStreak(e){this._powStreak=e,this.currentGui==="playing-gui"&&os.updateStreakLabel(this)}resize(){qe.resize(),ft.create(this._currentGui,this).resizeElements();const{w:e,h:t,targetRadius:n}=qe;this.cvs.width=e,this.cvs.height=t,this.ghostCvs.width=e,this.ghostCvs.height=t,this.activeSwingable.segmentLength=this.activeSwingable.relativeLength*(Math.min(e,t)/5),this.collisionGrids.clear();for(const r of this.allSwingables)for(const A of r.physicsSprites)this.collisionGrids.set(A,pu({sprite:A.sprite,scale:A.scale,targetRadius:n}));this.targets.length>0&&this.respawnTarget(this.targets[0])}nextTarget(){const e=this.currentTarget;return ei.create(e)}respawnTarget(e){if(this.currentGui==="tutorial-gui"&&$t.tutorialIndex===1)e.spawnCountdown=0,e.x=qe.w/2,e.y=qe.h/2,e.dx=0,e.dy=0;else{e.spawnCountdown=Zl,e.x=-qe.targetRadius,e.y=qe.h/2,e.dx=900;const t=(qe.w/2-e.x)/e.dx;e.dy=-.5*fs.y*t}}get currentGui(){return this._currentGui}switchToGui(e,t=!1){t||window.history.pushState({q:e},"",`?q=${e}`),this.activeGui.hide(this),this.activeGui=ft.create(e,this),this.activeGui.show(this),this._currentGui=e,this.resize()}cycleTarget(){let e=Hr.NAMES.indexOf(this.currentTarget);e++,e=e%Hr.NAMES.length,this.currentTarget=Hr.NAMES[e]}}const Jn=2*Math.PI;let jn=0,Yi=0,On=!1,cA=!0,iA=0,Ei=0;function Qu(i){let e=i%Jn;return e>Math.PI&&(e-=Jn),e<-Math.PI&&(e+=Jn),e}function zu(i,e,t,n,r){i.beginPath(),i.arc(e,t,n,0,Jn),i.stroke();const A=Math.min(Yi-jn,Jn);if(A<=0)return;i.beginPath(),i.moveTo(e,t),i.arc(e,t,n,jn,jn+A),i.closePath(),i.fillStyle=On?"green":"red",On&&(cA=!1);const o=On&&r.targets[0].spawnCountdown>0;if(i.fill(),On||Pn.draw(i,e,t,iA,.15),o){const l=1-r.targets[0].spawnCountdown/Zl,f=t+n-l*2*n;i.save(),i.beginPath(),i.arc(e,t,n,0,Jn),i.clip(),i.fillStyle="blue",i.fillRect(e-n,f,2*n,t+n-f),i.restore()}i.beginPath(),i.arc(e,t,n,0,2*Math.PI),i.closePath(),i.strokeStyle="black",i.lineWidth=10,i.stroke()}function Gu(i){Ei+=Qu(i-iA),iA=i,Ei<jn&&(jn=Ei),Ei>Yi&&(Yi=Ei),On=!cA||Yi-jn>=Jn}function rA(i){cA=!0,iA=i,Ei=i,jn=i,Yi=i}const ba=class ba extends ft{onOpen(){}onClose(){}elements(){return[{id:"titleBtn",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 50%;
          font-size: 90px;
          pointer-events: none;
        `,label:"HOME RUN",variant:"label",onclick:()=>{}},{id:"titleSecondBtn",style:`
          width: 100%;
          height: 200px;
          top: 20%;
          left: 50%;
          font-size: 70px;
          pointer-events: none;
        `,label:"CHALLENGE",variant:"label",onclick:()=>{}},{id:"playBtn",style:`
          width: 200px;
          height: 100px;
          top: 75%;
          left: 50%;
        `,onclick:e=>{e.switchToGui("main-menu"),eA(),rA(e.activeSwingable.angle),e.activeSwingable.isPitchMeterFull=!1,gn("buttonClick")},label:"PLAY"}]}};ft.register("start-menu",{factory:e=>new ba(e),preload:async()=>{}});let fo=ba,EA,vA;const ho=.2,po=.55,Ia=class Ia extends $n{constructor(){super(...arguments);Y(this,"physicsSprites",[{get sprite(){return vA},scale:po,basePointIndex:this.pointCount-1,directionPointIndex:this.pointCount-2,directionSign:-1,velocityPointIndex:this.pointCount-1,massRatio:2}]);Y(this,"relativeLength",.3);Y(this,"gravity",1400);Y(this,"damping",.997);Y(this,"tipDamping",.997);Y(this,"constraintIterations",1);Y(this,"label","flail")}get flailRadius(){return this.segmentLength*1}draw(t){const{points:n,mousex:r,mousey:A}=this;let o=r,l=A;for(let f=1;f<n.length;f++){const c=n.at(f),g=Math.atan2(c.y-l,c.x-o);if(f===n.length-1){EA.draw(t,o,l,g,ho),vA.draw(t,c.x,c.y,g,po);const s=this.flailRadius;t.strokeStyle="red",t.lineWidth=s*.05,t.beginPath(),t.arc(c.x,c.y,s,0,2*Math.PI),t.stroke()}else EA.draw(t,o,l,g,ho);t.globalAlpha=1,o=c.x,l=c.y}}};$n.register("flail",{preload:async()=>{EA=await jt(ou),vA=await jt(lu)},factory:()=>new Ia(8)});let go=Ia,mo;const ka=class ka extends ei{draw(e,t){t&&(e.globalAlpha=.4),mo.draw(e,this.x,this.y,this.angle),e.globalAlpha=1}};ei.register("crystal",{factory:()=>new ka,preload:async()=>{mo=await jt(cu)}});let Mo=ka;const Ua=class Ua extends ft{elements(){return[{id:"exitReplayBtn",style:`
          width: 50px;
          height: 50px;
          left: 25px;
          top: 25px;
        `,onclick:e=>{e.switchToGui("playing-gui")},label:"BACK"},{id:"exportReplayBtn",style:`
          width: 50px;
          height: 50px;
          right: 25px;
          top: 25px;
        `,onclick:e=>{e.instantReplay.exportReplay()},label:"EXPORT"},{id:"importReplayBtn",style:`
          width: 50px;
          height: 50px;
          right: 25px;
          top: 100px;
        `,onclick:e=>{e.instantReplay.importReplay()},label:"IMPORT"},{id:"replayStartBar",style:`
          width: 100%;
          height: 50px;
          left: 50%;
          bottom: 50px;
        `,onclick:e=>{const t=e.mousex/qe.w,n=Math.floor(t*e.instantReplay.replayLength);e.instantReplay.playbackStartFrame=n;const r=`${Math.floor(100*n/e.instantReplay.replayLength)}%`;document.getElementById("replayStartSlider").style.left=r},label:"START"},{id:"replayStartSlider",style:`
          width: 50px;
          height: 50px;
          left: 50%;
          bottom: 50px;
          pointer-events: none;
        `,onclick:e=>{},label:""},{id:"replayEndBar",style:`
          width: 100%;
          height: 50px;
          left: 50%;
          bottom: 0px;
        `,onclick:e=>{const t=e.mousex/qe.w,n=Math.floor(t*e.instantReplay.replayLength);e.instantReplay.playbackEndFrame=n;const r=`${Math.floor(100*n/e.instantReplay.replayLength)}%`;document.getElementById("replayEndSlider").style.left=r},label:"END"},{id:"replayEndSlider",style:`
          width: 50px;
          height: 50px;
          left: 50%;
          bottom: 0px;
          pointer-events: none;
        `,onclick:e=>{},label:""},{id:"replayProgressSlider",style:`
          width: 50px;
          height: 50px;
          left: 50%;
          bottom: 100px;
        `,onclick:e=>{},label:""}]}};ft.register("replay-gui",{factory:e=>new Ua(e),preload:async()=>{}});let Ro=Ua;/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const la="183",Hu=0,_o=1,Vu=2,Kr=1,Wu=2,Ki=3,Ln=0,Tt=1,pn=2,Mn=0,Si=1,Co=2,xo=3,Eo=4,Ku=5,Xn=100,Xu=101,Zu=102,qu=103,Yu=104,Ju=200,ju=201,$u=202,ef=203,hs=204,ps=205,tf=206,nf=207,rf=208,Af=209,sf=210,af=211,of=212,lf=213,cf=214,gs=0,ms=1,Ms=2,Ti=3,Rs=4,_s=5,Cs=6,xs=7,ql=0,uf=1,ff=2,tn=0,Yl=1,Jl=2,jl=3,$l=4,ec=5,tc=6,nc=7,ic=300,ti=301,bi=302,SA=303,wA=304,uA=306,Es=1e3,mn=1001,vs=1002,ht=1003,df=1004,Rr=1005,vt=1006,yA=1007,qn=1008,Ot=1009,rc=1010,Ac=1011,ji=1012,ca=1013,sn=1014,Wt=1015,Cn=1016,ua=1017,fa=1018,$i=1020,sc=35902,ac=35899,oc=1021,lc=1022,Nt=1023,xn=1026,Yn=1027,cc=1028,da=1029,Ii=1030,ha=1031,pa=1033,Xr=33776,Zr=33777,qr=33778,Yr=33779,Ss=35840,ws=35841,ys=35842,Ts=35843,bs=36196,Is=37492,ks=37496,Us=37488,Ps=37489,Ds=37490,Os=37491,Ns=37808,Ls=37809,Fs=37810,Bs=37811,Qs=37812,zs=37813,Gs=37814,Hs=37815,Vs=37816,Ws=37817,Ks=37818,Xs=37819,Zs=37820,qs=37821,Ys=36492,Js=36494,js=36495,$s=36283,ea=36284,ta=36285,na=36286,hf=3200,pf=0,gf=1,Dn="",Dt="srgb",ki="srgb-linear",AA="linear",Ze="srgb",si=7680,vo=519,mf=512,Mf=513,Rf=514,ga=515,_f=516,Cf=517,ma=518,xf=519,So=35044,wo="300 es",en=2e3,sA=2001;function Ef(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function aA(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function vf(){const i=aA("canvas");return i.style.display="block",i}const yo={};function To(...i){const e="THREE."+i.shift();console.log(e,...i)}function uc(i){const e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){const t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function ke(...i){i=uc(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function Ve(...i){i=uc(i);const e="THREE."+i.shift();{const t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function oA(...i){const e=i.join(" ");e in yo||(yo[e]=!0,ke(...i))}function Sf(i,e,t){return new Promise(function(n,r){function A(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(A,t);break;default:n()}}setTimeout(A,t)})}const wf={[gs]:ms,[Ms]:Cs,[Rs]:xs,[Ti]:_s,[ms]:gs,[Cs]:Ms,[xs]:Rs,[_s]:Ti};class Pi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const A=r.indexOf(t);A!==-1&&r.splice(A,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let A=0,o=r.length;A<o;A++)r[A].call(this,e);e.target=null}}}const xt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],TA=Math.PI/180,ia=180/Math.PI;function nr(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(xt[i&255]+xt[i>>8&255]+xt[i>>16&255]+xt[i>>24&255]+"-"+xt[e&255]+xt[e>>8&255]+"-"+xt[e>>16&15|64]+xt[e>>24&255]+"-"+xt[t&63|128]+xt[t>>8&255]+"-"+xt[t>>16&255]+xt[t>>24&255]+xt[n&255]+xt[n>>8&255]+xt[n>>16&255]+xt[n>>24&255]).toLowerCase()}function Qe(i,e,t){return Math.max(e,Math.min(t,i))}function yf(i,e){return(i%e+e)%e}function bA(i,e,t){return(1-t)*i+t*e}function Li(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function yt(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}class Ye{constructor(e=0,t=0){Ye.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Qe(this.x,e.x,t.x),this.y=Qe(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Qe(this.x,e,t),this.y=Qe(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qe(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Qe(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),A=this.x-e.x,o=this.y-e.y;return this.x=A*n-o*r+e.x,this.y=A*r+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Di{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,A,o,l){let f=n[r+0],c=n[r+1],g=n[r+2],s=n[r+3],a=A[o+0],u=A[o+1],h=A[o+2],m=A[o+3];if(s!==m||f!==a||c!==u||g!==h){let p=f*a+c*u+g*h+s*m;p<0&&(a=-a,u=-u,h=-h,m=-m,p=-p);let d=1-l;if(p<.9995){const R=Math.acos(p),E=Math.sin(R);d=Math.sin(d*R)/E,l=Math.sin(l*R)/E,f=f*d+a*l,c=c*d+u*l,g=g*d+h*l,s=s*d+m*l}else{f=f*d+a*l,c=c*d+u*l,g=g*d+h*l,s=s*d+m*l;const R=1/Math.sqrt(f*f+c*c+g*g+s*s);f*=R,c*=R,g*=R,s*=R}}e[t]=f,e[t+1]=c,e[t+2]=g,e[t+3]=s}static multiplyQuaternionsFlat(e,t,n,r,A,o){const l=n[r],f=n[r+1],c=n[r+2],g=n[r+3],s=A[o],a=A[o+1],u=A[o+2],h=A[o+3];return e[t]=l*h+g*s+f*u-c*a,e[t+1]=f*h+g*a+c*s-l*u,e[t+2]=c*h+g*u+l*a-f*s,e[t+3]=g*h-l*s-f*a-c*u,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,A=e._z,o=e._order,l=Math.cos,f=Math.sin,c=l(n/2),g=l(r/2),s=l(A/2),a=f(n/2),u=f(r/2),h=f(A/2);switch(o){case"XYZ":this._x=a*g*s+c*u*h,this._y=c*u*s-a*g*h,this._z=c*g*h+a*u*s,this._w=c*g*s-a*u*h;break;case"YXZ":this._x=a*g*s+c*u*h,this._y=c*u*s-a*g*h,this._z=c*g*h-a*u*s,this._w=c*g*s+a*u*h;break;case"ZXY":this._x=a*g*s-c*u*h,this._y=c*u*s+a*g*h,this._z=c*g*h+a*u*s,this._w=c*g*s-a*u*h;break;case"ZYX":this._x=a*g*s-c*u*h,this._y=c*u*s+a*g*h,this._z=c*g*h-a*u*s,this._w=c*g*s+a*u*h;break;case"YZX":this._x=a*g*s+c*u*h,this._y=c*u*s+a*g*h,this._z=c*g*h-a*u*s,this._w=c*g*s-a*u*h;break;case"XZY":this._x=a*g*s-c*u*h,this._y=c*u*s-a*g*h,this._z=c*g*h+a*u*s,this._w=c*g*s+a*u*h;break;default:ke("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],A=t[8],o=t[1],l=t[5],f=t[9],c=t[2],g=t[6],s=t[10],a=n+l+s;if(a>0){const u=.5/Math.sqrt(a+1);this._w=.25/u,this._x=(g-f)*u,this._y=(A-c)*u,this._z=(o-r)*u}else if(n>l&&n>s){const u=2*Math.sqrt(1+n-l-s);this._w=(g-f)/u,this._x=.25*u,this._y=(r+o)/u,this._z=(A+c)/u}else if(l>s){const u=2*Math.sqrt(1+l-n-s);this._w=(A-c)/u,this._x=(r+o)/u,this._y=.25*u,this._z=(f+g)/u}else{const u=2*Math.sqrt(1+s-n-l);this._w=(o-r)/u,this._x=(A+c)/u,this._y=(f+g)/u,this._z=.25*u}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Qe(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,A=e._z,o=e._w,l=t._x,f=t._y,c=t._z,g=t._w;return this._x=n*g+o*l+r*c-A*f,this._y=r*g+o*f+A*l-n*c,this._z=A*g+o*c+n*f-r*l,this._w=o*g-n*l-r*f-A*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,A=e._z,o=e._w,l=this.dot(e);l<0&&(n=-n,r=-r,A=-A,o=-o,l=-l);let f=1-t;if(l<.9995){const c=Math.acos(l),g=Math.sin(c);f=Math.sin(f*c)/g,t=Math.sin(t*c)/g,this._x=this._x*f+n*t,this._y=this._y*f+r*t,this._z=this._z*f+A*t,this._w=this._w*f+o*t,this._onChangeCallback()}else this._x=this._x*f+n*t,this._y=this._y*f+r*t,this._z=this._z*f+A*t,this._w=this._w*f+o*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),A=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),A*Math.sin(t),A*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class z{constructor(e=0,t=0,n=0){z.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(bo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(bo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,A=e.elements;return this.x=A[0]*t+A[3]*n+A[6]*r,this.y=A[1]*t+A[4]*n+A[7]*r,this.z=A[2]*t+A[5]*n+A[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,A=e.elements,o=1/(A[3]*t+A[7]*n+A[11]*r+A[15]);return this.x=(A[0]*t+A[4]*n+A[8]*r+A[12])*o,this.y=(A[1]*t+A[5]*n+A[9]*r+A[13])*o,this.z=(A[2]*t+A[6]*n+A[10]*r+A[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,A=e.x,o=e.y,l=e.z,f=e.w,c=2*(o*r-l*n),g=2*(l*t-A*r),s=2*(A*n-o*t);return this.x=t+f*c+o*s-l*g,this.y=n+f*g+l*c-A*s,this.z=r+f*s+A*g-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,A=e.elements;return this.x=A[0]*t+A[4]*n+A[8]*r,this.y=A[1]*t+A[5]*n+A[9]*r,this.z=A[2]*t+A[6]*n+A[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Qe(this.x,e.x,t.x),this.y=Qe(this.y,e.y,t.y),this.z=Qe(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Qe(this.x,e,t),this.y=Qe(this.y,e,t),this.z=Qe(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qe(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,A=e.z,o=t.x,l=t.y,f=t.z;return this.x=r*f-A*l,this.y=A*o-n*f,this.z=n*l-r*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return IA.copy(this).projectOnVector(e),this.sub(IA)}reflect(e){return this.sub(IA.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Qe(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const IA=new z,bo=new Di;class De{constructor(e,t,n,r,A,o,l,f,c){De.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,A,o,l,f,c)}set(e,t,n,r,A,o,l,f,c){const g=this.elements;return g[0]=e,g[1]=r,g[2]=l,g[3]=t,g[4]=A,g[5]=f,g[6]=n,g[7]=o,g[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,A=this.elements,o=n[0],l=n[3],f=n[6],c=n[1],g=n[4],s=n[7],a=n[2],u=n[5],h=n[8],m=r[0],p=r[3],d=r[6],R=r[1],E=r[4],v=r[7],w=r[2],y=r[5],b=r[8];return A[0]=o*m+l*R+f*w,A[3]=o*p+l*E+f*y,A[6]=o*d+l*v+f*b,A[1]=c*m+g*R+s*w,A[4]=c*p+g*E+s*y,A[7]=c*d+g*v+s*b,A[2]=a*m+u*R+h*w,A[5]=a*p+u*E+h*y,A[8]=a*d+u*v+h*b,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],A=e[3],o=e[4],l=e[5],f=e[6],c=e[7],g=e[8];return t*o*g-t*l*c-n*A*g+n*l*f+r*A*c-r*o*f}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],A=e[3],o=e[4],l=e[5],f=e[6],c=e[7],g=e[8],s=g*o-l*c,a=l*f-g*A,u=c*A-o*f,h=t*s+n*a+r*u;if(h===0)return this.set(0,0,0,0,0,0,0,0,0);const m=1/h;return e[0]=s*m,e[1]=(r*c-g*n)*m,e[2]=(l*n-r*o)*m,e[3]=a*m,e[4]=(g*t-r*f)*m,e[5]=(r*A-l*t)*m,e[6]=u*m,e[7]=(n*f-c*t)*m,e[8]=(o*t-n*A)*m,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,A,o,l){const f=Math.cos(A),c=Math.sin(A);return this.set(n*f,n*c,-n*(f*o+c*l)+o+e,-r*c,r*f,-r*(-c*o+f*l)+l+t,0,0,1),this}scale(e,t){return this.premultiply(kA.makeScale(e,t)),this}rotate(e){return this.premultiply(kA.makeRotation(-e)),this}translate(e,t){return this.premultiply(kA.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const kA=new De,Io=new De().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ko=new De().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Tf(){const i={enabled:!0,workingColorSpace:ki,spaces:{},convert:function(r,A,o){return this.enabled===!1||A===o||!A||!o||(this.spaces[A].transfer===Ze&&(r.r=Rn(r.r),r.g=Rn(r.g),r.b=Rn(r.b)),this.spaces[A].primaries!==this.spaces[o].primaries&&(r.applyMatrix3(this.spaces[A].toXYZ),r.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===Ze&&(r.r=wi(r.r),r.g=wi(r.g),r.b=wi(r.b))),r},workingToColorSpace:function(r,A){return this.convert(r,this.workingColorSpace,A)},colorSpaceToWorking:function(r,A){return this.convert(r,A,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Dn?AA:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,A=this.workingColorSpace){return r.fromArray(this.spaces[A].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,A,o){return r.copy(this.spaces[A].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,A){return oA("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(r,A)},toWorkingColorSpace:function(r,A){return oA("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(r,A)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[ki]:{primaries:e,whitePoint:n,transfer:AA,toXYZ:Io,fromXYZ:ko,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Dt},outputColorSpaceConfig:{drawingBufferColorSpace:Dt}},[Dt]:{primaries:e,whitePoint:n,transfer:Ze,toXYZ:Io,fromXYZ:ko,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Dt}}}),i}const Ge=Tf();function Rn(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function wi(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let ai;class bf{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{ai===void 0&&(ai=aA("canvas")),ai.width=e.width,ai.height=e.height;const r=ai.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=ai}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=aA("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),A=r.data;for(let o=0;o<A.length;o++)A[o]=Rn(A[o]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Rn(t[n]/255)*255):t[n]=Rn(t[n]);return{data:t,width:e.width,height:e.height}}else return ke("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let If=0;class Ma{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:If++}),this.uuid=nr(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let A;if(Array.isArray(r)){A=[];for(let o=0,l=r.length;o<l;o++)r[o].isDataTexture?A.push(UA(r[o].image)):A.push(UA(r[o]))}else A=UA(r);n.url=A}return t||(e.images[this.uuid]=n),n}}function UA(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?bf.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(ke("Texture: Unable to serialize Texture."),{})}let kf=0;const PA=new z;class wt extends Pi{constructor(e=wt.DEFAULT_IMAGE,t=wt.DEFAULT_MAPPING,n=mn,r=mn,A=vt,o=qn,l=Nt,f=Ot,c=wt.DEFAULT_ANISOTROPY,g=Dn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:kf++}),this.uuid=nr(),this.name="",this.source=new Ma(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=A,this.minFilter=o,this.anisotropy=c,this.format=l,this.internalFormat=null,this.type=f,this.offset=new Ye(0,0),this.repeat=new Ye(1,1),this.center=new Ye(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new De,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=g,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(PA).x}get height(){return this.source.getSize(PA).y}get depth(){return this.source.getSize(PA).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){ke(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){ke(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==ic)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Es:e.x=e.x-Math.floor(e.x);break;case mn:e.x=e.x<0?0:1;break;case vs:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Es:e.y=e.y-Math.floor(e.y);break;case mn:e.y=e.y<0?0:1;break;case vs:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}wt.DEFAULT_IMAGE=null;wt.DEFAULT_MAPPING=ic;wt.DEFAULT_ANISOTROPY=1;class lt{constructor(e=0,t=0,n=0,r=1){lt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,A=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*r+o[12]*A,this.y=o[1]*t+o[5]*n+o[9]*r+o[13]*A,this.z=o[2]*t+o[6]*n+o[10]*r+o[14]*A,this.w=o[3]*t+o[7]*n+o[11]*r+o[15]*A,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,A;const f=e.elements,c=f[0],g=f[4],s=f[8],a=f[1],u=f[5],h=f[9],m=f[2],p=f[6],d=f[10];if(Math.abs(g-a)<.01&&Math.abs(s-m)<.01&&Math.abs(h-p)<.01){if(Math.abs(g+a)<.1&&Math.abs(s+m)<.1&&Math.abs(h+p)<.1&&Math.abs(c+u+d-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const E=(c+1)/2,v=(u+1)/2,w=(d+1)/2,y=(g+a)/4,b=(s+m)/4,_=(h+p)/4;return E>v&&E>w?E<.01?(n=0,r=.707106781,A=.707106781):(n=Math.sqrt(E),r=y/n,A=b/n):v>w?v<.01?(n=.707106781,r=0,A=.707106781):(r=Math.sqrt(v),n=y/r,A=_/r):w<.01?(n=.707106781,r=.707106781,A=0):(A=Math.sqrt(w),n=b/A,r=_/A),this.set(n,r,A,t),this}let R=Math.sqrt((p-h)*(p-h)+(s-m)*(s-m)+(a-g)*(a-g));return Math.abs(R)<.001&&(R=1),this.x=(p-h)/R,this.y=(s-m)/R,this.z=(a-g)/R,this.w=Math.acos((c+u+d-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Qe(this.x,e.x,t.x),this.y=Qe(this.y,e.y,t.y),this.z=Qe(this.z,e.z,t.z),this.w=Qe(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Qe(this.x,e,t),this.y=Qe(this.y,e,t),this.z=Qe(this.z,e,t),this.w=Qe(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Qe(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Uf extends Pi{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:vt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new lt(0,0,e,t),this.scissorTest=!1,this.viewport=new lt(0,0,e,t),this.textures=[];const r={width:e,height:t,depth:n.depth},A=new wt(r),o=n.count;for(let l=0;l<o;l++)this.textures[l]=A.clone(),this.textures[l].isRenderTargetTexture=!0,this.textures[l].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:vt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,A=this.textures.length;r<A;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new Ma(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class nn extends Uf{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class fc extends wt{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=ht,this.minFilter=ht,this.wrapR=mn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Pf extends wt{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=ht,this.minFilter=ht,this.wrapR=mn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class dt{constructor(e,t,n,r,A,o,l,f,c,g,s,a,u,h,m,p){dt.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,A,o,l,f,c,g,s,a,u,h,m,p)}set(e,t,n,r,A,o,l,f,c,g,s,a,u,h,m,p){const d=this.elements;return d[0]=e,d[4]=t,d[8]=n,d[12]=r,d[1]=A,d[5]=o,d[9]=l,d[13]=f,d[2]=c,d[6]=g,d[10]=s,d[14]=a,d[3]=u,d[7]=h,d[11]=m,d[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new dt().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinant()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinant()===0)return this.identity();const t=this.elements,n=e.elements,r=1/oi.setFromMatrixColumn(e,0).length(),A=1/oi.setFromMatrixColumn(e,1).length(),o=1/oi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*A,t[5]=n[5]*A,t[6]=n[6]*A,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,A=e.z,o=Math.cos(n),l=Math.sin(n),f=Math.cos(r),c=Math.sin(r),g=Math.cos(A),s=Math.sin(A);if(e.order==="XYZ"){const a=o*g,u=o*s,h=l*g,m=l*s;t[0]=f*g,t[4]=-f*s,t[8]=c,t[1]=u+h*c,t[5]=a-m*c,t[9]=-l*f,t[2]=m-a*c,t[6]=h+u*c,t[10]=o*f}else if(e.order==="YXZ"){const a=f*g,u=f*s,h=c*g,m=c*s;t[0]=a+m*l,t[4]=h*l-u,t[8]=o*c,t[1]=o*s,t[5]=o*g,t[9]=-l,t[2]=u*l-h,t[6]=m+a*l,t[10]=o*f}else if(e.order==="ZXY"){const a=f*g,u=f*s,h=c*g,m=c*s;t[0]=a-m*l,t[4]=-o*s,t[8]=h+u*l,t[1]=u+h*l,t[5]=o*g,t[9]=m-a*l,t[2]=-o*c,t[6]=l,t[10]=o*f}else if(e.order==="ZYX"){const a=o*g,u=o*s,h=l*g,m=l*s;t[0]=f*g,t[4]=h*c-u,t[8]=a*c+m,t[1]=f*s,t[5]=m*c+a,t[9]=u*c-h,t[2]=-c,t[6]=l*f,t[10]=o*f}else if(e.order==="YZX"){const a=o*f,u=o*c,h=l*f,m=l*c;t[0]=f*g,t[4]=m-a*s,t[8]=h*s+u,t[1]=s,t[5]=o*g,t[9]=-l*g,t[2]=-c*g,t[6]=u*s+h,t[10]=a-m*s}else if(e.order==="XZY"){const a=o*f,u=o*c,h=l*f,m=l*c;t[0]=f*g,t[4]=-s,t[8]=c*g,t[1]=a*s+m,t[5]=o*g,t[9]=u*s-h,t[2]=h*s-u,t[6]=l*g,t[10]=m*s+a}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Df,e,Of)}lookAt(e,t,n){const r=this.elements;return It.subVectors(e,t),It.lengthSq()===0&&(It.z=1),It.normalize(),yn.crossVectors(n,It),yn.lengthSq()===0&&(Math.abs(n.z)===1?It.x+=1e-4:It.z+=1e-4,It.normalize(),yn.crossVectors(n,It)),yn.normalize(),_r.crossVectors(It,yn),r[0]=yn.x,r[4]=_r.x,r[8]=It.x,r[1]=yn.y,r[5]=_r.y,r[9]=It.y,r[2]=yn.z,r[6]=_r.z,r[10]=It.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,A=this.elements,o=n[0],l=n[4],f=n[8],c=n[12],g=n[1],s=n[5],a=n[9],u=n[13],h=n[2],m=n[6],p=n[10],d=n[14],R=n[3],E=n[7],v=n[11],w=n[15],y=r[0],b=r[4],_=r[8],x=r[12],K=r[1],T=r[5],B=r[9],F=r[13],H=r[2],O=r[6],Q=r[10],D=r[14],j=r[3],J=r[7],ae=r[11],he=r[15];return A[0]=o*y+l*K+f*H+c*j,A[4]=o*b+l*T+f*O+c*J,A[8]=o*_+l*B+f*Q+c*ae,A[12]=o*x+l*F+f*D+c*he,A[1]=g*y+s*K+a*H+u*j,A[5]=g*b+s*T+a*O+u*J,A[9]=g*_+s*B+a*Q+u*ae,A[13]=g*x+s*F+a*D+u*he,A[2]=h*y+m*K+p*H+d*j,A[6]=h*b+m*T+p*O+d*J,A[10]=h*_+m*B+p*Q+d*ae,A[14]=h*x+m*F+p*D+d*he,A[3]=R*y+E*K+v*H+w*j,A[7]=R*b+E*T+v*O+w*J,A[11]=R*_+E*B+v*Q+w*ae,A[15]=R*x+E*F+v*D+w*he,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],A=e[12],o=e[1],l=e[5],f=e[9],c=e[13],g=e[2],s=e[6],a=e[10],u=e[14],h=e[3],m=e[7],p=e[11],d=e[15],R=f*u-c*a,E=l*u-c*s,v=l*a-f*s,w=o*u-c*g,y=o*a-f*g,b=o*s-l*g;return t*(m*R-p*E+d*v)-n*(h*R-p*w+d*y)+r*(h*E-m*w+d*b)-A*(h*v-m*y+p*b)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],A=e[3],o=e[4],l=e[5],f=e[6],c=e[7],g=e[8],s=e[9],a=e[10],u=e[11],h=e[12],m=e[13],p=e[14],d=e[15],R=t*l-n*o,E=t*f-r*o,v=t*c-A*o,w=n*f-r*l,y=n*c-A*l,b=r*c-A*f,_=g*m-s*h,x=g*p-a*h,K=g*d-u*h,T=s*p-a*m,B=s*d-u*m,F=a*d-u*p,H=R*F-E*B+v*T+w*K-y*x+b*_;if(H===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const O=1/H;return e[0]=(l*F-f*B+c*T)*O,e[1]=(r*B-n*F-A*T)*O,e[2]=(m*b-p*y+d*w)*O,e[3]=(a*y-s*b-u*w)*O,e[4]=(f*K-o*F-c*x)*O,e[5]=(t*F-r*K+A*x)*O,e[6]=(p*v-h*b-d*E)*O,e[7]=(g*b-a*v+u*E)*O,e[8]=(o*B-l*K+c*_)*O,e[9]=(n*K-t*B-A*_)*O,e[10]=(h*y-m*v+d*R)*O,e[11]=(s*v-g*y-u*R)*O,e[12]=(l*x-o*T-f*_)*O,e[13]=(t*T-n*x+r*_)*O,e[14]=(m*E-h*w-p*R)*O,e[15]=(g*w-s*E+a*R)*O,this}scale(e){const t=this.elements,n=e.x,r=e.y,A=e.z;return t[0]*=n,t[4]*=r,t[8]*=A,t[1]*=n,t[5]*=r,t[9]*=A,t[2]*=n,t[6]*=r,t[10]*=A,t[3]*=n,t[7]*=r,t[11]*=A,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),A=1-n,o=e.x,l=e.y,f=e.z,c=A*o,g=A*l;return this.set(c*o+n,c*l-r*f,c*f+r*l,0,c*l+r*f,g*l+n,g*f-r*o,0,c*f-r*l,g*f+r*o,A*f*f+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,A,o){return this.set(1,n,A,0,e,1,o,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,A=t._x,o=t._y,l=t._z,f=t._w,c=A+A,g=o+o,s=l+l,a=A*c,u=A*g,h=A*s,m=o*g,p=o*s,d=l*s,R=f*c,E=f*g,v=f*s,w=n.x,y=n.y,b=n.z;return r[0]=(1-(m+d))*w,r[1]=(u+v)*w,r[2]=(h-E)*w,r[3]=0,r[4]=(u-v)*y,r[5]=(1-(a+d))*y,r[6]=(p+R)*y,r[7]=0,r[8]=(h+E)*b,r[9]=(p-R)*b,r[10]=(1-(a+m))*b,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const A=this.determinant();if(A===0)return n.set(1,1,1),t.identity(),this;let o=oi.set(r[0],r[1],r[2]).length();const l=oi.set(r[4],r[5],r[6]).length(),f=oi.set(r[8],r[9],r[10]).length();A<0&&(o=-o),Ft.copy(this);const c=1/o,g=1/l,s=1/f;return Ft.elements[0]*=c,Ft.elements[1]*=c,Ft.elements[2]*=c,Ft.elements[4]*=g,Ft.elements[5]*=g,Ft.elements[6]*=g,Ft.elements[8]*=s,Ft.elements[9]*=s,Ft.elements[10]*=s,t.setFromRotationMatrix(Ft),n.x=o,n.y=l,n.z=f,this}makePerspective(e,t,n,r,A,o,l=en,f=!1){const c=this.elements,g=2*A/(t-e),s=2*A/(n-r),a=(t+e)/(t-e),u=(n+r)/(n-r);let h,m;if(f)h=A/(o-A),m=o*A/(o-A);else if(l===en)h=-(o+A)/(o-A),m=-2*o*A/(o-A);else if(l===sA)h=-o/(o-A),m=-o*A/(o-A);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+l);return c[0]=g,c[4]=0,c[8]=a,c[12]=0,c[1]=0,c[5]=s,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=h,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,A,o,l=en,f=!1){const c=this.elements,g=2/(t-e),s=2/(n-r),a=-(t+e)/(t-e),u=-(n+r)/(n-r);let h,m;if(f)h=1/(o-A),m=o/(o-A);else if(l===en)h=-2/(o-A),m=-(o+A)/(o-A);else if(l===sA)h=-1/(o-A),m=-A/(o-A);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+l);return c[0]=g,c[4]=0,c[8]=0,c[12]=a,c[1]=0,c[5]=s,c[9]=0,c[13]=u,c[2]=0,c[6]=0,c[10]=h,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const oi=new z,Ft=new dt,Df=new z(0,0,0),Of=new z(1,1,1),yn=new z,_r=new z,It=new z,Uo=new dt,Po=new Di;class En{constructor(e=0,t=0,n=0,r=En.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,A=r[0],o=r[4],l=r[8],f=r[1],c=r[5],g=r[9],s=r[2],a=r[6],u=r[10];switch(t){case"XYZ":this._y=Math.asin(Qe(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-g,u),this._z=Math.atan2(-o,A)):(this._x=Math.atan2(a,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Qe(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(l,u),this._z=Math.atan2(f,c)):(this._y=Math.atan2(-s,A),this._z=0);break;case"ZXY":this._x=Math.asin(Qe(a,-1,1)),Math.abs(a)<.9999999?(this._y=Math.atan2(-s,u),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(f,A));break;case"ZYX":this._y=Math.asin(-Qe(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(a,u),this._z=Math.atan2(f,A)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(Qe(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-g,c),this._y=Math.atan2(-s,A)):(this._x=0,this._y=Math.atan2(l,u));break;case"XZY":this._z=Math.asin(-Qe(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(a,c),this._y=Math.atan2(l,A)):(this._x=Math.atan2(-g,u),this._y=0);break;default:ke("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Uo.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Uo,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Po.setFromEuler(this),this.setFromQuaternion(Po,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}En.DEFAULT_ORDER="XYZ";class dc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Nf=0;const Do=new z,li=new Di,cn=new dt,Cr=new z,Fi=new z,Lf=new z,Ff=new Di,Oo=new z(1,0,0),No=new z(0,1,0),Lo=new z(0,0,1),Fo={type:"added"},Bf={type:"removed"},ci={type:"childadded",child:null},DA={type:"childremoved",child:null};class Ut extends Pi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Nf++}),this.uuid=nr(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ut.DEFAULT_UP.clone();const e=new z,t=new En,n=new Di,r=new z(1,1,1);function A(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(A),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new dt},normalMatrix:{value:new De}}),this.matrix=new dt,this.matrixWorld=new dt,this.matrixAutoUpdate=Ut.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new dc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return li.setFromAxisAngle(e,t),this.quaternion.multiply(li),this}rotateOnWorldAxis(e,t){return li.setFromAxisAngle(e,t),this.quaternion.premultiply(li),this}rotateX(e){return this.rotateOnAxis(Oo,e)}rotateY(e){return this.rotateOnAxis(No,e)}rotateZ(e){return this.rotateOnAxis(Lo,e)}translateOnAxis(e,t){return Do.copy(e).applyQuaternion(this.quaternion),this.position.add(Do.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Oo,e)}translateY(e){return this.translateOnAxis(No,e)}translateZ(e){return this.translateOnAxis(Lo,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(cn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Cr.copy(e):Cr.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),Fi.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?cn.lookAt(Fi,Cr,this.up):cn.lookAt(Cr,Fi,this.up),this.quaternion.setFromRotationMatrix(cn),r&&(cn.extractRotation(r.matrixWorld),li.setFromRotationMatrix(cn),this.quaternion.premultiply(li.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(Ve("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Fo),ci.child=e,this.dispatchEvent(ci),ci.child=null):Ve("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Bf),DA.child=e,this.dispatchEvent(DA),DA.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),cn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),cn.multiply(e.parent.matrixWorld)),e.applyMatrix4(cn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Fo),ci.child=e,this.dispatchEvent(ci),ci.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let A=0,o=r.length;A<o;A++)r[A].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fi,e,Lf),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fi,Ff,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const t=e.x,n=e.y,r=e.z,A=this.matrix.elements;A[12]+=t-A[0]*t-A[4]*n-A[8]*r,A[13]+=n-A[1]*t-A[5]*n-A[9]*r,A[14]+=r-A[2]*t-A[6]*n-A[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let A=0,o=r.length;A<o;A++)r[A].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(l=>({...l,boundingBox:l.boundingBox?l.boundingBox.toJSON():void 0,boundingSphere:l.boundingSphere?l.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(l=>({...l})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function A(l,f){return l[f.uuid]===void 0&&(l[f.uuid]=f.toJSON(e)),f.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=A(e.geometries,this.geometry);const l=this.geometry.parameters;if(l!==void 0&&l.shapes!==void 0){const f=l.shapes;if(Array.isArray(f))for(let c=0,g=f.length;c<g;c++){const s=f[c];A(e.shapes,s)}else A(e.shapes,f)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(A(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const l=[];for(let f=0,c=this.material.length;f<c;f++)l.push(A(e.materials,this.material[f]));r.material=l}else r.material=A(e.materials,this.material);if(this.children.length>0){r.children=[];for(let l=0;l<this.children.length;l++)r.children.push(this.children[l].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let l=0;l<this.animations.length;l++){const f=this.animations[l];r.animations.push(A(e.animations,f))}}if(t){const l=o(e.geometries),f=o(e.materials),c=o(e.textures),g=o(e.images),s=o(e.shapes),a=o(e.skeletons),u=o(e.animations),h=o(e.nodes);l.length>0&&(n.geometries=l),f.length>0&&(n.materials=f),c.length>0&&(n.textures=c),g.length>0&&(n.images=g),s.length>0&&(n.shapes=s),a.length>0&&(n.skeletons=a),u.length>0&&(n.animations=u),h.length>0&&(n.nodes=h)}return n.object=r,n;function o(l){const f=[];for(const c in l){const g=l[c];delete g.metadata,f.push(g)}return f}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),e.pivot!==null&&(this.pivot=e.pivot.clone()),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}}Ut.DEFAULT_UP=new z(0,1,0);Ut.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class xr extends Ut{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Qf={type:"move"};class OA{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new xr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new xr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new z,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new z),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new xr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new z,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new z),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,A=null,o=null;const l=this._targetRay,f=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(const m of e.hand.values()){const p=t.getJointPose(m,n),d=this._getHandJoint(c,m);p!==null&&(d.matrix.fromArray(p.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=p.radius),d.visible=p!==null}const g=c.joints["index-finger-tip"],s=c.joints["thumb-tip"],a=g.position.distanceTo(s.position),u=.02,h=.005;c.inputState.pinching&&a>u+h?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&a<=u-h&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else f!==null&&e.gripSpace&&(A=t.getPose(e.gripSpace,n),A!==null&&(f.matrix.fromArray(A.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,A.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(A.linearVelocity)):f.hasLinearVelocity=!1,A.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(A.angularVelocity)):f.hasAngularVelocity=!1));l!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&A!==null&&(r=A),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,this.dispatchEvent(Qf)))}return l!==null&&(l.visible=r!==null),f!==null&&(f.visible=A!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new xr;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const hc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Tn={h:0,s:0,l:0},Er={h:0,s:0,l:0};function NA(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class $e{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Dt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ge.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Ge.workingColorSpace){return this.r=e,this.g=t,this.b=n,Ge.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Ge.workingColorSpace){if(e=yf(e,1),t=Qe(t,0,1),n=Qe(n,0,1),t===0)this.r=this.g=this.b=n;else{const A=n<=.5?n*(1+t):n+t-n*t,o=2*n-A;this.r=NA(o,A,e+1/3),this.g=NA(o,A,e),this.b=NA(o,A,e-1/3)}return Ge.colorSpaceToWorking(this,r),this}setStyle(e,t=Dt){function n(A){A!==void 0&&parseFloat(A)<1&&ke("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let A;const o=r[1],l=r[2];switch(o){case"rgb":case"rgba":if(A=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(A[4]),this.setRGB(Math.min(255,parseInt(A[1],10))/255,Math.min(255,parseInt(A[2],10))/255,Math.min(255,parseInt(A[3],10))/255,t);if(A=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(A[4]),this.setRGB(Math.min(100,parseInt(A[1],10))/100,Math.min(100,parseInt(A[2],10))/100,Math.min(100,parseInt(A[3],10))/100,t);break;case"hsl":case"hsla":if(A=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(l))return n(A[4]),this.setHSL(parseFloat(A[1])/360,parseFloat(A[2])/100,parseFloat(A[3])/100,t);break;default:ke("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const A=r[1],o=A.length;if(o===3)return this.setRGB(parseInt(A.charAt(0),16)/15,parseInt(A.charAt(1),16)/15,parseInt(A.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(A,16),t);ke("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Dt){const n=hc[e.toLowerCase()];return n!==void 0?this.setHex(n,t):ke("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Rn(e.r),this.g=Rn(e.g),this.b=Rn(e.b),this}copyLinearToSRGB(e){return this.r=wi(e.r),this.g=wi(e.g),this.b=wi(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Dt){return Ge.workingToColorSpace(Et.copy(this),e),Math.round(Qe(Et.r*255,0,255))*65536+Math.round(Qe(Et.g*255,0,255))*256+Math.round(Qe(Et.b*255,0,255))}getHexString(e=Dt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Ge.workingColorSpace){Ge.workingToColorSpace(Et.copy(this),t);const n=Et.r,r=Et.g,A=Et.b,o=Math.max(n,r,A),l=Math.min(n,r,A);let f,c;const g=(l+o)/2;if(l===o)f=0,c=0;else{const s=o-l;switch(c=g<=.5?s/(o+l):s/(2-o-l),o){case n:f=(r-A)/s+(r<A?6:0);break;case r:f=(A-n)/s+2;break;case A:f=(n-r)/s+4;break}f/=6}return e.h=f,e.s=c,e.l=g,e}getRGB(e,t=Ge.workingColorSpace){return Ge.workingToColorSpace(Et.copy(this),t),e.r=Et.r,e.g=Et.g,e.b=Et.b,e}getStyle(e=Dt){Ge.workingToColorSpace(Et.copy(this),e);const t=Et.r,n=Et.g,r=Et.b;return e!==Dt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(Tn),this.setHSL(Tn.h+e,Tn.s+t,Tn.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Tn),e.getHSL(Er);const n=bA(Tn.h,Er.h,t),r=bA(Tn.s,Er.s,t),A=bA(Tn.l,Er.l,t);return this.setHSL(n,r,A),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,A=e.elements;return this.r=A[0]*t+A[3]*n+A[6]*r,this.g=A[1]*t+A[4]*n+A[7]*r,this.b=A[2]*t+A[5]*n+A[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Et=new $e;$e.NAMES=hc;class zf extends Ut{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new En,this.environmentIntensity=1,this.environmentRotation=new En,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}const Bt=new z,un=new z,LA=new z,fn=new z,ui=new z,fi=new z,Bo=new z,FA=new z,BA=new z,QA=new z,zA=new lt,GA=new lt,HA=new lt;class Vt{constructor(e=new z,t=new z,n=new z){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Bt.subVectors(e,t),r.cross(Bt);const A=r.lengthSq();return A>0?r.multiplyScalar(1/Math.sqrt(A)):r.set(0,0,0)}static getBarycoord(e,t,n,r,A){Bt.subVectors(r,t),un.subVectors(n,t),LA.subVectors(e,t);const o=Bt.dot(Bt),l=Bt.dot(un),f=Bt.dot(LA),c=un.dot(un),g=un.dot(LA),s=o*c-l*l;if(s===0)return A.set(0,0,0),null;const a=1/s,u=(c*f-l*g)*a,h=(o*g-l*f)*a;return A.set(1-u-h,h,u)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,fn)===null?!1:fn.x>=0&&fn.y>=0&&fn.x+fn.y<=1}static getInterpolation(e,t,n,r,A,o,l,f){return this.getBarycoord(e,t,n,r,fn)===null?(f.x=0,f.y=0,"z"in f&&(f.z=0),"w"in f&&(f.w=0),null):(f.setScalar(0),f.addScaledVector(A,fn.x),f.addScaledVector(o,fn.y),f.addScaledVector(l,fn.z),f)}static getInterpolatedAttribute(e,t,n,r,A,o){return zA.setScalar(0),GA.setScalar(0),HA.setScalar(0),zA.fromBufferAttribute(e,t),GA.fromBufferAttribute(e,n),HA.fromBufferAttribute(e,r),o.setScalar(0),o.addScaledVector(zA,A.x),o.addScaledVector(GA,A.y),o.addScaledVector(HA,A.z),o}static isFrontFacing(e,t,n,r){return Bt.subVectors(n,t),un.subVectors(e,t),Bt.cross(un).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Bt.subVectors(this.c,this.b),un.subVectors(this.a,this.b),Bt.cross(un).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Vt.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Vt.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,A){return Vt.getInterpolation(e,this.a,this.b,this.c,t,n,r,A)}containsPoint(e){return Vt.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Vt.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,A=this.c;let o,l;ui.subVectors(r,n),fi.subVectors(A,n),FA.subVectors(e,n);const f=ui.dot(FA),c=fi.dot(FA);if(f<=0&&c<=0)return t.copy(n);BA.subVectors(e,r);const g=ui.dot(BA),s=fi.dot(BA);if(g>=0&&s<=g)return t.copy(r);const a=f*s-g*c;if(a<=0&&f>=0&&g<=0)return o=f/(f-g),t.copy(n).addScaledVector(ui,o);QA.subVectors(e,A);const u=ui.dot(QA),h=fi.dot(QA);if(h>=0&&u<=h)return t.copy(A);const m=u*c-f*h;if(m<=0&&c>=0&&h<=0)return l=c/(c-h),t.copy(n).addScaledVector(fi,l);const p=g*h-u*s;if(p<=0&&s-g>=0&&u-h>=0)return Bo.subVectors(A,r),l=(s-g)/(s-g+(u-h)),t.copy(r).addScaledVector(Bo,l);const d=1/(p+m+a);return o=m*d,l=a*d,t.copy(n).addScaledVector(ui,o).addScaledVector(fi,l)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class ir{constructor(e=new z(1/0,1/0,1/0),t=new z(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Qt.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Qt.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Qt.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const A=n.getAttribute("position");if(t===!0&&A!==void 0&&e.isInstancedMesh!==!0)for(let o=0,l=A.count;o<l;o++)e.isMesh===!0?e.getVertexPosition(o,Qt):Qt.fromBufferAttribute(A,o),Qt.applyMatrix4(e.matrixWorld),this.expandByPoint(Qt);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),vr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),vr.copy(n.boundingBox)),vr.applyMatrix4(e.matrixWorld),this.union(vr)}const r=e.children;for(let A=0,o=r.length;A<o;A++)this.expandByObject(r[A],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Qt),Qt.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Bi),Sr.subVectors(this.max,Bi),di.subVectors(e.a,Bi),hi.subVectors(e.b,Bi),pi.subVectors(e.c,Bi),bn.subVectors(hi,di),In.subVectors(pi,hi),Qn.subVectors(di,pi);let t=[0,-bn.z,bn.y,0,-In.z,In.y,0,-Qn.z,Qn.y,bn.z,0,-bn.x,In.z,0,-In.x,Qn.z,0,-Qn.x,-bn.y,bn.x,0,-In.y,In.x,0,-Qn.y,Qn.x,0];return!VA(t,di,hi,pi,Sr)||(t=[1,0,0,0,1,0,0,0,1],!VA(t,di,hi,pi,Sr))?!1:(wr.crossVectors(bn,In),t=[wr.x,wr.y,wr.z],VA(t,di,hi,pi,Sr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Qt).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Qt).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(dn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),dn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),dn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),dn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),dn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),dn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),dn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),dn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(dn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const dn=[new z,new z,new z,new z,new z,new z,new z,new z],Qt=new z,vr=new ir,di=new z,hi=new z,pi=new z,bn=new z,In=new z,Qn=new z,Bi=new z,Sr=new z,wr=new z,zn=new z;function VA(i,e,t,n,r){for(let A=0,o=i.length-3;A<=o;A+=3){zn.fromArray(i,A);const l=r.x*Math.abs(zn.x)+r.y*Math.abs(zn.y)+r.z*Math.abs(zn.z),f=e.dot(zn),c=t.dot(zn),g=n.dot(zn);if(Math.max(-Math.max(f,c,g),Math.min(f,c,g))>l)return!1}return!0}const ut=new z,yr=new Ye;let Gf=0;class rn{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Gf++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=So,this.updateRanges=[],this.gpuType=Wt,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,A=this.itemSize;r<A;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)yr.fromBufferAttribute(this,t),yr.applyMatrix3(e),this.setXY(t,yr.x,yr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)ut.fromBufferAttribute(this,t),ut.applyMatrix3(e),this.setXYZ(t,ut.x,ut.y,ut.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)ut.fromBufferAttribute(this,t),ut.applyMatrix4(e),this.setXYZ(t,ut.x,ut.y,ut.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)ut.fromBufferAttribute(this,t),ut.applyNormalMatrix(e),this.setXYZ(t,ut.x,ut.y,ut.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)ut.fromBufferAttribute(this,t),ut.transformDirection(e),this.setXYZ(t,ut.x,ut.y,ut.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Li(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=yt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Li(t,this.array)),t}setX(e,t){return this.normalized&&(t=yt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Li(t,this.array)),t}setY(e,t){return this.normalized&&(t=yt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Li(t,this.array)),t}setZ(e,t){return this.normalized&&(t=yt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Li(t,this.array)),t}setW(e,t){return this.normalized&&(t=yt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=yt(t,this.array),n=yt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=yt(t,this.array),n=yt(n,this.array),r=yt(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,A){return e*=this.itemSize,this.normalized&&(t=yt(t,this.array),n=yt(n,this.array),r=yt(r,this.array),A=yt(A,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=A,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==So&&(e.usage=this.usage),e}}class pc extends rn{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class gc extends rn{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class _n extends rn{constructor(e,t,n){super(new Float32Array(e),t,n)}}const Hf=new ir,Qi=new z,WA=new z;class Ra{constructor(e=new z,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Hf.setFromPoints(e).getCenter(n);let r=0;for(let A=0,o=e.length;A<o;A++)r=Math.max(r,n.distanceToSquared(e[A]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Qi.subVectors(e,this.center);const t=Qi.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(Qi,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(WA.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Qi.copy(e.center).add(WA)),this.expandByPoint(Qi.copy(e.center).sub(WA))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let Vf=0;const Pt=new dt,KA=new Ut,gi=new z,kt=new ir,zi=new ir,Rt=new z;class vn extends Pi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Vf++}),this.uuid=nr(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Ef(e)?gc:pc)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const A=new De().getNormalMatrix(e);n.applyNormalMatrix(A),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Pt.makeRotationFromQuaternion(e),this.applyMatrix4(Pt),this}rotateX(e){return Pt.makeRotationX(e),this.applyMatrix4(Pt),this}rotateY(e){return Pt.makeRotationY(e),this.applyMatrix4(Pt),this}rotateZ(e){return Pt.makeRotationZ(e),this.applyMatrix4(Pt),this}translate(e,t,n){return Pt.makeTranslation(e,t,n),this.applyMatrix4(Pt),this}scale(e,t,n){return Pt.makeScale(e,t,n),this.applyMatrix4(Pt),this}lookAt(e){return KA.lookAt(e),KA.updateMatrix(),this.applyMatrix4(KA.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(gi).negate(),this.translate(gi.x,gi.y,gi.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,A=e.length;r<A;r++){const o=e[r];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new _n(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const A=e[r];t.setXYZ(r,A.x,A.y,A.z||0)}e.length>t.count&&ke("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ir);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ve("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new z(-1/0,-1/0,-1/0),new z(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const A=t[n];kt.setFromBufferAttribute(A),this.morphTargetsRelative?(Rt.addVectors(this.boundingBox.min,kt.min),this.boundingBox.expandByPoint(Rt),Rt.addVectors(this.boundingBox.max,kt.max),this.boundingBox.expandByPoint(Rt)):(this.boundingBox.expandByPoint(kt.min),this.boundingBox.expandByPoint(kt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ve('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ra);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ve("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new z,1/0);return}if(e){const n=this.boundingSphere.center;if(kt.setFromBufferAttribute(e),t)for(let A=0,o=t.length;A<o;A++){const l=t[A];zi.setFromBufferAttribute(l),this.morphTargetsRelative?(Rt.addVectors(kt.min,zi.min),kt.expandByPoint(Rt),Rt.addVectors(kt.max,zi.max),kt.expandByPoint(Rt)):(kt.expandByPoint(zi.min),kt.expandByPoint(zi.max))}kt.getCenter(n);let r=0;for(let A=0,o=e.count;A<o;A++)Rt.fromBufferAttribute(e,A),r=Math.max(r,n.distanceToSquared(Rt));if(t)for(let A=0,o=t.length;A<o;A++){const l=t[A],f=this.morphTargetsRelative;for(let c=0,g=l.count;c<g;c++)Rt.fromBufferAttribute(l,c),f&&(gi.fromBufferAttribute(e,c),Rt.add(gi)),r=Math.max(r,n.distanceToSquared(Rt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&Ve('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){Ve("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,A=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new rn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),l=[],f=[];for(let _=0;_<n.count;_++)l[_]=new z,f[_]=new z;const c=new z,g=new z,s=new z,a=new Ye,u=new Ye,h=new Ye,m=new z,p=new z;function d(_,x,K){c.fromBufferAttribute(n,_),g.fromBufferAttribute(n,x),s.fromBufferAttribute(n,K),a.fromBufferAttribute(A,_),u.fromBufferAttribute(A,x),h.fromBufferAttribute(A,K),g.sub(c),s.sub(c),u.sub(a),h.sub(a);const T=1/(u.x*h.y-h.x*u.y);isFinite(T)&&(m.copy(g).multiplyScalar(h.y).addScaledVector(s,-u.y).multiplyScalar(T),p.copy(s).multiplyScalar(u.x).addScaledVector(g,-h.x).multiplyScalar(T),l[_].add(m),l[x].add(m),l[K].add(m),f[_].add(p),f[x].add(p),f[K].add(p))}let R=this.groups;R.length===0&&(R=[{start:0,count:e.count}]);for(let _=0,x=R.length;_<x;++_){const K=R[_],T=K.start,B=K.count;for(let F=T,H=T+B;F<H;F+=3)d(e.getX(F+0),e.getX(F+1),e.getX(F+2))}const E=new z,v=new z,w=new z,y=new z;function b(_){w.fromBufferAttribute(r,_),y.copy(w);const x=l[_];E.copy(x),E.sub(w.multiplyScalar(w.dot(x))).normalize(),v.crossVectors(y,x);const T=v.dot(f[_])<0?-1:1;o.setXYZW(_,E.x,E.y,E.z,T)}for(let _=0,x=R.length;_<x;++_){const K=R[_],T=K.start,B=K.count;for(let F=T,H=T+B;F<H;F+=3)b(e.getX(F+0)),b(e.getX(F+1)),b(e.getX(F+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new rn(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let a=0,u=n.count;a<u;a++)n.setXYZ(a,0,0,0);const r=new z,A=new z,o=new z,l=new z,f=new z,c=new z,g=new z,s=new z;if(e)for(let a=0,u=e.count;a<u;a+=3){const h=e.getX(a+0),m=e.getX(a+1),p=e.getX(a+2);r.fromBufferAttribute(t,h),A.fromBufferAttribute(t,m),o.fromBufferAttribute(t,p),g.subVectors(o,A),s.subVectors(r,A),g.cross(s),l.fromBufferAttribute(n,h),f.fromBufferAttribute(n,m),c.fromBufferAttribute(n,p),l.add(g),f.add(g),c.add(g),n.setXYZ(h,l.x,l.y,l.z),n.setXYZ(m,f.x,f.y,f.z),n.setXYZ(p,c.x,c.y,c.z)}else for(let a=0,u=t.count;a<u;a+=3)r.fromBufferAttribute(t,a+0),A.fromBufferAttribute(t,a+1),o.fromBufferAttribute(t,a+2),g.subVectors(o,A),s.subVectors(r,A),g.cross(s),n.setXYZ(a+0,g.x,g.y,g.z),n.setXYZ(a+1,g.x,g.y,g.z),n.setXYZ(a+2,g.x,g.y,g.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Rt.fromBufferAttribute(e,t),Rt.normalize(),e.setXYZ(t,Rt.x,Rt.y,Rt.z)}toNonIndexed(){function e(l,f){const c=l.array,g=l.itemSize,s=l.normalized,a=new c.constructor(f.length*g);let u=0,h=0;for(let m=0,p=f.length;m<p;m++){l.isInterleavedBufferAttribute?u=f[m]*l.data.stride+l.offset:u=f[m]*g;for(let d=0;d<g;d++)a[h++]=c[u++]}return new rn(a,g,s)}if(this.index===null)return ke("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new vn,n=this.index.array,r=this.attributes;for(const l in r){const f=r[l],c=e(f,n);t.setAttribute(l,c)}const A=this.morphAttributes;for(const l in A){const f=[],c=A[l];for(let g=0,s=c.length;g<s;g++){const a=c[g],u=e(a,n);f.push(u)}t.morphAttributes[l]=f}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let l=0,f=o.length;l<f;l++){const c=o[l];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const f=this.parameters;for(const c in f)f[c]!==void 0&&(e[c]=f[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const f in n){const c=n[f];e.data.attributes[f]=c.toJSON(e.data)}const r={};let A=!1;for(const f in this.morphAttributes){const c=this.morphAttributes[f],g=[];for(let s=0,a=c.length;s<a;s++){const u=c[s];g.push(u.toJSON(e.data))}g.length>0&&(r[f]=g,A=!0)}A&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const l=this.boundingSphere;return l!==null&&(e.data.boundingSphere=l.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const c in r){const g=r[c];this.setAttribute(c,g.clone(t))}const A=e.morphAttributes;for(const c in A){const g=[],s=A[c];for(let a=0,u=s.length;a<u;a++)g.push(s[a].clone(t));this.morphAttributes[c]=g}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let c=0,g=o.length;c<g;c++){const s=o[c];this.addGroup(s.start,s.count,s.materialIndex)}const l=e.boundingBox;l!==null&&(this.boundingBox=l.clone());const f=e.boundingSphere;return f!==null&&(this.boundingSphere=f.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let Wf=0;class fA extends Pi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Wf++}),this.uuid=nr(),this.name="",this.type="Material",this.blending=Si,this.side=Ln,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=hs,this.blendDst=ps,this.blendEquation=Xn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new $e(0,0,0),this.blendAlpha=0,this.depthFunc=Ti,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=vo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=si,this.stencilZFail=si,this.stencilZPass=si,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){ke(`Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){ke(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Si&&(n.blending=this.blending),this.side!==Ln&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==hs&&(n.blendSrc=this.blendSrc),this.blendDst!==ps&&(n.blendDst=this.blendDst),this.blendEquation!==Xn&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Ti&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==vo&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==si&&(n.stencilFail=this.stencilFail),this.stencilZFail!==si&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==si&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.allowOverride===!1&&(n.allowOverride=!1),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(A){const o=[];for(const l in A){const f=A[l];delete f.metadata,o.push(f)}return o}if(t){const A=r(e.textures),o=r(e.images);A.length>0&&(n.textures=A),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let A=0;A!==r;++A)n[A]=t[A].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const hn=new z,XA=new z,Tr=new z,kn=new z,ZA=new z,br=new z,qA=new z;class Kf{constructor(e=new z,t=new z(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,hn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=hn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(hn.copy(this.origin).addScaledVector(this.direction,t),hn.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){XA.copy(e).add(t).multiplyScalar(.5),Tr.copy(t).sub(e).normalize(),kn.copy(this.origin).sub(XA);const A=e.distanceTo(t)*.5,o=-this.direction.dot(Tr),l=kn.dot(this.direction),f=-kn.dot(Tr),c=kn.lengthSq(),g=Math.abs(1-o*o);let s,a,u,h;if(g>0)if(s=o*f-l,a=o*l-f,h=A*g,s>=0)if(a>=-h)if(a<=h){const m=1/g;s*=m,a*=m,u=s*(s+o*a+2*l)+a*(o*s+a+2*f)+c}else a=A,s=Math.max(0,-(o*a+l)),u=-s*s+a*(a+2*f)+c;else a=-A,s=Math.max(0,-(o*a+l)),u=-s*s+a*(a+2*f)+c;else a<=-h?(s=Math.max(0,-(-o*A+l)),a=s>0?-A:Math.min(Math.max(-A,-f),A),u=-s*s+a*(a+2*f)+c):a<=h?(s=0,a=Math.min(Math.max(-A,-f),A),u=a*(a+2*f)+c):(s=Math.max(0,-(o*A+l)),a=s>0?A:Math.min(Math.max(-A,-f),A),u=-s*s+a*(a+2*f)+c);else a=o>0?-A:A,s=Math.max(0,-(o*a+l)),u=-s*s+a*(a+2*f)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,s),r&&r.copy(XA).addScaledVector(Tr,a),u}intersectSphere(e,t){hn.subVectors(e.center,this.origin);const n=hn.dot(this.direction),r=hn.dot(hn)-n*n,A=e.radius*e.radius;if(r>A)return null;const o=Math.sqrt(A-r),l=n-o,f=n+o;return f<0?null:l<0?this.at(f,t):this.at(l,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,A,o,l,f;const c=1/this.direction.x,g=1/this.direction.y,s=1/this.direction.z,a=this.origin;return c>=0?(n=(e.min.x-a.x)*c,r=(e.max.x-a.x)*c):(n=(e.max.x-a.x)*c,r=(e.min.x-a.x)*c),g>=0?(A=(e.min.y-a.y)*g,o=(e.max.y-a.y)*g):(A=(e.max.y-a.y)*g,o=(e.min.y-a.y)*g),n>o||A>r||((A>n||isNaN(n))&&(n=A),(o<r||isNaN(r))&&(r=o),s>=0?(l=(e.min.z-a.z)*s,f=(e.max.z-a.z)*s):(l=(e.max.z-a.z)*s,f=(e.min.z-a.z)*s),n>f||l>r)||((l>n||n!==n)&&(n=l),(f<r||r!==r)&&(r=f),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,hn)!==null}intersectTriangle(e,t,n,r,A){ZA.subVectors(t,e),br.subVectors(n,e),qA.crossVectors(ZA,br);let o=this.direction.dot(qA),l;if(o>0){if(r)return null;l=1}else if(o<0)l=-1,o=-o;else return null;kn.subVectors(this.origin,e);const f=l*this.direction.dot(br.crossVectors(kn,br));if(f<0)return null;const c=l*this.direction.dot(ZA.cross(kn));if(c<0||f+c>o)return null;const g=-l*kn.dot(qA);return g<0?null:this.at(g/o,A)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class mc extends fA{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new $e(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new En,this.combine=ql,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Qo=new dt,Gn=new Kf,Ir=new Ra,zo=new z,kr=new z,Ur=new z,Pr=new z,YA=new z,Dr=new z,Go=new z,Or=new z;class an extends Ut{constructor(e=new vn,t=new mc){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let A=0,o=r.length;A<o;A++){const l=r[A].name||String(A);this.morphTargetInfluences.push(0),this.morphTargetDictionary[l]=A}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,A=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const l=this.morphTargetInfluences;if(A&&l){Dr.set(0,0,0);for(let f=0,c=A.length;f<c;f++){const g=l[f],s=A[f];g!==0&&(YA.fromBufferAttribute(s,e),o?Dr.addScaledVector(YA,g):Dr.addScaledVector(YA.sub(t),g))}t.add(Dr)}return t}raycast(e,t){const n=this.geometry,r=this.material,A=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Ir.copy(n.boundingSphere),Ir.applyMatrix4(A),Gn.copy(e.ray).recast(e.near),!(Ir.containsPoint(Gn.origin)===!1&&(Gn.intersectSphere(Ir,zo)===null||Gn.origin.distanceToSquared(zo)>(e.far-e.near)**2))&&(Qo.copy(A).invert(),Gn.copy(e.ray).applyMatrix4(Qo),!(n.boundingBox!==null&&Gn.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Gn)))}_computeIntersections(e,t,n){let r;const A=this.geometry,o=this.material,l=A.index,f=A.attributes.position,c=A.attributes.uv,g=A.attributes.uv1,s=A.attributes.normal,a=A.groups,u=A.drawRange;if(l!==null)if(Array.isArray(o))for(let h=0,m=a.length;h<m;h++){const p=a[h],d=o[p.materialIndex],R=Math.max(p.start,u.start),E=Math.min(l.count,Math.min(p.start+p.count,u.start+u.count));for(let v=R,w=E;v<w;v+=3){const y=l.getX(v),b=l.getX(v+1),_=l.getX(v+2);r=Nr(this,d,e,n,c,g,s,y,b,_),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const h=Math.max(0,u.start),m=Math.min(l.count,u.start+u.count);for(let p=h,d=m;p<d;p+=3){const R=l.getX(p),E=l.getX(p+1),v=l.getX(p+2);r=Nr(this,o,e,n,c,g,s,R,E,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}else if(f!==void 0)if(Array.isArray(o))for(let h=0,m=a.length;h<m;h++){const p=a[h],d=o[p.materialIndex],R=Math.max(p.start,u.start),E=Math.min(f.count,Math.min(p.start+p.count,u.start+u.count));for(let v=R,w=E;v<w;v+=3){const y=v,b=v+1,_=v+2;r=Nr(this,d,e,n,c,g,s,y,b,_),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const h=Math.max(0,u.start),m=Math.min(f.count,u.start+u.count);for(let p=h,d=m;p<d;p+=3){const R=p,E=p+1,v=p+2;r=Nr(this,o,e,n,c,g,s,R,E,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}}}function Xf(i,e,t,n,r,A,o,l){let f;if(e.side===Tt?f=n.intersectTriangle(o,A,r,!0,l):f=n.intersectTriangle(r,A,o,e.side===Ln,l),f===null)return null;Or.copy(l),Or.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(Or);return c<t.near||c>t.far?null:{distance:c,point:Or.clone(),object:i}}function Nr(i,e,t,n,r,A,o,l,f,c){i.getVertexPosition(l,kr),i.getVertexPosition(f,Ur),i.getVertexPosition(c,Pr);const g=Xf(i,e,t,n,kr,Ur,Pr,Go);if(g){const s=new z;Vt.getBarycoord(Go,kr,Ur,Pr,s),r&&(g.uv=Vt.getInterpolatedAttribute(r,l,f,c,s,new Ye)),A&&(g.uv1=Vt.getInterpolatedAttribute(A,l,f,c,s,new Ye)),o&&(g.normal=Vt.getInterpolatedAttribute(o,l,f,c,s,new z),g.normal.dot(n.direction)>0&&g.normal.multiplyScalar(-1));const a={a:l,b:f,c,normal:new z,materialIndex:0};Vt.getNormal(kr,Ur,Pr,a.normal),g.face=a,g.barycoord=s}return g}class Mc extends wt{constructor(e=null,t=1,n=1,r,A,o,l,f,c=ht,g=ht,s,a){super(null,o,l,f,c,g,r,A,s,a),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const JA=new z,Zf=new z,qf=new De;class Kn{constructor(e=new z(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=JA.subVectors(n,t).cross(Zf.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(JA),r=this.normal.dot(n);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const A=-(e.start.dot(this.normal)+this.constant)/r;return A<0||A>1?null:t.copy(e.start).addScaledVector(n,A)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||qf.getNormalMatrix(e),r=this.coplanarPoint(JA).applyMatrix4(e),A=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(A),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Hn=new Ra,Yf=new Ye(.5,.5),Lr=new z;class Rc{constructor(e=new Kn,t=new Kn,n=new Kn,r=new Kn,A=new Kn,o=new Kn){this.planes=[e,t,n,r,A,o]}set(e,t,n,r,A,o){const l=this.planes;return l[0].copy(e),l[1].copy(t),l[2].copy(n),l[3].copy(r),l[4].copy(A),l[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=en,n=!1){const r=this.planes,A=e.elements,o=A[0],l=A[1],f=A[2],c=A[3],g=A[4],s=A[5],a=A[6],u=A[7],h=A[8],m=A[9],p=A[10],d=A[11],R=A[12],E=A[13],v=A[14],w=A[15];if(r[0].setComponents(c-o,u-g,d-h,w-R).normalize(),r[1].setComponents(c+o,u+g,d+h,w+R).normalize(),r[2].setComponents(c+l,u+s,d+m,w+E).normalize(),r[3].setComponents(c-l,u-s,d-m,w-E).normalize(),n)r[4].setComponents(f,a,p,v).normalize(),r[5].setComponents(c-f,u-a,d-p,w-v).normalize();else if(r[4].setComponents(c-f,u-a,d-p,w-v).normalize(),t===en)r[5].setComponents(c+f,u+a,d+p,w+v).normalize();else if(t===sA)r[5].setComponents(f,a,p,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Hn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Hn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Hn)}intersectsSprite(e){Hn.center.set(0,0,0);const t=Yf.distanceTo(e.center);return Hn.radius=.7071067811865476+t,Hn.applyMatrix4(e.matrixWorld),this.intersectsSphere(Hn)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let A=0;A<6;A++)if(t[A].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Lr.x=r.normal.x>0?e.max.x:e.min.x,Lr.y=r.normal.y>0?e.max.y:e.min.y,Lr.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Lr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class _c extends wt{constructor(e=[],t=ti,n,r,A,o,l,f,c,g){super(e,t,n,r,A,o,l,f,c,g),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class er extends wt{constructor(e,t,n=sn,r,A,o,l=ht,f=ht,c,g=xn,s=1){if(g!==xn&&g!==Yn)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const a={width:e,height:t,depth:s};super(a,r,A,o,l,f,g,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Ma(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Jf extends er{constructor(e,t=sn,n=ti,r,A,o=ht,l=ht,f,c=xn){const g={width:e,height:e,depth:1},s=[g,g,g,g,g,g];super(e,e,t,n,r,A,o,l,f,c),this.image=s,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class Cc extends wt{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class rr extends vn{constructor(e=1,t=1,n=1,r=1,A=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:A,depthSegments:o};const l=this;r=Math.floor(r),A=Math.floor(A),o=Math.floor(o);const f=[],c=[],g=[],s=[];let a=0,u=0;h("z","y","x",-1,-1,n,t,e,o,A,0),h("z","y","x",1,-1,n,t,-e,o,A,1),h("x","z","y",1,1,e,n,t,r,o,2),h("x","z","y",1,-1,e,n,-t,r,o,3),h("x","y","z",1,-1,e,t,n,r,A,4),h("x","y","z",-1,-1,e,t,-n,r,A,5),this.setIndex(f),this.setAttribute("position",new _n(c,3)),this.setAttribute("normal",new _n(g,3)),this.setAttribute("uv",new _n(s,2));function h(m,p,d,R,E,v,w,y,b,_,x){const K=v/b,T=w/_,B=v/2,F=w/2,H=y/2,O=b+1,Q=_+1;let D=0,j=0;const J=new z;for(let ae=0;ae<Q;ae++){const he=ae*T-F;for(let ue=0;ue<O;ue++){const Oe=ue*K-B;J[m]=Oe*R,J[p]=he*E,J[d]=H,c.push(J.x,J.y,J.z),J[m]=0,J[p]=0,J[d]=y>0?1:-1,g.push(J.x,J.y,J.z),s.push(ue/b),s.push(1-ae/_),D+=1}}for(let ae=0;ae<_;ae++)for(let he=0;he<b;he++){const ue=a+he+O*ae,Oe=a+he+O*(ae+1),At=a+(he+1)+O*(ae+1),rt=a+(he+1)+O*ae;f.push(ue,Oe,rt),f.push(Oe,At,rt),j+=6}l.addGroup(u,j,x),u+=j,a+=D}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new rr(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Ar extends vn{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const A=e/2,o=t/2,l=Math.floor(n),f=Math.floor(r),c=l+1,g=f+1,s=e/l,a=t/f,u=[],h=[],m=[],p=[];for(let d=0;d<g;d++){const R=d*a-o;for(let E=0;E<c;E++){const v=E*s-A;h.push(v,-R,0),m.push(0,0,1),p.push(E/l),p.push(1-d/f)}}for(let d=0;d<f;d++)for(let R=0;R<l;R++){const E=R+c*d,v=R+c*(d+1),w=R+1+c*(d+1),y=R+1+c*d;u.push(E,v,y),u.push(v,w,y)}this.setIndex(u),this.setAttribute("position",new _n(h,3)),this.setAttribute("normal",new _n(m,3)),this.setAttribute("uv",new _n(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ar(e.width,e.height,e.widthSegments,e.heightSegments)}}function Ui(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(ke("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone():Array.isArray(r)?e[t][n]=r.slice():e[t][n]=r}}return e}function St(i){const e={};for(let t=0;t<i.length;t++){const n=Ui(i[t]);for(const r in n)e[r]=n[r]}return e}function jf(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function xc(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Ge.workingColorSpace}const $f={clone:Ui,merge:St};var ed=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,td=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Kt extends fA{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=ed,this.fragmentShader=td,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ui(e.uniforms),this.uniformsGroups=jf(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const o=this.uniforms[r].value;o&&o.isTexture?t.uniforms[r]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[r]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[r]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[r]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[r]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[r]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[r]={type:"m4",value:o.toArray()}:t.uniforms[r]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class nd extends Kt{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class id extends fA{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=hf,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class rd extends fA{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Fr=new z,Br=new Di,Zt=new z;class _a extends Ut{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new dt,this.projectionMatrix=new dt,this.projectionMatrixInverse=new dt,this.coordinateSystem=en,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Fr,Br,Zt),Zt.x===1&&Zt.y===1&&Zt.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Fr,Br,Zt.set(1,1,1)).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorld.decompose(Fr,Br,Zt),Zt.x===1&&Zt.y===1&&Zt.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Fr,Br,Zt.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Un=new z,Ho=new Ye,Vo=new Ye;class Ht extends _a{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=ia*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(TA*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ia*2*Math.atan(Math.tan(TA*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Un.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Un.x,Un.y).multiplyScalar(-e/Un.z),Un.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Un.x,Un.y).multiplyScalar(-e/Un.z)}getViewSize(e,t){return this.getViewBounds(e,Ho,Vo),t.subVectors(Vo,Ho)}setViewOffset(e,t,n,r,A,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=A,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(TA*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,A=-.5*r;const o=this.view;if(this.view!==null&&this.view.enabled){const f=o.fullWidth,c=o.fullHeight;A+=o.offsetX*r/f,t-=o.offsetY*n/c,r*=o.width/f,n*=o.height/c}const l=this.filmOffset;l!==0&&(A+=e*l/this.getFilmWidth()),this.projectionMatrix.makePerspective(A,A+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}class Ec extends _a{constructor(e=-1,t=1,n=1,r=-1,A=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=A,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,A,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=A,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let A=n-e,o=n+e,l=r+t,f=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,g=(this.top-this.bottom)/this.view.fullHeight/this.zoom;A+=c*this.view.offsetX,o=A+c*this.view.width,l-=g*this.view.offsetY,f=l-g*this.view.height}this.projectionMatrix.makeOrthographic(A,o,l,f,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const mi=-90,Mi=1;class Ad extends Ut{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Ht(mi,Mi,e,t);r.layers=this.layers,this.add(r);const A=new Ht(mi,Mi,e,t);A.layers=this.layers,this.add(A);const o=new Ht(mi,Mi,e,t);o.layers=this.layers,this.add(o);const l=new Ht(mi,Mi,e,t);l.layers=this.layers,this.add(l);const f=new Ht(mi,Mi,e,t);f.layers=this.layers,this.add(f);const c=new Ht(mi,Mi,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,A,o,l,f]=t;for(const c of t)this.remove(c);if(e===en)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),A.up.set(0,0,-1),A.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),l.up.set(0,1,0),l.lookAt(0,0,1),f.up.set(0,1,0),f.lookAt(0,0,-1);else if(e===sA)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),A.up.set(0,0,1),A.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),l.up.set(0,-1,0),l.lookAt(0,0,1),f.up.set(0,-1,0),f.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[A,o,l,f,c,g]=this.children,s=e.getRenderTarget(),a=e.getActiveCubeFace(),u=e.getActiveMipmapLevel(),h=e.xr.enabled;e.xr.enabled=!1;const m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let p=!1;e.isWebGLRenderer===!0?p=e.state.buffers.depth.getReversed():p=e.reversedDepthBuffer,e.setRenderTarget(n,0,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,A),e.setRenderTarget(n,1,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,2,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,3,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,f),e.setRenderTarget(n,4,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),p&&e.autoClear===!1&&e.clearDepth(),e.render(t,g),e.setRenderTarget(s,a,u),e.xr.enabled=h,n.texture.needsPMREMUpdate=!0}}class sd extends Ht{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}function Wo(i,e,t,n){const r=ad(n);switch(t){case oc:return i*e;case cc:return i*e/r.components*r.byteLength;case da:return i*e/r.components*r.byteLength;case Ii:return i*e*2/r.components*r.byteLength;case ha:return i*e*2/r.components*r.byteLength;case lc:return i*e*3/r.components*r.byteLength;case Nt:return i*e*4/r.components*r.byteLength;case pa:return i*e*4/r.components*r.byteLength;case Xr:case Zr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case qr:case Yr:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case ws:case Ts:return Math.max(i,16)*Math.max(e,8)/4;case Ss:case ys:return Math.max(i,8)*Math.max(e,8)/2;case bs:case Is:case Us:case Ps:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ks:case Ds:case Os:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ns:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ls:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Fs:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Bs:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Qs:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case zs:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Gs:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Hs:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Vs:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Ws:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Ks:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Xs:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Zs:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case qs:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Ys:case Js:case js:return Math.ceil(i/4)*Math.ceil(e/4)*16;case $s:case ea:return Math.ceil(i/4)*Math.ceil(e/4)*8;case ta:case na:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function ad(i){switch(i){case Ot:case rc:return{byteLength:1,components:1};case ji:case Ac:case Cn:return{byteLength:2,components:1};case ua:case fa:return{byteLength:2,components:4};case sn:case ca:case Wt:return{byteLength:4,components:1};case sc:case ac:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:la}}));typeof window<"u"&&(window.__THREE__?ke("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=la);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function vc(){let i=null,e=!1,t=null,n=null;function r(A,o){t(A,o),n=i.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(A){t=A},setContext:function(A){i=A}}}function od(i){const e=new WeakMap;function t(l,f){const c=l.array,g=l.usage,s=c.byteLength,a=i.createBuffer();i.bindBuffer(f,a),i.bufferData(f,c,g),l.onUploadCallback();let u;if(c instanceof Float32Array)u=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)u=i.HALF_FLOAT;else if(c instanceof Uint16Array)l.isFloat16BufferAttribute?u=i.HALF_FLOAT:u=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)u=i.SHORT;else if(c instanceof Uint32Array)u=i.UNSIGNED_INT;else if(c instanceof Int32Array)u=i.INT;else if(c instanceof Int8Array)u=i.BYTE;else if(c instanceof Uint8Array)u=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)u=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:a,type:u,bytesPerElement:c.BYTES_PER_ELEMENT,version:l.version,size:s}}function n(l,f,c){const g=f.array,s=f.updateRanges;if(i.bindBuffer(c,l),s.length===0)i.bufferSubData(c,0,g);else{s.sort((u,h)=>u.start-h.start);let a=0;for(let u=1;u<s.length;u++){const h=s[a],m=s[u];m.start<=h.start+h.count+1?h.count=Math.max(h.count,m.start+m.count-h.start):(++a,s[a]=m)}s.length=a+1;for(let u=0,h=s.length;u<h;u++){const m=s[u];i.bufferSubData(c,m.start*g.BYTES_PER_ELEMENT,g,m.start,m.count)}f.clearUpdateRanges()}f.onUploadCallback()}function r(l){return l.isInterleavedBufferAttribute&&(l=l.data),e.get(l)}function A(l){l.isInterleavedBufferAttribute&&(l=l.data);const f=e.get(l);f&&(i.deleteBuffer(f.buffer),e.delete(l))}function o(l,f){if(l.isInterleavedBufferAttribute&&(l=l.data),l.isGLBufferAttribute){const g=e.get(l);(!g||g.version<l.version)&&e.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}const c=e.get(l);if(c===void 0)e.set(l,t(l,f));else if(c.version<l.version){if(c.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,l,f),c.version=l.version}}return{get:r,remove:A,update:o}}var ld=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,cd=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ud=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,fd=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,dd=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,hd=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,pd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,gd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,md=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Md=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Rd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,_d=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Cd=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,xd=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Ed=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,vd=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Sd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,wd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,yd=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Td=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,bd=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Id=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,kd=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Ud=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Pd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Dd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Od=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Nd=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Ld=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Fd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Bd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Qd=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,zd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Gd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Hd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Vd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Kd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Xd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Zd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,qd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Yd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Jd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,jd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,$d=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,eh=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,th=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,nh=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ih=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,rh=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Ah=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sh=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ah=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return v;
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,oh=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lh=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,ch=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,uh=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,fh=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,dh=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,hh=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,ph=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,gh=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,mh=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Mh=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Rh=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,_h=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ch=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,xh=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Eh=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,vh=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Sh=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,wh=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,yh=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Th=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,bh=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ih=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,kh=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Uh=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Ph=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Dh=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Oh=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Nh=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Lh=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,Fh=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Bh=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Qh=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,zh=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Gh=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Hh=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Vh=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,Wh=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Kh=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Xh=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Zh=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,qh=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Yh=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Jh=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,jh=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,$h=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,ep=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,np=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,ip=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,rp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Ap=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sp=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,ap=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const op=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,lp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,up=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,dp=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,pp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,gp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,mp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,Mp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Rp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,_p=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Cp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,xp=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Ep=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Sp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wp=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,yp=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tp=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,bp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Ip=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,kp=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Up=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Pp=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Dp=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Op=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Np=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Lp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Fp=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Qp=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,zp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ne={alphahash_fragment:ld,alphahash_pars_fragment:cd,alphamap_fragment:ud,alphamap_pars_fragment:fd,alphatest_fragment:dd,alphatest_pars_fragment:hd,aomap_fragment:pd,aomap_pars_fragment:gd,batching_pars_vertex:md,batching_vertex:Md,begin_vertex:Rd,beginnormal_vertex:_d,bsdfs:Cd,iridescence_fragment:xd,bumpmap_pars_fragment:Ed,clipping_planes_fragment:vd,clipping_planes_pars_fragment:Sd,clipping_planes_pars_vertex:wd,clipping_planes_vertex:yd,color_fragment:Td,color_pars_fragment:bd,color_pars_vertex:Id,color_vertex:kd,common:Ud,cube_uv_reflection_fragment:Pd,defaultnormal_vertex:Dd,displacementmap_pars_vertex:Od,displacementmap_vertex:Nd,emissivemap_fragment:Ld,emissivemap_pars_fragment:Fd,colorspace_fragment:Bd,colorspace_pars_fragment:Qd,envmap_fragment:zd,envmap_common_pars_fragment:Gd,envmap_pars_fragment:Hd,envmap_pars_vertex:Vd,envmap_physical_pars_fragment:th,envmap_vertex:Wd,fog_vertex:Kd,fog_pars_vertex:Xd,fog_fragment:Zd,fog_pars_fragment:qd,gradientmap_pars_fragment:Yd,lightmap_pars_fragment:Jd,lights_lambert_fragment:jd,lights_lambert_pars_fragment:$d,lights_pars_begin:eh,lights_toon_fragment:nh,lights_toon_pars_fragment:ih,lights_phong_fragment:rh,lights_phong_pars_fragment:Ah,lights_physical_fragment:sh,lights_physical_pars_fragment:ah,lights_fragment_begin:oh,lights_fragment_maps:lh,lights_fragment_end:ch,logdepthbuf_fragment:uh,logdepthbuf_pars_fragment:fh,logdepthbuf_pars_vertex:dh,logdepthbuf_vertex:hh,map_fragment:ph,map_pars_fragment:gh,map_particle_fragment:mh,map_particle_pars_fragment:Mh,metalnessmap_fragment:Rh,metalnessmap_pars_fragment:_h,morphinstance_vertex:Ch,morphcolor_vertex:xh,morphnormal_vertex:Eh,morphtarget_pars_vertex:vh,morphtarget_vertex:Sh,normal_fragment_begin:wh,normal_fragment_maps:yh,normal_pars_fragment:Th,normal_pars_vertex:bh,normal_vertex:Ih,normalmap_pars_fragment:kh,clearcoat_normal_fragment_begin:Uh,clearcoat_normal_fragment_maps:Ph,clearcoat_pars_fragment:Dh,iridescence_pars_fragment:Oh,opaque_fragment:Nh,packing:Lh,premultiplied_alpha_fragment:Fh,project_vertex:Bh,dithering_fragment:Qh,dithering_pars_fragment:zh,roughnessmap_fragment:Gh,roughnessmap_pars_fragment:Hh,shadowmap_pars_fragment:Vh,shadowmap_pars_vertex:Wh,shadowmap_vertex:Kh,shadowmask_pars_fragment:Xh,skinbase_vertex:Zh,skinning_pars_vertex:qh,skinning_vertex:Yh,skinnormal_vertex:Jh,specularmap_fragment:jh,specularmap_pars_fragment:$h,tonemapping_fragment:ep,tonemapping_pars_fragment:tp,transmission_fragment:np,transmission_pars_fragment:ip,uv_pars_fragment:rp,uv_pars_vertex:Ap,uv_vertex:sp,worldpos_vertex:ap,background_vert:op,background_frag:lp,backgroundCube_vert:cp,backgroundCube_frag:up,cube_vert:fp,cube_frag:dp,depth_vert:hp,depth_frag:pp,distance_vert:gp,distance_frag:mp,equirect_vert:Mp,equirect_frag:Rp,linedashed_vert:_p,linedashed_frag:Cp,meshbasic_vert:xp,meshbasic_frag:Ep,meshlambert_vert:vp,meshlambert_frag:Sp,meshmatcap_vert:wp,meshmatcap_frag:yp,meshnormal_vert:Tp,meshnormal_frag:bp,meshphong_vert:Ip,meshphong_frag:kp,meshphysical_vert:Up,meshphysical_frag:Pp,meshtoon_vert:Dp,meshtoon_frag:Op,points_vert:Np,points_frag:Lp,shadow_vert:Fp,shadow_frag:Bp,sprite_vert:Qp,sprite_frag:zp},oe={common:{diffuse:{value:new $e(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new De}},envmap:{envMap:{value:null},envMapRotation:{value:new De},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new De}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new De}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new De},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new De},normalScale:{value:new Ye(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new De},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new De}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new De}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new De}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new $e(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new $e(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0},uvTransform:{value:new De}},sprite:{diffuse:{value:new $e(16777215)},opacity:{value:1},center:{value:new Ye(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}}},Jt={basic:{uniforms:St([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.fog]),vertexShader:Ne.meshbasic_vert,fragmentShader:Ne.meshbasic_frag},lambert:{uniforms:St([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,oe.lights,{emissive:{value:new $e(0)},envMapIntensity:{value:1}}]),vertexShader:Ne.meshlambert_vert,fragmentShader:Ne.meshlambert_frag},phong:{uniforms:St([oe.common,oe.specularmap,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,oe.lights,{emissive:{value:new $e(0)},specular:{value:new $e(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Ne.meshphong_vert,fragmentShader:Ne.meshphong_frag},standard:{uniforms:St([oe.common,oe.envmap,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.roughnessmap,oe.metalnessmap,oe.fog,oe.lights,{emissive:{value:new $e(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ne.meshphysical_vert,fragmentShader:Ne.meshphysical_frag},toon:{uniforms:St([oe.common,oe.aomap,oe.lightmap,oe.emissivemap,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.gradientmap,oe.fog,oe.lights,{emissive:{value:new $e(0)}}]),vertexShader:Ne.meshtoon_vert,fragmentShader:Ne.meshtoon_frag},matcap:{uniforms:St([oe.common,oe.bumpmap,oe.normalmap,oe.displacementmap,oe.fog,{matcap:{value:null}}]),vertexShader:Ne.meshmatcap_vert,fragmentShader:Ne.meshmatcap_frag},points:{uniforms:St([oe.points,oe.fog]),vertexShader:Ne.points_vert,fragmentShader:Ne.points_frag},dashed:{uniforms:St([oe.common,oe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ne.linedashed_vert,fragmentShader:Ne.linedashed_frag},depth:{uniforms:St([oe.common,oe.displacementmap]),vertexShader:Ne.depth_vert,fragmentShader:Ne.depth_frag},normal:{uniforms:St([oe.common,oe.bumpmap,oe.normalmap,oe.displacementmap,{opacity:{value:1}}]),vertexShader:Ne.meshnormal_vert,fragmentShader:Ne.meshnormal_frag},sprite:{uniforms:St([oe.sprite,oe.fog]),vertexShader:Ne.sprite_vert,fragmentShader:Ne.sprite_frag},background:{uniforms:{uvTransform:{value:new De},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ne.background_vert,fragmentShader:Ne.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new De}},vertexShader:Ne.backgroundCube_vert,fragmentShader:Ne.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ne.cube_vert,fragmentShader:Ne.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ne.equirect_vert,fragmentShader:Ne.equirect_frag},distance:{uniforms:St([oe.common,oe.displacementmap,{referencePosition:{value:new z},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ne.distance_vert,fragmentShader:Ne.distance_frag},shadow:{uniforms:St([oe.lights,oe.fog,{color:{value:new $e(0)},opacity:{value:1}}]),vertexShader:Ne.shadow_vert,fragmentShader:Ne.shadow_frag}};Jt.physical={uniforms:St([Jt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new De},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new De},clearcoatNormalScale:{value:new Ye(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new De},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new De},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new De},sheen:{value:0},sheenColor:{value:new $e(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new De},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new De},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new De},transmissionSamplerSize:{value:new Ye},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new De},attenuationDistance:{value:0},attenuationColor:{value:new $e(0)},specularColor:{value:new $e(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new De},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new De},anisotropyVector:{value:new Ye},anisotropyMap:{value:null},anisotropyMapTransform:{value:new De}}]),vertexShader:Ne.meshphysical_vert,fragmentShader:Ne.meshphysical_frag};const Qr={r:0,b:0,g:0},Vn=new En,Gp=new dt;function Hp(i,e,t,n,r,A){const o=new $e(0);let l=r===!0?0:1,f,c,g=null,s=0,a=null;function u(R){let E=R.isScene===!0?R.background:null;if(E&&E.isTexture){const v=R.backgroundBlurriness>0;E=e.get(E,v)}return E}function h(R){let E=!1;const v=u(R);v===null?p(o,l):v&&v.isColor&&(p(v,1),E=!0);const w=i.xr.getEnvironmentBlendMode();w==="additive"?t.buffers.color.setClear(0,0,0,1,A):w==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,A),(i.autoClear||E)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(R,E){const v=u(E);v&&(v.isCubeTexture||v.mapping===uA)?(c===void 0&&(c=new an(new rr(1,1,1),new Kt({name:"BackgroundCubeMaterial",uniforms:Ui(Jt.backgroundCube.uniforms),vertexShader:Jt.backgroundCube.vertexShader,fragmentShader:Jt.backgroundCube.fragmentShader,side:Tt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(w,y,b){this.matrixWorld.copyPosition(b.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),Vn.copy(E.backgroundRotation),Vn.x*=-1,Vn.y*=-1,Vn.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(Vn.y*=-1,Vn.z*=-1),c.material.uniforms.envMap.value=v,c.material.uniforms.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,c.material.uniforms.backgroundBlurriness.value=E.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(Gp.makeRotationFromEuler(Vn)),c.material.toneMapped=Ge.getTransfer(v.colorSpace)!==Ze,(g!==v||s!==v.version||a!==i.toneMapping)&&(c.material.needsUpdate=!0,g=v,s=v.version,a=i.toneMapping),c.layers.enableAll(),R.unshift(c,c.geometry,c.material,0,0,null)):v&&v.isTexture&&(f===void 0&&(f=new an(new Ar(2,2),new Kt({name:"BackgroundMaterial",uniforms:Ui(Jt.background.uniforms),vertexShader:Jt.background.vertexShader,fragmentShader:Jt.background.fragmentShader,side:Ln,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),f.geometry.deleteAttribute("normal"),Object.defineProperty(f.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(f)),f.material.uniforms.t2D.value=v,f.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,f.material.toneMapped=Ge.getTransfer(v.colorSpace)!==Ze,v.matrixAutoUpdate===!0&&v.updateMatrix(),f.material.uniforms.uvTransform.value.copy(v.matrix),(g!==v||s!==v.version||a!==i.toneMapping)&&(f.material.needsUpdate=!0,g=v,s=v.version,a=i.toneMapping),f.layers.enableAll(),R.unshift(f,f.geometry,f.material,0,0,null))}function p(R,E){R.getRGB(Qr,xc(i)),t.buffers.color.setClear(Qr.r,Qr.g,Qr.b,E,A)}function d(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),f!==void 0&&(f.geometry.dispose(),f.material.dispose(),f=void 0)}return{getClearColor:function(){return o},setClearColor:function(R,E=1){o.set(R),l=E,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(R){l=R,p(o,l)},render:h,addToRenderList:m,dispose:d}}function Vp(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=a(null);let A=r,o=!1;function l(T,B,F,H,O){let Q=!1;const D=s(T,H,F,B);A!==D&&(A=D,c(A.object)),Q=u(T,H,F,O),Q&&h(T,H,F,O),O!==null&&e.update(O,i.ELEMENT_ARRAY_BUFFER),(Q||o)&&(o=!1,v(T,B,F,H),O!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(O).buffer))}function f(){return i.createVertexArray()}function c(T){return i.bindVertexArray(T)}function g(T){return i.deleteVertexArray(T)}function s(T,B,F,H){const O=H.wireframe===!0;let Q=n[B.id];Q===void 0&&(Q={},n[B.id]=Q);const D=T.isInstancedMesh===!0?T.id:0;let j=Q[D];j===void 0&&(j={},Q[D]=j);let J=j[F.id];J===void 0&&(J={},j[F.id]=J);let ae=J[O];return ae===void 0&&(ae=a(f()),J[O]=ae),ae}function a(T){const B=[],F=[],H=[];for(let O=0;O<t;O++)B[O]=0,F[O]=0,H[O]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:B,enabledAttributes:F,attributeDivisors:H,object:T,attributes:{},index:null}}function u(T,B,F,H){const O=A.attributes,Q=B.attributes;let D=0;const j=F.getAttributes();for(const J in j)if(j[J].location>=0){const he=O[J];let ue=Q[J];if(ue===void 0&&(J==="instanceMatrix"&&T.instanceMatrix&&(ue=T.instanceMatrix),J==="instanceColor"&&T.instanceColor&&(ue=T.instanceColor)),he===void 0||he.attribute!==ue||ue&&he.data!==ue.data)return!0;D++}return A.attributesNum!==D||A.index!==H}function h(T,B,F,H){const O={},Q=B.attributes;let D=0;const j=F.getAttributes();for(const J in j)if(j[J].location>=0){let he=Q[J];he===void 0&&(J==="instanceMatrix"&&T.instanceMatrix&&(he=T.instanceMatrix),J==="instanceColor"&&T.instanceColor&&(he=T.instanceColor));const ue={};ue.attribute=he,he&&he.data&&(ue.data=he.data),O[J]=ue,D++}A.attributes=O,A.attributesNum=D,A.index=H}function m(){const T=A.newAttributes;for(let B=0,F=T.length;B<F;B++)T[B]=0}function p(T){d(T,0)}function d(T,B){const F=A.newAttributes,H=A.enabledAttributes,O=A.attributeDivisors;F[T]=1,H[T]===0&&(i.enableVertexAttribArray(T),H[T]=1),O[T]!==B&&(i.vertexAttribDivisor(T,B),O[T]=B)}function R(){const T=A.newAttributes,B=A.enabledAttributes;for(let F=0,H=B.length;F<H;F++)B[F]!==T[F]&&(i.disableVertexAttribArray(F),B[F]=0)}function E(T,B,F,H,O,Q,D){D===!0?i.vertexAttribIPointer(T,B,F,O,Q):i.vertexAttribPointer(T,B,F,H,O,Q)}function v(T,B,F,H){m();const O=H.attributes,Q=F.getAttributes(),D=B.defaultAttributeValues;for(const j in Q){const J=Q[j];if(J.location>=0){let ae=O[j];if(ae===void 0&&(j==="instanceMatrix"&&T.instanceMatrix&&(ae=T.instanceMatrix),j==="instanceColor"&&T.instanceColor&&(ae=T.instanceColor)),ae!==void 0){const he=ae.normalized,ue=ae.itemSize,Oe=e.get(ae);if(Oe===void 0)continue;const At=Oe.buffer,rt=Oe.type,Z=Oe.bytesPerElement,ie=rt===i.INT||rt===i.UNSIGNED_INT||ae.gpuType===ca;if(ae.isInterleavedBufferAttribute){const se=ae.data,Pe=se.stride,ye=ae.offset;if(se.isInstancedInterleavedBuffer){for(let be=0;be<J.locationSize;be++)d(J.location+be,se.meshPerAttribute);T.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=se.meshPerAttribute*se.count)}else for(let be=0;be<J.locationSize;be++)p(J.location+be);i.bindBuffer(i.ARRAY_BUFFER,At);for(let be=0;be<J.locationSize;be++)E(J.location+be,ue/J.locationSize,rt,he,Pe*Z,(ye+ue/J.locationSize*be)*Z,ie)}else{if(ae.isInstancedBufferAttribute){for(let se=0;se<J.locationSize;se++)d(J.location+se,ae.meshPerAttribute);T.isInstancedMesh!==!0&&H._maxInstanceCount===void 0&&(H._maxInstanceCount=ae.meshPerAttribute*ae.count)}else for(let se=0;se<J.locationSize;se++)p(J.location+se);i.bindBuffer(i.ARRAY_BUFFER,At);for(let se=0;se<J.locationSize;se++)E(J.location+se,ue/J.locationSize,rt,he,ue*Z,ue/J.locationSize*se*Z,ie)}}else if(D!==void 0){const he=D[j];if(he!==void 0)switch(he.length){case 2:i.vertexAttrib2fv(J.location,he);break;case 3:i.vertexAttrib3fv(J.location,he);break;case 4:i.vertexAttrib4fv(J.location,he);break;default:i.vertexAttrib1fv(J.location,he)}}}}R()}function w(){x();for(const T in n){const B=n[T];for(const F in B){const H=B[F];for(const O in H){const Q=H[O];for(const D in Q)g(Q[D].object),delete Q[D];delete H[O]}}delete n[T]}}function y(T){if(n[T.id]===void 0)return;const B=n[T.id];for(const F in B){const H=B[F];for(const O in H){const Q=H[O];for(const D in Q)g(Q[D].object),delete Q[D];delete H[O]}}delete n[T.id]}function b(T){for(const B in n){const F=n[B];for(const H in F){const O=F[H];if(O[T.id]===void 0)continue;const Q=O[T.id];for(const D in Q)g(Q[D].object),delete Q[D];delete O[T.id]}}}function _(T){for(const B in n){const F=n[B],H=T.isInstancedMesh===!0?T.id:0,O=F[H];if(O!==void 0){for(const Q in O){const D=O[Q];for(const j in D)g(D[j].object),delete D[j];delete O[Q]}delete F[H],Object.keys(F).length===0&&delete n[B]}}}function x(){K(),o=!0,A!==r&&(A=r,c(A.object))}function K(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:l,reset:x,resetDefaultState:K,dispose:w,releaseStatesOfGeometry:y,releaseStatesOfObject:_,releaseStatesOfProgram:b,initAttributes:m,enableAttribute:p,disableUnusedAttributes:R}}function Wp(i,e,t){let n;function r(c){n=c}function A(c,g){i.drawArrays(n,c,g),t.update(g,n,1)}function o(c,g,s){s!==0&&(i.drawArraysInstanced(n,c,g,s),t.update(g,n,s))}function l(c,g,s){if(s===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,g,0,s);let u=0;for(let h=0;h<s;h++)u+=g[h];t.update(u,n,1)}function f(c,g,s,a){if(s===0)return;const u=e.get("WEBGL_multi_draw");if(u===null)for(let h=0;h<c.length;h++)o(c[h],g[h],a[h]);else{u.multiDrawArraysInstancedWEBGL(n,c,0,g,0,a,0,s);let h=0;for(let m=0;m<s;m++)h+=g[m]*a[m];t.update(h,n,1)}}this.setMode=r,this.render=A,this.renderInstances=o,this.renderMultiDraw=l,this.renderMultiDrawInstances=f}function Kp(i,e,t,n){let r;function A(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const b=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(b.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function o(b){return!(b!==Nt&&n.convert(b)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function l(b){const _=b===Cn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(b!==Ot&&n.convert(b)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&b!==Wt&&!_)}function f(b){if(b==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";b="mediump"}return b==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const g=f(c);g!==c&&(ke("WebGLRenderer:",c,"not supported, using",g,"instead."),c=g);const s=t.logarithmicDepthBuffer===!0,a=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),u=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),h=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_TEXTURE_SIZE),p=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),d=i.getParameter(i.MAX_VERTEX_ATTRIBS),R=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),E=i.getParameter(i.MAX_VARYING_VECTORS),v=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=i.getParameter(i.MAX_SAMPLES),y=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:A,getMaxPrecision:f,textureFormatReadable:o,textureTypeReadable:l,precision:c,logarithmicDepthBuffer:s,reversedDepthBuffer:a,maxTextures:u,maxVertexTextures:h,maxTextureSize:m,maxCubemapSize:p,maxAttributes:d,maxVertexUniforms:R,maxVaryings:E,maxFragmentUniforms:v,maxSamples:w,samples:y}}function Xp(i){const e=this;let t=null,n=0,r=!1,A=!1;const o=new Kn,l=new De,f={value:null,needsUpdate:!1};this.uniform=f,this.numPlanes=0,this.numIntersection=0,this.init=function(s,a){const u=s.length!==0||a||n!==0||r;return r=a,n=s.length,u},this.beginShadows=function(){A=!0,g(null)},this.endShadows=function(){A=!1},this.setGlobalState=function(s,a){t=g(s,a,0)},this.setState=function(s,a,u){const h=s.clippingPlanes,m=s.clipIntersection,p=s.clipShadows,d=i.get(s);if(!r||h===null||h.length===0||A&&!p)A?g(null):c();else{const R=A?0:n,E=R*4;let v=d.clippingState||null;f.value=v,v=g(h,a,E,u);for(let w=0;w!==E;++w)v[w]=t[w];d.clippingState=v,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=R}};function c(){f.value!==t&&(f.value=t,f.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function g(s,a,u,h){const m=s!==null?s.length:0;let p=null;if(m!==0){if(p=f.value,h!==!0||p===null){const d=u+m*4,R=a.matrixWorldInverse;l.getNormalMatrix(R),(p===null||p.length<d)&&(p=new Float32Array(d));for(let E=0,v=u;E!==m;++E,v+=4)o.copy(s[E]).applyMatrix4(R,l),o.normal.toArray(p,v),p[v+3]=o.constant}f.value=p,f.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,p}}const Nn=4,Ko=[.125,.215,.35,.446,.526,.582],Zn=20,Zp=256,Gi=new Ec,Xo=new $e;let jA=null,$A=0,es=0,ts=!1;const qp=new z;class Zo{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,A={}){const{size:o=256,position:l=qp}=A;jA=this._renderer.getRenderTarget(),$A=this._renderer.getActiveCubeFace(),es=this._renderer.getActiveMipmapLevel(),ts=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const f=this._allocateTargets();return f.depthBuffer=!0,this._sceneToCubeUV(e,n,r,f,l),t>0&&this._blur(f,0,0,t),this._applyPMREM(f),this._cleanup(f),f}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Jo(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Yo(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(jA,$A,es),this._renderer.xr.enabled=ts,e.scissorTest=!1,Ri(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ti||e.mapping===bi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),jA=this._renderer.getRenderTarget(),$A=this._renderer.getActiveCubeFace(),es=this._renderer.getActiveMipmapLevel(),ts=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:vt,minFilter:vt,generateMipmaps:!1,type:Cn,format:Nt,colorSpace:ki,depthBuffer:!1},r=qo(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=qo(e,t,n);const{_lodMax:A}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Yp(A)),this._blurMaterial=jp(A,e,t),this._ggxMaterial=Jp(A,e,t)}return r}_compileMaterial(e){const t=new an(new vn,e);this._renderer.compile(t,Gi)}_sceneToCubeUV(e,t,n,r,A){const f=new Ht(90,1,t,n),c=[1,-1,1,1,1,1],g=[1,1,1,-1,-1,-1],s=this._renderer,a=s.autoClear,u=s.toneMapping;s.getClearColor(Xo),s.toneMapping=tn,s.autoClear=!1,s.state.buffers.depth.getReversed()&&(s.setRenderTarget(r),s.clearDepth(),s.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new an(new rr,new mc({name:"PMREM.Background",side:Tt,depthWrite:!1,depthTest:!1})));const m=this._backgroundBox,p=m.material;let d=!1;const R=e.background;R?R.isColor&&(p.color.copy(R),e.background=null,d=!0):(p.color.copy(Xo),d=!0);for(let E=0;E<6;E++){const v=E%3;v===0?(f.up.set(0,c[E],0),f.position.set(A.x,A.y,A.z),f.lookAt(A.x+g[E],A.y,A.z)):v===1?(f.up.set(0,0,c[E]),f.position.set(A.x,A.y,A.z),f.lookAt(A.x,A.y+g[E],A.z)):(f.up.set(0,c[E],0),f.position.set(A.x,A.y,A.z),f.lookAt(A.x,A.y,A.z+g[E]));const w=this._cubeSize;Ri(r,v*w,E>2?w:0,w,w),s.setRenderTarget(r),d&&s.render(m,f),s.render(e,f)}s.toneMapping=u,s.autoClear=a,e.background=R}_textureToCubeUV(e,t){const n=this._renderer,r=e.mapping===ti||e.mapping===bi;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Jo()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Yo());const A=r?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=A;const l=A.uniforms;l.envMap.value=e;const f=this._cubeSize;Ri(t,0,0,3*f,2*f),n.setRenderTarget(t),n.render(o,Gi)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const r=this._lodMeshes.length;for(let A=1;A<r;A++)this._applyGGXFilter(e,A-1,A);t.autoClear=n}_applyGGXFilter(e,t,n){const r=this._renderer,A=this._pingPongRenderTarget,o=this._ggxMaterial,l=this._lodMeshes[n];l.material=o;const f=o.uniforms,c=n/(this._lodMeshes.length-1),g=t/(this._lodMeshes.length-1),s=Math.sqrt(c*c-g*g),a=0+c*1.25,u=s*a,{_lodMax:h}=this,m=this._sizeLods[n],p=3*m*(n>h-Nn?n-h+Nn:0),d=4*(this._cubeSize-m);f.envMap.value=e.texture,f.roughness.value=u,f.mipInt.value=h-t,Ri(A,p,d,3*m,2*m),r.setRenderTarget(A),r.render(l,Gi),f.envMap.value=A.texture,f.roughness.value=0,f.mipInt.value=h-n,Ri(e,p,d,3*m,2*m),r.setRenderTarget(e),r.render(l,Gi)}_blur(e,t,n,r,A){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,r,"latitudinal",A),this._halfBlur(o,e,n,n,r,"longitudinal",A)}_halfBlur(e,t,n,r,A,o,l){const f=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&Ve("blur direction must be either latitudinal or longitudinal!");const g=3,s=this._lodMeshes[r];s.material=c;const a=c.uniforms,u=this._sizeLods[n]-1,h=isFinite(A)?Math.PI/(2*u):2*Math.PI/(2*Zn-1),m=A/h,p=isFinite(A)?1+Math.floor(g*m):Zn;p>Zn&&ke(`sigmaRadians, ${A}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${Zn}`);const d=[];let R=0;for(let b=0;b<Zn;++b){const _=b/m,x=Math.exp(-_*_/2);d.push(x),b===0?R+=x:b<p&&(R+=2*x)}for(let b=0;b<d.length;b++)d[b]=d[b]/R;a.envMap.value=e.texture,a.samples.value=p,a.weights.value=d,a.latitudinal.value=o==="latitudinal",l&&(a.poleAxis.value=l);const{_lodMax:E}=this;a.dTheta.value=h,a.mipInt.value=E-n;const v=this._sizeLods[r],w=3*v*(r>E-Nn?r-E+Nn:0),y=4*(this._cubeSize-v);Ri(t,w,y,3*v,2*v),f.setRenderTarget(t),f.render(s,Gi)}}function Yp(i){const e=[],t=[],n=[];let r=i;const A=i-Nn+1+Ko.length;for(let o=0;o<A;o++){const l=Math.pow(2,r);e.push(l);let f=1/l;o>i-Nn?f=Ko[o-i+Nn-1]:o===0&&(f=0),t.push(f);const c=1/(l-2),g=-c,s=1+c,a=[g,g,s,g,s,s,g,g,s,s,g,s],u=6,h=6,m=3,p=2,d=1,R=new Float32Array(m*h*u),E=new Float32Array(p*h*u),v=new Float32Array(d*h*u);for(let y=0;y<u;y++){const b=y%3*2/3-1,_=y>2?0:-1,x=[b,_,0,b+2/3,_,0,b+2/3,_+1,0,b,_,0,b+2/3,_+1,0,b,_+1,0];R.set(x,m*h*y),E.set(a,p*h*y);const K=[y,y,y,y,y,y];v.set(K,d*h*y)}const w=new vn;w.setAttribute("position",new rn(R,m)),w.setAttribute("uv",new rn(E,p)),w.setAttribute("faceIndex",new rn(v,d)),n.push(new an(w,null)),r>Nn&&r--}return{lodMeshes:n,sizeLods:e,sigmas:t}}function qo(i,e,t){const n=new nn(i,e,t);return n.texture.mapping=uA,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Ri(i,e,t,n,r){i.viewport.set(e,t,n,r),i.scissor.set(e,t,n,r)}function Jp(i,e,t){return new Kt({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Zp,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:dA(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function jp(i,e,t){const n=new Float32Array(Zn),r=new z(0,1,0);return new Kt({name:"SphericalGaussianBlur",defines:{n:Zn,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:dA(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function Yo(){return new Kt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:dA(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function Jo(){return new Kt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:dA(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function dA(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class Sc extends nn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new _c(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new rr(5,5,5),A=new Kt({name:"CubemapFromEquirect",uniforms:Ui(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Tt,blending:Mn});A.uniforms.tEquirect.value=t;const o=new an(r,A),l=t.minFilter;return t.minFilter===qn&&(t.minFilter=vt),new Ad(1,10,this).update(e,o),t.minFilter=l,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const A=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,r);e.setRenderTarget(A)}}function $p(i){let e=new WeakMap,t=new WeakMap,n=null;function r(a,u=!1){return a==null?null:u?o(a):A(a)}function A(a){if(a&&a.isTexture){const u=a.mapping;if(u===SA||u===wA)if(e.has(a)){const h=e.get(a).texture;return l(h,a.mapping)}else{const h=a.image;if(h&&h.height>0){const m=new Sc(h.height);return m.fromEquirectangularTexture(i,a),e.set(a,m),a.addEventListener("dispose",c),l(m.texture,a.mapping)}else return null}}return a}function o(a){if(a&&a.isTexture){const u=a.mapping,h=u===SA||u===wA,m=u===ti||u===bi;if(h||m){let p=t.get(a);const d=p!==void 0?p.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return n===null&&(n=new Zo(i)),p=h?n.fromEquirectangular(a,p):n.fromCubemap(a,p),p.texture.pmremVersion=a.pmremVersion,t.set(a,p),p.texture;if(p!==void 0)return p.texture;{const R=a.image;return h&&R&&R.height>0||m&&R&&f(R)?(n===null&&(n=new Zo(i)),p=h?n.fromEquirectangular(a):n.fromCubemap(a),p.texture.pmremVersion=a.pmremVersion,t.set(a,p),a.addEventListener("dispose",g),p.texture):null}}}return a}function l(a,u){return u===SA?a.mapping=ti:u===wA&&(a.mapping=bi),a}function f(a){let u=0;const h=6;for(let m=0;m<h;m++)a[m]!==void 0&&u++;return u===h}function c(a){const u=a.target;u.removeEventListener("dispose",c);const h=e.get(u);h!==void 0&&(e.delete(u),h.dispose())}function g(a){const u=a.target;u.removeEventListener("dispose",g);const h=t.get(u);h!==void 0&&(t.delete(u),h.dispose())}function s(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:r,dispose:s}}function eg(i){const e={};function t(n){if(e[n]!==void 0)return e[n];const r=i.getExtension(n);return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&oA("WebGLRenderer: "+n+" extension not supported."),r}}}function tg(i,e,t,n){const r={},A=new WeakMap;function o(s){const a=s.target;a.index!==null&&e.remove(a.index);for(const h in a.attributes)e.remove(a.attributes[h]);a.removeEventListener("dispose",o),delete r[a.id];const u=A.get(a);u&&(e.remove(u),A.delete(a)),n.releaseStatesOfGeometry(a),a.isInstancedBufferGeometry===!0&&delete a._maxInstanceCount,t.memory.geometries--}function l(s,a){return r[a.id]===!0||(a.addEventListener("dispose",o),r[a.id]=!0,t.memory.geometries++),a}function f(s){const a=s.attributes;for(const u in a)e.update(a[u],i.ARRAY_BUFFER)}function c(s){const a=[],u=s.index,h=s.attributes.position;let m=0;if(h===void 0)return;if(u!==null){const R=u.array;m=u.version;for(let E=0,v=R.length;E<v;E+=3){const w=R[E+0],y=R[E+1],b=R[E+2];a.push(w,y,y,b,b,w)}}else{const R=h.array;m=h.version;for(let E=0,v=R.length/3-1;E<v;E+=3){const w=E+0,y=E+1,b=E+2;a.push(w,y,y,b,b,w)}}const p=new(h.count>=65535?gc:pc)(a,1);p.version=m;const d=A.get(s);d&&e.remove(d),A.set(s,p)}function g(s){const a=A.get(s);if(a){const u=s.index;u!==null&&a.version<u.version&&c(s)}else c(s);return A.get(s)}return{get:l,update:f,getWireframeAttribute:g}}function ng(i,e,t){let n;function r(a){n=a}let A,o;function l(a){A=a.type,o=a.bytesPerElement}function f(a,u){i.drawElements(n,u,A,a*o),t.update(u,n,1)}function c(a,u,h){h!==0&&(i.drawElementsInstanced(n,u,A,a*o,h),t.update(u,n,h))}function g(a,u,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,u,0,A,a,0,h);let p=0;for(let d=0;d<h;d++)p+=u[d];t.update(p,n,1)}function s(a,u,h,m){if(h===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let d=0;d<a.length;d++)c(a[d]/o,u[d],m[d]);else{p.multiDrawElementsInstancedWEBGL(n,u,0,A,a,0,m,0,h);let d=0;for(let R=0;R<h;R++)d+=u[R]*m[R];t.update(d,n,1)}}this.setMode=r,this.setIndex=l,this.render=f,this.renderInstances=c,this.renderMultiDraw=g,this.renderMultiDrawInstances=s}function ig(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(A,o,l){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=l*(A/3);break;case i.LINES:t.lines+=l*(A/2);break;case i.LINE_STRIP:t.lines+=l*(A-1);break;case i.LINE_LOOP:t.lines+=l*A;break;case i.POINTS:t.points+=l*A;break;default:Ve("WebGLInfo: Unknown draw mode:",o);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function rg(i,e,t){const n=new WeakMap,r=new lt;function A(o,l,f){const c=o.morphTargetInfluences,g=l.morphAttributes.position||l.morphAttributes.normal||l.morphAttributes.color,s=g!==void 0?g.length:0;let a=n.get(l);if(a===void 0||a.count!==s){let K=function(){_.dispose(),n.delete(l),l.removeEventListener("dispose",K)};var u=K;a!==void 0&&a.texture.dispose();const h=l.morphAttributes.position!==void 0,m=l.morphAttributes.normal!==void 0,p=l.morphAttributes.color!==void 0,d=l.morphAttributes.position||[],R=l.morphAttributes.normal||[],E=l.morphAttributes.color||[];let v=0;h===!0&&(v=1),m===!0&&(v=2),p===!0&&(v=3);let w=l.attributes.position.count*v,y=1;w>e.maxTextureSize&&(y=Math.ceil(w/e.maxTextureSize),w=e.maxTextureSize);const b=new Float32Array(w*y*4*s),_=new fc(b,w,y,s);_.type=Wt,_.needsUpdate=!0;const x=v*4;for(let T=0;T<s;T++){const B=d[T],F=R[T],H=E[T],O=w*y*4*T;for(let Q=0;Q<B.count;Q++){const D=Q*x;h===!0&&(r.fromBufferAttribute(B,Q),b[O+D+0]=r.x,b[O+D+1]=r.y,b[O+D+2]=r.z,b[O+D+3]=0),m===!0&&(r.fromBufferAttribute(F,Q),b[O+D+4]=r.x,b[O+D+5]=r.y,b[O+D+6]=r.z,b[O+D+7]=0),p===!0&&(r.fromBufferAttribute(H,Q),b[O+D+8]=r.x,b[O+D+9]=r.y,b[O+D+10]=r.z,b[O+D+11]=H.itemSize===4?r.w:1)}}a={count:s,texture:_,size:new Ye(w,y)},n.set(l,a),l.addEventListener("dispose",K)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)f.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let h=0;for(let p=0;p<c.length;p++)h+=c[p];const m=l.morphTargetsRelative?1:1-h;f.getUniforms().setValue(i,"morphTargetBaseInfluence",m),f.getUniforms().setValue(i,"morphTargetInfluences",c)}f.getUniforms().setValue(i,"morphTargetsTexture",a.texture,t),f.getUniforms().setValue(i,"morphTargetsTextureSize",a.size)}return{update:A}}function Ag(i,e,t,n,r){let A=new WeakMap;function o(c){const g=r.render.frame,s=c.geometry,a=e.get(c,s);if(A.get(a)!==g&&(e.update(a),A.set(a,g)),c.isInstancedMesh&&(c.hasEventListener("dispose",f)===!1&&c.addEventListener("dispose",f),A.get(c)!==g&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),A.set(c,g))),c.isSkinnedMesh){const u=c.skeleton;A.get(u)!==g&&(u.update(),A.set(u,g))}return a}function l(){A=new WeakMap}function f(c){const g=c.target;g.removeEventListener("dispose",f),n.releaseStatesOfObject(g),t.remove(g.instanceMatrix),g.instanceColor!==null&&t.remove(g.instanceColor)}return{update:o,dispose:l}}const sg={[Yl]:"LINEAR_TONE_MAPPING",[Jl]:"REINHARD_TONE_MAPPING",[jl]:"CINEON_TONE_MAPPING",[$l]:"ACES_FILMIC_TONE_MAPPING",[tc]:"AGX_TONE_MAPPING",[nc]:"NEUTRAL_TONE_MAPPING",[ec]:"CUSTOM_TONE_MAPPING"};function ag(i,e,t,n,r){const A=new nn(e,t,{type:i,depthBuffer:n,stencilBuffer:r}),o=new nn(e,t,{type:Cn,depthBuffer:!1,stencilBuffer:!1}),l=new vn;l.setAttribute("position",new _n([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute("uv",new _n([0,2,0,0,2,0],2));const f=new nd({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),c=new an(l,f),g=new Ec(-1,1,1,-1,0,1);let s=null,a=null,u=!1,h,m=null,p=[],d=!1;this.setSize=function(R,E){A.setSize(R,E),o.setSize(R,E);for(let v=0;v<p.length;v++){const w=p[v];w.setSize&&w.setSize(R,E)}},this.setEffects=function(R){p=R,d=p.length>0&&p[0].isRenderPass===!0;const E=A.width,v=A.height;for(let w=0;w<p.length;w++){const y=p[w];y.setSize&&y.setSize(E,v)}},this.begin=function(R,E){if(u||R.toneMapping===tn&&p.length===0)return!1;if(m=E,E!==null){const v=E.width,w=E.height;(A.width!==v||A.height!==w)&&this.setSize(v,w)}return d===!1&&R.setRenderTarget(A),h=R.toneMapping,R.toneMapping=tn,!0},this.hasRenderPass=function(){return d},this.end=function(R,E){R.toneMapping=h,u=!0;let v=A,w=o;for(let y=0;y<p.length;y++){const b=p[y];if(b.enabled!==!1&&(b.render(R,w,v,E),b.needsSwap!==!1)){const _=v;v=w,w=_}}if(s!==R.outputColorSpace||a!==R.toneMapping){s=R.outputColorSpace,a=R.toneMapping,f.defines={},Ge.getTransfer(s)===Ze&&(f.defines.SRGB_TRANSFER="");const y=sg[a];y&&(f.defines[y]=""),f.needsUpdate=!0}f.uniforms.tDiffuse.value=v.texture,R.setRenderTarget(m),R.render(c,g),m=null,u=!1},this.isCompositing=function(){return u},this.dispose=function(){A.dispose(),o.dispose(),l.dispose(),f.dispose()}}const wc=new wt,ra=new er(1,1),yc=new fc,Tc=new Pf,bc=new _c,jo=[],$o=[],el=new Float32Array(16),tl=new Float32Array(9),nl=new Float32Array(4);function Oi(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let A=jo[r];if(A===void 0&&(A=new Float32Array(r),jo[r]=A),e!==0){n.toArray(A,0);for(let o=1,l=0;o!==e;++o)l+=t,i[o].toArray(A,l)}return A}function pt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function gt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function hA(i,e){let t=$o[e];t===void 0&&(t=new Int32Array(e),$o[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function og(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function lg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(pt(t,e))return;i.uniform2fv(this.addr,e),gt(t,e)}}function cg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(pt(t,e))return;i.uniform3fv(this.addr,e),gt(t,e)}}function ug(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(pt(t,e))return;i.uniform4fv(this.addr,e),gt(t,e)}}function fg(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(pt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),gt(t,e)}else{if(pt(t,n))return;nl.set(n),i.uniformMatrix2fv(this.addr,!1,nl),gt(t,n)}}function dg(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(pt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),gt(t,e)}else{if(pt(t,n))return;tl.set(n),i.uniformMatrix3fv(this.addr,!1,tl),gt(t,n)}}function hg(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(pt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),gt(t,e)}else{if(pt(t,n))return;el.set(n),i.uniformMatrix4fv(this.addr,!1,el),gt(t,n)}}function pg(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function gg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(pt(t,e))return;i.uniform2iv(this.addr,e),gt(t,e)}}function mg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(pt(t,e))return;i.uniform3iv(this.addr,e),gt(t,e)}}function Mg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(pt(t,e))return;i.uniform4iv(this.addr,e),gt(t,e)}}function Rg(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function _g(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(pt(t,e))return;i.uniform2uiv(this.addr,e),gt(t,e)}}function Cg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(pt(t,e))return;i.uniform3uiv(this.addr,e),gt(t,e)}}function xg(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(pt(t,e))return;i.uniform4uiv(this.addr,e),gt(t,e)}}function Eg(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let A;this.type===i.SAMPLER_2D_SHADOW?(ra.compareFunction=t.isReversedDepthBuffer()?ma:ga,A=ra):A=wc,t.setTexture2D(e||A,r)}function vg(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||Tc,r)}function Sg(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTextureCube(e||bc,r)}function wg(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||yc,r)}function yg(i){switch(i){case 5126:return og;case 35664:return lg;case 35665:return cg;case 35666:return ug;case 35674:return fg;case 35675:return dg;case 35676:return hg;case 5124:case 35670:return pg;case 35667:case 35671:return gg;case 35668:case 35672:return mg;case 35669:case 35673:return Mg;case 5125:return Rg;case 36294:return _g;case 36295:return Cg;case 36296:return xg;case 35678:case 36198:case 36298:case 36306:case 35682:return Eg;case 35679:case 36299:case 36307:return vg;case 35680:case 36300:case 36308:case 36293:return Sg;case 36289:case 36303:case 36311:case 36292:return wg}}function Tg(i,e){i.uniform1fv(this.addr,e)}function bg(i,e){const t=Oi(e,this.size,2);i.uniform2fv(this.addr,t)}function Ig(i,e){const t=Oi(e,this.size,3);i.uniform3fv(this.addr,t)}function kg(i,e){const t=Oi(e,this.size,4);i.uniform4fv(this.addr,t)}function Ug(i,e){const t=Oi(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Pg(i,e){const t=Oi(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function Dg(i,e){const t=Oi(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function Og(i,e){i.uniform1iv(this.addr,e)}function Ng(i,e){i.uniform2iv(this.addr,e)}function Lg(i,e){i.uniform3iv(this.addr,e)}function Fg(i,e){i.uniform4iv(this.addr,e)}function Bg(i,e){i.uniform1uiv(this.addr,e)}function Qg(i,e){i.uniform2uiv(this.addr,e)}function zg(i,e){i.uniform3uiv(this.addr,e)}function Gg(i,e){i.uniform4uiv(this.addr,e)}function Hg(i,e,t){const n=this.cache,r=e.length,A=hA(t,r);pt(n,A)||(i.uniform1iv(this.addr,A),gt(n,A));let o;this.type===i.SAMPLER_2D_SHADOW?o=ra:o=wc;for(let l=0;l!==r;++l)t.setTexture2D(e[l]||o,A[l])}function Vg(i,e,t){const n=this.cache,r=e.length,A=hA(t,r);pt(n,A)||(i.uniform1iv(this.addr,A),gt(n,A));for(let o=0;o!==r;++o)t.setTexture3D(e[o]||Tc,A[o])}function Wg(i,e,t){const n=this.cache,r=e.length,A=hA(t,r);pt(n,A)||(i.uniform1iv(this.addr,A),gt(n,A));for(let o=0;o!==r;++o)t.setTextureCube(e[o]||bc,A[o])}function Kg(i,e,t){const n=this.cache,r=e.length,A=hA(t,r);pt(n,A)||(i.uniform1iv(this.addr,A),gt(n,A));for(let o=0;o!==r;++o)t.setTexture2DArray(e[o]||yc,A[o])}function Xg(i){switch(i){case 5126:return Tg;case 35664:return bg;case 35665:return Ig;case 35666:return kg;case 35674:return Ug;case 35675:return Pg;case 35676:return Dg;case 5124:case 35670:return Og;case 35667:case 35671:return Ng;case 35668:case 35672:return Lg;case 35669:case 35673:return Fg;case 5125:return Bg;case 36294:return Qg;case 36295:return zg;case 36296:return Gg;case 35678:case 36198:case 36298:case 36306:case 35682:return Hg;case 35679:case 36299:case 36307:return Vg;case 35680:case 36300:case 36308:case 36293:return Wg;case 36289:case 36303:case 36311:case 36292:return Kg}}class Zg{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=yg(t.type)}}class qg{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Xg(t.type)}}class Yg{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let A=0,o=r.length;A!==o;++A){const l=r[A];l.setValue(e,t[l.id],n)}}}const ns=/(\w+)(\])?(\[|\.)?/g;function il(i,e){i.seq.push(e),i.map[e.id]=e}function Jg(i,e,t){const n=i.name,r=n.length;for(ns.lastIndex=0;;){const A=ns.exec(n),o=ns.lastIndex;let l=A[1];const f=A[2]==="]",c=A[3];if(f&&(l=l|0),c===void 0||c==="["&&o+2===r){il(t,c===void 0?new Zg(l,i,e):new qg(l,i,e));break}else{let s=t.map[l];s===void 0&&(s=new Yg(l),il(t,s)),t=s}}}class Jr{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let o=0;o<n;++o){const l=e.getActiveUniform(t,o),f=e.getUniformLocation(t,l.name);Jg(l,f,this)}const r=[],A=[];for(const o of this.seq)o.type===e.SAMPLER_2D_SHADOW||o.type===e.SAMPLER_CUBE_SHADOW||o.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(o):A.push(o);r.length>0&&(this.seq=r.concat(A))}setValue(e,t,n,r){const A=this.map[t];A!==void 0&&A.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let A=0,o=t.length;A!==o;++A){const l=t[A],f=n[l.id];f.needsUpdate!==!1&&l.setValue(e,f.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,A=e.length;r!==A;++r){const o=e[r];o.id in t&&n.push(o)}return n}}function rl(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const jg=37297;let $g=0;function em(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),A=Math.min(e+6,t.length);for(let o=r;o<A;o++){const l=o+1;n.push(`${l===e?">":" "} ${l}: ${t[o]}`)}return n.join(`
`)}const Al=new De;function tm(i){Ge._getMatrix(Al,Ge.workingColorSpace,i);const e=`mat3( ${Al.elements.map(t=>t.toFixed(4))} )`;switch(Ge.getTransfer(i)){case AA:return[e,"LinearTransferOETF"];case Ze:return[e,"sRGBTransferOETF"];default:return ke("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function sl(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),A=(i.getShaderInfoLog(e)||"").trim();if(n&&A==="")return"";const o=/ERROR: 0:(\d+)/.exec(A);if(o){const l=parseInt(o[1]);return t.toUpperCase()+`

`+A+`

`+em(i.getShaderSource(e),l)}else return A}function nm(i,e){const t=tm(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const im={[Yl]:"Linear",[Jl]:"Reinhard",[jl]:"Cineon",[$l]:"ACESFilmic",[tc]:"AgX",[nc]:"Neutral",[ec]:"Custom"};function rm(i,e){const t=im[e];return t===void 0?(ke("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const zr=new z;function Am(){Ge.getLuminanceCoefficients(zr);const i=zr.x.toFixed(4),e=zr.y.toFixed(4),t=zr.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function sm(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Xi).join(`
`)}function am(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function om(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const A=i.getActiveAttrib(e,r),o=A.name;let l=1;A.type===i.FLOAT_MAT2&&(l=2),A.type===i.FLOAT_MAT3&&(l=3),A.type===i.FLOAT_MAT4&&(l=4),t[o]={type:A.type,location:i.getAttribLocation(e,o),locationSize:l}}return t}function Xi(i){return i!==""}function al(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function ol(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const lm=/^[ \t]*#include +<([\w\d./]+)>/gm;function Aa(i){return i.replace(lm,um)}const cm=new Map;function um(i,e){let t=Ne[e];if(t===void 0){const n=cm.get(e);if(n!==void 0)t=Ne[n],ke('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Aa(t)}const fm=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function ll(i){return i.replace(fm,dm)}function dm(i,e,t,n){let r="";for(let A=parseInt(e);A<parseInt(t);A++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+A+" ]").replace(/UNROLLED_LOOP_INDEX/g,A);return r}function cl(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const hm={[Kr]:"SHADOWMAP_TYPE_PCF",[Ki]:"SHADOWMAP_TYPE_VSM"};function pm(i){return hm[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const gm={[ti]:"ENVMAP_TYPE_CUBE",[bi]:"ENVMAP_TYPE_CUBE",[uA]:"ENVMAP_TYPE_CUBE_UV"};function mm(i){return i.envMap===!1?"ENVMAP_TYPE_CUBE":gm[i.envMapMode]||"ENVMAP_TYPE_CUBE"}const Mm={[bi]:"ENVMAP_MODE_REFRACTION"};function Rm(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":Mm[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}const _m={[ql]:"ENVMAP_BLENDING_MULTIPLY",[uf]:"ENVMAP_BLENDING_MIX",[ff]:"ENVMAP_BLENDING_ADD"};function Cm(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":_m[i.combine]||"ENVMAP_BLENDING_NONE"}function xm(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Em(i,e,t,n){const r=i.getContext(),A=t.defines;let o=t.vertexShader,l=t.fragmentShader;const f=pm(t),c=mm(t),g=Rm(t),s=Cm(t),a=xm(t),u=sm(t),h=am(A),m=r.createProgram();let p,d,R=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h].filter(Xi).join(`
`),p.length>0&&(p+=`
`),d=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h].filter(Xi).join(`
`),d.length>0&&(d+=`
`)):(p=[cl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+g:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Xi).join(`
`),d=[cl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,h,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+g:"",t.envMap?"#define "+s:"",a?"#define CUBEUV_TEXEL_WIDTH "+a.texelWidth:"",a?"#define CUBEUV_TEXEL_HEIGHT "+a.texelHeight:"",a?"#define CUBEUV_MAX_MIP "+a.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+f:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==tn?"#define TONE_MAPPING":"",t.toneMapping!==tn?Ne.tonemapping_pars_fragment:"",t.toneMapping!==tn?rm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ne.colorspace_pars_fragment,nm("linearToOutputTexel",t.outputColorSpace),Am(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Xi).join(`
`)),o=Aa(o),o=al(o,t),o=ol(o,t),l=Aa(l),l=al(l,t),l=ol(l,t),o=ll(o),l=ll(l),t.isRawShaderMaterial!==!0&&(R=`#version 300 es
`,p=[u,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,d=["#define varying in",t.glslVersion===wo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===wo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+d);const E=R+p+o,v=R+d+l,w=rl(r,r.VERTEX_SHADER,E),y=rl(r,r.FRAGMENT_SHADER,v);r.attachShader(m,w),r.attachShader(m,y),t.index0AttributeName!==void 0?r.bindAttribLocation(m,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(m,0,"position"),r.linkProgram(m);function b(T){if(i.debug.checkShaderErrors){const B=r.getProgramInfoLog(m)||"",F=r.getShaderInfoLog(w)||"",H=r.getShaderInfoLog(y)||"",O=B.trim(),Q=F.trim(),D=H.trim();let j=!0,J=!0;if(r.getProgramParameter(m,r.LINK_STATUS)===!1)if(j=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,m,w,y);else{const ae=sl(r,w,"vertex"),he=sl(r,y,"fragment");Ve("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(m,r.VALIDATE_STATUS)+`

Material Name: `+T.name+`
Material Type: `+T.type+`

Program Info Log: `+O+`
`+ae+`
`+he)}else O!==""?ke("WebGLProgram: Program Info Log:",O):(Q===""||D==="")&&(J=!1);J&&(T.diagnostics={runnable:j,programLog:O,vertexShader:{log:Q,prefix:p},fragmentShader:{log:D,prefix:d}})}r.deleteShader(w),r.deleteShader(y),_=new Jr(r,m),x=om(r,m)}let _;this.getUniforms=function(){return _===void 0&&b(this),_};let x;this.getAttributes=function(){return x===void 0&&b(this),x};let K=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return K===!1&&(K=r.getProgramParameter(m,jg)),K},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=$g++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=w,this.fragmentShader=y,this}let vm=0;class Sm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,r=this._getShaderStage(t),A=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(r)===!1&&(o.add(r),r.usedTimes++),o.has(A)===!1&&(o.add(A),A.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new wm(e),t.set(e,n)),n}}class wm{constructor(e){this.id=vm++,this.code=e,this.usedTimes=0}}function ym(i,e,t,n,r,A){const o=new dc,l=new Sm,f=new Set,c=[],g=new Map,s=n.logarithmicDepthBuffer;let a=n.precision;const u={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function h(_){return f.add(_),_===0?"uv":`uv${_}`}function m(_,x,K,T,B){const F=T.fog,H=B.geometry,O=_.isMeshStandardMaterial||_.isMeshLambertMaterial||_.isMeshPhongMaterial?T.environment:null,Q=_.isMeshStandardMaterial||_.isMeshLambertMaterial&&!_.envMap||_.isMeshPhongMaterial&&!_.envMap,D=e.get(_.envMap||O,Q),j=D&&D.mapping===uA?D.image.height:null,J=u[_.type];_.precision!==null&&(a=n.getMaxPrecision(_.precision),a!==_.precision&&ke("WebGLProgram.getParameters:",_.precision,"not supported, using",a,"instead."));const ae=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,he=ae!==void 0?ae.length:0;let ue=0;H.morphAttributes.position!==void 0&&(ue=1),H.morphAttributes.normal!==void 0&&(ue=2),H.morphAttributes.color!==void 0&&(ue=3);let Oe,At,rt,Z;if(J){const Xe=Jt[J];Oe=Xe.vertexShader,At=Xe.fragmentShader}else Oe=_.vertexShader,At=_.fragmentShader,l.update(_),rt=l.getVertexShaderID(_),Z=l.getFragmentShaderID(_);const ie=i.getRenderTarget(),se=i.state.buffers.depth.getReversed(),Pe=B.isInstancedMesh===!0,ye=B.isBatchedMesh===!0,be=!!_.map,mt=!!_.matcap,ze=!!D,Ke=!!_.aoMap,et=!!_.lightMap,Le=!!_.bumpMap,at=!!_.normalMap,I=!!_.displacementMap,ct=!!_.emissiveMap,We=!!_.metalnessMap,nt=!!_.roughnessMap,Ce=_.anisotropy>0,S=_.clearcoat>0,M=_.dispersion>0,U=_.iridescence>0,X=_.sheen>0,q=_.transmission>0,W=Ce&&!!_.anisotropyMap,ge=S&&!!_.clearcoatMap,re=S&&!!_.clearcoatNormalMap,we=S&&!!_.clearcoatRoughnessMap,Te=U&&!!_.iridescenceMap,$=U&&!!_.iridescenceThicknessMap,te=X&&!!_.sheenColorMap,me=X&&!!_.sheenRoughnessMap,Re=!!_.specularMap,fe=!!_.specularColorMap,Fe=!!_.specularIntensityMap,k=q&&!!_.transmissionMap,Ae=q&&!!_.thicknessMap,ne=!!_.gradientMap,pe=!!_.alphaMap,ee=_.alphaTest>0,V=!!_.alphaHash,Me=!!_.extensions;let Ie=tn;_.toneMapped&&(ie===null||ie.isXRRenderTarget===!0)&&(Ie=i.toneMapping);const it={shaderID:J,shaderType:_.type,shaderName:_.name,vertexShader:Oe,fragmentShader:At,defines:_.defines,customVertexShaderID:rt,customFragmentShaderID:Z,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:a,batching:ye,batchingColor:ye&&B._colorsTexture!==null,instancing:Pe,instancingColor:Pe&&B.instanceColor!==null,instancingMorph:Pe&&B.morphTexture!==null,outputColorSpace:ie===null?i.outputColorSpace:ie.isXRRenderTarget===!0?ie.texture.colorSpace:ki,alphaToCoverage:!!_.alphaToCoverage,map:be,matcap:mt,envMap:ze,envMapMode:ze&&D.mapping,envMapCubeUVHeight:j,aoMap:Ke,lightMap:et,bumpMap:Le,normalMap:at,displacementMap:I,emissiveMap:ct,normalMapObjectSpace:at&&_.normalMapType===gf,normalMapTangentSpace:at&&_.normalMapType===pf,metalnessMap:We,roughnessMap:nt,anisotropy:Ce,anisotropyMap:W,clearcoat:S,clearcoatMap:ge,clearcoatNormalMap:re,clearcoatRoughnessMap:we,dispersion:M,iridescence:U,iridescenceMap:Te,iridescenceThicknessMap:$,sheen:X,sheenColorMap:te,sheenRoughnessMap:me,specularMap:Re,specularColorMap:fe,specularIntensityMap:Fe,transmission:q,transmissionMap:k,thicknessMap:Ae,gradientMap:ne,opaque:_.transparent===!1&&_.blending===Si&&_.alphaToCoverage===!1,alphaMap:pe,alphaTest:ee,alphaHash:V,combine:_.combine,mapUv:be&&h(_.map.channel),aoMapUv:Ke&&h(_.aoMap.channel),lightMapUv:et&&h(_.lightMap.channel),bumpMapUv:Le&&h(_.bumpMap.channel),normalMapUv:at&&h(_.normalMap.channel),displacementMapUv:I&&h(_.displacementMap.channel),emissiveMapUv:ct&&h(_.emissiveMap.channel),metalnessMapUv:We&&h(_.metalnessMap.channel),roughnessMapUv:nt&&h(_.roughnessMap.channel),anisotropyMapUv:W&&h(_.anisotropyMap.channel),clearcoatMapUv:ge&&h(_.clearcoatMap.channel),clearcoatNormalMapUv:re&&h(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:we&&h(_.clearcoatRoughnessMap.channel),iridescenceMapUv:Te&&h(_.iridescenceMap.channel),iridescenceThicknessMapUv:$&&h(_.iridescenceThicknessMap.channel),sheenColorMapUv:te&&h(_.sheenColorMap.channel),sheenRoughnessMapUv:me&&h(_.sheenRoughnessMap.channel),specularMapUv:Re&&h(_.specularMap.channel),specularColorMapUv:fe&&h(_.specularColorMap.channel),specularIntensityMapUv:Fe&&h(_.specularIntensityMap.channel),transmissionMapUv:k&&h(_.transmissionMap.channel),thicknessMapUv:Ae&&h(_.thicknessMap.channel),alphaMapUv:pe&&h(_.alphaMap.channel),vertexTangents:!!H.attributes.tangent&&(at||Ce),vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,pointsUvs:B.isPoints===!0&&!!H.attributes.uv&&(be||pe),fog:!!F,useFog:_.fog===!0,fogExp2:!!F&&F.isFogExp2,flatShading:_.wireframe===!1&&(_.flatShading===!0||H.attributes.normal===void 0&&at===!1&&(_.isMeshLambertMaterial||_.isMeshPhongMaterial||_.isMeshStandardMaterial||_.isMeshPhysicalMaterial)),sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:s,reversedDepthBuffer:se,skinning:B.isSkinnedMesh===!0,morphTargets:H.morphAttributes.position!==void 0,morphNormals:H.morphAttributes.normal!==void 0,morphColors:H.morphAttributes.color!==void 0,morphTargetsCount:he,morphTextureStride:ue,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:A.numPlanes,numClipIntersection:A.numIntersection,dithering:_.dithering,shadowMapEnabled:i.shadowMap.enabled&&K.length>0,shadowMapType:i.shadowMap.type,toneMapping:Ie,decodeVideoTexture:be&&_.map.isVideoTexture===!0&&Ge.getTransfer(_.map.colorSpace)===Ze,decodeVideoTextureEmissive:ct&&_.emissiveMap.isVideoTexture===!0&&Ge.getTransfer(_.emissiveMap.colorSpace)===Ze,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===pn,flipSided:_.side===Tt,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:Me&&_.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Me&&_.extensions.multiDraw===!0||ye)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return it.vertexUv1s=f.has(1),it.vertexUv2s=f.has(2),it.vertexUv3s=f.has(3),f.clear(),it}function p(_){const x=[];if(_.shaderID?x.push(_.shaderID):(x.push(_.customVertexShaderID),x.push(_.customFragmentShaderID)),_.defines!==void 0)for(const K in _.defines)x.push(K),x.push(_.defines[K]);return _.isRawShaderMaterial===!1&&(d(x,_),R(x,_),x.push(i.outputColorSpace)),x.push(_.customProgramCacheKey),x.join()}function d(_,x){_.push(x.precision),_.push(x.outputColorSpace),_.push(x.envMapMode),_.push(x.envMapCubeUVHeight),_.push(x.mapUv),_.push(x.alphaMapUv),_.push(x.lightMapUv),_.push(x.aoMapUv),_.push(x.bumpMapUv),_.push(x.normalMapUv),_.push(x.displacementMapUv),_.push(x.emissiveMapUv),_.push(x.metalnessMapUv),_.push(x.roughnessMapUv),_.push(x.anisotropyMapUv),_.push(x.clearcoatMapUv),_.push(x.clearcoatNormalMapUv),_.push(x.clearcoatRoughnessMapUv),_.push(x.iridescenceMapUv),_.push(x.iridescenceThicknessMapUv),_.push(x.sheenColorMapUv),_.push(x.sheenRoughnessMapUv),_.push(x.specularMapUv),_.push(x.specularColorMapUv),_.push(x.specularIntensityMapUv),_.push(x.transmissionMapUv),_.push(x.thicknessMapUv),_.push(x.combine),_.push(x.fogExp2),_.push(x.sizeAttenuation),_.push(x.morphTargetsCount),_.push(x.morphAttributeCount),_.push(x.numDirLights),_.push(x.numPointLights),_.push(x.numSpotLights),_.push(x.numSpotLightMaps),_.push(x.numHemiLights),_.push(x.numRectAreaLights),_.push(x.numDirLightShadows),_.push(x.numPointLightShadows),_.push(x.numSpotLightShadows),_.push(x.numSpotLightShadowsWithMaps),_.push(x.numLightProbes),_.push(x.shadowMapType),_.push(x.toneMapping),_.push(x.numClippingPlanes),_.push(x.numClipIntersection),_.push(x.depthPacking)}function R(_,x){o.disableAll(),x.instancing&&o.enable(0),x.instancingColor&&o.enable(1),x.instancingMorph&&o.enable(2),x.matcap&&o.enable(3),x.envMap&&o.enable(4),x.normalMapObjectSpace&&o.enable(5),x.normalMapTangentSpace&&o.enable(6),x.clearcoat&&o.enable(7),x.iridescence&&o.enable(8),x.alphaTest&&o.enable(9),x.vertexColors&&o.enable(10),x.vertexAlphas&&o.enable(11),x.vertexUv1s&&o.enable(12),x.vertexUv2s&&o.enable(13),x.vertexUv3s&&o.enable(14),x.vertexTangents&&o.enable(15),x.anisotropy&&o.enable(16),x.alphaHash&&o.enable(17),x.batching&&o.enable(18),x.dispersion&&o.enable(19),x.batchingColor&&o.enable(20),x.gradientMap&&o.enable(21),_.push(o.mask),o.disableAll(),x.fog&&o.enable(0),x.useFog&&o.enable(1),x.flatShading&&o.enable(2),x.logarithmicDepthBuffer&&o.enable(3),x.reversedDepthBuffer&&o.enable(4),x.skinning&&o.enable(5),x.morphTargets&&o.enable(6),x.morphNormals&&o.enable(7),x.morphColors&&o.enable(8),x.premultipliedAlpha&&o.enable(9),x.shadowMapEnabled&&o.enable(10),x.doubleSided&&o.enable(11),x.flipSided&&o.enable(12),x.useDepthPacking&&o.enable(13),x.dithering&&o.enable(14),x.transmission&&o.enable(15),x.sheen&&o.enable(16),x.opaque&&o.enable(17),x.pointsUvs&&o.enable(18),x.decodeVideoTexture&&o.enable(19),x.decodeVideoTextureEmissive&&o.enable(20),x.alphaToCoverage&&o.enable(21),_.push(o.mask)}function E(_){const x=u[_.type];let K;if(x){const T=Jt[x];K=$f.clone(T.uniforms)}else K=_.uniforms;return K}function v(_,x){let K=g.get(x);return K!==void 0?++K.usedTimes:(K=new Em(i,x,_,r),c.push(K),g.set(x,K)),K}function w(_){if(--_.usedTimes===0){const x=c.indexOf(_);c[x]=c[c.length-1],c.pop(),g.delete(_.cacheKey),_.destroy()}}function y(_){l.remove(_)}function b(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:E,acquireProgram:v,releaseProgram:w,releaseShaderCache:y,programs:c,dispose:b}}function Tm(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let l=i.get(o);return l===void 0&&(l={},i.set(o,l)),l}function n(o){i.delete(o)}function r(o,l,f){i.get(o)[l]=f}function A(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:A}}function bm(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function ul(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function fl(){const i=[];let e=0;const t=[],n=[],r=[];function A(){e=0,t.length=0,n.length=0,r.length=0}function o(a){let u=0;return a.isInstancedMesh&&(u+=2),a.isSkinnedMesh&&(u+=1),u}function l(a,u,h,m,p,d){let R=i[e];return R===void 0?(R={id:a.id,object:a,geometry:u,material:h,materialVariant:o(a),groupOrder:m,renderOrder:a.renderOrder,z:p,group:d},i[e]=R):(R.id=a.id,R.object=a,R.geometry=u,R.material=h,R.materialVariant=o(a),R.groupOrder=m,R.renderOrder=a.renderOrder,R.z=p,R.group=d),e++,R}function f(a,u,h,m,p,d){const R=l(a,u,h,m,p,d);h.transmission>0?n.push(R):h.transparent===!0?r.push(R):t.push(R)}function c(a,u,h,m,p,d){const R=l(a,u,h,m,p,d);h.transmission>0?n.unshift(R):h.transparent===!0?r.unshift(R):t.unshift(R)}function g(a,u){t.length>1&&t.sort(a||bm),n.length>1&&n.sort(u||ul),r.length>1&&r.sort(u||ul)}function s(){for(let a=e,u=i.length;a<u;a++){const h=i[a];if(h.id===null)break;h.id=null,h.object=null,h.geometry=null,h.material=null,h.group=null}}return{opaque:t,transmissive:n,transparent:r,init:A,push:f,unshift:c,finish:s,sort:g}}function Im(){let i=new WeakMap;function e(n,r){const A=i.get(n);let o;return A===void 0?(o=new fl,i.set(n,[o])):r>=A.length?(o=new fl,A.push(o)):o=A[r],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function km(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new z,color:new $e};break;case"SpotLight":t={position:new z,direction:new z,color:new $e,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new z,color:new $e,distance:0,decay:0};break;case"HemisphereLight":t={direction:new z,skyColor:new $e,groundColor:new $e};break;case"RectAreaLight":t={color:new $e,position:new z,halfWidth:new z,halfHeight:new z};break}return i[e.id]=t,t}}}function Um(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ye};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ye};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ye,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Pm=0;function Dm(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Om(i){const e=new km,t=Um(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new z);const r=new z,A=new dt,o=new dt;function l(c){let g=0,s=0,a=0;for(let x=0;x<9;x++)n.probe[x].set(0,0,0);let u=0,h=0,m=0,p=0,d=0,R=0,E=0,v=0,w=0,y=0,b=0;c.sort(Dm);for(let x=0,K=c.length;x<K;x++){const T=c[x],B=T.color,F=T.intensity,H=T.distance;let O=null;if(T.shadow&&T.shadow.map&&(T.shadow.map.texture.format===Ii?O=T.shadow.map.texture:O=T.shadow.map.depthTexture||T.shadow.map.texture),T.isAmbientLight)g+=B.r*F,s+=B.g*F,a+=B.b*F;else if(T.isLightProbe){for(let Q=0;Q<9;Q++)n.probe[Q].addScaledVector(T.sh.coefficients[Q],F);b++}else if(T.isDirectionalLight){const Q=e.get(T);if(Q.color.copy(T.color).multiplyScalar(T.intensity),T.castShadow){const D=T.shadow,j=t.get(T);j.shadowIntensity=D.intensity,j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,n.directionalShadow[u]=j,n.directionalShadowMap[u]=O,n.directionalShadowMatrix[u]=T.shadow.matrix,R++}n.directional[u]=Q,u++}else if(T.isSpotLight){const Q=e.get(T);Q.position.setFromMatrixPosition(T.matrixWorld),Q.color.copy(B).multiplyScalar(F),Q.distance=H,Q.coneCos=Math.cos(T.angle),Q.penumbraCos=Math.cos(T.angle*(1-T.penumbra)),Q.decay=T.decay,n.spot[m]=Q;const D=T.shadow;if(T.map&&(n.spotLightMap[w]=T.map,w++,D.updateMatrices(T),T.castShadow&&y++),n.spotLightMatrix[m]=D.matrix,T.castShadow){const j=t.get(T);j.shadowIntensity=D.intensity,j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,n.spotShadow[m]=j,n.spotShadowMap[m]=O,v++}m++}else if(T.isRectAreaLight){const Q=e.get(T);Q.color.copy(B).multiplyScalar(F),Q.halfWidth.set(T.width*.5,0,0),Q.halfHeight.set(0,T.height*.5,0),n.rectArea[p]=Q,p++}else if(T.isPointLight){const Q=e.get(T);if(Q.color.copy(T.color).multiplyScalar(T.intensity),Q.distance=T.distance,Q.decay=T.decay,T.castShadow){const D=T.shadow,j=t.get(T);j.shadowIntensity=D.intensity,j.shadowBias=D.bias,j.shadowNormalBias=D.normalBias,j.shadowRadius=D.radius,j.shadowMapSize=D.mapSize,j.shadowCameraNear=D.camera.near,j.shadowCameraFar=D.camera.far,n.pointShadow[h]=j,n.pointShadowMap[h]=O,n.pointShadowMatrix[h]=T.shadow.matrix,E++}n.point[h]=Q,h++}else if(T.isHemisphereLight){const Q=e.get(T);Q.skyColor.copy(T.color).multiplyScalar(F),Q.groundColor.copy(T.groundColor).multiplyScalar(F),n.hemi[d]=Q,d++}}p>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=oe.LTC_FLOAT_1,n.rectAreaLTC2=oe.LTC_FLOAT_2):(n.rectAreaLTC1=oe.LTC_HALF_1,n.rectAreaLTC2=oe.LTC_HALF_2)),n.ambient[0]=g,n.ambient[1]=s,n.ambient[2]=a;const _=n.hash;(_.directionalLength!==u||_.pointLength!==h||_.spotLength!==m||_.rectAreaLength!==p||_.hemiLength!==d||_.numDirectionalShadows!==R||_.numPointShadows!==E||_.numSpotShadows!==v||_.numSpotMaps!==w||_.numLightProbes!==b)&&(n.directional.length=u,n.spot.length=m,n.rectArea.length=p,n.point.length=h,n.hemi.length=d,n.directionalShadow.length=R,n.directionalShadowMap.length=R,n.pointShadow.length=E,n.pointShadowMap.length=E,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=R,n.pointShadowMatrix.length=E,n.spotLightMatrix.length=v+w-y,n.spotLightMap.length=w,n.numSpotLightShadowsWithMaps=y,n.numLightProbes=b,_.directionalLength=u,_.pointLength=h,_.spotLength=m,_.rectAreaLength=p,_.hemiLength=d,_.numDirectionalShadows=R,_.numPointShadows=E,_.numSpotShadows=v,_.numSpotMaps=w,_.numLightProbes=b,n.version=Pm++)}function f(c,g){let s=0,a=0,u=0,h=0,m=0;const p=g.matrixWorldInverse;for(let d=0,R=c.length;d<R;d++){const E=c[d];if(E.isDirectionalLight){const v=n.directional[s];v.direction.setFromMatrixPosition(E.matrixWorld),r.setFromMatrixPosition(E.target.matrixWorld),v.direction.sub(r),v.direction.transformDirection(p),s++}else if(E.isSpotLight){const v=n.spot[u];v.position.setFromMatrixPosition(E.matrixWorld),v.position.applyMatrix4(p),v.direction.setFromMatrixPosition(E.matrixWorld),r.setFromMatrixPosition(E.target.matrixWorld),v.direction.sub(r),v.direction.transformDirection(p),u++}else if(E.isRectAreaLight){const v=n.rectArea[h];v.position.setFromMatrixPosition(E.matrixWorld),v.position.applyMatrix4(p),o.identity(),A.copy(E.matrixWorld),A.premultiply(p),o.extractRotation(A),v.halfWidth.set(E.width*.5,0,0),v.halfHeight.set(0,E.height*.5,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),h++}else if(E.isPointLight){const v=n.point[a];v.position.setFromMatrixPosition(E.matrixWorld),v.position.applyMatrix4(p),a++}else if(E.isHemisphereLight){const v=n.hemi[m];v.direction.setFromMatrixPosition(E.matrixWorld),v.direction.transformDirection(p),m++}}}return{setup:l,setupView:f,state:n}}function dl(i){const e=new Om(i),t=[],n=[];function r(g){c.camera=g,t.length=0,n.length=0}function A(g){t.push(g)}function o(g){n.push(g)}function l(){e.setup(t)}function f(g){e.setupView(t,g)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:c,setupLights:l,setupLightsView:f,pushLight:A,pushShadow:o}}function Nm(i){let e=new WeakMap;function t(r,A=0){const o=e.get(r);let l;return o===void 0?(l=new dl(i),e.set(r,[l])):A>=o.length?(l=new dl(i),o.push(l)):l=o[A],l}function n(){e=new WeakMap}return{get:t,dispose:n}}const Lm=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Fm=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Bm=[new z(1,0,0),new z(-1,0,0),new z(0,1,0),new z(0,-1,0),new z(0,0,1),new z(0,0,-1)],Qm=[new z(0,-1,0),new z(0,-1,0),new z(0,0,1),new z(0,0,-1),new z(0,-1,0),new z(0,-1,0)],hl=new dt,Hi=new z,is=new z;function zm(i,e,t){let n=new Rc;const r=new Ye,A=new Ye,o=new lt,l=new id,f=new rd,c={},g=t.maxTextureSize,s={[Ln]:Tt,[Tt]:Ln,[pn]:pn},a=new Kt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ye},radius:{value:4}},vertexShader:Lm,fragmentShader:Fm}),u=a.clone();u.defines.HORIZONTAL_PASS=1;const h=new vn;h.setAttribute("position",new rn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const m=new an(h,a),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Kr;let d=this.type;this.render=function(y,b,_){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||y.length===0)return;this.type===Wu&&(ke("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=Kr);const x=i.getRenderTarget(),K=i.getActiveCubeFace(),T=i.getActiveMipmapLevel(),B=i.state;B.setBlending(Mn),B.buffers.depth.getReversed()===!0?B.buffers.color.setClear(0,0,0,0):B.buffers.color.setClear(1,1,1,1),B.buffers.depth.setTest(!0),B.setScissorTest(!1);const F=d!==this.type;F&&b.traverse(function(H){H.material&&(Array.isArray(H.material)?H.material.forEach(O=>O.needsUpdate=!0):H.material.needsUpdate=!0)});for(let H=0,O=y.length;H<O;H++){const Q=y[H],D=Q.shadow;if(D===void 0){ke("WebGLShadowMap:",Q,"has no shadow.");continue}if(D.autoUpdate===!1&&D.needsUpdate===!1)continue;r.copy(D.mapSize);const j=D.getFrameExtents();r.multiply(j),A.copy(D.mapSize),(r.x>g||r.y>g)&&(r.x>g&&(A.x=Math.floor(g/j.x),r.x=A.x*j.x,D.mapSize.x=A.x),r.y>g&&(A.y=Math.floor(g/j.y),r.y=A.y*j.y,D.mapSize.y=A.y));const J=i.state.buffers.depth.getReversed();if(D.camera._reversedDepth=J,D.map===null||F===!0){if(D.map!==null&&(D.map.depthTexture!==null&&(D.map.depthTexture.dispose(),D.map.depthTexture=null),D.map.dispose()),this.type===Ki){if(Q.isPointLight){ke("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}D.map=new nn(r.x,r.y,{format:Ii,type:Cn,minFilter:vt,magFilter:vt,generateMipmaps:!1}),D.map.texture.name=Q.name+".shadowMap",D.map.depthTexture=new er(r.x,r.y,Wt),D.map.depthTexture.name=Q.name+".shadowMapDepth",D.map.depthTexture.format=xn,D.map.depthTexture.compareFunction=null,D.map.depthTexture.minFilter=ht,D.map.depthTexture.magFilter=ht}else Q.isPointLight?(D.map=new Sc(r.x),D.map.depthTexture=new Jf(r.x,sn)):(D.map=new nn(r.x,r.y),D.map.depthTexture=new er(r.x,r.y,sn)),D.map.depthTexture.name=Q.name+".shadowMap",D.map.depthTexture.format=xn,this.type===Kr?(D.map.depthTexture.compareFunction=J?ma:ga,D.map.depthTexture.minFilter=vt,D.map.depthTexture.magFilter=vt):(D.map.depthTexture.compareFunction=null,D.map.depthTexture.minFilter=ht,D.map.depthTexture.magFilter=ht);D.camera.updateProjectionMatrix()}const ae=D.map.isWebGLCubeRenderTarget?6:1;for(let he=0;he<ae;he++){if(D.map.isWebGLCubeRenderTarget)i.setRenderTarget(D.map,he),i.clear();else{he===0&&(i.setRenderTarget(D.map),i.clear());const ue=D.getViewport(he);o.set(A.x*ue.x,A.y*ue.y,A.x*ue.z,A.y*ue.w),B.viewport(o)}if(Q.isPointLight){const ue=D.camera,Oe=D.matrix,At=Q.distance||ue.far;At!==ue.far&&(ue.far=At,ue.updateProjectionMatrix()),Hi.setFromMatrixPosition(Q.matrixWorld),ue.position.copy(Hi),is.copy(ue.position),is.add(Bm[he]),ue.up.copy(Qm[he]),ue.lookAt(is),ue.updateMatrixWorld(),Oe.makeTranslation(-Hi.x,-Hi.y,-Hi.z),hl.multiplyMatrices(ue.projectionMatrix,ue.matrixWorldInverse),D._frustum.setFromProjectionMatrix(hl,ue.coordinateSystem,ue.reversedDepth)}else D.updateMatrices(Q);n=D.getFrustum(),v(b,_,D.camera,Q,this.type)}D.isPointLightShadow!==!0&&this.type===Ki&&R(D,_),D.needsUpdate=!1}d=this.type,p.needsUpdate=!1,i.setRenderTarget(x,K,T)};function R(y,b){const _=e.update(m);a.defines.VSM_SAMPLES!==y.blurSamples&&(a.defines.VSM_SAMPLES=y.blurSamples,u.defines.VSM_SAMPLES=y.blurSamples,a.needsUpdate=!0,u.needsUpdate=!0),y.mapPass===null&&(y.mapPass=new nn(r.x,r.y,{format:Ii,type:Cn})),a.uniforms.shadow_pass.value=y.map.depthTexture,a.uniforms.resolution.value=y.mapSize,a.uniforms.radius.value=y.radius,i.setRenderTarget(y.mapPass),i.clear(),i.renderBufferDirect(b,null,_,a,m,null),u.uniforms.shadow_pass.value=y.mapPass.texture,u.uniforms.resolution.value=y.mapSize,u.uniforms.radius.value=y.radius,i.setRenderTarget(y.map),i.clear(),i.renderBufferDirect(b,null,_,u,m,null)}function E(y,b,_,x){let K=null;const T=_.isPointLight===!0?y.customDistanceMaterial:y.customDepthMaterial;if(T!==void 0)K=T;else if(K=_.isPointLight===!0?f:l,i.localClippingEnabled&&b.clipShadows===!0&&Array.isArray(b.clippingPlanes)&&b.clippingPlanes.length!==0||b.displacementMap&&b.displacementScale!==0||b.alphaMap&&b.alphaTest>0||b.map&&b.alphaTest>0||b.alphaToCoverage===!0){const B=K.uuid,F=b.uuid;let H=c[B];H===void 0&&(H={},c[B]=H);let O=H[F];O===void 0&&(O=K.clone(),H[F]=O,b.addEventListener("dispose",w)),K=O}if(K.visible=b.visible,K.wireframe=b.wireframe,x===Ki?K.side=b.shadowSide!==null?b.shadowSide:b.side:K.side=b.shadowSide!==null?b.shadowSide:s[b.side],K.alphaMap=b.alphaMap,K.alphaTest=b.alphaToCoverage===!0?.5:b.alphaTest,K.map=b.map,K.clipShadows=b.clipShadows,K.clippingPlanes=b.clippingPlanes,K.clipIntersection=b.clipIntersection,K.displacementMap=b.displacementMap,K.displacementScale=b.displacementScale,K.displacementBias=b.displacementBias,K.wireframeLinewidth=b.wireframeLinewidth,K.linewidth=b.linewidth,_.isPointLight===!0&&K.isMeshDistanceMaterial===!0){const B=i.properties.get(K);B.light=_}return K}function v(y,b,_,x,K){if(y.visible===!1)return;if(y.layers.test(b.layers)&&(y.isMesh||y.isLine||y.isPoints)&&(y.castShadow||y.receiveShadow&&K===Ki)&&(!y.frustumCulled||n.intersectsObject(y))){y.modelViewMatrix.multiplyMatrices(_.matrixWorldInverse,y.matrixWorld);const F=e.update(y),H=y.material;if(Array.isArray(H)){const O=F.groups;for(let Q=0,D=O.length;Q<D;Q++){const j=O[Q],J=H[j.materialIndex];if(J&&J.visible){const ae=E(y,J,x,K);y.onBeforeShadow(i,y,b,_,F,ae,j),i.renderBufferDirect(_,null,F,ae,y,j),y.onAfterShadow(i,y,b,_,F,ae,j)}}}else if(H.visible){const O=E(y,H,x,K);y.onBeforeShadow(i,y,b,_,F,O,null),i.renderBufferDirect(_,null,F,O,y,null),y.onAfterShadow(i,y,b,_,F,O,null)}}const B=y.children;for(let F=0,H=B.length;F<H;F++)v(B[F],b,_,x,K)}function w(y){y.target.removeEventListener("dispose",w);for(const _ in c){const x=c[_],K=y.target.uuid;K in x&&(x[K].dispose(),delete x[K])}}}function Gm(i,e){function t(){let k=!1;const Ae=new lt;let ne=null;const pe=new lt(0,0,0,0);return{setMask:function(ee){ne!==ee&&!k&&(i.colorMask(ee,ee,ee,ee),ne=ee)},setLocked:function(ee){k=ee},setClear:function(ee,V,Me,Ie,it){it===!0&&(ee*=Ie,V*=Ie,Me*=Ie),Ae.set(ee,V,Me,Ie),pe.equals(Ae)===!1&&(i.clearColor(ee,V,Me,Ie),pe.copy(Ae))},reset:function(){k=!1,ne=null,pe.set(-1,0,0,0)}}}function n(){let k=!1,Ae=!1,ne=null,pe=null,ee=null;return{setReversed:function(V){if(Ae!==V){const Me=e.get("EXT_clip_control");V?Me.clipControlEXT(Me.LOWER_LEFT_EXT,Me.ZERO_TO_ONE_EXT):Me.clipControlEXT(Me.LOWER_LEFT_EXT,Me.NEGATIVE_ONE_TO_ONE_EXT),Ae=V;const Ie=ee;ee=null,this.setClear(Ie)}},getReversed:function(){return Ae},setTest:function(V){V?ie(i.DEPTH_TEST):se(i.DEPTH_TEST)},setMask:function(V){ne!==V&&!k&&(i.depthMask(V),ne=V)},setFunc:function(V){if(Ae&&(V=wf[V]),pe!==V){switch(V){case gs:i.depthFunc(i.NEVER);break;case ms:i.depthFunc(i.ALWAYS);break;case Ms:i.depthFunc(i.LESS);break;case Ti:i.depthFunc(i.LEQUAL);break;case Rs:i.depthFunc(i.EQUAL);break;case _s:i.depthFunc(i.GEQUAL);break;case Cs:i.depthFunc(i.GREATER);break;case xs:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}pe=V}},setLocked:function(V){k=V},setClear:function(V){ee!==V&&(ee=V,Ae&&(V=1-V),i.clearDepth(V))},reset:function(){k=!1,ne=null,pe=null,ee=null,Ae=!1}}}function r(){let k=!1,Ae=null,ne=null,pe=null,ee=null,V=null,Me=null,Ie=null,it=null;return{setTest:function(Xe){k||(Xe?ie(i.STENCIL_TEST):se(i.STENCIL_TEST))},setMask:function(Xe){Ae!==Xe&&!k&&(i.stencilMask(Xe),Ae=Xe)},setFunc:function(Xe,on,ln){(ne!==Xe||pe!==on||ee!==ln)&&(i.stencilFunc(Xe,on,ln),ne=Xe,pe=on,ee=ln)},setOp:function(Xe,on,ln){(V!==Xe||Me!==on||Ie!==ln)&&(i.stencilOp(Xe,on,ln),V=Xe,Me=on,Ie=ln)},setLocked:function(Xe){k=Xe},setClear:function(Xe){it!==Xe&&(i.clearStencil(Xe),it=Xe)},reset:function(){k=!1,Ae=null,ne=null,pe=null,ee=null,V=null,Me=null,Ie=null,it=null}}}const A=new t,o=new n,l=new r,f=new WeakMap,c=new WeakMap;let g={},s={},a=new WeakMap,u=[],h=null,m=!1,p=null,d=null,R=null,E=null,v=null,w=null,y=null,b=new $e(0,0,0),_=0,x=!1,K=null,T=null,B=null,F=null,H=null;const O=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Q=!1,D=0;const j=i.getParameter(i.VERSION);j.indexOf("WebGL")!==-1?(D=parseFloat(/^WebGL (\d)/.exec(j)[1]),Q=D>=1):j.indexOf("OpenGL ES")!==-1&&(D=parseFloat(/^OpenGL ES (\d)/.exec(j)[1]),Q=D>=2);let J=null,ae={};const he=i.getParameter(i.SCISSOR_BOX),ue=i.getParameter(i.VIEWPORT),Oe=new lt().fromArray(he),At=new lt().fromArray(ue);function rt(k,Ae,ne,pe){const ee=new Uint8Array(4),V=i.createTexture();i.bindTexture(k,V),i.texParameteri(k,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(k,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Me=0;Me<ne;Me++)k===i.TEXTURE_3D||k===i.TEXTURE_2D_ARRAY?i.texImage3D(Ae,0,i.RGBA,1,1,pe,0,i.RGBA,i.UNSIGNED_BYTE,ee):i.texImage2D(Ae+Me,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ee);return V}const Z={};Z[i.TEXTURE_2D]=rt(i.TEXTURE_2D,i.TEXTURE_2D,1),Z[i.TEXTURE_CUBE_MAP]=rt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Z[i.TEXTURE_2D_ARRAY]=rt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Z[i.TEXTURE_3D]=rt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),A.setClear(0,0,0,1),o.setClear(1),l.setClear(0),ie(i.DEPTH_TEST),o.setFunc(Ti),Le(!1),at(_o),ie(i.CULL_FACE),Ke(Mn);function ie(k){g[k]!==!0&&(i.enable(k),g[k]=!0)}function se(k){g[k]!==!1&&(i.disable(k),g[k]=!1)}function Pe(k,Ae){return s[k]!==Ae?(i.bindFramebuffer(k,Ae),s[k]=Ae,k===i.DRAW_FRAMEBUFFER&&(s[i.FRAMEBUFFER]=Ae),k===i.FRAMEBUFFER&&(s[i.DRAW_FRAMEBUFFER]=Ae),!0):!1}function ye(k,Ae){let ne=u,pe=!1;if(k){ne=a.get(Ae),ne===void 0&&(ne=[],a.set(Ae,ne));const ee=k.textures;if(ne.length!==ee.length||ne[0]!==i.COLOR_ATTACHMENT0){for(let V=0,Me=ee.length;V<Me;V++)ne[V]=i.COLOR_ATTACHMENT0+V;ne.length=ee.length,pe=!0}}else ne[0]!==i.BACK&&(ne[0]=i.BACK,pe=!0);pe&&i.drawBuffers(ne)}function be(k){return h!==k?(i.useProgram(k),h=k,!0):!1}const mt={[Xn]:i.FUNC_ADD,[Xu]:i.FUNC_SUBTRACT,[Zu]:i.FUNC_REVERSE_SUBTRACT};mt[qu]=i.MIN,mt[Yu]=i.MAX;const ze={[Ju]:i.ZERO,[ju]:i.ONE,[$u]:i.SRC_COLOR,[hs]:i.SRC_ALPHA,[sf]:i.SRC_ALPHA_SATURATE,[rf]:i.DST_COLOR,[tf]:i.DST_ALPHA,[ef]:i.ONE_MINUS_SRC_COLOR,[ps]:i.ONE_MINUS_SRC_ALPHA,[Af]:i.ONE_MINUS_DST_COLOR,[nf]:i.ONE_MINUS_DST_ALPHA,[af]:i.CONSTANT_COLOR,[of]:i.ONE_MINUS_CONSTANT_COLOR,[lf]:i.CONSTANT_ALPHA,[cf]:i.ONE_MINUS_CONSTANT_ALPHA};function Ke(k,Ae,ne,pe,ee,V,Me,Ie,it,Xe){if(k===Mn){m===!0&&(se(i.BLEND),m=!1);return}if(m===!1&&(ie(i.BLEND),m=!0),k!==Ku){if(k!==p||Xe!==x){if((d!==Xn||v!==Xn)&&(i.blendEquation(i.FUNC_ADD),d=Xn,v=Xn),Xe)switch(k){case Si:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Co:i.blendFunc(i.ONE,i.ONE);break;case xo:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case Eo:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:Ve("WebGLState: Invalid blending: ",k);break}else switch(k){case Si:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Co:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case xo:Ve("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Eo:Ve("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ve("WebGLState: Invalid blending: ",k);break}R=null,E=null,w=null,y=null,b.set(0,0,0),_=0,p=k,x=Xe}return}ee=ee||Ae,V=V||ne,Me=Me||pe,(Ae!==d||ee!==v)&&(i.blendEquationSeparate(mt[Ae],mt[ee]),d=Ae,v=ee),(ne!==R||pe!==E||V!==w||Me!==y)&&(i.blendFuncSeparate(ze[ne],ze[pe],ze[V],ze[Me]),R=ne,E=pe,w=V,y=Me),(Ie.equals(b)===!1||it!==_)&&(i.blendColor(Ie.r,Ie.g,Ie.b,it),b.copy(Ie),_=it),p=k,x=!1}function et(k,Ae){k.side===pn?se(i.CULL_FACE):ie(i.CULL_FACE);let ne=k.side===Tt;Ae&&(ne=!ne),Le(ne),k.blending===Si&&k.transparent===!1?Ke(Mn):Ke(k.blending,k.blendEquation,k.blendSrc,k.blendDst,k.blendEquationAlpha,k.blendSrcAlpha,k.blendDstAlpha,k.blendColor,k.blendAlpha,k.premultipliedAlpha),o.setFunc(k.depthFunc),o.setTest(k.depthTest),o.setMask(k.depthWrite),A.setMask(k.colorWrite);const pe=k.stencilWrite;l.setTest(pe),pe&&(l.setMask(k.stencilWriteMask),l.setFunc(k.stencilFunc,k.stencilRef,k.stencilFuncMask),l.setOp(k.stencilFail,k.stencilZFail,k.stencilZPass)),ct(k.polygonOffset,k.polygonOffsetFactor,k.polygonOffsetUnits),k.alphaToCoverage===!0?ie(i.SAMPLE_ALPHA_TO_COVERAGE):se(i.SAMPLE_ALPHA_TO_COVERAGE)}function Le(k){K!==k&&(k?i.frontFace(i.CW):i.frontFace(i.CCW),K=k)}function at(k){k!==Hu?(ie(i.CULL_FACE),k!==T&&(k===_o?i.cullFace(i.BACK):k===Vu?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):se(i.CULL_FACE),T=k}function I(k){k!==B&&(Q&&i.lineWidth(k),B=k)}function ct(k,Ae,ne){k?(ie(i.POLYGON_OFFSET_FILL),(F!==Ae||H!==ne)&&(F=Ae,H=ne,o.getReversed()&&(Ae=-Ae),i.polygonOffset(Ae,ne))):se(i.POLYGON_OFFSET_FILL)}function We(k){k?ie(i.SCISSOR_TEST):se(i.SCISSOR_TEST)}function nt(k){k===void 0&&(k=i.TEXTURE0+O-1),J!==k&&(i.activeTexture(k),J=k)}function Ce(k,Ae,ne){ne===void 0&&(J===null?ne=i.TEXTURE0+O-1:ne=J);let pe=ae[ne];pe===void 0&&(pe={type:void 0,texture:void 0},ae[ne]=pe),(pe.type!==k||pe.texture!==Ae)&&(J!==ne&&(i.activeTexture(ne),J=ne),i.bindTexture(k,Ae||Z[k]),pe.type=k,pe.texture=Ae)}function S(){const k=ae[J];k!==void 0&&k.type!==void 0&&(i.bindTexture(k.type,null),k.type=void 0,k.texture=void 0)}function M(){try{i.compressedTexImage2D(...arguments)}catch(k){Ve("WebGLState:",k)}}function U(){try{i.compressedTexImage3D(...arguments)}catch(k){Ve("WebGLState:",k)}}function X(){try{i.texSubImage2D(...arguments)}catch(k){Ve("WebGLState:",k)}}function q(){try{i.texSubImage3D(...arguments)}catch(k){Ve("WebGLState:",k)}}function W(){try{i.compressedTexSubImage2D(...arguments)}catch(k){Ve("WebGLState:",k)}}function ge(){try{i.compressedTexSubImage3D(...arguments)}catch(k){Ve("WebGLState:",k)}}function re(){try{i.texStorage2D(...arguments)}catch(k){Ve("WebGLState:",k)}}function we(){try{i.texStorage3D(...arguments)}catch(k){Ve("WebGLState:",k)}}function Te(){try{i.texImage2D(...arguments)}catch(k){Ve("WebGLState:",k)}}function $(){try{i.texImage3D(...arguments)}catch(k){Ve("WebGLState:",k)}}function te(k){Oe.equals(k)===!1&&(i.scissor(k.x,k.y,k.z,k.w),Oe.copy(k))}function me(k){At.equals(k)===!1&&(i.viewport(k.x,k.y,k.z,k.w),At.copy(k))}function Re(k,Ae){let ne=c.get(Ae);ne===void 0&&(ne=new WeakMap,c.set(Ae,ne));let pe=ne.get(k);pe===void 0&&(pe=i.getUniformBlockIndex(Ae,k.name),ne.set(k,pe))}function fe(k,Ae){const pe=c.get(Ae).get(k);f.get(Ae)!==pe&&(i.uniformBlockBinding(Ae,pe,k.__bindingPointIndex),f.set(Ae,pe))}function Fe(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),g={},J=null,ae={},s={},a=new WeakMap,u=[],h=null,m=!1,p=null,d=null,R=null,E=null,v=null,w=null,y=null,b=new $e(0,0,0),_=0,x=!1,K=null,T=null,B=null,F=null,H=null,Oe.set(0,0,i.canvas.width,i.canvas.height),At.set(0,0,i.canvas.width,i.canvas.height),A.reset(),o.reset(),l.reset()}return{buffers:{color:A,depth:o,stencil:l},enable:ie,disable:se,bindFramebuffer:Pe,drawBuffers:ye,useProgram:be,setBlending:Ke,setMaterial:et,setFlipSided:Le,setCullFace:at,setLineWidth:I,setPolygonOffset:ct,setScissorTest:We,activeTexture:nt,bindTexture:Ce,unbindTexture:S,compressedTexImage2D:M,compressedTexImage3D:U,texImage2D:Te,texImage3D:$,updateUBOMapping:Re,uniformBlockBinding:fe,texStorage2D:re,texStorage3D:we,texSubImage2D:X,texSubImage3D:q,compressedTexSubImage2D:W,compressedTexSubImage3D:ge,scissor:te,viewport:me,reset:Fe}}function Hm(i,e,t,n,r,A,o){const l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,f=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ye,g=new WeakMap;let s;const a=new WeakMap;let u=!1;try{u=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function h(S,M){return u?new OffscreenCanvas(S,M):aA("canvas")}function m(S,M,U){let X=1;const q=Ce(S);if((q.width>U||q.height>U)&&(X=U/Math.max(q.width,q.height)),X<1)if(typeof HTMLImageElement<"u"&&S instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&S instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&S instanceof ImageBitmap||typeof VideoFrame<"u"&&S instanceof VideoFrame){const W=Math.floor(X*q.width),ge=Math.floor(X*q.height);s===void 0&&(s=h(W,ge));const re=M?h(W,ge):s;return re.width=W,re.height=ge,re.getContext("2d").drawImage(S,0,0,W,ge),ke("WebGLRenderer: Texture has been resized from ("+q.width+"x"+q.height+") to ("+W+"x"+ge+")."),re}else return"data"in S&&ke("WebGLRenderer: Image in DataTexture is too big ("+q.width+"x"+q.height+")."),S;return S}function p(S){return S.generateMipmaps}function d(S){i.generateMipmap(S)}function R(S){return S.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:S.isWebGL3DRenderTarget?i.TEXTURE_3D:S.isWebGLArrayRenderTarget||S.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function E(S,M,U,X,q=!1){if(S!==null){if(i[S]!==void 0)return i[S];ke("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+S+"'")}let W=M;if(M===i.RED&&(U===i.FLOAT&&(W=i.R32F),U===i.HALF_FLOAT&&(W=i.R16F),U===i.UNSIGNED_BYTE&&(W=i.R8)),M===i.RED_INTEGER&&(U===i.UNSIGNED_BYTE&&(W=i.R8UI),U===i.UNSIGNED_SHORT&&(W=i.R16UI),U===i.UNSIGNED_INT&&(W=i.R32UI),U===i.BYTE&&(W=i.R8I),U===i.SHORT&&(W=i.R16I),U===i.INT&&(W=i.R32I)),M===i.RG&&(U===i.FLOAT&&(W=i.RG32F),U===i.HALF_FLOAT&&(W=i.RG16F),U===i.UNSIGNED_BYTE&&(W=i.RG8)),M===i.RG_INTEGER&&(U===i.UNSIGNED_BYTE&&(W=i.RG8UI),U===i.UNSIGNED_SHORT&&(W=i.RG16UI),U===i.UNSIGNED_INT&&(W=i.RG32UI),U===i.BYTE&&(W=i.RG8I),U===i.SHORT&&(W=i.RG16I),U===i.INT&&(W=i.RG32I)),M===i.RGB_INTEGER&&(U===i.UNSIGNED_BYTE&&(W=i.RGB8UI),U===i.UNSIGNED_SHORT&&(W=i.RGB16UI),U===i.UNSIGNED_INT&&(W=i.RGB32UI),U===i.BYTE&&(W=i.RGB8I),U===i.SHORT&&(W=i.RGB16I),U===i.INT&&(W=i.RGB32I)),M===i.RGBA_INTEGER&&(U===i.UNSIGNED_BYTE&&(W=i.RGBA8UI),U===i.UNSIGNED_SHORT&&(W=i.RGBA16UI),U===i.UNSIGNED_INT&&(W=i.RGBA32UI),U===i.BYTE&&(W=i.RGBA8I),U===i.SHORT&&(W=i.RGBA16I),U===i.INT&&(W=i.RGBA32I)),M===i.RGB&&(U===i.UNSIGNED_INT_5_9_9_9_REV&&(W=i.RGB9_E5),U===i.UNSIGNED_INT_10F_11F_11F_REV&&(W=i.R11F_G11F_B10F)),M===i.RGBA){const ge=q?AA:Ge.getTransfer(X);U===i.FLOAT&&(W=i.RGBA32F),U===i.HALF_FLOAT&&(W=i.RGBA16F),U===i.UNSIGNED_BYTE&&(W=ge===Ze?i.SRGB8_ALPHA8:i.RGBA8),U===i.UNSIGNED_SHORT_4_4_4_4&&(W=i.RGBA4),U===i.UNSIGNED_SHORT_5_5_5_1&&(W=i.RGB5_A1)}return(W===i.R16F||W===i.R32F||W===i.RG16F||W===i.RG32F||W===i.RGBA16F||W===i.RGBA32F)&&e.get("EXT_color_buffer_float"),W}function v(S,M){let U;return S?M===null||M===sn||M===$i?U=i.DEPTH24_STENCIL8:M===Wt?U=i.DEPTH32F_STENCIL8:M===ji&&(U=i.DEPTH24_STENCIL8,ke("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):M===null||M===sn||M===$i?U=i.DEPTH_COMPONENT24:M===Wt?U=i.DEPTH_COMPONENT32F:M===ji&&(U=i.DEPTH_COMPONENT16),U}function w(S,M){return p(S)===!0||S.isFramebufferTexture&&S.minFilter!==ht&&S.minFilter!==vt?Math.log2(Math.max(M.width,M.height))+1:S.mipmaps!==void 0&&S.mipmaps.length>0?S.mipmaps.length:S.isCompressedTexture&&Array.isArray(S.image)?M.mipmaps.length:1}function y(S){const M=S.target;M.removeEventListener("dispose",y),_(M),M.isVideoTexture&&g.delete(M)}function b(S){const M=S.target;M.removeEventListener("dispose",b),K(M)}function _(S){const M=n.get(S);if(M.__webglInit===void 0)return;const U=S.source,X=a.get(U);if(X){const q=X[M.__cacheKey];q.usedTimes--,q.usedTimes===0&&x(S),Object.keys(X).length===0&&a.delete(U)}n.remove(S)}function x(S){const M=n.get(S);i.deleteTexture(M.__webglTexture);const U=S.source,X=a.get(U);delete X[M.__cacheKey],o.memory.textures--}function K(S){const M=n.get(S);if(S.depthTexture&&(S.depthTexture.dispose(),n.remove(S.depthTexture)),S.isWebGLCubeRenderTarget)for(let X=0;X<6;X++){if(Array.isArray(M.__webglFramebuffer[X]))for(let q=0;q<M.__webglFramebuffer[X].length;q++)i.deleteFramebuffer(M.__webglFramebuffer[X][q]);else i.deleteFramebuffer(M.__webglFramebuffer[X]);M.__webglDepthbuffer&&i.deleteRenderbuffer(M.__webglDepthbuffer[X])}else{if(Array.isArray(M.__webglFramebuffer))for(let X=0;X<M.__webglFramebuffer.length;X++)i.deleteFramebuffer(M.__webglFramebuffer[X]);else i.deleteFramebuffer(M.__webglFramebuffer);if(M.__webglDepthbuffer&&i.deleteRenderbuffer(M.__webglDepthbuffer),M.__webglMultisampledFramebuffer&&i.deleteFramebuffer(M.__webglMultisampledFramebuffer),M.__webglColorRenderbuffer)for(let X=0;X<M.__webglColorRenderbuffer.length;X++)M.__webglColorRenderbuffer[X]&&i.deleteRenderbuffer(M.__webglColorRenderbuffer[X]);M.__webglDepthRenderbuffer&&i.deleteRenderbuffer(M.__webglDepthRenderbuffer)}const U=S.textures;for(let X=0,q=U.length;X<q;X++){const W=n.get(U[X]);W.__webglTexture&&(i.deleteTexture(W.__webglTexture),o.memory.textures--),n.remove(U[X])}n.remove(S)}let T=0;function B(){T=0}function F(){const S=T;return S>=r.maxTextures&&ke("WebGLTextures: Trying to use "+S+" texture units while this GPU supports only "+r.maxTextures),T+=1,S}function H(S){const M=[];return M.push(S.wrapS),M.push(S.wrapT),M.push(S.wrapR||0),M.push(S.magFilter),M.push(S.minFilter),M.push(S.anisotropy),M.push(S.internalFormat),M.push(S.format),M.push(S.type),M.push(S.generateMipmaps),M.push(S.premultiplyAlpha),M.push(S.flipY),M.push(S.unpackAlignment),M.push(S.colorSpace),M.join()}function O(S,M){const U=n.get(S);if(S.isVideoTexture&&We(S),S.isRenderTargetTexture===!1&&S.isExternalTexture!==!0&&S.version>0&&U.__version!==S.version){const X=S.image;if(X===null)ke("WebGLRenderer: Texture marked for update but no image data found.");else if(X.complete===!1)ke("WebGLRenderer: Texture marked for update but image is incomplete");else{Z(U,S,M);return}}else S.isExternalTexture&&(U.__webglTexture=S.sourceTexture?S.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,U.__webglTexture,i.TEXTURE0+M)}function Q(S,M){const U=n.get(S);if(S.isRenderTargetTexture===!1&&S.version>0&&U.__version!==S.version){Z(U,S,M);return}else S.isExternalTexture&&(U.__webglTexture=S.sourceTexture?S.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,U.__webglTexture,i.TEXTURE0+M)}function D(S,M){const U=n.get(S);if(S.isRenderTargetTexture===!1&&S.version>0&&U.__version!==S.version){Z(U,S,M);return}t.bindTexture(i.TEXTURE_3D,U.__webglTexture,i.TEXTURE0+M)}function j(S,M){const U=n.get(S);if(S.isCubeDepthTexture!==!0&&S.version>0&&U.__version!==S.version){ie(U,S,M);return}t.bindTexture(i.TEXTURE_CUBE_MAP,U.__webglTexture,i.TEXTURE0+M)}const J={[Es]:i.REPEAT,[mn]:i.CLAMP_TO_EDGE,[vs]:i.MIRRORED_REPEAT},ae={[ht]:i.NEAREST,[df]:i.NEAREST_MIPMAP_NEAREST,[Rr]:i.NEAREST_MIPMAP_LINEAR,[vt]:i.LINEAR,[yA]:i.LINEAR_MIPMAP_NEAREST,[qn]:i.LINEAR_MIPMAP_LINEAR},he={[mf]:i.NEVER,[xf]:i.ALWAYS,[Mf]:i.LESS,[ga]:i.LEQUAL,[Rf]:i.EQUAL,[ma]:i.GEQUAL,[_f]:i.GREATER,[Cf]:i.NOTEQUAL};function ue(S,M){if(M.type===Wt&&e.has("OES_texture_float_linear")===!1&&(M.magFilter===vt||M.magFilter===yA||M.magFilter===Rr||M.magFilter===qn||M.minFilter===vt||M.minFilter===yA||M.minFilter===Rr||M.minFilter===qn)&&ke("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(S,i.TEXTURE_WRAP_S,J[M.wrapS]),i.texParameteri(S,i.TEXTURE_WRAP_T,J[M.wrapT]),(S===i.TEXTURE_3D||S===i.TEXTURE_2D_ARRAY)&&i.texParameteri(S,i.TEXTURE_WRAP_R,J[M.wrapR]),i.texParameteri(S,i.TEXTURE_MAG_FILTER,ae[M.magFilter]),i.texParameteri(S,i.TEXTURE_MIN_FILTER,ae[M.minFilter]),M.compareFunction&&(i.texParameteri(S,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(S,i.TEXTURE_COMPARE_FUNC,he[M.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(M.magFilter===ht||M.minFilter!==Rr&&M.minFilter!==qn||M.type===Wt&&e.has("OES_texture_float_linear")===!1)return;if(M.anisotropy>1||n.get(M).__currentAnisotropy){const U=e.get("EXT_texture_filter_anisotropic");i.texParameterf(S,U.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,r.getMaxAnisotropy())),n.get(M).__currentAnisotropy=M.anisotropy}}}function Oe(S,M){let U=!1;S.__webglInit===void 0&&(S.__webglInit=!0,M.addEventListener("dispose",y));const X=M.source;let q=a.get(X);q===void 0&&(q={},a.set(X,q));const W=H(M);if(W!==S.__cacheKey){q[W]===void 0&&(q[W]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,U=!0),q[W].usedTimes++;const ge=q[S.__cacheKey];ge!==void 0&&(q[S.__cacheKey].usedTimes--,ge.usedTimes===0&&x(M)),S.__cacheKey=W,S.__webglTexture=q[W].texture}return U}function At(S,M,U){return Math.floor(Math.floor(S/U)/M)}function rt(S,M,U,X){const W=S.updateRanges;if(W.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,M.width,M.height,U,X,M.data);else{W.sort(($,te)=>$.start-te.start);let ge=0;for(let $=1;$<W.length;$++){const te=W[ge],me=W[$],Re=te.start+te.count,fe=At(me.start,M.width,4),Fe=At(te.start,M.width,4);me.start<=Re+1&&fe===Fe&&At(me.start+me.count-1,M.width,4)===fe?te.count=Math.max(te.count,me.start+me.count-te.start):(++ge,W[ge]=me)}W.length=ge+1;const re=i.getParameter(i.UNPACK_ROW_LENGTH),we=i.getParameter(i.UNPACK_SKIP_PIXELS),Te=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,M.width);for(let $=0,te=W.length;$<te;$++){const me=W[$],Re=Math.floor(me.start/4),fe=Math.ceil(me.count/4),Fe=Re%M.width,k=Math.floor(Re/M.width),Ae=fe,ne=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Fe),i.pixelStorei(i.UNPACK_SKIP_ROWS,k),t.texSubImage2D(i.TEXTURE_2D,0,Fe,k,Ae,ne,U,X,M.data)}S.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,re),i.pixelStorei(i.UNPACK_SKIP_PIXELS,we),i.pixelStorei(i.UNPACK_SKIP_ROWS,Te)}}function Z(S,M,U){let X=i.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(X=i.TEXTURE_2D_ARRAY),M.isData3DTexture&&(X=i.TEXTURE_3D);const q=Oe(S,M),W=M.source;t.bindTexture(X,S.__webglTexture,i.TEXTURE0+U);const ge=n.get(W);if(W.version!==ge.__version||q===!0){t.activeTexture(i.TEXTURE0+U);const re=Ge.getPrimaries(Ge.workingColorSpace),we=M.colorSpace===Dn?null:Ge.getPrimaries(M.colorSpace),Te=M.colorSpace===Dn||re===we?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Te);let $=m(M.image,!1,r.maxTextureSize);$=nt(M,$);const te=A.convert(M.format,M.colorSpace),me=A.convert(M.type);let Re=E(M.internalFormat,te,me,M.colorSpace,M.isVideoTexture);ue(X,M);let fe;const Fe=M.mipmaps,k=M.isVideoTexture!==!0,Ae=ge.__version===void 0||q===!0,ne=W.dataReady,pe=w(M,$);if(M.isDepthTexture)Re=v(M.format===Yn,M.type),Ae&&(k?t.texStorage2D(i.TEXTURE_2D,1,Re,$.width,$.height):t.texImage2D(i.TEXTURE_2D,0,Re,$.width,$.height,0,te,me,null));else if(M.isDataTexture)if(Fe.length>0){k&&Ae&&t.texStorage2D(i.TEXTURE_2D,pe,Re,Fe[0].width,Fe[0].height);for(let ee=0,V=Fe.length;ee<V;ee++)fe=Fe[ee],k?ne&&t.texSubImage2D(i.TEXTURE_2D,ee,0,0,fe.width,fe.height,te,me,fe.data):t.texImage2D(i.TEXTURE_2D,ee,Re,fe.width,fe.height,0,te,me,fe.data);M.generateMipmaps=!1}else k?(Ae&&t.texStorage2D(i.TEXTURE_2D,pe,Re,$.width,$.height),ne&&rt(M,$,te,me)):t.texImage2D(i.TEXTURE_2D,0,Re,$.width,$.height,0,te,me,$.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){k&&Ae&&t.texStorage3D(i.TEXTURE_2D_ARRAY,pe,Re,Fe[0].width,Fe[0].height,$.depth);for(let ee=0,V=Fe.length;ee<V;ee++)if(fe=Fe[ee],M.format!==Nt)if(te!==null)if(k){if(ne)if(M.layerUpdates.size>0){const Me=Wo(fe.width,fe.height,M.format,M.type);for(const Ie of M.layerUpdates){const it=fe.data.subarray(Ie*Me/fe.data.BYTES_PER_ELEMENT,(Ie+1)*Me/fe.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ee,0,0,Ie,fe.width,fe.height,1,te,it)}M.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ee,0,0,0,fe.width,fe.height,$.depth,te,fe.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ee,Re,fe.width,fe.height,$.depth,0,fe.data,0,0);else ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else k?ne&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ee,0,0,0,fe.width,fe.height,$.depth,te,me,fe.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ee,Re,fe.width,fe.height,$.depth,0,te,me,fe.data)}else{k&&Ae&&t.texStorage2D(i.TEXTURE_2D,pe,Re,Fe[0].width,Fe[0].height);for(let ee=0,V=Fe.length;ee<V;ee++)fe=Fe[ee],M.format!==Nt?te!==null?k?ne&&t.compressedTexSubImage2D(i.TEXTURE_2D,ee,0,0,fe.width,fe.height,te,fe.data):t.compressedTexImage2D(i.TEXTURE_2D,ee,Re,fe.width,fe.height,0,fe.data):ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):k?ne&&t.texSubImage2D(i.TEXTURE_2D,ee,0,0,fe.width,fe.height,te,me,fe.data):t.texImage2D(i.TEXTURE_2D,ee,Re,fe.width,fe.height,0,te,me,fe.data)}else if(M.isDataArrayTexture)if(k){if(Ae&&t.texStorage3D(i.TEXTURE_2D_ARRAY,pe,Re,$.width,$.height,$.depth),ne)if(M.layerUpdates.size>0){const ee=Wo($.width,$.height,M.format,M.type);for(const V of M.layerUpdates){const Me=$.data.subarray(V*ee/$.data.BYTES_PER_ELEMENT,(V+1)*ee/$.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,V,$.width,$.height,1,te,me,Me)}M.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,$.width,$.height,$.depth,te,me,$.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Re,$.width,$.height,$.depth,0,te,me,$.data);else if(M.isData3DTexture)k?(Ae&&t.texStorage3D(i.TEXTURE_3D,pe,Re,$.width,$.height,$.depth),ne&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,$.width,$.height,$.depth,te,me,$.data)):t.texImage3D(i.TEXTURE_3D,0,Re,$.width,$.height,$.depth,0,te,me,$.data);else if(M.isFramebufferTexture){if(Ae)if(k)t.texStorage2D(i.TEXTURE_2D,pe,Re,$.width,$.height);else{let ee=$.width,V=$.height;for(let Me=0;Me<pe;Me++)t.texImage2D(i.TEXTURE_2D,Me,Re,ee,V,0,te,me,null),ee>>=1,V>>=1}}else if(Fe.length>0){if(k&&Ae){const ee=Ce(Fe[0]);t.texStorage2D(i.TEXTURE_2D,pe,Re,ee.width,ee.height)}for(let ee=0,V=Fe.length;ee<V;ee++)fe=Fe[ee],k?ne&&t.texSubImage2D(i.TEXTURE_2D,ee,0,0,te,me,fe):t.texImage2D(i.TEXTURE_2D,ee,Re,te,me,fe);M.generateMipmaps=!1}else if(k){if(Ae){const ee=Ce($);t.texStorage2D(i.TEXTURE_2D,pe,Re,ee.width,ee.height)}ne&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,te,me,$)}else t.texImage2D(i.TEXTURE_2D,0,Re,te,me,$);p(M)&&d(X),ge.__version=W.version,M.onUpdate&&M.onUpdate(M)}S.__version=M.version}function ie(S,M,U){if(M.image.length!==6)return;const X=Oe(S,M),q=M.source;t.bindTexture(i.TEXTURE_CUBE_MAP,S.__webglTexture,i.TEXTURE0+U);const W=n.get(q);if(q.version!==W.__version||X===!0){t.activeTexture(i.TEXTURE0+U);const ge=Ge.getPrimaries(Ge.workingColorSpace),re=M.colorSpace===Dn?null:Ge.getPrimaries(M.colorSpace),we=M.colorSpace===Dn||ge===re?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,M.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,M.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,we);const Te=M.isCompressedTexture||M.image[0].isCompressedTexture,$=M.image[0]&&M.image[0].isDataTexture,te=[];for(let V=0;V<6;V++)!Te&&!$?te[V]=m(M.image[V],!0,r.maxCubemapSize):te[V]=$?M.image[V].image:M.image[V],te[V]=nt(M,te[V]);const me=te[0],Re=A.convert(M.format,M.colorSpace),fe=A.convert(M.type),Fe=E(M.internalFormat,Re,fe,M.colorSpace),k=M.isVideoTexture!==!0,Ae=W.__version===void 0||X===!0,ne=q.dataReady;let pe=w(M,me);ue(i.TEXTURE_CUBE_MAP,M);let ee;if(Te){k&&Ae&&t.texStorage2D(i.TEXTURE_CUBE_MAP,pe,Fe,me.width,me.height);for(let V=0;V<6;V++){ee=te[V].mipmaps;for(let Me=0;Me<ee.length;Me++){const Ie=ee[Me];M.format!==Nt?Re!==null?k?ne&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me,0,0,Ie.width,Ie.height,Re,Ie.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me,Fe,Ie.width,Ie.height,0,Ie.data):ke("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):k?ne&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me,0,0,Ie.width,Ie.height,Re,fe,Ie.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me,Fe,Ie.width,Ie.height,0,Re,fe,Ie.data)}}}else{if(ee=M.mipmaps,k&&Ae){ee.length>0&&pe++;const V=Ce(te[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,pe,Fe,V.width,V.height)}for(let V=0;V<6;V++)if($){k?ne&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,0,0,te[V].width,te[V].height,Re,fe,te[V].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,Fe,te[V].width,te[V].height,0,Re,fe,te[V].data);for(let Me=0;Me<ee.length;Me++){const it=ee[Me].image[V].image;k?ne&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me+1,0,0,it.width,it.height,Re,fe,it.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me+1,Fe,it.width,it.height,0,Re,fe,it.data)}}else{k?ne&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,0,0,Re,fe,te[V]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,0,Fe,Re,fe,te[V]);for(let Me=0;Me<ee.length;Me++){const Ie=ee[Me];k?ne&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me+1,0,0,Re,fe,Ie.image[V]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+V,Me+1,Fe,Re,fe,Ie.image[V])}}}p(M)&&d(i.TEXTURE_CUBE_MAP),W.__version=q.version,M.onUpdate&&M.onUpdate(M)}S.__version=M.version}function se(S,M,U,X,q,W){const ge=A.convert(U.format,U.colorSpace),re=A.convert(U.type),we=E(U.internalFormat,ge,re,U.colorSpace),Te=n.get(M),$=n.get(U);if($.__renderTarget=M,!Te.__hasExternalTextures){const te=Math.max(1,M.width>>W),me=Math.max(1,M.height>>W);q===i.TEXTURE_3D||q===i.TEXTURE_2D_ARRAY?t.texImage3D(q,W,we,te,me,M.depth,0,ge,re,null):t.texImage2D(q,W,we,te,me,0,ge,re,null)}t.bindFramebuffer(i.FRAMEBUFFER,S),ct(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,X,q,$.__webglTexture,0,I(M)):(q===i.TEXTURE_2D||q>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&q<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,X,q,$.__webglTexture,W),t.bindFramebuffer(i.FRAMEBUFFER,null)}function Pe(S,M,U){if(i.bindRenderbuffer(i.RENDERBUFFER,S),M.depthBuffer){const X=M.depthTexture,q=X&&X.isDepthTexture?X.type:null,W=v(M.stencilBuffer,q),ge=M.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;ct(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,I(M),W,M.width,M.height):U?i.renderbufferStorageMultisample(i.RENDERBUFFER,I(M),W,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,W,M.width,M.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ge,i.RENDERBUFFER,S)}else{const X=M.textures;for(let q=0;q<X.length;q++){const W=X[q],ge=A.convert(W.format,W.colorSpace),re=A.convert(W.type),we=E(W.internalFormat,ge,re,W.colorSpace);ct(M)?l.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,I(M),we,M.width,M.height):U?i.renderbufferStorageMultisample(i.RENDERBUFFER,I(M),we,M.width,M.height):i.renderbufferStorage(i.RENDERBUFFER,we,M.width,M.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function ye(S,M,U){const X=M.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,S),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const q=n.get(M.depthTexture);if(q.__renderTarget=M,(!q.__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),X){if(q.__webglInit===void 0&&(q.__webglInit=!0,M.depthTexture.addEventListener("dispose",y)),q.__webglTexture===void 0){q.__webglTexture=i.createTexture(),t.bindTexture(i.TEXTURE_CUBE_MAP,q.__webglTexture),ue(i.TEXTURE_CUBE_MAP,M.depthTexture);const Te=A.convert(M.depthTexture.format),$=A.convert(M.depthTexture.type);let te;M.depthTexture.format===xn?te=i.DEPTH_COMPONENT24:M.depthTexture.format===Yn&&(te=i.DEPTH24_STENCIL8);for(let me=0;me<6;me++)i.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,te,M.width,M.height,0,Te,$,null)}}else O(M.depthTexture,0);const W=q.__webglTexture,ge=I(M),re=X?i.TEXTURE_CUBE_MAP_POSITIVE_X+U:i.TEXTURE_2D,we=M.depthTexture.format===Yn?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(M.depthTexture.format===xn)ct(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,we,re,W,0,ge):i.framebufferTexture2D(i.FRAMEBUFFER,we,re,W,0);else if(M.depthTexture.format===Yn)ct(M)?l.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,we,re,W,0,ge):i.framebufferTexture2D(i.FRAMEBUFFER,we,re,W,0);else throw new Error("Unknown depthTexture format")}function be(S){const M=n.get(S),U=S.isWebGLCubeRenderTarget===!0;if(M.__boundDepthTexture!==S.depthTexture){const X=S.depthTexture;if(M.__depthDisposeCallback&&M.__depthDisposeCallback(),X){const q=()=>{delete M.__boundDepthTexture,delete M.__depthDisposeCallback,X.removeEventListener("dispose",q)};X.addEventListener("dispose",q),M.__depthDisposeCallback=q}M.__boundDepthTexture=X}if(S.depthTexture&&!M.__autoAllocateDepthBuffer)if(U)for(let X=0;X<6;X++)ye(M.__webglFramebuffer[X],S,X);else{const X=S.texture.mipmaps;X&&X.length>0?ye(M.__webglFramebuffer[0],S,0):ye(M.__webglFramebuffer,S,0)}else if(U){M.__webglDepthbuffer=[];for(let X=0;X<6;X++)if(t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[X]),M.__webglDepthbuffer[X]===void 0)M.__webglDepthbuffer[X]=i.createRenderbuffer(),Pe(M.__webglDepthbuffer[X],S,!1);else{const q=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,W=M.__webglDepthbuffer[X];i.bindRenderbuffer(i.RENDERBUFFER,W),i.framebufferRenderbuffer(i.FRAMEBUFFER,q,i.RENDERBUFFER,W)}}else{const X=S.texture.mipmaps;if(X&&X.length>0?t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer===void 0)M.__webglDepthbuffer=i.createRenderbuffer(),Pe(M.__webglDepthbuffer,S,!1);else{const q=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,W=M.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,W),i.framebufferRenderbuffer(i.FRAMEBUFFER,q,i.RENDERBUFFER,W)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function mt(S,M,U){const X=n.get(S);M!==void 0&&se(X.__webglFramebuffer,S,S.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),U!==void 0&&be(S)}function ze(S){const M=S.texture,U=n.get(S),X=n.get(M);S.addEventListener("dispose",b);const q=S.textures,W=S.isWebGLCubeRenderTarget===!0,ge=q.length>1;if(ge||(X.__webglTexture===void 0&&(X.__webglTexture=i.createTexture()),X.__version=M.version,o.memory.textures++),W){U.__webglFramebuffer=[];for(let re=0;re<6;re++)if(M.mipmaps&&M.mipmaps.length>0){U.__webglFramebuffer[re]=[];for(let we=0;we<M.mipmaps.length;we++)U.__webglFramebuffer[re][we]=i.createFramebuffer()}else U.__webglFramebuffer[re]=i.createFramebuffer()}else{if(M.mipmaps&&M.mipmaps.length>0){U.__webglFramebuffer=[];for(let re=0;re<M.mipmaps.length;re++)U.__webglFramebuffer[re]=i.createFramebuffer()}else U.__webglFramebuffer=i.createFramebuffer();if(ge)for(let re=0,we=q.length;re<we;re++){const Te=n.get(q[re]);Te.__webglTexture===void 0&&(Te.__webglTexture=i.createTexture(),o.memory.textures++)}if(S.samples>0&&ct(S)===!1){U.__webglMultisampledFramebuffer=i.createFramebuffer(),U.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,U.__webglMultisampledFramebuffer);for(let re=0;re<q.length;re++){const we=q[re];U.__webglColorRenderbuffer[re]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,U.__webglColorRenderbuffer[re]);const Te=A.convert(we.format,we.colorSpace),$=A.convert(we.type),te=E(we.internalFormat,Te,$,we.colorSpace,S.isXRRenderTarget===!0),me=I(S);i.renderbufferStorageMultisample(i.RENDERBUFFER,me,te,S.width,S.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+re,i.RENDERBUFFER,U.__webglColorRenderbuffer[re])}i.bindRenderbuffer(i.RENDERBUFFER,null),S.depthBuffer&&(U.__webglDepthRenderbuffer=i.createRenderbuffer(),Pe(U.__webglDepthRenderbuffer,S,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(W){t.bindTexture(i.TEXTURE_CUBE_MAP,X.__webglTexture),ue(i.TEXTURE_CUBE_MAP,M);for(let re=0;re<6;re++)if(M.mipmaps&&M.mipmaps.length>0)for(let we=0;we<M.mipmaps.length;we++)se(U.__webglFramebuffer[re][we],S,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+re,we);else se(U.__webglFramebuffer[re],S,M,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+re,0);p(M)&&d(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ge){for(let re=0,we=q.length;re<we;re++){const Te=q[re],$=n.get(Te);let te=i.TEXTURE_2D;(S.isWebGL3DRenderTarget||S.isWebGLArrayRenderTarget)&&(te=S.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(te,$.__webglTexture),ue(te,Te),se(U.__webglFramebuffer,S,Te,i.COLOR_ATTACHMENT0+re,te,0),p(Te)&&d(te)}t.unbindTexture()}else{let re=i.TEXTURE_2D;if((S.isWebGL3DRenderTarget||S.isWebGLArrayRenderTarget)&&(re=S.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(re,X.__webglTexture),ue(re,M),M.mipmaps&&M.mipmaps.length>0)for(let we=0;we<M.mipmaps.length;we++)se(U.__webglFramebuffer[we],S,M,i.COLOR_ATTACHMENT0,re,we);else se(U.__webglFramebuffer,S,M,i.COLOR_ATTACHMENT0,re,0);p(M)&&d(re),t.unbindTexture()}S.depthBuffer&&be(S)}function Ke(S){const M=S.textures;for(let U=0,X=M.length;U<X;U++){const q=M[U];if(p(q)){const W=R(S),ge=n.get(q).__webglTexture;t.bindTexture(W,ge),d(W),t.unbindTexture()}}}const et=[],Le=[];function at(S){if(S.samples>0){if(ct(S)===!1){const M=S.textures,U=S.width,X=S.height;let q=i.COLOR_BUFFER_BIT;const W=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ge=n.get(S),re=M.length>1;if(re)for(let Te=0;Te<M.length;Te++)t.bindFramebuffer(i.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Te,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,ge.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Te,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,ge.__webglMultisampledFramebuffer);const we=S.texture.mipmaps;we&&we.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ge.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ge.__webglFramebuffer);for(let Te=0;Te<M.length;Te++){if(S.resolveDepthBuffer&&(S.depthBuffer&&(q|=i.DEPTH_BUFFER_BIT),S.stencilBuffer&&S.resolveStencilBuffer&&(q|=i.STENCIL_BUFFER_BIT)),re){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ge.__webglColorRenderbuffer[Te]);const $=n.get(M[Te]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,$,0)}i.blitFramebuffer(0,0,U,X,0,0,U,X,q,i.NEAREST),f===!0&&(et.length=0,Le.length=0,et.push(i.COLOR_ATTACHMENT0+Te),S.depthBuffer&&S.resolveDepthBuffer===!1&&(et.push(W),Le.push(W),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,Le)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,et))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),re)for(let Te=0;Te<M.length;Te++){t.bindFramebuffer(i.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Te,i.RENDERBUFFER,ge.__webglColorRenderbuffer[Te]);const $=n.get(M[Te]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,ge.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Te,i.TEXTURE_2D,$,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ge.__webglMultisampledFramebuffer)}else if(S.depthBuffer&&S.resolveDepthBuffer===!1&&f){const M=S.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[M])}}}function I(S){return Math.min(r.maxSamples,S.samples)}function ct(S){const M=n.get(S);return S.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function We(S){const M=o.render.frame;g.get(S)!==M&&(g.set(S,M),S.update())}function nt(S,M){const U=S.colorSpace,X=S.format,q=S.type;return S.isCompressedTexture===!0||S.isVideoTexture===!0||U!==ki&&U!==Dn&&(Ge.getTransfer(U)===Ze?(X!==Nt||q!==Ot)&&ke("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ve("WebGLTextures: Unsupported texture color space:",U)),M}function Ce(S){return typeof HTMLImageElement<"u"&&S instanceof HTMLImageElement?(c.width=S.naturalWidth||S.width,c.height=S.naturalHeight||S.height):typeof VideoFrame<"u"&&S instanceof VideoFrame?(c.width=S.displayWidth,c.height=S.displayHeight):(c.width=S.width,c.height=S.height),c}this.allocateTextureUnit=F,this.resetTextureUnits=B,this.setTexture2D=O,this.setTexture2DArray=Q,this.setTexture3D=D,this.setTextureCube=j,this.rebindTextures=mt,this.setupRenderTarget=ze,this.updateRenderTargetMipmap=Ke,this.updateMultisampleRenderTarget=at,this.setupDepthRenderbuffer=be,this.setupFrameBufferTexture=se,this.useMultisampledRTT=ct,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function Vm(i,e){function t(n,r=Dn){let A;const o=Ge.getTransfer(r);if(n===Ot)return i.UNSIGNED_BYTE;if(n===ua)return i.UNSIGNED_SHORT_4_4_4_4;if(n===fa)return i.UNSIGNED_SHORT_5_5_5_1;if(n===sc)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===ac)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===rc)return i.BYTE;if(n===Ac)return i.SHORT;if(n===ji)return i.UNSIGNED_SHORT;if(n===ca)return i.INT;if(n===sn)return i.UNSIGNED_INT;if(n===Wt)return i.FLOAT;if(n===Cn)return i.HALF_FLOAT;if(n===oc)return i.ALPHA;if(n===lc)return i.RGB;if(n===Nt)return i.RGBA;if(n===xn)return i.DEPTH_COMPONENT;if(n===Yn)return i.DEPTH_STENCIL;if(n===cc)return i.RED;if(n===da)return i.RED_INTEGER;if(n===Ii)return i.RG;if(n===ha)return i.RG_INTEGER;if(n===pa)return i.RGBA_INTEGER;if(n===Xr||n===Zr||n===qr||n===Yr)if(o===Ze)if(A=e.get("WEBGL_compressed_texture_s3tc_srgb"),A!==null){if(n===Xr)return A.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Zr)return A.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===qr)return A.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Yr)return A.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(A=e.get("WEBGL_compressed_texture_s3tc"),A!==null){if(n===Xr)return A.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Zr)return A.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===qr)return A.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Yr)return A.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Ss||n===ws||n===ys||n===Ts)if(A=e.get("WEBGL_compressed_texture_pvrtc"),A!==null){if(n===Ss)return A.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ws)return A.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===ys)return A.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Ts)return A.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===bs||n===Is||n===ks||n===Us||n===Ps||n===Ds||n===Os)if(A=e.get("WEBGL_compressed_texture_etc"),A!==null){if(n===bs||n===Is)return o===Ze?A.COMPRESSED_SRGB8_ETC2:A.COMPRESSED_RGB8_ETC2;if(n===ks)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:A.COMPRESSED_RGBA8_ETC2_EAC;if(n===Us)return A.COMPRESSED_R11_EAC;if(n===Ps)return A.COMPRESSED_SIGNED_R11_EAC;if(n===Ds)return A.COMPRESSED_RG11_EAC;if(n===Os)return A.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===Ns||n===Ls||n===Fs||n===Bs||n===Qs||n===zs||n===Gs||n===Hs||n===Vs||n===Ws||n===Ks||n===Xs||n===Zs||n===qs)if(A=e.get("WEBGL_compressed_texture_astc"),A!==null){if(n===Ns)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:A.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Ls)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:A.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Fs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:A.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Bs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:A.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Qs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:A.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===zs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:A.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Gs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:A.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Hs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:A.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Vs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:A.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ws)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:A.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Ks)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:A.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Xs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:A.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Zs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:A.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===qs)return o===Ze?A.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:A.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ys||n===Js||n===js)if(A=e.get("EXT_texture_compression_bptc"),A!==null){if(n===Ys)return o===Ze?A.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:A.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Js)return A.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===js)return A.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===$s||n===ea||n===ta||n===na)if(A=e.get("EXT_texture_compression_rgtc"),A!==null){if(n===$s)return A.COMPRESSED_RED_RGTC1_EXT;if(n===ea)return A.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ta)return A.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===na)return A.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===$i?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const Wm=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Km=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Xm{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new Cc(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Kt({vertexShader:Wm,fragmentShader:Km,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new an(new Ar(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Zm extends Pi{constructor(e,t){super();const n=this;let r=null,A=1,o=null,l="local-floor",f=1,c=null,g=null,s=null,a=null,u=null,h=null;const m=typeof XRWebGLBinding<"u",p=new Xm,d={},R=t.getContextAttributes();let E=null,v=null;const w=[],y=[],b=new Ye;let _=null;const x=new Ht;x.viewport=new lt;const K=new Ht;K.viewport=new lt;const T=[x,K],B=new sd;let F=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let ie=w[Z];return ie===void 0&&(ie=new OA,w[Z]=ie),ie.getTargetRaySpace()},this.getControllerGrip=function(Z){let ie=w[Z];return ie===void 0&&(ie=new OA,w[Z]=ie),ie.getGripSpace()},this.getHand=function(Z){let ie=w[Z];return ie===void 0&&(ie=new OA,w[Z]=ie),ie.getHandSpace()};function O(Z){const ie=y.indexOf(Z.inputSource);if(ie===-1)return;const se=w[ie];se!==void 0&&(se.update(Z.inputSource,Z.frame,c||o),se.dispatchEvent({type:Z.type,data:Z.inputSource}))}function Q(){r.removeEventListener("select",O),r.removeEventListener("selectstart",O),r.removeEventListener("selectend",O),r.removeEventListener("squeeze",O),r.removeEventListener("squeezestart",O),r.removeEventListener("squeezeend",O),r.removeEventListener("end",Q),r.removeEventListener("inputsourceschange",D);for(let Z=0;Z<w.length;Z++){const ie=y[Z];ie!==null&&(y[Z]=null,w[Z].disconnect(ie))}F=null,H=null,p.reset();for(const Z in d)delete d[Z];e.setRenderTarget(E),u=null,a=null,s=null,r=null,v=null,rt.stop(),n.isPresenting=!1,e.setPixelRatio(_),e.setSize(b.width,b.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){A=Z,n.isPresenting===!0&&ke("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){l=Z,n.isPresenting===!0&&ke("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return a!==null?a:u},this.getBinding=function(){return s===null&&m&&(s=new XRWebGLBinding(r,t)),s},this.getFrame=function(){return h},this.getSession=function(){return r},this.setSession=async function(Z){if(r=Z,r!==null){if(E=e.getRenderTarget(),r.addEventListener("select",O),r.addEventListener("selectstart",O),r.addEventListener("selectend",O),r.addEventListener("squeeze",O),r.addEventListener("squeezestart",O),r.addEventListener("squeezeend",O),r.addEventListener("end",Q),r.addEventListener("inputsourceschange",D),R.xrCompatible!==!0&&await t.makeXRCompatible(),_=e.getPixelRatio(),e.getSize(b),m&&"createProjectionLayer"in XRWebGLBinding.prototype){let se=null,Pe=null,ye=null;R.depth&&(ye=R.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,se=R.stencil?Yn:xn,Pe=R.stencil?$i:sn);const be={colorFormat:t.RGBA8,depthFormat:ye,scaleFactor:A};s=this.getBinding(),a=s.createProjectionLayer(be),r.updateRenderState({layers:[a]}),e.setPixelRatio(1),e.setSize(a.textureWidth,a.textureHeight,!1),v=new nn(a.textureWidth,a.textureHeight,{format:Nt,type:Ot,depthTexture:new er(a.textureWidth,a.textureHeight,Pe,void 0,void 0,void 0,void 0,void 0,void 0,se),stencilBuffer:R.stencil,colorSpace:e.outputColorSpace,samples:R.antialias?4:0,resolveDepthBuffer:a.ignoreDepthValues===!1,resolveStencilBuffer:a.ignoreDepthValues===!1})}else{const se={antialias:R.antialias,alpha:!0,depth:R.depth,stencil:R.stencil,framebufferScaleFactor:A};u=new XRWebGLLayer(r,t,se),r.updateRenderState({baseLayer:u}),e.setPixelRatio(1),e.setSize(u.framebufferWidth,u.framebufferHeight,!1),v=new nn(u.framebufferWidth,u.framebufferHeight,{format:Nt,type:Ot,colorSpace:e.outputColorSpace,stencilBuffer:R.stencil,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(f),c=null,o=await r.requestReferenceSpace(l),rt.setContext(r),rt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return p.getDepthTexture()};function D(Z){for(let ie=0;ie<Z.removed.length;ie++){const se=Z.removed[ie],Pe=y.indexOf(se);Pe>=0&&(y[Pe]=null,w[Pe].disconnect(se))}for(let ie=0;ie<Z.added.length;ie++){const se=Z.added[ie];let Pe=y.indexOf(se);if(Pe===-1){for(let be=0;be<w.length;be++)if(be>=y.length){y.push(se),Pe=be;break}else if(y[be]===null){y[be]=se,Pe=be;break}if(Pe===-1)break}const ye=w[Pe];ye&&ye.connect(se)}}const j=new z,J=new z;function ae(Z,ie,se){j.setFromMatrixPosition(ie.matrixWorld),J.setFromMatrixPosition(se.matrixWorld);const Pe=j.distanceTo(J),ye=ie.projectionMatrix.elements,be=se.projectionMatrix.elements,mt=ye[14]/(ye[10]-1),ze=ye[14]/(ye[10]+1),Ke=(ye[9]+1)/ye[5],et=(ye[9]-1)/ye[5],Le=(ye[8]-1)/ye[0],at=(be[8]+1)/be[0],I=mt*Le,ct=mt*at,We=Pe/(-Le+at),nt=We*-Le;if(ie.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(nt),Z.translateZ(We),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),ye[10]===-1)Z.projectionMatrix.copy(ie.projectionMatrix),Z.projectionMatrixInverse.copy(ie.projectionMatrixInverse);else{const Ce=mt+We,S=ze+We,M=I-nt,U=ct+(Pe-nt),X=Ke*ze/S*Ce,q=et*ze/S*Ce;Z.projectionMatrix.makePerspective(M,U,X,q,Ce,S),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function he(Z,ie){ie===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(ie.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(r===null)return;let ie=Z.near,se=Z.far;p.texture!==null&&(p.depthNear>0&&(ie=p.depthNear),p.depthFar>0&&(se=p.depthFar)),B.near=K.near=x.near=ie,B.far=K.far=x.far=se,(F!==B.near||H!==B.far)&&(r.updateRenderState({depthNear:B.near,depthFar:B.far}),F=B.near,H=B.far),B.layers.mask=Z.layers.mask|6,x.layers.mask=B.layers.mask&-5,K.layers.mask=B.layers.mask&-3;const Pe=Z.parent,ye=B.cameras;he(B,Pe);for(let be=0;be<ye.length;be++)he(ye[be],Pe);ye.length===2?ae(B,x,K):B.projectionMatrix.copy(x.projectionMatrix),ue(Z,B,Pe)};function ue(Z,ie,se){se===null?Z.matrix.copy(ie.matrixWorld):(Z.matrix.copy(se.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(ie.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(ie.projectionMatrix),Z.projectionMatrixInverse.copy(ie.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=ia*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return B},this.getFoveation=function(){if(!(a===null&&u===null))return f},this.setFoveation=function(Z){f=Z,a!==null&&(a.fixedFoveation=Z),u!==null&&u.fixedFoveation!==void 0&&(u.fixedFoveation=Z)},this.hasDepthSensing=function(){return p.texture!==null},this.getDepthSensingMesh=function(){return p.getMesh(B)},this.getCameraTexture=function(Z){return d[Z]};let Oe=null;function At(Z,ie){if(g=ie.getViewerPose(c||o),h=ie,g!==null){const se=g.views;u!==null&&(e.setRenderTargetFramebuffer(v,u.framebuffer),e.setRenderTarget(v));let Pe=!1;se.length!==B.cameras.length&&(B.cameras.length=0,Pe=!0);for(let ze=0;ze<se.length;ze++){const Ke=se[ze];let et=null;if(u!==null)et=u.getViewport(Ke);else{const at=s.getViewSubImage(a,Ke);et=at.viewport,ze===0&&(e.setRenderTargetTextures(v,at.colorTexture,at.depthStencilTexture),e.setRenderTarget(v))}let Le=T[ze];Le===void 0&&(Le=new Ht,Le.layers.enable(ze),Le.viewport=new lt,T[ze]=Le),Le.matrix.fromArray(Ke.transform.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale),Le.projectionMatrix.fromArray(Ke.projectionMatrix),Le.projectionMatrixInverse.copy(Le.projectionMatrix).invert(),Le.viewport.set(et.x,et.y,et.width,et.height),ze===0&&(B.matrix.copy(Le.matrix),B.matrix.decompose(B.position,B.quaternion,B.scale)),Pe===!0&&B.cameras.push(Le)}const ye=r.enabledFeatures;if(ye&&ye.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&m){s=n.getBinding();const ze=s.getDepthInformation(se[0]);ze&&ze.isValid&&ze.texture&&p.init(ze,r.renderState)}if(ye&&ye.includes("camera-access")&&m){e.state.unbindTexture(),s=n.getBinding();for(let ze=0;ze<se.length;ze++){const Ke=se[ze].camera;if(Ke){let et=d[Ke];et||(et=new Cc,d[Ke]=et);const Le=s.getCameraImage(Ke);et.sourceTexture=Le}}}}for(let se=0;se<w.length;se++){const Pe=y[se],ye=w[se];Pe!==null&&ye!==void 0&&ye.update(Pe,ie,c||o)}Oe&&Oe(Z,ie),ie.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:ie}),h=null}const rt=new vc;rt.setAnimationLoop(At),this.setAnimationLoop=function(Z){Oe=Z},this.dispose=function(){}}}const Wn=new En,qm=new dt;function Ym(i,e){function t(p,d){p.matrixAutoUpdate===!0&&p.updateMatrix(),d.value.copy(p.matrix)}function n(p,d){d.color.getRGB(p.fogColor.value,xc(i)),d.isFog?(p.fogNear.value=d.near,p.fogFar.value=d.far):d.isFogExp2&&(p.fogDensity.value=d.density)}function r(p,d,R,E,v){d.isMeshBasicMaterial?A(p,d):d.isMeshLambertMaterial?(A(p,d),d.envMap&&(p.envMapIntensity.value=d.envMapIntensity)):d.isMeshToonMaterial?(A(p,d),s(p,d)):d.isMeshPhongMaterial?(A(p,d),g(p,d),d.envMap&&(p.envMapIntensity.value=d.envMapIntensity)):d.isMeshStandardMaterial?(A(p,d),a(p,d),d.isMeshPhysicalMaterial&&u(p,d,v)):d.isMeshMatcapMaterial?(A(p,d),h(p,d)):d.isMeshDepthMaterial?A(p,d):d.isMeshDistanceMaterial?(A(p,d),m(p,d)):d.isMeshNormalMaterial?A(p,d):d.isLineBasicMaterial?(o(p,d),d.isLineDashedMaterial&&l(p,d)):d.isPointsMaterial?f(p,d,R,E):d.isSpriteMaterial?c(p,d):d.isShadowMaterial?(p.color.value.copy(d.color),p.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function A(p,d){p.opacity.value=d.opacity,d.color&&p.diffuse.value.copy(d.color),d.emissive&&p.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(p.map.value=d.map,t(d.map,p.mapTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,t(d.alphaMap,p.alphaMapTransform)),d.bumpMap&&(p.bumpMap.value=d.bumpMap,t(d.bumpMap,p.bumpMapTransform),p.bumpScale.value=d.bumpScale,d.side===Tt&&(p.bumpScale.value*=-1)),d.normalMap&&(p.normalMap.value=d.normalMap,t(d.normalMap,p.normalMapTransform),p.normalScale.value.copy(d.normalScale),d.side===Tt&&p.normalScale.value.negate()),d.displacementMap&&(p.displacementMap.value=d.displacementMap,t(d.displacementMap,p.displacementMapTransform),p.displacementScale.value=d.displacementScale,p.displacementBias.value=d.displacementBias),d.emissiveMap&&(p.emissiveMap.value=d.emissiveMap,t(d.emissiveMap,p.emissiveMapTransform)),d.specularMap&&(p.specularMap.value=d.specularMap,t(d.specularMap,p.specularMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest);const R=e.get(d),E=R.envMap,v=R.envMapRotation;E&&(p.envMap.value=E,Wn.copy(v),Wn.x*=-1,Wn.y*=-1,Wn.z*=-1,E.isCubeTexture&&E.isRenderTargetTexture===!1&&(Wn.y*=-1,Wn.z*=-1),p.envMapRotation.value.setFromMatrix4(qm.makeRotationFromEuler(Wn)),p.flipEnvMap.value=E.isCubeTexture&&E.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=d.reflectivity,p.ior.value=d.ior,p.refractionRatio.value=d.refractionRatio),d.lightMap&&(p.lightMap.value=d.lightMap,p.lightMapIntensity.value=d.lightMapIntensity,t(d.lightMap,p.lightMapTransform)),d.aoMap&&(p.aoMap.value=d.aoMap,p.aoMapIntensity.value=d.aoMapIntensity,t(d.aoMap,p.aoMapTransform))}function o(p,d){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,d.map&&(p.map.value=d.map,t(d.map,p.mapTransform))}function l(p,d){p.dashSize.value=d.dashSize,p.totalSize.value=d.dashSize+d.gapSize,p.scale.value=d.scale}function f(p,d,R,E){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,p.size.value=d.size*R,p.scale.value=E*.5,d.map&&(p.map.value=d.map,t(d.map,p.uvTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,t(d.alphaMap,p.alphaMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest)}function c(p,d){p.diffuse.value.copy(d.color),p.opacity.value=d.opacity,p.rotation.value=d.rotation,d.map&&(p.map.value=d.map,t(d.map,p.mapTransform)),d.alphaMap&&(p.alphaMap.value=d.alphaMap,t(d.alphaMap,p.alphaMapTransform)),d.alphaTest>0&&(p.alphaTest.value=d.alphaTest)}function g(p,d){p.specular.value.copy(d.specular),p.shininess.value=Math.max(d.shininess,1e-4)}function s(p,d){d.gradientMap&&(p.gradientMap.value=d.gradientMap)}function a(p,d){p.metalness.value=d.metalness,d.metalnessMap&&(p.metalnessMap.value=d.metalnessMap,t(d.metalnessMap,p.metalnessMapTransform)),p.roughness.value=d.roughness,d.roughnessMap&&(p.roughnessMap.value=d.roughnessMap,t(d.roughnessMap,p.roughnessMapTransform)),d.envMap&&(p.envMapIntensity.value=d.envMapIntensity)}function u(p,d,R){p.ior.value=d.ior,d.sheen>0&&(p.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),p.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(p.sheenColorMap.value=d.sheenColorMap,t(d.sheenColorMap,p.sheenColorMapTransform)),d.sheenRoughnessMap&&(p.sheenRoughnessMap.value=d.sheenRoughnessMap,t(d.sheenRoughnessMap,p.sheenRoughnessMapTransform))),d.clearcoat>0&&(p.clearcoat.value=d.clearcoat,p.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(p.clearcoatMap.value=d.clearcoatMap,t(d.clearcoatMap,p.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,t(d.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(p.clearcoatNormalMap.value=d.clearcoatNormalMap,t(d.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===Tt&&p.clearcoatNormalScale.value.negate())),d.dispersion>0&&(p.dispersion.value=d.dispersion),d.iridescence>0&&(p.iridescence.value=d.iridescence,p.iridescenceIOR.value=d.iridescenceIOR,p.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(p.iridescenceMap.value=d.iridescenceMap,t(d.iridescenceMap,p.iridescenceMapTransform)),d.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=d.iridescenceThicknessMap,t(d.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),d.transmission>0&&(p.transmission.value=d.transmission,p.transmissionSamplerMap.value=R.texture,p.transmissionSamplerSize.value.set(R.width,R.height),d.transmissionMap&&(p.transmissionMap.value=d.transmissionMap,t(d.transmissionMap,p.transmissionMapTransform)),p.thickness.value=d.thickness,d.thicknessMap&&(p.thicknessMap.value=d.thicknessMap,t(d.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=d.attenuationDistance,p.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(p.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(p.anisotropyMap.value=d.anisotropyMap,t(d.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=d.specularIntensity,p.specularColor.value.copy(d.specularColor),d.specularColorMap&&(p.specularColorMap.value=d.specularColorMap,t(d.specularColorMap,p.specularColorMapTransform)),d.specularIntensityMap&&(p.specularIntensityMap.value=d.specularIntensityMap,t(d.specularIntensityMap,p.specularIntensityMapTransform))}function h(p,d){d.matcap&&(p.matcap.value=d.matcap)}function m(p,d){const R=e.get(d).light;p.referencePosition.value.setFromMatrixPosition(R.matrixWorld),p.nearDistance.value=R.shadow.camera.near,p.farDistance.value=R.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function Jm(i,e,t,n){let r={},A={},o=[];const l=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function f(R,E){const v=E.program;n.uniformBlockBinding(R,v)}function c(R,E){let v=r[R.id];v===void 0&&(h(R),v=g(R),r[R.id]=v,R.addEventListener("dispose",p));const w=E.program;n.updateUBOMapping(R,w);const y=e.render.frame;A[R.id]!==y&&(a(R),A[R.id]=y)}function g(R){const E=s();R.__bindingPointIndex=E;const v=i.createBuffer(),w=R.__size,y=R.usage;return i.bindBuffer(i.UNIFORM_BUFFER,v),i.bufferData(i.UNIFORM_BUFFER,w,y),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,E,v),v}function s(){for(let R=0;R<l;R++)if(o.indexOf(R)===-1)return o.push(R),R;return Ve("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function a(R){const E=r[R.id],v=R.uniforms,w=R.__cache;i.bindBuffer(i.UNIFORM_BUFFER,E);for(let y=0,b=v.length;y<b;y++){const _=Array.isArray(v[y])?v[y]:[v[y]];for(let x=0,K=_.length;x<K;x++){const T=_[x];if(u(T,y,x,w)===!0){const B=T.__offset,F=Array.isArray(T.value)?T.value:[T.value];let H=0;for(let O=0;O<F.length;O++){const Q=F[O],D=m(Q);typeof Q=="number"||typeof Q=="boolean"?(T.__data[0]=Q,i.bufferSubData(i.UNIFORM_BUFFER,B+H,T.__data)):Q.isMatrix3?(T.__data[0]=Q.elements[0],T.__data[1]=Q.elements[1],T.__data[2]=Q.elements[2],T.__data[3]=0,T.__data[4]=Q.elements[3],T.__data[5]=Q.elements[4],T.__data[6]=Q.elements[5],T.__data[7]=0,T.__data[8]=Q.elements[6],T.__data[9]=Q.elements[7],T.__data[10]=Q.elements[8],T.__data[11]=0):(Q.toArray(T.__data,H),H+=D.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,B,T.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function u(R,E,v,w){const y=R.value,b=E+"_"+v;if(w[b]===void 0)return typeof y=="number"||typeof y=="boolean"?w[b]=y:w[b]=y.clone(),!0;{const _=w[b];if(typeof y=="number"||typeof y=="boolean"){if(_!==y)return w[b]=y,!0}else if(_.equals(y)===!1)return _.copy(y),!0}return!1}function h(R){const E=R.uniforms;let v=0;const w=16;for(let b=0,_=E.length;b<_;b++){const x=Array.isArray(E[b])?E[b]:[E[b]];for(let K=0,T=x.length;K<T;K++){const B=x[K],F=Array.isArray(B.value)?B.value:[B.value];for(let H=0,O=F.length;H<O;H++){const Q=F[H],D=m(Q),j=v%w,J=j%D.boundary,ae=j+J;v+=J,ae!==0&&w-ae<D.storage&&(v+=w-ae),B.__data=new Float32Array(D.storage/Float32Array.BYTES_PER_ELEMENT),B.__offset=v,v+=D.storage}}}const y=v%w;return y>0&&(v+=w-y),R.__size=v,R.__cache={},this}function m(R){const E={boundary:0,storage:0};return typeof R=="number"||typeof R=="boolean"?(E.boundary=4,E.storage=4):R.isVector2?(E.boundary=8,E.storage=8):R.isVector3||R.isColor?(E.boundary=16,E.storage=12):R.isVector4?(E.boundary=16,E.storage=16):R.isMatrix3?(E.boundary=48,E.storage=48):R.isMatrix4?(E.boundary=64,E.storage=64):R.isTexture?ke("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ke("WebGLRenderer: Unsupported uniform value type.",R),E}function p(R){const E=R.target;E.removeEventListener("dispose",p);const v=o.indexOf(E.__bindingPointIndex);o.splice(v,1),i.deleteBuffer(r[E.id]),delete r[E.id],delete A[E.id]}function d(){for(const R in r)i.deleteBuffer(r[R]);o=[],r={},A={}}return{bind:f,update:c,dispose:d}}const jm=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let qt=null;function $m(){return qt===null&&(qt=new Mc(jm,16,16,Ii,Cn),qt.name="DFG_LUT",qt.minFilter=vt,qt.magFilter=vt,qt.wrapS=mn,qt.wrapT=mn,qt.generateMipmaps=!1,qt.needsUpdate=!0),qt}class e0{constructor(e={}){const{canvas:t=vf(),context:n=null,depth:r=!0,stencil:A=!1,alpha:o=!1,antialias:l=!1,premultipliedAlpha:f=!0,preserveDrawingBuffer:c=!1,powerPreference:g="default",failIfMajorPerformanceCaveat:s=!1,reversedDepthBuffer:a=!1,outputBufferType:u=Ot}=e;this.isWebGLRenderer=!0;let h;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");h=n.getContextAttributes().alpha}else h=o;const m=u,p=new Set([pa,ha,da]),d=new Set([Ot,sn,ji,$i,ua,fa]),R=new Uint32Array(4),E=new Int32Array(4);let v=null,w=null;const y=[],b=[];let _=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=tn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const x=this;let K=!1;this._outputColorSpace=Dt;let T=0,B=0,F=null,H=-1,O=null;const Q=new lt,D=new lt;let j=null;const J=new $e(0);let ae=0,he=t.width,ue=t.height,Oe=1,At=null,rt=null;const Z=new lt(0,0,he,ue),ie=new lt(0,0,he,ue);let se=!1;const Pe=new Rc;let ye=!1,be=!1;const mt=new dt,ze=new z,Ke=new lt,et={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Le=!1;function at(){return F===null?Oe:1}let I=n;function ct(C,P){return t.getContext(C,P)}try{const C={alpha:!0,depth:r,stencil:A,antialias:l,premultipliedAlpha:f,preserveDrawingBuffer:c,powerPreference:g,failIfMajorPerformanceCaveat:s};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${la}`),t.addEventListener("webglcontextlost",Me,!1),t.addEventListener("webglcontextrestored",Ie,!1),t.addEventListener("webglcontextcreationerror",it,!1),I===null){const P="webgl2";if(I=ct(P,C),I===null)throw ct(P)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw Ve("WebGLRenderer: "+C.message),C}let We,nt,Ce,S,M,U,X,q,W,ge,re,we,Te,$,te,me,Re,fe,Fe,k,Ae,ne,pe;function ee(){We=new eg(I),We.init(),Ae=new Vm(I,We),nt=new Kp(I,We,e,Ae),Ce=new Gm(I,We),nt.reversedDepthBuffer&&a&&Ce.buffers.depth.setReversed(!0),S=new ig(I),M=new Tm,U=new Hm(I,We,Ce,M,nt,Ae,S),X=new $p(x),q=new od(I),ne=new Vp(I,q),W=new tg(I,q,S,ne),ge=new Ag(I,W,q,ne,S),fe=new rg(I,nt,U),te=new Xp(M),re=new ym(x,X,We,nt,ne,te),we=new Ym(x,M),Te=new Im,$=new Nm(We),Re=new Hp(x,X,Ce,ge,h,f),me=new zm(x,ge,nt),pe=new Jm(I,S,nt,Ce),Fe=new Wp(I,We,S),k=new ng(I,We,S),S.programs=re.programs,x.capabilities=nt,x.extensions=We,x.properties=M,x.renderLists=Te,x.shadowMap=me,x.state=Ce,x.info=S}ee(),m!==Ot&&(_=new ag(m,t.width,t.height,r,A));const V=new Zm(x,I);this.xr=V,this.getContext=function(){return I},this.getContextAttributes=function(){return I.getContextAttributes()},this.forceContextLoss=function(){const C=We.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=We.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Oe},this.setPixelRatio=function(C){C!==void 0&&(Oe=C,this.setSize(he,ue,!1))},this.getSize=function(C){return C.set(he,ue)},this.setSize=function(C,P,G=!0){if(V.isPresenting){ke("WebGLRenderer: Can't change size while VR device is presenting.");return}he=C,ue=P,t.width=Math.floor(C*Oe),t.height=Math.floor(P*Oe),G===!0&&(t.style.width=C+"px",t.style.height=P+"px"),_!==null&&_.setSize(t.width,t.height),this.setViewport(0,0,C,P)},this.getDrawingBufferSize=function(C){return C.set(he*Oe,ue*Oe).floor()},this.setDrawingBufferSize=function(C,P,G){he=C,ue=P,Oe=G,t.width=Math.floor(C*G),t.height=Math.floor(P*G),this.setViewport(0,0,C,P)},this.setEffects=function(C){if(m===Ot){console.error("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(C){for(let P=0;P<C.length;P++)if(C[P].isOutputPass===!0){console.warn("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}_.setEffects(C||[])},this.getCurrentViewport=function(C){return C.copy(Q)},this.getViewport=function(C){return C.copy(Z)},this.setViewport=function(C,P,G,L){C.isVector4?Z.set(C.x,C.y,C.z,C.w):Z.set(C,P,G,L),Ce.viewport(Q.copy(Z).multiplyScalar(Oe).round())},this.getScissor=function(C){return C.copy(ie)},this.setScissor=function(C,P,G,L){C.isVector4?ie.set(C.x,C.y,C.z,C.w):ie.set(C,P,G,L),Ce.scissor(D.copy(ie).multiplyScalar(Oe).round())},this.getScissorTest=function(){return se},this.setScissorTest=function(C){Ce.setScissorTest(se=C)},this.setOpaqueSort=function(C){At=C},this.setTransparentSort=function(C){rt=C},this.getClearColor=function(C){return C.copy(Re.getClearColor())},this.setClearColor=function(){Re.setClearColor(...arguments)},this.getClearAlpha=function(){return Re.getClearAlpha()},this.setClearAlpha=function(){Re.setClearAlpha(...arguments)},this.clear=function(C=!0,P=!0,G=!0){let L=0;if(C){let N=!1;if(F!==null){const le=F.texture.format;N=p.has(le)}if(N){const le=F.texture.type,de=d.has(le),ce=Re.getClearColor(),_e=Re.getClearAlpha(),Ee=ce.r,Ue=ce.g,Be=ce.b;de?(R[0]=Ee,R[1]=Ue,R[2]=Be,R[3]=_e,I.clearBufferuiv(I.COLOR,0,R)):(E[0]=Ee,E[1]=Ue,E[2]=Be,E[3]=_e,I.clearBufferiv(I.COLOR,0,E))}else L|=I.COLOR_BUFFER_BIT}P&&(L|=I.DEPTH_BUFFER_BIT),G&&(L|=I.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L!==0&&I.clear(L)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Me,!1),t.removeEventListener("webglcontextrestored",Ie,!1),t.removeEventListener("webglcontextcreationerror",it,!1),Re.dispose(),Te.dispose(),$.dispose(),M.dispose(),X.dispose(),ge.dispose(),ne.dispose(),pe.dispose(),re.dispose(),V.dispose(),V.removeEventListener("sessionstart",Na),V.removeEventListener("sessionend",La),Fn.stop()};function Me(C){C.preventDefault(),To("WebGLRenderer: Context Lost."),K=!0}function Ie(){To("WebGLRenderer: Context Restored."),K=!1;const C=S.autoReset,P=me.enabled,G=me.autoUpdate,L=me.needsUpdate,N=me.type;ee(),S.autoReset=C,me.enabled=P,me.autoUpdate=G,me.needsUpdate=L,me.type=N}function it(C){Ve("WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function Xe(C){const P=C.target;P.removeEventListener("dispose",Xe),on(P)}function on(C){ln(C),M.remove(C)}function ln(C){const P=M.get(C).programs;P!==void 0&&(P.forEach(function(G){re.releaseProgram(G)}),C.isShaderMaterial&&re.releaseShaderCache(C))}this.renderBufferDirect=function(C,P,G,L,N,le){P===null&&(P=et);const de=N.isMesh&&N.matrixWorld.determinant()<0,ce=Dc(C,P,G,L,N);Ce.setMaterial(L,de);let _e=G.index,Ee=1;if(L.wireframe===!0){if(_e=W.getWireframeAttribute(G),_e===void 0)return;Ee=2}const Ue=G.drawRange,Be=G.attributes.position;let ve=Ue.start*Ee,Je=(Ue.start+Ue.count)*Ee;le!==null&&(ve=Math.max(ve,le.start*Ee),Je=Math.min(Je,(le.start+le.count)*Ee)),_e!==null?(ve=Math.max(ve,0),Je=Math.min(Je,_e.count)):Be!=null&&(ve=Math.max(ve,0),Je=Math.min(Je,Be.count));const ot=Je-ve;if(ot<0||ot===1/0)return;ne.setup(N,L,ce,G,_e);let st,je=Fe;if(_e!==null&&(st=q.get(_e),je=k,je.setIndex(st)),N.isMesh)L.wireframe===!0?(Ce.setLineWidth(L.wireframeLinewidth*at()),je.setMode(I.LINES)):je.setMode(I.TRIANGLES);else if(N.isLine){let Ct=L.linewidth;Ct===void 0&&(Ct=1),Ce.setLineWidth(Ct*at()),N.isLineSegments?je.setMode(I.LINES):N.isLineLoop?je.setMode(I.LINE_LOOP):je.setMode(I.LINE_STRIP)}else N.isPoints?je.setMode(I.POINTS):N.isSprite&&je.setMode(I.TRIANGLES);if(N.isBatchedMesh)if(N._multiDrawInstances!==null)oA("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),je.renderMultiDrawInstances(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount,N._multiDrawInstances);else if(We.get("WEBGL_multi_draw"))je.renderMultiDraw(N._multiDrawStarts,N._multiDrawCounts,N._multiDrawCount);else{const Ct=N._multiDrawStarts,xe=N._multiDrawCounts,bt=N._multiDrawCount,He=_e?q.get(_e).bytesPerElement:1,Lt=M.get(L).currentProgram.getUniforms();for(let Xt=0;Xt<bt;Xt++)Lt.setValue(I,"_gl_DrawID",Xt),je.render(Ct[Xt]/He,xe[Xt])}else if(N.isInstancedMesh)je.renderInstances(ve,ot,N.count);else if(G.isInstancedBufferGeometry){const Ct=G._maxInstanceCount!==void 0?G._maxInstanceCount:1/0,xe=Math.min(G.instanceCount,Ct);je.renderInstances(ve,ot,xe)}else je.render(ve,ot)};function Oa(C,P,G){C.transparent===!0&&C.side===pn&&C.forceSinglePass===!1?(C.side=Tt,C.needsUpdate=!0,ar(C,P,G),C.side=Ln,C.needsUpdate=!0,ar(C,P,G),C.side=pn):ar(C,P,G)}this.compile=function(C,P,G=null){G===null&&(G=C),w=$.get(G),w.init(P),b.push(w),G.traverseVisible(function(N){N.isLight&&N.layers.test(P.layers)&&(w.pushLight(N),N.castShadow&&w.pushShadow(N))}),C!==G&&C.traverseVisible(function(N){N.isLight&&N.layers.test(P.layers)&&(w.pushLight(N),N.castShadow&&w.pushShadow(N))}),w.setupLights();const L=new Set;return C.traverse(function(N){if(!(N.isMesh||N.isPoints||N.isLine||N.isSprite))return;const le=N.material;if(le)if(Array.isArray(le))for(let de=0;de<le.length;de++){const ce=le[de];Oa(ce,G,N),L.add(ce)}else Oa(le,G,N),L.add(le)}),w=b.pop(),L},this.compileAsync=function(C,P,G=null){const L=this.compile(C,P,G);return new Promise(N=>{function le(){if(L.forEach(function(de){M.get(de).currentProgram.isReady()&&L.delete(de)}),L.size===0){N(C);return}setTimeout(le,10)}We.get("KHR_parallel_shader_compile")!==null?le():setTimeout(le,10)})};let pA=null;function Pc(C){pA&&pA(C)}function Na(){Fn.stop()}function La(){Fn.start()}const Fn=new vc;Fn.setAnimationLoop(Pc),typeof self<"u"&&Fn.setContext(self),this.setAnimationLoop=function(C){pA=C,V.setAnimationLoop(C),C===null?Fn.stop():Fn.start()},V.addEventListener("sessionstart",Na),V.addEventListener("sessionend",La),this.render=function(C,P){if(P!==void 0&&P.isCamera!==!0){Ve("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(K===!0)return;const G=V.enabled===!0&&V.isPresenting===!0,L=_!==null&&(F===null||G)&&_.begin(x,F);if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),P.parent===null&&P.matrixWorldAutoUpdate===!0&&P.updateMatrixWorld(),V.enabled===!0&&V.isPresenting===!0&&(_===null||_.isCompositing()===!1)&&(V.cameraAutoUpdate===!0&&V.updateCamera(P),P=V.getCamera()),C.isScene===!0&&C.onBeforeRender(x,C,P,F),w=$.get(C,b.length),w.init(P),b.push(w),mt.multiplyMatrices(P.projectionMatrix,P.matrixWorldInverse),Pe.setFromProjectionMatrix(mt,en,P.reversedDepth),be=this.localClippingEnabled,ye=te.init(this.clippingPlanes,be),v=Te.get(C,y.length),v.init(),y.push(v),V.enabled===!0&&V.isPresenting===!0){const de=x.xr.getDepthSensingMesh();de!==null&&gA(de,P,-1/0,x.sortObjects)}gA(C,P,0,x.sortObjects),v.finish(),x.sortObjects===!0&&v.sort(At,rt),Le=V.enabled===!1||V.isPresenting===!1||V.hasDepthSensing()===!1,Le&&Re.addToRenderList(v,C),this.info.render.frame++,ye===!0&&te.beginShadows();const N=w.state.shadowsArray;if(me.render(N,C,P),ye===!0&&te.endShadows(),this.info.autoReset===!0&&this.info.reset(),(L&&_.hasRenderPass())===!1){const de=v.opaque,ce=v.transmissive;if(w.setupLights(),P.isArrayCamera){const _e=P.cameras;if(ce.length>0)for(let Ee=0,Ue=_e.length;Ee<Ue;Ee++){const Be=_e[Ee];Ba(de,ce,C,Be)}Le&&Re.render(C);for(let Ee=0,Ue=_e.length;Ee<Ue;Ee++){const Be=_e[Ee];Fa(v,C,Be,Be.viewport)}}else ce.length>0&&Ba(de,ce,C,P),Le&&Re.render(C),Fa(v,C,P)}F!==null&&B===0&&(U.updateMultisampleRenderTarget(F),U.updateRenderTargetMipmap(F)),L&&_.end(x),C.isScene===!0&&C.onAfterRender(x,C,P),ne.resetDefaultState(),H=-1,O=null,b.pop(),b.length>0?(w=b[b.length-1],ye===!0&&te.setGlobalState(x.clippingPlanes,w.state.camera)):w=null,y.pop(),y.length>0?v=y[y.length-1]:v=null};function gA(C,P,G,L){if(C.visible===!1)return;if(C.layers.test(P.layers)){if(C.isGroup)G=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(P);else if(C.isLight)w.pushLight(C),C.castShadow&&w.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||Pe.intersectsSprite(C)){L&&Ke.setFromMatrixPosition(C.matrixWorld).applyMatrix4(mt);const de=ge.update(C),ce=C.material;ce.visible&&v.push(C,de,ce,G,Ke.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||Pe.intersectsObject(C))){const de=ge.update(C),ce=C.material;if(L&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Ke.copy(C.boundingSphere.center)):(de.boundingSphere===null&&de.computeBoundingSphere(),Ke.copy(de.boundingSphere.center)),Ke.applyMatrix4(C.matrixWorld).applyMatrix4(mt)),Array.isArray(ce)){const _e=de.groups;for(let Ee=0,Ue=_e.length;Ee<Ue;Ee++){const Be=_e[Ee],ve=ce[Be.materialIndex];ve&&ve.visible&&v.push(C,de,ve,G,Ke.z,Be)}}else ce.visible&&v.push(C,de,ce,G,Ke.z,null)}}const le=C.children;for(let de=0,ce=le.length;de<ce;de++)gA(le[de],P,G,L)}function Fa(C,P,G,L){const{opaque:N,transmissive:le,transparent:de}=C;w.setupLightsView(G),ye===!0&&te.setGlobalState(x.clippingPlanes,G),L&&Ce.viewport(Q.copy(L)),N.length>0&&sr(N,P,G),le.length>0&&sr(le,P,G),de.length>0&&sr(de,P,G),Ce.buffers.depth.setTest(!0),Ce.buffers.depth.setMask(!0),Ce.buffers.color.setMask(!0),Ce.setPolygonOffset(!1)}function Ba(C,P,G,L){if((G.isScene===!0?G.overrideMaterial:null)!==null)return;if(w.state.transmissionRenderTarget[L.id]===void 0){const ve=We.has("EXT_color_buffer_half_float")||We.has("EXT_color_buffer_float");w.state.transmissionRenderTarget[L.id]=new nn(1,1,{generateMipmaps:!0,type:ve?Cn:Ot,minFilter:qn,samples:Math.max(4,nt.samples),stencilBuffer:A,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ge.workingColorSpace})}const le=w.state.transmissionRenderTarget[L.id],de=L.viewport||Q;le.setSize(de.z*x.transmissionResolutionScale,de.w*x.transmissionResolutionScale);const ce=x.getRenderTarget(),_e=x.getActiveCubeFace(),Ee=x.getActiveMipmapLevel();x.setRenderTarget(le),x.getClearColor(J),ae=x.getClearAlpha(),ae<1&&x.setClearColor(16777215,.5),x.clear(),Le&&Re.render(G);const Ue=x.toneMapping;x.toneMapping=tn;const Be=L.viewport;if(L.viewport!==void 0&&(L.viewport=void 0),w.setupLightsView(L),ye===!0&&te.setGlobalState(x.clippingPlanes,L),sr(C,G,L),U.updateMultisampleRenderTarget(le),U.updateRenderTargetMipmap(le),We.has("WEBGL_multisampled_render_to_texture")===!1){let ve=!1;for(let Je=0,ot=P.length;Je<ot;Je++){const st=P[Je],{object:je,geometry:Ct,material:xe,group:bt}=st;if(xe.side===pn&&je.layers.test(L.layers)){const He=xe.side;xe.side=Tt,xe.needsUpdate=!0,Qa(je,G,L,Ct,xe,bt),xe.side=He,xe.needsUpdate=!0,ve=!0}}ve===!0&&(U.updateMultisampleRenderTarget(le),U.updateRenderTargetMipmap(le))}x.setRenderTarget(ce,_e,Ee),x.setClearColor(J,ae),Be!==void 0&&(L.viewport=Be),x.toneMapping=Ue}function sr(C,P,G){const L=P.isScene===!0?P.overrideMaterial:null;for(let N=0,le=C.length;N<le;N++){const de=C[N],{object:ce,geometry:_e,group:Ee}=de;let Ue=de.material;Ue.allowOverride===!0&&L!==null&&(Ue=L),ce.layers.test(G.layers)&&Qa(ce,P,G,_e,Ue,Ee)}}function Qa(C,P,G,L,N,le){C.onBeforeRender(x,P,G,L,N,le),C.modelViewMatrix.multiplyMatrices(G.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),N.onBeforeRender(x,P,G,L,C,le),N.transparent===!0&&N.side===pn&&N.forceSinglePass===!1?(N.side=Tt,N.needsUpdate=!0,x.renderBufferDirect(G,P,L,N,C,le),N.side=Ln,N.needsUpdate=!0,x.renderBufferDirect(G,P,L,N,C,le),N.side=pn):x.renderBufferDirect(G,P,L,N,C,le),C.onAfterRender(x,P,G,L,N,le)}function ar(C,P,G){P.isScene!==!0&&(P=et);const L=M.get(C),N=w.state.lights,le=w.state.shadowsArray,de=N.state.version,ce=re.getParameters(C,N.state,le,P,G),_e=re.getProgramCacheKey(ce);let Ee=L.programs;L.environment=C.isMeshStandardMaterial||C.isMeshLambertMaterial||C.isMeshPhongMaterial?P.environment:null,L.fog=P.fog;const Ue=C.isMeshStandardMaterial||C.isMeshLambertMaterial&&!C.envMap||C.isMeshPhongMaterial&&!C.envMap;L.envMap=X.get(C.envMap||L.environment,Ue),L.envMapRotation=L.environment!==null&&C.envMap===null?P.environmentRotation:C.envMapRotation,Ee===void 0&&(C.addEventListener("dispose",Xe),Ee=new Map,L.programs=Ee);let Be=Ee.get(_e);if(Be!==void 0){if(L.currentProgram===Be&&L.lightsStateVersion===de)return Ga(C,ce),Be}else ce.uniforms=re.getUniforms(C),C.onBeforeCompile(ce,x),Be=re.acquireProgram(ce,_e),Ee.set(_e,Be),L.uniforms=ce.uniforms;const ve=L.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(ve.clippingPlanes=te.uniform),Ga(C,ce),L.needsLights=Nc(C),L.lightsStateVersion=de,L.needsLights&&(ve.ambientLightColor.value=N.state.ambient,ve.lightProbe.value=N.state.probe,ve.directionalLights.value=N.state.directional,ve.directionalLightShadows.value=N.state.directionalShadow,ve.spotLights.value=N.state.spot,ve.spotLightShadows.value=N.state.spotShadow,ve.rectAreaLights.value=N.state.rectArea,ve.ltc_1.value=N.state.rectAreaLTC1,ve.ltc_2.value=N.state.rectAreaLTC2,ve.pointLights.value=N.state.point,ve.pointLightShadows.value=N.state.pointShadow,ve.hemisphereLights.value=N.state.hemi,ve.directionalShadowMatrix.value=N.state.directionalShadowMatrix,ve.spotLightMatrix.value=N.state.spotLightMatrix,ve.spotLightMap.value=N.state.spotLightMap,ve.pointShadowMatrix.value=N.state.pointShadowMatrix),L.currentProgram=Be,L.uniformsList=null,Be}function za(C){if(C.uniformsList===null){const P=C.currentProgram.getUniforms();C.uniformsList=Jr.seqWithValue(P.seq,C.uniforms)}return C.uniformsList}function Ga(C,P){const G=M.get(C);G.outputColorSpace=P.outputColorSpace,G.batching=P.batching,G.batchingColor=P.batchingColor,G.instancing=P.instancing,G.instancingColor=P.instancingColor,G.instancingMorph=P.instancingMorph,G.skinning=P.skinning,G.morphTargets=P.morphTargets,G.morphNormals=P.morphNormals,G.morphColors=P.morphColors,G.morphTargetsCount=P.morphTargetsCount,G.numClippingPlanes=P.numClippingPlanes,G.numIntersection=P.numClipIntersection,G.vertexAlphas=P.vertexAlphas,G.vertexTangents=P.vertexTangents,G.toneMapping=P.toneMapping}function Dc(C,P,G,L,N){P.isScene!==!0&&(P=et),U.resetTextureUnits();const le=P.fog,de=L.isMeshStandardMaterial||L.isMeshLambertMaterial||L.isMeshPhongMaterial?P.environment:null,ce=F===null?x.outputColorSpace:F.isXRRenderTarget===!0?F.texture.colorSpace:ki,_e=L.isMeshStandardMaterial||L.isMeshLambertMaterial&&!L.envMap||L.isMeshPhongMaterial&&!L.envMap,Ee=X.get(L.envMap||de,_e),Ue=L.vertexColors===!0&&!!G.attributes.color&&G.attributes.color.itemSize===4,Be=!!G.attributes.tangent&&(!!L.normalMap||L.anisotropy>0),ve=!!G.morphAttributes.position,Je=!!G.morphAttributes.normal,ot=!!G.morphAttributes.color;let st=tn;L.toneMapped&&(F===null||F.isXRRenderTarget===!0)&&(st=x.toneMapping);const je=G.morphAttributes.position||G.morphAttributes.normal||G.morphAttributes.color,Ct=je!==void 0?je.length:0,xe=M.get(L),bt=w.state.lights;if(ye===!0&&(be===!0||C!==O)){const Mt=C===O&&L.id===H;te.setState(L,C,Mt)}let He=!1;L.version===xe.__version?(xe.needsLights&&xe.lightsStateVersion!==bt.state.version||xe.outputColorSpace!==ce||N.isBatchedMesh&&xe.batching===!1||!N.isBatchedMesh&&xe.batching===!0||N.isBatchedMesh&&xe.batchingColor===!0&&N.colorTexture===null||N.isBatchedMesh&&xe.batchingColor===!1&&N.colorTexture!==null||N.isInstancedMesh&&xe.instancing===!1||!N.isInstancedMesh&&xe.instancing===!0||N.isSkinnedMesh&&xe.skinning===!1||!N.isSkinnedMesh&&xe.skinning===!0||N.isInstancedMesh&&xe.instancingColor===!0&&N.instanceColor===null||N.isInstancedMesh&&xe.instancingColor===!1&&N.instanceColor!==null||N.isInstancedMesh&&xe.instancingMorph===!0&&N.morphTexture===null||N.isInstancedMesh&&xe.instancingMorph===!1&&N.morphTexture!==null||xe.envMap!==Ee||L.fog===!0&&xe.fog!==le||xe.numClippingPlanes!==void 0&&(xe.numClippingPlanes!==te.numPlanes||xe.numIntersection!==te.numIntersection)||xe.vertexAlphas!==Ue||xe.vertexTangents!==Be||xe.morphTargets!==ve||xe.morphNormals!==Je||xe.morphColors!==ot||xe.toneMapping!==st||xe.morphTargetsCount!==Ct)&&(He=!0):(He=!0,xe.__version=L.version);let Lt=xe.currentProgram;He===!0&&(Lt=ar(L,P,N));let Xt=!1,Bn=!1,ni=!1;const tt=Lt.getUniforms(),_t=xe.uniforms;if(Ce.useProgram(Lt.program)&&(Xt=!0,Bn=!0,ni=!0),L.id!==H&&(H=L.id,Bn=!0),Xt||O!==C){Ce.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),tt.setValue(I,"projectionMatrix",C.projectionMatrix),tt.setValue(I,"viewMatrix",C.matrixWorldInverse);const wn=tt.map.cameraPosition;wn!==void 0&&wn.setValue(I,ze.setFromMatrixPosition(C.matrixWorld)),nt.logarithmicDepthBuffer&&tt.setValue(I,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(L.isMeshPhongMaterial||L.isMeshToonMaterial||L.isMeshLambertMaterial||L.isMeshBasicMaterial||L.isMeshStandardMaterial||L.isShaderMaterial)&&tt.setValue(I,"isOrthographic",C.isOrthographicCamera===!0),O!==C&&(O=C,Bn=!0,ni=!0)}if(xe.needsLights&&(bt.state.directionalShadowMap.length>0&&tt.setValue(I,"directionalShadowMap",bt.state.directionalShadowMap,U),bt.state.spotShadowMap.length>0&&tt.setValue(I,"spotShadowMap",bt.state.spotShadowMap,U),bt.state.pointShadowMap.length>0&&tt.setValue(I,"pointShadowMap",bt.state.pointShadowMap,U)),N.isSkinnedMesh){tt.setOptional(I,N,"bindMatrix"),tt.setOptional(I,N,"bindMatrixInverse");const Mt=N.skeleton;Mt&&(Mt.boneTexture===null&&Mt.computeBoneTexture(),tt.setValue(I,"boneTexture",Mt.boneTexture,U))}N.isBatchedMesh&&(tt.setOptional(I,N,"batchingTexture"),tt.setValue(I,"batchingTexture",N._matricesTexture,U),tt.setOptional(I,N,"batchingIdTexture"),tt.setValue(I,"batchingIdTexture",N._indirectTexture,U),tt.setOptional(I,N,"batchingColorTexture"),N._colorsTexture!==null&&tt.setValue(I,"batchingColorTexture",N._colorsTexture,U));const Sn=G.morphAttributes;if((Sn.position!==void 0||Sn.normal!==void 0||Sn.color!==void 0)&&fe.update(N,G,Lt),(Bn||xe.receiveShadow!==N.receiveShadow)&&(xe.receiveShadow=N.receiveShadow,tt.setValue(I,"receiveShadow",N.receiveShadow)),(L.isMeshStandardMaterial||L.isMeshLambertMaterial||L.isMeshPhongMaterial)&&L.envMap===null&&P.environment!==null&&(_t.envMapIntensity.value=P.environmentIntensity),_t.dfgLUT!==void 0&&(_t.dfgLUT.value=$m()),Bn&&(tt.setValue(I,"toneMappingExposure",x.toneMappingExposure),xe.needsLights&&Oc(_t,ni),le&&L.fog===!0&&we.refreshFogUniforms(_t,le),we.refreshMaterialUniforms(_t,L,Oe,ue,w.state.transmissionRenderTarget[C.id]),Jr.upload(I,za(xe),_t,U)),L.isShaderMaterial&&L.uniformsNeedUpdate===!0&&(Jr.upload(I,za(xe),_t,U),L.uniformsNeedUpdate=!1),L.isSpriteMaterial&&tt.setValue(I,"center",N.center),tt.setValue(I,"modelViewMatrix",N.modelViewMatrix),tt.setValue(I,"normalMatrix",N.normalMatrix),tt.setValue(I,"modelMatrix",N.matrixWorld),L.isShaderMaterial||L.isRawShaderMaterial){const Mt=L.uniformsGroups;for(let wn=0,ii=Mt.length;wn<ii;wn++){const Ha=Mt[wn];pe.update(Ha,Lt),pe.bind(Ha,Lt)}}return Lt}function Oc(C,P){C.ambientLightColor.needsUpdate=P,C.lightProbe.needsUpdate=P,C.directionalLights.needsUpdate=P,C.directionalLightShadows.needsUpdate=P,C.pointLights.needsUpdate=P,C.pointLightShadows.needsUpdate=P,C.spotLights.needsUpdate=P,C.spotLightShadows.needsUpdate=P,C.rectAreaLights.needsUpdate=P,C.hemisphereLights.needsUpdate=P}function Nc(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return T},this.getActiveMipmapLevel=function(){return B},this.getRenderTarget=function(){return F},this.setRenderTargetTextures=function(C,P,G){const L=M.get(C);L.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,L.__autoAllocateDepthBuffer===!1&&(L.__useRenderToTexture=!1),M.get(C.texture).__webglTexture=P,M.get(C.depthTexture).__webglTexture=L.__autoAllocateDepthBuffer?void 0:G,L.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,P){const G=M.get(C);G.__webglFramebuffer=P,G.__useDefaultFramebuffer=P===void 0};const Lc=I.createFramebuffer();this.setRenderTarget=function(C,P=0,G=0){F=C,T=P,B=G;let L=null,N=!1,le=!1;if(C){const ce=M.get(C);if(ce.__useDefaultFramebuffer!==void 0){Ce.bindFramebuffer(I.FRAMEBUFFER,ce.__webglFramebuffer),Q.copy(C.viewport),D.copy(C.scissor),j=C.scissorTest,Ce.viewport(Q),Ce.scissor(D),Ce.setScissorTest(j),H=-1;return}else if(ce.__webglFramebuffer===void 0)U.setupRenderTarget(C);else if(ce.__hasExternalTextures)U.rebindTextures(C,M.get(C.texture).__webglTexture,M.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const Ue=C.depthTexture;if(ce.__boundDepthTexture!==Ue){if(Ue!==null&&M.has(Ue)&&(C.width!==Ue.image.width||C.height!==Ue.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");U.setupDepthRenderbuffer(C)}}const _e=C.texture;(_e.isData3DTexture||_e.isDataArrayTexture||_e.isCompressedArrayTexture)&&(le=!0);const Ee=M.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Ee[P])?L=Ee[P][G]:L=Ee[P],N=!0):C.samples>0&&U.useMultisampledRTT(C)===!1?L=M.get(C).__webglMultisampledFramebuffer:Array.isArray(Ee)?L=Ee[G]:L=Ee,Q.copy(C.viewport),D.copy(C.scissor),j=C.scissorTest}else Q.copy(Z).multiplyScalar(Oe).floor(),D.copy(ie).multiplyScalar(Oe).floor(),j=se;if(G!==0&&(L=Lc),Ce.bindFramebuffer(I.FRAMEBUFFER,L)&&Ce.drawBuffers(C,L),Ce.viewport(Q),Ce.scissor(D),Ce.setScissorTest(j),N){const ce=M.get(C.texture);I.framebufferTexture2D(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_CUBE_MAP_POSITIVE_X+P,ce.__webglTexture,G)}else if(le){const ce=P;for(let _e=0;_e<C.textures.length;_e++){const Ee=M.get(C.textures[_e]);I.framebufferTextureLayer(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0+_e,Ee.__webglTexture,G,ce)}}else if(C!==null&&G!==0){const ce=M.get(C.texture);I.framebufferTexture2D(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,ce.__webglTexture,G)}H=-1},this.readRenderTargetPixels=function(C,P,G,L,N,le,de,ce=0){if(!(C&&C.isWebGLRenderTarget)){Ve("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let _e=M.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&de!==void 0&&(_e=_e[de]),_e){Ce.bindFramebuffer(I.FRAMEBUFFER,_e);try{const Ee=C.textures[ce],Ue=Ee.format,Be=Ee.type;if(C.textures.length>1&&I.readBuffer(I.COLOR_ATTACHMENT0+ce),!nt.textureFormatReadable(Ue)){Ve("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!nt.textureTypeReadable(Be)){Ve("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}P>=0&&P<=C.width-L&&G>=0&&G<=C.height-N&&I.readPixels(P,G,L,N,Ae.convert(Ue),Ae.convert(Be),le)}finally{const Ee=F!==null?M.get(F).__webglFramebuffer:null;Ce.bindFramebuffer(I.FRAMEBUFFER,Ee)}}},this.readRenderTargetPixelsAsync=async function(C,P,G,L,N,le,de,ce=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let _e=M.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&de!==void 0&&(_e=_e[de]),_e)if(P>=0&&P<=C.width-L&&G>=0&&G<=C.height-N){Ce.bindFramebuffer(I.FRAMEBUFFER,_e);const Ee=C.textures[ce],Ue=Ee.format,Be=Ee.type;if(C.textures.length>1&&I.readBuffer(I.COLOR_ATTACHMENT0+ce),!nt.textureFormatReadable(Ue))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!nt.textureTypeReadable(Be))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const ve=I.createBuffer();I.bindBuffer(I.PIXEL_PACK_BUFFER,ve),I.bufferData(I.PIXEL_PACK_BUFFER,le.byteLength,I.STREAM_READ),I.readPixels(P,G,L,N,Ae.convert(Ue),Ae.convert(Be),0);const Je=F!==null?M.get(F).__webglFramebuffer:null;Ce.bindFramebuffer(I.FRAMEBUFFER,Je);const ot=I.fenceSync(I.SYNC_GPU_COMMANDS_COMPLETE,0);return I.flush(),await Sf(I,ot,4),I.bindBuffer(I.PIXEL_PACK_BUFFER,ve),I.getBufferSubData(I.PIXEL_PACK_BUFFER,0,le),I.deleteBuffer(ve),I.deleteSync(ot),le}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,P=null,G=0){const L=Math.pow(2,-G),N=Math.floor(C.image.width*L),le=Math.floor(C.image.height*L),de=P!==null?P.x:0,ce=P!==null?P.y:0;U.setTexture2D(C,0),I.copyTexSubImage2D(I.TEXTURE_2D,G,0,0,de,ce,N,le),Ce.unbindTexture()};const Fc=I.createFramebuffer(),Bc=I.createFramebuffer();this.copyTextureToTexture=function(C,P,G=null,L=null,N=0,le=0){let de,ce,_e,Ee,Ue,Be,ve,Je,ot;const st=C.isCompressedTexture?C.mipmaps[le]:C.image;if(G!==null)de=G.max.x-G.min.x,ce=G.max.y-G.min.y,_e=G.isBox3?G.max.z-G.min.z:1,Ee=G.min.x,Ue=G.min.y,Be=G.isBox3?G.min.z:0;else{const _t=Math.pow(2,-N);de=Math.floor(st.width*_t),ce=Math.floor(st.height*_t),C.isDataArrayTexture?_e=st.depth:C.isData3DTexture?_e=Math.floor(st.depth*_t):_e=1,Ee=0,Ue=0,Be=0}L!==null?(ve=L.x,Je=L.y,ot=L.z):(ve=0,Je=0,ot=0);const je=Ae.convert(P.format),Ct=Ae.convert(P.type);let xe;P.isData3DTexture?(U.setTexture3D(P,0),xe=I.TEXTURE_3D):P.isDataArrayTexture||P.isCompressedArrayTexture?(U.setTexture2DArray(P,0),xe=I.TEXTURE_2D_ARRAY):(U.setTexture2D(P,0),xe=I.TEXTURE_2D),I.pixelStorei(I.UNPACK_FLIP_Y_WEBGL,P.flipY),I.pixelStorei(I.UNPACK_PREMULTIPLY_ALPHA_WEBGL,P.premultiplyAlpha),I.pixelStorei(I.UNPACK_ALIGNMENT,P.unpackAlignment);const bt=I.getParameter(I.UNPACK_ROW_LENGTH),He=I.getParameter(I.UNPACK_IMAGE_HEIGHT),Lt=I.getParameter(I.UNPACK_SKIP_PIXELS),Xt=I.getParameter(I.UNPACK_SKIP_ROWS),Bn=I.getParameter(I.UNPACK_SKIP_IMAGES);I.pixelStorei(I.UNPACK_ROW_LENGTH,st.width),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,st.height),I.pixelStorei(I.UNPACK_SKIP_PIXELS,Ee),I.pixelStorei(I.UNPACK_SKIP_ROWS,Ue),I.pixelStorei(I.UNPACK_SKIP_IMAGES,Be);const ni=C.isDataArrayTexture||C.isData3DTexture,tt=P.isDataArrayTexture||P.isData3DTexture;if(C.isDepthTexture){const _t=M.get(C),Sn=M.get(P),Mt=M.get(_t.__renderTarget),wn=M.get(Sn.__renderTarget);Ce.bindFramebuffer(I.READ_FRAMEBUFFER,Mt.__webglFramebuffer),Ce.bindFramebuffer(I.DRAW_FRAMEBUFFER,wn.__webglFramebuffer);for(let ii=0;ii<_e;ii++)ni&&(I.framebufferTextureLayer(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,M.get(C).__webglTexture,N,Be+ii),I.framebufferTextureLayer(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,M.get(P).__webglTexture,le,ot+ii)),I.blitFramebuffer(Ee,Ue,de,ce,ve,Je,de,ce,I.DEPTH_BUFFER_BIT,I.NEAREST);Ce.bindFramebuffer(I.READ_FRAMEBUFFER,null),Ce.bindFramebuffer(I.DRAW_FRAMEBUFFER,null)}else if(N!==0||C.isRenderTargetTexture||M.has(C)){const _t=M.get(C),Sn=M.get(P);Ce.bindFramebuffer(I.READ_FRAMEBUFFER,Fc),Ce.bindFramebuffer(I.DRAW_FRAMEBUFFER,Bc);for(let Mt=0;Mt<_e;Mt++)ni?I.framebufferTextureLayer(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,_t.__webglTexture,N,Be+Mt):I.framebufferTexture2D(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,_t.__webglTexture,N),tt?I.framebufferTextureLayer(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,Sn.__webglTexture,le,ot+Mt):I.framebufferTexture2D(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,Sn.__webglTexture,le),N!==0?I.blitFramebuffer(Ee,Ue,de,ce,ve,Je,de,ce,I.COLOR_BUFFER_BIT,I.NEAREST):tt?I.copyTexSubImage3D(xe,le,ve,Je,ot+Mt,Ee,Ue,de,ce):I.copyTexSubImage2D(xe,le,ve,Je,Ee,Ue,de,ce);Ce.bindFramebuffer(I.READ_FRAMEBUFFER,null),Ce.bindFramebuffer(I.DRAW_FRAMEBUFFER,null)}else tt?C.isDataTexture||C.isData3DTexture?I.texSubImage3D(xe,le,ve,Je,ot,de,ce,_e,je,Ct,st.data):P.isCompressedArrayTexture?I.compressedTexSubImage3D(xe,le,ve,Je,ot,de,ce,_e,je,st.data):I.texSubImage3D(xe,le,ve,Je,ot,de,ce,_e,je,Ct,st):C.isDataTexture?I.texSubImage2D(I.TEXTURE_2D,le,ve,Je,de,ce,je,Ct,st.data):C.isCompressedTexture?I.compressedTexSubImage2D(I.TEXTURE_2D,le,ve,Je,st.width,st.height,je,st.data):I.texSubImage2D(I.TEXTURE_2D,le,ve,Je,de,ce,je,Ct,st);I.pixelStorei(I.UNPACK_ROW_LENGTH,bt),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,He),I.pixelStorei(I.UNPACK_SKIP_PIXELS,Lt),I.pixelStorei(I.UNPACK_SKIP_ROWS,Xt),I.pixelStorei(I.UNPACK_SKIP_IMAGES,Bn),le===0&&P.generateMipmaps&&I.generateMipmap(xe),Ce.unbindTexture()},this.initRenderTarget=function(C){M.get(C).__webglFramebuffer===void 0&&U.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?U.setTextureCube(C,0):C.isData3DTexture?U.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?U.setTexture2DArray(C,0):U.setTexture2D(C,0),Ce.unbindTexture()},this.resetState=function(){T=0,B=0,F=null,Ce.reset(),ne.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return en}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=Ge._getDrawingBufferColorSpace(e),t.unpackColorSpace=Ge._getUnpackColorSpace()}}function sa(i,e){return i%=e,i<0&&(i+=e),i}class t0{}class n0 extends t0{constructor(){super(...arguments);Y(this,"ellipse",[0,0,1,1]);Y(this,"r2",[1,1]);Y(this,"edgeWidth",1);Y(this,"w",1);Y(this,"h",1)}resize(t,n){this.w=t,this.h=n;const r=Math.min(t,n);this.ellipse=[t/2,n/2,0,0],this.r2=[this.ellipse[2]**2,this.ellipse[3]**2],this.edgeWidth=r*.027}warpPoint(t,n){t=sa(t,this.w),n=sa(n,this.h);const[r,A,o,l]=this.ellipse,f=t-r,c=n-A,g=f*f/this.r2[0]+c*c/this.r2[1];if(g>1)return[t,n];let s=1-g;s=Math.sqrt(s)*s+s*(1-s);const a=s*this.edgeWidth,u=Math.atan2(c/l,f/o);return[r+(o-a)*Math.cos(u),A+(l-a)*Math.sin(u)]}}function i0(i){let e=1779033703,t=3144134277,n=1013904242,r=2773480762;for(let A=0;A<i.length;A++){const o=i.charCodeAt(A);e=t^Math.imul(e^o,597399067),t=n^Math.imul(t^o,2869860233),n=r^Math.imul(n^o,951274213),r=e^Math.imul(r^o,2716044179)}return e=Math.imul(n^e>>>18,597399067),t=Math.imul(r^t>>>22,2869860233),n=Math.imul(e^n>>>17,951274213),r=Math.imul(t^r>>>19,2716044179),[(e^t^n^r)>>>0,(t^e)>>>0,(n^e)>>>0,(r^e)>>>0]}function pl(i,e,t,n){return()=>{i>>>=0,e>>>=0,t>>>=0,n>>>=0;let r=i+e|0;return i=e^e>>>9,e=t+(t<<3)|0,t=t<<21|t>>>11,n=n+1|0,r=r+n|0,t=t+r|0,(r>>>0)/4294967296}}class r0{constructor(){Y(this,"seed",i0(Math.random().toString(36).slice(2)));Y(this,"next",pl(...this.seed))}reset(){this.next=pl(...this.seed)}value(){return this.next()}}const gl=1/5,Zi=1e3,A0=10,s0=.008,a0=5,ml=10,o0=.5,l0=.1,Ml=[5,0],c0=.2,Gr=221/255,u0=200/255,f0=1e3,rs=221/255,d0=`
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`,h0=`
  precision highp float;

  uniform vec2 uResolution;
  uniform sampler2D uPositions;
  uniform float uPositionsWidth;
  uniform int uCount;
  uniform float uRadius;
  uniform float uSmoothK;
  uniform vec3 uBgColor;
  uniform vec3 uBlobColor;

  varying vec2 vUv;

  // polynomial smooth minimum, blends two SDF distances into one continuous surface
  float smoothUnion(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
  }

  void main() {
    vec2 fragPos = vUv * uResolution;

    float d = 1.0e5;
    for (int i = 0; i < ${Zi}; i++) {
      if (i >= uCount) break;
      vec2 p = texture2D(uPositions, vec2((float(i) + 0.5) / uPositionsWidth, 0.5)).xy;
      float dist = length(fragPos - p) - uRadius;
      d = smoothUnion(d, dist, uSmoothK);
    }

    // float alpha = 1.0 - smoothstep(-1.5, 1.5, d);
    float alpha = 1.0 - step(0.0, d);
    gl_FragColor = vec4(mix(uBgColor, uBlobColor, alpha), 1.0);
  }
`;function p0(i,e,t){return[i[0]*(1-t)+e[0]*t,i[1]*(1-t)+e[1]*t]}function g0(i,e,t){return i*(1-t)+e*t}const vi=class vi{constructor(e){Y(this,"rng",new r0);Y(this,"warpSequence",Ol([new n0]));Y(this,"warpIndex",0);Y(this,"warp",this.warpSequence[0]);Y(this,"nextWarp",null);Y(this,"transitionR",1);Y(this,"particleCount",0);Y(this,"width",0);Y(this,"height",0);Y(this,"panPos",[0,0]);Y(this,"animAngle",0);Y(this,"renderer");Y(this,"scene");Y(this,"camera");Y(this,"material");Y(this,"positionsData",new Float32Array(Zi*4));Y(this,"positionsTexture");this.renderer=new e0({canvas:e,antialias:!1}),this.renderer.setPixelRatio(1),this.positionsTexture=new Mc(this.positionsData,Zi,1,Nt,Wt),this.positionsTexture.minFilter=ht,this.positionsTexture.magFilter=ht,this.material=new Kt({uniforms:{uResolution:{value:new Ye(1,1)},uPositions:{value:this.positionsTexture},uPositionsWidth:{value:Zi},uCount:{value:0},uRadius:{value:a0},uSmoothK:{value:ml},uBgColor:{value:new z(Gr,Gr,Gr)},uBlobColor:{value:new z(rs,rs,rs)}},vertexShader:d0,fragmentShader:h0}),this.scene=new zf,this.scene.add(new an(new Ar(2,2),this.material)),this.camera=new _a}nextWarpInSequence(){return this.warpIndex=(this.warpIndex+1)%this.warpSequence.length,this.warpSequence[this.warpIndex]}resize(e,t){this.width=e,this.height=t,this.particleCount=Math.round(Math.min(Zi,Math.max(A0,e*t*s0)));for(const n of this.warpSequence)n.resize(e,t);this.renderer.setSize(e,t,!1),this.material.uniforms.uResolution.value.set(e,t)}update(e,t,n){const r=Math.max(1,Math.round(t*gl)),A=Math.max(1,Math.round(n*gl));(r!==this.width||A!==this.height)&&this.resize(r,A),this.transitionR=Math.min(this.transitionR+o0*e,1),this.transitionR>=1&&Math.random()<l0*e&&(this.transitionR=0,this.nextWarp&&(this.warp=this.nextWarp),this.nextWarp=this.nextWarpInSequence()),this.animAngle=sa(this.animAngle+c0*e,Math.PI*2),this.panPos[0]+=Ml[0]*e,this.panPos[1]+=Ml[1]*e}render(){this.rng.reset();const e=ml,t=(this.width+2*e)/this.width,n=(this.height+2*e)/this.height;for(let o=0;o<this.particleCount;o++){const l=this.animAngle+this.rng.value()*Math.PI*2,f=this.rng.value()+.5,c=this.panPos[0]+this.rng.value()*this.width+f*Math.cos(l*Math.floor(this.rng.value()*10)),g=this.panPos[1]+this.rng.value()*this.height+f*Math.sin(l*Math.floor(this.rng.value()*10)),s=this.warp.warpPoint(c,g),a=this.nextWarp?p0(s,this.nextWarp.warpPoint(c,g),this.transitionR):s;this.positionsData[o*4]=a[0]*t-e,this.positionsData[o*4+1]=a[1]*n-e}this.positionsTexture.needsUpdate=!0,this.material.uniforms.uCount.value=this.particleCount,vi.firstRenderTime||(vi.firstRenderTime=performance.now());const r=Math.min(1,(performance.now()-vi.firstRenderTime)/f0),A=g0(Gr,u0,r);this.material.uniforms.uBgColor.value.set(A,A,A),this.renderer.render(this.scene,this.camera)}};Y(vi,"firstRenderTime",0);let lA=vi,_i,As,Rl;function _l(i){return new Promise((e,t)=>{const n=new Image;n.onload=()=>e(n),n.onerror=r=>t(r),n.src=i})}async function Cl(i){const r=document.createElement("canvas");r.width=100,r.height=200;const A=r.getContext("2d");A.imageSmoothingEnabled=!0;const o=await _l(`png/${i}-0.png`);A.drawImage(o,0,0,o.width,o.height,0,0,100,100);const l=await _l(`png/${i}-1.png`);return A.drawImage(l,0,0,l.width,l.height,0,100,100,100),{canvas:r,frameHeight:100,frameWidth:100,nFrames:2,frameIndex:0}}const Pa=class Pa extends ft{onOpen(){_i||(_i=tr("alex-morgan-organ-jazz-rainy-night-music-564284.ogg")),_i.loop(!0),_i.volume(.2),_i.play(),lA.firstRenderTime=performance.now()}onClose(){_i.stop()}elements(){return[{id:"mainMenuDebugBtn",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 50%;
          font-size: 90px;
          pointer-events: none;
        `,label:"MAIN MENU",variant:"label",onclick:()=>{}},{id:"startTutorialBtn",style:`
          width: 200px;
          height: 100px;
          top: 90%;
          left: 25%;
        `,onclick:e=>{e.switchToGui("tutorial-gui"),eA(),rA(e.activeSwingable.angle),e.activeSwingable.isPitchMeterFull=!1,gn("buttonClick")},label:"TUTORIAL"},{id:"trainingBtn",style:`
          width: 300px;
          height: 100px;
          top: 30%;
          left: 50%;
        `,onclick:e=>{e.switchToGui("training-menu")},label:"Training",filmstrip:Rl},{id:"freeplayBtn",style:`
          width: 600px;
          height: 200px;
          top: 50%;
          left: 50%;
        `,onclick:e=>{e.switchToGui("playing-gui"),eA(),rA(e.activeSwingable.angle),e.activeSwingable.isPitchMeterFull=!1,gn("buttonClick")},label:"Freeplay",filmstrip:As},{id:"expertModeBtn",style:`
          width: 300px;
          height: 100px;
          top: 70%;
          left: 50%;
        `,onclick:e=>{},label:"Expert Mode",filmstrip:As}]}};ft.register("main-menu",{factory:e=>new Pa(e),preload:async()=>{As=await Cl("balance"),Rl=await Cl("strike")}});let xl=Pa,Ci,El,vl;function Sl(i){return new Promise((e,t)=>{const n=new Image;n.onload=()=>e(n),n.onerror=r=>t(r),n.src=i})}async function wl(i){const r=document.createElement("canvas");r.width=100,r.height=200;const A=r.getContext("2d");A.imageSmoothingEnabled=!0;const o=await Sl(`png/${i}-0.png`);A.drawImage(o,0,0,o.width,o.height,0,0,100,100);const l=await Sl(`png/${i}-1.png`);return A.drawImage(l,0,0,l.width,l.height,0,100,100,100),{canvas:r,frameHeight:100,frameWidth:100,nFrames:2,frameIndex:0}}const Da=class Da extends ft{onOpen(){Ci||(Ci=tr("alex-morgan-organ-jazz-rainy-night-music-564284.ogg")),Ci.loop(!0),Ci.volume(.2),Ci.play()}onClose(){Ci.stop()}elements(){return[{id:"trainingMenuDebugBtn",style:`
          width: 100%;
          height: 200px;
          top: 10%;
          left: 50%;
          font-size: 90px;
          pointer-events: none;
        `,label:"Training MENU",variant:"label",onclick:()=>{}},{id:"strikeModeBtn",style:`
          width: 300px;
          height: 100px;
          top: 75%;
          left: 50%;
          font-size: 40px;
        `,onclick:e=>{},label:"Strike",filmstrip:vl},{id:"balanceModeBtn",style:`
          width: 300px;
          height: 100px;
          top: 50%;
          left: 50%;
          font-size: 40px;
        `,onclick:e=>{},label:"Balance",filmstrip:El},{id:"trainingBackBtn",style:`
          width: 50px;
          height: 50px;
          left: 25px;
          top: 25px;
        `,onclick:e=>{e.switchToGui("main-menu")},label:"BACK"}]}};ft.register("training-menu",{factory:e=>new Da(e),preload:async()=>{El=await wl("balance"),vl=await wl("strike")}});let yl=Da;const Ic=document.getElementById("ghost-canvas"),m0=Ic.getContext("2d"),kc=document.getElementById("app-canvas"),zt=kc.getContext("2d"),aa=document.getElementById("warp-canvas");let Se=null;window.addEventListener("touchstart",()=>{Se&&(Se.isTouchDevice=!0,console.log("TOUCH DEVICE"))});window.addEventListener("popstate",i=>{Se&&Se.switchToGui(i.state.q,!0)});window.addEventListener("resize",()=>Se==null?void 0:Se.resize());function M0(i){Se&&(Se.mousex=i.pageX*qe.dpr,Se.mousey=i.pageY*qe.dpr)}window.addEventListener("pointermove",M0);function R0(i){Se&&(Se.mousex=i.touches[0].pageX*qe.dpr,Se.mousey=i.touches[0].pageY*qe.dpr)}window.addEventListener("touchmove",R0);let Tl=performance.now();function _0(){return qe.targetRadius*1.1}function C0(i){const e=_0();return i.x<-e||i.x>qe.w+e||i.y<-e||i.y>qe.h+e}let Vi=null,Wi=0;const bl=new lA(aa);function Uc(i){if(requestAnimationFrame(Uc),!Se)return;const e=Math.min((i-Tl)/1e3,1/30);Tl=i;const t=ft.create(Se.currentGui,Se);if(t.updateFilmStrips(e,Se),t.updateIdleBounce(e,Se),t.updateAnimations(e,Se),zt.clearRect(0,0,qe.w,qe.h),Se.currentGui==="main-menu"?(aa.classList.remove("hidden"),bl.update(e,qe.w/qe.dpr,qe.h/qe.dpr),bl.render()):aa.classList.add("hidden"),Se.currentGui==="replay-gui"||Se.currentGui==="start-menu"){Wi+=Math.floor(e/Wr),Se.instantReplay.playbackEndFrame===-1&&(Se.instantReplay.playbackEndFrame=Se.instantReplay.replayLength),Wi>=Se.instantReplay.playbackEndFrame&&(Se.currentGui==="start-menu"&&Se.instantReplay.importReplay(),Wi=Se.instantReplay.playbackStartFrame),Se.instantReplay.restoreSnapshot(Se,Wi);const n=document.getElementById("replayProgressSlider");if(n){const r=`${Math.floor(100*Wi/Se.instantReplay.replayLength)}%`;n.style.left=r}for(const r of Se.targets){const A=qe.targetRadius;zt.fillStyle="#888",zt.lineWidth=A*.05,zt.beginPath(),zt.arc(r.x,r.y,A,0,2*Math.PI),zt.fill()}Se.activeSwingable.draw(zt,!1)}(Se.currentGui==="playing-gui"||Se.currentGui==="tutorial-gui")&&(Iu(e,Se),Se.targets=Se.targets.filter(n=>C0(n)?(n.hasBeenPowHit||(Se.powStreak=0),Vi=Se.nextTarget(),Se.activeSwingable.angle,!1):(n.draw(zt,!1),!0)),Se.activeSwingable.draw(zt,!1),Se.activeEffects=Se.activeEffects.filter(n=>n.draw(zt,e)),Gu(Se.activeSwingable.angle),Se.currentGui==="tutorial-gui"&&On&&$t.tutorialIndex===0&&Ji.advanceTutorial(Se),Se.activeSwingable.isPitchMeterFull=On||!cA,Vi&&On&&(Se.targets.push(Vi),Se.respawnTarget(Vi),Vi=null),zu(zt,75,qe.h-75,50,Se))}async function x0(){await Nl(),await ei.preloadAll(),await $n.preloadAll(),await ft.preloadAll(),await An.preloadAll(),Se=new Bu(kc,Ic,m0),Se.resize(),Se.instantReplay.importReplay(),requestAnimationFrame(Uc)}x0();
