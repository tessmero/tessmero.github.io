var $t=Object.defineProperty;var St=(r,t,e)=>t in r?$t(r,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):r[t]=e;var a=(r,t,e)=>St(r,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const n of s)if(n.type==="childList")for(const o of n.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&i(o)}).observe(document,{childList:!0,subtree:!0});function e(s){const n={};return s.integrity&&(n.integrity=s.integrity),s.referrerPolicy&&(n.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?n.credentials="include":s.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function i(s){if(s.ep)return;s.ep=!0;const n=e(s);fetch(s.href,n)}})();const Y="rgba(100, 180, 255, 1)";class m{constructor(){a(this,"flatConfig")}refreshConfig(){this.flatConfig=yt(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],i=e();return i.refreshConfig(),i}}a(m,"_registry",{});function yt(r,t={}){for(const[e,i]of Object.entries(r.children))"action"in i||("value"in i?t[e]=i.value:yt(i,t));return t}const Mt={children:{speedMultiplier:{value:1,min:1,max:10,step:1,onChange:()=>E.refreshConfig()}}},J=class J extends m{constructor(){super(...arguments);a(this,"tree",Mt)}};m.register("top-config",()=>new J);let it=J;const E=m.create("top-config"),P=5;function Ct(r,[t,e]){r.fillRect(t-P,e-P,2*P,2*P)}function F(r,t){const[e,i,s,n]=r,[o,l]=t;return o>=e&&o<e+s&&l>=i&&l<i+n}function st(r,t){const[e,i,s,n]=r,[o,l,h,d]=t;return e<o+h&&o<e+s&&i<l+d&&l<i+n}function Ft(r){return r[Math.floor(Math.random()*r.length)]}const rt=10;class Tt{constructor(t,e){a(this,"debugColor",`rgb(${I()},${I()},${I()})`);a(this,"parents",[]);a(this,"children",[]);a(this,"capacity");a(this,"particles",[]);a(this,"settledVolume",0);this.rect=t,this.rims=e,this.capacity=t[2]*t[3]}draw(t,e,i){this._drawActiveParticles(t),this._drawSettledParticles(t)}_drawActiveParticles(t){t.fillStyle=Y;for(const e of this.particles)Ct(t,[this.rect[0]+e[0],this.rect[1]+e[1]])}_drawSettledParticles(t){if(this.settledVolume===0)return;const[e,i,s,n]=this.rect,o=this.filledHeight,l=i+n-o;t.fillStyle=Y,t.fillRect(e,l,s,o+1)}registerParents(t){kt(this,t)}registerChildren(t){Rt(this,t)}get isFilled(){return this.settledVolume>=this.capacity}get isClosed(){return!!(this.parents.length===0||this.parents.every(t=>t.isFilled))}get filledHeight(){return Math.min(this.rect[3],this.settledVolume/this.rect[2])}get pressure(){if(this.isFilled){const t=this.children[0];return t?this.rect[3]+t.pressure:this.rect[3]}return this.filledHeight}leakOverLeftRim(t){t.looseParticles.push([this.rect[0]-5,this.rect[1]-1])}leakOverRightRim(t){t.looseParticles.push([this.rect[0]+this.rect[2]+3,this.rect[1]-1])}step(t){if(this.parents.length>0&&this.settledVolume>0){this.settledVolume-=rt;const e=Ft(this.parents);e.particles.push([e.rect[2]/2,e.rect[3]/2])}if(this.isFilled){for(const e of this.particles){if(this.children.length===0){this.rims==="both"?Math.random()>.5?this.leakOverLeftRim(t):this.leakOverRightRim(t):this.rims==="left"?this.leakOverLeftRim(t):this.rims==="right"&&this.leakOverRightRim(t);continue}let i,s=Number.MAX_VALUE;for(const n of this.children){const o=n.pressure;o<s&&(s=o,i=n)}if(i){const n=this.rect[0]+e[0];i.particles.push([Math.max(0,Math.min(i.rect[2],n-i.rect[0])),i.rect[1]-1])}}this.particles=[];return}for(const e of this.particles)e[1]++;if(this.isClosed){let e=this.rect[3]-this.filledHeight;this.particles=this.particles.filter(i=>i[1]>e?(this.settledVolume+=rt,e=this.rect[3]-this.filledHeight,!1):!0)}else this.particles=this.particles.filter(e=>{if(e[1]>this.rect[3]){const i=[this.rect[0]+e[0],this.rect[1]+this.rect[3]+1],s=this.parents.find(n=>!n.isFilled&&F(n.rect,i));if(s)s.particles.push([i[0]-s.rect[0],0]);else{const n=this.parents.find(o=>!o.isFilled);if(!n)throw new Error("non-filled basin has no non-filled parents (logically impossible)");n.particles.push([Math.max(0,Math.min(n.rect[2],i[0]-n.rect[0])),0])}return!1}return!0})}}function kt(r,t){const e=r.rect[1]+r.rect[3];for(const i of t)i!==r&&i.rect[1]===e&&Dt(r.rect,i.rect)&&r.parents.push(i)}function Rt(r,t){for(const e of t)e!==r&&e.parents.includes(r)&&r.children.push(e)}function Dt(r,t){const[e,,i]=r,[s,,n]=t,o=e,l=e+i,h=s,d=s+n;return o<d&&h<l}function I(){return Math.floor(100+100*Math.random())}const Pt={label:"Graphics",children:{}},U=class U extends m{constructor(){super(...arguments);a(this,"tree",Pt)}};m.register("gfx-config",()=>new U);let nt=U;const vt=m.create("gfx-config"),At={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:50,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:40,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const r of Object.values(At.children))r.onChange=t=>{_.refreshConfig(),t.onResize()};const Z=class Z extends m{constructor(){super(...arguments);a(this,"tree",At)}};m.register("layout-config",()=>new Z);let ot=Z;const _=m.create("layout-config");function lt(){V.refreshConfig()}const Ot={label:"Physics",children:{stepDelay:{value:3,min:3,max:1e4,step:1,onChange:lt},spawnDelay:{value:3,min:3,max:1e4,step:1,onChange:lt}}},Q=class Q extends m{constructor(){super(...arguments);a(this,"tree",Ot)}};m.register("physics-config",()=>new Q);let at=Q;const V=m.create("physics-config"),zt={label:"Level Zero",children:{}},q=class q extends m{constructor(){super(...arguments);a(this,"tree",zt)}};m.register("zero-config",()=>new q);let ht=q;const Vt=m.create("zero-config"),It={children:{...E.tree.children,...V.tree.children,graphics:vt.tree,layout:_.tree,zero:Vt.tree}},tt=class tt extends m{constructor(){super(...arguments);a(this,"tree",It)}};m.register("waterLevel-config",()=>new tt);let ct=tt;const Ht=m.create("waterLevel-config");function Bt(r,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",i=t.display.classes??[],s=i.filter(l=>l.startsWith("fa-")),n=i.filter(l=>!l.startsWith("fa-"));t.display.type!=="button"&&n.push("noselect");const o=Wt(`
    <${e} 
       id="${r}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${n.join(" ")}
        ">

      <span 
        class="${s.join(" ")}" 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[l,h]of Object.entries(t.display.styles??{}))o.style.setProperty(l,h);return t.id=r,t.htmlElem=o,o}function N(r){let t;typeof r=="string"?t=document.getElementById(r):t=r.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function W(r){let t;typeof r=="string"?t=document.getElementById(r):t=r.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function S(r,t){if(r.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:i}=r;i&&(i.innerHTML=`
    <span ${r.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function Yt(r,t){if(!t.display.draw)throw new Error("diagram gui element should define draw");const{htmlElem:e,rectangle:i}=t;if(!i||!e)return;if(e.tagName!=="CANVAS")throw new Error("diagram html element is not canvas");const n=e.getContext("2d");t.display.draw(n,r,i.map(o=>o*window.devicePixelRatio))}function Nt(r,t,e){if(!e){r.classList.add("hidden");return}r.style.opacity="";const[i,s,n,o]=e;r.style.display="",r.style.left=`${i}px`,r.style.top=`${s}px`,r.style.width=`${n}px`,r.style.height=`${o}px`;const l=r;l.width=n*window.devicePixelRatio,l.height=o*window.devicePixelRatio}function Wt(r){const t=document.createElement("div");return t.innerHTML=r.trim(),t.firstChild}class Xt{constructor(){a(this,"canvas");a(this,"ctx");a(this,"w");a(this,"h");a(this,"screenRectangle");a(this,"pxScreenRectangle")}handleResize(t){const e=window.devicePixelRatio;this.w=this.canvas.offsetWidth*e,this.h=this.canvas.offsetHeight*e,this.screenRectangle=[0,0,this.w,this.h],this.pxScreenRectangle=[0,0,this.canvas.offsetWidth,this.canvas.offsetHeight],this.canvas.width=this.w,this.canvas.height=this.h}init(t,e){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.handleResize(t)}}const Kt={"fa-faucet-drip":new Path2D(`
    
    M224 32c-17.7 0-32 14.3-32 32L96 64C78.3 64 64 78.3 64 96s14.3 32 32 32l96 0 0 
    64-18.7 0c-8.5 0-16.6 3.4-22.6 9.4L128 224 32 224c-17.7 0-32 14.3-32 32l0 64c0 
    17.7 14.3 32 32 32l100.1 0c20.2 29 53.9 48 91.9 48s71.7-19 91.9-48l36.1 0c17.7 
    0 32 14.3 32 32s14.3 32 32 32l64 0c17.7 0 32-14.3 32-32 0-88.4-71.6-160-160-160l-32 
    0-22.6-22.6c-6-6-14.1-9.4-22.6-9.4l-18.7 0 0-64 96 0c17.7 0 32-14.3 
    32-32s-14.3-32-32-32l-96 0c0-17.7-14.3-32-32-32zM436.8 455.4l-18.2 42.4c-1.8 
    4.1-2.7 8.6-2.7 13.1l0 1.2c0 17.7 14.3 32 32 
    32s32-14.3 32-32l0-1.2c0-4.5-.9-8.9-2.7-13.1l-18.2-42.4c-1.9-4.5-6.3-7.4-11.2-7.4s-9.2 2.9-11.2 7.4z
    
    
    `),"fa-rotate-left":new Path2D(`

    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 168.3C277.6
     109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 259.3 530.7 184.3 
     455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 412.9C98.8 422.4 94.4 
     442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 501C601 401 601 239 501
      139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 78.8 65.8C69.8 69.5 64 78.3 
      64 88L64 232C64 245.3 74.7 256 88 256z
  
  
      `),"fa-rotate-right":new Path2D(`

    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 168.3C362.4
     109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 380.7 530.7 455.7
      455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 421.7C536.7 431.8 540.2
       451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 139 501C39.1 401 39 239 139 
       139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 62.1 561.2 65.8C570.2 69.5 576 
       78.3 576 88L576 232C576 245.3 565.3 256 552 256z

  
      `),"fa-arrow-up":new Path2D(`


    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z

  
  
      `),left:new Path2D(`
    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 
    168.3C277.6 109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 
    259.3 530.7 184.3 455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 
    412.9C98.8 422.4 94.4 442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 
    501C601 401 601 239 501 139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 
    78.8 65.8C69.8 69.5 64 78.3 64 88L64 232C64 245.3 74.7 256 88 256z
  `),forward:new Path2D(`
    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z
  `),right:new Path2D(`
    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 
    168.3C362.4 109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 
    380.7 530.7 455.7 455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 
    421.7C536.7 431.8 540.2 451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 
    139 501C39.1 401 39 239 139 139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 
    62.1 561.2 65.8C570.2 69.5 576 78.3 576 88L576 232C576 245.3 565.3 256 552 256z
  `),"triangle-ex":new Path2D(`
        M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 
        550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 
        85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320
        480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 
        288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 
        257.7C352.5 239.5 338.1 224 319.8 224z
    `),"square-check":new Path2D(`
        M480 96C515.3 96 544 124.7 544 160L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 
        515.3 96 480L96 160C96 124.7 124.7 96 160 96L480 96zM438 209.7C427.3 201.9 412.3 204.3 404.5 
        215L285.1 379.2L233 327.1C223.6 317.7 208.4 317.7 199.1 327.1C189.8 336.5 189.7 351.7 199.1 
        361L271.1 433C276.1 438 283 440.5 289.9 440C296.8 439.5 303.3 435.9 307.4 430.2L443.3 243.2C451.1 
        232.5 448.7 217.5 438 209.7z
    `),"fa-gear":new Path2D(`

      M259.1 73.5C262.1 58.7 275.2 48 290.4 48L350.2 48C365.4 48 378.5 58.7 381.5 73.5L396 143.5C410.1
       149.5 423.3 157.2 435.3 166.3L503.1 143.8C517.5 139 533.3 145 540.9 158.2L570.8 210C578.4 223.2
        575.7 239.8 564.3 249.9L511 297.3C511.9 304.7 512.3 312.3 512.3 320C512.3 327.7 511.8 335.3 511
         342.7L564.4 390.2C575.8 400.3 578.4 417 570.9 430.1L541 481.9C533.4 495 517.6 501.1 503.2 
         496.3L435.4 473.8C423.3 482.9 410.1 490.5 396.1 496.6L381.7 566.5C378.6 581.4 365.5 592 350.4
          592L290.6 592C275.4 592 262.3 581.3 259.3 566.5L244.9 496.6C230.8 490.6 217.7 482.9 205.6
           473.8L137.5 496.3C123.1 501.1 107.3 495.1 99.7 481.9L69.8 430.1C62.2 416.9 64.9 400.3 76.3
            390.2L129.7 342.7C128.8 335.3 128.4 327.7 128.4 320C128.4 312.3 128.9 304.7 129.7 297.3L76.3
             249.8C64.9 239.7 62.3 223 69.8 209.9L99.7 158.1C107.3 144.9 123.1 138.9 137.5 143.7L205.3 
             166.2C217.4 157.1 230.6 149.5 244.6 143.4L259.1 73.5zM320.3 400C364.5 399.8 400.2 363.9 400
              319.7C399.8 275.5 363.9 239.8 319.7 240C275.5 240.2 239.8 276.1 240 320.3C240.2 364.5 276.1
               400.2 320.3 400z

      
    `),"fa-trash":new Path2D(`


      M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 
      160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 
      48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576
       197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z
      
    `),"fa-list-check":new Path2D(`

      M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 
      224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4
       106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 
       379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 
       95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 
       302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 
       192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576
        337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 
        448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 
        440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 
        440 128 440z

      
    `),"fa-x":new Path2D(`

      M504.6 148.5C515.9 134.9 514.1 114.7 500.5 103.4C486.9 92.1 466.7 93.9 455.4 107.5L320 270L184.6
       107.5C173.3 93.9 153.1 92.1 139.5 103.4C125.9 114.7 124.1 134.9 135.4 148.5L278.3 320L135.4
        491.5C124.1 505.1 125.9 525.3 139.5 536.6C153.1 547.9 173.3 546.1 184.6 532.5L320 370L455.4
         532.5C466.7 546.1 486.9 547.9 500.5 536.6C514.1 525.3 515.9 505.1 504.6 491.5L361.7 320L504.6 148.5z

      
    `),"fa-arrow-pointer":new Path2D(`


      M173.3 66.5C181.4 62.4 191.2 63.3 198.4 68.8L518.4 308.7C526.7 314.9 530 325.7 
      526.8 335.5C523.6 345.3 514.4 351.9 504 351.9L351.7 351.9L440.6 529.6C448.5
       545.4 442.1 564.6 426.3 572.5C410.5 580.4 391.3 574 383.4 558.2L294.5 380.5L203.2 
       502.3C197 510.6 186.2 513.9 176.4 510.7C166.6 507.5 160 498.3 160 488L160
        88C160 78.9 165.1 70.6 173.3 66.5z
      
    `)};function jt(r){r.isLandscape,r.isPortrait}function Gt(r){return Object.entries(r)}function Jt(r,t){return new X(r,t)._computedRects}const v=class v{constructor(t,e){a(this,"_computedRects",{});a(this,"isPortrait",!1);a(this,"isLandscape",!1);a(this,"parent");a(this,"_currentLayoutKey","");a(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const i=600;t[2]<i||t[3]<i?v.isSmall=!0:v.isSmall=!1,jt(this),this.parent=t;for(const[n,o]of Object.entries(e))this.parent=t,this._currentLayoutKey=n,this._computedRects[n]=this.computeRect(o);const s=this._childrenToParse;for(;Object.keys(s).length>0;){const n=Object.keys(s)[0],o=s[n];delete s[n];const l=this._computedRects[n],{_computedRects:h}=new v(l,o);for(const d in h)this._computedRects[`${n}.${d}`]=h[d]}}computeRect(t){let e=[...this.parent];for(const[i,s]of Gt(t))if(i==="parent"){if(!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);this.parent=this._computedRects[s],e=[...this.parent]}else if(i.startsWith("parent@")){const[n,o]=i.split("@");if(typeof s!="string"||!(s in this._computedRects))throw new Error(`layout parent '${s}' not defined by any previous rulesets`);if(o==="portrait")this.isPortrait&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(o==="landscape")this.isLandscape&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(o==="sm-portrait")this.isPortrait&&v.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else if(o==="sm-landscape")this.isLandscape&&v.isSmall&&(this.parent=this._computedRects[s],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else if(i==="children")this._childrenToParse[this._currentLayoutKey]=s;else if(i.includes("@")){const[n,o]=i.split("@");if(o==="portrait")this.isPortrait&&(e=this.applyRule(e,n,s));else if(o==="landscape")this.isLandscape&&(e=this.applyRule(e,n,s));else if(o==="sm-portrait")this.isPortrait&&v.isSmall&&(e=this.applyRule(e,n,s));else if(o==="sm-landscape")this.isLandscape&&v.isSmall&&(e=this.applyRule(e,n,s));else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else e=this.applyRule(e,i,s);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,i){const[s,n,o,l]=t,[h,d,f,w]=this.parent,b=(g,p)=>{if(typeof p=="function"&&(p=p()),typeof p=="string"&&p.endsWith("%")){const C=parseFloat(p)/100;return["left","right","width","margin"].includes(g)?f*C:w*C}else{if(p==="auto")return g==="width"?h+f-s:g==="height"?d+w-n:["left","right"].includes(g)?(f-o)/2:(w-l)/2;if(typeof p=="number"&&p<0){if(g==="width")return f+p;if(g==="height")return w+p}}return Number(p)},$=e.split("-");if($.length===2){const[g,p]=$;let C;if(g==="min")C=Math.max;else if(g==="max")C=Math.min;else throw new Error("only min- or max- prefixed allowed");if(p==="width")return[s,n,C(o,b("width",i)),l];if(p==="height")return[s,n,o,C(l,b("height",i))];if(p==="left")return[C(s,b("left",i)),n,o,l];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[h+b("left",i),n,o,l];case"right":return[h+f-o-b("right",i),n,o,l];case"top":return[s,d+b("top",i),o,l];case"bottom":return[s,d+w-l-b("bottom",i),o,l];case"width":return[s,n,b("width",i),l];case"height":return[s,n,o,b("height",i)];case"margin":{const g=b("margin",i);return[s+g,n+g,o-2*g,l-2*g]}default:return t}}};a(v,"isSmall",!1);let X=v;const dt={};let Ut=0;class x{constructor(){a(this,"guiLayout");a(this,"layoutRectangles",{});a(this,"elements",{});a(this,"layoutFactory")}init(t,e,i){this.layoutFactory=e;for(const s of i)if(typeof s.id=="string")this.elements[s.id]=s;else{const n=`_${Ut++}`;this.elements[n]=s;const o=Bt(n,s);o.onclick=l=>{l.preventDefault(),s.click&&s.click({elementId:n,waterLevel:t,pointerEvent:l})},o.onpointerdown=l=>{l.preventDefault(),s.down&&s.down({elementId:n,waterLevel:t,pointerEvent:l})},o.onpointermove=l=>{l.preventDefault(),s.move&&s.move({elementId:n,waterLevel:t,pointerEvent:l})},o.onpointerup=l=>{l.preventDefault(),s.up&&s.up({elementId:n,waterLevel:t,pointerEvent:l})},o.onpointerleave=l=>{l.preventDefault(),s.up&&s.up({elementId:n,waterLevel:t,pointerEvent:l})},o.style.display="none",document.body.appendChild(o),dt[n]=o,s.id=n}}refreshLayout(t){const{pxScreenRectangle:e}=t.layeredViewport;this.guiLayout=this.layoutFactory(t),this.layoutRectangles=Jt(e,this.guiLayout);for(const i in this.elements){const s=this.elements[i],n=this.layoutRectangles[s.layoutKey];s.rectangle=n,s.rectangle&&(s.dprRectangle=s.rectangle.map(o=>o*window.devicePixelRatio)),Nt(dt[i],s,n)}}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const i=this._registry[e];if(!i)throw new Error(`gui ${e} not registered `);const{factory:s,layoutFactory:n,elements:o}=i,l=s();this._preloaded[e]=l,l.init(t,n,o)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}a(x,"_registry",{}),a(x,"_preloaded",{});const Zt={screen:{},_outerMargin:{parent:"screen",margin:()=>_.flatConfig.outerMargin},topLabel:{parent:"_outerMargin",height:()=>_.flatConfig.buttonHeight},bottomLabel:{parent:"_outerMargin",height:()=>_.flatConfig.buttonHeight,left:0,bottom:0},nextLevelBtn:{parent:"_outerMargin",width:()=>_.flatConfig.buttonWidth,height:()=>_.flatConfig.buttonHeight,right:0,bottom:0}},T={layoutKey:"screen",display:{type:"diagram",draw:(r,t,e)=>{t.draw(r,e)}},down:({waterLevel:r,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,s=window.devicePixelRatio,n=[e*s,i*s];r.down(n)},up:({waterLevel:r,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,s=window.devicePixelRatio,n=[e*s,i*s];r.up(n)},move:({waterLevel:r,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,s=window.devicePixelRatio,n=[e*s,i*s];r.move(n)}},xt={layoutKey:"topLabel",display:{type:"panel",label:"WHICH TANK WILL FILL FIRST?",styles:{border:"none"}}},k={layoutKey:"bottomLabel",display:{type:"panel",label:'<span style="color:red">&nbsp;INCORRECT</span>',textAlign:"left",styles:{border:"none"}}},z={layoutKey:"nextLevelBtn",display:{type:"button",label:"NEXT",classes:["click-me"]},click:({waterLevel:r})=>{r.goToNextLevel()}},et=class et extends x{};x.register("zero-gui",{factory:()=>new et,layoutFactory:()=>Zt,elements:[xt,k,T,z]});let ut=et;class Qt extends x{constructor(){super(...arguments);a(this,"_isShowing",!1)}get isShowing(){return this._isShowing}toggle(e,i){typeof i=="boolean"?this._isShowing=i:this._isShowing=!this._isShowing;for(const s in this.elements)this._isShowing?(this.elements[s].display.classes??[]).includes("hidden")||W(s):N(s);this._isShowing&&this.refreshLayout(e),this.onToggle(e)}}const pt={NAMES:["zero-gui"]};function qt(r,t){return{bounds:M(r.bounds,t),spawn:[r.spawn[0]*t,r.spawn[1]*t],platforms:r.platforms.map(e=>M(e,t)),basins:r.basins.map(e=>({rims:e.rims,rect:M(e.rect,t)})),wrongTargets:r.wrongTargets.map(e=>M(e,t)),correctTarget:M(r.correctTarget,t)}}function M(r,t){return r.map(e=>e*t)}const ft=[{bounds:[0,0,200,200],platforms:[[39,76,1,42],[71,76,1,34],[81,76,1,34],[113,76,1,26],[118,91,15,1],[118,92,1,10],[132,92,1,10],[122,95,7,1],[122,96,1,10],[128,96,1,10],[137,97,1,5],[169,97,1,42],[114,101,4,1],[133,101,4,1],[113,105,9,1],[129,105,9,1],[113,106,1,12],[137,106,1,33],[72,109,9,1],[71,113,11,1],[71,114,1,4],[81,114,1,4],[40,117,31,1],[82,117,31,1],[138,138,31,1]],basins:[{rect:[114,91,4,10],rims:"right"},{rect:[133,97,4,4],rims:"right"},{rect:[72,76,9,33],rims:"both"},{rect:[40,113,31,4],rims:"right"},{rect:[82,113,31,4],rims:"left"},{rect:[138,105,31,33],rims:"left"},{rect:[129,102,40,3],rims:"neither"},{rect:[40,110,73,3],rims:"neither"},{rect:[129,95,3,7],rims:"left"},{rect:[138,97,31,5],rims:"both"},{rect:[40,76,31,34],rims:"both"},{rect:[82,105,31,5],rims:"right"},{rect:[82,102,40,3],rims:"neither"},{rect:[82,76,31,26],rims:"both"},{rect:[119,95,3,7],rims:"right"},{rect:[119,92,13,3],rims:"neither"}],spawn:[98,60.5],wrongTargets:[[40,76,31,41],[82,76,31,41]],correctTarget:[138,97,31,41]},{bounds:[0,0,200,200],platforms:[[151,38,1,34],[183,38,1,42],[107,58,1,34],[139,58,1,4],[140,61,8,1],[147,62,1,10],[139,65,5,1],[139,66,1,34],[143,66,1,10],[148,71,3,1],[144,75,8,1],[151,76,1,4],[63,78,1,34],[95,78,1,4],[152,79,31,1],[96,81,8,1],[103,82,1,10],[95,85,5,1],[95,86,1,34],[99,86,1,10],[104,91,3,1],[100,95,8,1],[107,96,1,4],[19,98,1,42],[51,98,1,4],[108,99,31,1],[52,101,8,1],[59,102,1,10],[51,105,5,1],[51,106,1,27],[55,106,1,10],[60,111,3,1],[151,111,1,42],[183,111,1,42],[56,115,8,1],[63,116,1,4],[64,119,31,1],[52,132,69,1],[120,133,1,39],[51,136,66,1],[51,137,1,3],[116,137,1,39],[20,139,31,1],[152,152,25,1],[180,152,3,1],[176,153,1,19],[180,153,1,23],[121,171,55,1],[117,175,63,1]],basins:[{rect:[148,61,3,10],rims:"left"},{rect:[152,75,31,4],rims:"left"},{rect:[104,81,3,10],rims:"left"},{rect:[108,95,31,4],rims:"left"},{rect:[60,101,3,10],rims:"left"},{rect:[64,115,31,4],rims:"left"},{rect:[20,136,31,3],rims:"right"},{rect:[121,153,55,18],rims:"neither"},{rect:[117,172,63,3],rims:"neither"},{rect:[140,58,11,3],rims:"left"},{rect:[144,72,39,3],rims:"neither"},{rect:[96,78,11,3],rims:"left"},{rect:[100,92,39,3],rims:"neither"},{rect:[52,98,11,3],rims:"left"},{rect:[56,112,39,3],rims:"neither"},{rect:[121,132,30,21],rims:"left"},{rect:[117,136,3,36],rims:"left"},{rect:[177,152,3,20],rims:"both"},{rect:[144,65,3,7],rims:"left"},{rect:[152,38,31,34],rims:"both"},{rect:[100,85,3,7],rims:"left"},{rect:[108,65,31,27],rims:"right"},{rect:[56,105,3,7],rims:"left"},{rect:[64,85,31,27],rims:"right"},{rect:[52,120,99,12],rims:"neither"},{rect:[20,133,100,3],rims:"neither"},{rect:[152,111,31,41],rims:"both"},{rect:[108,62,39,3],rims:"neither"},{rect:[64,82,39,3],rims:"neither"},{rect:[52,116,11,4],rims:"neither"},{rect:[96,111,55,9],rims:"right"},{rect:[20,105,31,28],rims:"right"},{rect:[108,58,31,4],rims:"both"},{rect:[64,78,31,4],rims:"both"},{rect:[20,102,39,3],rims:"neither"},{rect:[52,106,3,10],rims:"neither"},{rect:[20,98,31,4],rims:"both"}],spawn:[168,22.5],wrongTargets:[[152,38,31,41],[108,58,31,41],[64,78,31,41],[20,98,31,41]],correctTarget:[152,111,31,41]},{bounds:[0,0,200,200],platforms:[[83,42,1,42],[115,42,1,42],[139,80,1,33],[171,80,1,42],[84,83,25,1],[112,83,3,1],[108,84,1,29],[112,84,1,29],[67,93,1,29],[99,93,1,20],[100,112,8,1],[113,112,26,1],[99,116,10,1],[112,116,28,1],[99,117,1,5],[108,117,1,44],[112,117,1,40],[139,117,1,5],[68,121,31,1],[140,121,31,1],[46,128,1,42],[78,128,1,42],[139,149,1,42],[171,149,1,42],[113,156,26,1],[109,160,30,1],[47,169,31,1],[140,190,31,1]],basins:[{rect:[100,93,8,19],rims:"left"},{rect:[113,84,26,28],rims:"neither"},{rect:[68,116,31,5],rims:"right"},{rect:[140,116,31,5],rims:"left"},{rect:[113,149,26,7],rims:"right"},{rect:[109,157,30,3],rims:"neither"},{rect:[47,128,31,41],rims:"both"},{rect:[140,149,31,41],rims:"both"},{rect:[116,80,23,4],rims:"right"},{rect:[109,116,3,41],rims:"both"},{rect:[68,113,103,3],rims:"neither"},{rect:[68,93,31,20],rims:"both"},{rect:[109,83,3,30],rims:"both"},{rect:[140,80,31,33],rims:"both"},{rect:[84,42,31,41],rims:"both"}],spawn:[100,26.5],wrongTargets:[[84,42,31,41],[140,80,31,41],[140,149,31,41]],correctTarget:[47,128,31,41]},{bounds:[0,0,200,200],platforms:[[118,67,15,1],[118,68,1,34],[132,68,1,34],[122,71,7,1],[122,72,1,34],[128,72,1,34],[81,76,1,34],[113,76,1,26],[39,81,1,42],[71,81,1,29],[137,97,1,5],[169,97,1,42],[114,101,4,1],[133,101,4,1],[113,105,9,1],[129,105,9,1],[113,106,1,12],[137,106,1,33],[72,109,9,1],[71,113,11,1],[71,114,1,9],[81,114,1,4],[82,117,31,1],[40,122,31,1],[138,138,31,1]],basins:[{rect:[114,76,4,25],rims:"left"},{rect:[133,97,4,4],rims:"right"},{rect:[72,81,9,28],rims:"left"},{rect:[82,113,31,4],rims:"left"},{rect:[40,113,31,9],rims:"right"},{rect:[138,105,31,33],rims:"left"},{rect:[129,102,40,3],rims:"neither"},{rect:[40,110,73,3],rims:"neither"},{rect:[129,71,3,31],rims:"left"},{rect:[138,97,31,5],rims:"both"},{rect:[40,81,31,29],rims:"both"},{rect:[82,105,31,5],rims:"right"},{rect:[82,102,40,3],rims:"neither"},{rect:[82,76,31,26],rims:"both"},{rect:[119,71,3,31],rims:"right"},{rect:[119,68,13,3],rims:"neither"}],spawn:[98,60.5],wrongTargets:[[82,76,31,41],[138,97,31,41]],correctTarget:[40,81,31,41]},{bounds:[0,0,200,200],platforms:[[81,38,1,22],[113,38,1,22],[82,59,31,1],[58,68,1,22],[90,68,1,22],[105,68,1,22],[137,68,1,22],[59,89,31,1],[106,89,31,1],[81,101,1,42],[113,101,1,42],[124,111,1,34],[156,111,1,42],[37,113,1,42],[69,113,1,42],[82,142,31,1],[117,144,7,1],[117,145,1,13],[121,148,4,1],[121,149,1,13],[124,149,1,4],[125,152,31,1],[38,154,31,1],[81,154,1,42],[113,154,1,4],[114,157,3,1],[113,161,8,1],[113,162,1,34],[82,195,31,1]],basins:[{rect:[82,38,31,21],rims:"both"},{rect:[59,68,31,21],rims:"both"},{rect:[106,68,31,21],rims:"both"},{rect:[82,101,31,41],rims:"both"},{rect:[125,148,31,4],rims:"left"},{rect:[38,113,31,41],rims:"both"},{rect:[114,154,3,3],rims:"left"},{rect:[82,161,31,34],rims:"right"},{rect:[82,158,39,3],rims:"neither"},{rect:[82,154,31,4],rims:"both"},{rect:[118,148,3,10],rims:"right"},{rect:[118,145,38,3],rims:"neither"},{rect:[125,111,31,34],rims:"both"}],spawn:[98,24.5],wrongTargets:[[125,111,31,41],[38,113,31,41],[82,154,31,41]],correctTarget:[82,101,31,41]},{bounds:[0,0,200,200],platforms:[[72,55,1,5],[122,55,1,5],[73,59,49,1],[119,71,1,13],[143,71,1,13],[51,75,1,5],[75,75,1,5],[52,79,23,1],[120,83,23,1],[38,92,1,5],[54,92,1,5],[72,92,1,5],[88,92,1,5],[106,92,1,13],[122,92,1,13],[140,92,1,13],[156,92,1,13],[39,96,15,1],[73,96,15,1],[107,104,15,1],[141,104,15,1],[31,121,1,12],[44,121,1,12],[48,121,1,21],[61,121,1,21],[65,121,1,34],[78,121,1,34],[82,121,1,42],[95,121,1,42],[99,121,1,42],[112,121,1,42],[116,121,1,34],[129,121,1,34],[133,121,1,21],[146,121,1,21],[150,121,1,12],[163,121,1,12],[32,132,12,1],[151,132,12,1],[49,141,12,1],[134,141,12,1],[66,154,12,1],[117,154,12,1],[83,162,12,1],[100,162,12,1]],basins:[{rect:[73,55,49,4],rims:"both"},{rect:[52,75,23,4],rims:"both"},{rect:[120,71,23,12],rims:"both"},{rect:[39,92,15,4],rims:"both"},{rect:[73,92,15,4],rims:"both"},{rect:[107,92,15,12],rims:"both"},{rect:[141,92,15,12],rims:"both"},{rect:[32,121,12,11],rims:"both"},{rect:[151,121,12,11],rims:"both"},{rect:[49,121,12,20],rims:"both"},{rect:[134,121,12,20],rims:"both"},{rect:[66,121,12,33],rims:"both"},{rect:[117,121,12,33],rims:"both"},{rect:[83,121,12,41],rims:"both"},{rect:[100,121,12,41],rims:"both"}],spawn:[98,24.5],wrongTargets:[[49,121,12,20],[66,121,12,33],[83,121,12,41],[100,121,12,41],[117,121,12,33],[134,121,12,20],[151,121,12,11]],correctTarget:[32,121,12,11]}];/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class A{constructor(t,e,i,s,n="div"){this.parent=t,this.object=e,this.property=i,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(n),this.domElement.classList.add("controller"),this.domElement.classList.add(s),this.$name=document.createElement("div"),this.$name.classList.add("name"),A.nextNameID=A.nextNameID||0,this.$name.id=`lil-gui-name-${++A.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",o=>o.stopPropagation()),this.domElement.addEventListener("keyup",o=>o.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(i)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class te extends A{constructor(t,e,i){super(t,e,i,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function K(r){let t,e;return(t=r.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=r.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=r.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const ee={isPrimitive:!0,match:r=>typeof r=="string",fromHexString:K,toHexString:K},R={isPrimitive:!0,match:r=>typeof r=="number",fromHexString:r=>parseInt(r.substring(1),16),toHexString:r=>"#"+r.toString(16).padStart(6,0)},ie={isPrimitive:!1,match:r=>Array.isArray(r),fromHexString(r,t,e=1){const i=R.fromHexString(r);t[0]=(i>>16&255)/255*e,t[1]=(i>>8&255)/255*e,t[2]=(i&255)/255*e},toHexString([r,t,e],i=1){i=255/i;const s=r*i<<16^t*i<<8^e*i<<0;return R.toHexString(s)}},se={isPrimitive:!1,match:r=>Object(r)===r,fromHexString(r,t,e=1){const i=R.fromHexString(r);t.r=(i>>16&255)/255*e,t.g=(i>>8&255)/255*e,t.b=(i&255)/255*e},toHexString({r,g:t,b:e},i=1){i=255/i;const s=r*i<<16^t*i<<8^e*i<<0;return R.toHexString(s)}},re=[ee,R,ie,se];function ne(r){return re.find(t=>t.match(r))}class oe extends A{constructor(t,e,i,s){super(t,e,i,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=ne(this.initialValue),this._rgbScale=s,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const n=K(this.$text.value);n&&this._setValueFromHexString(n)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class H extends A{constructor(t,e,i){super(t,e,i,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",s=>{s.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class le extends A{constructor(t,e,i,s,n,o){super(t,e,i,"number"),this._initInput(),this.min(s),this.max(n);const l=o!==void 0;this.step(l?o:this._getImplicitStep(),l),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let c=parseFloat(this.$input.value);isNaN(c)||(this._stepExplicit&&(c=this._snap(c)),this.setValue(this._clamp(c)))},i=c=>{const y=parseFloat(this.$input.value);isNaN(y)||(this._snapClampSetValue(y+c),this.$input.value=this.getValue())},s=c=>{c.key==="Enter"&&this.$input.blur(),c.code==="ArrowUp"&&(c.preventDefault(),i(this._step*this._arrowKeyMultiplier(c))),c.code==="ArrowDown"&&(c.preventDefault(),i(this._step*this._arrowKeyMultiplier(c)*-1))},n=c=>{this._inputFocused&&(c.preventDefault(),i(this._step*this._normalizeMouseWheel(c)))};let o=!1,l,h,d,f,w;const b=5,$=c=>{l=c.clientX,h=d=c.clientY,o=!0,f=this.getValue(),w=0,window.addEventListener("mousemove",g),window.addEventListener("mouseup",p)},g=c=>{if(o){const y=c.clientX-l,D=c.clientY-h;Math.abs(D)>b?(c.preventDefault(),this.$input.blur(),o=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(y)>b&&p()}if(!o){const y=c.clientY-d;w-=y*this._step*this._arrowKeyMultiplier(c),f+w>this._max?w=this._max-f:f+w<this._min&&(w=this._min-f),this._snapClampSetValue(f+w)}d=c.clientY},p=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",p)},C=()=>{this._inputFocused=!0},u=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",s),this.$input.addEventListener("wheel",n,{passive:!1}),this.$input.addEventListener("mousedown",$),this.$input.addEventListener("focus",C),this.$input.addEventListener("blur",u)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(u,c,y,D,Et)=>(u-c)/(y-c)*(Et-D)+D,e=u=>{const c=this.$slider.getBoundingClientRect();let y=t(u,c.left,c.right,this._min,this._max);this._snapClampSetValue(y)},i=u=>{this._setDraggingStyle(!0),e(u.clientX),window.addEventListener("mousemove",s),window.addEventListener("mouseup",n)},s=u=>{e(u.clientX)},n=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",s),window.removeEventListener("mouseup",n)};let o=!1,l,h;const d=u=>{u.preventDefault(),this._setDraggingStyle(!0),e(u.touches[0].clientX),o=!1},f=u=>{u.touches.length>1||(this._hasScrollBar?(l=u.touches[0].clientX,h=u.touches[0].clientY,o=!0):d(u),window.addEventListener("touchmove",w,{passive:!1}),window.addEventListener("touchend",b))},w=u=>{if(o){const c=u.touches[0].clientX-l,y=u.touches[0].clientY-h;Math.abs(c)>Math.abs(y)?d(u):(window.removeEventListener("touchmove",w),window.removeEventListener("touchend",b))}else u.preventDefault(),e(u.touches[0].clientX)},b=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",w),window.removeEventListener("touchend",b)},$=this._callOnFinishChange.bind(this),g=400;let p;const C=u=>{if(Math.abs(u.deltaX)<Math.abs(u.deltaY)&&this._hasScrollBar)return;u.preventDefault();const y=this._normalizeMouseWheel(u)*this._step;this._snapClampSetValue(this.getValue()+y),this.$input.value=this.getValue(),clearTimeout(p),p=setTimeout($,g)};this.$slider.addEventListener("mousedown",i),this.$slider.addEventListener("touchstart",f,{passive:!1}),this.$slider.addEventListener("wheel",C,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:i}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,i=-t.wheelDelta/120,i*=this._stepExplicit?1:10),e+-i}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class ae extends A{constructor(t,e,i,s){super(t,e,i,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(s)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const i=document.createElement("option");i.textContent=e,this.$select.appendChild(i)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class he extends A{constructor(t,e,i){super(t,e,i,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",s=>{s.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var ce=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function de(r){const t=document.createElement("style");t.innerHTML=r;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let gt=!1;class G{constructor({parent:t,autoPlace:e=t===void 0,container:i,width:s,title:n="Controls",closeFolders:o=!1,injectStyles:l=!0,touchStyles:h=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(n),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),h&&this.domElement.classList.add("allow-touch-styles"),!gt&&l&&(de(ce),gt=!0),i?i.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),s&&this.domElement.style.setProperty("--width",s+"px"),this._closeFolders=o}add(t,e,i,s,n){if(Object(i)===i)return new ae(this,t,e,i);const o=t[e];switch(typeof o){case"number":return new le(this,t,e,i,s,n);case"boolean":return new te(this,t,e);case"string":return new he(this,t,e);case"function":return new H(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,o)}addColor(t,e,i=1){return new oe(this,t,e,i)}addFolder(t){const e=new G({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(i=>{i instanceof H||i._name in t.controllers&&i.load(t.controllers[i._name])}),e&&t.folders&&this.folders.forEach(i=>{i._title in t.folders&&i.load(t.folders[i._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(i=>{if(!(i instanceof H)){if(i._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${i._name}"`);e.controllers[i._name]=i.save()}}),t&&this.folders.forEach(i=>{if(i._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${i._title}"`);e.folders[i._title]=i.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const i=n=>{n.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",i))};this.$children.addEventListener("transitionend",i);const s=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=s+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(i=>i.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let j={},L;function ue(r){const t=Ht.tree;j={},L&&L.destroy(),L=new G({closeFolders:!0,container:document.getElementById("controls-container")}),Lt(L,t,r),L.onOpenClose(()=>{L._closed&&setTimeout(()=>{L.destroy()},200)})}function Lt(r,t,e){const i=t.children;for(const s in i){const n=i[s];if(!("isHidden"in n&&n.isHidden))if("action"in n){const o=n,l=n.label??O(s),h={[l]:async()=>{await o.action(e)}};r.add(h,l)}else if("options"in n&&Array.isArray(n.options)){const o=n,l={};for(const d of o.options)typeof d=="string"&&(l[d]=d);const h=r.add(o,"value",l).name(o.label??O(s)).listen();h.onChange(d=>{o.value=d,o.onChange&&o.onChange(e,d)}),B(h,o.tooltip),j[s]=h}else if("value"in n&&typeof n.value=="number"){const o=n,l=r.add(o,"value",o.min,o.max).name(o.label??O(s));o.step&&l.step(o.step),l.onChange(h=>{typeof h=="number"&&(o.value=h,o.onChange&&o.onChange(e,h))}),B(l,o.tooltip),j[s]=l}else{const o=r.addFolder(n.label??O(s));B(o,n.tooltip),Lt(o,n,e)}}}function B(r,t){if(typeof t!="string"||t.trim()==="")return;r.domElement.setAttribute("title",t)}function O(r){return/^[A-Z0-9_]+$/.test(r)?r.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():r.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}const _t="ABCDEFGHIJKLMNOPQRSTUVWXYZ";function mt([r,t,e,i]){return[r+e/2-50/2,t+i/2-50/2,50,50]}let wt=!1,bt=!1;class pe{constructor(t){a(this,"layeredViewport");a(this,"gui");a(this,"levelIndex",0);a(this,"level");a(this,"spawn",[0,0]);a(this,"basins",[]);a(this,"targets",[]);a(this,"selectedTarget");a(this,"bottomY",0);a(this,"isFinished",!1);a(this,"isFreeplay",!1);a(this,"looseParticles",[]);a(this,"interludeCountdown",0);a(this,"spawnCountdown",0);a(this,"stepCountdown",0);a(this,"hoveredTarget");a(this,"drawOffset",[0,0]);a(this,"mousePos");a(this,"isMouseDown",!1);a(this,"didBuildControls",!1);if(this.defaultLayeredViewport=t,this.layeredViewport=t,wt)throw new Error("WaterLevel constructed multiple times");wt=!0;for(const e of pt.NAMES)x.preload(this,e)}init(){if(bt)throw new Error("WaterLevel initialized multiple times");bt=!0;for(const t of pt.NAMES){const e=x.create(t);e instanceof Qt&&e.toggle(this,!1)}this.gui=x.create("zero-gui"),this.initLevel(),window.addEventListener("resize",()=>this.onResize())}initLevel(){this.selectedTarget=void 0,this.isFinished=!1,this.isFreeplay=!1,this.looseParticles=[],this.level=qt(ft[this.levelIndex],3),this.spawn=[...this.level.spawn],this.basins=this.level.basins.map(({rect:i,rims:s})=>new Tt(i,s));for(const i of this.basins)i.registerParents(this.basins);for(const i of this.basins)i.registerChildren(this.basins);this.targets=[];for(const i of this.level.wrongTargets)this.targets.push({rect:i,basins:this.basins.filter(s=>st(s.rect,i)),isCorrect:!1,hasFilled:!1,displayRect:mt(i)});this.targets.push({rect:this.level.correctTarget,basins:this.basins.filter(i=>st(i.rect,this.level.correctTarget)),isCorrect:!0,hasFilled:!1,displayRect:mt(this.level.correctTarget)});function t([i,s]){return i*1e6+s}this.targets.sort((i,s)=>t(i.rect)-t(s.rect));let e=0;for(const i of this.basins)e=Math.max(e,i.rect[1]+i.rect[3]);this.bottomY=e}spawnParticle(t){const e=this.basins.find(i=>F(i.rect,t));if(e){const i=[t[0]-e.rect[0],t[1]-e.rect[1]];e.particles.push(i)}else this.looseParticles.push([...t])}step(){for(const t of this.basins)t.step(this);this.looseParticles=this.looseParticles.filter(t=>{if(t[1]++,t[1]>this.bottomY)return!1;const e=this.basins.find(i=>F(i.rect,t));if(e){const i=[t[0]-e.rect[0],t[1]-e.rect[1]];return e.particles.push(i),!1}return!0})}update(t){if(this.selectedTarget){const e=E.flatConfig.speedMultiplier;if(!this.isFinished||this.isFreeplay)for(this.spawnCountdown-=t;this.spawnCountdown<0;){for(let i=0;i<e;i++)this.spawnParticle(this.spawn);this.spawnCountdown+=V.flatConfig.spawnDelay}for(this.stepCountdown-=t;this.stepCountdown<0;){for(let i=0;i<e;i++)this.step();this.stepCountdown+=V.flatConfig.stepDelay}for(const i of this.targets)i.basins.length>0&&i.basins.every(n=>n.isFilled)&&(i.hasFilled=!0,this.isFinished=!0,this.onResize())}Yt(this,T)}goToNextLevel(){this.levelIndex++,this.initLevel(),this.onResize()}draw(t,e){const[i,s,n,o]=e;t.clearRect(i,s,n,o);const l=n/2-this.level.bounds[2]/2,h=o/2-this.level.bounds[3]/2;this.drawOffset[0]=l,this.drawOffset[1]=h;const d=.1;t.fillStyle="black",t.save(),t.translate(l+this.spawn[0]-50,h+this.spawn[1]-50),t.scale(d,d),t.fill(Kt["fa-faucet-drip"]),t.restore(),t.save(),t.translate(l,h),t.fillStyle=Y;for(const f of this.looseParticles)Ct(t,f);for(const f of this.basins)f.draw(t,!1,!1);t.fillStyle="black";for(const f of this.level.platforms)t.fillRect(...f);this.drawTargets(t),t.restore()}drawTargets(t){t.font="30px Lexend",t.textAlign="center",t.textBaseline="middle",t.strokeStyle="black",t.lineWidth=4;for(const[e,i]of this.targets.entries()){const[s,n,o,l]=i.displayRect;i===this.selectedTarget&&t.strokeRect(s,n,o,l),!this.selectedTarget&&i===this.hoveredTarget&&t.strokeRect(s,n,o,l);const h=_t.charAt(e);t.fillStyle="black",t.fillText(h,s+o/2,n+l/2)}}move(t){var i,s;const e=[t[0]-this.drawOffset[0],t[1]-this.drawOffset[1]];return this.mousePos=e,this.isMouseDown&&this.isFinished&&(this.isFreeplay=!0,this.spawn=this.mousePos),(i=T.htmlElem)==null||i.style.setProperty("cursor","default"),this.selectedTarget||(this.hoveredTarget=this.targets.find(({rect:n})=>F(n,e)),this.hoveredTarget&&((s=T.htmlElem)==null||s.style.setProperty("cursor","pointer"))),e}down(t){var s;const e=this.move(t);this.selectedTarget||(this.selectedTarget=this.hoveredTarget,(s=T.htmlElem)==null||s.style.setProperty("cursor","default"),this.onResize()),this.isMouseDown=!0;const i=this.basins.find(({rect:n})=>F(n,e));console.log("clicked basin rims:",JSON.stringify(i==null?void 0:i.rims))}up(t){this.isMouseDown=!1}onResize(){var e;this.layeredViewport=this.defaultLayeredViewport,this.layeredViewport.ctx.clearRect(0,0,this.layeredViewport.w,this.layeredViewport.h);const{layeredViewport:t}=this;t.handleResize(this);for(const i in this.gui.elements)W(i);this.gui.refreshLayout(this),this.isFinished?((e=this.selectedTarget)!=null&&e.isCorrect?S(k,'<span style="color:green">&nbsp;CORRECT!</span>'):S(k,'<span style="color:red">&nbsp;INCORRECT</span>'),this.levelIndex<ft.length-1?W(z):(S(xt,"THANKS FOR PLAYING!"),N(z))):(this.selectedTarget?S(k,'<span style="color:black">&nbsp;FILLING...</span>'):S(k,'<span style="color:black">&nbsp;</span>'),N(z))}rebuildControls(){this.didBuildControls=!0,ue(this)}}function fe(r){return{getSetting:t=>E.flatConfig[t],applySetting:(t,e)=>{t in E.tree.children&&(E.tree.children[t].value=e),E.flatConfig[t]=e},getGameState:()=>r.selectedTarget?r.isFinished?"finished":"filling":"picking-target",getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.cursorForTestSupport}),locateElement(t){if(t.startsWith("target-")){const e=t.split("-")[1],i=_t.indexOf(e),[s,n,o,l]=r.targets[i].rect,[h,d]=r.drawOffset;return[s+h,n+d,o,l]}else{const e=[x.create("zero-gui")];for(const i of e){const s=i.layoutRectangles[t];if(!s)continue;const[n,o,l,h]=s,d=1;return[n*d,o*d,l*d,h*d]}}}}}async function ge(){const r=new Xt;vt.refreshConfig();const t=new pe(r);r.init(t,document.getElementById("midCanvas")),window.TestSupport=fe(t),t.init(),t.onResize(),navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",s=>{window.mouseXForTestSupport=s.clientX,window.mouseYForTestSupport=s.clientY;const n=window.getComputedStyle(s.target).cursor;n==="auto"?window.cursorForTestSupport="default":window.cursorForTestSupport=n,s.stopPropagation()});let e=performance.now();function i(){requestAnimationFrame(i);const s=performance.now(),n=Math.min(50,s-e);e=s,t.update(n)}i()}ge();
