({scriptTags,contentTags}) => {




  // render html with script tags and content
  return `
    
      <!DOCTYPE html>
      <html>
        <body>  
          <canvas></canvas>
          <style>
              canvas { border: none; background-color: #AAA; }
              * { margin: 0; padding: 0;}
              body, html { height:100%; overflow: hidden; }
              canvas { position:absolute; left: 0px; width:100%; height:100%; }
          </style>
          ${scriptTags}
          ${contentTags}
        </body>
      </html>

  `
}