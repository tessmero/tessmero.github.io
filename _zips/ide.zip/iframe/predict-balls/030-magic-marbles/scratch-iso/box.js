/**
 * @file Box
 * A solid box that the sphere can collide with
 *
 * They can be animated by sliding along one axis
 */
class Box {

  /**
   * Construct a box
   * @param {object} params The parameters
   * @param {Vector} params.center The x,y,x center position
   * @param {Vector} params.dimensions The width,height,depth
   * @param {boolean} params.hidden Set to true to skip rendering
   */
  constructor(params) {

    const { 
      center, 
      dimensions, 
      hidden, // only used for iso graphics

      gfxAnim, // drop-in, trigger any time during loading
      physAnim, // deterministic, effects both gfx and physics
    } = params;

    this.center = center;
    this.dims = dimensions;
    this.hidden = hidden;

    this.bounds = {
      minX: center.x - dimensions.x / 2,
      maxX: center.x + dimensions.x / 2,
      minY: center.y - dimensions.y / 2,
      maxY: center.y + dimensions.y / 2,
      minZ: center.z - dimensions.z / 2,
      maxZ: center.z + dimensions.z / 2,
    };
  }

  /**
   *
   */
  get position() {
    return this.center;
  }

  /**
   * Check if the given sphere is intersecting this box.
   * @param {object} sphereObj The Sphere instance
   * @returns {object} result The collision data or null
   */
  checkCollision(sphereObj) {

    const b = this.bounds;
    const box = this.center;
    const sphere = sphereObj.position;

    // Find closest point on box to sphere
    const closestX = Math.max(b.minX, Math.min(sphere.x, b.maxX));
    const closestY = Math.max(b.minY, Math.min(sphere.y, b.maxY));
    const closestZ = Math.max(b.minZ, Math.min(sphere.z, b.maxZ));

    // Calculate distance components
    const dx = sphere.x - closestX;
    const dy = sphere.y - closestY;
    const dz = sphere.z - closestZ;
    const distanceSq = dx * dx + dy * dy + dz * dz;

    if (distanceSq > SPHERE_RADIUS ** 2) { return null; }

    // Calculate collision normal
    const distance = Math.sqrt(distanceSq);
    const normal = {
      x: dx / distance || 0, // Prevent NaN when distance is 0
      y: dy / distance || 0,
      z: dz / distance || 0,
    };

    // Calculate adjusted position: move sphere center along normal so it just touches the box
    let adjustedPosition;
    const centerOutside = (distance > 0);
    if (centerOutside) {
    // Move out along the normal by (radius - penetration depth)
      const penetration = SPHERE_RADIUS - distance;
      adjustedPosition = {
        x: sphere.x + normal.x * penetration,
        y: sphere.y + normal.y * penetration,
        z: sphere.z + normal.z * penetration,
      };
    }
    else {
    // Sphere center is inside box; pick the direction of max penetration axis
    // Find the smallest distance to a face
      const dists = [
        Math.abs(sphere.x - b.minX),
        Math.abs(sphere.x - b.maxX),
        Math.abs(sphere.y - b.minY),
        Math.abs(sphere.y - b.maxY),
        Math.abs(sphere.z - b.minZ),
        Math.abs(sphere.z - b.maxZ),
      ];
      const minDist = Math.min(...dists);
      const axis = dists.indexOf(minDist);
      adjustedPosition = { ...sphere };
      if (axis === 0) { adjustedPosition.x = b.minX - SPHERE_RADIUS; }
      else if (axis === 1) { adjustedPosition.x = b.maxX + SPHERE_RADIUS; }
      else if (axis === 2) { adjustedPosition.y = b.minY - SPHERE_RADIUS; }
      else if (axis === 3) { adjustedPosition.y = b.maxY + SPHERE_RADIUS; }
      else if (axis === 4) { adjustedPosition.z = b.minZ - SPHERE_RADIUS; }
      else if (axis === 5) { adjustedPosition.z = b.maxZ + SPHERE_RADIUS; }
    }

    return { normal, adjustedPosition, centerOutside };
  }

}
