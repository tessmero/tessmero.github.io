/**
 * @file main.js entry point
 * top-level objects and main loop
 */

const DEBUG_QUADS = true; // color-code the 4 canvases
const DEBUG_SCREEN = true; // trace screen boundaries
const DEBUG_SHRINK = true; // shrink screen boundaries
const DEBUG_CHUNKS = false; // trace simulation chunks




const MAX_CHUNKS = 256; // default number of chunks per simulation

// assume document has one canvas
// to be used as a placeholder or for debugging
// it will always fill the REAL viewport
const BASE_CANVAS = document.getElementsByTagName('canvas')[0];
Canvas.setStyles(BASE_CANVAS, { 'background-color': 'transparent' });

const {

  // define global variables
  CHUNK_SIZE, // square chunk
  VIEW_WIDTH, VIEW_HEIGHT, // viewport dimensions
  QUAD_WIDTH, QUAD_HEIGHT, // expanded dimensions
  TOP_LEFT, // corner matching viewport
  BOTTOM_RIGHT, // expanded corner

  // get array of 4 Canvas instances
  quadCvs, 

} = QuadUtil.setupQuadCanvases()


const CAMERA_SPEED = 100; 

// (milliseconds) system time
let time = Date.now();

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // compute time elapsed since last frame
  const newTime = Date.now();
  const dt = Math.min(50, newTime - time); // limit to 50 ms in case of lag
  time = newTime;

  const angle = time / 3000;
  const rawCam = { x: CAMERA_SPEED * Math.sin(angle), y: CAMERA_SPEED * Math.cos(angle) };

  const pixel = 1/devicePixelRatio
  const camera = { x: pixel*Math.round(rawCam.x/pixel), y: pixel*Math.round(rawCam.y/pixel) };
  
  for (const cvs of quadCvs) {
    cvs.updatePosition({ camera });
  }


// debug viewport or quads or chunks
  QuadUtil.drawDebugOverlays()
  
}
requestAnimationFrame(animationLoop); // queue first loop