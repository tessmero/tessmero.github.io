# Chapter 1: Infinite Canvas

We define the Canvas object type and construct four instances (quad canvases). Each Canvas instance controls an html canvas element. We regularly adjust their css styles to change their positions on screen. We have them all move in unison based on the same camera x,y. We use math to swap them around as necessary so they always cover the whole viewport. 

Getting started with the infinite canvas can be finicky but ultimately rewarding. Like many things in 2D, we eventually realize we only have a few numbers and a few sensible math operations apply to them. After a bit of trial and error, everything suddenly lines up and feels solid.

<details>
<summary>
Read math explaination...

</summary>
(mod function)

We know that the position of the canvas has to involve some piece-wise function. As the camera moves in a straight line, the canvas occasionally teleports. The canvas keeps moving in the same direction after teleporting and eventually ends up back in the same spot. So, we apply the modulo function to the camera coordinates. 

When the canvas jumps to the opposite side of the screen, it has to move a distance equal to two canvas-lengths. So, the divisor for the modulo should be double the canvas length. 

We also need to include some unique constant offsets for each of the four canvases.
</details>

## Adjusted Canvas Shape

Our canvases have to be at least the size of the viewport. We will also plan ahead and make sure our canvas can be filled neatly by square tiles - square tiles which themselves match up with the physical device pixels. To make this work out we may expand the width and height a bit.






