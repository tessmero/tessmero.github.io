/**
 * @file main.js entry point
 * top-level objects and main loop
 */

// air hockey scene
const thick = 10; // thickness of walls
const scene = {

  // one sliding disk
  disks: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0.15, y: 0.1 },
      radius: 5,
    },
  ],

  // 5 solid obstacles
  obstacles: [

    // center obstacle that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // four outer walls
    { box: [0, 0, thick, 100] }, // left
    { box: [100 - thick, 0, thick, 100] }, // right
    { box: [0, 0, 100, thick] }, // top
    { box: [0, 100 - thick, 100, thick] }, // bottom
  ],
};

// construct Disk and Obstacle instances
const disks = scene.disks.map((p) => new Disk(p));
const obstacles = scene.obstacles.map((p) => new Obstacle(p));

const engine = Matter.Engine.create({ gravity: { x: 0, y: 0 } });

// enable elastic bouncing
// https://github.com/liabru/matter-js/issues/394
Matter.Resolver._restingThresh = 0;

// add disks and obstacles to matter.js engine
for (const { body } of ([...disks, ...obstacles])) {
  Matter.World.add(engine.world, body);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first obstacle to the mouse position
  mouseMove: (mousePos) => {
    Matter.Body.setPosition(obstacles[0].body, mousePos);
  },
});

// get system time in units of steps
const stepDuration = 3; // milliseconds
function getStepTime() {
  return Date.now() / stepDuration;
}

// start keeping track of time
let time = getStepTime();


// sanity check for first few steps
// change in disk position should equal its velocity
let totalSteps = 0;
function sanityCheck() {
  totalSteps++;
  if (totalSteps < 10) {
    const diskStart = scene.disks[0]; // initial disk state
    const delta = VectorMath.subtract(disks[0].getPosition(), diskStart.position);
    const expectedLength = stepDuration * totalSteps * VectorMath.getLength(diskStart.velocity);
    const actualLength = VectorMath.getLength(delta);
    const score = Math.round(100 * actualLength / expectedLength);
    console.log({ totalSteps, score, expectedLength, actualLength });
  }
}

// main loop
function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    Matter.Engine.update(engine, stepDuration * (1000 / 60));

    // sanityCheck();
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const disk of disks) {
    Graphics.drawDisk(ctx, disk);
  }
  for (const obstacle of obstacles) {
    Graphics.drawObstacle(ctx, obstacle);
  }

  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop

