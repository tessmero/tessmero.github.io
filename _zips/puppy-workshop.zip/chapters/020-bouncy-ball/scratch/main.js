/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 1e-3 }; // change in velocity per step
const AIR_RESISTANCE = 1e-3; // fraction of speed lost per step
const RESTITUTION = 0.9; // fraction of speed maintained in bounce

// bouncy ball scene
const thick = 10; // thickness of walls
const scene = {

  // one bouncy ball
  balls: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0.15, y: 0.1 },
      radius: 5,
    },
  ],

  // some solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left
    { box: [100 - thick, 0, thick, 100] }, // right
    { box: [0, 0, 100, thick] }, // ceiling

    // { box: [0, 100 - thick, 100, thick] }, // flat floor

    // sloped floor with a low point in the middle
    // (composed of two overlapping triangles)
    { vertices: [
      { x: 0, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },
    { vertices: [
      { x: 100, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },

  ],
};

// construct Ball and Platform instances based on scene
const balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  // (replace it with a new platform with different position)
  mouseMove: (mousePos) => {
    platforms[0] = new Platform({
      ...scene.platforms[0], // inherit initial platform parameters
      center: mousePos, // overwrite default position
    });
  },
});

const STEP_DURATION = 3; // (milliseconds) simulation time resolution
let time = Date.now() // (milliseconds) system time

// main loop
function animationLoop() {
  requestAnimationFrame(animationLoop); // queue next loop

  // check how much time has passed since the last frame was drawn
  const newTime = Date.now();
  const dt = newTime - time;
  time = newTime;
  if (dt > 200) {
    return; // lagging or regained focus, do nothing this frame
  }
  const nSteps = Math.round(dt / STEP_DURATION);

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    for (const ball of balls) {
      ball.step(platforms);
    }
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const ball of balls) {
    Graphics.drawBall(ctx, ball);
  }
  for (const platform of platforms) {
    Graphics.drawPlatform(ctx, platform);
  }

}
requestAnimationFrame(animationLoop) // queue first loop