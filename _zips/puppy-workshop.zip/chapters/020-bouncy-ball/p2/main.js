/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 1e-3 };
const AIR_RESISTANCE = 1e-3;
const RESTITUTION = 0.9;

// bouncy ball scene
const thick = 10; // thickness of walls
const scene = {

  // one bouncy ball
  balls: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0.15, y: 0.1 },
      radius: 5,
    },
  ],

  // some solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left
    { box: [100 - thick, 0, thick, 100] }, // right
    { box: [0, 0, 100, thick] }, // ceiling

    // { box: [0, 100 - thick, 100, thick] }, // flat floor

    // sloped floor with a low point in the middle
    // (composed of two overlapping triangles)
    { vertices: [
      { x: 0, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },
    { vertices: [
      { x: 100, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },

  ],
};

// construct Ball and Platform instances based on scene
const balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// initialize p2.js physics world
const p2World = new p2.World({
  gravity: [GRAVITY.x, GRAVITY.y],
});

// enable elastic bouncing
p2World.defaultContactMaterial.restitution = RESTITUTION;
p2World.defaultContactMaterial.friction = 0;

// add balls and platforms to p2 engine
for (const { body } of ([...balls, ...platforms])) {
  p2World.addBody(body);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  mouseMove: ({ x, y }) => {
    platforms[0].body.position = [x, y];
  },
});

// get system time in units of steps
const stepDuration = 3; // milliseconds
function getStepTime() {
  return Date.now() / stepDuration;
}

// start keeping track of time
let time = getStepTime();

function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    p2World.step(stepDuration);
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const ball of balls) {
    Graphics.drawBall(ctx, ball);
  }
  for (const platform of platforms) {
    Graphics.drawPlatform(ctx, platform);
  }

  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop
