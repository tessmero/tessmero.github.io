/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 1e-3 };
const AIR_RESISTANCE = 1e-3;
const RESTITUTION = 0.99;
const SPRING_STIFFNESS = 1e-3;
const SPRING_DAMPING = 1e-3;

// balls and springs scene
const thick = 10; // thickness of walls

const scene = {

  // 2 connected bouncy balls
  balls: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0, y: 0 },
      radius: 5,
    },
    {
      position: { x: 45, y: 25 },
      velocity: { x: 0, y: 0 },
      radius: 5,
    },
  ],

  // solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left wall
    { box: [100 - thick, 0, thick, 100] }, // right wall
    { box: [0, 0, 100, thick] }, // ceiling

    // flat floor
    // { box: [0, 100 - thick, 100, thick] },

    // sloped floor with a low point in the middle
    // (composed of two overlapping triangles)
    { vertices: [
      { x: 0, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },
    { vertices: [
      { x: 100, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },

  ],
};

// construct Ball and Platform instances based on scene
const balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// construct Spring instance connecting the two balls
const springs = [
  new Spring(balls[0], balls[1]),
];

const engine = Matter.Engine.create({ gravity: GRAVITY });

// enable elastic bouncing
// https://github.com/liabru/matter-js/issues/394
Matter.Resolver._restingThresh = 0;

// add physics objects to matter.js engine
for (const { body } of ([...balls, ...platforms])) {
  Matter.World.add(engine.world, body);
}
for (const { matterObj } of springs) {
  Matter.World.add(engine.world, matterObj);
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  mouseMove: (mousePos) => {
    Matter.Body.setPosition(platforms[0].body, mousePos);
  },
});

// get system time in units of steps
const stepDuration = 1; // milliseconds
function getStepTime() {
  return Date.now() / stepDuration;
}

// start keeping track of time
let time = getStepTime();

// main loop
function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    Matter.Engine.update(engine, stepDuration * (1000 / 60));
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const ball of balls) {
    Graphics.drawBall(ctx, ball);
  }
  for (const platform of platforms) {
    Graphics.drawPlatform(ctx, platform);
  }
  for (const spring of springs) {
    Graphics.drawSpring(ctx, spring);
  }
  
  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop

