/**
 * @file main.js entry point
 * settings, top-level objects, and main loop
 */

const GRAVITY = { x: 0, y: 5e-4 }; // change in velocity per step
const AIR_RESISTANCE = 1e-3; // fraction of speed lost per step
const RESTITUTION = 0.9; // fraction of speed maintained in bounce
const SPRING_STIFFNESS = 1e-2;
const SPRING_DAMPING = 1e-2;

// balls and springs scene
const thick = 10; // thickness of walls

const scene = {

  // 2 connected bouncy balls
  balls: [
    {
      position: { x: 25, y: 25 },
      velocity: { x: 0, y: 0 },
      radius: 5,
    },
    {
      position: { x: 45, y: 25 },
      velocity: { x: 0, y: 0 },
      radius: 5,
    },
  ],

  // solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left wall
    { box: [100 - thick, 0, thick, 100] }, // right wall
    { box: [0, 0, 100, thick] }, // ceiling

    // flat floor
    // { box: [0, 100 - thick, 100, thick] },

    // sloped floor with a low point in the middle
    // (composed of two overlapping triangles)
    { vertices: [
      { x: 0, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },
    { vertices: [
      { x: 100, y: 100 - thick },
      { x: 100, y: 100 },
      { x: 0, y: 100 },
    ] },

  ],
};

// construct Ball and Platform instances based on scene
const balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// construct Spring instance connecting the two balls
const springs = [
  new Spring(balls[0], balls[1]),
];

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  // (replace it with a new platform with different position)
  mouseMove: (mousePos) => {
    platforms[0] = new Platform({
      ...scene.platforms[0], // inherit initial platform parameters
      center: mousePos, // overwrite default position
    });
  },
});

// get system time in units of steps
const stepDuration = 1; // milliseconds
function getStepTime() {
  return Date.now() / stepDuration;
}

// start keeping track of time
let time = getStepTime();

function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    for (const spring of springs) {
      spring.applyForces();
    }
    for (const ball of balls) {
      ball.step(platforms);
    }
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  for (const ball of balls) {
    Graphics.drawBall(ctx, ball);
  }
  for (const platform of platforms) {
    Graphics.drawPlatform(ctx, platform);
  }
  for (const spring of springs) {
    Graphics.drawSpring(ctx, spring);
  }
  
  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop
