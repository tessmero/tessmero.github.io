/**
 * @file Ball
 * bouncy ball
 */
class Ball {

  /**
   * Construct a bouncy ball.
   * @param {object} params
   * @param {Vector} params.position
   * @param {Vector} params.velocity
   * @param {number} params.radius The size of the ball
   */
  constructor(params) {
    const { position, velocity, radius } = params;

    // build matter.js circle body
    const body = Matter.Bodies.circle(
      position.x, // x position
      position.y, // y position
      radius, // circle radius
      {
        collisionFilter: {
          category: BALL_CATEGORY, // is ball
          mask: PLATFORM_CATEGORY, // collide with platforms
        },
        friction: 0,
        frictionStatic: 0,
        frictionAir: AIR_RESISTANCE,
        restitution: RESTITUTION,
        inertia: 1e6,
      }
    );
    Matter.Body.setVelocity(body, velocity);

    // body will be registered in matter.js engine
    // also used to check the position for drawing
    this.body = body;

    // radius used for drawing
    this.radius = radius;
  }

  /**
   * Set friction (grip). Used in walking animation.
   * @param {number} friction
   */
  setFriction(friction) {
    Matter.Body.set(this.body, {
      friction,
      staticFriction: friction,
    });
  }

  /**
   * Get position for purposes of drawing
   * @returns {Vector} The position of the body
   */
  getPosition() {
    return this.body.position;
  }

  /**
   * Get angle for purposes of drawing
   * @returns {number} The angle of the body
   */
  getAngle() {
    return -this.body.angle;
  }
}
