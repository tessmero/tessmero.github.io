/**
 * @file main.js entry point
 * where we define our top-level objects and the main loop
 */

const GRAVITY = { x: 0, y: 5e-4 }; // change in velocity per step
const AIR_RESISTANCE = 1e-3; // fraction of speed lost per step
const RESTITUTION = 0.9; // fraction of speed maintained in bounce
const SPRING_STIFFNESS = 1e-2;
const SPRING_DAMPING = 1e-2;

// walking puppy scene
const thick = 10; // thickness of walls

const scene = {

  // no loose balls
  balls: [],

  // one puppy
  puppies: [
    { position: { x: 20, y: 20 } },
  ],

  // some solid platforms
  platforms: [

    // center platform that moves with the mouse
    { center: { x: 50, y: 50 }, radius: 10, n: 10 },

    // outer walls
    { box: [0, 0, thick, 100] }, // left wall
    { box: [100 - thick, 0, thick, 100] }, // right wall
    { box: [0, 0, 100, thick] }, // ceiling
    { box: [0, 100 - thick, 100, thick] }, // floor

  ],
};

// construct Ball, and Platform instances based on scene
let balls = scene.balls.map((p) => new Ball(p));
const platforms = scene.platforms.map((p) => new Platform(p));

// construct Puppies composed of Ball and Spring instances
let springs = [];
const puppies = [];
for (const puppyParams of scene.puppies) {
  const puppy = new Puppy(puppyParams);
  puppies.push(puppy);
  balls = [...balls, ...puppy.balls];
  springs = [...springs, ...puppy.springs];
}

// set up graphics context and start listening for input
const { canvas, ctx, clearRect } = CanvasUtil.setupCanvas({

  // move the first platform to the mouse position
  // (replace it with a new platform with different position)
  mouseMove: (mousePos) => {
    platforms[0] = new Platform({
      ...scene.platforms[0], // inherit initial platform parameters
      center: mousePos, // overwrite default position
    });
  },
});

// get system time in units of steps
const stepDuration = 3; // milliseconds
function getStepTime() {
  return Date.now() / stepDuration;
}

// start keeping track of time
let time = getStepTime();

function animationLoop() {

  // check how much time has passed since the last frame was drawn
  const newTime = getStepTime();
  const nSteps = Math.round(newTime - time);
  time = newTime;

  // advance the simulation by n steps
  for (let i = 0; i < nSteps; i++) {
    for (const puppy of puppies) {
      puppy.updateWalkAnim();
    }
    for (const spring of springs) {
      spring.applyForces();
    }
    for (const ball of balls) {
      ball.step(platforms);
    }
  }

  // draw the updated scene
  ctx.clearRect(...clearRect);
  
  for (const platform of platforms) {
    Graphics.drawPlatform(ctx, platform);
  }
  
  for (const puppy of puppies) {
    Graphics.drawPuppy(ctx, puppy);
  }
  
  // for (const ball of balls) {
  //   Graphics.drawBall(ctx, ball);
  // }
  // for(const spring of springs) {
  //   Graphics.drawSpring(ctx,spring)
  // }
  
  requestAnimationFrame(animationLoop); // queue next loop
}
animationLoop(); // start first loop
