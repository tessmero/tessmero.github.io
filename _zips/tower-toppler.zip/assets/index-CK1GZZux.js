var uf=Object.defineProperty;var ff=(s,t,e)=>t in s?uf(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var F=(s,t,e)=>ff(s,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function e(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(i){if(i.ep)return;i.ep=!0;const r=e(i);fetch(i.href,r)}})();/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const ul="181",Us={ROTATE:0,DOLLY:1,PAN:2},Is={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},pf=0,Jl=1,mf=2,ru=1,xf=2,ni=3,Fi=0,Ke=1,Pn=2,oi=0,Ns=1,Ql=2,th=3,eh=4,gf=5,es=100,_f=101,vf=102,bf=103,Mf=104,Sf=200,yf=201,Ef=202,Af=203,ac=204,cc=205,wf=206,Tf=207,Cf=208,Rf=209,Pf=210,Lf=211,If=212,Df=213,Ff=214,lc=0,hc=1,dc=2,Bs=3,uc=4,fc=5,pc=6,mc=7,ou=0,Uf=1,Nf=2,Di=0,Of=1,Bf=2,zf=3,Vf=4,kf=5,Gf=6,Hf=7,au=300,zs=301,Vs=302,xc=303,gc=304,Jo=306,Oo=1e3,si=1001,_c=1002,pn=1003,Wf=1004,Or=1005,en=1006,ha=1007,ss=1008,ci=1009,cu=1010,lu=1011,yr=1012,fl=1013,os=1014,zn=1015,Ws=1016,pl=1017,ml=1018,Er=1020,hu=35902,du=35899,uu=1021,fu=1022,In=1023,Ar=1026,wr=1027,xl=1028,gl=1029,_l=1030,vl=1031,bl=1033,wo=33776,To=33777,Co=33778,Ro=33779,vc=35840,bc=35841,Mc=35842,Sc=35843,yc=36196,Ec=37492,Ac=37496,wc=37808,Tc=37809,Cc=37810,Rc=37811,Pc=37812,Lc=37813,Ic=37814,Dc=37815,Fc=37816,Uc=37817,Nc=37818,Oc=37819,Bc=37820,zc=37821,Vc=36492,kc=36494,Gc=36495,Hc=36283,Wc=36284,Xc=36285,qc=36286,Xf=3200,qf=3201,Yf=0,$f=1,Ri="",bn="srgb",ks="srgb-linear",Bo="linear",fe="srgb",us=7680,nh=519,Kf=512,Zf=513,jf=514,pu=515,Jf=516,Qf=517,tp=518,ep=519,ih=35044,sh="300 es",Vn=2e3,zo=2001;function mu(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function Vo(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function np(){const s=Vo("canvas");return s.style.display="block",s}const rh={};function oh(...s){const t="THREE."+s.shift();console.log(t,...s)}function Ht(...s){const t="THREE."+s.shift();console.warn(t,...s)}function Pe(...s){const t="THREE."+s.shift();console.error(t,...s)}function Tr(...s){const t=s.join(" ");t in rh||(rh[t]=!0,Ht(...s))}function ip(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}class ls{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const i=n[t];if(i!==void 0){const r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let r=0,o=i.length;r<o;r++)i[r].call(this,t);t.target=null}}}const Ve=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Po=Math.PI/180,Yc=180/Math.PI;function Ir(){const s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Ve[s&255]+Ve[s>>8&255]+Ve[s>>16&255]+Ve[s>>24&255]+"-"+Ve[t&255]+Ve[t>>8&255]+"-"+Ve[t>>16&15|64]+Ve[t>>24&255]+"-"+Ve[e&63|128]+Ve[e>>8&255]+"-"+Ve[e>>16&255]+Ve[e>>24&255]+Ve[n&255]+Ve[n>>8&255]+Ve[n>>16&255]+Ve[n>>24&255]).toLowerCase()}function Jt(s,t,e){return Math.max(t,Math.min(e,s))}function sp(s,t){return(s%t+t)%t}function da(s,t,e){return(1-e)*s+e*t}function Ks(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function Je(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}const rp={DEG2RAD:Po};class zt{constructor(t=0,e=0){zt.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*i+t.x,this.y=r*i+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Ui{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,o,a){let c=n[i+0],l=n[i+1],h=n[i+2],d=n[i+3],u=r[o+0],m=r[o+1],x=r[o+2],g=r[o+3];if(a<=0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d;return}if(a>=1){t[e+0]=u,t[e+1]=m,t[e+2]=x,t[e+3]=g;return}if(d!==g||c!==u||l!==m||h!==x){let p=c*u+l*m+h*x+d*g;p<0&&(u=-u,m=-m,x=-x,g=-g,p=-p);let f=1-a;if(p<.9995){const M=Math.acos(p),_=Math.sin(M);f=Math.sin(f*M)/_,a=Math.sin(a*M)/_,c=c*f+u*a,l=l*f+m*a,h=h*f+x*a,d=d*f+g*a}else{c=c*f+u*a,l=l*f+m*a,h=h*f+x*a,d=d*f+g*a;const M=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=M,l*=M,h*=M,d*=M}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,r,o){const a=n[i],c=n[i+1],l=n[i+2],h=n[i+3],d=r[o],u=r[o+1],m=r[o+2],x=r[o+3];return t[e]=a*x+h*d+c*m-l*u,t[e+1]=c*x+h*u+l*d-a*m,t[e+2]=l*x+h*m+a*u-c*d,t[e+3]=h*x-a*d-c*u-l*m,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,r=t._z,o=t._order,a=Math.cos,c=Math.sin,l=a(n/2),h=a(i/2),d=a(r/2),u=c(n/2),m=c(i/2),x=c(r/2);switch(o){case"XYZ":this._x=u*h*d+l*m*x,this._y=l*m*d-u*h*x,this._z=l*h*x+u*m*d,this._w=l*h*d-u*m*x;break;case"YXZ":this._x=u*h*d+l*m*x,this._y=l*m*d-u*h*x,this._z=l*h*x-u*m*d,this._w=l*h*d+u*m*x;break;case"ZXY":this._x=u*h*d-l*m*x,this._y=l*m*d+u*h*x,this._z=l*h*x+u*m*d,this._w=l*h*d-u*m*x;break;case"ZYX":this._x=u*h*d-l*m*x,this._y=l*m*d+u*h*x,this._z=l*h*x-u*m*d,this._w=l*h*d+u*m*x;break;case"YZX":this._x=u*h*d+l*m*x,this._y=l*m*d+u*h*x,this._z=l*h*x-u*m*d,this._w=l*h*d-u*m*x;break;case"XZY":this._x=u*h*d-l*m*x,this._y=l*m*d-u*h*x,this._z=l*h*x+u*m*d,this._w=l*h*d+u*m*x;break;default:Ht("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],r=e[8],o=e[1],a=e[5],c=e[9],l=e[2],h=e[6],d=e[10],u=n+a+d;if(u>0){const m=.5/Math.sqrt(u+1);this._w=.25/m,this._x=(h-c)*m,this._y=(r-l)*m,this._z=(o-i)*m}else if(n>a&&n>d){const m=2*Math.sqrt(1+n-a-d);this._w=(h-c)/m,this._x=.25*m,this._y=(i+o)/m,this._z=(r+l)/m}else if(a>d){const m=2*Math.sqrt(1+a-n-d);this._w=(r-l)/m,this._x=(i+o)/m,this._y=.25*m,this._z=(c+h)/m}else{const m=2*Math.sqrt(1+d-n-a);this._w=(o-i)/m,this._x=(r+l)/m,this._y=(c+h)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Jt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,r=t._z,o=t._w,a=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+o*a+i*l-r*c,this._y=i*h+o*c+r*a-n*l,this._z=r*h+o*l+n*c-i*a,this._w=o*h-n*a-i*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e<=0)return this;if(e>=1)return this.copy(t);let n=t._x,i=t._y,r=t._z,o=t._w,a=this.dot(t);a<0&&(n=-n,i=-i,r=-r,o=-o,a=-a);let c=1-e;if(a<.9995){const l=Math.acos(a),h=Math.sin(l);c=Math.sin(c*l)/h,e=Math.sin(e*l)/h,this._x=this._x*c+n*e,this._y=this._y*c+i*e,this._z=this._z*c+r*e,this._w=this._w*c+o*e,this._onChangeCallback()}else this._x=this._x*c+n*e,this._y=this._y*c+i*e,this._z=this._z*c+r*e,this._w=this._w*c+o*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class B{constructor(t=0,e=0,n=0){B.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(ah.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(ah.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*o,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,r=t.x,o=t.y,a=t.z,c=t.w,l=2*(o*i-a*n),h=2*(a*e-r*i),d=2*(r*n-o*e);return this.x=e+c*l+o*d-a*h,this.y=n+c*h+a*l-r*d,this.z=i+c*d+r*h-o*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this.z=Jt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this.z=Jt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,r=t.z,o=e.x,a=e.y,c=e.z;return this.x=i*c-r*a,this.y=r*o-n*c,this.z=n*a-i*o,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return ua.copy(this).projectOnVector(t),this.sub(ua)}reflect(t){return this.sub(ua.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const ua=new B,ah=new Ui;class Xt{constructor(t,e,n,i,r,o,a,c,l){Xt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l)}set(t,e,n,i,r,o,a,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=a,h[3]=e,h[4]=r,h[5]=c,h[6]=n,h[7]=o,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[3],c=n[6],l=n[1],h=n[4],d=n[7],u=n[2],m=n[5],x=n[8],g=i[0],p=i[3],f=i[6],M=i[1],_=i[4],v=i[7],b=i[2],S=i[5],T=i[8];return r[0]=o*g+a*M+c*b,r[3]=o*p+a*_+c*S,r[6]=o*f+a*v+c*T,r[1]=l*g+h*M+d*b,r[4]=l*p+h*_+d*S,r[7]=l*f+h*v+d*T,r[2]=u*g+m*M+x*b,r[5]=u*p+m*_+x*S,r[8]=u*f+m*v+x*T,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8];return e*o*h-e*a*l-n*r*h+n*a*c+i*r*l-i*o*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],d=h*o-a*l,u=a*c-h*r,m=l*r-o*c,x=e*d+n*u+i*m;if(x===0)return this.set(0,0,0,0,0,0,0,0,0);const g=1/x;return t[0]=d*g,t[1]=(i*l-h*n)*g,t[2]=(a*n-i*o)*g,t[3]=u*g,t[4]=(h*e-i*c)*g,t[5]=(i*r-a*e)*g,t[6]=m*g,t[7]=(n*c-l*e)*g,t[8]=(o*e-n*r)*g,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*o+l*a)+o+t,-i*l,i*c,-i*(-l*o+c*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(fa.makeScale(t,e)),this}rotate(t){return this.premultiply(fa.makeRotation(-t)),this}translate(t,e){return this.premultiply(fa.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const fa=new Xt,ch=new Xt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),lh=new Xt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function op(){const s={enabled:!0,workingColorSpace:ks,spaces:{},convert:function(i,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===fe&&(i.r=ai(i.r),i.g=ai(i.g),i.b=ai(i.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===fe&&(i.r=Os(i.r),i.g=Os(i.g),i.b=Os(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Ri?Bo:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,o){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return Tr("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return Tr("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[ks]:{primaries:t,whitePoint:n,transfer:Bo,toXYZ:ch,fromXYZ:lh,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:bn},outputColorSpaceConfig:{drawingBufferColorSpace:bn}},[bn]:{primaries:t,whitePoint:n,transfer:fe,toXYZ:ch,fromXYZ:lh,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:bn}}}),s}const oe=op();function ai(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Os(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let fs;class ap{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{fs===void 0&&(fs=Vo("canvas")),fs.width=t.width,fs.height=t.height;const i=fs.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=fs}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=Vo("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let o=0;o<r.length;o++)r[o]=ai(r[o]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(ai(e[n]/255)*255):e[n]=ai(e[n]);return{data:e,width:t.width,height:t.height}}else return Ht("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let cp=0;class Ml{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:cp++}),this.uuid=Ir(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?r.push(pa(i[o].image)):r.push(pa(i[o]))}else r=pa(i);n.url=r}return e||(t.images[this.uuid]=n),n}}function pa(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?ap.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(Ht("Texture: Unable to serialize Texture."),{})}let lp=0;const ma=new B;class He extends ls{constructor(t=He.DEFAULT_IMAGE,e=He.DEFAULT_MAPPING,n=si,i=si,r=en,o=ss,a=In,c=ci,l=He.DEFAULT_ANISOTROPY,h=Ri){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:lp++}),this.uuid=Ir(),this.name="",this.source=new Ml(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new zt(0,0),this.repeat=new zt(1,1),this.center=new zt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(ma).x}get height(){return this.source.getSize(ma).y}get depth(){return this.source.getSize(ma).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){Ht(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){Ht(`Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==au)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Oo:t.x=t.x-Math.floor(t.x);break;case si:t.x=t.x<0?0:1;break;case _c:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Oo:t.y=t.y-Math.floor(t.y);break;case si:t.y=t.y<0?0:1;break;case _c:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}He.DEFAULT_IMAGE=null;He.DEFAULT_MAPPING=au;He.DEFAULT_ANISOTROPY=1;class Le{constructor(t=0,e=0,n=0,i=1){Le.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*i+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*i+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*i+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*i+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r;const c=t.elements,l=c[0],h=c[4],d=c[8],u=c[1],m=c[5],x=c[9],g=c[2],p=c[6],f=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-g)<.01&&Math.abs(x-p)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+g)<.1&&Math.abs(x+p)<.1&&Math.abs(l+m+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const _=(l+1)/2,v=(m+1)/2,b=(f+1)/2,S=(h+u)/4,T=(d+g)/4,P=(x+p)/4;return _>v&&_>b?_<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(_),i=S/n,r=T/n):v>b?v<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(v),n=S/i,r=P/i):b<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(b),n=T/r,i=P/r),this.set(n,i,r,e),this}let M=Math.sqrt((p-x)*(p-x)+(d-g)*(d-g)+(u-h)*(u-h));return Math.abs(M)<.001&&(M=1),this.x=(p-x)/M,this.y=(d-g)/M,this.z=(u-h)/M,this.w=Math.acos((l+m+f-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this.z=Jt(this.z,t.z,e.z),this.w=Jt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this.z=Jt(this.z,t,e),this.w=Jt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class hp extends ls{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:en,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new Le(0,0,t,e),this.scissorTest=!1,this.viewport=new Le(0,0,t,e);const i={width:t,height:e,depth:n.depth},r=new He(i);this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){const e={minFilter:en,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isData3DTexture!==!0&&(this.textures[i].isArrayTexture=this.textures[i].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const i=Object.assign({},t.textures[e].image);this.textures[e].source=new Ml(i)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class as extends hp{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class xu extends He{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=pn,this.minFilter=pn,this.wrapR=si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class dp extends He{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=pn,this.minFilter=pn,this.wrapR=si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class hs{constructor(t=new B(1/0,1/0,1/0),e=new B(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(An.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(An.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=An.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,An):An.fromBufferAttribute(r,o),An.applyMatrix4(t.matrixWorld),this.expandByPoint(An);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Br.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Br.copy(n.boundingBox)),Br.applyMatrix4(t.matrixWorld),this.union(Br)}const i=t.children;for(let r=0,o=i.length;r<o;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,An),An.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Zs),zr.subVectors(this.max,Zs),ps.subVectors(t.a,Zs),ms.subVectors(t.b,Zs),xs.subVectors(t.c,Zs),fi.subVectors(ms,ps),pi.subVectors(xs,ms),zi.subVectors(ps,xs);let e=[0,-fi.z,fi.y,0,-pi.z,pi.y,0,-zi.z,zi.y,fi.z,0,-fi.x,pi.z,0,-pi.x,zi.z,0,-zi.x,-fi.y,fi.x,0,-pi.y,pi.x,0,-zi.y,zi.x,0];return!xa(e,ps,ms,xs,zr)||(e=[1,0,0,0,1,0,0,0,1],!xa(e,ps,ms,xs,zr))?!1:(Vr.crossVectors(fi,pi),e=[Vr.x,Vr.y,Vr.z],xa(e,ps,ms,xs,zr))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,An).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(An).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Wn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Wn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Wn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Wn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Wn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Wn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Wn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Wn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Wn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Wn=[new B,new B,new B,new B,new B,new B,new B,new B],An=new B,Br=new hs,ps=new B,ms=new B,xs=new B,fi=new B,pi=new B,zi=new B,Zs=new B,zr=new B,Vr=new B,Vi=new B;function xa(s,t,e,n,i){for(let r=0,o=s.length-3;r<=o;r+=3){Vi.fromArray(s,r);const a=i.x*Math.abs(Vi.x)+i.y*Math.abs(Vi.y)+i.z*Math.abs(Vi.z),c=t.dot(Vi),l=e.dot(Vi),h=n.dot(Vi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>a)return!1}return!0}const up=new hs,js=new B,ga=new B;class Dr{constructor(t=new B,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):up.setFromPoints(t).getCenter(n);let i=0;for(let r=0,o=t.length;r<o;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;js.subVectors(t,this.center);const e=js.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(js,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(ga.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(js.copy(t.center).add(ga)),this.expandByPoint(js.copy(t.center).sub(ga))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}const Xn=new B,_a=new B,kr=new B,mi=new B,va=new B,Gr=new B,ba=new B;let Sl=class{constructor(t=new B,e=new B(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Xn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=Xn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Xn.copy(this.origin).addScaledVector(this.direction,e),Xn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){_a.copy(t).add(e).multiplyScalar(.5),kr.copy(e).sub(t).normalize(),mi.copy(this.origin).sub(_a);const r=t.distanceTo(e)*.5,o=-this.direction.dot(kr),a=mi.dot(this.direction),c=-mi.dot(kr),l=mi.lengthSq(),h=Math.abs(1-o*o);let d,u,m,x;if(h>0)if(d=o*c-a,u=o*a-c,x=r*h,d>=0)if(u>=-x)if(u<=x){const g=1/h;d*=g,u*=g,m=d*(d+o*u+2*a)+u*(o*d+u+2*c)+l}else u=r,d=Math.max(0,-(o*u+a)),m=-d*d+u*(u+2*c)+l;else u=-r,d=Math.max(0,-(o*u+a)),m=-d*d+u*(u+2*c)+l;else u<=-x?(d=Math.max(0,-(-o*r+a)),u=d>0?-r:Math.min(Math.max(-r,-c),r),m=-d*d+u*(u+2*c)+l):u<=x?(d=0,u=Math.min(Math.max(-r,-c),r),m=u*(u+2*c)+l):(d=Math.max(0,-(o*r+a)),u=d>0?r:Math.min(Math.max(-r,-c),r),m=-d*d+u*(u+2*c)+l);else u=o>0?-r:r,d=Math.max(0,-(o*u+a)),m=-d*d+u*(u+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),i&&i.copy(_a).addScaledVector(kr,u),m}intersectSphere(t,e){Xn.subVectors(t.center,this.origin);const n=Xn.dot(this.direction),i=Xn.dot(Xn)-n*n,r=t.radius*t.radius;if(i>r)return null;const o=Math.sqrt(r-i),a=n-o,c=n+o;return c<0?null:a<0?this.at(c,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,o,a,c;const l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(n=(t.min.x-u.x)*l,i=(t.max.x-u.x)*l):(n=(t.max.x-u.x)*l,i=(t.min.x-u.x)*l),h>=0?(r=(t.min.y-u.y)*h,o=(t.max.y-u.y)*h):(r=(t.max.y-u.y)*h,o=(t.min.y-u.y)*h),n>o||r>i||((r>n||isNaN(n))&&(n=r),(o<i||isNaN(i))&&(i=o),d>=0?(a=(t.min.z-u.z)*d,c=(t.max.z-u.z)*d):(a=(t.max.z-u.z)*d,c=(t.min.z-u.z)*d),n>c||a>i)||((a>n||n!==n)&&(n=a),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Xn)!==null}intersectTriangle(t,e,n,i,r){va.subVectors(e,t),Gr.subVectors(n,t),ba.crossVectors(va,Gr);let o=this.direction.dot(ba),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;mi.subVectors(this.origin,t);const c=a*this.direction.dot(Gr.crossVectors(mi,Gr));if(c<0)return null;const l=a*this.direction.dot(va.cross(mi));if(l<0||c+l>o)return null;const h=-a*mi.dot(ba);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}};class Me{constructor(t,e,n,i,r,o,a,c,l,h,d,u,m,x,g,p){Me.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l,h,d,u,m,x,g,p)}set(t,e,n,i,r,o,a,c,l,h,d,u,m,x,g,p){const f=this.elements;return f[0]=t,f[4]=e,f[8]=n,f[12]=i,f[1]=r,f[5]=o,f[9]=a,f[13]=c,f[2]=l,f[6]=h,f[10]=d,f[14]=u,f[3]=m,f[7]=x,f[11]=g,f[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Me().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/gs.setFromMatrixColumn(t,0).length(),r=1/gs.setFromMatrixColumn(t,1).length(),o=1/gs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(r),d=Math.sin(r);if(t.order==="XYZ"){const u=o*h,m=o*d,x=a*h,g=a*d;e[0]=c*h,e[4]=-c*d,e[8]=l,e[1]=m+x*l,e[5]=u-g*l,e[9]=-a*c,e[2]=g-u*l,e[6]=x+m*l,e[10]=o*c}else if(t.order==="YXZ"){const u=c*h,m=c*d,x=l*h,g=l*d;e[0]=u+g*a,e[4]=x*a-m,e[8]=o*l,e[1]=o*d,e[5]=o*h,e[9]=-a,e[2]=m*a-x,e[6]=g+u*a,e[10]=o*c}else if(t.order==="ZXY"){const u=c*h,m=c*d,x=l*h,g=l*d;e[0]=u-g*a,e[4]=-o*d,e[8]=x+m*a,e[1]=m+x*a,e[5]=o*h,e[9]=g-u*a,e[2]=-o*l,e[6]=a,e[10]=o*c}else if(t.order==="ZYX"){const u=o*h,m=o*d,x=a*h,g=a*d;e[0]=c*h,e[4]=x*l-m,e[8]=u*l+g,e[1]=c*d,e[5]=g*l+u,e[9]=m*l-x,e[2]=-l,e[6]=a*c,e[10]=o*c}else if(t.order==="YZX"){const u=o*c,m=o*l,x=a*c,g=a*l;e[0]=c*h,e[4]=g-u*d,e[8]=x*d+m,e[1]=d,e[5]=o*h,e[9]=-a*h,e[2]=-l*h,e[6]=m*d+x,e[10]=u-g*d}else if(t.order==="XZY"){const u=o*c,m=o*l,x=a*c,g=a*l;e[0]=c*h,e[4]=-d,e[8]=l*h,e[1]=u*d+g,e[5]=o*h,e[9]=m*d-x,e[2]=x*d-m,e[6]=a*h,e[10]=g*d+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(fp,t,pp)}lookAt(t,e,n){const i=this.elements;return cn.subVectors(t,e),cn.lengthSq()===0&&(cn.z=1),cn.normalize(),xi.crossVectors(n,cn),xi.lengthSq()===0&&(Math.abs(n.z)===1?cn.x+=1e-4:cn.z+=1e-4,cn.normalize(),xi.crossVectors(n,cn)),xi.normalize(),Hr.crossVectors(cn,xi),i[0]=xi.x,i[4]=Hr.x,i[8]=cn.x,i[1]=xi.y,i[5]=Hr.y,i[9]=cn.y,i[2]=xi.z,i[6]=Hr.z,i[10]=cn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[4],c=n[8],l=n[12],h=n[1],d=n[5],u=n[9],m=n[13],x=n[2],g=n[6],p=n[10],f=n[14],M=n[3],_=n[7],v=n[11],b=n[15],S=i[0],T=i[4],P=i[8],A=i[12],E=i[1],C=i[5],D=i[9],O=i[13],H=i[2],W=i[6],$=i[10],G=i[14],V=i[3],Y=i[7],st=i[11],St=i[15];return r[0]=o*S+a*E+c*H+l*V,r[4]=o*T+a*C+c*W+l*Y,r[8]=o*P+a*D+c*$+l*st,r[12]=o*A+a*O+c*G+l*St,r[1]=h*S+d*E+u*H+m*V,r[5]=h*T+d*C+u*W+m*Y,r[9]=h*P+d*D+u*$+m*st,r[13]=h*A+d*O+u*G+m*St,r[2]=x*S+g*E+p*H+f*V,r[6]=x*T+g*C+p*W+f*Y,r[10]=x*P+g*D+p*$+f*st,r[14]=x*A+g*O+p*G+f*St,r[3]=M*S+_*E+v*H+b*V,r[7]=M*T+_*C+v*W+b*Y,r[11]=M*P+_*D+v*$+b*st,r[15]=M*A+_*O+v*G+b*St,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],o=t[1],a=t[5],c=t[9],l=t[13],h=t[2],d=t[6],u=t[10],m=t[14],x=t[3],g=t[7],p=t[11],f=t[15];return x*(+r*c*d-i*l*d-r*a*u+n*l*u+i*a*m-n*c*m)+g*(+e*c*m-e*l*u+r*o*u-i*o*m+i*l*h-r*c*h)+p*(+e*l*d-e*a*m-r*o*d+n*o*m+r*a*h-n*l*h)+f*(-i*a*h-e*c*d+e*a*u+i*o*d-n*o*u+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],d=t[9],u=t[10],m=t[11],x=t[12],g=t[13],p=t[14],f=t[15],M=d*p*l-g*u*l+g*c*m-a*p*m-d*c*f+a*u*f,_=x*u*l-h*p*l-x*c*m+o*p*m+h*c*f-o*u*f,v=h*g*l-x*d*l+x*a*m-o*g*m-h*a*f+o*d*f,b=x*d*c-h*g*c-x*a*u+o*g*u+h*a*p-o*d*p,S=e*M+n*_+i*v+r*b;if(S===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const T=1/S;return t[0]=M*T,t[1]=(g*u*r-d*p*r-g*i*m+n*p*m+d*i*f-n*u*f)*T,t[2]=(a*p*r-g*c*r+g*i*l-n*p*l-a*i*f+n*c*f)*T,t[3]=(d*c*r-a*u*r-d*i*l+n*u*l+a*i*m-n*c*m)*T,t[4]=_*T,t[5]=(h*p*r-x*u*r+x*i*m-e*p*m-h*i*f+e*u*f)*T,t[6]=(x*c*r-o*p*r-x*i*l+e*p*l+o*i*f-e*c*f)*T,t[7]=(o*u*r-h*c*r+h*i*l-e*u*l-o*i*m+e*c*m)*T,t[8]=v*T,t[9]=(x*d*r-h*g*r-x*n*m+e*g*m+h*n*f-e*d*f)*T,t[10]=(o*g*r-x*a*r+x*n*l-e*g*l-o*n*f+e*a*f)*T,t[11]=(h*a*r-o*d*r-h*n*l+e*d*l+o*n*m-e*a*m)*T,t[12]=b*T,t[13]=(h*g*i-x*d*i+x*n*u-e*g*u-h*n*p+e*d*p)*T,t[14]=(x*a*i-o*g*i-x*n*c+e*g*c+o*n*p-e*a*p)*T,t[15]=(o*d*i-h*a*i+h*n*c-e*d*c-o*n*u+e*a*u)*T,this}scale(t){const e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),r=1-n,o=t.x,a=t.y,c=t.z,l=r*o,h=r*a;return this.set(l*o+n,l*a-i*c,l*c+i*a,0,l*a+i*c,h*a+n,h*c-i*o,0,l*c-i*a,h*c+i*o,r*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,o){return this.set(1,n,r,0,t,1,o,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,r=e._x,o=e._y,a=e._z,c=e._w,l=r+r,h=o+o,d=a+a,u=r*l,m=r*h,x=r*d,g=o*h,p=o*d,f=a*d,M=c*l,_=c*h,v=c*d,b=n.x,S=n.y,T=n.z;return i[0]=(1-(g+f))*b,i[1]=(m+v)*b,i[2]=(x-_)*b,i[3]=0,i[4]=(m-v)*S,i[5]=(1-(u+f))*S,i[6]=(p+M)*S,i[7]=0,i[8]=(x+_)*T,i[9]=(p-M)*T,i[10]=(1-(u+g))*T,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let r=gs.set(i[0],i[1],i[2]).length();const o=gs.set(i[4],i[5],i[6]).length(),a=gs.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],wn.copy(this);const l=1/r,h=1/o,d=1/a;return wn.elements[0]*=l,wn.elements[1]*=l,wn.elements[2]*=l,wn.elements[4]*=h,wn.elements[5]*=h,wn.elements[6]*=h,wn.elements[8]*=d,wn.elements[9]*=d,wn.elements[10]*=d,e.setFromRotationMatrix(wn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,i,r,o,a=Vn,c=!1){const l=this.elements,h=2*r/(e-t),d=2*r/(n-i),u=(e+t)/(e-t),m=(n+i)/(n-i);let x,g;if(c)x=r/(o-r),g=o*r/(o-r);else if(a===Vn)x=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===zo)x=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=d,l[9]=m,l[13]=0,l[2]=0,l[6]=0,l[10]=x,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,o,a=Vn,c=!1){const l=this.elements,h=2/(e-t),d=2/(n-i),u=-(e+t)/(e-t),m=-(n+i)/(n-i);let x,g;if(c)x=1/(o-r),g=o/(o-r);else if(a===Vn)x=-2/(o-r),g=-(o+r)/(o-r);else if(a===zo)x=-1/(o-r),g=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=0,l[12]=u,l[1]=0,l[5]=d,l[9]=0,l[13]=m,l[2]=0,l[6]=0,l[10]=x,l[14]=g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const gs=new B,wn=new Me,fp=new B(0,0,0),pp=new B(1,1,1),xi=new B,Hr=new B,cn=new B,hh=new Me,dh=new Ui;class li{constructor(t=0,e=0,n=0,i=li.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,r=i[0],o=i[4],a=i[8],c=i[1],l=i[5],h=i[9],d=i[2],u=i[6],m=i[10];switch(e){case"XYZ":this._y=Math.asin(Jt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,m),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Jt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,m),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(Jt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,m),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Jt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,m),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(Jt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(a,m));break;case"XZY":this._z=Math.asin(-Jt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,m),this._y=0);break;default:Ht("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return hh.makeRotationFromQuaternion(t),this.setFromRotationMatrix(hh,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return dh.setFromEuler(this),this.setFromQuaternion(dh,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}li.DEFAULT_ORDER="XYZ";class yl{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let mp=0;const uh=new B,_s=new Ui,qn=new Me,Wr=new B,Js=new B,xp=new B,gp=new Ui,fh=new B(1,0,0),ph=new B(0,1,0),mh=new B(0,0,1),xh={type:"added"},_p={type:"removed"},vs={type:"childadded",child:null},Ma={type:"childremoved",child:null};class ge extends ls{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:mp++}),this.uuid=Ir(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ge.DEFAULT_UP.clone();const t=new B,e=new li,n=new Ui,i=new B(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Me},normalMatrix:{value:new Xt}}),this.matrix=new Me,this.matrixWorld=new Me,this.matrixAutoUpdate=ge.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ge.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new yl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return _s.setFromAxisAngle(t,e),this.quaternion.multiply(_s),this}rotateOnWorldAxis(t,e){return _s.setFromAxisAngle(t,e),this.quaternion.premultiply(_s),this}rotateX(t){return this.rotateOnAxis(fh,t)}rotateY(t){return this.rotateOnAxis(ph,t)}rotateZ(t){return this.rotateOnAxis(mh,t)}translateOnAxis(t,e){return uh.copy(t).applyQuaternion(this.quaternion),this.position.add(uh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(fh,t)}translateY(t){return this.translateOnAxis(ph,t)}translateZ(t){return this.translateOnAxis(mh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(qn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Wr.copy(t):Wr.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Js.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?qn.lookAt(Js,Wr,this.up):qn.lookAt(Wr,Js,this.up),this.quaternion.setFromRotationMatrix(qn),i&&(qn.extractRotation(i.matrixWorld),_s.setFromRotationMatrix(qn),this.quaternion.premultiply(_s.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(Pe("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(xh),vs.child=t,this.dispatchEvent(vs),vs.child=null):Pe("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(_p),Ma.child=t,this.dispatchEvent(Ma),Ma.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),qn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),qn.multiply(t.parent.matrixWorld)),t.applyMatrix4(qn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(xh),vs.child=t,this.dispatchEvent(vs),vs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Js,t,xp),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Js,gp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(a=>({...a})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const d=c[l];r(t.shapes,d)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(t.materials,this.material[c]));i.material=a}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];i.animations.push(r(t.animations,c))}}if(e){const a=o(t.geometries),c=o(t.materials),l=o(t.textures),h=o(t.images),d=o(t.shapes),u=o(t.skeletons),m=o(t.animations),x=o(t.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),m.length>0&&(n.animations=m),x.length>0&&(n.nodes=x)}return n.object=i,n;function o(a){const c=[];for(const l in a){const h=a[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}ge.DEFAULT_UP=new B(0,1,0);ge.DEFAULT_MATRIX_AUTO_UPDATE=!0;ge.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Tn=new B,Yn=new B,Sa=new B,$n=new B,bs=new B,Ms=new B,gh=new B,ya=new B,Ea=new B,Aa=new B,wa=new Le,Ta=new Le,Ca=new Le;class Ln{constructor(t=new B,e=new B,n=new B){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),Tn.subVectors(t,e),i.cross(Tn);const r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){Tn.subVectors(i,e),Yn.subVectors(n,e),Sa.subVectors(t,e);const o=Tn.dot(Tn),a=Tn.dot(Yn),c=Tn.dot(Sa),l=Yn.dot(Yn),h=Yn.dot(Sa),d=o*l-a*a;if(d===0)return r.set(0,0,0),null;const u=1/d,m=(l*c-a*h)*u,x=(o*h-a*c)*u;return r.set(1-m-x,x,m)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,$n)===null?!1:$n.x>=0&&$n.y>=0&&$n.x+$n.y<=1}static getInterpolation(t,e,n,i,r,o,a,c){return this.getBarycoord(t,e,n,i,$n)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,$n.x),c.addScaledVector(o,$n.y),c.addScaledVector(a,$n.z),c)}static getInterpolatedAttribute(t,e,n,i,r,o){return wa.setScalar(0),Ta.setScalar(0),Ca.setScalar(0),wa.fromBufferAttribute(t,e),Ta.fromBufferAttribute(t,n),Ca.fromBufferAttribute(t,i),o.setScalar(0),o.addScaledVector(wa,r.x),o.addScaledVector(Ta,r.y),o.addScaledVector(Ca,r.z),o}static isFrontFacing(t,e,n,i){return Tn.subVectors(n,e),Yn.subVectors(t,e),Tn.cross(Yn).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Tn.subVectors(this.c,this.b),Yn.subVectors(this.a,this.b),Tn.cross(Yn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ln.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return Ln.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return Ln.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return Ln.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ln.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,r=this.c;let o,a;bs.subVectors(i,n),Ms.subVectors(r,n),ya.subVectors(t,n);const c=bs.dot(ya),l=Ms.dot(ya);if(c<=0&&l<=0)return e.copy(n);Ea.subVectors(t,i);const h=bs.dot(Ea),d=Ms.dot(Ea);if(h>=0&&d<=h)return e.copy(i);const u=c*d-h*l;if(u<=0&&c>=0&&h<=0)return o=c/(c-h),e.copy(n).addScaledVector(bs,o);Aa.subVectors(t,r);const m=bs.dot(Aa),x=Ms.dot(Aa);if(x>=0&&m<=x)return e.copy(r);const g=m*l-c*x;if(g<=0&&l>=0&&x<=0)return a=l/(l-x),e.copy(n).addScaledVector(Ms,a);const p=h*x-m*d;if(p<=0&&d-h>=0&&m-x>=0)return gh.subVectors(r,i),a=(d-h)/(d-h+(m-x)),e.copy(i).addScaledVector(gh,a);const f=1/(p+g+u);return o=g*f,a=u*f,e.copy(n).addScaledVector(bs,o).addScaledVector(Ms,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const gu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},gi={h:0,s:0,l:0},Xr={h:0,s:0,l:0};function Ra(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}class se{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=bn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,oe.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=oe.workingColorSpace){return this.r=t,this.g=e,this.b=n,oe.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=oe.workingColorSpace){if(t=sp(t,1),e=Jt(e,0,1),n=Jt(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=Ra(o,r,t+1/3),this.g=Ra(o,r,t),this.b=Ra(o,r,t-1/3)}return oe.colorSpaceToWorking(this,i),this}setStyle(t,e=bn){function n(r){r!==void 0&&parseFloat(r)<1&&Ht("Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:Ht("Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=i[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);Ht("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=bn){const n=gu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Ht("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=ai(t.r),this.g=ai(t.g),this.b=ai(t.b),this}copyLinearToSRGB(t){return this.r=Os(t.r),this.g=Os(t.g),this.b=Os(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=bn){return oe.workingToColorSpace(ke.copy(this),t),Math.round(Jt(ke.r*255,0,255))*65536+Math.round(Jt(ke.g*255,0,255))*256+Math.round(Jt(ke.b*255,0,255))}getHexString(t=bn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=oe.workingColorSpace){oe.workingToColorSpace(ke.copy(this),e);const n=ke.r,i=ke.g,r=ke.b,o=Math.max(n,i,r),a=Math.min(n,i,r);let c,l;const h=(a+o)/2;if(a===o)c=0,l=0;else{const d=o-a;switch(l=h<=.5?d/(o+a):d/(2-o-a),o){case n:c=(i-r)/d+(i<r?6:0);break;case i:c=(r-n)/d+2;break;case r:c=(n-i)/d+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=oe.workingColorSpace){return oe.workingToColorSpace(ke.copy(this),e),t.r=ke.r,t.g=ke.g,t.b=ke.b,t}getStyle(t=bn){oe.workingToColorSpace(ke.copy(this),t);const e=ke.r,n=ke.g,i=ke.b;return t!==bn?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(gi),this.setHSL(gi.h+t,gi.s+e,gi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(gi),t.getHSL(Xr);const n=da(gi.h,Xr.h,e),i=da(gi.s,Xr.s,e),r=da(gi.l,Xr.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const ke=new se;se.NAMES=gu;let vp=0,Qo=class extends ls{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:vp++}),this.uuid=Ir(),this.name="",this.type="Material",this.blending=Ns,this.side=Fi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ac,this.blendDst=cc,this.blendEquation=es,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new se(0,0,0),this.blendAlpha=0,this.depthFunc=Bs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=nh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=us,this.stencilZFail=us,this.stencilZPass=us,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){Ht(`Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){Ht(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ns&&(n.blending=this.blending),this.side!==Fi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==ac&&(n.blendSrc=this.blendSrc),this.blendDst!==cc&&(n.blendDst=this.blendDst),this.blendEquation!==es&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Bs&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==nh&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==us&&(n.stencilFail=this.stencilFail),this.stencilZFail!==us&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==us&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(e){const r=i(t.textures),o=i(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}};class rn extends Qo{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new se(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new li,this.combine=ou,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Ie=new B,qr=new zt;let bp=0;class Dn{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:bp++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=ih,this.updateRanges=[],this.gpuType=zn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)qr.fromBufferAttribute(this,e),qr.applyMatrix3(t),this.setXY(e,qr.x,qr.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyMatrix3(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyMatrix4(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyNormalMatrix(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.transformDirection(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ks(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Je(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ks(e,this.array)),e}setX(t,e){return this.normalized&&(e=Je(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ks(e,this.array)),e}setY(t,e){return this.normalized&&(e=Je(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ks(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Je(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ks(e,this.array)),e}setW(t,e){return this.normalized&&(e=Je(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Je(e,this.array),n=Je(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=Je(e,this.array),n=Je(n,this.array),i=Je(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=Je(e,this.array),n=Je(n,this.array),i=Je(i,this.array),r=Je(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==ih&&(t.usage=this.usage),t}}class _u extends Dn{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class vu extends Dn{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class We extends Dn{constructor(t,e,n){super(new Float32Array(t),e,n)}}let Mp=0;const xn=new Me,Pa=new ge,Ss=new B,ln=new hs,Qs=new hs,Ne=new B;class Fn extends ls{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Mp++}),this.uuid=Ir(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(mu(t)?vu:_u)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Xt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return xn.makeRotationFromQuaternion(t),this.applyMatrix4(xn),this}rotateX(t){return xn.makeRotationX(t),this.applyMatrix4(xn),this}rotateY(t){return xn.makeRotationY(t),this.applyMatrix4(xn),this}rotateZ(t){return xn.makeRotationZ(t),this.applyMatrix4(xn),this}translate(t,e,n){return xn.makeTranslation(t,e,n),this.applyMatrix4(xn),this}scale(t,e,n){return xn.makeScale(t,e,n),this.applyMatrix4(xn),this}lookAt(t){return Pa.lookAt(t),Pa.updateMatrix(),this.applyMatrix4(Pa.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ss).negate(),this.translate(Ss.x,Ss.y,Ss.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let i=0,r=t.length;i<r;i++){const o=t[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new We(n,3))}else{const n=Math.min(t.length,e.count);for(let i=0;i<n;i++){const r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&Ht("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new hs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Pe("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new B(-1/0,-1/0,-1/0),new B(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const r=e[n];ln.setFromBufferAttribute(r),this.morphTargetsRelative?(Ne.addVectors(this.boundingBox.min,ln.min),this.boundingBox.expandByPoint(Ne),Ne.addVectors(this.boundingBox.max,ln.max),this.boundingBox.expandByPoint(Ne)):(this.boundingBox.expandByPoint(ln.min),this.boundingBox.expandByPoint(ln.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Pe('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Dr);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Pe("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new B,1/0);return}if(t){const n=this.boundingSphere.center;if(ln.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){const a=e[r];Qs.setFromBufferAttribute(a),this.morphTargetsRelative?(Ne.addVectors(ln.min,Qs.min),ln.expandByPoint(Ne),Ne.addVectors(ln.max,Qs.max),ln.expandByPoint(Ne)):(ln.expandByPoint(Qs.min),ln.expandByPoint(Qs.max))}ln.getCenter(n);let i=0;for(let r=0,o=t.count;r<o;r++)Ne.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Ne));if(e)for(let r=0,o=e.length;r<o;r++){const a=e[r],c=this.morphTargetsRelative;for(let l=0,h=a.count;l<h;l++)Ne.fromBufferAttribute(a,l),c&&(Ss.fromBufferAttribute(t,l),Ne.add(Ss)),i=Math.max(i,n.distanceToSquared(Ne))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&Pe('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){Pe("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Dn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let P=0;P<n.count;P++)a[P]=new B,c[P]=new B;const l=new B,h=new B,d=new B,u=new zt,m=new zt,x=new zt,g=new B,p=new B;function f(P,A,E){l.fromBufferAttribute(n,P),h.fromBufferAttribute(n,A),d.fromBufferAttribute(n,E),u.fromBufferAttribute(r,P),m.fromBufferAttribute(r,A),x.fromBufferAttribute(r,E),h.sub(l),d.sub(l),m.sub(u),x.sub(u);const C=1/(m.x*x.y-x.x*m.y);isFinite(C)&&(g.copy(h).multiplyScalar(x.y).addScaledVector(d,-m.y).multiplyScalar(C),p.copy(d).multiplyScalar(m.x).addScaledVector(h,-x.x).multiplyScalar(C),a[P].add(g),a[A].add(g),a[E].add(g),c[P].add(p),c[A].add(p),c[E].add(p))}let M=this.groups;M.length===0&&(M=[{start:0,count:t.count}]);for(let P=0,A=M.length;P<A;++P){const E=M[P],C=E.start,D=E.count;for(let O=C,H=C+D;O<H;O+=3)f(t.getX(O+0),t.getX(O+1),t.getX(O+2))}const _=new B,v=new B,b=new B,S=new B;function T(P){b.fromBufferAttribute(i,P),S.copy(b);const A=a[P];_.copy(A),_.sub(b.multiplyScalar(b.dot(A))).normalize(),v.crossVectors(S,A);const C=v.dot(c[P])<0?-1:1;o.setXYZW(P,_.x,_.y,_.z,C)}for(let P=0,A=M.length;P<A;++P){const E=M[P],C=E.start,D=E.count;for(let O=C,H=C+D;O<H;O+=3)T(t.getX(O+0)),T(t.getX(O+1)),T(t.getX(O+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Dn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,m=n.count;u<m;u++)n.setXYZ(u,0,0,0);const i=new B,r=new B,o=new B,a=new B,c=new B,l=new B,h=new B,d=new B;if(t)for(let u=0,m=t.count;u<m;u+=3){const x=t.getX(u+0),g=t.getX(u+1),p=t.getX(u+2);i.fromBufferAttribute(e,x),r.fromBufferAttribute(e,g),o.fromBufferAttribute(e,p),h.subVectors(o,r),d.subVectors(i,r),h.cross(d),a.fromBufferAttribute(n,x),c.fromBufferAttribute(n,g),l.fromBufferAttribute(n,p),a.add(h),c.add(h),l.add(h),n.setXYZ(x,a.x,a.y,a.z),n.setXYZ(g,c.x,c.y,c.z),n.setXYZ(p,l.x,l.y,l.z)}else for(let u=0,m=e.count;u<m;u+=3)i.fromBufferAttribute(e,u+0),r.fromBufferAttribute(e,u+1),o.fromBufferAttribute(e,u+2),h.subVectors(o,r),d.subVectors(i,r),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Ne.fromBufferAttribute(t,e),Ne.normalize(),t.setXYZ(e,Ne.x,Ne.y,Ne.z)}toNonIndexed(){function t(a,c){const l=a.array,h=a.itemSize,d=a.normalized,u=new l.constructor(c.length*h);let m=0,x=0;for(let g=0,p=c.length;g<p;g++){a.isInterleavedBufferAttribute?m=c[g]*a.data.stride+a.offset:m=c[g]*h;for(let f=0;f<h;f++)u[x++]=l[m++]}return new Dn(u,h,d)}if(this.index===null)return Ht("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Fn,n=this.index.array,i=this.attributes;for(const a in i){const c=i[a],l=t(c,n);e.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let h=0,d=l.length;h<d;h++){const u=l[h],m=t(u,n);c.push(m)}e.morphAttributes[a]=c}e.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){const m=l[d];h.push(m.toJSON(t.data))}h.length>0&&(i[c]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const r=t.morphAttributes;for(const l in r){const h=[],d=r[l];for(let u=0,m=d.length;u<m;u++)h.push(d[u].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const o=t.groups;for(let l=0,h=o.length;l<h;l++){const d=o[l];this.addGroup(d.start,d.count,d.materialIndex)}const a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const _h=new Me,ki=new Sl,Yr=new Dr,vh=new B,$r=new B,Kr=new B,Zr=new B,La=new B,jr=new B,bh=new B,Jr=new B;class sn extends ge{constructor(t=new Fn,e=new rn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){const a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const a=this.morphTargetInfluences;if(r&&a){jr.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const h=a[c],d=r[c];h!==0&&(La.fromBufferAttribute(d,t),o?jr.addScaledVector(La,h):jr.addScaledVector(La.sub(e),h))}e.add(jr)}return e}raycast(t,e){const n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Yr.copy(n.boundingSphere),Yr.applyMatrix4(r),ki.copy(t.ray).recast(t.near),!(Yr.containsPoint(ki.origin)===!1&&(ki.intersectSphere(Yr,vh)===null||ki.origin.distanceToSquared(vh)>(t.far-t.near)**2))&&(_h.copy(r).invert(),ki.copy(t.ray).applyMatrix4(_h),!(n.boundingBox!==null&&ki.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ki)))}_computeIntersections(t,e,n){let i;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,d=r.attributes.normal,u=r.groups,m=r.drawRange;if(a!==null)if(Array.isArray(o))for(let x=0,g=u.length;x<g;x++){const p=u[x],f=o[p.materialIndex],M=Math.max(p.start,m.start),_=Math.min(a.count,Math.min(p.start+p.count,m.start+m.count));for(let v=M,b=_;v<b;v+=3){const S=a.getX(v),T=a.getX(v+1),P=a.getX(v+2);i=Qr(this,f,t,n,l,h,d,S,T,P),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=p.materialIndex,e.push(i))}}else{const x=Math.max(0,m.start),g=Math.min(a.count,m.start+m.count);for(let p=x,f=g;p<f;p+=3){const M=a.getX(p),_=a.getX(p+1),v=a.getX(p+2);i=Qr(this,o,t,n,l,h,d,M,_,v),i&&(i.faceIndex=Math.floor(p/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(o))for(let x=0,g=u.length;x<g;x++){const p=u[x],f=o[p.materialIndex],M=Math.max(p.start,m.start),_=Math.min(c.count,Math.min(p.start+p.count,m.start+m.count));for(let v=M,b=_;v<b;v+=3){const S=v,T=v+1,P=v+2;i=Qr(this,f,t,n,l,h,d,S,T,P),i&&(i.faceIndex=Math.floor(v/3),i.face.materialIndex=p.materialIndex,e.push(i))}}else{const x=Math.max(0,m.start),g=Math.min(c.count,m.start+m.count);for(let p=x,f=g;p<f;p+=3){const M=p,_=p+1,v=p+2;i=Qr(this,o,t,n,l,h,d,M,_,v),i&&(i.faceIndex=Math.floor(p/3),e.push(i))}}}}function Sp(s,t,e,n,i,r,o,a){let c;if(t.side===Ke?c=n.intersectTriangle(o,r,i,!0,a):c=n.intersectTriangle(i,r,o,t.side===Fi,a),c===null)return null;Jr.copy(a),Jr.applyMatrix4(s.matrixWorld);const l=e.ray.origin.distanceTo(Jr);return l<e.near||l>e.far?null:{distance:l,point:Jr.clone(),object:s}}function Qr(s,t,e,n,i,r,o,a,c,l){s.getVertexPosition(a,$r),s.getVertexPosition(c,Kr),s.getVertexPosition(l,Zr);const h=Sp(s,t,e,n,$r,Kr,Zr,bh);if(h){const d=new B;Ln.getBarycoord(bh,$r,Kr,Zr,d),i&&(h.uv=Ln.getInterpolatedAttribute(i,a,c,l,d,new zt)),r&&(h.uv1=Ln.getInterpolatedAttribute(r,a,c,l,d,new zt)),o&&(h.normal=Ln.getInterpolatedAttribute(o,a,c,l,d,new B),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const u={a,b:c,c:l,normal:new B,materialIndex:0};Ln.getNormal($r,Kr,Zr,u.normal),h.face=u,h.barycoord=d}return h}class un extends Fn{constructor(t=1,e=1,n=1,i=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:o};const a=this;i=Math.floor(i),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],h=[],d=[];let u=0,m=0;x("z","y","x",-1,-1,n,e,t,o,r,0),x("z","y","x",1,-1,n,e,-t,o,r,1),x("x","z","y",1,1,t,n,e,i,o,2),x("x","z","y",1,-1,t,n,-e,i,o,3),x("x","y","z",1,-1,t,e,n,i,r,4),x("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(c),this.setAttribute("position",new We(l,3)),this.setAttribute("normal",new We(h,3)),this.setAttribute("uv",new We(d,2));function x(g,p,f,M,_,v,b,S,T,P,A){const E=v/T,C=b/P,D=v/2,O=b/2,H=S/2,W=T+1,$=P+1;let G=0,V=0;const Y=new B;for(let st=0;st<$;st++){const St=st*C-O;for(let kt=0;kt<W;kt++){const qt=kt*E-D;Y[g]=qt*M,Y[p]=St*_,Y[f]=H,l.push(Y.x,Y.y,Y.z),Y[g]=0,Y[p]=0,Y[f]=S>0?1:-1,h.push(Y.x,Y.y,Y.z),d.push(kt/T),d.push(1-st/P),G+=1}}for(let st=0;st<P;st++)for(let St=0;St<T;St++){const kt=u+St+W*st,qt=u+St+W*(st+1),ce=u+(St+1)+W*(st+1),le=u+(St+1)+W*st;c.push(kt,qt,le),c.push(qt,ce,le),V+=6}a.addGroup(m,V,A),m+=V,u+=G}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new un(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Gs(s){const t={};for(const e in s){t[e]={};for(const n in s[e]){const i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(Ht("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function $e(s){const t={};for(let e=0;e<s.length;e++){const n=Gs(s[e]);for(const i in n)t[i]=n[i]}return t}function yp(s){const t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function bu(s){const t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:oe.workingColorSpace}const Ep={clone:Gs,merge:$e};var Ap=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,wp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Gn extends Qo{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Ap,this.fragmentShader=wp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Gs(t.uniforms),this.uniformsGroups=yp(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const o=this.uniforms[i].value;o&&o.isTexture?e.uniforms[i]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[i]={type:"m4",value:o.toArray()}:e.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}let Mu=class extends ge{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Me,this.projectionMatrix=new Me,this.projectionMatrixInverse=new Me,this.coordinateSystem=Vn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}};const _i=new B,Mh=new zt,Sh=new zt;class Sn extends Mu{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Yc*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Po*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Yc*2*Math.atan(Math.tan(Po*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){_i.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(_i.x,_i.y).multiplyScalar(-t/_i.z),_i.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(_i.x,_i.y).multiplyScalar(-t/_i.z)}getViewSize(t,e){return this.getViewBounds(t,Mh,Sh),e.subVectors(Sh,Mh)}setViewOffset(t,e,n,i,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Po*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*i/c,e-=o.offsetY*n/l,i*=o.width/c,n*=o.height/l}const a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const ys=-90,Es=1;class Tp extends ge{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Sn(ys,Es,t,e);i.layers=this.layers,this.add(i);const r=new Sn(ys,Es,t,e);r.layers=this.layers,this.add(r);const o=new Sn(ys,Es,t,e);o.layers=this.layers,this.add(o);const a=new Sn(ys,Es,t,e);a.layers=this.layers,this.add(a);const c=new Sn(ys,Es,t,e);c.layers=this.layers,this.add(c);const l=new Sn(ys,Es,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,r,o,a,c]=e;for(const l of e)this.remove(l);if(t===Vn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===zo)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,h]=this.children,d=t.getRenderTarget(),u=t.getActiveCubeFace(),m=t.getActiveMipmapLevel(),x=t.xr.enabled;t.xr.enabled=!1;const g=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,o),t.setRenderTarget(n,2,i),t.render(e,a),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=g,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(d,u,m),t.xr.enabled=x,n.texture.needsPMREMUpdate=!0}}class Su extends He{constructor(t=[],e=zs,n,i,r,o,a,c,l,h){super(t,e,n,i,r,o,a,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class Cp extends as{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new Su(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new un(5,5,5),r=new Gn({name:"CubemapFromEquirect",uniforms:Gs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ke,blending:oi});r.uniforms.tEquirect.value=e;const o=new sn(i,r),a=e.minFilter;return e.minFilter===ss&&(e.minFilter=en),new Tp(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){const r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,i);t.setRenderTarget(r)}}class fr extends ge{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Rp={type:"move"};class Ia{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new fr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new fr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new B,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new B),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new fr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new B,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new B),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){o=!0;for(const g of t.hand.values()){const p=e.getJointPose(g,n),f=this._getHandJoint(l,g);p!==null&&(f.matrix.fromArray(p.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=p.radius),f.visible=p!==null}const h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),m=.02,x=.005;l.inputState.pinching&&u>m+x?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&u<=m-x&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Rp)))}return a!==null&&(a.visible=i!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new fr;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class Pp extends ge{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new li,this.environmentIntensity=1,this.environmentRotation=new li,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}class yu extends He{constructor(t=null,e=1,n=1,i,r,o,a,c,l=pn,h=pn,d,u){super(null,o,a,c,l,h,i,r,d,u),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Hs extends Dn{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const As=new Me,yh=new Me,to=[],Eh=new hs,Lp=new Me,tr=new sn,er=new Dr;class ze extends sn{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Hs(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Lp)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new hs),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,As),Eh.copy(t.boundingBox).applyMatrix4(As),this.boundingBox.union(Eh)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Dr),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,As),er.copy(t.boundingSphere).applyMatrix4(As),this.boundingSphere.union(er)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=i[o+a]}raycast(t,e){const n=this.matrixWorld,i=this.count;if(tr.geometry=this.geometry,tr.material=this.material,tr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),er.copy(this.boundingSphere),er.applyMatrix4(n),t.ray.intersectsSphere(er)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,As),yh.multiplyMatrices(n,As),tr.matrixWorld=yh,tr.raycast(t,to);for(let o=0,a=to.length;o<a;o++){const c=to[o];c.instanceId=r,c.object=this,e.push(c)}to.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Hs(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){const n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new yu(new Float32Array(i*this.count),i,this.count,xl,zn));const r=this.morphTexture.source.data.data;let o=0;for(let l=0;l<n.length;l++)o+=n[l];const a=this.geometry.morphTargetsRelative?1:1-o,c=i*t;r[c]=a,r.set(n,c+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Da=new B,Ip=new B,Dp=new Xt;class Ai{constructor(t=new B(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Da.subVectors(n,e).cross(Ip.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Da),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||Dp.getNormalMatrix(t),i=this.coplanarPoint(Da).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Gi=new Dr,Fp=new zt(.5,.5),eo=new B;class Eu{constructor(t=new Ai,e=new Ai,n=new Ai,i=new Ai,r=new Ai,o=new Ai){this.planes=[t,e,n,i,r,o]}set(t,e,n,i,r,o){const a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(i),a[4].copy(r),a[5].copy(o),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Vn,n=!1){const i=this.planes,r=t.elements,o=r[0],a=r[1],c=r[2],l=r[3],h=r[4],d=r[5],u=r[6],m=r[7],x=r[8],g=r[9],p=r[10],f=r[11],M=r[12],_=r[13],v=r[14],b=r[15];if(i[0].setComponents(l-o,m-h,f-x,b-M).normalize(),i[1].setComponents(l+o,m+h,f+x,b+M).normalize(),i[2].setComponents(l+a,m+d,f+g,b+_).normalize(),i[3].setComponents(l-a,m-d,f-g,b-_).normalize(),n)i[4].setComponents(c,u,p,v).normalize(),i[5].setComponents(l-c,m-u,f-p,b-v).normalize();else if(i[4].setComponents(l-c,m-u,f-p,b-v).normalize(),e===Vn)i[5].setComponents(l+c,m+u,f+p,b+v).normalize();else if(e===zo)i[5].setComponents(c,u,p,v).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Gi.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Gi.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Gi)}intersectsSprite(t){Gi.center.set(0,0,0);const e=Fp.distanceTo(t.center);return Gi.radius=.7071067811865476+e,Gi.applyMatrix4(t.matrixWorld),this.intersectsSphere(Gi)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(eo.x=i.normal.x>0?t.max.x:t.min.x,eo.y=i.normal.y>0?t.max.y:t.min.y,eo.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(eo)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Up extends He{constructor(t,e,n,i,r,o,a,c,l){super(t,e,n,i,r,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Au extends He{constructor(t,e,n=os,i,r,o,a=pn,c=pn,l,h=Ar,d=1){if(h!==Ar&&h!==wr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const u={width:t,height:e,depth:d};super(u,i,r,o,a,c,h,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Ml(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}class wu extends He{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ta extends Fn{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const r=[],o=[],a=[],c=[],l=new B,h=new zt;o.push(0,0,0),a.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=e;d++,u+=3){const m=n+d/e*i;l.x=t*Math.cos(m),l.y=t*Math.sin(m),o.push(l.x,l.y,l.z),a.push(0,0,1),h.x=(o[u]/t+1)/2,h.y=(o[u+1]/t+1)/2,c.push(h.x,h.y)}for(let d=1;d<=e;d++)r.push(d,d+1,0);this.setIndex(r),this.setAttribute("position",new We(o,3)),this.setAttribute("normal",new We(a,3)),this.setAttribute("uv",new We(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ta(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class ui extends Fn{constructor(t=1,e=1,n=1,i=32,r=1,o=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:c};const l=this;i=Math.floor(i),r=Math.floor(r);const h=[],d=[],u=[],m=[];let x=0;const g=[],p=n/2;let f=0;M(),o===!1&&(t>0&&_(!0),e>0&&_(!1)),this.setIndex(h),this.setAttribute("position",new We(d,3)),this.setAttribute("normal",new We(u,3)),this.setAttribute("uv",new We(m,2));function M(){const v=new B,b=new B;let S=0;const T=(e-t)/n;for(let P=0;P<=r;P++){const A=[],E=P/r,C=E*(e-t)+t;for(let D=0;D<=i;D++){const O=D/i,H=O*c+a,W=Math.sin(H),$=Math.cos(H);b.x=C*W,b.y=-E*n+p,b.z=C*$,d.push(b.x,b.y,b.z),v.set(W,T,$).normalize(),u.push(v.x,v.y,v.z),m.push(O,1-E),A.push(x++)}g.push(A)}for(let P=0;P<i;P++)for(let A=0;A<r;A++){const E=g[A][P],C=g[A+1][P],D=g[A+1][P+1],O=g[A][P+1];(t>0||A!==0)&&(h.push(E,C,O),S+=3),(e>0||A!==r-1)&&(h.push(C,D,O),S+=3)}l.addGroup(f,S,0),f+=S}function _(v){const b=x,S=new zt,T=new B;let P=0;const A=v===!0?t:e,E=v===!0?1:-1;for(let D=1;D<=i;D++)d.push(0,p*E,0),u.push(0,E,0),m.push(.5,.5),x++;const C=x;for(let D=0;D<=i;D++){const H=D/i*c+a,W=Math.cos(H),$=Math.sin(H);T.x=A*$,T.y=p*E,T.z=A*W,d.push(T.x,T.y,T.z),u.push(0,E,0),S.x=W*.5+.5,S.y=$*.5*E+.5,m.push(S.x,S.y),x++}for(let D=0;D<i;D++){const O=b+D,H=C+D;v===!0?h.push(H,H+1,O):h.push(H+1,H,O),P+=3}l.addGroup(f,P,v===!0?1:2),f+=P}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ui(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Xs extends Fn{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const r=t/2,o=e/2,a=Math.floor(n),c=Math.floor(i),l=a+1,h=c+1,d=t/a,u=e/c,m=[],x=[],g=[],p=[];for(let f=0;f<h;f++){const M=f*u-o;for(let _=0;_<l;_++){const v=_*d-r;x.push(v,-M,0),g.push(0,0,1),p.push(_/a),p.push(1-f/c)}}for(let f=0;f<c;f++)for(let M=0;M<a;M++){const _=M+l*f,v=M+l*(f+1),b=M+1+l*(f+1),S=M+1+l*f;m.push(_,v,S),m.push(v,b,S)}this.setIndex(m),this.setAttribute("position",new We(x,3)),this.setAttribute("normal",new We(g,3)),this.setAttribute("uv",new We(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Xs(t.width,t.height,t.widthSegments,t.heightSegments)}}class ea extends Fn{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(o+a,Math.PI);let l=0;const h=[],d=new B,u=new B,m=[],x=[],g=[],p=[];for(let f=0;f<=n;f++){const M=[],_=f/n;let v=0;f===0&&o===0?v=.5/e:f===n&&c===Math.PI&&(v=-.5/e);for(let b=0;b<=e;b++){const S=b/e;d.x=-t*Math.cos(i+S*r)*Math.sin(o+_*a),d.y=t*Math.cos(o+_*a),d.z=t*Math.sin(i+S*r)*Math.sin(o+_*a),x.push(d.x,d.y,d.z),u.copy(d).normalize(),g.push(u.x,u.y,u.z),p.push(S+v,1-_),M.push(l++)}h.push(M)}for(let f=0;f<n;f++)for(let M=0;M<e;M++){const _=h[f][M+1],v=h[f][M],b=h[f+1][M],S=h[f+1][M+1];(f!==0||o>0)&&m.push(_,v,S),(f!==n-1||c<Math.PI)&&m.push(v,b,S)}this.setIndex(m),this.setAttribute("position",new We(x,3)),this.setAttribute("normal",new We(g,3)),this.setAttribute("uv",new We(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ea(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class Np extends Qo{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Xf,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class Op extends Qo{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class Bp extends Mu{constructor(t=-1,e=1,n=1,i=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let r=n-t,o=n+t,a=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=h*this.view.offsetY,c=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class zp extends Sn{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const Ah=new Me;class Vp{constructor(t,e,n=0,i=1/0){this.ray=new Sl(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new yl,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):Pe("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Ah.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Ah),this}intersectObject(t,e=!0,n=[]){return $c(t,this,n,e),n.sort(wh),n}intersectObjects(t,e=!0,n=[]){for(let i=0,r=t.length;i<r;i++)$c(t[i],this,n,e);return n.sort(wh),n}}function wh(s,t){return s.distance-t.distance}function $c(s,t,e,n){let i=!0;if(s.layers.test(t.layers)&&s.raycast(t,e)===!1&&(i=!1),i===!0&&n===!0){const r=s.children;for(let o=0,a=r.length;o<a;o++)$c(r[o],t,e,!0)}}class ko{constructor(t=1,e=0,n=0){this.radius=t,this.phi=e,this.theta=n}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Jt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(Jt(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class kp extends ls{constructor(t,e=null){super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(t){if(t===void 0){Ht("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=t}disconnect(){}dispose(){}update(){}}function Th(s,t,e,n){const i=Gp(n);switch(e){case uu:return s*t;case xl:return s*t/i.components*i.byteLength;case gl:return s*t/i.components*i.byteLength;case _l:return s*t*2/i.components*i.byteLength;case vl:return s*t*2/i.components*i.byteLength;case fu:return s*t*3/i.components*i.byteLength;case In:return s*t*4/i.components*i.byteLength;case bl:return s*t*4/i.components*i.byteLength;case wo:case To:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Co:case Ro:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case bc:case Sc:return Math.max(s,16)*Math.max(t,8)/4;case vc:case Mc:return Math.max(s,8)*Math.max(t,8)/2;case yc:case Ec:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Ac:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case wc:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Tc:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Cc:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case Rc:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case Pc:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case Lc:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case Ic:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case Dc:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case Fc:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case Uc:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case Nc:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case Oc:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case Bc:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case zc:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case Vc:case kc:case Gc:return Math.ceil(s/4)*Math.ceil(t/4)*16;case Hc:case Wc:return Math.ceil(s/4)*Math.ceil(t/4)*8;case Xc:case qc:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Gp(s){switch(s){case ci:case cu:return{byteLength:1,components:1};case yr:case lu:case Ws:return{byteLength:2,components:1};case pl:case ml:return{byteLength:2,components:4};case os:case fl:case zn:return{byteLength:4,components:1};case hu:case du:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:ul}}));typeof window<"u"&&(window.__THREE__?Ht("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=ul);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function Tu(){let s=null,t=!1,e=null,n=null;function i(r,o){e(r,o),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function Hp(s){const t=new WeakMap;function e(a,c){const l=a.array,h=a.usage,d=l.byteLength,u=s.createBuffer();s.bindBuffer(c,u),s.bufferData(c,l,h),a.onUploadCallback();let m;if(l instanceof Float32Array)m=s.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)m=s.HALF_FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?m=s.HALF_FLOAT:m=s.UNSIGNED_SHORT;else if(l instanceof Int16Array)m=s.SHORT;else if(l instanceof Uint32Array)m=s.UNSIGNED_INT;else if(l instanceof Int32Array)m=s.INT;else if(l instanceof Int8Array)m=s.BYTE;else if(l instanceof Uint8Array)m=s.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)m=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:u,type:m,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:d}}function n(a,c,l){const h=c.array,d=c.updateRanges;if(s.bindBuffer(l,a),d.length===0)s.bufferSubData(l,0,h);else{d.sort((m,x)=>m.start-x.start);let u=0;for(let m=1;m<d.length;m++){const x=d[u],g=d[m];g.start<=x.start+x.count+1?x.count=Math.max(x.count,g.start+g.count-x.start):(++u,d[u]=g)}d.length=u+1;for(let m=0,x=d.length;m<x;m++){const g=d[m];s.bufferSubData(l,g.start*h.BYTES_PER_ELEMENT,h,g.start,g.count)}c.clearUpdateRanges()}c.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=t.get(a);c&&(s.deleteBuffer(c.buffer),t.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=t.get(a);if(l===void 0)t.set(a,e(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:i,remove:r,update:o}}var Wp=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Xp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,qp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Yp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,$p=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Kp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Zp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,jp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Jp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Qp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,t0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,e0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,n0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,i0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,s0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,r0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,o0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,a0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,c0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,l0=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,h0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,d0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,u0=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,f0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,p0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,m0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,x0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,g0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,_0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,v0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,b0="gl_FragColor = linearToOutputTexel( gl_FragColor );",M0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,S0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,y0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,E0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,A0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,w0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,T0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,C0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,R0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,P0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,L0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,I0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,D0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,F0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,U0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,N0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,O0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,B0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,z0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,V0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,k0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,G0=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,H0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,W0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,X0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,q0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Y0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,$0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,K0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Z0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,j0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,J0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Q0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,tm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,em=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,nm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,im=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,sm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,rm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,om=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,am=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,cm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,lm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,hm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,dm=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,um=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,fm=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,pm=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,mm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,xm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,gm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,_m=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,vm=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,bm=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Mm=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Sm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,ym=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Em=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Am=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,wm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Tm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Cm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Rm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Pm=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Lm=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Im=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Dm=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Fm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Um=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Nm=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Om=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Bm=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,zm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Vm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,km=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Gm=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Hm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Wm=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,qm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ym=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,$m=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Km=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Zm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,jm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Jm=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Qm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,tx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,ex=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,nx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ix=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,sx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,rx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ox=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ax=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,cx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,lx=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,hx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,dx=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ux=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,fx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,px=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mx=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,xx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,gx=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,_x=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,vx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,bx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Mx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Sx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,$t={alphahash_fragment:Wp,alphahash_pars_fragment:Xp,alphamap_fragment:qp,alphamap_pars_fragment:Yp,alphatest_fragment:$p,alphatest_pars_fragment:Kp,aomap_fragment:Zp,aomap_pars_fragment:jp,batching_pars_vertex:Jp,batching_vertex:Qp,begin_vertex:t0,beginnormal_vertex:e0,bsdfs:n0,iridescence_fragment:i0,bumpmap_pars_fragment:s0,clipping_planes_fragment:r0,clipping_planes_pars_fragment:o0,clipping_planes_pars_vertex:a0,clipping_planes_vertex:c0,color_fragment:l0,color_pars_fragment:h0,color_pars_vertex:d0,color_vertex:u0,common:f0,cube_uv_reflection_fragment:p0,defaultnormal_vertex:m0,displacementmap_pars_vertex:x0,displacementmap_vertex:g0,emissivemap_fragment:_0,emissivemap_pars_fragment:v0,colorspace_fragment:b0,colorspace_pars_fragment:M0,envmap_fragment:S0,envmap_common_pars_fragment:y0,envmap_pars_fragment:E0,envmap_pars_vertex:A0,envmap_physical_pars_fragment:N0,envmap_vertex:w0,fog_vertex:T0,fog_pars_vertex:C0,fog_fragment:R0,fog_pars_fragment:P0,gradientmap_pars_fragment:L0,lightmap_pars_fragment:I0,lights_lambert_fragment:D0,lights_lambert_pars_fragment:F0,lights_pars_begin:U0,lights_toon_fragment:O0,lights_toon_pars_fragment:B0,lights_phong_fragment:z0,lights_phong_pars_fragment:V0,lights_physical_fragment:k0,lights_physical_pars_fragment:G0,lights_fragment_begin:H0,lights_fragment_maps:W0,lights_fragment_end:X0,logdepthbuf_fragment:q0,logdepthbuf_pars_fragment:Y0,logdepthbuf_pars_vertex:$0,logdepthbuf_vertex:K0,map_fragment:Z0,map_pars_fragment:j0,map_particle_fragment:J0,map_particle_pars_fragment:Q0,metalnessmap_fragment:tm,metalnessmap_pars_fragment:em,morphinstance_vertex:nm,morphcolor_vertex:im,morphnormal_vertex:sm,morphtarget_pars_vertex:rm,morphtarget_vertex:om,normal_fragment_begin:am,normal_fragment_maps:cm,normal_pars_fragment:lm,normal_pars_vertex:hm,normal_vertex:dm,normalmap_pars_fragment:um,clearcoat_normal_fragment_begin:fm,clearcoat_normal_fragment_maps:pm,clearcoat_pars_fragment:mm,iridescence_pars_fragment:xm,opaque_fragment:gm,packing:_m,premultiplied_alpha_fragment:vm,project_vertex:bm,dithering_fragment:Mm,dithering_pars_fragment:Sm,roughnessmap_fragment:ym,roughnessmap_pars_fragment:Em,shadowmap_pars_fragment:Am,shadowmap_pars_vertex:wm,shadowmap_vertex:Tm,shadowmask_pars_fragment:Cm,skinbase_vertex:Rm,skinning_pars_vertex:Pm,skinning_vertex:Lm,skinnormal_vertex:Im,specularmap_fragment:Dm,specularmap_pars_fragment:Fm,tonemapping_fragment:Um,tonemapping_pars_fragment:Nm,transmission_fragment:Om,transmission_pars_fragment:Bm,uv_pars_fragment:zm,uv_pars_vertex:Vm,uv_vertex:km,worldpos_vertex:Gm,background_vert:Hm,background_frag:Wm,backgroundCube_vert:Xm,backgroundCube_frag:qm,cube_vert:Ym,cube_frag:$m,depth_vert:Km,depth_frag:Zm,distanceRGBA_vert:jm,distanceRGBA_frag:Jm,equirect_vert:Qm,equirect_frag:tx,linedashed_vert:ex,linedashed_frag:nx,meshbasic_vert:ix,meshbasic_frag:sx,meshlambert_vert:rx,meshlambert_frag:ox,meshmatcap_vert:ax,meshmatcap_frag:cx,meshnormal_vert:lx,meshnormal_frag:hx,meshphong_vert:dx,meshphong_frag:ux,meshphysical_vert:fx,meshphysical_frag:px,meshtoon_vert:mx,meshtoon_frag:xx,points_vert:gx,points_frag:_x,shadow_vert:vx,shadow_frag:bx,sprite_vert:Mx,sprite_frag:Sx},lt={common:{diffuse:{value:new se(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xt}},envmap:{envMap:{value:null},envMapRotation:{value:new Xt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xt},normalScale:{value:new zt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new se(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new se(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0},uvTransform:{value:new Xt}},sprite:{diffuse:{value:new se(16777215)},opacity:{value:1},center:{value:new zt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}}},Bn={basic:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.fog]),vertexShader:$t.meshbasic_vert,fragmentShader:$t.meshbasic_frag},lambert:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new se(0)}}]),vertexShader:$t.meshlambert_vert,fragmentShader:$t.meshlambert_frag},phong:{uniforms:$e([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new se(0)},specular:{value:new se(1118481)},shininess:{value:30}}]),vertexShader:$t.meshphong_vert,fragmentShader:$t.meshphong_frag},standard:{uniforms:$e([lt.common,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.roughnessmap,lt.metalnessmap,lt.fog,lt.lights,{emissive:{value:new se(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:$t.meshphysical_vert,fragmentShader:$t.meshphysical_frag},toon:{uniforms:$e([lt.common,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.gradientmap,lt.fog,lt.lights,{emissive:{value:new se(0)}}]),vertexShader:$t.meshtoon_vert,fragmentShader:$t.meshtoon_frag},matcap:{uniforms:$e([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,{matcap:{value:null}}]),vertexShader:$t.meshmatcap_vert,fragmentShader:$t.meshmatcap_frag},points:{uniforms:$e([lt.points,lt.fog]),vertexShader:$t.points_vert,fragmentShader:$t.points_frag},dashed:{uniforms:$e([lt.common,lt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:$t.linedashed_vert,fragmentShader:$t.linedashed_frag},depth:{uniforms:$e([lt.common,lt.displacementmap]),vertexShader:$t.depth_vert,fragmentShader:$t.depth_frag},normal:{uniforms:$e([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,{opacity:{value:1}}]),vertexShader:$t.meshnormal_vert,fragmentShader:$t.meshnormal_frag},sprite:{uniforms:$e([lt.sprite,lt.fog]),vertexShader:$t.sprite_vert,fragmentShader:$t.sprite_frag},background:{uniforms:{uvTransform:{value:new Xt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:$t.background_vert,fragmentShader:$t.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Xt}},vertexShader:$t.backgroundCube_vert,fragmentShader:$t.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:$t.cube_vert,fragmentShader:$t.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:$t.equirect_vert,fragmentShader:$t.equirect_frag},distanceRGBA:{uniforms:$e([lt.common,lt.displacementmap,{referencePosition:{value:new B},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:$t.distanceRGBA_vert,fragmentShader:$t.distanceRGBA_frag},shadow:{uniforms:$e([lt.lights,lt.fog,{color:{value:new se(0)},opacity:{value:1}}]),vertexShader:$t.shadow_vert,fragmentShader:$t.shadow_frag}};Bn.physical={uniforms:$e([Bn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xt},clearcoatNormalScale:{value:new zt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xt},sheen:{value:0},sheenColor:{value:new se(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xt},transmissionSamplerSize:{value:new zt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xt},attenuationDistance:{value:0},attenuationColor:{value:new se(0)},specularColor:{value:new se(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xt},anisotropyVector:{value:new zt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xt}}]),vertexShader:$t.meshphysical_vert,fragmentShader:$t.meshphysical_frag};const no={r:0,b:0,g:0},Hi=new li,yx=new Me;function Ex(s,t,e,n,i,r,o){const a=new se(0);let c=r===!0?0:1,l,h,d=null,u=0,m=null;function x(_){let v=_.isScene===!0?_.background:null;return v&&v.isTexture&&(v=(_.backgroundBlurriness>0?e:t).get(v)),v}function g(_){let v=!1;const b=x(_);b===null?f(a,c):b&&b.isColor&&(f(b,1),v=!0);const S=s.xr.getEnvironmentBlendMode();S==="additive"?n.buffers.color.setClear(0,0,0,1,o):S==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(s.autoClear||v)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function p(_,v){const b=x(v);b&&(b.isCubeTexture||b.mapping===Jo)?(h===void 0&&(h=new sn(new un(1,1,1),new Gn({name:"BackgroundCubeMaterial",uniforms:Gs(Bn.backgroundCube.uniforms),vertexShader:Bn.backgroundCube.vertexShader,fragmentShader:Bn.backgroundCube.fragmentShader,side:Ke,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(S,T,P){this.matrixWorld.copyPosition(P.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),Hi.copy(v.backgroundRotation),Hi.x*=-1,Hi.y*=-1,Hi.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(Hi.y*=-1,Hi.z*=-1),h.material.uniforms.envMap.value=b,h.material.uniforms.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=v.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(yx.makeRotationFromEuler(Hi)),h.material.toneMapped=oe.getTransfer(b.colorSpace)!==fe,(d!==b||u!==b.version||m!==s.toneMapping)&&(h.material.needsUpdate=!0,d=b,u=b.version,m=s.toneMapping),h.layers.enableAll(),_.unshift(h,h.geometry,h.material,0,0,null)):b&&b.isTexture&&(l===void 0&&(l=new sn(new Xs(2,2),new Gn({name:"BackgroundMaterial",uniforms:Gs(Bn.background.uniforms),vertexShader:Bn.background.vertexShader,fragmentShader:Bn.background.fragmentShader,side:Fi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=b,l.material.uniforms.backgroundIntensity.value=v.backgroundIntensity,l.material.toneMapped=oe.getTransfer(b.colorSpace)!==fe,b.matrixAutoUpdate===!0&&b.updateMatrix(),l.material.uniforms.uvTransform.value.copy(b.matrix),(d!==b||u!==b.version||m!==s.toneMapping)&&(l.material.needsUpdate=!0,d=b,u=b.version,m=s.toneMapping),l.layers.enableAll(),_.unshift(l,l.geometry,l.material,0,0,null))}function f(_,v){_.getRGB(no,bu(s)),n.buffers.color.setClear(no.r,no.g,no.b,v,o)}function M(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(_,v=1){a.set(_),c=v,f(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(_){c=_,f(a,c)},render:g,addToRenderList:p,dispose:M}}function Ax(s,t){const e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=u(null);let r=i,o=!1;function a(E,C,D,O,H){let W=!1;const $=d(O,D,C);r!==$&&(r=$,l(r.object)),W=m(E,O,D,H),W&&x(E,O,D,H),H!==null&&t.update(H,s.ELEMENT_ARRAY_BUFFER),(W||o)&&(o=!1,v(E,C,D,O),H!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(H).buffer))}function c(){return s.createVertexArray()}function l(E){return s.bindVertexArray(E)}function h(E){return s.deleteVertexArray(E)}function d(E,C,D){const O=D.wireframe===!0;let H=n[E.id];H===void 0&&(H={},n[E.id]=H);let W=H[C.id];W===void 0&&(W={},H[C.id]=W);let $=W[O];return $===void 0&&($=u(c()),W[O]=$),$}function u(E){const C=[],D=[],O=[];for(let H=0;H<e;H++)C[H]=0,D[H]=0,O[H]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:D,attributeDivisors:O,object:E,attributes:{},index:null}}function m(E,C,D,O){const H=r.attributes,W=C.attributes;let $=0;const G=D.getAttributes();for(const V in G)if(G[V].location>=0){const st=H[V];let St=W[V];if(St===void 0&&(V==="instanceMatrix"&&E.instanceMatrix&&(St=E.instanceMatrix),V==="instanceColor"&&E.instanceColor&&(St=E.instanceColor)),st===void 0||st.attribute!==St||St&&st.data!==St.data)return!0;$++}return r.attributesNum!==$||r.index!==O}function x(E,C,D,O){const H={},W=C.attributes;let $=0;const G=D.getAttributes();for(const V in G)if(G[V].location>=0){let st=W[V];st===void 0&&(V==="instanceMatrix"&&E.instanceMatrix&&(st=E.instanceMatrix),V==="instanceColor"&&E.instanceColor&&(st=E.instanceColor));const St={};St.attribute=st,st&&st.data&&(St.data=st.data),H[V]=St,$++}r.attributes=H,r.attributesNum=$,r.index=O}function g(){const E=r.newAttributes;for(let C=0,D=E.length;C<D;C++)E[C]=0}function p(E){f(E,0)}function f(E,C){const D=r.newAttributes,O=r.enabledAttributes,H=r.attributeDivisors;D[E]=1,O[E]===0&&(s.enableVertexAttribArray(E),O[E]=1),H[E]!==C&&(s.vertexAttribDivisor(E,C),H[E]=C)}function M(){const E=r.newAttributes,C=r.enabledAttributes;for(let D=0,O=C.length;D<O;D++)C[D]!==E[D]&&(s.disableVertexAttribArray(D),C[D]=0)}function _(E,C,D,O,H,W,$){$===!0?s.vertexAttribIPointer(E,C,D,H,W):s.vertexAttribPointer(E,C,D,O,H,W)}function v(E,C,D,O){g();const H=O.attributes,W=D.getAttributes(),$=C.defaultAttributeValues;for(const G in W){const V=W[G];if(V.location>=0){let Y=H[G];if(Y===void 0&&(G==="instanceMatrix"&&E.instanceMatrix&&(Y=E.instanceMatrix),G==="instanceColor"&&E.instanceColor&&(Y=E.instanceColor)),Y!==void 0){const st=Y.normalized,St=Y.itemSize,kt=t.get(Y);if(kt===void 0)continue;const qt=kt.buffer,ce=kt.type,le=kt.bytesPerElement,Z=ce===s.INT||ce===s.UNSIGNED_INT||Y.gpuType===fl;if(Y.isInterleavedBufferAttribute){const Q=Y.data,ut=Q.stride,Lt=Y.offset;if(Q.isInstancedInterleavedBuffer){for(let yt=0;yt<V.locationSize;yt++)f(V.location+yt,Q.meshPerAttribute);E.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let yt=0;yt<V.locationSize;yt++)p(V.location+yt);s.bindBuffer(s.ARRAY_BUFFER,qt);for(let yt=0;yt<V.locationSize;yt++)_(V.location+yt,St/V.locationSize,ce,st,ut*le,(Lt+St/V.locationSize*yt)*le,Z)}else{if(Y.isInstancedBufferAttribute){for(let Q=0;Q<V.locationSize;Q++)f(V.location+Q,Y.meshPerAttribute);E.isInstancedMesh!==!0&&O._maxInstanceCount===void 0&&(O._maxInstanceCount=Y.meshPerAttribute*Y.count)}else for(let Q=0;Q<V.locationSize;Q++)p(V.location+Q);s.bindBuffer(s.ARRAY_BUFFER,qt);for(let Q=0;Q<V.locationSize;Q++)_(V.location+Q,St/V.locationSize,ce,st,St*le,St/V.locationSize*Q*le,Z)}}else if($!==void 0){const st=$[G];if(st!==void 0)switch(st.length){case 2:s.vertexAttrib2fv(V.location,st);break;case 3:s.vertexAttrib3fv(V.location,st);break;case 4:s.vertexAttrib4fv(V.location,st);break;default:s.vertexAttrib1fv(V.location,st)}}}}M()}function b(){P();for(const E in n){const C=n[E];for(const D in C){const O=C[D];for(const H in O)h(O[H].object),delete O[H];delete C[D]}delete n[E]}}function S(E){if(n[E.id]===void 0)return;const C=n[E.id];for(const D in C){const O=C[D];for(const H in O)h(O[H].object),delete O[H];delete C[D]}delete n[E.id]}function T(E){for(const C in n){const D=n[C];if(D[E.id]===void 0)continue;const O=D[E.id];for(const H in O)h(O[H].object),delete O[H];delete D[E.id]}}function P(){A(),o=!0,r!==i&&(r=i,l(r.object))}function A(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:P,resetDefaultState:A,dispose:b,releaseStatesOfGeometry:S,releaseStatesOfProgram:T,initAttributes:g,enableAttribute:p,disableUnusedAttributes:M}}function wx(s,t,e){let n;function i(l){n=l}function r(l,h){s.drawArrays(n,l,h),e.update(h,n,1)}function o(l,h,d){d!==0&&(s.drawArraysInstanced(n,l,h,d),e.update(h,n,d))}function a(l,h,d){if(d===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,h,0,d);let m=0;for(let x=0;x<d;x++)m+=h[x];e.update(m,n,1)}function c(l,h,d,u){if(d===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let x=0;x<l.length;x++)o(l[x],h[x],u[x]);else{m.multiDrawArraysInstancedWEBGL(n,l,0,h,0,u,0,d);let x=0;for(let g=0;g<d;g++)x+=h[g]*u[g];e.update(x,n,1)}}this.setMode=i,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function Tx(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){const T=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(T){return!(T!==In&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){const P=T===Ws&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(T!==ci&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==zn&&!P)}function c(T){if(T==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=e.precision!==void 0?e.precision:"highp";const h=c(l);h!==l&&(Ht("WebGLRenderer:",l,"not supported, using",h,"instead."),l=h);const d=e.logarithmicDepthBuffer===!0,u=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),m=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),x=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),g=s.getParameter(s.MAX_TEXTURE_SIZE),p=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),f=s.getParameter(s.MAX_VERTEX_ATTRIBS),M=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),_=s.getParameter(s.MAX_VARYING_VECTORS),v=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),b=x>0,S=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:u,maxTextures:m,maxVertexTextures:x,maxTextureSize:g,maxCubemapSize:p,maxAttributes:f,maxVertexUniforms:M,maxVaryings:_,maxFragmentUniforms:v,vertexTextures:b,maxSamples:S}}function Cx(s){const t=this;let e=null,n=0,i=!1,r=!1;const o=new Ai,a=new Xt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const m=d.length!==0||u||n!==0||i;return i=u,n=d.length,m},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,u){e=h(d,u,0)},this.setState=function(d,u,m){const x=d.clippingPlanes,g=d.clipIntersection,p=d.clipShadows,f=s.get(d);if(!i||x===null||x.length===0||r&&!p)r?h(null):l();else{const M=r?0:n,_=M*4;let v=f.clippingState||null;c.value=v,v=h(x,u,_,m);for(let b=0;b!==_;++b)v[b]=e[b];f.clippingState=v,this.numIntersection=g?this.numPlanes:0,this.numPlanes+=M}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(d,u,m,x){const g=d!==null?d.length:0;let p=null;if(g!==0){if(p=c.value,x!==!0||p===null){const f=m+g*4,M=u.matrixWorldInverse;a.getNormalMatrix(M),(p===null||p.length<f)&&(p=new Float32Array(f));for(let _=0,v=m;_!==g;++_,v+=4)o.copy(d[_]).applyMatrix4(M,a),o.normal.toArray(p,v),p[v+3]=o.constant}c.value=p,c.needsUpdate=!0}return t.numPlanes=g,t.numIntersection=0,p}}function Rx(s){let t=new WeakMap;function e(o,a){return a===xc?o.mapping=zs:a===gc&&(o.mapping=Vs),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===xc||a===gc)if(t.has(o)){const c=t.get(o).texture;return e(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new Cp(c.height);return l.fromEquirectangularTexture(s,o),t.set(o,l),o.addEventListener("dispose",i),e(l.texture,o.mapping)}else return null}}return o}function i(o){const a=o.target;a.removeEventListener("dispose",i);const c=t.get(a);c!==void 0&&(t.delete(a),c.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}const Li=4,Ch=[.125,.215,.35,.446,.526,.582],ns=20,Px=256,nr=new Bp,Rh=new se;let Fa=null,Ua=0,Na=0,Oa=!1;const Lx=new B;class Ph{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,e=0,n=.1,i=100,r={}){const{size:o=256,position:a=Lx}=r;Fa=this._renderer.getRenderTarget(),Ua=this._renderer.getActiveCubeFace(),Na=this._renderer.getActiveMipmapLevel(),Oa=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(t,n,i,c,a),e>0&&this._blur(c,0,0,e),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Dh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ih(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(Fa,Ua,Na),this._renderer.xr.enabled=Oa,t.scissorTest=!1,ws(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===zs||t.mapping===Vs?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Fa=this._renderer.getRenderTarget(),Ua=this._renderer.getActiveCubeFace(),Na=this._renderer.getActiveMipmapLevel(),Oa=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:en,minFilter:en,generateMipmaps:!1,type:Ws,format:In,colorSpace:ks,depthBuffer:!1},i=Lh(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Lh(t,e,n);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Ix(r)),this._blurMaterial=Fx(r,t,e),this._ggxMaterial=Dx(r,t,e)}return i}_compileMaterial(t){const e=new sn(new Fn,t);this._renderer.compile(e,nr)}_sceneToCubeUV(t,e,n,i,r){const c=new Sn(90,1,e,n),l=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],d=this._renderer,u=d.autoClear,m=d.toneMapping;d.getClearColor(Rh),d.toneMapping=Di,d.autoClear=!1,d.state.buffers.depth.getReversed()&&(d.setRenderTarget(i),d.clearDepth(),d.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new sn(new un,new rn({name:"PMREM.Background",side:Ke,depthWrite:!1,depthTest:!1})));const g=this._backgroundBox,p=g.material;let f=!1;const M=t.background;M?M.isColor&&(p.color.copy(M),t.background=null,f=!0):(p.color.copy(Rh),f=!0);for(let _=0;_<6;_++){const v=_%3;v===0?(c.up.set(0,l[_],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+h[_],r.y,r.z)):v===1?(c.up.set(0,0,l[_]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+h[_],r.z)):(c.up.set(0,l[_],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+h[_]));const b=this._cubeSize;ws(i,v*b,_>2?b:0,b,b),d.setRenderTarget(i),f&&d.render(g,c),d.render(t,c)}d.toneMapping=m,d.autoClear=u,t.background=M}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===zs||t.mapping===Vs;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Dh()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ih());const r=i?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=r;const a=r.uniforms;a.envMap.value=t;const c=this._cubeSize;ws(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(o,nr)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const i=this._lodMeshes.length;for(let r=1;r<i;r++)this._applyGGXFilter(t,r-1,r);e.autoClear=n}_applyGGXFilter(t,e,n){const i=this._renderer,r=this._pingPongRenderTarget,o=this._ggxMaterial,a=this._lodMeshes[n];a.material=o;const c=o.uniforms,l=n/(this._lodMeshes.length-1),h=e/(this._lodMeshes.length-1),d=Math.sqrt(l*l-h*h),u=.05+l*.95,m=d*u,{_lodMax:x}=this,g=this._sizeLods[n],p=3*g*(n>x-Li?n-x+Li:0),f=4*(this._cubeSize-g);c.envMap.value=t.texture,c.roughness.value=m,c.mipInt.value=x-e,ws(r,p,f,3*g,2*g),i.setRenderTarget(r),i.render(a,nr),c.envMap.value=r.texture,c.roughness.value=0,c.mipInt.value=x-n,ws(t,p,f,3*g,2*g),i.setRenderTarget(t),i.render(a,nr)}_blur(t,e,n,i,r){const o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,i,"latitudinal",r),this._halfBlur(o,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&Pe("blur direction must be either latitudinal or longitudinal!");const h=3,d=this._lodMeshes[i];d.material=l;const u=l.uniforms,m=this._sizeLods[n]-1,x=isFinite(r)?Math.PI/(2*m):2*Math.PI/(2*ns-1),g=r/x,p=isFinite(r)?1+Math.floor(h*g):ns;p>ns&&Ht(`sigmaRadians, ${r}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${ns}`);const f=[];let M=0;for(let T=0;T<ns;++T){const P=T/g,A=Math.exp(-P*P/2);f.push(A),T===0?M+=A:T<p&&(M+=2*A)}for(let T=0;T<f.length;T++)f[T]=f[T]/M;u.envMap.value=t.texture,u.samples.value=p,u.weights.value=f,u.latitudinal.value=o==="latitudinal",a&&(u.poleAxis.value=a);const{_lodMax:_}=this;u.dTheta.value=x,u.mipInt.value=_-n;const v=this._sizeLods[i],b=3*v*(i>_-Li?i-_+Li:0),S=4*(this._cubeSize-v);ws(e,b,S,3*v,2*v),c.setRenderTarget(e),c.render(d,nr)}}function Ix(s){const t=[],e=[],n=[];let i=s;const r=s-Li+1+Ch.length;for(let o=0;o<r;o++){const a=Math.pow(2,i);t.push(a);let c=1/a;o>s-Li?c=Ch[o-s+Li-1]:o===0&&(c=0),e.push(c);const l=1/(a-2),h=-l,d=1+l,u=[h,h,d,h,d,d,h,h,d,d,h,d],m=6,x=6,g=3,p=2,f=1,M=new Float32Array(g*x*m),_=new Float32Array(p*x*m),v=new Float32Array(f*x*m);for(let S=0;S<m;S++){const T=S%3*2/3-1,P=S>2?0:-1,A=[T,P,0,T+2/3,P,0,T+2/3,P+1,0,T,P,0,T+2/3,P+1,0,T,P+1,0];M.set(A,g*x*S),_.set(u,p*x*S);const E=[S,S,S,S,S,S];v.set(E,f*x*S)}const b=new Fn;b.setAttribute("position",new Dn(M,g)),b.setAttribute("uv",new Dn(_,p)),b.setAttribute("faceIndex",new Dn(v,f)),n.push(new sn(b,null)),i>Li&&i--}return{lodMeshes:n,sizeLods:t,sigmas:e}}function Lh(s,t,e){const n=new as(s,t,e);return n.texture.mapping=Jo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function ws(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function Dx(s,t,e){return new Gn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Px,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:na(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Fx(s,t,e){const n=new Float32Array(ns),i=new B(0,1,0);return new Gn({name:"SphericalGaussianBlur",defines:{n:ns,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:na(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Ih(){return new Gn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:na(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Dh(){return new Gn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:na(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function na(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Ux(s){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){const c=a.mapping,l=c===xc||c===gc,h=c===zs||c===Vs;if(l||h){let d=t.get(a);const u=d!==void 0?d.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==u)return e===null&&(e=new Ph(s)),d=l?e.fromEquirectangular(a,d):e.fromCubemap(a,d),d.texture.pmremVersion=a.pmremVersion,t.set(a,d),d.texture;if(d!==void 0)return d.texture;{const m=a.image;return l&&m&&m.height>0||h&&m&&i(m)?(e===null&&(e=new Ph(s)),d=l?e.fromEquirectangular(a):e.fromCubemap(a),d.texture.pmremVersion=a.pmremVersion,t.set(a,d),a.addEventListener("dispose",r),d.texture):null}}}return a}function i(a){let c=0;const l=6;for(let h=0;h<l;h++)a[h]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function Nx(s){const t={};function e(n){if(t[n]!==void 0)return t[n];const i=s.getExtension(n);return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const i=e(n);return i===null&&Tr("WebGLRenderer: "+n+" extension not supported."),i}}}function Ox(s,t,e,n){const i={},r=new WeakMap;function o(d){const u=d.target;u.index!==null&&t.remove(u.index);for(const x in u.attributes)t.remove(u.attributes[x]);u.removeEventListener("dispose",o),delete i[u.id];const m=r.get(u);m&&(t.remove(m),r.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,e.memory.geometries--}function a(d,u){return i[u.id]===!0||(u.addEventListener("dispose",o),i[u.id]=!0,e.memory.geometries++),u}function c(d){const u=d.attributes;for(const m in u)t.update(u[m],s.ARRAY_BUFFER)}function l(d){const u=[],m=d.index,x=d.attributes.position;let g=0;if(m!==null){const M=m.array;g=m.version;for(let _=0,v=M.length;_<v;_+=3){const b=M[_+0],S=M[_+1],T=M[_+2];u.push(b,S,S,T,T,b)}}else if(x!==void 0){const M=x.array;g=x.version;for(let _=0,v=M.length/3-1;_<v;_+=3){const b=_+0,S=_+1,T=_+2;u.push(b,S,S,T,T,b)}}else return;const p=new(mu(u)?vu:_u)(u,1);p.version=g;const f=r.get(d);f&&t.remove(f),r.set(d,p)}function h(d){const u=r.get(d);if(u){const m=d.index;m!==null&&u.version<m.version&&l(d)}else l(d);return r.get(d)}return{get:a,update:c,getWireframeAttribute:h}}function Bx(s,t,e){let n;function i(u){n=u}let r,o;function a(u){r=u.type,o=u.bytesPerElement}function c(u,m){s.drawElements(n,m,r,u*o),e.update(m,n,1)}function l(u,m,x){x!==0&&(s.drawElementsInstanced(n,m,r,u*o,x),e.update(m,n,x))}function h(u,m,x){if(x===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,m,0,r,u,0,x);let p=0;for(let f=0;f<x;f++)p+=m[f];e.update(p,n,1)}function d(u,m,x,g){if(x===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let f=0;f<u.length;f++)l(u[f]/o,m[f],g[f]);else{p.multiDrawElementsInstancedWEBGL(n,m,0,r,u,0,g,0,x);let f=0;for(let M=0;M<x;M++)f+=m[M]*g[M];e.update(f,n,1)}}this.setMode=i,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=h,this.renderMultiDrawInstances=d}function zx(s){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case s.TRIANGLES:e.triangles+=a*(r/3);break;case s.LINES:e.lines+=a*(r/2);break;case s.LINE_STRIP:e.lines+=a*(r-1);break;case s.LINE_LOOP:e.lines+=a*r;break;case s.POINTS:e.points+=a*r;break;default:Pe("WebGLInfo: Unknown draw mode:",o);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function Vx(s,t,e){const n=new WeakMap,i=new Le;function r(o,a,c){const l=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=h!==void 0?h.length:0;let u=n.get(a);if(u===void 0||u.count!==d){let E=function(){P.dispose(),n.delete(a),a.removeEventListener("dispose",E)};var m=E;u!==void 0&&u.texture.dispose();const x=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,p=a.morphAttributes.color!==void 0,f=a.morphAttributes.position||[],M=a.morphAttributes.normal||[],_=a.morphAttributes.color||[];let v=0;x===!0&&(v=1),g===!0&&(v=2),p===!0&&(v=3);let b=a.attributes.position.count*v,S=1;b>t.maxTextureSize&&(S=Math.ceil(b/t.maxTextureSize),b=t.maxTextureSize);const T=new Float32Array(b*S*4*d),P=new xu(T,b,S,d);P.type=zn,P.needsUpdate=!0;const A=v*4;for(let C=0;C<d;C++){const D=f[C],O=M[C],H=_[C],W=b*S*4*C;for(let $=0;$<D.count;$++){const G=$*A;x===!0&&(i.fromBufferAttribute(D,$),T[W+G+0]=i.x,T[W+G+1]=i.y,T[W+G+2]=i.z,T[W+G+3]=0),g===!0&&(i.fromBufferAttribute(O,$),T[W+G+4]=i.x,T[W+G+5]=i.y,T[W+G+6]=i.z,T[W+G+7]=0),p===!0&&(i.fromBufferAttribute(H,$),T[W+G+8]=i.x,T[W+G+9]=i.y,T[W+G+10]=i.z,T[W+G+11]=H.itemSize===4?i.w:1)}}u={count:d,texture:P,size:new zt(b,S)},n.set(a,u),a.addEventListener("dispose",E)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(s,"morphTexture",o.morphTexture,e);else{let x=0;for(let p=0;p<l.length;p++)x+=l[p];const g=a.morphTargetsRelative?1:1-x;c.getUniforms().setValue(s,"morphTargetBaseInfluence",g),c.getUniforms().setValue(s,"morphTargetInfluences",l)}c.getUniforms().setValue(s,"morphTargetsTexture",u.texture,e),c.getUniforms().setValue(s,"morphTargetsTextureSize",u.size)}return{update:r}}function kx(s,t,e,n){let i=new WeakMap;function r(c){const l=n.render.frame,h=c.geometry,d=t.get(c,h);if(i.get(d)!==l&&(t.update(d),i.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),i.get(c)!==l&&(e.update(c.instanceMatrix,s.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,s.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;i.get(u)!==l&&(u.update(),i.set(u,l))}return d}function o(){i=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:o}}const Cu=new He,Fh=new Au(1,1),Ru=new xu,Pu=new dp,Lu=new Su,Uh=[],Nh=[],Oh=new Float32Array(16),Bh=new Float32Array(9),zh=new Float32Array(4);function qs(s,t,e){const n=s[0];if(n<=0||n>0)return s;const i=t*e;let r=Uh[i];if(r===void 0&&(r=new Float32Array(i),Uh[i]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,s[o].toArray(r,a)}return r}function Fe(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Ue(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function ia(s,t){let e=Nh[t];e===void 0&&(e=new Int32Array(t),Nh[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function Gx(s,t){const e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function Hx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2fv(this.addr,t),Ue(e,t)}}function Wx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Fe(e,t))return;s.uniform3fv(this.addr,t),Ue(e,t)}}function Xx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4fv(this.addr,t),Ue(e,t)}}function qx(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Ue(e,t)}else{if(Fe(e,n))return;zh.set(n),s.uniformMatrix2fv(this.addr,!1,zh),Ue(e,n)}}function Yx(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Ue(e,t)}else{if(Fe(e,n))return;Bh.set(n),s.uniformMatrix3fv(this.addr,!1,Bh),Ue(e,n)}}function $x(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Ue(e,t)}else{if(Fe(e,n))return;Oh.set(n),s.uniformMatrix4fv(this.addr,!1,Oh),Ue(e,n)}}function Kx(s,t){const e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function Zx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2iv(this.addr,t),Ue(e,t)}}function jx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Fe(e,t))return;s.uniform3iv(this.addr,t),Ue(e,t)}}function Jx(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4iv(this.addr,t),Ue(e,t)}}function Qx(s,t){const e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function tg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2uiv(this.addr,t),Ue(e,t)}}function eg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Fe(e,t))return;s.uniform3uiv(this.addr,t),Ue(e,t)}}function ng(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4uiv(this.addr,t),Ue(e,t)}}function ig(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(Fh.compareFunction=pu,r=Fh):r=Cu,e.setTexture2D(t||r,i)}function sg(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Pu,i)}function rg(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Lu,i)}function og(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||Ru,i)}function ag(s){switch(s){case 5126:return Gx;case 35664:return Hx;case 35665:return Wx;case 35666:return Xx;case 35674:return qx;case 35675:return Yx;case 35676:return $x;case 5124:case 35670:return Kx;case 35667:case 35671:return Zx;case 35668:case 35672:return jx;case 35669:case 35673:return Jx;case 5125:return Qx;case 36294:return tg;case 36295:return eg;case 36296:return ng;case 35678:case 36198:case 36298:case 36306:case 35682:return ig;case 35679:case 36299:case 36307:return sg;case 35680:case 36300:case 36308:case 36293:return rg;case 36289:case 36303:case 36311:case 36292:return og}}function cg(s,t){s.uniform1fv(this.addr,t)}function lg(s,t){const e=qs(t,this.size,2);s.uniform2fv(this.addr,e)}function hg(s,t){const e=qs(t,this.size,3);s.uniform3fv(this.addr,e)}function dg(s,t){const e=qs(t,this.size,4);s.uniform4fv(this.addr,e)}function ug(s,t){const e=qs(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function fg(s,t){const e=qs(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function pg(s,t){const e=qs(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function mg(s,t){s.uniform1iv(this.addr,t)}function xg(s,t){s.uniform2iv(this.addr,t)}function gg(s,t){s.uniform3iv(this.addr,t)}function _g(s,t){s.uniform4iv(this.addr,t)}function vg(s,t){s.uniform1uiv(this.addr,t)}function bg(s,t){s.uniform2uiv(this.addr,t)}function Mg(s,t){s.uniform3uiv(this.addr,t)}function Sg(s,t){s.uniform4uiv(this.addr,t)}function yg(s,t,e){const n=this.cache,i=t.length,r=ia(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture2D(t[o]||Cu,r[o])}function Eg(s,t,e){const n=this.cache,i=t.length,r=ia(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture3D(t[o]||Pu,r[o])}function Ag(s,t,e){const n=this.cache,i=t.length,r=ia(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTextureCube(t[o]||Lu,r[o])}function wg(s,t,e){const n=this.cache,i=t.length,r=ia(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ue(n,r));for(let o=0;o!==i;++o)e.setTexture2DArray(t[o]||Ru,r[o])}function Tg(s){switch(s){case 5126:return cg;case 35664:return lg;case 35665:return hg;case 35666:return dg;case 35674:return ug;case 35675:return fg;case 35676:return pg;case 5124:case 35670:return mg;case 35667:case 35671:return xg;case 35668:case 35672:return gg;case 35669:case 35673:return _g;case 5125:return vg;case 36294:return bg;case 36295:return Mg;case 36296:return Sg;case 35678:case 36198:case 36298:case 36306:case 35682:return yg;case 35679:case 36299:case 36307:return Eg;case 35680:case 36300:case 36308:case 36293:return Ag;case 36289:case 36303:case 36311:case 36292:return wg}}class Cg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=ag(e.type)}}class Rg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Tg(e.type)}}class Pg{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let r=0,o=i.length;r!==o;++r){const a=i[r];a.setValue(t,e[a.id],n)}}}const Ba=/(\w+)(\])?(\[|\.)?/g;function Vh(s,t){s.seq.push(t),s.map[t.id]=t}function Lg(s,t,e){const n=s.name,i=n.length;for(Ba.lastIndex=0;;){const r=Ba.exec(n),o=Ba.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===i){Vh(e,l===void 0?new Cg(a,s,t):new Rg(a,s,t));break}else{let d=e.map[a];d===void 0&&(d=new Pg(a),Vh(e,d)),e=d}}}class Lo{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const r=t.getActiveUniform(e,i),o=t.getUniformLocation(e,r.name);Lg(r,o,this)}}setValue(t,e,n,i){const r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,o=e.length;r!==o;++r){const a=e[r],c=n[a.id];c.needsUpdate!==!1&&a.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,r=t.length;i!==r;++i){const o=t[i];o.id in e&&n.push(o)}return n}}function kh(s,t,e){const n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}const Ig=37297;let Dg=0;function Fg(s,t){const e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=i;o<r;o++){const a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}const Gh=new Xt;function Ug(s){oe._getMatrix(Gh,oe.workingColorSpace,s);const t=`mat3( ${Gh.elements.map(e=>e.toFixed(4))} )`;switch(oe.getTransfer(s)){case Bo:return[t,"LinearTransferOETF"];case fe:return[t,"sRGBTransferOETF"];default:return Ht("WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function Hh(s,t,e){const n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const a=parseInt(o[1]);return e.toUpperCase()+`

`+r+`

`+Fg(s.getShaderSource(t),a)}else return r}function Ng(s,t){const e=Ug(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Og(s,t){let e;switch(t){case Of:e="Linear";break;case Bf:e="Reinhard";break;case zf:e="Cineon";break;case Vf:e="ACESFilmic";break;case Gf:e="AgX";break;case Hf:e="Neutral";break;case kf:e="Custom";break;default:Ht("WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const io=new B;function Bg(){oe.getLuminanceCoefficients(io);const s=io.x.toFixed(4),t=io.y.toFixed(4),e=io.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function zg(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(pr).join(`
`)}function Vg(s){const t=[];for(const e in s){const n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function kg(s,t){const e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const r=s.getActiveAttrib(t,i),o=r.name;let a=1;r.type===s.FLOAT_MAT2&&(a=2),r.type===s.FLOAT_MAT3&&(a=3),r.type===s.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:s.getAttribLocation(t,o),locationSize:a}}return e}function pr(s){return s!==""}function Wh(s,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Xh(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const Gg=/^[ \t]*#include +<([\w\d./]+)>/gm;function Kc(s){return s.replace(Gg,Wg)}const Hg=new Map;function Wg(s,t){let e=$t[t];if(e===void 0){const n=Hg.get(t);if(n!==void 0)e=$t[n],Ht('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return Kc(e)}const Xg=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function qh(s){return s.replace(Xg,qg)}function qg(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Yh(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Yg(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===ru?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===xf?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===ni&&(t="SHADOWMAP_TYPE_VSM"),t}function $g(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case zs:case Vs:t="ENVMAP_TYPE_CUBE";break;case Jo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Kg(s){let t="ENVMAP_MODE_REFLECTION";if(s.envMap)switch(s.envMapMode){case Vs:t="ENVMAP_MODE_REFRACTION";break}return t}function Zg(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case ou:t="ENVMAP_BLENDING_MULTIPLY";break;case Uf:t="ENVMAP_BLENDING_MIX";break;case Nf:t="ENVMAP_BLENDING_ADD";break}return t}function jg(s){const t=s.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function Jg(s,t,e,n){const i=s.getContext(),r=e.defines;let o=e.vertexShader,a=e.fragmentShader;const c=Yg(e),l=$g(e),h=Kg(e),d=Zg(e),u=jg(e),m=zg(e),x=Vg(r),g=i.createProgram();let p,f,M=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(pr).join(`
`),p.length>0&&(p+=`
`),f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(pr).join(`
`),f.length>0&&(f+=`
`)):(p=[Yh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(pr).join(`
`),f=[Yh(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Di?"#define TONE_MAPPING":"",e.toneMapping!==Di?$t.tonemapping_pars_fragment:"",e.toneMapping!==Di?Og("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",$t.colorspace_pars_fragment,Ng("linearToOutputTexel",e.outputColorSpace),Bg(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(pr).join(`
`)),o=Kc(o),o=Wh(o,e),o=Xh(o,e),a=Kc(a),a=Wh(a,e),a=Xh(a,e),o=qh(o),a=qh(a),e.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,p=[m,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,f=["#define varying in",e.glslVersion===sh?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===sh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const _=M+p+o,v=M+f+a,b=kh(i,i.VERTEX_SHADER,_),S=kh(i,i.FRAGMENT_SHADER,v);i.attachShader(g,b),i.attachShader(g,S),e.index0AttributeName!==void 0?i.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(g,0,"position"),i.linkProgram(g);function T(C){if(s.debug.checkShaderErrors){const D=i.getProgramInfoLog(g)||"",O=i.getShaderInfoLog(b)||"",H=i.getShaderInfoLog(S)||"",W=D.trim(),$=O.trim(),G=H.trim();let V=!0,Y=!0;if(i.getProgramParameter(g,i.LINK_STATUS)===!1)if(V=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,g,b,S);else{const st=Hh(i,b,"vertex"),St=Hh(i,S,"fragment");Pe("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(g,i.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+W+`
`+st+`
`+St)}else W!==""?Ht("WebGLProgram: Program Info Log:",W):($===""||G==="")&&(Y=!1);Y&&(C.diagnostics={runnable:V,programLog:W,vertexShader:{log:$,prefix:p},fragmentShader:{log:G,prefix:f}})}i.deleteShader(b),i.deleteShader(S),P=new Lo(i,g),A=kg(i,g)}let P;this.getUniforms=function(){return P===void 0&&T(this),P};let A;this.getAttributes=function(){return A===void 0&&T(this),A};let E=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(g,Ig)),E},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Dg++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=b,this.fragmentShader=S,this}let Qg=0;class t_{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new e_(t),e.set(t,n)),n}}class e_{constructor(t){this.id=Qg++,this.code=t,this.usedTimes=0}}function n_(s,t,e,n,i,r,o){const a=new yl,c=new t_,l=new Set,h=[],d=i.logarithmicDepthBuffer,u=i.vertexTextures;let m=i.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function g(A){return l.add(A),A===0?"uv":`uv${A}`}function p(A,E,C,D,O){const H=D.fog,W=O.geometry,$=A.isMeshStandardMaterial?D.environment:null,G=(A.isMeshStandardMaterial?e:t).get(A.envMap||$),V=G&&G.mapping===Jo?G.image.height:null,Y=x[A.type];A.precision!==null&&(m=i.getMaxPrecision(A.precision),m!==A.precision&&Ht("WebGLProgram.getParameters:",A.precision,"not supported, using",m,"instead."));const st=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,St=st!==void 0?st.length:0;let kt=0;W.morphAttributes.position!==void 0&&(kt=1),W.morphAttributes.normal!==void 0&&(kt=2),W.morphAttributes.color!==void 0&&(kt=3);let qt,ce,le,Z;if(Y){const de=Bn[Y];qt=de.vertexShader,ce=de.fragmentShader}else qt=A.vertexShader,ce=A.fragmentShader,c.update(A),le=c.getVertexShaderID(A),Z=c.getFragmentShaderID(A);const Q=s.getRenderTarget(),ut=s.state.buffers.depth.getReversed(),Lt=O.isInstancedMesh===!0,yt=O.isBatchedMesh===!0,Wt=!!A.map,Se=!!A.matcap,Yt=!!G,ie=!!A.aoMap,L=!!A.lightMap,Qt=!!A.bumpMap,te=!!A.normalMap,_e=!!A.displacementMap,Mt=!!A.emissiveMap,ye=!!A.metalnessMap,Ct=!!A.roughnessMap,Gt=A.anisotropy>0,R=A.clearcoat>0,y=A.dispersion>0,k=A.iridescence>0,j=A.sheen>0,tt=A.transmission>0,K=Gt&&!!A.anisotropyMap,wt=R&&!!A.clearcoatMap,ht=R&&!!A.clearcoatNormalMap,Rt=R&&!!A.clearcoatRoughnessMap,At=k&&!!A.iridescenceMap,et=k&&!!A.iridescenceThicknessMap,ot=j&&!!A.sheenColorMap,Ut=j&&!!A.sheenRoughnessMap,It=!!A.specularMap,pt=!!A.specularColorMap,Ot=!!A.specularIntensityMap,I=tt&&!!A.transmissionMap,dt=tt&&!!A.thicknessMap,at=!!A.gradientMap,ct=!!A.alphaMap,it=A.alphaTest>0,J=!!A.alphaHash,vt=!!A.extensions;let Vt=Di;A.toneMapped&&(Q===null||Q.isXRRenderTarget===!0)&&(Vt=s.toneMapping);const ve={shaderID:Y,shaderType:A.type,shaderName:A.name,vertexShader:qt,fragmentShader:ce,defines:A.defines,customVertexShaderID:le,customFragmentShaderID:Z,isRawShaderMaterial:A.isRawShaderMaterial===!0,glslVersion:A.glslVersion,precision:m,batching:yt,batchingColor:yt&&O._colorsTexture!==null,instancing:Lt,instancingColor:Lt&&O.instanceColor!==null,instancingMorph:Lt&&O.morphTexture!==null,supportsVertexTextures:u,outputColorSpace:Q===null?s.outputColorSpace:Q.isXRRenderTarget===!0?Q.texture.colorSpace:ks,alphaToCoverage:!!A.alphaToCoverage,map:Wt,matcap:Se,envMap:Yt,envMapMode:Yt&&G.mapping,envMapCubeUVHeight:V,aoMap:ie,lightMap:L,bumpMap:Qt,normalMap:te,displacementMap:u&&_e,emissiveMap:Mt,normalMapObjectSpace:te&&A.normalMapType===$f,normalMapTangentSpace:te&&A.normalMapType===Yf,metalnessMap:ye,roughnessMap:Ct,anisotropy:Gt,anisotropyMap:K,clearcoat:R,clearcoatMap:wt,clearcoatNormalMap:ht,clearcoatRoughnessMap:Rt,dispersion:y,iridescence:k,iridescenceMap:At,iridescenceThicknessMap:et,sheen:j,sheenColorMap:ot,sheenRoughnessMap:Ut,specularMap:It,specularColorMap:pt,specularIntensityMap:Ot,transmission:tt,transmissionMap:I,thicknessMap:dt,gradientMap:at,opaque:A.transparent===!1&&A.blending===Ns&&A.alphaToCoverage===!1,alphaMap:ct,alphaTest:it,alphaHash:J,combine:A.combine,mapUv:Wt&&g(A.map.channel),aoMapUv:ie&&g(A.aoMap.channel),lightMapUv:L&&g(A.lightMap.channel),bumpMapUv:Qt&&g(A.bumpMap.channel),normalMapUv:te&&g(A.normalMap.channel),displacementMapUv:_e&&g(A.displacementMap.channel),emissiveMapUv:Mt&&g(A.emissiveMap.channel),metalnessMapUv:ye&&g(A.metalnessMap.channel),roughnessMapUv:Ct&&g(A.roughnessMap.channel),anisotropyMapUv:K&&g(A.anisotropyMap.channel),clearcoatMapUv:wt&&g(A.clearcoatMap.channel),clearcoatNormalMapUv:ht&&g(A.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Rt&&g(A.clearcoatRoughnessMap.channel),iridescenceMapUv:At&&g(A.iridescenceMap.channel),iridescenceThicknessMapUv:et&&g(A.iridescenceThicknessMap.channel),sheenColorMapUv:ot&&g(A.sheenColorMap.channel),sheenRoughnessMapUv:Ut&&g(A.sheenRoughnessMap.channel),specularMapUv:It&&g(A.specularMap.channel),specularColorMapUv:pt&&g(A.specularColorMap.channel),specularIntensityMapUv:Ot&&g(A.specularIntensityMap.channel),transmissionMapUv:I&&g(A.transmissionMap.channel),thicknessMapUv:dt&&g(A.thicknessMap.channel),alphaMapUv:ct&&g(A.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(te||Gt),vertexColors:A.vertexColors,vertexAlphas:A.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:O.isPoints===!0&&!!W.attributes.uv&&(Wt||ct),fog:!!H,useFog:A.fog===!0,fogExp2:!!H&&H.isFogExp2,flatShading:A.flatShading===!0&&A.wireframe===!1,sizeAttenuation:A.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ut,skinning:O.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:St,morphTextureStride:kt,numDirLights:E.directional.length,numPointLights:E.point.length,numSpotLights:E.spot.length,numSpotLightMaps:E.spotLightMap.length,numRectAreaLights:E.rectArea.length,numHemiLights:E.hemi.length,numDirLightShadows:E.directionalShadowMap.length,numPointLightShadows:E.pointShadowMap.length,numSpotLightShadows:E.spotShadowMap.length,numSpotLightShadowsWithMaps:E.numSpotLightShadowsWithMaps,numLightProbes:E.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:A.dithering,shadowMapEnabled:s.shadowMap.enabled&&C.length>0,shadowMapType:s.shadowMap.type,toneMapping:Vt,decodeVideoTexture:Wt&&A.map.isVideoTexture===!0&&oe.getTransfer(A.map.colorSpace)===fe,decodeVideoTextureEmissive:Mt&&A.emissiveMap.isVideoTexture===!0&&oe.getTransfer(A.emissiveMap.colorSpace)===fe,premultipliedAlpha:A.premultipliedAlpha,doubleSided:A.side===Pn,flipSided:A.side===Ke,useDepthPacking:A.depthPacking>=0,depthPacking:A.depthPacking||0,index0AttributeName:A.index0AttributeName,extensionClipCullDistance:vt&&A.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(vt&&A.extensions.multiDraw===!0||yt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:A.customProgramCacheKey()};return ve.vertexUv1s=l.has(1),ve.vertexUv2s=l.has(2),ve.vertexUv3s=l.has(3),l.clear(),ve}function f(A){const E=[];if(A.shaderID?E.push(A.shaderID):(E.push(A.customVertexShaderID),E.push(A.customFragmentShaderID)),A.defines!==void 0)for(const C in A.defines)E.push(C),E.push(A.defines[C]);return A.isRawShaderMaterial===!1&&(M(E,A),_(E,A),E.push(s.outputColorSpace)),E.push(A.customProgramCacheKey),E.join()}function M(A,E){A.push(E.precision),A.push(E.outputColorSpace),A.push(E.envMapMode),A.push(E.envMapCubeUVHeight),A.push(E.mapUv),A.push(E.alphaMapUv),A.push(E.lightMapUv),A.push(E.aoMapUv),A.push(E.bumpMapUv),A.push(E.normalMapUv),A.push(E.displacementMapUv),A.push(E.emissiveMapUv),A.push(E.metalnessMapUv),A.push(E.roughnessMapUv),A.push(E.anisotropyMapUv),A.push(E.clearcoatMapUv),A.push(E.clearcoatNormalMapUv),A.push(E.clearcoatRoughnessMapUv),A.push(E.iridescenceMapUv),A.push(E.iridescenceThicknessMapUv),A.push(E.sheenColorMapUv),A.push(E.sheenRoughnessMapUv),A.push(E.specularMapUv),A.push(E.specularColorMapUv),A.push(E.specularIntensityMapUv),A.push(E.transmissionMapUv),A.push(E.thicknessMapUv),A.push(E.combine),A.push(E.fogExp2),A.push(E.sizeAttenuation),A.push(E.morphTargetsCount),A.push(E.morphAttributeCount),A.push(E.numDirLights),A.push(E.numPointLights),A.push(E.numSpotLights),A.push(E.numSpotLightMaps),A.push(E.numHemiLights),A.push(E.numRectAreaLights),A.push(E.numDirLightShadows),A.push(E.numPointLightShadows),A.push(E.numSpotLightShadows),A.push(E.numSpotLightShadowsWithMaps),A.push(E.numLightProbes),A.push(E.shadowMapType),A.push(E.toneMapping),A.push(E.numClippingPlanes),A.push(E.numClipIntersection),A.push(E.depthPacking)}function _(A,E){a.disableAll(),E.supportsVertexTextures&&a.enable(0),E.instancing&&a.enable(1),E.instancingColor&&a.enable(2),E.instancingMorph&&a.enable(3),E.matcap&&a.enable(4),E.envMap&&a.enable(5),E.normalMapObjectSpace&&a.enable(6),E.normalMapTangentSpace&&a.enable(7),E.clearcoat&&a.enable(8),E.iridescence&&a.enable(9),E.alphaTest&&a.enable(10),E.vertexColors&&a.enable(11),E.vertexAlphas&&a.enable(12),E.vertexUv1s&&a.enable(13),E.vertexUv2s&&a.enable(14),E.vertexUv3s&&a.enable(15),E.vertexTangents&&a.enable(16),E.anisotropy&&a.enable(17),E.alphaHash&&a.enable(18),E.batching&&a.enable(19),E.dispersion&&a.enable(20),E.batchingColor&&a.enable(21),E.gradientMap&&a.enable(22),A.push(a.mask),a.disableAll(),E.fog&&a.enable(0),E.useFog&&a.enable(1),E.flatShading&&a.enable(2),E.logarithmicDepthBuffer&&a.enable(3),E.reversedDepthBuffer&&a.enable(4),E.skinning&&a.enable(5),E.morphTargets&&a.enable(6),E.morphNormals&&a.enable(7),E.morphColors&&a.enable(8),E.premultipliedAlpha&&a.enable(9),E.shadowMapEnabled&&a.enable(10),E.doubleSided&&a.enable(11),E.flipSided&&a.enable(12),E.useDepthPacking&&a.enable(13),E.dithering&&a.enable(14),E.transmission&&a.enable(15),E.sheen&&a.enable(16),E.opaque&&a.enable(17),E.pointsUvs&&a.enable(18),E.decodeVideoTexture&&a.enable(19),E.decodeVideoTextureEmissive&&a.enable(20),E.alphaToCoverage&&a.enable(21),A.push(a.mask)}function v(A){const E=x[A.type];let C;if(E){const D=Bn[E];C=Ep.clone(D.uniforms)}else C=A.uniforms;return C}function b(A,E){let C;for(let D=0,O=h.length;D<O;D++){const H=h[D];if(H.cacheKey===E){C=H,++C.usedTimes;break}}return C===void 0&&(C=new Jg(s,E,A,r),h.push(C)),C}function S(A){if(--A.usedTimes===0){const E=h.indexOf(A);h[E]=h[h.length-1],h.pop(),A.destroy()}}function T(A){c.remove(A)}function P(){c.dispose()}return{getParameters:p,getProgramCacheKey:f,getUniforms:v,acquireProgram:b,releaseProgram:S,releaseShaderCache:T,programs:h,dispose:P}}function i_(){let s=new WeakMap;function t(o){return s.has(o)}function e(o){let a=s.get(o);return a===void 0&&(a={},s.set(o,a)),a}function n(o){s.delete(o)}function i(o,a,c){s.get(o)[a]=c}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function s_(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function $h(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Kh(){const s=[];let t=0;const e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function o(d,u,m,x,g,p){let f=s[t];return f===void 0?(f={id:d.id,object:d,geometry:u,material:m,groupOrder:x,renderOrder:d.renderOrder,z:g,group:p},s[t]=f):(f.id=d.id,f.object=d,f.geometry=u,f.material=m,f.groupOrder=x,f.renderOrder=d.renderOrder,f.z=g,f.group=p),t++,f}function a(d,u,m,x,g,p){const f=o(d,u,m,x,g,p);m.transmission>0?n.push(f):m.transparent===!0?i.push(f):e.push(f)}function c(d,u,m,x,g,p){const f=o(d,u,m,x,g,p);m.transmission>0?n.unshift(f):m.transparent===!0?i.unshift(f):e.unshift(f)}function l(d,u){e.length>1&&e.sort(d||s_),n.length>1&&n.sort(u||$h),i.length>1&&i.sort(u||$h)}function h(){for(let d=t,u=s.length;d<u;d++){const m=s[d];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:a,unshift:c,finish:h,sort:l}}function r_(){let s=new WeakMap;function t(n,i){const r=s.get(n);let o;return r===void 0?(o=new Kh,s.set(n,[o])):i>=r.length?(o=new Kh,r.push(o)):o=r[i],o}function e(){s=new WeakMap}return{get:t,dispose:e}}function o_(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new B,color:new se};break;case"SpotLight":e={position:new B,direction:new B,color:new se,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new B,color:new se,distance:0,decay:0};break;case"HemisphereLight":e={direction:new B,skyColor:new se,groundColor:new se};break;case"RectAreaLight":e={color:new se,position:new B,halfWidth:new B,halfHeight:new B};break}return s[t.id]=e,e}}}function a_(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}let c_=0;function l_(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function h_(s){const t=new o_,e=a_(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new B);const i=new B,r=new Me,o=new Me;function a(l){let h=0,d=0,u=0;for(let A=0;A<9;A++)n.probe[A].set(0,0,0);let m=0,x=0,g=0,p=0,f=0,M=0,_=0,v=0,b=0,S=0,T=0;l.sort(l_);for(let A=0,E=l.length;A<E;A++){const C=l[A],D=C.color,O=C.intensity,H=C.distance,W=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)h+=D.r*O,d+=D.g*O,u+=D.b*O;else if(C.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(C.sh.coefficients[$],O);T++}else if(C.isDirectionalLight){const $=t.get(C);if($.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const G=C.shadow,V=e.get(C);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,n.directionalShadow[m]=V,n.directionalShadowMap[m]=W,n.directionalShadowMatrix[m]=C.shadow.matrix,M++}n.directional[m]=$,m++}else if(C.isSpotLight){const $=t.get(C);$.position.setFromMatrixPosition(C.matrixWorld),$.color.copy(D).multiplyScalar(O),$.distance=H,$.coneCos=Math.cos(C.angle),$.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),$.decay=C.decay,n.spot[g]=$;const G=C.shadow;if(C.map&&(n.spotLightMap[b]=C.map,b++,G.updateMatrices(C),C.castShadow&&S++),n.spotLightMatrix[g]=G.matrix,C.castShadow){const V=e.get(C);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,n.spotShadow[g]=V,n.spotShadowMap[g]=W,v++}g++}else if(C.isRectAreaLight){const $=t.get(C);$.color.copy(D).multiplyScalar(O),$.halfWidth.set(C.width*.5,0,0),$.halfHeight.set(0,C.height*.5,0),n.rectArea[p]=$,p++}else if(C.isPointLight){const $=t.get(C);if($.color.copy(C.color).multiplyScalar(C.intensity),$.distance=C.distance,$.decay=C.decay,C.castShadow){const G=C.shadow,V=e.get(C);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,V.shadowCameraNear=G.camera.near,V.shadowCameraFar=G.camera.far,n.pointShadow[x]=V,n.pointShadowMap[x]=W,n.pointShadowMatrix[x]=C.shadow.matrix,_++}n.point[x]=$,x++}else if(C.isHemisphereLight){const $=t.get(C);$.skyColor.copy(C.color).multiplyScalar(O),$.groundColor.copy(C.groundColor).multiplyScalar(O),n.hemi[f]=$,f++}}p>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=lt.LTC_FLOAT_1,n.rectAreaLTC2=lt.LTC_FLOAT_2):(n.rectAreaLTC1=lt.LTC_HALF_1,n.rectAreaLTC2=lt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=d,n.ambient[2]=u;const P=n.hash;(P.directionalLength!==m||P.pointLength!==x||P.spotLength!==g||P.rectAreaLength!==p||P.hemiLength!==f||P.numDirectionalShadows!==M||P.numPointShadows!==_||P.numSpotShadows!==v||P.numSpotMaps!==b||P.numLightProbes!==T)&&(n.directional.length=m,n.spot.length=g,n.rectArea.length=p,n.point.length=x,n.hemi.length=f,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=_,n.pointShadowMap.length=_,n.spotShadow.length=v,n.spotShadowMap.length=v,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=_,n.spotLightMatrix.length=v+b-S,n.spotLightMap.length=b,n.numSpotLightShadowsWithMaps=S,n.numLightProbes=T,P.directionalLength=m,P.pointLength=x,P.spotLength=g,P.rectAreaLength=p,P.hemiLength=f,P.numDirectionalShadows=M,P.numPointShadows=_,P.numSpotShadows=v,P.numSpotMaps=b,P.numLightProbes=T,n.version=c_++)}function c(l,h){let d=0,u=0,m=0,x=0,g=0;const p=h.matrixWorldInverse;for(let f=0,M=l.length;f<M;f++){const _=l[f];if(_.isDirectionalLight){const v=n.directional[d];v.direction.setFromMatrixPosition(_.matrixWorld),i.setFromMatrixPosition(_.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(p),d++}else if(_.isSpotLight){const v=n.spot[m];v.position.setFromMatrixPosition(_.matrixWorld),v.position.applyMatrix4(p),v.direction.setFromMatrixPosition(_.matrixWorld),i.setFromMatrixPosition(_.target.matrixWorld),v.direction.sub(i),v.direction.transformDirection(p),m++}else if(_.isRectAreaLight){const v=n.rectArea[x];v.position.setFromMatrixPosition(_.matrixWorld),v.position.applyMatrix4(p),o.identity(),r.copy(_.matrixWorld),r.premultiply(p),o.extractRotation(r),v.halfWidth.set(_.width*.5,0,0),v.halfHeight.set(0,_.height*.5,0),v.halfWidth.applyMatrix4(o),v.halfHeight.applyMatrix4(o),x++}else if(_.isPointLight){const v=n.point[u];v.position.setFromMatrixPosition(_.matrixWorld),v.position.applyMatrix4(p),u++}else if(_.isHemisphereLight){const v=n.hemi[g];v.direction.setFromMatrixPosition(_.matrixWorld),v.direction.transformDirection(p),g++}}}return{setup:a,setupView:c,state:n}}function Zh(s){const t=new h_(s),e=[],n=[];function i(h){l.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function c(h){t.setupView(e,h)}const l={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function d_(s){let t=new WeakMap;function e(i,r=0){const o=t.get(i);let a;return o===void 0?(a=new Zh(s),t.set(i,[a])):r>=o.length?(a=new Zh(s),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}const u_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,f_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function p_(s,t,e){let n=new Eu;const i=new zt,r=new zt,o=new Le,a=new Np({depthPacking:qf}),c=new Op,l={},h=e.maxTextureSize,d={[Fi]:Ke,[Ke]:Fi,[Pn]:Pn},u=new Gn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new zt},radius:{value:4}},vertexShader:u_,fragmentShader:f_}),m=u.clone();m.defines.HORIZONTAL_PASS=1;const x=new Fn;x.setAttribute("position",new Dn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const g=new sn(x,u),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ru;let f=this.type;this.render=function(S,T,P){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||S.length===0)return;const A=s.getRenderTarget(),E=s.getActiveCubeFace(),C=s.getActiveMipmapLevel(),D=s.state;D.setBlending(oi),D.buffers.depth.getReversed()===!0?D.buffers.color.setClear(0,0,0,0):D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);const O=f!==ni&&this.type===ni,H=f===ni&&this.type!==ni;for(let W=0,$=S.length;W<$;W++){const G=S[W],V=G.shadow;if(V===void 0){Ht("WebGLShadowMap:",G,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;i.copy(V.mapSize);const Y=V.getFrameExtents();if(i.multiply(Y),r.copy(V.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/Y.x),i.x=r.x*Y.x,V.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/Y.y),i.y=r.y*Y.y,V.mapSize.y=r.y)),V.map===null||O===!0||H===!0){const St=this.type!==ni?{minFilter:pn,magFilter:pn}:{};V.map!==null&&V.map.dispose(),V.map=new as(i.x,i.y,St),V.map.texture.name=G.name+".shadowMap",V.camera.updateProjectionMatrix()}s.setRenderTarget(V.map),s.clear();const st=V.getViewportCount();for(let St=0;St<st;St++){const kt=V.getViewport(St);o.set(r.x*kt.x,r.y*kt.y,r.x*kt.z,r.y*kt.w),D.viewport(o),V.updateMatrices(G,St),n=V.getFrustum(),v(T,P,V.camera,G,this.type)}V.isPointLightShadow!==!0&&this.type===ni&&M(V,P),V.needsUpdate=!1}f=this.type,p.needsUpdate=!1,s.setRenderTarget(A,E,C)};function M(S,T){const P=t.update(g);u.defines.VSM_SAMPLES!==S.blurSamples&&(u.defines.VSM_SAMPLES=S.blurSamples,m.defines.VSM_SAMPLES=S.blurSamples,u.needsUpdate=!0,m.needsUpdate=!0),S.mapPass===null&&(S.mapPass=new as(i.x,i.y)),u.uniforms.shadow_pass.value=S.map.texture,u.uniforms.resolution.value=S.mapSize,u.uniforms.radius.value=S.radius,s.setRenderTarget(S.mapPass),s.clear(),s.renderBufferDirect(T,null,P,u,g,null),m.uniforms.shadow_pass.value=S.mapPass.texture,m.uniforms.resolution.value=S.mapSize,m.uniforms.radius.value=S.radius,s.setRenderTarget(S.map),s.clear(),s.renderBufferDirect(T,null,P,m,g,null)}function _(S,T,P,A){let E=null;const C=P.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(C!==void 0)E=C;else if(E=P.isPointLight===!0?c:a,s.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){const D=E.uuid,O=T.uuid;let H=l[D];H===void 0&&(H={},l[D]=H);let W=H[O];W===void 0&&(W=E.clone(),H[O]=W,T.addEventListener("dispose",b)),E=W}if(E.visible=T.visible,E.wireframe=T.wireframe,A===ni?E.side=T.shadowSide!==null?T.shadowSide:T.side:E.side=T.shadowSide!==null?T.shadowSide:d[T.side],E.alphaMap=T.alphaMap,E.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,E.map=T.map,E.clipShadows=T.clipShadows,E.clippingPlanes=T.clippingPlanes,E.clipIntersection=T.clipIntersection,E.displacementMap=T.displacementMap,E.displacementScale=T.displacementScale,E.displacementBias=T.displacementBias,E.wireframeLinewidth=T.wireframeLinewidth,E.linewidth=T.linewidth,P.isPointLight===!0&&E.isMeshDistanceMaterial===!0){const D=s.properties.get(E);D.light=P}return E}function v(S,T,P,A,E){if(S.visible===!1)return;if(S.layers.test(T.layers)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&E===ni)&&(!S.frustumCulled||n.intersectsObject(S))){S.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,S.matrixWorld);const O=t.update(S),H=S.material;if(Array.isArray(H)){const W=O.groups;for(let $=0,G=W.length;$<G;$++){const V=W[$],Y=H[V.materialIndex];if(Y&&Y.visible){const st=_(S,Y,A,E);S.onBeforeShadow(s,S,T,P,O,st,V),s.renderBufferDirect(P,null,O,st,S,V),S.onAfterShadow(s,S,T,P,O,st,V)}}}else if(H.visible){const W=_(S,H,A,E);S.onBeforeShadow(s,S,T,P,O,W,null),s.renderBufferDirect(P,null,O,W,S,null),S.onAfterShadow(s,S,T,P,O,W,null)}}const D=S.children;for(let O=0,H=D.length;O<H;O++)v(D[O],T,P,A,E)}function b(S){S.target.removeEventListener("dispose",b);for(const P in l){const A=l[P],E=S.target.uuid;E in A&&(A[E].dispose(),delete A[E])}}}const m_={[lc]:hc,[dc]:pc,[uc]:mc,[Bs]:fc,[hc]:lc,[pc]:dc,[mc]:uc,[fc]:Bs};function x_(s,t){function e(){let I=!1;const dt=new Le;let at=null;const ct=new Le(0,0,0,0);return{setMask:function(it){at!==it&&!I&&(s.colorMask(it,it,it,it),at=it)},setLocked:function(it){I=it},setClear:function(it,J,vt,Vt,ve){ve===!0&&(it*=Vt,J*=Vt,vt*=Vt),dt.set(it,J,vt,Vt),ct.equals(dt)===!1&&(s.clearColor(it,J,vt,Vt),ct.copy(dt))},reset:function(){I=!1,at=null,ct.set(-1,0,0,0)}}}function n(){let I=!1,dt=!1,at=null,ct=null,it=null;return{setReversed:function(J){if(dt!==J){const vt=t.get("EXT_clip_control");J?vt.clipControlEXT(vt.LOWER_LEFT_EXT,vt.ZERO_TO_ONE_EXT):vt.clipControlEXT(vt.LOWER_LEFT_EXT,vt.NEGATIVE_ONE_TO_ONE_EXT),dt=J;const Vt=it;it=null,this.setClear(Vt)}},getReversed:function(){return dt},setTest:function(J){J?Q(s.DEPTH_TEST):ut(s.DEPTH_TEST)},setMask:function(J){at!==J&&!I&&(s.depthMask(J),at=J)},setFunc:function(J){if(dt&&(J=m_[J]),ct!==J){switch(J){case lc:s.depthFunc(s.NEVER);break;case hc:s.depthFunc(s.ALWAYS);break;case dc:s.depthFunc(s.LESS);break;case Bs:s.depthFunc(s.LEQUAL);break;case uc:s.depthFunc(s.EQUAL);break;case fc:s.depthFunc(s.GEQUAL);break;case pc:s.depthFunc(s.GREATER);break;case mc:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}ct=J}},setLocked:function(J){I=J},setClear:function(J){it!==J&&(dt&&(J=1-J),s.clearDepth(J),it=J)},reset:function(){I=!1,at=null,ct=null,it=null,dt=!1}}}function i(){let I=!1,dt=null,at=null,ct=null,it=null,J=null,vt=null,Vt=null,ve=null;return{setTest:function(de){I||(de?Q(s.STENCIL_TEST):ut(s.STENCIL_TEST))},setMask:function(de){dt!==de&&!I&&(s.stencilMask(de),dt=de)},setFunc:function(de,Un,En){(at!==de||ct!==Un||it!==En)&&(s.stencilFunc(de,Un,En),at=de,ct=Un,it=En)},setOp:function(de,Un,En){(J!==de||vt!==Un||Vt!==En)&&(s.stencilOp(de,Un,En),J=de,vt=Un,Vt=En)},setLocked:function(de){I=de},setClear:function(de){ve!==de&&(s.clearStencil(de),ve=de)},reset:function(){I=!1,dt=null,at=null,ct=null,it=null,J=null,vt=null,Vt=null,ve=null}}}const r=new e,o=new n,a=new i,c=new WeakMap,l=new WeakMap;let h={},d={},u=new WeakMap,m=[],x=null,g=!1,p=null,f=null,M=null,_=null,v=null,b=null,S=null,T=new se(0,0,0),P=0,A=!1,E=null,C=null,D=null,O=null,H=null;const W=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,G=0;const V=s.getParameter(s.VERSION);V.indexOf("WebGL")!==-1?(G=parseFloat(/^WebGL (\d)/.exec(V)[1]),$=G>=1):V.indexOf("OpenGL ES")!==-1&&(G=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),$=G>=2);let Y=null,st={};const St=s.getParameter(s.SCISSOR_BOX),kt=s.getParameter(s.VIEWPORT),qt=new Le().fromArray(St),ce=new Le().fromArray(kt);function le(I,dt,at,ct){const it=new Uint8Array(4),J=s.createTexture();s.bindTexture(I,J),s.texParameteri(I,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(I,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let vt=0;vt<at;vt++)I===s.TEXTURE_3D||I===s.TEXTURE_2D_ARRAY?s.texImage3D(dt,0,s.RGBA,1,1,ct,0,s.RGBA,s.UNSIGNED_BYTE,it):s.texImage2D(dt+vt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,it);return J}const Z={};Z[s.TEXTURE_2D]=le(s.TEXTURE_2D,s.TEXTURE_2D,1),Z[s.TEXTURE_CUBE_MAP]=le(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Z[s.TEXTURE_2D_ARRAY]=le(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Z[s.TEXTURE_3D]=le(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),Q(s.DEPTH_TEST),o.setFunc(Bs),Qt(!1),te(Jl),Q(s.CULL_FACE),ie(oi);function Q(I){h[I]!==!0&&(s.enable(I),h[I]=!0)}function ut(I){h[I]!==!1&&(s.disable(I),h[I]=!1)}function Lt(I,dt){return d[I]!==dt?(s.bindFramebuffer(I,dt),d[I]=dt,I===s.DRAW_FRAMEBUFFER&&(d[s.FRAMEBUFFER]=dt),I===s.FRAMEBUFFER&&(d[s.DRAW_FRAMEBUFFER]=dt),!0):!1}function yt(I,dt){let at=m,ct=!1;if(I){at=u.get(dt),at===void 0&&(at=[],u.set(dt,at));const it=I.textures;if(at.length!==it.length||at[0]!==s.COLOR_ATTACHMENT0){for(let J=0,vt=it.length;J<vt;J++)at[J]=s.COLOR_ATTACHMENT0+J;at.length=it.length,ct=!0}}else at[0]!==s.BACK&&(at[0]=s.BACK,ct=!0);ct&&s.drawBuffers(at)}function Wt(I){return x!==I?(s.useProgram(I),x=I,!0):!1}const Se={[es]:s.FUNC_ADD,[_f]:s.FUNC_SUBTRACT,[vf]:s.FUNC_REVERSE_SUBTRACT};Se[bf]=s.MIN,Se[Mf]=s.MAX;const Yt={[Sf]:s.ZERO,[yf]:s.ONE,[Ef]:s.SRC_COLOR,[ac]:s.SRC_ALPHA,[Pf]:s.SRC_ALPHA_SATURATE,[Cf]:s.DST_COLOR,[wf]:s.DST_ALPHA,[Af]:s.ONE_MINUS_SRC_COLOR,[cc]:s.ONE_MINUS_SRC_ALPHA,[Rf]:s.ONE_MINUS_DST_COLOR,[Tf]:s.ONE_MINUS_DST_ALPHA,[Lf]:s.CONSTANT_COLOR,[If]:s.ONE_MINUS_CONSTANT_COLOR,[Df]:s.CONSTANT_ALPHA,[Ff]:s.ONE_MINUS_CONSTANT_ALPHA};function ie(I,dt,at,ct,it,J,vt,Vt,ve,de){if(I===oi){g===!0&&(ut(s.BLEND),g=!1);return}if(g===!1&&(Q(s.BLEND),g=!0),I!==gf){if(I!==p||de!==A){if((f!==es||v!==es)&&(s.blendEquation(s.FUNC_ADD),f=es,v=es),de)switch(I){case Ns:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ql:s.blendFunc(s.ONE,s.ONE);break;case th:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case eh:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:Pe("WebGLState: Invalid blending: ",I);break}else switch(I){case Ns:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ql:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case th:Pe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case eh:Pe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Pe("WebGLState: Invalid blending: ",I);break}M=null,_=null,b=null,S=null,T.set(0,0,0),P=0,p=I,A=de}return}it=it||dt,J=J||at,vt=vt||ct,(dt!==f||it!==v)&&(s.blendEquationSeparate(Se[dt],Se[it]),f=dt,v=it),(at!==M||ct!==_||J!==b||vt!==S)&&(s.blendFuncSeparate(Yt[at],Yt[ct],Yt[J],Yt[vt]),M=at,_=ct,b=J,S=vt),(Vt.equals(T)===!1||ve!==P)&&(s.blendColor(Vt.r,Vt.g,Vt.b,ve),T.copy(Vt),P=ve),p=I,A=!1}function L(I,dt){I.side===Pn?ut(s.CULL_FACE):Q(s.CULL_FACE);let at=I.side===Ke;dt&&(at=!at),Qt(at),I.blending===Ns&&I.transparent===!1?ie(oi):ie(I.blending,I.blendEquation,I.blendSrc,I.blendDst,I.blendEquationAlpha,I.blendSrcAlpha,I.blendDstAlpha,I.blendColor,I.blendAlpha,I.premultipliedAlpha),o.setFunc(I.depthFunc),o.setTest(I.depthTest),o.setMask(I.depthWrite),r.setMask(I.colorWrite);const ct=I.stencilWrite;a.setTest(ct),ct&&(a.setMask(I.stencilWriteMask),a.setFunc(I.stencilFunc,I.stencilRef,I.stencilFuncMask),a.setOp(I.stencilFail,I.stencilZFail,I.stencilZPass)),Mt(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),I.alphaToCoverage===!0?Q(s.SAMPLE_ALPHA_TO_COVERAGE):ut(s.SAMPLE_ALPHA_TO_COVERAGE)}function Qt(I){E!==I&&(I?s.frontFace(s.CW):s.frontFace(s.CCW),E=I)}function te(I){I!==pf?(Q(s.CULL_FACE),I!==C&&(I===Jl?s.cullFace(s.BACK):I===mf?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):ut(s.CULL_FACE),C=I}function _e(I){I!==D&&($&&s.lineWidth(I),D=I)}function Mt(I,dt,at){I?(Q(s.POLYGON_OFFSET_FILL),(O!==dt||H!==at)&&(s.polygonOffset(dt,at),O=dt,H=at)):ut(s.POLYGON_OFFSET_FILL)}function ye(I){I?Q(s.SCISSOR_TEST):ut(s.SCISSOR_TEST)}function Ct(I){I===void 0&&(I=s.TEXTURE0+W-1),Y!==I&&(s.activeTexture(I),Y=I)}function Gt(I,dt,at){at===void 0&&(Y===null?at=s.TEXTURE0+W-1:at=Y);let ct=st[at];ct===void 0&&(ct={type:void 0,texture:void 0},st[at]=ct),(ct.type!==I||ct.texture!==dt)&&(Y!==at&&(s.activeTexture(at),Y=at),s.bindTexture(I,dt||Z[I]),ct.type=I,ct.texture=dt)}function R(){const I=st[Y];I!==void 0&&I.type!==void 0&&(s.bindTexture(I.type,null),I.type=void 0,I.texture=void 0)}function y(){try{s.compressedTexImage2D(...arguments)}catch(I){I("WebGLState:",I)}}function k(){try{s.compressedTexImage3D(...arguments)}catch(I){I("WebGLState:",I)}}function j(){try{s.texSubImage2D(...arguments)}catch(I){I("WebGLState:",I)}}function tt(){try{s.texSubImage3D(...arguments)}catch(I){I("WebGLState:",I)}}function K(){try{s.compressedTexSubImage2D(...arguments)}catch(I){I("WebGLState:",I)}}function wt(){try{s.compressedTexSubImage3D(...arguments)}catch(I){I("WebGLState:",I)}}function ht(){try{s.texStorage2D(...arguments)}catch(I){I("WebGLState:",I)}}function Rt(){try{s.texStorage3D(...arguments)}catch(I){I("WebGLState:",I)}}function At(){try{s.texImage2D(...arguments)}catch(I){I("WebGLState:",I)}}function et(){try{s.texImage3D(...arguments)}catch(I){I("WebGLState:",I)}}function ot(I){qt.equals(I)===!1&&(s.scissor(I.x,I.y,I.z,I.w),qt.copy(I))}function Ut(I){ce.equals(I)===!1&&(s.viewport(I.x,I.y,I.z,I.w),ce.copy(I))}function It(I,dt){let at=l.get(dt);at===void 0&&(at=new WeakMap,l.set(dt,at));let ct=at.get(I);ct===void 0&&(ct=s.getUniformBlockIndex(dt,I.name),at.set(I,ct))}function pt(I,dt){const ct=l.get(dt).get(I);c.get(dt)!==ct&&(s.uniformBlockBinding(dt,ct,I.__bindingPointIndex),c.set(dt,ct))}function Ot(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),o.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},Y=null,st={},d={},u=new WeakMap,m=[],x=null,g=!1,p=null,f=null,M=null,_=null,v=null,b=null,S=null,T=new se(0,0,0),P=0,A=!1,E=null,C=null,D=null,O=null,H=null,qt.set(0,0,s.canvas.width,s.canvas.height),ce.set(0,0,s.canvas.width,s.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:Q,disable:ut,bindFramebuffer:Lt,drawBuffers:yt,useProgram:Wt,setBlending:ie,setMaterial:L,setFlipSided:Qt,setCullFace:te,setLineWidth:_e,setPolygonOffset:Mt,setScissorTest:ye,activeTexture:Ct,bindTexture:Gt,unbindTexture:R,compressedTexImage2D:y,compressedTexImage3D:k,texImage2D:At,texImage3D:et,updateUBOMapping:It,uniformBlockBinding:pt,texStorage2D:ht,texStorage3D:Rt,texSubImage2D:j,texSubImage3D:tt,compressedTexSubImage2D:K,compressedTexSubImage3D:wt,scissor:ot,viewport:Ut,reset:Ot}}function g_(s,t,e,n,i,r,o){const a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new zt,h=new WeakMap;let d;const u=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function x(R,y){return m?new OffscreenCanvas(R,y):Vo("canvas")}function g(R,y,k){let j=1;const tt=Gt(R);if((tt.width>k||tt.height>k)&&(j=k/Math.max(tt.width,tt.height)),j<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const K=Math.floor(j*tt.width),wt=Math.floor(j*tt.height);d===void 0&&(d=x(K,wt));const ht=y?x(K,wt):d;return ht.width=K,ht.height=wt,ht.getContext("2d").drawImage(R,0,0,K,wt),Ht("WebGLRenderer: Texture has been resized from ("+tt.width+"x"+tt.height+") to ("+K+"x"+wt+")."),ht}else return"data"in R&&Ht("WebGLRenderer: Image in DataTexture is too big ("+tt.width+"x"+tt.height+")."),R;return R}function p(R){return R.generateMipmaps}function f(R){s.generateMipmap(R)}function M(R){return R.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?s.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function _(R,y,k,j,tt=!1){if(R!==null){if(s[R]!==void 0)return s[R];Ht("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let K=y;if(y===s.RED&&(k===s.FLOAT&&(K=s.R32F),k===s.HALF_FLOAT&&(K=s.R16F),k===s.UNSIGNED_BYTE&&(K=s.R8)),y===s.RED_INTEGER&&(k===s.UNSIGNED_BYTE&&(K=s.R8UI),k===s.UNSIGNED_SHORT&&(K=s.R16UI),k===s.UNSIGNED_INT&&(K=s.R32UI),k===s.BYTE&&(K=s.R8I),k===s.SHORT&&(K=s.R16I),k===s.INT&&(K=s.R32I)),y===s.RG&&(k===s.FLOAT&&(K=s.RG32F),k===s.HALF_FLOAT&&(K=s.RG16F),k===s.UNSIGNED_BYTE&&(K=s.RG8)),y===s.RG_INTEGER&&(k===s.UNSIGNED_BYTE&&(K=s.RG8UI),k===s.UNSIGNED_SHORT&&(K=s.RG16UI),k===s.UNSIGNED_INT&&(K=s.RG32UI),k===s.BYTE&&(K=s.RG8I),k===s.SHORT&&(K=s.RG16I),k===s.INT&&(K=s.RG32I)),y===s.RGB_INTEGER&&(k===s.UNSIGNED_BYTE&&(K=s.RGB8UI),k===s.UNSIGNED_SHORT&&(K=s.RGB16UI),k===s.UNSIGNED_INT&&(K=s.RGB32UI),k===s.BYTE&&(K=s.RGB8I),k===s.SHORT&&(K=s.RGB16I),k===s.INT&&(K=s.RGB32I)),y===s.RGBA_INTEGER&&(k===s.UNSIGNED_BYTE&&(K=s.RGBA8UI),k===s.UNSIGNED_SHORT&&(K=s.RGBA16UI),k===s.UNSIGNED_INT&&(K=s.RGBA32UI),k===s.BYTE&&(K=s.RGBA8I),k===s.SHORT&&(K=s.RGBA16I),k===s.INT&&(K=s.RGBA32I)),y===s.RGB&&(k===s.UNSIGNED_INT_5_9_9_9_REV&&(K=s.RGB9_E5),k===s.UNSIGNED_INT_10F_11F_11F_REV&&(K=s.R11F_G11F_B10F)),y===s.RGBA){const wt=tt?Bo:oe.getTransfer(j);k===s.FLOAT&&(K=s.RGBA32F),k===s.HALF_FLOAT&&(K=s.RGBA16F),k===s.UNSIGNED_BYTE&&(K=wt===fe?s.SRGB8_ALPHA8:s.RGBA8),k===s.UNSIGNED_SHORT_4_4_4_4&&(K=s.RGBA4),k===s.UNSIGNED_SHORT_5_5_5_1&&(K=s.RGB5_A1)}return(K===s.R16F||K===s.R32F||K===s.RG16F||K===s.RG32F||K===s.RGBA16F||K===s.RGBA32F)&&t.get("EXT_color_buffer_float"),K}function v(R,y){let k;return R?y===null||y===os||y===Er?k=s.DEPTH24_STENCIL8:y===zn?k=s.DEPTH32F_STENCIL8:y===yr&&(k=s.DEPTH24_STENCIL8,Ht("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):y===null||y===os||y===Er?k=s.DEPTH_COMPONENT24:y===zn?k=s.DEPTH_COMPONENT32F:y===yr&&(k=s.DEPTH_COMPONENT16),k}function b(R,y){return p(R)===!0||R.isFramebufferTexture&&R.minFilter!==pn&&R.minFilter!==en?Math.log2(Math.max(y.width,y.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?y.mipmaps.length:1}function S(R){const y=R.target;y.removeEventListener("dispose",S),P(y),y.isVideoTexture&&h.delete(y)}function T(R){const y=R.target;y.removeEventListener("dispose",T),E(y)}function P(R){const y=n.get(R);if(y.__webglInit===void 0)return;const k=R.source,j=u.get(k);if(j){const tt=j[y.__cacheKey];tt.usedTimes--,tt.usedTimes===0&&A(R),Object.keys(j).length===0&&u.delete(k)}n.remove(R)}function A(R){const y=n.get(R);s.deleteTexture(y.__webglTexture);const k=R.source,j=u.get(k);delete j[y.__cacheKey],o.memory.textures--}function E(R){const y=n.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),n.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(y.__webglFramebuffer[j]))for(let tt=0;tt<y.__webglFramebuffer[j].length;tt++)s.deleteFramebuffer(y.__webglFramebuffer[j][tt]);else s.deleteFramebuffer(y.__webglFramebuffer[j]);y.__webglDepthbuffer&&s.deleteRenderbuffer(y.__webglDepthbuffer[j])}else{if(Array.isArray(y.__webglFramebuffer))for(let j=0;j<y.__webglFramebuffer.length;j++)s.deleteFramebuffer(y.__webglFramebuffer[j]);else s.deleteFramebuffer(y.__webglFramebuffer);if(y.__webglDepthbuffer&&s.deleteRenderbuffer(y.__webglDepthbuffer),y.__webglMultisampledFramebuffer&&s.deleteFramebuffer(y.__webglMultisampledFramebuffer),y.__webglColorRenderbuffer)for(let j=0;j<y.__webglColorRenderbuffer.length;j++)y.__webglColorRenderbuffer[j]&&s.deleteRenderbuffer(y.__webglColorRenderbuffer[j]);y.__webglDepthRenderbuffer&&s.deleteRenderbuffer(y.__webglDepthRenderbuffer)}const k=R.textures;for(let j=0,tt=k.length;j<tt;j++){const K=n.get(k[j]);K.__webglTexture&&(s.deleteTexture(K.__webglTexture),o.memory.textures--),n.remove(k[j])}n.remove(R)}let C=0;function D(){C=0}function O(){const R=C;return R>=i.maxTextures&&Ht("WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+i.maxTextures),C+=1,R}function H(R){const y=[];return y.push(R.wrapS),y.push(R.wrapT),y.push(R.wrapR||0),y.push(R.magFilter),y.push(R.minFilter),y.push(R.anisotropy),y.push(R.internalFormat),y.push(R.format),y.push(R.type),y.push(R.generateMipmaps),y.push(R.premultiplyAlpha),y.push(R.flipY),y.push(R.unpackAlignment),y.push(R.colorSpace),y.join()}function W(R,y){const k=n.get(R);if(R.isVideoTexture&&ye(R),R.isRenderTargetTexture===!1&&R.isExternalTexture!==!0&&R.version>0&&k.__version!==R.version){const j=R.image;if(j===null)Ht("WebGLRenderer: Texture marked for update but no image data found.");else if(j.complete===!1)Ht("WebGLRenderer: Texture marked for update but image is incomplete");else{Z(k,R,y);return}}else R.isExternalTexture&&(k.__webglTexture=R.sourceTexture?R.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,k.__webglTexture,s.TEXTURE0+y)}function $(R,y){const k=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&k.__version!==R.version){Z(k,R,y);return}else R.isExternalTexture&&(k.__webglTexture=R.sourceTexture?R.sourceTexture:null);e.bindTexture(s.TEXTURE_2D_ARRAY,k.__webglTexture,s.TEXTURE0+y)}function G(R,y){const k=n.get(R);if(R.isRenderTargetTexture===!1&&R.version>0&&k.__version!==R.version){Z(k,R,y);return}e.bindTexture(s.TEXTURE_3D,k.__webglTexture,s.TEXTURE0+y)}function V(R,y){const k=n.get(R);if(R.version>0&&k.__version!==R.version){Q(k,R,y);return}e.bindTexture(s.TEXTURE_CUBE_MAP,k.__webglTexture,s.TEXTURE0+y)}const Y={[Oo]:s.REPEAT,[si]:s.CLAMP_TO_EDGE,[_c]:s.MIRRORED_REPEAT},st={[pn]:s.NEAREST,[Wf]:s.NEAREST_MIPMAP_NEAREST,[Or]:s.NEAREST_MIPMAP_LINEAR,[en]:s.LINEAR,[ha]:s.LINEAR_MIPMAP_NEAREST,[ss]:s.LINEAR_MIPMAP_LINEAR},St={[Kf]:s.NEVER,[ep]:s.ALWAYS,[Zf]:s.LESS,[pu]:s.LEQUAL,[jf]:s.EQUAL,[tp]:s.GEQUAL,[Jf]:s.GREATER,[Qf]:s.NOTEQUAL};function kt(R,y){if(y.type===zn&&t.has("OES_texture_float_linear")===!1&&(y.magFilter===en||y.magFilter===ha||y.magFilter===Or||y.magFilter===ss||y.minFilter===en||y.minFilter===ha||y.minFilter===Or||y.minFilter===ss)&&Ht("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(R,s.TEXTURE_WRAP_S,Y[y.wrapS]),s.texParameteri(R,s.TEXTURE_WRAP_T,Y[y.wrapT]),(R===s.TEXTURE_3D||R===s.TEXTURE_2D_ARRAY)&&s.texParameteri(R,s.TEXTURE_WRAP_R,Y[y.wrapR]),s.texParameteri(R,s.TEXTURE_MAG_FILTER,st[y.magFilter]),s.texParameteri(R,s.TEXTURE_MIN_FILTER,st[y.minFilter]),y.compareFunction&&(s.texParameteri(R,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(R,s.TEXTURE_COMPARE_FUNC,St[y.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(y.magFilter===pn||y.minFilter!==Or&&y.minFilter!==ss||y.type===zn&&t.has("OES_texture_float_linear")===!1)return;if(y.anisotropy>1||n.get(y).__currentAnisotropy){const k=t.get("EXT_texture_filter_anisotropic");s.texParameterf(R,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(y.anisotropy,i.getMaxAnisotropy())),n.get(y).__currentAnisotropy=y.anisotropy}}}function qt(R,y){let k=!1;R.__webglInit===void 0&&(R.__webglInit=!0,y.addEventListener("dispose",S));const j=y.source;let tt=u.get(j);tt===void 0&&(tt={},u.set(j,tt));const K=H(y);if(K!==R.__cacheKey){tt[K]===void 0&&(tt[K]={texture:s.createTexture(),usedTimes:0},o.memory.textures++,k=!0),tt[K].usedTimes++;const wt=tt[R.__cacheKey];wt!==void 0&&(tt[R.__cacheKey].usedTimes--,wt.usedTimes===0&&A(y)),R.__cacheKey=K,R.__webglTexture=tt[K].texture}return k}function ce(R,y,k){return Math.floor(Math.floor(R/k)/y)}function le(R,y,k,j){const K=R.updateRanges;if(K.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,y.width,y.height,k,j,y.data);else{K.sort((et,ot)=>et.start-ot.start);let wt=0;for(let et=1;et<K.length;et++){const ot=K[wt],Ut=K[et],It=ot.start+ot.count,pt=ce(Ut.start,y.width,4),Ot=ce(ot.start,y.width,4);Ut.start<=It+1&&pt===Ot&&ce(Ut.start+Ut.count-1,y.width,4)===pt?ot.count=Math.max(ot.count,Ut.start+Ut.count-ot.start):(++wt,K[wt]=Ut)}K.length=wt+1;const ht=s.getParameter(s.UNPACK_ROW_LENGTH),Rt=s.getParameter(s.UNPACK_SKIP_PIXELS),At=s.getParameter(s.UNPACK_SKIP_ROWS);s.pixelStorei(s.UNPACK_ROW_LENGTH,y.width);for(let et=0,ot=K.length;et<ot;et++){const Ut=K[et],It=Math.floor(Ut.start/4),pt=Math.ceil(Ut.count/4),Ot=It%y.width,I=Math.floor(It/y.width),dt=pt,at=1;s.pixelStorei(s.UNPACK_SKIP_PIXELS,Ot),s.pixelStorei(s.UNPACK_SKIP_ROWS,I),e.texSubImage2D(s.TEXTURE_2D,0,Ot,I,dt,at,k,j,y.data)}R.clearUpdateRanges(),s.pixelStorei(s.UNPACK_ROW_LENGTH,ht),s.pixelStorei(s.UNPACK_SKIP_PIXELS,Rt),s.pixelStorei(s.UNPACK_SKIP_ROWS,At)}}function Z(R,y,k){let j=s.TEXTURE_2D;(y.isDataArrayTexture||y.isCompressedArrayTexture)&&(j=s.TEXTURE_2D_ARRAY),y.isData3DTexture&&(j=s.TEXTURE_3D);const tt=qt(R,y),K=y.source;e.bindTexture(j,R.__webglTexture,s.TEXTURE0+k);const wt=n.get(K);if(K.version!==wt.__version||tt===!0){e.activeTexture(s.TEXTURE0+k);const ht=oe.getPrimaries(oe.workingColorSpace),Rt=y.colorSpace===Ri?null:oe.getPrimaries(y.colorSpace),At=y.colorSpace===Ri||ht===Rt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,y.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,y.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,At);let et=g(y.image,!1,i.maxTextureSize);et=Ct(y,et);const ot=r.convert(y.format,y.colorSpace),Ut=r.convert(y.type);let It=_(y.internalFormat,ot,Ut,y.colorSpace,y.isVideoTexture);kt(j,y);let pt;const Ot=y.mipmaps,I=y.isVideoTexture!==!0,dt=wt.__version===void 0||tt===!0,at=K.dataReady,ct=b(y,et);if(y.isDepthTexture)It=v(y.format===wr,y.type),dt&&(I?e.texStorage2D(s.TEXTURE_2D,1,It,et.width,et.height):e.texImage2D(s.TEXTURE_2D,0,It,et.width,et.height,0,ot,Ut,null));else if(y.isDataTexture)if(Ot.length>0){I&&dt&&e.texStorage2D(s.TEXTURE_2D,ct,It,Ot[0].width,Ot[0].height);for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],I?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,Ut,pt.data):e.texImage2D(s.TEXTURE_2D,it,It,pt.width,pt.height,0,ot,Ut,pt.data);y.generateMipmaps=!1}else I?(dt&&e.texStorage2D(s.TEXTURE_2D,ct,It,et.width,et.height),at&&le(y,et,ot,Ut)):e.texImage2D(s.TEXTURE_2D,0,It,et.width,et.height,0,ot,Ut,et.data);else if(y.isCompressedTexture)if(y.isCompressedArrayTexture){I&&dt&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ct,It,Ot[0].width,Ot[0].height,et.depth);for(let it=0,J=Ot.length;it<J;it++)if(pt=Ot[it],y.format!==In)if(ot!==null)if(I){if(at)if(y.layerUpdates.size>0){const vt=Th(pt.width,pt.height,y.format,y.type);for(const Vt of y.layerUpdates){const ve=pt.data.subarray(Vt*vt/pt.data.BYTES_PER_ELEMENT,(Vt+1)*vt/pt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,Vt,pt.width,pt.height,1,ot,ve)}y.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,0,pt.width,pt.height,et.depth,ot,pt.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,it,It,pt.width,pt.height,et.depth,0,pt.data,0,0);else Ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else I?at&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,0,pt.width,pt.height,et.depth,ot,Ut,pt.data):e.texImage3D(s.TEXTURE_2D_ARRAY,it,It,pt.width,pt.height,et.depth,0,ot,Ut,pt.data)}else{I&&dt&&e.texStorage2D(s.TEXTURE_2D,ct,It,Ot[0].width,Ot[0].height);for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],y.format!==In?ot!==null?I?at&&e.compressedTexSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,pt.data):e.compressedTexImage2D(s.TEXTURE_2D,it,It,pt.width,pt.height,0,pt.data):Ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):I?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,Ut,pt.data):e.texImage2D(s.TEXTURE_2D,it,It,pt.width,pt.height,0,ot,Ut,pt.data)}else if(y.isDataArrayTexture)if(I){if(dt&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ct,It,et.width,et.height,et.depth),at)if(y.layerUpdates.size>0){const it=Th(et.width,et.height,y.format,y.type);for(const J of y.layerUpdates){const vt=et.data.subarray(J*it/et.data.BYTES_PER_ELEMENT,(J+1)*it/et.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,J,et.width,et.height,1,ot,Ut,vt)}y.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,et.width,et.height,et.depth,ot,Ut,et.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,It,et.width,et.height,et.depth,0,ot,Ut,et.data);else if(y.isData3DTexture)I?(dt&&e.texStorage3D(s.TEXTURE_3D,ct,It,et.width,et.height,et.depth),at&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,et.width,et.height,et.depth,ot,Ut,et.data)):e.texImage3D(s.TEXTURE_3D,0,It,et.width,et.height,et.depth,0,ot,Ut,et.data);else if(y.isFramebufferTexture){if(dt)if(I)e.texStorage2D(s.TEXTURE_2D,ct,It,et.width,et.height);else{let it=et.width,J=et.height;for(let vt=0;vt<ct;vt++)e.texImage2D(s.TEXTURE_2D,vt,It,it,J,0,ot,Ut,null),it>>=1,J>>=1}}else if(Ot.length>0){if(I&&dt){const it=Gt(Ot[0]);e.texStorage2D(s.TEXTURE_2D,ct,It,it.width,it.height)}for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],I?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,ot,Ut,pt):e.texImage2D(s.TEXTURE_2D,it,It,ot,Ut,pt);y.generateMipmaps=!1}else if(I){if(dt){const it=Gt(et);e.texStorage2D(s.TEXTURE_2D,ct,It,it.width,it.height)}at&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,ot,Ut,et)}else e.texImage2D(s.TEXTURE_2D,0,It,ot,Ut,et);p(y)&&f(j),wt.__version=K.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function Q(R,y,k){if(y.image.length!==6)return;const j=qt(R,y),tt=y.source;e.bindTexture(s.TEXTURE_CUBE_MAP,R.__webglTexture,s.TEXTURE0+k);const K=n.get(tt);if(tt.version!==K.__version||j===!0){e.activeTexture(s.TEXTURE0+k);const wt=oe.getPrimaries(oe.workingColorSpace),ht=y.colorSpace===Ri?null:oe.getPrimaries(y.colorSpace),Rt=y.colorSpace===Ri||wt===ht?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,y.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,y.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,y.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Rt);const At=y.isCompressedTexture||y.image[0].isCompressedTexture,et=y.image[0]&&y.image[0].isDataTexture,ot=[];for(let J=0;J<6;J++)!At&&!et?ot[J]=g(y.image[J],!0,i.maxCubemapSize):ot[J]=et?y.image[J].image:y.image[J],ot[J]=Ct(y,ot[J]);const Ut=ot[0],It=r.convert(y.format,y.colorSpace),pt=r.convert(y.type),Ot=_(y.internalFormat,It,pt,y.colorSpace),I=y.isVideoTexture!==!0,dt=K.__version===void 0||j===!0,at=tt.dataReady;let ct=b(y,Ut);kt(s.TEXTURE_CUBE_MAP,y);let it;if(At){I&&dt&&e.texStorage2D(s.TEXTURE_CUBE_MAP,ct,Ot,Ut.width,Ut.height);for(let J=0;J<6;J++){it=ot[J].mipmaps;for(let vt=0;vt<it.length;vt++){const Vt=it[vt];y.format!==In?It!==null?I?at&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,0,0,Vt.width,Vt.height,It,Vt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,Ot,Vt.width,Vt.height,0,Vt.data):Ht("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):I?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,0,0,Vt.width,Vt.height,It,pt,Vt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,Ot,Vt.width,Vt.height,0,It,pt,Vt.data)}}}else{if(it=y.mipmaps,I&&dt){it.length>0&&ct++;const J=Gt(ot[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,ct,Ot,J.width,J.height)}for(let J=0;J<6;J++)if(et){I?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,ot[J].width,ot[J].height,It,pt,ot[J].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,Ot,ot[J].width,ot[J].height,0,It,pt,ot[J].data);for(let vt=0;vt<it.length;vt++){const ve=it[vt].image[J].image;I?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,0,0,ve.width,ve.height,It,pt,ve.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,Ot,ve.width,ve.height,0,It,pt,ve.data)}}else{I?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,It,pt,ot[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,Ot,It,pt,ot[J]);for(let vt=0;vt<it.length;vt++){const Vt=it[vt];I?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,0,0,It,pt,Vt.image[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,Ot,It,pt,Vt.image[J])}}}p(y)&&f(s.TEXTURE_CUBE_MAP),K.__version=tt.version,y.onUpdate&&y.onUpdate(y)}R.__version=y.version}function ut(R,y,k,j,tt,K){const wt=r.convert(k.format,k.colorSpace),ht=r.convert(k.type),Rt=_(k.internalFormat,wt,ht,k.colorSpace),At=n.get(y),et=n.get(k);if(et.__renderTarget=y,!At.__hasExternalTextures){const ot=Math.max(1,y.width>>K),Ut=Math.max(1,y.height>>K);tt===s.TEXTURE_3D||tt===s.TEXTURE_2D_ARRAY?e.texImage3D(tt,K,Rt,ot,Ut,y.depth,0,wt,ht,null):e.texImage2D(tt,K,Rt,ot,Ut,0,wt,ht,null)}e.bindFramebuffer(s.FRAMEBUFFER,R),Mt(y)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,j,tt,et.__webglTexture,0,_e(y)):(tt===s.TEXTURE_2D||tt>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&tt<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,j,tt,et.__webglTexture,K),e.bindFramebuffer(s.FRAMEBUFFER,null)}function Lt(R,y,k){if(s.bindRenderbuffer(s.RENDERBUFFER,R),y.depthBuffer){const j=y.depthTexture,tt=j&&j.isDepthTexture?j.type:null,K=v(y.stencilBuffer,tt),wt=y.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,ht=_e(y);Mt(y)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ht,K,y.width,y.height):k?s.renderbufferStorageMultisample(s.RENDERBUFFER,ht,K,y.width,y.height):s.renderbufferStorage(s.RENDERBUFFER,K,y.width,y.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,wt,s.RENDERBUFFER,R)}else{const j=y.textures;for(let tt=0;tt<j.length;tt++){const K=j[tt],wt=r.convert(K.format,K.colorSpace),ht=r.convert(K.type),Rt=_(K.internalFormat,wt,ht,K.colorSpace),At=_e(y);k&&Mt(y)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,At,Rt,y.width,y.height):Mt(y)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,At,Rt,y.width,y.height):s.renderbufferStorage(s.RENDERBUFFER,Rt,y.width,y.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function yt(R,y){if(y&&y.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,R),!(y.depthTexture&&y.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const j=n.get(y.depthTexture);j.__renderTarget=y,(!j.__webglTexture||y.depthTexture.image.width!==y.width||y.depthTexture.image.height!==y.height)&&(y.depthTexture.image.width=y.width,y.depthTexture.image.height=y.height,y.depthTexture.needsUpdate=!0),W(y.depthTexture,0);const tt=j.__webglTexture,K=_e(y);if(y.depthTexture.format===Ar)Mt(y)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0,K):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0);else if(y.depthTexture.format===wr)Mt(y)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0,K):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function Wt(R){const y=n.get(R),k=R.isWebGLCubeRenderTarget===!0;if(y.__boundDepthTexture!==R.depthTexture){const j=R.depthTexture;if(y.__depthDisposeCallback&&y.__depthDisposeCallback(),j){const tt=()=>{delete y.__boundDepthTexture,delete y.__depthDisposeCallback,j.removeEventListener("dispose",tt)};j.addEventListener("dispose",tt),y.__depthDisposeCallback=tt}y.__boundDepthTexture=j}if(R.depthTexture&&!y.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");const j=R.texture.mipmaps;j&&j.length>0?yt(y.__webglFramebuffer[0],R):yt(y.__webglFramebuffer,R)}else if(k){y.__webglDepthbuffer=[];for(let j=0;j<6;j++)if(e.bindFramebuffer(s.FRAMEBUFFER,y.__webglFramebuffer[j]),y.__webglDepthbuffer[j]===void 0)y.__webglDepthbuffer[j]=s.createRenderbuffer(),Lt(y.__webglDepthbuffer[j],R,!1);else{const tt=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,K=y.__webglDepthbuffer[j];s.bindRenderbuffer(s.RENDERBUFFER,K),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,K)}}else{const j=R.texture.mipmaps;if(j&&j.length>0?e.bindFramebuffer(s.FRAMEBUFFER,y.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,y.__webglFramebuffer),y.__webglDepthbuffer===void 0)y.__webglDepthbuffer=s.createRenderbuffer(),Lt(y.__webglDepthbuffer,R,!1);else{const tt=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,K=y.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,K),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,K)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function Se(R,y,k){const j=n.get(R);y!==void 0&&ut(j.__webglFramebuffer,R,R.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),k!==void 0&&Wt(R)}function Yt(R){const y=R.texture,k=n.get(R),j=n.get(y);R.addEventListener("dispose",T);const tt=R.textures,K=R.isWebGLCubeRenderTarget===!0,wt=tt.length>1;if(wt||(j.__webglTexture===void 0&&(j.__webglTexture=s.createTexture()),j.__version=y.version,o.memory.textures++),K){k.__webglFramebuffer=[];for(let ht=0;ht<6;ht++)if(y.mipmaps&&y.mipmaps.length>0){k.__webglFramebuffer[ht]=[];for(let Rt=0;Rt<y.mipmaps.length;Rt++)k.__webglFramebuffer[ht][Rt]=s.createFramebuffer()}else k.__webglFramebuffer[ht]=s.createFramebuffer()}else{if(y.mipmaps&&y.mipmaps.length>0){k.__webglFramebuffer=[];for(let ht=0;ht<y.mipmaps.length;ht++)k.__webglFramebuffer[ht]=s.createFramebuffer()}else k.__webglFramebuffer=s.createFramebuffer();if(wt)for(let ht=0,Rt=tt.length;ht<Rt;ht++){const At=n.get(tt[ht]);At.__webglTexture===void 0&&(At.__webglTexture=s.createTexture(),o.memory.textures++)}if(R.samples>0&&Mt(R)===!1){k.__webglMultisampledFramebuffer=s.createFramebuffer(),k.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let ht=0;ht<tt.length;ht++){const Rt=tt[ht];k.__webglColorRenderbuffer[ht]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,k.__webglColorRenderbuffer[ht]);const At=r.convert(Rt.format,Rt.colorSpace),et=r.convert(Rt.type),ot=_(Rt.internalFormat,At,et,Rt.colorSpace,R.isXRRenderTarget===!0),Ut=_e(R);s.renderbufferStorageMultisample(s.RENDERBUFFER,Ut,ot,R.width,R.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ht,s.RENDERBUFFER,k.__webglColorRenderbuffer[ht])}s.bindRenderbuffer(s.RENDERBUFFER,null),R.depthBuffer&&(k.__webglDepthRenderbuffer=s.createRenderbuffer(),Lt(k.__webglDepthRenderbuffer,R,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(K){e.bindTexture(s.TEXTURE_CUBE_MAP,j.__webglTexture),kt(s.TEXTURE_CUBE_MAP,y);for(let ht=0;ht<6;ht++)if(y.mipmaps&&y.mipmaps.length>0)for(let Rt=0;Rt<y.mipmaps.length;Rt++)ut(k.__webglFramebuffer[ht][Rt],R,y,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ht,Rt);else ut(k.__webglFramebuffer[ht],R,y,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ht,0);p(y)&&f(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(wt){for(let ht=0,Rt=tt.length;ht<Rt;ht++){const At=tt[ht],et=n.get(At);let ot=s.TEXTURE_2D;(R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ot=R.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ot,et.__webglTexture),kt(ot,At),ut(k.__webglFramebuffer,R,At,s.COLOR_ATTACHMENT0+ht,ot,0),p(At)&&f(ot)}e.unbindTexture()}else{let ht=s.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ht=R.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ht,j.__webglTexture),kt(ht,y),y.mipmaps&&y.mipmaps.length>0)for(let Rt=0;Rt<y.mipmaps.length;Rt++)ut(k.__webglFramebuffer[Rt],R,y,s.COLOR_ATTACHMENT0,ht,Rt);else ut(k.__webglFramebuffer,R,y,s.COLOR_ATTACHMENT0,ht,0);p(y)&&f(ht),e.unbindTexture()}R.depthBuffer&&Wt(R)}function ie(R){const y=R.textures;for(let k=0,j=y.length;k<j;k++){const tt=y[k];if(p(tt)){const K=M(R),wt=n.get(tt).__webglTexture;e.bindTexture(K,wt),f(K),e.unbindTexture()}}}const L=[],Qt=[];function te(R){if(R.samples>0){if(Mt(R)===!1){const y=R.textures,k=R.width,j=R.height;let tt=s.COLOR_BUFFER_BIT;const K=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,wt=n.get(R),ht=y.length>1;if(ht)for(let At=0;At<y.length;At++)e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+At,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+At,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,wt.__webglMultisampledFramebuffer);const Rt=R.texture.mipmaps;Rt&&Rt.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglFramebuffer);for(let At=0;At<y.length;At++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(tt|=s.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(tt|=s.STENCIL_BUFFER_BIT)),ht){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,wt.__webglColorRenderbuffer[At]);const et=n.get(y[At]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,et,0)}s.blitFramebuffer(0,0,k,j,0,0,k,j,tt,s.NEAREST),c===!0&&(L.length=0,Qt.length=0,L.push(s.COLOR_ATTACHMENT0+At),R.depthBuffer&&R.resolveDepthBuffer===!1&&(L.push(K),Qt.push(K),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Qt)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,L))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ht)for(let At=0;At<y.length;At++){e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+At,s.RENDERBUFFER,wt.__webglColorRenderbuffer[At]);const et=n.get(y[At]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+At,s.TEXTURE_2D,et,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&c){const y=R.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[y])}}}function _e(R){return Math.min(i.maxSamples,R.samples)}function Mt(R){const y=n.get(R);return R.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&y.__useRenderToTexture!==!1}function ye(R){const y=o.render.frame;h.get(R)!==y&&(h.set(R,y),R.update())}function Ct(R,y){const k=R.colorSpace,j=R.format,tt=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||k!==ks&&k!==Ri&&(oe.getTransfer(k)===fe?(j!==In||tt!==ci)&&Ht("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Pe("WebGLTextures: Unsupported texture color space:",k)),y}function Gt(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(l.width=R.naturalWidth||R.width,l.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(l.width=R.displayWidth,l.height=R.displayHeight):(l.width=R.width,l.height=R.height),l}this.allocateTextureUnit=O,this.resetTextureUnits=D,this.setTexture2D=W,this.setTexture2DArray=$,this.setTexture3D=G,this.setTextureCube=V,this.rebindTextures=Se,this.setupRenderTarget=Yt,this.updateRenderTargetMipmap=ie,this.updateMultisampleRenderTarget=te,this.setupDepthRenderbuffer=Wt,this.setupFrameBufferTexture=ut,this.useMultisampledRTT=Mt}function __(s,t){function e(n,i=Ri){let r;const o=oe.getTransfer(i);if(n===ci)return s.UNSIGNED_BYTE;if(n===pl)return s.UNSIGNED_SHORT_4_4_4_4;if(n===ml)return s.UNSIGNED_SHORT_5_5_5_1;if(n===hu)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===du)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===cu)return s.BYTE;if(n===lu)return s.SHORT;if(n===yr)return s.UNSIGNED_SHORT;if(n===fl)return s.INT;if(n===os)return s.UNSIGNED_INT;if(n===zn)return s.FLOAT;if(n===Ws)return s.HALF_FLOAT;if(n===uu)return s.ALPHA;if(n===fu)return s.RGB;if(n===In)return s.RGBA;if(n===Ar)return s.DEPTH_COMPONENT;if(n===wr)return s.DEPTH_STENCIL;if(n===xl)return s.RED;if(n===gl)return s.RED_INTEGER;if(n===_l)return s.RG;if(n===vl)return s.RG_INTEGER;if(n===bl)return s.RGBA_INTEGER;if(n===wo||n===To||n===Co||n===Ro)if(o===fe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===wo)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===To)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Co)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Ro)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===wo)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===To)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Co)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Ro)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===vc||n===bc||n===Mc||n===Sc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===vc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===bc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Mc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Sc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===yc||n===Ec||n===Ac)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===yc||n===Ec)return o===fe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Ac)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===wc||n===Tc||n===Cc||n===Rc||n===Pc||n===Lc||n===Ic||n===Dc||n===Fc||n===Uc||n===Nc||n===Oc||n===Bc||n===zc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===wc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Tc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Cc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Rc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Pc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Lc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ic)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Dc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Fc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Uc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Nc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Oc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Bc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===zc)return o===fe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Vc||n===kc||n===Gc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Vc)return o===fe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===kc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Gc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Hc||n===Wc||n===Xc||n===qc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Hc)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Wc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Xc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===qc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Er?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}const v_=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,b_=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class M_{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new wu(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new Gn({vertexShader:v_,fragmentShader:b_,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new sn(new Xs(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class S_ extends ls{constructor(t,e){super();const n=this;let i=null,r=1,o=null,a="local-floor",c=1,l=null,h=null,d=null,u=null,m=null,x=null;const g=typeof XRWebGLBinding<"u",p=new M_,f={},M=e.getContextAttributes();let _=null,v=null;const b=[],S=[],T=new zt;let P=null;const A=new Sn;A.viewport=new Le;const E=new Sn;E.viewport=new Le;const C=[A,E],D=new zp;let O=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let Q=b[Z];return Q===void 0&&(Q=new Ia,b[Z]=Q),Q.getTargetRaySpace()},this.getControllerGrip=function(Z){let Q=b[Z];return Q===void 0&&(Q=new Ia,b[Z]=Q),Q.getGripSpace()},this.getHand=function(Z){let Q=b[Z];return Q===void 0&&(Q=new Ia,b[Z]=Q),Q.getHandSpace()};function W(Z){const Q=S.indexOf(Z.inputSource);if(Q===-1)return;const ut=b[Q];ut!==void 0&&(ut.update(Z.inputSource,Z.frame,l||o),ut.dispatchEvent({type:Z.type,data:Z.inputSource}))}function $(){i.removeEventListener("select",W),i.removeEventListener("selectstart",W),i.removeEventListener("selectend",W),i.removeEventListener("squeeze",W),i.removeEventListener("squeezestart",W),i.removeEventListener("squeezeend",W),i.removeEventListener("end",$),i.removeEventListener("inputsourceschange",G);for(let Z=0;Z<b.length;Z++){const Q=S[Z];Q!==null&&(S[Z]=null,b[Z].disconnect(Q))}O=null,H=null,p.reset();for(const Z in f)delete f[Z];t.setRenderTarget(_),m=null,u=null,d=null,i=null,v=null,le.stop(),n.isPresenting=!1,t.setPixelRatio(P),t.setSize(T.width,T.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){r=Z,n.isPresenting===!0&&Ht("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){a=Z,n.isPresenting===!0&&Ht("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(Z){l=Z},this.getBaseLayer=function(){return u!==null?u:m},this.getBinding=function(){return d===null&&g&&(d=new XRWebGLBinding(i,e)),d},this.getFrame=function(){return x},this.getSession=function(){return i},this.setSession=async function(Z){if(i=Z,i!==null){if(_=t.getRenderTarget(),i.addEventListener("select",W),i.addEventListener("selectstart",W),i.addEventListener("selectend",W),i.addEventListener("squeeze",W),i.addEventListener("squeezestart",W),i.addEventListener("squeezeend",W),i.addEventListener("end",$),i.addEventListener("inputsourceschange",G),M.xrCompatible!==!0&&await e.makeXRCompatible(),P=t.getPixelRatio(),t.getSize(T),g&&"createProjectionLayer"in XRWebGLBinding.prototype){let ut=null,Lt=null,yt=null;M.depth&&(yt=M.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,ut=M.stencil?wr:Ar,Lt=M.stencil?Er:os);const Wt={colorFormat:e.RGBA8,depthFormat:yt,scaleFactor:r};d=this.getBinding(),u=d.createProjectionLayer(Wt),i.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),v=new as(u.textureWidth,u.textureHeight,{format:In,type:ci,depthTexture:new Au(u.textureWidth,u.textureHeight,Lt,void 0,void 0,void 0,void 0,void 0,void 0,ut),stencilBuffer:M.stencil,colorSpace:t.outputColorSpace,samples:M.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1,resolveStencilBuffer:u.ignoreDepthValues===!1})}else{const ut={antialias:M.antialias,alpha:!0,depth:M.depth,stencil:M.stencil,framebufferScaleFactor:r};m=new XRWebGLLayer(i,e,ut),i.updateRenderState({baseLayer:m}),t.setPixelRatio(1),t.setSize(m.framebufferWidth,m.framebufferHeight,!1),v=new as(m.framebufferWidth,m.framebufferHeight,{format:In,type:ci,colorSpace:t.outputColorSpace,stencilBuffer:M.stencil,resolveDepthBuffer:m.ignoreDepthValues===!1,resolveStencilBuffer:m.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await i.requestReferenceSpace(a),le.setContext(i),le.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return p.getDepthTexture()};function G(Z){for(let Q=0;Q<Z.removed.length;Q++){const ut=Z.removed[Q],Lt=S.indexOf(ut);Lt>=0&&(S[Lt]=null,b[Lt].disconnect(ut))}for(let Q=0;Q<Z.added.length;Q++){const ut=Z.added[Q];let Lt=S.indexOf(ut);if(Lt===-1){for(let Wt=0;Wt<b.length;Wt++)if(Wt>=S.length){S.push(ut),Lt=Wt;break}else if(S[Wt]===null){S[Wt]=ut,Lt=Wt;break}if(Lt===-1)break}const yt=b[Lt];yt&&yt.connect(ut)}}const V=new B,Y=new B;function st(Z,Q,ut){V.setFromMatrixPosition(Q.matrixWorld),Y.setFromMatrixPosition(ut.matrixWorld);const Lt=V.distanceTo(Y),yt=Q.projectionMatrix.elements,Wt=ut.projectionMatrix.elements,Se=yt[14]/(yt[10]-1),Yt=yt[14]/(yt[10]+1),ie=(yt[9]+1)/yt[5],L=(yt[9]-1)/yt[5],Qt=(yt[8]-1)/yt[0],te=(Wt[8]+1)/Wt[0],_e=Se*Qt,Mt=Se*te,ye=Lt/(-Qt+te),Ct=ye*-Qt;if(Q.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(Ct),Z.translateZ(ye),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),yt[10]===-1)Z.projectionMatrix.copy(Q.projectionMatrix),Z.projectionMatrixInverse.copy(Q.projectionMatrixInverse);else{const Gt=Se+ye,R=Yt+ye,y=_e-Ct,k=Mt+(Lt-Ct),j=ie*Yt/R*Gt,tt=L*Yt/R*Gt;Z.projectionMatrix.makePerspective(y,k,j,tt,Gt,R),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function St(Z,Q){Q===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(Q.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(i===null)return;let Q=Z.near,ut=Z.far;p.texture!==null&&(p.depthNear>0&&(Q=p.depthNear),p.depthFar>0&&(ut=p.depthFar)),D.near=E.near=A.near=Q,D.far=E.far=A.far=ut,(O!==D.near||H!==D.far)&&(i.updateRenderState({depthNear:D.near,depthFar:D.far}),O=D.near,H=D.far),D.layers.mask=Z.layers.mask|6,A.layers.mask=D.layers.mask&3,E.layers.mask=D.layers.mask&5;const Lt=Z.parent,yt=D.cameras;St(D,Lt);for(let Wt=0;Wt<yt.length;Wt++)St(yt[Wt],Lt);yt.length===2?st(D,A,E):D.projectionMatrix.copy(A.projectionMatrix),kt(Z,D,Lt)};function kt(Z,Q,ut){ut===null?Z.matrix.copy(Q.matrixWorld):(Z.matrix.copy(ut.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(Q.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(Q.projectionMatrix),Z.projectionMatrixInverse.copy(Q.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=Yc*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return D},this.getFoveation=function(){if(!(u===null&&m===null))return c},this.setFoveation=function(Z){c=Z,u!==null&&(u.fixedFoveation=Z),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=Z)},this.hasDepthSensing=function(){return p.texture!==null},this.getDepthSensingMesh=function(){return p.getMesh(D)},this.getCameraTexture=function(Z){return f[Z]};let qt=null;function ce(Z,Q){if(h=Q.getViewerPose(l||o),x=Q,h!==null){const ut=h.views;m!==null&&(t.setRenderTargetFramebuffer(v,m.framebuffer),t.setRenderTarget(v));let Lt=!1;ut.length!==D.cameras.length&&(D.cameras.length=0,Lt=!0);for(let Yt=0;Yt<ut.length;Yt++){const ie=ut[Yt];let L=null;if(m!==null)L=m.getViewport(ie);else{const te=d.getViewSubImage(u,ie);L=te.viewport,Yt===0&&(t.setRenderTargetTextures(v,te.colorTexture,te.depthStencilTexture),t.setRenderTarget(v))}let Qt=C[Yt];Qt===void 0&&(Qt=new Sn,Qt.layers.enable(Yt),Qt.viewport=new Le,C[Yt]=Qt),Qt.matrix.fromArray(ie.transform.matrix),Qt.matrix.decompose(Qt.position,Qt.quaternion,Qt.scale),Qt.projectionMatrix.fromArray(ie.projectionMatrix),Qt.projectionMatrixInverse.copy(Qt.projectionMatrix).invert(),Qt.viewport.set(L.x,L.y,L.width,L.height),Yt===0&&(D.matrix.copy(Qt.matrix),D.matrix.decompose(D.position,D.quaternion,D.scale)),Lt===!0&&D.cameras.push(Qt)}const yt=i.enabledFeatures;if(yt&&yt.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&g){d=n.getBinding();const Yt=d.getDepthInformation(ut[0]);Yt&&Yt.isValid&&Yt.texture&&p.init(Yt,i.renderState)}if(yt&&yt.includes("camera-access")&&g){t.state.unbindTexture(),d=n.getBinding();for(let Yt=0;Yt<ut.length;Yt++){const ie=ut[Yt].camera;if(ie){let L=f[ie];L||(L=new wu,f[ie]=L);const Qt=d.getCameraImage(ie);L.sourceTexture=Qt}}}}for(let ut=0;ut<b.length;ut++){const Lt=S[ut],yt=b[ut];Lt!==null&&yt!==void 0&&yt.update(Lt,Q,l||o)}qt&&qt(Z,Q),Q.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Q}),x=null}const le=new Tu;le.setAnimationLoop(ce),this.setAnimationLoop=function(Z){qt=Z},this.dispose=function(){}}}const Wi=new li,y_=new Me;function E_(s,t){function e(p,f){p.matrixAutoUpdate===!0&&p.updateMatrix(),f.value.copy(p.matrix)}function n(p,f){f.color.getRGB(p.fogColor.value,bu(s)),f.isFog?(p.fogNear.value=f.near,p.fogFar.value=f.far):f.isFogExp2&&(p.fogDensity.value=f.density)}function i(p,f,M,_,v){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(p,f):f.isMeshToonMaterial?(r(p,f),d(p,f)):f.isMeshPhongMaterial?(r(p,f),h(p,f)):f.isMeshStandardMaterial?(r(p,f),u(p,f),f.isMeshPhysicalMaterial&&m(p,f,v)):f.isMeshMatcapMaterial?(r(p,f),x(p,f)):f.isMeshDepthMaterial?r(p,f):f.isMeshDistanceMaterial?(r(p,f),g(p,f)):f.isMeshNormalMaterial?r(p,f):f.isLineBasicMaterial?(o(p,f),f.isLineDashedMaterial&&a(p,f)):f.isPointsMaterial?c(p,f,M,_):f.isSpriteMaterial?l(p,f):f.isShadowMaterial?(p.color.value.copy(f.color),p.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(p,f){p.opacity.value=f.opacity,f.color&&p.diffuse.value.copy(f.color),f.emissive&&p.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(p.map.value=f.map,e(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,e(f.alphaMap,p.alphaMapTransform)),f.bumpMap&&(p.bumpMap.value=f.bumpMap,e(f.bumpMap,p.bumpMapTransform),p.bumpScale.value=f.bumpScale,f.side===Ke&&(p.bumpScale.value*=-1)),f.normalMap&&(p.normalMap.value=f.normalMap,e(f.normalMap,p.normalMapTransform),p.normalScale.value.copy(f.normalScale),f.side===Ke&&p.normalScale.value.negate()),f.displacementMap&&(p.displacementMap.value=f.displacementMap,e(f.displacementMap,p.displacementMapTransform),p.displacementScale.value=f.displacementScale,p.displacementBias.value=f.displacementBias),f.emissiveMap&&(p.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,p.emissiveMapTransform)),f.specularMap&&(p.specularMap.value=f.specularMap,e(f.specularMap,p.specularMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);const M=t.get(f),_=M.envMap,v=M.envMapRotation;_&&(p.envMap.value=_,Wi.copy(v),Wi.x*=-1,Wi.y*=-1,Wi.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(Wi.y*=-1,Wi.z*=-1),p.envMapRotation.value.setFromMatrix4(y_.makeRotationFromEuler(Wi)),p.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=f.reflectivity,p.ior.value=f.ior,p.refractionRatio.value=f.refractionRatio),f.lightMap&&(p.lightMap.value=f.lightMap,p.lightMapIntensity.value=f.lightMapIntensity,e(f.lightMap,p.lightMapTransform)),f.aoMap&&(p.aoMap.value=f.aoMap,p.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,p.aoMapTransform))}function o(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,f.map&&(p.map.value=f.map,e(f.map,p.mapTransform))}function a(p,f){p.dashSize.value=f.dashSize,p.totalSize.value=f.dashSize+f.gapSize,p.scale.value=f.scale}function c(p,f,M,_){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.size.value=f.size*M,p.scale.value=_*.5,f.map&&(p.map.value=f.map,e(f.map,p.uvTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,e(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function l(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.rotation.value=f.rotation,f.map&&(p.map.value=f.map,e(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,e(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function h(p,f){p.specular.value.copy(f.specular),p.shininess.value=Math.max(f.shininess,1e-4)}function d(p,f){f.gradientMap&&(p.gradientMap.value=f.gradientMap)}function u(p,f){p.metalness.value=f.metalness,f.metalnessMap&&(p.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,p.metalnessMapTransform)),p.roughness.value=f.roughness,f.roughnessMap&&(p.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,p.roughnessMapTransform)),f.envMap&&(p.envMapIntensity.value=f.envMapIntensity)}function m(p,f,M){p.ior.value=f.ior,f.sheen>0&&(p.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),p.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(p.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,p.sheenColorMapTransform)),f.sheenRoughnessMap&&(p.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,p.sheenRoughnessMapTransform))),f.clearcoat>0&&(p.clearcoat.value=f.clearcoat,p.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(p.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,p.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(p.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Ke&&p.clearcoatNormalScale.value.negate())),f.dispersion>0&&(p.dispersion.value=f.dispersion),f.iridescence>0&&(p.iridescence.value=f.iridescence,p.iridescenceIOR.value=f.iridescenceIOR,p.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(p.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,p.iridescenceMapTransform)),f.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),f.transmission>0&&(p.transmission.value=f.transmission,p.transmissionSamplerMap.value=M.texture,p.transmissionSamplerSize.value.set(M.width,M.height),f.transmissionMap&&(p.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,p.transmissionMapTransform)),p.thickness.value=f.thickness,f.thicknessMap&&(p.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=f.attenuationDistance,p.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(p.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(p.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=f.specularIntensity,p.specularColor.value.copy(f.specularColor),f.specularColorMap&&(p.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,p.specularColorMapTransform)),f.specularIntensityMap&&(p.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,p.specularIntensityMapTransform))}function x(p,f){f.matcap&&(p.matcap.value=f.matcap)}function g(p,f){const M=t.get(f).light;p.referencePosition.value.setFromMatrixPosition(M.matrixWorld),p.nearDistance.value=M.shadow.camera.near,p.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function A_(s,t,e,n){let i={},r={},o=[];const a=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function c(M,_){const v=_.program;n.uniformBlockBinding(M,v)}function l(M,_){let v=i[M.id];v===void 0&&(x(M),v=h(M),i[M.id]=v,M.addEventListener("dispose",p));const b=_.program;n.updateUBOMapping(M,b);const S=t.render.frame;r[M.id]!==S&&(u(M),r[M.id]=S)}function h(M){const _=d();M.__bindingPointIndex=_;const v=s.createBuffer(),b=M.__size,S=M.usage;return s.bindBuffer(s.UNIFORM_BUFFER,v),s.bufferData(s.UNIFORM_BUFFER,b,S),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,_,v),v}function d(){for(let M=0;M<a;M++)if(o.indexOf(M)===-1)return o.push(M),M;return Pe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(M){const _=i[M.id],v=M.uniforms,b=M.__cache;s.bindBuffer(s.UNIFORM_BUFFER,_);for(let S=0,T=v.length;S<T;S++){const P=Array.isArray(v[S])?v[S]:[v[S]];for(let A=0,E=P.length;A<E;A++){const C=P[A];if(m(C,S,A,b)===!0){const D=C.__offset,O=Array.isArray(C.value)?C.value:[C.value];let H=0;for(let W=0;W<O.length;W++){const $=O[W],G=g($);typeof $=="number"||typeof $=="boolean"?(C.__data[0]=$,s.bufferSubData(s.UNIFORM_BUFFER,D+H,C.__data)):$.isMatrix3?(C.__data[0]=$.elements[0],C.__data[1]=$.elements[1],C.__data[2]=$.elements[2],C.__data[3]=0,C.__data[4]=$.elements[3],C.__data[5]=$.elements[4],C.__data[6]=$.elements[5],C.__data[7]=0,C.__data[8]=$.elements[6],C.__data[9]=$.elements[7],C.__data[10]=$.elements[8],C.__data[11]=0):($.toArray(C.__data,H),H+=G.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,D,C.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function m(M,_,v,b){const S=M.value,T=_+"_"+v;if(b[T]===void 0)return typeof S=="number"||typeof S=="boolean"?b[T]=S:b[T]=S.clone(),!0;{const P=b[T];if(typeof S=="number"||typeof S=="boolean"){if(P!==S)return b[T]=S,!0}else if(P.equals(S)===!1)return P.copy(S),!0}return!1}function x(M){const _=M.uniforms;let v=0;const b=16;for(let T=0,P=_.length;T<P;T++){const A=Array.isArray(_[T])?_[T]:[_[T]];for(let E=0,C=A.length;E<C;E++){const D=A[E],O=Array.isArray(D.value)?D.value:[D.value];for(let H=0,W=O.length;H<W;H++){const $=O[H],G=g($),V=v%b,Y=V%G.boundary,st=V+Y;v+=Y,st!==0&&b-st<G.storage&&(v+=b-st),D.__data=new Float32Array(G.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=v,v+=G.storage}}}const S=v%b;return S>0&&(v+=b-S),M.__size=v,M.__cache={},this}function g(M){const _={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(_.boundary=4,_.storage=4):M.isVector2?(_.boundary=8,_.storage=8):M.isVector3||M.isColor?(_.boundary=16,_.storage=12):M.isVector4?(_.boundary=16,_.storage=16):M.isMatrix3?(_.boundary=48,_.storage=48):M.isMatrix4?(_.boundary=64,_.storage=64):M.isTexture?Ht("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Ht("WebGLRenderer: Unsupported uniform value type.",M),_}function p(M){const _=M.target;_.removeEventListener("dispose",p);const v=o.indexOf(_.__bindingPointIndex);o.splice(v,1),s.deleteBuffer(i[_.id]),delete i[_.id],delete r[_.id]}function f(){for(const M in i)s.deleteBuffer(i[M]);o=[],i={},r={}}return{bind:c,update:l,dispose:f}}const w_=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let Kn=null;function T_(){return Kn===null&&(Kn=new yu(w_,32,32,_l,Ws),Kn.minFilter=en,Kn.magFilter=en,Kn.wrapS=si,Kn.wrapT=si,Kn.generateMipmaps=!1,Kn.needsUpdate=!0),Kn}class C_{constructor(t={}){const{canvas:e=np(),context:n=null,depth:i=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1,reversedDepthBuffer:u=!1}=t;this.isWebGLRenderer=!0;let m;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");m=n.getContextAttributes().alpha}else m=o;const x=new Set([bl,vl,gl]),g=new Set([ci,os,yr,Er,pl,ml]),p=new Uint32Array(4),f=new Int32Array(4);let M=null,_=null;const v=[],b=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Di,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const S=this;let T=!1;this._outputColorSpace=bn;let P=0,A=0,E=null,C=-1,D=null;const O=new Le,H=new Le;let W=null;const $=new se(0);let G=0,V=e.width,Y=e.height,st=1,St=null,kt=null;const qt=new Le(0,0,V,Y),ce=new Le(0,0,V,Y);let le=!1;const Z=new Eu;let Q=!1,ut=!1;const Lt=new Me,yt=new B,Wt=new Le,Se={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Yt=!1;function ie(){return E===null?st:1}let L=n;function Qt(w,N){return e.getContext(w,N)}try{const w={alpha:!0,depth:i,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${ul}`),e.addEventListener("webglcontextlost",it,!1),e.addEventListener("webglcontextrestored",J,!1),e.addEventListener("webglcontextcreationerror",vt,!1),L===null){const N="webgl2";if(L=Qt(N,w),L===null)throw Qt(N)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw w("WebGLRenderer: "+w.message),w}let te,_e,Mt,ye,Ct,Gt,R,y,k,j,tt,K,wt,ht,Rt,At,et,ot,Ut,It,pt,Ot,I,dt;function at(){te=new Nx(L),te.init(),Ot=new __(L,te),_e=new Tx(L,te,t,Ot),Mt=new x_(L,te),_e.reversedDepthBuffer&&u&&Mt.buffers.depth.setReversed(!0),ye=new zx(L),Ct=new i_,Gt=new g_(L,te,Mt,Ct,_e,Ot,ye),R=new Rx(S),y=new Ux(S),k=new Hp(L),I=new Ax(L,k),j=new Ox(L,k,ye,I),tt=new kx(L,j,k,ye),Ut=new Vx(L,_e,Gt),At=new Cx(Ct),K=new n_(S,R,y,te,_e,I,At),wt=new E_(S,Ct),ht=new r_,Rt=new d_(te),ot=new Ex(S,R,y,Mt,tt,m,c),et=new p_(S,tt,_e),dt=new A_(L,ye,_e,Mt),It=new wx(L,te,ye),pt=new Bx(L,te,ye),ye.programs=K.programs,S.capabilities=_e,S.extensions=te,S.properties=Ct,S.renderLists=ht,S.shadowMap=et,S.state=Mt,S.info=ye}at();const ct=new S_(S,L);this.xr=ct,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const w=te.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=te.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return st},this.setPixelRatio=function(w){w!==void 0&&(st=w,this.setSize(V,Y,!1))},this.getSize=function(w){return w.set(V,Y)},this.setSize=function(w,N,X=!0){if(ct.isPresenting){Ht("WebGLRenderer: Can't change size while VR device is presenting.");return}V=w,Y=N,e.width=Math.floor(w*st),e.height=Math.floor(N*st),X===!0&&(e.style.width=w+"px",e.style.height=N+"px"),this.setViewport(0,0,w,N)},this.getDrawingBufferSize=function(w){return w.set(V*st,Y*st).floor()},this.setDrawingBufferSize=function(w,N,X){V=w,Y=N,st=X,e.width=Math.floor(w*X),e.height=Math.floor(N*X),this.setViewport(0,0,w,N)},this.getCurrentViewport=function(w){return w.copy(O)},this.getViewport=function(w){return w.copy(qt)},this.setViewport=function(w,N,X,q){w.isVector4?qt.set(w.x,w.y,w.z,w.w):qt.set(w,N,X,q),Mt.viewport(O.copy(qt).multiplyScalar(st).round())},this.getScissor=function(w){return w.copy(ce)},this.setScissor=function(w,N,X,q){w.isVector4?ce.set(w.x,w.y,w.z,w.w):ce.set(w,N,X,q),Mt.scissor(H.copy(ce).multiplyScalar(st).round())},this.getScissorTest=function(){return le},this.setScissorTest=function(w){Mt.setScissorTest(le=w)},this.setOpaqueSort=function(w){St=w},this.setTransparentSort=function(w){kt=w},this.getClearColor=function(w){return w.copy(ot.getClearColor())},this.setClearColor=function(){ot.setClearColor(...arguments)},this.getClearAlpha=function(){return ot.getClearAlpha()},this.setClearAlpha=function(){ot.setClearAlpha(...arguments)},this.clear=function(w=!0,N=!0,X=!0){let q=0;if(w){let z=!1;if(E!==null){const rt=E.texture.format;z=x.has(rt)}if(z){const rt=E.texture.type,ft=g.has(rt),bt=ot.getClearColor(),xt=ot.getClearAlpha(),Dt=bt.r,Nt=bt.g,Tt=bt.b;ft?(p[0]=Dt,p[1]=Nt,p[2]=Tt,p[3]=xt,L.clearBufferuiv(L.COLOR,0,p)):(f[0]=Dt,f[1]=Nt,f[2]=Tt,f[3]=xt,L.clearBufferiv(L.COLOR,0,f))}else q|=L.COLOR_BUFFER_BIT}N&&(q|=L.DEPTH_BUFFER_BIT),X&&(q|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",it,!1),e.removeEventListener("webglcontextrestored",J,!1),e.removeEventListener("webglcontextcreationerror",vt,!1),ot.dispose(),ht.dispose(),Rt.dispose(),Ct.dispose(),R.dispose(),y.dispose(),tt.dispose(),I.dispose(),dt.dispose(),K.dispose(),ct.dispose(),ct.removeEventListener("sessionstart",Xl),ct.removeEventListener("sessionend",ql),Oi.stop()};function it(w){w.preventDefault(),oh("WebGLRenderer: Context Lost."),T=!0}function J(){oh("WebGLRenderer: Context Restored."),T=!1;const w=ye.autoReset,N=et.enabled,X=et.autoUpdate,q=et.needsUpdate,z=et.type;at(),ye.autoReset=w,et.enabled=N,et.autoUpdate=X,et.needsUpdate=q,et.type=z}function vt(w){Pe("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function Vt(w){const N=w.target;N.removeEventListener("dispose",Vt),ve(N)}function ve(w){de(w),Ct.remove(w)}function de(w){const N=Ct.get(w).programs;N!==void 0&&(N.forEach(function(X){K.releaseProgram(X)}),w.isShaderMaterial&&K.releaseShaderCache(w))}this.renderBufferDirect=function(w,N,X,q,z,rt){N===null&&(N=Se);const ft=z.isMesh&&z.matrixWorld.determinant()<0,bt=of(w,N,X,q,z);Mt.setMaterial(q,ft);let xt=X.index,Dt=1;if(q.wireframe===!0){if(xt=j.getWireframeAttribute(X),xt===void 0)return;Dt=2}const Nt=X.drawRange,Tt=X.attributes.position;let ee=Nt.start*Dt,ue=(Nt.start+Nt.count)*Dt;rt!==null&&(ee=Math.max(ee,rt.start*Dt),ue=Math.min(ue,(rt.start+rt.count)*Dt)),xt!==null?(ee=Math.max(ee,0),ue=Math.min(ue,xt.count)):Tt!=null&&(ee=Math.max(ee,0),ue=Math.min(ue,Tt.count));const Te=ue-ee;if(Te<0||Te===1/0)return;I.setup(z,q,bt,X,xt);let Ce,me=It;if(xt!==null&&(Ce=k.get(xt),me=pt,me.setIndex(Ce)),z.isMesh)q.wireframe===!0?(Mt.setLineWidth(q.wireframeLinewidth*ie()),me.setMode(L.LINES)):me.setMode(L.TRIANGLES);else if(z.isLine){let Pt=q.linewidth;Pt===void 0&&(Pt=1),Mt.setLineWidth(Pt*ie()),z.isLineSegments?me.setMode(L.LINES):z.isLineLoop?me.setMode(L.LINE_LOOP):me.setMode(L.LINE_STRIP)}else z.isPoints?me.setMode(L.POINTS):z.isSprite&&me.setMode(L.TRIANGLES);if(z.isBatchedMesh)if(z._multiDrawInstances!==null)Tr("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),me.renderMultiDrawInstances(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount,z._multiDrawInstances);else if(te.get("WEBGL_multi_draw"))me.renderMultiDraw(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount);else{const Pt=z._multiDrawStarts,Ee=z._multiDrawCounts,re=z._multiDrawCount,on=xt?k.get(xt).bytesPerElement:1,ds=Ct.get(q).currentProgram.getUniforms();for(let an=0;an<re;an++)ds.setValue(L,"_gl_DrawID",an),me.render(Pt[an]/on,Ee[an])}else if(z.isInstancedMesh)me.renderInstances(ee,Te,z.count);else if(X.isInstancedBufferGeometry){const Pt=X._maxInstanceCount!==void 0?X._maxInstanceCount:1/0,Ee=Math.min(X.instanceCount,Pt);me.renderInstances(ee,Te,Ee)}else me.render(ee,Te)};function Un(w,N,X){w.transparent===!0&&w.side===Pn&&w.forceSinglePass===!1?(w.side=Ke,w.needsUpdate=!0,Nr(w,N,X),w.side=Fi,w.needsUpdate=!0,Nr(w,N,X),w.side=Pn):Nr(w,N,X)}this.compile=function(w,N,X=null){X===null&&(X=w),_=Rt.get(X),_.init(N),b.push(_),X.traverseVisible(function(z){z.isLight&&z.layers.test(N.layers)&&(_.pushLight(z),z.castShadow&&_.pushShadow(z))}),w!==X&&w.traverseVisible(function(z){z.isLight&&z.layers.test(N.layers)&&(_.pushLight(z),z.castShadow&&_.pushShadow(z))}),_.setupLights();const q=new Set;return w.traverse(function(z){if(!(z.isMesh||z.isPoints||z.isLine||z.isSprite))return;const rt=z.material;if(rt)if(Array.isArray(rt))for(let ft=0;ft<rt.length;ft++){const bt=rt[ft];Un(bt,X,z),q.add(bt)}else Un(rt,X,z),q.add(rt)}),_=b.pop(),q},this.compileAsync=function(w,N,X=null){const q=this.compile(w,N,X);return new Promise(z=>{function rt(){if(q.forEach(function(ft){Ct.get(ft).currentProgram.isReady()&&q.delete(ft)}),q.size===0){z(w);return}setTimeout(rt,10)}te.get("KHR_parallel_shader_compile")!==null?rt():setTimeout(rt,10)})};let En=null;function rf(w){En&&En(w)}function Xl(){Oi.stop()}function ql(){Oi.start()}const Oi=new Tu;Oi.setAnimationLoop(rf),typeof self<"u"&&Oi.setContext(self),this.setAnimationLoop=function(w){En=w,ct.setAnimationLoop(w),w===null?Oi.stop():Oi.start()},ct.addEventListener("sessionstart",Xl),ct.addEventListener("sessionend",ql),this.render=function(w,N){if(N!==void 0&&N.isCamera!==!0){Pe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(T===!0)return;if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),N.parent===null&&N.matrixWorldAutoUpdate===!0&&N.updateMatrixWorld(),ct.enabled===!0&&ct.isPresenting===!0&&(ct.cameraAutoUpdate===!0&&ct.updateCamera(N),N=ct.getCamera()),w.isScene===!0&&w.onBeforeRender(S,w,N,E),_=Rt.get(w,b.length),_.init(N),b.push(_),Lt.multiplyMatrices(N.projectionMatrix,N.matrixWorldInverse),Z.setFromProjectionMatrix(Lt,Vn,N.reversedDepth),ut=this.localClippingEnabled,Q=At.init(this.clippingPlanes,ut),M=ht.get(w,v.length),M.init(),v.push(M),ct.enabled===!0&&ct.isPresenting===!0){const rt=S.xr.getDepthSensingMesh();rt!==null&&ca(rt,N,-1/0,S.sortObjects)}ca(w,N,0,S.sortObjects),M.finish(),S.sortObjects===!0&&M.sort(St,kt),Yt=ct.enabled===!1||ct.isPresenting===!1||ct.hasDepthSensing()===!1,Yt&&ot.addToRenderList(M,w),this.info.render.frame++,Q===!0&&At.beginShadows();const X=_.state.shadowsArray;et.render(X,w,N),Q===!0&&At.endShadows(),this.info.autoReset===!0&&this.info.reset();const q=M.opaque,z=M.transmissive;if(_.setupLights(),N.isArrayCamera){const rt=N.cameras;if(z.length>0)for(let ft=0,bt=rt.length;ft<bt;ft++){const xt=rt[ft];$l(q,z,w,xt)}Yt&&ot.render(w);for(let ft=0,bt=rt.length;ft<bt;ft++){const xt=rt[ft];Yl(M,w,xt,xt.viewport)}}else z.length>0&&$l(q,z,w,N),Yt&&ot.render(w),Yl(M,w,N);E!==null&&A===0&&(Gt.updateMultisampleRenderTarget(E),Gt.updateRenderTargetMipmap(E)),w.isScene===!0&&w.onAfterRender(S,w,N),I.resetDefaultState(),C=-1,D=null,b.pop(),b.length>0?(_=b[b.length-1],Q===!0&&At.setGlobalState(S.clippingPlanes,_.state.camera)):_=null,v.pop(),v.length>0?M=v[v.length-1]:M=null};function ca(w,N,X,q){if(w.visible===!1)return;if(w.layers.test(N.layers)){if(w.isGroup)X=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(N);else if(w.isLight)_.pushLight(w),w.castShadow&&_.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||Z.intersectsSprite(w)){q&&Wt.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Lt);const ft=tt.update(w),bt=w.material;bt.visible&&M.push(w,ft,bt,X,Wt.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||Z.intersectsObject(w))){const ft=tt.update(w),bt=w.material;if(q&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Wt.copy(w.boundingSphere.center)):(ft.boundingSphere===null&&ft.computeBoundingSphere(),Wt.copy(ft.boundingSphere.center)),Wt.applyMatrix4(w.matrixWorld).applyMatrix4(Lt)),Array.isArray(bt)){const xt=ft.groups;for(let Dt=0,Nt=xt.length;Dt<Nt;Dt++){const Tt=xt[Dt],ee=bt[Tt.materialIndex];ee&&ee.visible&&M.push(w,ft,ee,X,Wt.z,Tt)}}else bt.visible&&M.push(w,ft,bt,X,Wt.z,null)}}const rt=w.children;for(let ft=0,bt=rt.length;ft<bt;ft++)ca(rt[ft],N,X,q)}function Yl(w,N,X,q){const{opaque:z,transmissive:rt,transparent:ft}=w;_.setupLightsView(X),Q===!0&&At.setGlobalState(S.clippingPlanes,X),q&&Mt.viewport(O.copy(q)),z.length>0&&Ur(z,N,X),rt.length>0&&Ur(rt,N,X),ft.length>0&&Ur(ft,N,X),Mt.buffers.depth.setTest(!0),Mt.buffers.depth.setMask(!0),Mt.buffers.color.setMask(!0),Mt.setPolygonOffset(!1)}function $l(w,N,X,q){if((X.isScene===!0?X.overrideMaterial:null)!==null)return;_.state.transmissionRenderTarget[q.id]===void 0&&(_.state.transmissionRenderTarget[q.id]=new as(1,1,{generateMipmaps:!0,type:te.has("EXT_color_buffer_half_float")||te.has("EXT_color_buffer_float")?Ws:ci,minFilter:ss,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:oe.workingColorSpace}));const rt=_.state.transmissionRenderTarget[q.id],ft=q.viewport||O;rt.setSize(ft.z*S.transmissionResolutionScale,ft.w*S.transmissionResolutionScale);const bt=S.getRenderTarget(),xt=S.getActiveCubeFace(),Dt=S.getActiveMipmapLevel();S.setRenderTarget(rt),S.getClearColor($),G=S.getClearAlpha(),G<1&&S.setClearColor(16777215,.5),S.clear(),Yt&&ot.render(X);const Nt=S.toneMapping;S.toneMapping=Di;const Tt=q.viewport;if(q.viewport!==void 0&&(q.viewport=void 0),_.setupLightsView(q),Q===!0&&At.setGlobalState(S.clippingPlanes,q),Ur(w,X,q),Gt.updateMultisampleRenderTarget(rt),Gt.updateRenderTargetMipmap(rt),te.has("WEBGL_multisampled_render_to_texture")===!1){let ee=!1;for(let ue=0,Te=N.length;ue<Te;ue++){const Ce=N[ue],{object:me,geometry:Pt,material:Ee,group:re}=Ce;if(Ee.side===Pn&&me.layers.test(q.layers)){const on=Ee.side;Ee.side=Ke,Ee.needsUpdate=!0,Kl(me,X,q,Pt,Ee,re),Ee.side=on,Ee.needsUpdate=!0,ee=!0}}ee===!0&&(Gt.updateMultisampleRenderTarget(rt),Gt.updateRenderTargetMipmap(rt))}S.setRenderTarget(bt,xt,Dt),S.setClearColor($,G),Tt!==void 0&&(q.viewport=Tt),S.toneMapping=Nt}function Ur(w,N,X){const q=N.isScene===!0?N.overrideMaterial:null;for(let z=0,rt=w.length;z<rt;z++){const ft=w[z],{object:bt,geometry:xt,group:Dt}=ft;let Nt=ft.material;Nt.allowOverride===!0&&q!==null&&(Nt=q),bt.layers.test(X.layers)&&Kl(bt,N,X,xt,Nt,Dt)}}function Kl(w,N,X,q,z,rt){w.onBeforeRender(S,N,X,q,z,rt),w.modelViewMatrix.multiplyMatrices(X.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),z.onBeforeRender(S,N,X,q,w,rt),z.transparent===!0&&z.side===Pn&&z.forceSinglePass===!1?(z.side=Ke,z.needsUpdate=!0,S.renderBufferDirect(X,N,q,z,w,rt),z.side=Fi,z.needsUpdate=!0,S.renderBufferDirect(X,N,q,z,w,rt),z.side=Pn):S.renderBufferDirect(X,N,q,z,w,rt),w.onAfterRender(S,N,X,q,z,rt)}function Nr(w,N,X){N.isScene!==!0&&(N=Se);const q=Ct.get(w),z=_.state.lights,rt=_.state.shadowsArray,ft=z.state.version,bt=K.getParameters(w,z.state,rt,N,X),xt=K.getProgramCacheKey(bt);let Dt=q.programs;q.environment=w.isMeshStandardMaterial?N.environment:null,q.fog=N.fog,q.envMap=(w.isMeshStandardMaterial?y:R).get(w.envMap||q.environment),q.envMapRotation=q.environment!==null&&w.envMap===null?N.environmentRotation:w.envMapRotation,Dt===void 0&&(w.addEventListener("dispose",Vt),Dt=new Map,q.programs=Dt);let Nt=Dt.get(xt);if(Nt!==void 0){if(q.currentProgram===Nt&&q.lightsStateVersion===ft)return jl(w,bt),Nt}else bt.uniforms=K.getUniforms(w),w.onBeforeCompile(bt,S),Nt=K.acquireProgram(bt,xt),Dt.set(xt,Nt),q.uniforms=bt.uniforms;const Tt=q.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Tt.clippingPlanes=At.uniform),jl(w,bt),q.needsLights=cf(w),q.lightsStateVersion=ft,q.needsLights&&(Tt.ambientLightColor.value=z.state.ambient,Tt.lightProbe.value=z.state.probe,Tt.directionalLights.value=z.state.directional,Tt.directionalLightShadows.value=z.state.directionalShadow,Tt.spotLights.value=z.state.spot,Tt.spotLightShadows.value=z.state.spotShadow,Tt.rectAreaLights.value=z.state.rectArea,Tt.ltc_1.value=z.state.rectAreaLTC1,Tt.ltc_2.value=z.state.rectAreaLTC2,Tt.pointLights.value=z.state.point,Tt.pointLightShadows.value=z.state.pointShadow,Tt.hemisphereLights.value=z.state.hemi,Tt.directionalShadowMap.value=z.state.directionalShadowMap,Tt.directionalShadowMatrix.value=z.state.directionalShadowMatrix,Tt.spotShadowMap.value=z.state.spotShadowMap,Tt.spotLightMatrix.value=z.state.spotLightMatrix,Tt.spotLightMap.value=z.state.spotLightMap,Tt.pointShadowMap.value=z.state.pointShadowMap,Tt.pointShadowMatrix.value=z.state.pointShadowMatrix),q.currentProgram=Nt,q.uniformsList=null,Nt}function Zl(w){if(w.uniformsList===null){const N=w.currentProgram.getUniforms();w.uniformsList=Lo.seqWithValue(N.seq,w.uniforms)}return w.uniformsList}function jl(w,N){const X=Ct.get(w);X.outputColorSpace=N.outputColorSpace,X.batching=N.batching,X.batchingColor=N.batchingColor,X.instancing=N.instancing,X.instancingColor=N.instancingColor,X.instancingMorph=N.instancingMorph,X.skinning=N.skinning,X.morphTargets=N.morphTargets,X.morphNormals=N.morphNormals,X.morphColors=N.morphColors,X.morphTargetsCount=N.morphTargetsCount,X.numClippingPlanes=N.numClippingPlanes,X.numIntersection=N.numClipIntersection,X.vertexAlphas=N.vertexAlphas,X.vertexTangents=N.vertexTangents,X.toneMapping=N.toneMapping}function of(w,N,X,q,z){N.isScene!==!0&&(N=Se),Gt.resetTextureUnits();const rt=N.fog,ft=q.isMeshStandardMaterial?N.environment:null,bt=E===null?S.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:ks,xt=(q.isMeshStandardMaterial?y:R).get(q.envMap||ft),Dt=q.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,Nt=!!X.attributes.tangent&&(!!q.normalMap||q.anisotropy>0),Tt=!!X.morphAttributes.position,ee=!!X.morphAttributes.normal,ue=!!X.morphAttributes.color;let Te=Di;q.toneMapped&&(E===null||E.isXRRenderTarget===!0)&&(Te=S.toneMapping);const Ce=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,me=Ce!==void 0?Ce.length:0,Pt=Ct.get(q),Ee=_.state.lights;if(Q===!0&&(ut===!0||w!==D)){const Ye=w===D&&q.id===C;At.setState(q,w,Ye)}let re=!1;q.version===Pt.__version?(Pt.needsLights&&Pt.lightsStateVersion!==Ee.state.version||Pt.outputColorSpace!==bt||z.isBatchedMesh&&Pt.batching===!1||!z.isBatchedMesh&&Pt.batching===!0||z.isBatchedMesh&&Pt.batchingColor===!0&&z.colorTexture===null||z.isBatchedMesh&&Pt.batchingColor===!1&&z.colorTexture!==null||z.isInstancedMesh&&Pt.instancing===!1||!z.isInstancedMesh&&Pt.instancing===!0||z.isSkinnedMesh&&Pt.skinning===!1||!z.isSkinnedMesh&&Pt.skinning===!0||z.isInstancedMesh&&Pt.instancingColor===!0&&z.instanceColor===null||z.isInstancedMesh&&Pt.instancingColor===!1&&z.instanceColor!==null||z.isInstancedMesh&&Pt.instancingMorph===!0&&z.morphTexture===null||z.isInstancedMesh&&Pt.instancingMorph===!1&&z.morphTexture!==null||Pt.envMap!==xt||q.fog===!0&&Pt.fog!==rt||Pt.numClippingPlanes!==void 0&&(Pt.numClippingPlanes!==At.numPlanes||Pt.numIntersection!==At.numIntersection)||Pt.vertexAlphas!==Dt||Pt.vertexTangents!==Nt||Pt.morphTargets!==Tt||Pt.morphNormals!==ee||Pt.morphColors!==ue||Pt.toneMapping!==Te||Pt.morphTargetsCount!==me)&&(re=!0):(re=!0,Pt.__version=q.version);let on=Pt.currentProgram;re===!0&&(on=Nr(q,N,z));let ds=!1,an=!1,$s=!1;const Ae=on.getUniforms(),Ze=Pt.uniforms;if(Mt.useProgram(on.program)&&(ds=!0,an=!0,$s=!0),q.id!==C&&(C=q.id,an=!0),ds||D!==w){Mt.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),Ae.setValue(L,"projectionMatrix",w.projectionMatrix),Ae.setValue(L,"viewMatrix",w.matrixWorldInverse);const je=Ae.map.cameraPosition;je!==void 0&&je.setValue(L,yt.setFromMatrixPosition(w.matrixWorld)),_e.logarithmicDepthBuffer&&Ae.setValue(L,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(q.isMeshPhongMaterial||q.isMeshToonMaterial||q.isMeshLambertMaterial||q.isMeshBasicMaterial||q.isMeshStandardMaterial||q.isShaderMaterial)&&Ae.setValue(L,"isOrthographic",w.isOrthographicCamera===!0),D!==w&&(D=w,an=!0,$s=!0)}if(z.isSkinnedMesh){Ae.setOptional(L,z,"bindMatrix"),Ae.setOptional(L,z,"bindMatrixInverse");const Ye=z.skeleton;Ye&&(Ye.boneTexture===null&&Ye.computeBoneTexture(),Ae.setValue(L,"boneTexture",Ye.boneTexture,Gt))}z.isBatchedMesh&&(Ae.setOptional(L,z,"batchingTexture"),Ae.setValue(L,"batchingTexture",z._matricesTexture,Gt),Ae.setOptional(L,z,"batchingIdTexture"),Ae.setValue(L,"batchingIdTexture",z._indirectTexture,Gt),Ae.setOptional(L,z,"batchingColorTexture"),z._colorsTexture!==null&&Ae.setValue(L,"batchingColorTexture",z._colorsTexture,Gt));const mn=X.morphAttributes;if((mn.position!==void 0||mn.normal!==void 0||mn.color!==void 0)&&Ut.update(z,X,on),(an||Pt.receiveShadow!==z.receiveShadow)&&(Pt.receiveShadow=z.receiveShadow,Ae.setValue(L,"receiveShadow",z.receiveShadow)),q.isMeshGouraudMaterial&&q.envMap!==null&&(Ze.envMap.value=xt,Ze.flipEnvMap.value=xt.isCubeTexture&&xt.isRenderTargetTexture===!1?-1:1),q.isMeshStandardMaterial&&q.envMap===null&&N.environment!==null&&(Ze.envMapIntensity.value=N.environmentIntensity),Ze.dfgLUT!==void 0&&(Ze.dfgLUT.value=T_()),an&&(Ae.setValue(L,"toneMappingExposure",S.toneMappingExposure),Pt.needsLights&&af(Ze,$s),rt&&q.fog===!0&&wt.refreshFogUniforms(Ze,rt),wt.refreshMaterialUniforms(Ze,q,st,Y,_.state.transmissionRenderTarget[w.id]),Lo.upload(L,Zl(Pt),Ze,Gt)),q.isShaderMaterial&&q.uniformsNeedUpdate===!0&&(Lo.upload(L,Zl(Pt),Ze,Gt),q.uniformsNeedUpdate=!1),q.isSpriteMaterial&&Ae.setValue(L,"center",z.center),Ae.setValue(L,"modelViewMatrix",z.modelViewMatrix),Ae.setValue(L,"normalMatrix",z.normalMatrix),Ae.setValue(L,"modelMatrix",z.matrixWorld),q.isShaderMaterial||q.isRawShaderMaterial){const Ye=q.uniformsGroups;for(let je=0,la=Ye.length;je<la;je++){const Bi=Ye[je];dt.update(Bi,on),dt.bind(Bi,on)}}return on}function af(w,N){w.ambientLightColor.needsUpdate=N,w.lightProbe.needsUpdate=N,w.directionalLights.needsUpdate=N,w.directionalLightShadows.needsUpdate=N,w.pointLights.needsUpdate=N,w.pointLightShadows.needsUpdate=N,w.spotLights.needsUpdate=N,w.spotLightShadows.needsUpdate=N,w.rectAreaLights.needsUpdate=N,w.hemisphereLights.needsUpdate=N}function cf(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return P},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(w,N,X){const q=Ct.get(w);q.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,q.__autoAllocateDepthBuffer===!1&&(q.__useRenderToTexture=!1),Ct.get(w.texture).__webglTexture=N,Ct.get(w.depthTexture).__webglTexture=q.__autoAllocateDepthBuffer?void 0:X,q.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,N){const X=Ct.get(w);X.__webglFramebuffer=N,X.__useDefaultFramebuffer=N===void 0};const lf=L.createFramebuffer();this.setRenderTarget=function(w,N=0,X=0){E=w,P=N,A=X;let q=!0,z=null,rt=!1,ft=!1;if(w){const xt=Ct.get(w);if(xt.__useDefaultFramebuffer!==void 0)Mt.bindFramebuffer(L.FRAMEBUFFER,null),q=!1;else if(xt.__webglFramebuffer===void 0)Gt.setupRenderTarget(w);else if(xt.__hasExternalTextures)Gt.rebindTextures(w,Ct.get(w.texture).__webglTexture,Ct.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const Tt=w.depthTexture;if(xt.__boundDepthTexture!==Tt){if(Tt!==null&&Ct.has(Tt)&&(w.width!==Tt.image.width||w.height!==Tt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Gt.setupDepthRenderbuffer(w)}}const Dt=w.texture;(Dt.isData3DTexture||Dt.isDataArrayTexture||Dt.isCompressedArrayTexture)&&(ft=!0);const Nt=Ct.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Nt[N])?z=Nt[N][X]:z=Nt[N],rt=!0):w.samples>0&&Gt.useMultisampledRTT(w)===!1?z=Ct.get(w).__webglMultisampledFramebuffer:Array.isArray(Nt)?z=Nt[X]:z=Nt,O.copy(w.viewport),H.copy(w.scissor),W=w.scissorTest}else O.copy(qt).multiplyScalar(st).floor(),H.copy(ce).multiplyScalar(st).floor(),W=le;if(X!==0&&(z=lf),Mt.bindFramebuffer(L.FRAMEBUFFER,z)&&q&&Mt.drawBuffers(w,z),Mt.viewport(O),Mt.scissor(H),Mt.setScissorTest(W),rt){const xt=Ct.get(w.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+N,xt.__webglTexture,X)}else if(ft){const xt=N;for(let Dt=0;Dt<w.textures.length;Dt++){const Nt=Ct.get(w.textures[Dt]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+Dt,Nt.__webglTexture,X,xt)}}else if(w!==null&&X!==0){const xt=Ct.get(w.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,xt.__webglTexture,X)}C=-1},this.readRenderTargetPixels=function(w,N,X,q,z,rt,ft,bt=0){if(!(w&&w.isWebGLRenderTarget)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let xt=Ct.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&ft!==void 0&&(xt=xt[ft]),xt){Mt.bindFramebuffer(L.FRAMEBUFFER,xt);try{const Dt=w.textures[bt],Nt=Dt.format,Tt=Dt.type;if(!_e.textureFormatReadable(Nt)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!_e.textureTypeReadable(Tt)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}N>=0&&N<=w.width-q&&X>=0&&X<=w.height-z&&(w.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+bt),L.readPixels(N,X,q,z,Ot.convert(Nt),Ot.convert(Tt),rt))}finally{const Dt=E!==null?Ct.get(E).__webglFramebuffer:null;Mt.bindFramebuffer(L.FRAMEBUFFER,Dt)}}},this.readRenderTargetPixelsAsync=async function(w,N,X,q,z,rt,ft,bt=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let xt=Ct.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&ft!==void 0&&(xt=xt[ft]),xt)if(N>=0&&N<=w.width-q&&X>=0&&X<=w.height-z){Mt.bindFramebuffer(L.FRAMEBUFFER,xt);const Dt=w.textures[bt],Nt=Dt.format,Tt=Dt.type;if(!_e.textureFormatReadable(Nt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!_e.textureTypeReadable(Tt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const ee=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,ee),L.bufferData(L.PIXEL_PACK_BUFFER,rt.byteLength,L.STREAM_READ),w.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+bt),L.readPixels(N,X,q,z,Ot.convert(Nt),Ot.convert(Tt),0);const ue=E!==null?Ct.get(E).__webglFramebuffer:null;Mt.bindFramebuffer(L.FRAMEBUFFER,ue);const Te=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await ip(L,Te,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,ee),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,rt),L.deleteBuffer(ee),L.deleteSync(Te),rt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,N=null,X=0){const q=Math.pow(2,-X),z=Math.floor(w.image.width*q),rt=Math.floor(w.image.height*q),ft=N!==null?N.x:0,bt=N!==null?N.y:0;Gt.setTexture2D(w,0),L.copyTexSubImage2D(L.TEXTURE_2D,X,0,0,ft,bt,z,rt),Mt.unbindTexture()};const hf=L.createFramebuffer(),df=L.createFramebuffer();this.copyTextureToTexture=function(w,N,X=null,q=null,z=0,rt=null){rt===null&&(z!==0?(Tr("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),rt=z,z=0):rt=0);let ft,bt,xt,Dt,Nt,Tt,ee,ue,Te;const Ce=w.isCompressedTexture?w.mipmaps[rt]:w.image;if(X!==null)ft=X.max.x-X.min.x,bt=X.max.y-X.min.y,xt=X.isBox3?X.max.z-X.min.z:1,Dt=X.min.x,Nt=X.min.y,Tt=X.isBox3?X.min.z:0;else{const mn=Math.pow(2,-z);ft=Math.floor(Ce.width*mn),bt=Math.floor(Ce.height*mn),w.isDataArrayTexture?xt=Ce.depth:w.isData3DTexture?xt=Math.floor(Ce.depth*mn):xt=1,Dt=0,Nt=0,Tt=0}q!==null?(ee=q.x,ue=q.y,Te=q.z):(ee=0,ue=0,Te=0);const me=Ot.convert(N.format),Pt=Ot.convert(N.type);let Ee;N.isData3DTexture?(Gt.setTexture3D(N,0),Ee=L.TEXTURE_3D):N.isDataArrayTexture||N.isCompressedArrayTexture?(Gt.setTexture2DArray(N,0),Ee=L.TEXTURE_2D_ARRAY):(Gt.setTexture2D(N,0),Ee=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,N.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,N.unpackAlignment);const re=L.getParameter(L.UNPACK_ROW_LENGTH),on=L.getParameter(L.UNPACK_IMAGE_HEIGHT),ds=L.getParameter(L.UNPACK_SKIP_PIXELS),an=L.getParameter(L.UNPACK_SKIP_ROWS),$s=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,Ce.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,Ce.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Dt),L.pixelStorei(L.UNPACK_SKIP_ROWS,Nt),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Tt);const Ae=w.isDataArrayTexture||w.isData3DTexture,Ze=N.isDataArrayTexture||N.isData3DTexture;if(w.isDepthTexture){const mn=Ct.get(w),Ye=Ct.get(N),je=Ct.get(mn.__renderTarget),la=Ct.get(Ye.__renderTarget);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,je.__webglFramebuffer),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,la.__webglFramebuffer);for(let Bi=0;Bi<xt;Bi++)Ae&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ct.get(w).__webglTexture,z,Tt+Bi),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ct.get(N).__webglTexture,rt,Te+Bi)),L.blitFramebuffer(Dt,Nt,ft,bt,ee,ue,ft,bt,L.DEPTH_BUFFER_BIT,L.NEAREST);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,null),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(z!==0||w.isRenderTargetTexture||Ct.has(w)){const mn=Ct.get(w),Ye=Ct.get(N);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,hf),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,df);for(let je=0;je<xt;je++)Ae?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,mn.__webglTexture,z,Tt+je):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,mn.__webglTexture,z),Ze?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ye.__webglTexture,rt,Te+je):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,Ye.__webglTexture,rt),z!==0?L.blitFramebuffer(Dt,Nt,ft,bt,ee,ue,ft,bt,L.COLOR_BUFFER_BIT,L.NEAREST):Ze?L.copyTexSubImage3D(Ee,rt,ee,ue,Te+je,Dt,Nt,ft,bt):L.copyTexSubImage2D(Ee,rt,ee,ue,Dt,Nt,ft,bt);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,null),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else Ze?w.isDataTexture||w.isData3DTexture?L.texSubImage3D(Ee,rt,ee,ue,Te,ft,bt,xt,me,Pt,Ce.data):N.isCompressedArrayTexture?L.compressedTexSubImage3D(Ee,rt,ee,ue,Te,ft,bt,xt,me,Ce.data):L.texSubImage3D(Ee,rt,ee,ue,Te,ft,bt,xt,me,Pt,Ce):w.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,rt,ee,ue,ft,bt,me,Pt,Ce.data):w.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,rt,ee,ue,Ce.width,Ce.height,me,Ce.data):L.texSubImage2D(L.TEXTURE_2D,rt,ee,ue,ft,bt,me,Pt,Ce);L.pixelStorei(L.UNPACK_ROW_LENGTH,re),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,on),L.pixelStorei(L.UNPACK_SKIP_PIXELS,ds),L.pixelStorei(L.UNPACK_SKIP_ROWS,an),L.pixelStorei(L.UNPACK_SKIP_IMAGES,$s),rt===0&&N.generateMipmaps&&L.generateMipmap(Ee),Mt.unbindTexture()},this.initRenderTarget=function(w){Ct.get(w).__webglFramebuffer===void 0&&Gt.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?Gt.setTextureCube(w,0):w.isData3DTexture?Gt.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?Gt.setTexture2DArray(w,0):Gt.setTexture2D(w,0),Mt.unbindTexture()},this.resetState=function(){P=0,A=0,E=null,Mt.reset(),I.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Vn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=oe._getDrawingBufferColorSpace(t),e.unpackColorSpace=oe._getUnpackColorSpace()}}const R_=13626615,Iu=7829367,P_=6728294,L_=11132329,I_=15658736,Du=new se(16711680),sa=new se(13421772),D_=new se(13434828),F_=new se(16763904);class Xe{constructor(){F(this,"flatConfig")}refreshConfig(){this.flatConfig=Fu(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],n=e();return n.refreshConfig(),n}}F(Xe,"_registry",{});function Fu(s,t={}){for(const[e,n]of Object.entries(s.children))"action"in n||("value"in n?t[e]=n.value:Fu(n,t));return t}function U_(s){Ys.refreshConfig(),s.onResize()}const N_={label:"Graphics",children:{emoteProbability:{tooltip:"probability to change facial expression per ms",value:.001,min:0,max:1,onChange:U_}}},Bl=class Bl extends Xe{constructor(){super(...arguments);F(this,"tree",N_)}};Xe.register("gfx-config",()=>new Bl);let jh=Bl;const Ys=Xe.create("gfx-config"),Uu={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:50,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:40,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const s of Object.values(Uu.children))s.onChange=t=>{Re.refreshConfig(),t.onResize()};const zl=class zl extends Xe{constructor(){super(...arguments);F(this,"tree",Uu)}};Xe.register("layout-config",()=>new zl);let Jh=zl;const Re=Xe.create("layout-config");function Qh(){Nu.refreshConfig()}const O_={label:"Physics",children:{stepDelay:{value:3,min:3,max:1e4,step:1,onChange:Qh},spawnDelay:{value:3,min:3,max:1e4,step:1,onChange:Qh}}},Vl=class Vl extends Xe{constructor(){super(...arguments);F(this,"tree",O_)}};Xe.register("physics-config",()=>new Vl);let td=Vl;const Nu=Xe.create("physics-config"),B_={children:{speedMultiplier:{value:1,min:1,max:10,step:1,onChange:()=>Ds.refreshConfig()}}},kl=class kl extends Xe{constructor(){super(...arguments);F(this,"tree",B_)}};Xe.register("top-config",()=>new kl);let ed=kl;const Ds=Xe.create("top-config"),z_={children:{...Ds.tree.children,...Nu.tree.children,...Ys.tree.children,layout:Re.tree}},Gl=class Gl extends Xe{constructor(){super(...arguments);F(this,"tree",z_)}};Xe.register("tower-toppler-config",()=>new Gl);let nd=Gl;const V_=Xe.create("tower-toppler-config"),ra=Math.PI,Ou=2*ra,Zc=ra/2,wi=ra/4;function id(s,t,e){return s+(t-s)*e}const Go=["N","E","S","W"];function k_(s,t){const e=s.position.x-t.x,n=s.position.z-t.z,i=Math.atan2(e,n);return i>=-wi&&i<wi?"N":i>=wi&&i<3*wi?"E":i>=-3*wi&&i<-wi?"W":"S"}function G_(s,t,e){switch(e){case"N":return[s.x,s.y,t];case"S":return[s.x,s.y,-t];case"E":return[t,s.y,s.z];case"W":return[-t,s.y,s.z];default:return[s.x,s.y,t]}}function H_(s,t){if(s===t)return 0;const e=Go.indexOf(t)-Go.indexOf(s);return e===-3?1:e===3?-1:e<-1||e>1?Math.random()>.5?1:-1:e}const W_=["isShocked","areEyesOpen","isMouthOpen","isFilled"],_n=class _n{static getFaceImage(t){return this._getGfx(t)}static drawFace(t,e,n){const i=this._getGfx(n),[r,o,a,c]=e,l=a/_n._bufferWidth,h=c/_n._bufferHeight,d=Math.min(l,h);t.save(),t.translate(r,o),t.scale(d,d),t.drawImage(i,0,0),t.restore()}static _getGfx(t){const e=_n._hash(t),n=_n._graphics;return Object.hasOwn(n,e)||(n[e]=new _n()._buildFaceGfx(t)),n[e]}static _hash(t){let e="base";for(const n of W_)t[n]&&(e=`${e}-${n}`);return t.rotations&&(e=`${e}-rot=${t.rotations}`),e}_buildFaceGfx(t){const i=_n._bufferWidth,r=_n._bufferHeight,o=document.createElement("canvas");o.width=i,o.height=r;const a=o.getContext("2d"),{rotations:c=0}=t;if(c){const[h,d]=[i/2,r/2],u=Zc*c;a.translate(h,d),a.rotate(u),a.translate(-h,-d)}if(a.lineCap="round",a.lineWidth=80,t.isFilled){a.fillStyle="#ddd";const h="#666";a.fillRect(0,0,i,r),a.strokeStyle=h,a.strokeRect(0,0,i,r),a.fillStyle=h,a.strokeStyle=h}else a.fillStyle="black",a.strokeStyle="black";const{isShocked:l}=t;return l?this._isShockedFace(a,{x:0,y:0,w:i,h:r,...t}):this._idleFace(a,{x:0,y:0,w:i,h:r,...t}),o}_isShockedFace(t,e){const{x:n,y:i,w:r,h:o}=e;t.beginPath(),t.arc(n+r/2,i+o/2,r/4,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+r/4,i+o/5,r/10,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+3*r/4,i+o/5,r/10,0,2*Math.PI),t.fill()}_idleFace(t,e){const{x:n,y:i,w:r,h:o,isMouthOpen:a,areEyesOpen:c}=e;a?(t.beginPath(),t.arc(n+r/2,i+o/3,r/3,.1*Math.PI,.9*Math.PI),t.fill()):(t.beginPath(),t.arc(n+r/2,i,r/2,.3*Math.PI,.7*Math.PI),t.stroke()),c?(t.beginPath(),t.arc(n+r/4,i+o/5,r/10,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+3*r/4,i+o/5,r/10,0,2*Math.PI),t.fill()):(t.beginPath(),t.arc(n+r/4,i+o/3,r/6,1.25*Math.PI,1.75*Math.PI),t.stroke(),t.beginPath(),t.arc(n+3*r/4,i+o/3,r/6,1.25*Math.PI,1.75*Math.PI),t.stroke())}};F(_n,"_bufferWidth",1e3),F(_n,"_bufferHeight",1e3),F(_n,"_graphics",{});let jc=_n;const hi=[{areEyesOpen:!0,isFilled:!1,isMouthOpen:!0,isShocked:!1,rotations:0},{areEyesOpen:!0,isFilled:!1,isMouthOpen:!1,isShocked:!1,rotations:0},{areEyesOpen:!1,isFilled:!1,isMouthOpen:!0,isShocked:!1,rotations:0},{areEyesOpen:!1,isFilled:!1,isMouthOpen:!1,isShocked:!1,rotations:0}],qe=1+2*hi.length,Bu=1e3,X_=1e3,oa=document.createElement("canvas");oa.width=qe*Bu;oa.height=X_;const q_=oa.getContext("2d");for(let s=0;s<hi.length;s++)q_.drawImage(jc.getFaceImage(hi[s]),0,0,1e3,1e3,(1+2*s)*Bu,0,1e3,1e3);const di=new Up(oa);di.minFilter=en;di.magFilter=en;di.wrapS=di.wrapT=Oo;di.offset.set(0,0);di.repeat.set(1,1);const Ji=new rn({color:sa}),zu=new rn({color:0}),El=new rn({map:di,transparent:!0}),Y_=[Ji,zu,El];let Ho=!0;function $_(){Ho=!0}function sd(){Ho=!1}const rd=.005,od=.02,K_=.005,Z_=1e-5,j_=1e-4,J_={value:.0025},Qi={value:0},Jc={value:1e4};function Q_(s){Jc.value+=s*K_*(.2+.2*Math.sin(Jc.value*1e-4)),Ho&&Qi.value<od?Qi.value=Math.min(od,Qi.value+s*Z_):!Ho&&Qi.value>rd&&(Qi.value=Math.max(rd,Qi.value-s*j_))}for(const s of Y_)s.onBeforeCompile=t=>{t.uniforms.uTime=Jc,t.uniforms.uGlobalFreq=J_,t.uniforms.uGlobalAmp=Qi,t.vertexShader=`
  uniform float uTime;
  uniform float uGlobalFreq;
  uniform float uGlobalAmp;
  ${t.vertexShader}
  `.replace("#include <begin_vertex>",`
        // Cartoonish jello hose wave: spine anchored at bottom, top moves most.
        vec3 transformed = vec3(position);

        #ifdef USE_INSTANCING
          mat4 worldMat = modelMatrix * instanceMatrix;
        #else
          mat4 worldMat = modelMatrix;
        #endif

        vec3 worldPos = (worldMat * vec4(transformed, 1.0)).xyz;

        // Per-axis scale so deformation magnitude is scale-invariant.
        vec3 scaleVec = vec3(
          length(worldMat[0].xyz),
          length(worldMat[1].xyz),
          length(worldMat[2].xyz)
        );

        float t = uTime;            // Time driver
        float freq = uGlobalFreq;    // Spatial frequency along height
        float baseAmp = uGlobalAmp;  // Overall amplitude control

        // Height factor: bottom (y≈0) almost rigid; top flexes fully.
        float hFactor = clamp(worldPos.y * 0.08, 0.0, 1.0);
        hFactor = smoothstep(0.0, 1.0, hFactor);

        // Bending angle of vertical spine (hose) depending on height & time.
        float bend = sin(t * 0.8 + worldPos.y * freq) * baseAmp * hFactor;

        // Side-to-side displacement proportional to height (rotation around spine).
        float lateralX = bend * worldPos.y;

        // Light jello wobble in Z for extra cartoon feel.
        float lateralZ = 0.35 * bend * worldPos.y + 0.08 * sin(worldPos.y * freq * 1.7 + t * 1.3);

        // Vertical offset: when leaning sideways, top shifts up/down preserving length illusion.
        float verticalOffset = -0.15 * abs(bend) * worldPos.y + 0.05 * sin(worldPos.y * freq * 1.2 + t * 2.0);

        vec3 offset = vec3(lateralX, verticalOffset, lateralZ);

        // Map world-space offset back into the mesh's local space taking rotation into account.
        // Using the normalized world axes (columns of worldMat) as a basis allows consistent
        // deformation even when instances have different rotations.
        vec3 axisX = normalize(worldMat[0].xyz);
        vec3 axisY = normalize(worldMat[1].xyz);
        vec3 axisZ = normalize(worldMat[2].xyz);

        vec3 localOffset;
        localOffset.x = dot(offset, axisX) / scaleVec.x; // project onto local X then remove scale
        localOffset.y = dot(offset, axisY) / scaleVec.y; // project onto local Y then remove scale
        localOffset.z = dot(offset, axisZ) / scaleVec.z; // project onto local Z then remove scale

        transformed += localOffset;
      `),s===El&&(t.uniforms.atlasSize={value:qe},t.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`)))};const Al=100,ir=.1,sr=new B(0,1,0),rr=new B,ad=new B,Ts=new B,cd=new B,Cs=new B,ld=new Me,hd=new B,Ge=new ge,he=new ge,Vu=new Float32Array(Al);for(let s=0;s<Al;++s)Vu[s]=Math.floor(Math.random()*qe)/qe;class tv{constructor(){F(this,"im");F(this,"faceStates",[]);F(this,"uvOffsets");const t=new Xs(1,1,10,10);this.im=new ze(t,El,Al),this.uvOffsets=new Hs(Vu,1),t.setAttribute("uvOffset",this.uvOffsets),this.im.instanceMatrix.needsUpdate=!0}clear(){this.im.count=0,this.im.instanceMatrix.needsUpdate=!0,this.im.instanceColor&&(this.im.instanceColor.needsUpdate=!0)}hideAll(){const t=this.im;for(let e=0;e<t.count;e++)t.getMatrixAt(e,he.matrix),he.matrix.decompose(he.position,he.quaternion,he.scale),he.position.setY(1e6),he.updateMatrix(),t.setMatrixAt(e,he.matrix);t.instanceMatrix.needsUpdate=!0}update(t,e){const i=t*.01,r=this.uvOffsets;for(let o=0;o<this.im.count;o++){const a=this.faceStates[o];Math.random()<t*Ys.flatConfig.emoteProbability&&(a.faceIndex=Math.floor(Math.random()*hi.length));const{slideOffset:c,faceIndex:l}=a;c<0?a.slideOffset=Math.min(0,c+i):c>0&&(a.slideOffset=Math.max(0,c-i)),r.setX(o,(1+2*l+c)/qe),o===e.removedBlockIndex&&r.setX(o,-1)}r.needsUpdate=!0}addFace(t,e){const n=this.im.count,i=Math.floor(Math.random()*hi.length);this.faceStates.push({faceIndex:i,dir:e,slideOffset:-1}),this.uvOffsets.setX(n,(1+2*i)/qe),this.placeFace(n,t,e),this.im.count++}placeFace(t,[e,n,i,r,o,a],c){const l=this.faceStates[t];l.dir!==c&&(l.slideOffset=H_(l.dir,c)),l.dir=c;let h;c==="N"?(h=Math.min(r,o),Ge.position.set(e+r/2,n+o/2,i+a+ir),Ge.setRotationFromAxisAngle(sr,0)):c==="S"?(h=Math.min(r,o),Ge.position.set(e+r/2,n+o/2,i-ir),Ge.setRotationFromAxisAngle(sr,ra)):c==="E"?(h=Math.min(a,o),Ge.position.set(e+r+ir,n+o/2,i+a/2),Ge.setRotationFromAxisAngle(sr,Zc)):c==="W"&&(h=Math.min(a,o),Ge.position.set(e-ir,n+o/2,i+a/2),Ge.setRotationFromAxisAngle(sr,3*Zc)),Ge.scale.set(h,h,a),Ge.updateMatrix(),this.im.setMatrixAt(t,Ge.matrix),this.im.instanceMatrix.needsUpdate=!0}updateActiveFace(t,e){t.getMatrixAt(e,he.matrix),he.matrix.decompose(he.position,he.quaternion,he.scale);const i=this.faceStates[e].dir;let r=0;i==="N"?(rr.set(0,0,1),r=he.scale.z*.5):i==="S"?(rr.set(0,0,-1),r=he.scale.z*.5):i==="E"?(rr.set(1,0,0),r=he.scale.x*.5):(rr.set(-1,0,0),r=he.scale.x*.5),Cs.copy(rr).applyQuaternion(he.quaternion).normalize(),ad.set(0,1,0).applyQuaternion(he.quaternion).normalize(),Ts.crossVectors(ad,Cs),Ts.lengthSq()<1e-8&&Ts.crossVectors(sr,Cs),Ts.normalize(),cd.crossVectors(Cs,Ts).normalize(),ld.makeBasis(Ts,cd,Cs),hd.copy(he.position).add(Cs.multiplyScalar(r+ir));let o;i==="N"||i==="S"?o=Math.min(he.scale.x,he.scale.y):(i==="E"||i==="W")&&(o=Math.min(he.scale.z,he.scale.y)),Ge.position.copy(hd),Ge.setRotationFromMatrix(ld),Ge.scale.set(o,o,he.scale.z),Ge.updateMatrix(),this.im.setMatrixAt(e,Ge.matrix),this.im.instanceMatrix.needsUpdate=!0}}const Xi=100,za=new B,or=new Ui,so=new B,Zn=new ge,Bt=new ge,dd=new B(1,0,0),ud=new B(0,0,1),gt=2,Sr=class Sr{constructor(){F(this,"facesIm");F(this,"edgesIm");F(this,"boxes",{});F(this,"baseColors",{});F(this,"brightnessFactors",[1,1.3,.5,1.5,1.1,1.2]);F(this,"_boxCount",0);F(this,"_hoveredBoxIndex",-1);F(this,"_selectedBoxIndex",-1);this.facesIm=[new ze(new un(1,1,1,1,1,1),Ji,Xi),new ze(new un(1,1,1,1,1,1),Ji,Xi),new ze(new un(1,1,1,1,1,1),Ji,Xi),new ze(new un(1,1,1,1,1,1),Ji,Xi),new ze(new un(1,1,1,1,1,1),Ji,Xi),new ze(new un(1,1,1,1,1,1),Ji,Xi)],this.edgesIm=new ze(new un(1,1,1,10,10,10),zu,12*Xi)}get hoveredBoxIndex(){return this._hoveredBoxIndex}set hoveredBoxIndex(t){this._hoveredBoxIndex=t,this.updateColors()}set selectedBoxIndex(t){this._selectedBoxIndex=t,this.updateColors()}get selectedBoxIndex(){return this._selectedBoxIndex}clear(){for(const t of this.instancedMeshes)t.count=0,t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0);this._boxCount=0}get boxCount(){return this._boxCount}get instancedMeshes(){return[...this.facesIm,this.edgesIm]}updateColors(){for(let t=0;t<this._boxCount;t++){let e=this.baseColors[t]??sa;t===this._hoveredBoxIndex?e=D_:t===this._selectedBoxIndex&&(e=F_);for(let n=0;n<6;n++){const i=e.clone().multiplyScalar(this.brightnessFactors[n]);this.facesIm[n].setColorAt(t,i)}}for(const t of this.facesIm)t.instanceColor&&(t.instanceColor.needsUpdate=!0)}setColorAt(t,e){this.baseColors[t]=e}addBox(t){const e=this._boxCount;this.boxes[e]=t;const[n,i,r,o,a,c]=t,l=Sr.FACE_THICKNESS,h=[[n,i+a/2,r+c/2,l,a,c],[n+o,i+a/2,r+c/2,l,a,c],[n+o/2,i,r+c/2,o,l,c],[n+o/2,i+a,r+c/2,o,l,c],[n+o/2,i+a/2,r,o,a,l],[n+o/2,i+a/2,r+c,o,a,l]];for(let d=0;d<6;d++){const[u,m,x,g,p,f]=h[d];Zn.position.set(u,m,x),Zn.scale.set(g,p,f),Zn.quaternion.identity(),Zn.updateMatrix(),this.facesIm[d].setMatrixAt(e,Zn.matrix),this.facesIm[d].count=e+1}this._boxCount++,this.addEdge(n,i+a/2,r,gt,a+gt,gt),this.addEdge(n+o,i+a/2,r,gt,a+gt,gt),this.addEdge(n+o,i+a/2,r+c,gt,a+gt,gt),this.addEdge(n,i+a/2,r+c,gt,a+gt,gt),this.addEdge(n+o/2,i,r,o+gt,gt,gt),this.addEdge(n+o,i,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i,r+c,o+gt,gt,gt),this.addEdge(n,i,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i+a,r,o+gt,gt,gt),this.addEdge(n+o,i+a,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i+a,r+c,o+gt,gt,gt),this.addEdge(n,i+a,r+c/2,gt,gt,c+gt)}addEdge(t,e,n,i,r,o){Zn.position.set(t,e,n),Zn.scale.set(i,r,o),Zn.updateMatrix(),this.edgesIm.setMatrixAt(this.edgesIm.count++,Zn.matrix)}updateActiveBox(t,e,n,i){if(e>=this._boxCount)return;const[r,o,a,c,l,h]=t.bounds,d=n.interpolatedPosition,u=n.interpolatedAngle,[m,x]=d,g=n.shapes[0].height,p=n.shapes[0].width;Bt.position.setY(l-x),Bt.scale.setY(g),i==="W"?(Bt.scale.setZ(p),Bt.position.setZ(m),Bt.position.setX(r+c/2),Bt.scale.setX(p),Bt.setRotationFromAxisAngle(dd,u)):i==="E"?(Bt.scale.setZ(p),Bt.position.setZ(h-m),Bt.position.setX(r+c/2),Bt.scale.setX(p),Bt.setRotationFromAxisAngle(dd,-u)):i==="N"?(Bt.scale.setX(p),Bt.position.setX(m),Bt.position.setZ(a+h/2),Bt.scale.setZ(p),Bt.setRotationFromAxisAngle(ud,-u)):i==="S"&&(Bt.scale.setX(p),Bt.position.setX(c-m),Bt.position.setZ(a+h/2),Bt.scale.setZ(p),Bt.setRotationFromAxisAngle(ud,u)),Bt.updateMatrix();let f=12*e;za.copy(Bt.position),or.copy(Bt.quaternion);const M=Bt.scale.x,_=Bt.scale.y,v=Bt.scale.z,b=M/2,S=_/2,T=v/2,P=M+gt,A=_+gt,E=v+gt,C=(H,W,$,G,V,Y)=>{so.set(H,W,$).applyQuaternion(or).add(za),Bt.position.copy(so),Bt.quaternion.copy(or),Bt.scale.set(G,V,Y),Bt.updateMatrix(),this.edgesIm.setMatrixAt(f++,Bt.matrix)};C(-b,0,-T,gt,A,gt),C(+b,0,-T,gt,A,gt),C(+b,0,+T,gt,A,gt),C(-b,0,+T,gt,A,gt),C(0,-S,-T,P,gt,gt),C(+b,-S,0,gt,gt,E),C(0,-S,+T,P,gt,gt),C(-b,-S,0,gt,gt,E),C(0,+S,-T,P,gt,gt),C(+b,+S,0,gt,gt,E),C(0,+S,+T,P,gt,gt),C(-b,+S,0,gt,gt,E),this.edgesIm.instanceMatrix.needsUpdate=!0;const D=Sr.FACE_THICKNESS,O=(H,W,$,G,V,Y,st)=>{so.set(H,W,$).applyQuaternion(or).add(za),Bt.position.copy(so),Bt.quaternion.copy(or),Bt.scale.set(G,V,Y),Bt.updateMatrix(),st.setMatrixAt(e,Bt.matrix)};O(-b,0,0,D,_,v,this.facesIm[0]),O(+b,0,0,D,_,v,this.facesIm[1]),O(0,-S,0,M,D,v,this.facesIm[2]),O(0,+S,0,M,D,v,this.facesIm[3]),O(0,0,-T,M,_,D,this.facesIm[4]),O(0,0,+T,M,_,D,this.facesIm[5]);for(const H of this.facesIm)H.instanceMatrix.needsUpdate=!0}hideAll(){for(const t of[...this.facesIm,this.edgesIm]){for(let e=0;e<t.count;e++)t.getMatrixAt(e,Bt.matrix),Bt.matrix.decompose(Bt.position,Bt.quaternion,Bt.scale),Bt.position.setY(1e6),Bt.updateMatrix(),t.setMatrixAt(e,Bt.matrix);t.instanceMatrix.needsUpdate=!0}}};F(Sr,"FACE_THICKNESS",.01);let Qc=Sr;const Va="tt-box";class is{static reset(t,e){document.querySelectorAll(`.${Va}`).forEach(n=>n.remove());for(const[n,i]of t.boxes.entries()){if(n===t.targetBoxIndex)continue;const r=document.createElement("div");r.className=Va,r.style.display="none",r.id=`box-${n}`,r.onclick=()=>e(n),document.body.appendChild(r)}}static placeElement(t,[e,n,i,r]){const o=document.getElementById(`box-${t}`);o&&(o.style.display="block",o.style.left=`${e}px`,o.style.top=`${n}px`,o.style.width=`${i}px`,o.style.height=`${r}px`)}static hideAll(){document.querySelectorAll(`.${Va}`).forEach(t=>{t.style.display="none"})}}const ev={bounds:[0,0,0,200,200,200],boxes:[[80,80,80,40,50,40],[90,-60,90,20,50,20],[40,130,50,120,20,100],[40,150,120,30,50,30],[130,150,120,30,50,30],[80,150,120,40,50,30],[130,150,50,30,50,30],[80,150,50,40,50,30],[40,150,50,30,50,30],[90,50,90,20,30,20],[80,30,80,40,20,40],[70,10,70,60,20,60],[80,-10,80,40,20,40]],targetBoxIndex:1},nv={bounds:[0,0,0,200,200,200],boxes:[[90,80,90,20,50,20],[90,-60,90,20,50,20],[40,130,50,120,20,100],[80,150,120,40,50,30],[130,150,50,30,50,30],[40,150,50,30,50,30],[20,60,40,160,20,120],[80,30,80,40,30,40],[70,10,70,60,20,60],[80,-10,80,40,20,40],[60,80,130,30,50,20],[110,80,130,30,50,20],[140,80,50,20,50,20],[40,80,50,20,50,20],[20,40,40,20,20,20],[20,40,140,20,20,20],[160,40,140,20,20,20],[160,40,40,20,20,20]],targetBoxIndex:1},iv={bounds:[0,0,0,200,130,200],boxes:[[90,0,150,20,60,20],[90,0,30,20,60,20],[90,0,90,20,60,20],[40,60,30,120,20,140],[40,80,90,30,50,20]],targetBoxIndex:0},sv={bounds:[0,0,0,200,200,200],boxes:[[90,10,90,20,50,20],[40,130,40,120,20,140],[40,150,140,20,50,20],[140,150,140,20,50,20],[90,150,90,20,50,20],[20,130,30,20,70,30],[20,80,30,40,50,30],[20,60,20,160,20,160],[90,80,90,20,50,20],[20,-30,140,40,90,40],[20,80,160,20,120,20],[160,80,160,20,120,20],[40,150,30,20,50,30],[160,80,30,20,120,30],[140,150,30,20,50,30],[140,80,30,20,50,30],[140,80,140,20,50,20],[40,80,140,20,50,20]],targetBoxIndex:0},rv={bounds:[0,0,0,200,200,200],boxes:[[90,10,90,20,50,20],[20,80,160,20,120,20],[90,180,100,20,20,20],[140,80,20,40,120,40],[0,60,0,200,20,200],[20,-30,140,40,90,40],[160,80,160,20,120,20],[20,80,20,40,120,40],[80,160,90,20,20,20],[90,140,100,20,20,20],[100,120,90,20,20,20],[90,100,100,20,20,20],[80,80,90,20,20,20],[40,80,140,20,120,20],[140,80,140,20,120,20],[100,160,90,20,20,20],[80,120,90,20,20,20],[100,80,90,20,20,20],[90,180,80,20,20,20],[90,140,80,20,20,20],[90,100,80,20,20,20]],targetBoxIndex:0},Ei=[ev,nv,iv,sv,rv],Wo="tt-box-editor",tl=[{type:"center"},{type:"edge",dir:"E"},{type:"edge",dir:"S"},{type:"edge",dir:"N"},{type:"edge",dir:"W"},{type:"corner",dir:["N","E"]},{type:"corner",dir:["S","E"]},{type:"corner",dir:["N","W"]},{type:"corner",dir:["S","W"]}],Cn=10;function ku([s,t,e,n],i){const r=Cn/2,o=s+e/2,a=t+n/2;switch(i.type){case"center":return[s,t,e,n];case"edge":{switch(i.dir){case"N":return[o-r,t-r,Cn,Cn];case"S":return[o-r,t+n-r,Cn,Cn];case"E":return[s+e-r,a-r,Cn,Cn];case"W":return[s-r,a-r,Cn,Cn]}break}case"corner":{const[c,l]=i.dir,h=l==="E"?s+e:s,d=c==="S"?t+n:t;return[h-r,d-r,Cn,Cn]}}return[0,0,0,0]}const fd=10;function ro(s){return fd*Math.round(s/fd)}function ov(s,t,e,n,i){const r=ku(e,n),o=r[0]+r[2]/2,a=r[1]+r[3]/2;let c=i[0]-o;const l=i[1]-a,h=t==="S"||t==="N"?0:2,d=t==="S"||t==="N"?3:5,u=t==="S"||t==="E";let m=s[h],x=s[1],g=s[d],p=s[4];const f=()=>{let b=c;const S=g-b;if(S<1){b=g-1,m+=b,g=1;return}m+=b,g=S},M=()=>{const b=g+c;g=b<1?1:b},_=()=>{let b=l;const S=p-b;if(S<1){b=p-1,x+=b,p=1;return}x+=b,p=S},v=()=>{const b=p+l;p=b<1?1:b};switch(u&&(c*=-1),n.type){case"center":m+=c,x+=l;break;case"edge":switch(n.dir){case"W":u?M():f();break;case"E":u?f():M();break;case"N":_();break;case"S":v();break}break;case"corner":{const[b,S]=n.dir;S==="W"?u?M():f():u?f():M(),b==="N"?_():v();break}}s[h]=ro(m),s[1]=ro(x),s[d]=ro(g),s[4]=ro(p)}let vi=-1;class ri{static down(t,e){vi=e;const n=document.getElementById(`node-${vi}`);n&&n.classList.add("active")}static move(t){if(vi===-1)return;const e=vi;if(this.towerToppler){const n=this.towerToppler.graphics.boxes.selectedBoxIndex;if(n>=0){const i=this.towerToppler.state.levelIndex,o=Ei[i].boxes[n],a=this.towerToppler.state.flatDirection,c=this.towerToppler.locateBoxOnScreen(n);ov(o,a,c,tl[e],t),this.towerToppler.rebuildGraphics(),this.showAll(),vi=e}}}static up(t){vi>=0&&(document.querySelectorAll(`.${Wo}`).forEach(e=>{e.classList.remove("active")}),vi=-1)}static showAll(){if(vi=-1,this.towerToppler){const t=this.towerToppler.graphics.boxes.selectedBoxIndex;if(t>=0){const e=this.towerToppler.locateBoxOnScreen(t);for(const[n,i]of tl.entries()){const r=ku(e,i);this.placeNode(n,r)}}}}static hideAll(){document.querySelectorAll(`.${Wo}`).forEach(t=>{t.style.display="none"})}static placeNode(t,[e,n,i,r]){const o=document.getElementById(`node-${t}`);o&&(o.style.display="block",o.style.left=`${e}px`,o.style.top=`${n}px`,o.style.width=`${i}px`,o.style.height=`${r}px`)}}F(ri,"towerToppler",null);for(const[s,t]of tl.entries()){const e=document.createElement("div");e.classList.add(Wo,`${Wo}-${t.type}`),e.style.display="none",e.id=`node-${s}`,e.onpointerdown=n=>{ri.down([n.clientX,n.clientY],s),n.stopPropagation()},document.body.appendChild(e)}document.addEventListener("mousemove",s=>ri.move([s.clientX,s.clientY]));document.addEventListener("mouseup",s=>ri.up([s.clientX,s.clientY]));function av(s,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",n=t.display.classes??[],i=n.filter(a=>a.startsWith("fa-")),r=n.filter(a=>!a.startsWith("fa-"));t.display.type!=="button"&&r.push("noselect");const o=lv(`
    <${e} 
       id="${s}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${r.join(" ")}
        ">

      <span 
        class="${i.join(" ")}" 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[a,c]of Object.entries(t.display.styles??{}))o.style.setProperty(a,c);return t.id=s,t.htmlElem=o,o}function ar(s,t){t?rs(s):Pi(s)}function Pi(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function rs(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function oo(s,t){if(s.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:n}=s;n&&(n.innerHTML=`
    <span ${s.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function cv(s,t,e){if(!e){s.classList.add("hidden");return}s.style.opacity="";const[n,i,r,o]=e;s.style.display="",s.style.left=`${n}px`,s.style.top=`${i}px`,s.style.width=`${r}px`,s.style.height=`${o}px`;const a=s;a.width=r*window.devicePixelRatio,a.height=o*window.devicePixelRatio}function lv(s){const t=document.createElement("div");return t.innerHTML=s.trim(),t.firstChild}function hv(s){s.isLandscape,s.isPortrait}function dv(s){return Object.entries(s)}function uv(s,t){return new el(s,t)._computedRects}const On=class On{constructor(t,e){F(this,"_computedRects",{});F(this,"isPortrait",!1);F(this,"isLandscape",!1);F(this,"parent");F(this,"_currentLayoutKey","");F(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const n=600;t[2]<n||t[3]<n?On.isSmall=!0:On.isSmall=!1,hv(this),this.parent=t;for(const[r,o]of Object.entries(e))this.parent=t,this._currentLayoutKey=r,this._computedRects[r]=this.computeRect(o);const i=this._childrenToParse;for(;Object.keys(i).length>0;){const r=Object.keys(i)[0],o=i[r];delete i[r];const a=this._computedRects[r],{_computedRects:c}=new On(a,o);for(const l in c)this._computedRects[`${r}.${l}`]=c[l]}}computeRect(t){let e=[...this.parent];for(const[n,i]of dv(t))if(n==="parent"){if(!(i in this._computedRects))throw new Error(`layout parent '${i}' not defined by any previous rulesets`);this.parent=this._computedRects[i],e=[...this.parent]}else if(n.startsWith("parent@")){const[r,o]=n.split("@");if(typeof i!="string"||!(i in this._computedRects))throw new Error(`layout parent '${i}' not defined by any previous rulesets`);if(o==="portrait")this.isPortrait&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="landscape")this.isLandscape&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="sm-portrait")this.isPortrait&&On.isSmall&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="sm-landscape")this.isLandscape&&On.isSmall&&(this.parent=this._computedRects[i],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else if(n==="children")this._childrenToParse[this._currentLayoutKey]=i;else if(n.includes("@")){const[r,o]=n.split("@");if(o==="portrait")this.isPortrait&&(e=this.applyRule(e,r,i));else if(o==="landscape")this.isLandscape&&(e=this.applyRule(e,r,i));else if(o==="sm-portrait")this.isPortrait&&On.isSmall&&(e=this.applyRule(e,r,i));else if(o==="sm-landscape")this.isLandscape&&On.isSmall&&(e=this.applyRule(e,r,i));else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else e=this.applyRule(e,n,i);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,n){const[i,r,o,a]=t,[c,l,h,d]=this.parent,u=(x,g)=>{if(typeof g=="function"&&(g=g()),typeof g=="string"&&g.endsWith("%")){const p=parseFloat(g)/100;return["left","right","width","margin"].includes(x)?h*p:d*p}else{if(g==="auto")return x==="width"?c+h-i:x==="height"?l+d-r:["left","right"].includes(x)?(h-o)/2:(d-a)/2;if(typeof g=="number"&&g<0){if(x==="width")return h+g;if(x==="height")return d+g}}return Number(g)},m=e.split("-");if(m.length===2){const[x,g]=m;let p;if(x==="min")p=Math.max;else if(x==="max")p=Math.min;else throw new Error("only min- or max- prefixed allowed");if(g==="width")return[i,r,p(o,u("width",n)),a];if(g==="height")return[i,r,o,p(a,u("height",n))];if(g==="left")return[p(i,u("left",n)),r,o,a];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[c+u("left",n),r,o,a];case"right":return[c+h-o-u("right",n),r,o,a];case"top":return[i,l+u("top",n),o,a];case"bottom":return[i,l+d-a-u("bottom",n),o,a];case"width":return[i,r,u("width",n),a];case"height":return[i,r,o,u("height",n)];case"margin":{const x=u("margin",n);return[i+x,r+x,o-2*x,a-2*x]}default:return t}}};F(On,"isSmall",!1);let el=On;const pd={};let fv=0;class fn{constructor(){F(this,"guiLayout");F(this,"layoutRectangles",{});F(this,"elements",{});F(this,"layoutFactory")}init(t,e,n){this.layoutFactory=e;for(const i of n)if(typeof i.id=="string")this.elements[i.id]=i;else{const r=`_${fv++}`;this.elements[r]=i;const o=av(r,i);o.onclick=a=>{a.preventDefault(),i.click&&i.click({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerdown=a=>{a.preventDefault(),i.down&&i.down({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointermove=a=>{a.preventDefault(),i.move&&i.move({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerup=a=>{a.preventDefault(),i.up&&i.up({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerleave=a=>{a.preventDefault(),i.up&&i.up({elementId:r,towerToppler:t,pointerEvent:a})},o.style.display="none",document.body.appendChild(o),pd[r]=o,i.id=r}}refreshLayout(t){const e=[0,0,window.innerWidth,window.innerHeight];this.guiLayout=this.layoutFactory(t),this.layoutRectangles=uv(e,this.guiLayout);for(const n in this.elements){const i=this.elements[n],r=this.layoutRectangles[i.layoutKey];i.rectangle=r,i.rectangle&&(i.dprRectangle=i.rectangle.map(o=>o*window.devicePixelRatio)),cv(pd[n],i,r)}}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const n=this._registry[e];if(!n)throw new Error(`gui ${e} not registered `);const{factory:i,layoutFactory:r,elements:o}=n,a=i();this._preloaded[e]=a,a.init(t,r,o)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}F(fn,"_registry",{}),F(fn,"_preloaded",{});const pv={screen:{},_outerMargin:{parent:"screen",margin:()=>Re.flatConfig.outerMargin},topLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight},bottomLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},nextLevelBtn:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,bottom:0},resetBtn:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,top:0},bottomBar:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:"auto",bottom:0},rotateLeft:{parent:"bottomBar",width:"50%"},rotateRight:{parent:"bottomBar",width:"50%",right:0}},Gu={layoutKey:"topLabel",display:{type:"panel",label:"Remove one block",textAlign:"left",styles:{border:"none"}}},Ti={layoutKey:"bottomLabel",display:{type:"panel",label:"Drag to rotate",textAlign:"left",styles:{border:"none"}}},nl={layoutKey:"resetBtn",display:{type:"button",label:"Reset",classes:["click-me"]},click:({towerToppler:s})=>{s.resetLevel()}},mr={layoutKey:"nextLevelBtn",display:{type:"button",label:"Next",classes:["click-me"]},click:({towerToppler:s})=>{s.goToNextLevel()}},wl={layoutKey:"rotateLeft",display:{type:"button",label:"<"},click:({towerToppler:s})=>{s.toggleViewDirection(-1)}},Tl={layoutKey:"rotateRight",display:{type:"button",label:">"},click:({towerToppler:s})=>{s.toggleViewDirection(1)}},Hl=class Hl extends fn{};fn.register("playing-gui",{factory:()=>new Hl,layoutFactory:()=>pv,elements:[Gu,nl,Ti,mr,wl,Tl]});let md=Hl;const Ls={hasDragged:!1,hasRemovedBlock:!1},xd={type:"change"},Cl={type:"start"},Hu={type:"end"},ao=new Sl,gd=new Ai,mv=Math.cos(70*rp.DEG2RAD),De=new B,Qe=2*Math.PI,pe={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},ka=1e-6;class xv extends kp{constructor(t,e=null){super(t,e),this.state=pe.NONE,this.target=new B,this.cursor=new B,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Us.ROTATE,MIDDLE:Us.DOLLY,RIGHT:Us.PAN},this.touches={ONE:Is.ROTATE,TWO:Is.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new B,this._lastQuaternion=new Ui,this._lastTargetPosition=new B,this._quat=new Ui().setFromUnitVectors(t.up,new B(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new ko,this._sphericalDelta=new ko,this._scale=1,this._panOffset=new B,this._rotateStart=new zt,this._rotateEnd=new zt,this._rotateDelta=new zt,this._panStart=new zt,this._panEnd=new zt,this._panDelta=new zt,this._dollyStart=new zt,this._dollyEnd=new zt,this._dollyDelta=new zt,this._dollyDirection=new B,this._mouse=new zt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=_v.bind(this),this._onPointerDown=gv.bind(this),this._onPointerUp=vv.bind(this),this._onContextMenu=wv.bind(this),this._onMouseWheel=Sv.bind(this),this._onKeyDown=yv.bind(this),this._onTouchStart=Ev.bind(this),this._onTouchMove=Av.bind(this),this._onMouseDown=bv.bind(this),this._onMouseMove=Mv.bind(this),this._interceptControlDown=Tv.bind(this),this._interceptControlUp=Cv.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(t){super.connect(t),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(xd),this.update(),this.state=pe.NONE}update(t=null){const e=this.object.position;De.copy(e).sub(this.target),De.applyQuaternion(this._quat),this._spherical.setFromVector3(De),this.autoRotate&&this.state===pe.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,i=this.maxAzimuthAngle;isFinite(n)&&isFinite(i)&&(n<-Math.PI?n+=Qe:n>Math.PI&&(n-=Qe),i<-Math.PI?i+=Qe:i>Math.PI&&(i-=Qe),n<=i?this._spherical.theta=Math.max(n,Math.min(i,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+i)/2?Math.max(n,this._spherical.theta):Math.min(i,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(De.setFromSpherical(this._spherical),De.applyQuaternion(this._quatInverse),e.copy(this.target).add(De),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const a=De.length();o=this._clampDistance(a*this._scale);const c=a-o;this.object.position.addScaledVector(this._dollyDirection,c),this.object.updateMatrixWorld(),r=!!c}else if(this.object.isOrthographicCamera){const a=new B(this._mouse.x,this._mouse.y,0);a.unproject(this.object);const c=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=c!==this.object.zoom;const l=new B(this._mouse.x,this._mouse.y,0);l.unproject(this.object),this.object.position.sub(l).add(a),this.object.updateMatrixWorld(),o=De.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(ao.origin.copy(this.object.position),ao.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(ao.direction))<mv?this.object.lookAt(this.target):(gd.setFromNormalAndCoplanarPoint(this.object.up,this.target),ao.intersectPlane(gd,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>ka||8*(1-this._lastQuaternion.dot(this.object.quaternion))>ka||this._lastTargetPosition.distanceToSquared(this.target)>ka?(this.dispatchEvent(xd),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?Qe/60*this.autoRotateSpeed*t:Qe/60/60*this.autoRotateSpeed}_getZoomScale(t){const e=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*e)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,e){De.setFromMatrixColumn(e,0),De.multiplyScalar(-t),this._panOffset.add(De)}_panUp(t,e){this.screenSpacePanning===!0?De.setFromMatrixColumn(e,1):(De.setFromMatrixColumn(e,0),De.crossVectors(this.object.up,De)),De.multiplyScalar(t),this._panOffset.add(De)}_pan(t,e){const n=this.domElement;if(this.object.isPerspectiveCamera){const i=this.object.position;De.copy(i).sub(this.target);let r=De.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*r/n.clientHeight,this.object.matrix),this._panUp(2*e*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(e*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,e){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),i=t-n.left,r=e-n.top,o=n.width,a=n.height;this._mouse.x=i/o*2-1,this._mouse.y=-(r/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientX),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(Qe*this._rotateDelta.x/e.clientHeight),this._rotateUp(Qe*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let e=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(Qe*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),e=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-Qe*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),e=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(Qe*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),e=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-Qe*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),e=!0;break}e&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._rotateStart.set(n,i)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._panStart.set(n,i)}}_handleTouchStartDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,i=t.pageY-e.y,r=Math.sqrt(n*n+i*i);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{const n=this._getSecondPointerPosition(t),i=.5*(t.pageX+n.x),r=.5*(t.pageY+n.y);this._rotateEnd.set(i,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(Qe*this._rotateDelta.x/e.clientHeight),this._rotateUp(Qe*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._panEnd.set(n,i)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,i=t.pageY-e.y,r=Math.sqrt(n*n+i*i);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(t.pageX+e.x)*.5,a=(t.pageY+e.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId){this._pointers.splice(e,1);return}}_isTrackingPointer(t){for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId)return!0;return!1}_trackPointer(t){let e=this._pointerPositions[t.pointerId];e===void 0&&(e=new zt,this._pointerPositions[t.pointerId]=e),e.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){const e=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[e]}_customWheelEvent(t){const e=t.deltaMode,n={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(e){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function gv(s){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(s.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(s)&&(this._addPointer(s),s.pointerType==="touch"?this._onTouchStart(s):this._onMouseDown(s)))}function _v(s){this.enabled!==!1&&(s.pointerType==="touch"?this._onTouchMove(s):this._onMouseMove(s))}function vv(s){switch(this._removePointer(s),this._pointers.length){case 0:this.domElement.releasePointerCapture(s.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Hu),this.state=pe.NONE;break;case 1:const t=this._pointers[0],e=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:e.x,pageY:e.y});break}}function bv(s){let t;switch(s.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Us.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(s),this.state=pe.DOLLY;break;case Us.ROTATE:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=pe.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=pe.ROTATE}break;case Us.PAN:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=pe.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=pe.PAN}break;default:this.state=pe.NONE}this.state!==pe.NONE&&this.dispatchEvent(Cl)}function Mv(s){switch(this.state){case pe.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(s);break;case pe.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(s);break;case pe.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(s);break}}function Sv(s){this.enabled===!1||this.enableZoom===!1||this.state!==pe.NONE||(s.preventDefault(),this.dispatchEvent(Cl),this._handleMouseWheel(this._customWheelEvent(s)),this.dispatchEvent(Hu))}function yv(s){this.enabled!==!1&&this._handleKeyDown(s)}function Ev(s){switch(this._trackPointer(s),this._pointers.length){case 1:switch(this.touches.ONE){case Is.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(s),this.state=pe.TOUCH_ROTATE;break;case Is.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(s),this.state=pe.TOUCH_PAN;break;default:this.state=pe.NONE}break;case 2:switch(this.touches.TWO){case Is.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(s),this.state=pe.TOUCH_DOLLY_PAN;break;case Is.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(s),this.state=pe.TOUCH_DOLLY_ROTATE;break;default:this.state=pe.NONE}break;default:this.state=pe.NONE}this.state!==pe.NONE&&this.dispatchEvent(Cl)}function Av(s){switch(this._trackPointer(s),this.state){case pe.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(s),this.update();break;case pe.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(s),this.update();break;case pe.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(s),this.update();break;case pe.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(s),this.update();break;default:this.state=pe.NONE}}function wv(s){this.enabled!==!1&&s.preventDefault()}function Tv(s){s.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function Cv(s){s.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const Rv=.01,Ga=30,_d=new B,vd=new B,bd=new B,qi=new B,Pv=new B,Lv=new B,cr=new B,bi=new ko,Yi=new ko;class Iv{constructor(t){F(this,"camera");F(this,"controls");F(this,"currentViewMode","perspective");F(this,"cameraDist",100);F(this,"isDragging",!1);F(this,"isSnapping",!1);F(this,"isFlat",!1);F(this,"reachedTargetPerspective",!1);this.camera=new Sn(Ga,window.innerWidth/window.innerHeight,.1,1e10),this.controls=new xv(this.camera,t),this.controls.enableDamping=!0,this.controls.dampingFactor=.1,this.controls.enablePan=!1,this.controls.enableZoom=!0,this.controls.minDistance=10,this.controls.maxDistance=1e10,this.controls.addEventListener("start",()=>this.startDrag()),this.controls.addEventListener("end",()=>this.endDrag())}startDrag(){this.isDragging=!0,this.isSnapping=!1,this.isFlat=!1,this.toggleViewMode("perspective"),is.hideAll(),ri.hideAll()}endDrag(){this.isDragging=!1}reset(t){const[e,n,i,r,o,a]=t.bounds,c=[r/2,o/2,a/2];this.isDragging=!1,this.isSnapping=!1,this.isFlat=!1,this.camera.fov=Ga,this.currentViewMode="perspective",this.reachedTargetPerspective=!1,this.cameraDist=100;const l=40;this.camera.position.set(c[0]+10*l,c[1]+12*l,c[2]+14*l),this.camera.lookAt(...c),this.camera.updateProjectionMatrix(),this.controls.enabled=!0,this.controls.target.set(...c),this.controls.update(),this.cameraDist=this.camera.position.distanceTo(this.controls.target)}update(t,e){if(!this.reachedTargetPerspective){let n;this.currentViewMode==="orthographic"?n=Rv:n=Ga,this.animatePerspective(n,t)}if(this.controls.update(),!this.isFlat&&!this.isSnapping&&!this.isDragging&&(Math.abs(this.controls._sphericalDelta.theta)>.01||Math.abs(this.controls._sphericalDelta.phi)>.01||Math.abs(this.controls._sphericalDelta.radius)>.01||(e.flatDirection=k_(this.camera,this.controls.target),(e.flatDirection==="E"||e.flatDirection==="W")&&(Ls.hasDragged=!0,Pi(Ti),rs(wl),rs(Tl)),this.isSnapping=!0,this.toggleViewMode("orthographic"))),!this.isDragging&&this.isSnapping){const n=this.camera,i=this.controls.target;cr.copy(n.position).sub(i);const r=G_(this.controls.target,this.cameraDist,e.flatDirection);qi.set(r[0]-i.x,r[1]-i.y,r[2]-i.z),bi.radius=cr.length(),bi.theta=Math.atan2(cr.x,cr.z),bi.phi=Math.acos(cr.y/(bi.radius||1e-8)),_d.set(qi.x,qi.y,qi.z),Yi.radius=_d.length(),Yi.theta=Math.atan2(qi.x,qi.z),Yi.phi=Math.acos(qi.y/(Yi.radius||1e-8));const o=.18;let a=Yi.theta-bi.theta;a>Math.PI&&(a-=2*Math.PI),a<-Math.PI&&(a+=2*Math.PI);const c=bi.theta+a*o,l=id(bi.phi,Yi.phi,o),h=id(bi.radius,Yi.radius,o),d=Math.sin(l),u=h*d*Math.sin(c),m=h*Math.cos(l),x=h*d*Math.cos(c);n.position.set(i.x+u,i.y+m,i.z+x),n.lookAt(i.x,i.y,i.z),n.updateProjectionMatrix(),this.controls.update(),vd.subVectors(n.position,i).normalize(),bd.set(r[0]-i.x,r[1]-i.y,r[2]-i.z).normalize();const g=vd.dot(bd);if(Math.acos(Math.max(-1,Math.min(1,g)))<1e-4)return n.position.set(r[0],r[1],r[2]),n.lookAt(i.x,i.y,i.z),n.updateProjectionMatrix(),this.controls.update(),this.isSnapping=!1,this.isFlat=!0,!0}return!1}getScale2d(){const t=this.camera.fov*Math.PI/180,n=2*Math.tan(t/2)*this.cameraDist*this.camera.aspect;return window.innerWidth/n}onResize(){this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix(),this.controls&&this.controls.update(),this.isFlat=!1}toggleViewMode(t){t||(this.currentViewMode==="orthographic"?t="perspective":t="orthographic"),t!==this.currentViewMode&&(this.currentViewMode=t,this.reachedTargetPerspective=!1)}animatePerspective(t,e){const n=this.camera,i=this.controls,r=i.target,o=this.cameraDist,a=n.fov,c=Math.tan(a*Math.PI/180/2)*o,l=.1;let h=a;Math.abs(t-a)<=l*e?(h=t,this.reachedTargetPerspective=!0):h+=Math.sign(t-a)*l*e;const d=c/Math.tan(h*Math.PI/180/2);this.cameraDist=d;const u=Pv.copy(r).sub(n.position).normalize();n.position.copy(Lv.copy(r).sub(u.multiplyScalar(d))),n.fov=h,n.updateProjectionMatrix(),i.update()}}const Wu=new rn({map:di,transparent:!0,opacity:.5}),Dv=new rn({color:I_}),Fv=new rn({color:Iu});Wu.onBeforeCompile=s=>{s.uniforms.atlasSize={value:qe},s.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+s.vertexShader,s.vertexShader=s.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`))};const Rl=100,Uv=.1,Md=1,jn=new ge,hn=new ge,Jn=new ge,Sd=new B,Xu=new Float32Array(Rl);for(let s=0;s<Rl;++s)Xu[s]=Math.floor(Math.random()*qe)/qe;class Nv{constructor(){F(this,"im");F(this,"faceStates",[]);F(this,"uvOffsets");F(this,"geometry");const t=Md,e=-t/2,n=8,i=new ui(1,1,1,n,1,!0,e,t);this.im=new ze(i,Wu,Rl),this.uvOffsets=new Hs(Xu,1),i.setAttribute("uvOffset",this.uvOffsets),this.im.instanceMatrix.needsUpdate=!0,this.geometry=i}clear(){this.im.count=0,this.im.instanceMatrix.needsUpdate=!0,this.im.instanceColor&&(this.im.instanceColor.needsUpdate=!0)}hideAll(){const t=this.im;for(let e=0;e<t.count;e++)t.getMatrixAt(e,hn.matrix),hn.matrix.decompose(hn.position,hn.quaternion,hn.scale),hn.position.setY(1e6),hn.updateMatrix(),t.setMatrixAt(e,hn.matrix);t.instanceMatrix.needsUpdate=!0}addFace(){const t=this.im.count,e=Math.floor(Math.random()*hi.length),n=["N","S","E","W"],i=n[Math.floor(Math.random()*n.length)];this.faceStates.push({faceIndex:e,dir:i,slideOffset:-1}),this.uvOffsets.setX(t,(1+2*e)/qe),this.im.count++}update(t){const n=t*.01,i=this.uvOffsets;for(let r=0;r<this.im.count;r++){const o=this.faceStates[r];Math.random()<t*Ys.flatConfig.emoteProbability&&(o.faceIndex=Math.floor(Math.random()*hi.length));const{slideOffset:a,faceIndex:c}=o;a<0?o.slideOffset=Math.min(0,a+n):a>0&&(o.slideOffset=Math.max(0,a-n)),i.setX(r,(1+2*c+a)/qe)}i.needsUpdate=!0,this.im.instanceMatrix.needsUpdate=!0}positionFaces(t,e){for(let n=0;n<t.count;n++){t.getMatrixAt(n,jn.matrix),jn.matrix.decompose(jn.position,jn.quaternion,jn.scale);const i=jn.scale.x,r=i*Md,o=i*(1+Uv),a=this.faceStates[n],c=a?a.dir:"N";let l=0;switch(c){case"N":{l=0;break}case"S":{l=Math.PI;break}case"E":{l=-Math.PI/2;break}case"W":{l=Math.PI/2;break}}hn.position.set(jn.position.x,jn.position.y,jn.position.z),hn.rotation.set(0,l,0),hn.scale.set(o,r,o),hn.updateMatrix(),this.im.setMatrixAt(n,hn.matrix),this.im.getMatrixAt(n,Jn.matrix),Jn.matrix.decompose(Jn.position,Jn.quaternion,Jn.scale),Sd.set(e.position.x,Jn.position.y,e.position.z),Jn.lookAt(Sd),Jn.updateMatrix(),this.im.setMatrixAt(n,Jn.matrix)}this.im.count=t.count,this.im.instanceMatrix.needsUpdate=!0}}const Ha=15,yd=2,Ov=new ea(1,32,16),Bv=new ta(1,32),tn=new ge,Mi=new ge,zv=new B;class Vv{constructor(){F(this,"domesIm",new ze(Ov,Dv,Ha));F(this,"crownsIm",new ze(Bv,Fv,Ha));F(this,"faces",new Nv);F(this,"cloudData",[]);F(this,"springDamping",20);F(this,"springFreq",12);F(this,"animMaxTime",.5);F(this,"groundY",0);F(this,"centerX",0);F(this,"centerZ",0);F(this,"createdAt",performance.now())}clear(){for(const t of this.instancedMeshes)t.count=0;this.cloudData.length=0}addRandomClouds(t){const[e,n,i,r,o,a]=t.bounds;this.groundY=n;const c=e+r/2,l=i+a/2;this.centerX=c,this.centerZ=l;for(let h=0;h<Ha;h++){const u=Math.random()*Ou,m=200+Math.random()*50,x=20+10*Math.floor(Math.random()*2),g=c+500*Math.cos(u),p=l+500*Math.sin(u);this.addCloud(g,p,x,m)}}update(t,e){zv.copy(t.position);const n=t.position.distanceTo(e),i=new B,r=this.instancedMeshes[0].count;for(let o=0;o<r;o++){const a=this.cloudData[o];if(!a)continue;const c=performance.now(),l=(c-this.createdAt)/1e3,h=a.angle+l*a.rotationSpeed,d=this.centerX+a.dist*Math.cos(h),u=this.centerZ+a.dist*Math.sin(h);i.set(d,a.y/2,u),t.position.distanceTo(i)>=n?(a.animState==="hidden"||a.animState==="hiding")&&(a.animState="showing",a.animStart=c):(a.animState==="shown"||a.animState==="showing")&&(a.animState="hiding",a.animStart=c);let g=0;const p=-1e3;if(a.animState==="hidden")g=1e7;else if(a.animState==="shown")g=0;else{const _=(c-a.animStart)/1e3,v=this.springDamping,b=this.springFreq,S=1-Math.exp(-v*_)*Math.cos(b*_);if(a.animState==="showing")g=p*(1-S),_>this.animMaxTime&&(a.animState="shown",g=0);else if(a.animState==="hiding"){const T=Math.exp(-v*_)*Math.cos(b*_);g=p*(1-T),_>this.animMaxTime*.5&&(a.animState="hidden",g=p)}}const f=a.y-g;tn.position.set(d,f,u),tn.scale.set(a.radius,a.radius,a.radius),tn.updateMatrix(),this.domesIm.setMatrixAt(o,tn.matrix);const M=a.radius+yd;tn.scale.set(M,M,M),tn.updateMatrix(),this.crownsIm.setMatrixAt(o,tn.matrix),this.crownsIm.getMatrixAt(o,Mi.matrix),Mi.matrix.decompose(Mi.position,Mi.quaternion,Mi.scale),Mi.lookAt(t.position),Mi.updateMatrix(),this.crownsIm.setMatrixAt(o,Mi.matrix)}this.faces.positionFaces(this.domesIm,t);for(const o of this.instancedMeshes)o.instanceMatrix.needsUpdate=!0}addCloud(t,e,n,i){const r=this.instancedMeshes[0].count;this.faces.addFace();for(const d of this.instancedMeshes)d.count=r+1;const o=t-this.centerX,a=e-this.centerZ,c=Math.sqrt(o*o+a*a),l=Math.atan2(a,o);this.cloudData[r]={x:t,z:e,radius:n,y:i,dist:c,angle:l,animState:"shown",rotationSpeed:.001+Math.random()*.01,animStart:performance.now()},tn.position.set(t,i,e),tn.scale.set(n,n,n),tn.updateMatrix(),this.domesIm.setMatrixAt(r,tn.matrix);const h=n+yd;tn.scale.set(h,h,h),tn.updateMatrix(),this.crownsIm.setMatrixAt(r,tn.matrix)}get instancedMeshes(){return[this.domesIm,this.crownsIm,this.faces.im]}}const kv=new rn({color:P_}),Xo=1e3,Ed=1e3,Gv=new ui(Xo,Xo,Ed).translate(0,-Ed/2,0),Hv=new sn(Gv,kv),Wv=new rn({color:0,side:Pn}),Xv=new ui(Xo,Xo,2,32,1,!0).translate(0,1,0),qv=new sn(Xv,Wv),Yv=new rn({color:14540253,side:Pn}),$v=new ui(1,1,1,4,1,!0).rotateY(wi).translate(0,.5,0),Ad=new sn($v,Yv);class xr{static reset(t){const[e,n,i,r,o,a]=t.bounds;this.mesh.position.set(e+r/2,n,i+a/2),Ad.scale.set(r,1,a)}}F(xr,"mesh",new fr().add(Hv,Ad,qv));const Pl=new rn({map:di,transparent:!0,opacity:.5}),il=new rn({color:L_}),Io=new rn({color:Iu}),Kv=[Io,il,Pl],wd=.05,Zv=.005,jv=1e-5,Jv={value:.0025},Do={value:.05},sl={value:0};function Qv(s){sl.value+=s*Zv*(.2+.4*Math.sin(sl.value*1e-4)),Do.value<wd&&(Do.value=Math.min(wd,Do.value+s*jv))}for(const s of Kv)s.onBeforeCompile=t=>{t.uniforms.uTime=sl,t.uniforms.uGlobalFreq=Jv,t.uniforms.uGlobalAmp=Do,t.vertexShader=`
  uniform float uTime;
  uniform float uGlobalFreq;
  uniform float uGlobalAmp;
  attribute float instanceOffset; // per-hill random phase
  ${t.vertexShader}
  `.replace("#include <begin_vertex>",`
        // Cartoonish jello hose wave: spine anchored at bottom, top moves most.
        vec3 transformed = vec3(position);

        #ifdef USE_INSTANCING
          mat4 worldMat = modelMatrix * instanceMatrix;
        #else
          mat4 worldMat = modelMatrix;
        #endif

        vec3 worldPos = (worldMat * vec4(transformed, 1.0)).xyz;

        // Per-axis scale so deformation magnitude is scale-invariant.
        vec3 scaleVec = vec3(
          length(worldMat[0].xyz),
          length(worldMat[1].xyz),
          length(worldMat[2].xyz)
        );

        float t = uTime + instanceOffset; // Time driver with unique per-hill phase
        float freq = uGlobalFreq;    // Spatial frequency along height
        float baseAmp = uGlobalAmp;  // Overall amplitude control

        // Height factor: bottom (y≈0) almost rigid; top flexes fully.
        float hFactor = clamp(worldPos.y * 0.08, 0.0, 1.0);
        hFactor = smoothstep(0.0, 1.0, hFactor);

        // Bending angle of vertical spine (hose) depending on height & time.
        float bend = sin(t * 0.8 + worldPos.y * freq) * baseAmp * hFactor;

        // Side-to-side displacement proportional to height (rotation around spine).
        float lateralX = bend * worldPos.y;

        // Light jello wobble in Z for extra cartoon feel.
        float lateralZ = 0.35 * bend * worldPos.y + 0.08 * sin(worldPos.y * freq * 1.7 + t * 1.3);

        // Vertical offset: when leaning sideways, top shifts up/down preserving length illusion.
        float verticalOffset = -0.15 * abs(bend) * worldPos.y + 0.05 * sin(worldPos.y * freq * 1.2 + t * 2.0);

        vec3 offset = vec3(lateralX, verticalOffset, lateralZ);

        // Map world-space offset back into the mesh's local space taking rotation into account.
        // Using the normalized world axes (columns of worldMat) as a basis allows consistent
        // deformation even when instances have different rotations.
        vec3 axisX = normalize(worldMat[0].xyz);
        vec3 axisY = normalize(worldMat[1].xyz);
        vec3 axisZ = normalize(worldMat[2].xyz);

        vec3 localOffset;
        localOffset.x = dot(offset, axisX) / scaleVec.x; // project onto local X then remove scale
        localOffset.y = dot(offset, axisY) / scaleVec.y; // project onto local Y then remove scale
        localOffset.z = dot(offset, axisZ) / scaleVec.z; // project onto local Z then remove scale

        transformed += localOffset;
      `),s===Pl&&(t.uniforms.atlasSize={value:qe},t.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`)))};const Ll=100,t1=.1,Td=1,Qn=new ge,dn=new ge,ti=new ge,Cd=new B,qu=new Float32Array(Ll);for(let s=0;s<Ll;++s)qu[s]=Math.floor(Math.random()*qe)/qe;class e1{constructor(){F(this,"im");F(this,"faceStates",[]);F(this,"uvOffsets");F(this,"geometry");const t=Td,e=-t/2,n=8,i=new ui(1,1,1,n,1,!0,e,t);this.im=new ze(i,Pl,Ll),this.uvOffsets=new Hs(qu,1),i.setAttribute("uvOffset",this.uvOffsets),this.im.instanceMatrix.needsUpdate=!0,this.geometry=i}clear(){this.im.count=0,this.im.instanceMatrix.needsUpdate=!0,this.im.instanceColor&&(this.im.instanceColor.needsUpdate=!0)}hideAll(){const t=this.im;for(let e=0;e<t.count;e++)t.getMatrixAt(e,dn.matrix),dn.matrix.decompose(dn.position,dn.quaternion,dn.scale),dn.position.setY(1e6),dn.updateMatrix(),t.setMatrixAt(e,dn.matrix);t.instanceMatrix.needsUpdate=!0}addFace(){const t=this.im.count,e=Math.floor(Math.random()*hi.length),n=["N","S","E","W"],i=n[Math.floor(Math.random()*n.length)];this.faceStates.push({faceIndex:e,dir:i,slideOffset:-1}),this.uvOffsets.setX(t,(1+2*e)/qe),this.im.count++}update(t){const n=t*.01,i=this.uvOffsets;for(let r=0;r<this.im.count;r++){const o=this.faceStates[r];Math.random()<t*Ys.flatConfig.emoteProbability&&(o.faceIndex=Math.floor(Math.random()*hi.length));const{slideOffset:a,faceIndex:c}=o;a<0?o.slideOffset=Math.min(0,a+n):a>0&&(o.slideOffset=Math.max(0,a-n)),i.setX(r,(1+2*c+a)/qe)}i.needsUpdate=!0,this.im.instanceMatrix.needsUpdate=!0}positionFaces(t,e){for(let n=0;n<t.count;n++){t.getMatrixAt(n,Qn.matrix),Qn.matrix.decompose(Qn.position,Qn.quaternion,Qn.scale);const i=Qn.scale.x,r=i*Td,o=i*(1+t1),a=this.faceStates[n],c=a?a.dir:"N";let l=0;switch(c){case"N":{l=0;break}case"S":{l=Math.PI;break}case"E":{l=-Math.PI/2;break}case"W":{l=Math.PI/2;break}}dn.position.set(Qn.position.x,Qn.position.y,Qn.position.z),dn.rotation.set(0,l,0),dn.scale.set(o,r,o),dn.updateMatrix(),this.im.setMatrixAt(n,dn.matrix),this.im.getMatrixAt(n,ti.matrix),ti.matrix.decompose(ti.position,ti.quaternion,ti.scale),Cd.set(e.position.x,ti.position.y,e.position.z),ti.lookAt(Cd),ti.updateMatrix(),this.im.setMatrixAt(n,ti.matrix)}this.im.count=t.count,this.im.instanceMatrix.needsUpdate=!0}}const Si=30,Nn=2,Rd=20,Pd=new ui,Ld=new Xs,Id=new ea(1,32,16,0,Math.PI*2,0,Math.PI/2),Dd=new ta(1,32,0,Math.PI),Fd=new ui(1,1,Nn),ne=new ge,Be=new ge,Wa=new B;class n1{constructor(){F(this,"domesIm",new ze(Id,il,Si));F(this,"tubesIm",new ze(Pd,il,Si));F(this,"crownsIm",new ze(Dd,Io,Si));F(this,"ringsIm",new ze(Fd,Io,Si));F(this,"platesIm",new ze(Ld,Io,Si));F(this,"faces",new e1);F(this,"hillData",[]);F(this,"springDamping",20);F(this,"springFreq",12);F(this,"animMaxTime",.5);F(this,"groundY",0);const t=new Float32Array(Si);for(let n=0;n<Si;n++)t[n]=Math.random()*Math.PI*2;const e=new Hs(t,1);Id.setAttribute("instanceOffset",e),Pd.setAttribute("instanceOffset",e),Dd.setAttribute("instanceOffset",e),Fd.setAttribute("instanceOffset",e),Ld.setAttribute("instanceOffset",e),this.faces.geometry.setAttribute("instanceOffset",e)}clear(){for(const t of this.instancedMeshes)t.count=0;this.hillData.length=0}addRandomHills(t){const[e,n,i,r,o,a]=t.bounds;this.groundY=n;const c=e+r/2,l=i+a/2;for(let h=0;h<Si;h++){const d=500+(2*Math.random()-1)*20,u=Math.random()*Ou,m=50+Math.random()*200,x=20+10*Math.floor(Math.random()*2),g=c+d*Math.cos(u),p=l+d*Math.sin(u);this.addHill(g,p,x,m)}}update(t,e){Wa.copy(t.position);const n=t.position.distanceTo(e),i=new B,r=this.instancedMeshes[0].count;for(let o=0;o<r;o++){const a=this.hillData[o];if(!a)continue;i.set(a.x,a.height/2,a.z);const l=t.position.distanceTo(i)>=n,h=performance.now();l?(a.animState==="hidden"||a.animState==="hiding")&&(a.animState="showing",a.animStart=h):(a.animState==="shown"||a.animState==="showing")&&(a.animState="hiding",a.animStart=h);let d=0;const u=a.height+a.radius+10;if(a.animState==="hidden")d=1e7;else if(a.animState==="shown")d=0;else{const p=(h-a.animStart)/1e3,f=this.springDamping,M=this.springFreq,_=1-Math.exp(-f*p)*Math.cos(M*p);if(a.animState==="showing")d=u*(1-_),p>this.animMaxTime&&(a.animState="shown",d=0);else if(a.animState==="hiding"){const v=Math.exp(-f*p)*Math.cos(M*p);d=u*(1-v),p>this.animMaxTime*.5&&(a.animState="hidden",d=u)}}ne.position.set(a.x,a.height/2-d-Rd,a.z),ne.scale.set(a.radius,a.height,a.radius),ne.updateMatrix(),this.tubesIm.setMatrixAt(o,ne.matrix);const m=a.radius+Nn;ne.scale.set(2*m,a.height+2*Nn,2*m),ne.updateMatrix(),this.platesIm.setMatrixAt(o,ne.matrix);const x=a.height-d-Rd;ne.position.set(a.x,x,a.z),ne.scale.set(a.radius,a.radius,a.radius),ne.updateMatrix(),this.domesIm.setMatrixAt(o,ne.matrix);const g=a.radius+Nn;ne.scale.set(g,g,g),ne.updateMatrix(),this.crownsIm.setMatrixAt(o,ne.matrix),ne.position.setY(Math.min(x,this.groundY+Nn/2)),ne.scale.setY(1),ne.updateMatrix(),this.ringsIm.setMatrixAt(o,ne.matrix),this.crownsIm.getMatrixAt(o,Be.matrix),Be.matrix.decompose(Be.position,Be.quaternion,Be.scale),Be.lookAt(t.position),Be.updateMatrix(),this.crownsIm.setMatrixAt(o,Be.matrix),this.platesIm.getMatrixAt(o,Be.matrix),Be.matrix.decompose(Be.position,Be.quaternion,Be.scale),Wa.set(t.position.x,Be.position.y,t.position.z),Be.lookAt(Wa),Be.updateMatrix(),this.platesIm.setMatrixAt(o,Be.matrix)}this.faces.positionFaces(this.tubesIm,t);for(const o of this.instancedMeshes)o.instanceMatrix.needsUpdate=!0}addHill(t,e,n,i){const r=this.instancedMeshes[0].count;this.faces.addFace();for(const c of this.instancedMeshes)c.count=r+1;this.hillData[r]={x:t,z:e,radius:n,height:i,animState:"shown",animStart:performance.now()},ne.position.set(t,i/2,e),ne.scale.set(n,i,n),ne.updateMatrix(),this.tubesIm.setMatrixAt(r,ne.matrix),ne.scale.set(2*(n+Nn),i+2*Nn,2*(n+Nn)),ne.updateMatrix(),this.platesIm.setMatrixAt(r,ne.matrix);const o=i;ne.position.set(t,i,e),ne.scale.set(n,n,n),ne.updateMatrix(),this.domesIm.setMatrixAt(r,ne.matrix);const a=n+Nn;ne.scale.set(a,a,a),ne.updateMatrix(),this.crownsIm.setMatrixAt(r,ne.matrix),ne.position.setY(Math.max(o,this.groundY+Nn/2)),ne.scale.setY(1),ne.updateMatrix(),this.ringsIm.setMatrixAt(r,ne.matrix)}get instancedMeshes(){return[this.domesIm,this.tubesIm,this.crownsIm,this.ringsIm,this.platesIm,this.faces.im]}}let Ud=!1;class i1{constructor(){F(this,"renderer");F(this,"scene");F(this,"camera");F(this,"boxes");F(this,"faces");F(this,"hills");F(this,"clouds");if(Ud)throw new Error("Graphics constructed multiple times");Ud=!0,this.renderer=new C_({logarithmicDepthBuffer:!0}),this.renderer.setPixelRatio(window.devicePixelRatio),this.renderer.setSize(window.innerWidth,window.innerHeight),document.body.appendChild(this.renderer.domElement),this.camera=new Iv(this.renderer.domElement),this.scene=new Pp,this.scene.background=new se(R_),this.boxes=new Qc,this.faces=new tv,this.hills=new n1,this.clouds=new Vv}draw(){xr.mesh.visible=this.camera.cameraDist>1e3||this.camera.camera.position.y>xr.mesh.position.y,this.hills.update(this.camera.camera,this.camera.controls.target),this.clouds.update(this.camera.camera,this.camera.controls.target),this.renderer.render(this.scene,this.camera.camera)}onResize(){this.renderer.setSize(window.innerWidth,window.innerHeight),this.renderer.setPixelRatio(window.devicePixelRatio),this.camera.onResize(),is.hideAll()}reset(t){this.scene.clear(),this.hills.clear(),this.clouds.clear(),this.boxes.clear(),this.faces.clear(),xr.reset(t),this.scene.add(xr.mesh),this.hills.addRandomHills(t),this.scene.add(...this.hills.instancedMeshes),this.clouds.addRandomClouds(t),this.scene.add(...this.clouds.instancedMeshes),this.scene.add(...this.boxes.instancedMeshes),this.scene.add(this.faces.im),this.camera.reset(t);const[e,n,i,r,o,a]=t.bounds;for(const[c,l]of t.boxes.entries()){const[h,d,u,m,x,g]=l;this.boxes.addBox([h,o-d-x,u,m,x,g]);const p=c===t.targetBoxIndex?Du:sa;this.boxes.setColorAt(c,p),this.faces.addFace(this.boxes.boxes[c],"N")}this.boxes.updateColors()}}function s1(){return new Gn({side:Ke,depthTest:!0,depthWrite:!1,uniforms:{skyColor:{value:[.12,.15,.45]},noiseOffset:{value:new zt(0,0)},resolution:{value:new zt(1,1)},noiseScale:{value:2.5},noiseStrength:{value:.2},noiseExtra:{value:new zt(0,0)},posterizeLevels:{value:6}},vertexShader:`
      void main() {
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,fragmentShader:`
      precision highp float;
      uniform vec2 resolution;
      uniform vec2 noiseOffset;
      uniform vec2 noiseExtra; // two additional dimensions to morph noise
      uniform vec3 skyColor;
      uniform float noiseScale;
      uniform float noiseStrength;
      uniform float posterizeLevels;

      // Scalar hash: maps a 2D point to a repeatable pseudo-random float in [-1,1].
      float hash2(vec2 p) {
        return -1.0 + 2.0 * fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }

      // 4D hash in [-1,1]
      float hash4(vec4 p) {
        return -1.0 + 2.0 * fract(sin(dot(p, vec4(127.1, 311.7, 74.7, 192.5))) * 43758.5453123);
      }

      // Classic value noise in 4D with smoothstep-like fade (same as 2D but extended).
      float noise4(vec4 p) {
        vec4 i = floor(p);
        vec4 f = fract(p);
        vec4 u = f * f * (3.0 - 2.0 * f);

        // Mix along x for all 8 yz w corners
        float n0000 = mix(hash4(i + vec4(0.0,0.0,0.0,0.0)), hash4(i + vec4(1.0,0.0,0.0,0.0)), u.x);
        float n0100 = mix(hash4(i + vec4(0.0,1.0,0.0,0.0)), hash4(i + vec4(1.0,1.0,0.0,0.0)), u.x);
        float n0010 = mix(hash4(i + vec4(0.0,0.0,1.0,0.0)), hash4(i + vec4(1.0,0.0,1.0,0.0)), u.x);
        float n0110 = mix(hash4(i + vec4(0.0,1.0,1.0,0.0)), hash4(i + vec4(1.0,1.0,1.0,0.0)), u.x);
        float n0001 = mix(hash4(i + vec4(0.0,0.0,0.0,1.0)), hash4(i + vec4(1.0,0.0,0.0,1.0)), u.x);
        float n0101 = mix(hash4(i + vec4(0.0,1.0,0.0,1.0)), hash4(i + vec4(1.0,1.0,0.0,1.0)), u.x);
        float n0011 = mix(hash4(i + vec4(0.0,0.0,1.0,1.0)), hash4(i + vec4(1.0,0.0,1.0,1.0)), u.x);
        float n0111 = mix(hash4(i + vec4(0.0,1.0,1.0,1.0)), hash4(i + vec4(1.0,1.0,1.0,1.0)), u.x);

        // Mix along y
        float ny000 = mix(n0000, n0100, u.y);
        float ny010 = mix(n0010, n0110, u.y);
        float ny001 = mix(n0001, n0101, u.y);
        float ny011 = mix(n0011, n0111, u.y);

        // Mix along z
        float nz00 = mix(ny000, ny010, u.z);
        float nz01 = mix(ny001, ny011, u.z);

        // Mix along w
        return mix(nz00, nz01, u.w);
      }

      void main() {
        vec2 uv = gl_FragCoord.xy / resolution.xy; // 0..1
        // Compose 4D point: visible (x,y) plus hidden (z,w) drives morphology.
        vec4 p4 = vec4(uv * noiseScale, noiseExtra.x, noiseExtra.y);
        float n = noise4(p4) * 0.5 + 0.5; // 0..1 smooth
        vec3 color = skyColor + (n - 0.5) * noiseStrength; // subtle variation around base
        color = clamp(color, 0.0, 1.0);
        // Posterize per channel
        float levels = max(2.0, posterizeLevels);
        color = floor(color * levels) / levels;
        gl_FragColor = vec4(color, 1.0);
      }
    `})}const r1=s1(),o1=new un(1e3,1e3,1e3),a1=new sn(o1,r1);a1.renderOrder=-1;new Path2D(`
    
    M224 32c-17.7 0-32 14.3-32 32L96 64C78.3 64 64 78.3 64 96s14.3 32 32 32l96 0 0 
    64-18.7 0c-8.5 0-16.6 3.4-22.6 9.4L128 224 32 224c-17.7 0-32 14.3-32 32l0 64c0 
    17.7 14.3 32 32 32l100.1 0c20.2 29 53.9 48 91.9 48s71.7-19 91.9-48l36.1 0c17.7 
    0 32 14.3 32 32s14.3 32 32 32l64 0c17.7 0 32-14.3 32-32 0-88.4-71.6-160-160-160l-32 
    0-22.6-22.6c-6-6-14.1-9.4-22.6-9.4l-18.7 0 0-64 96 0c17.7 0 32-14.3 
    32-32s-14.3-32-32-32l-96 0c0-17.7-14.3-32-32-32zM436.8 455.4l-18.2 42.4c-1.8 
    4.1-2.7 8.6-2.7 13.1l0 1.2c0 17.7 14.3 32 32 
    32s32-14.3 32-32l0-1.2c0-4.5-.9-8.9-2.7-13.1l-18.2-42.4c-1.9-4.5-6.3-7.4-11.2-7.4s-9.2 2.9-11.2 7.4z
    
    
    `),new Path2D(`

    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 168.3C277.6
     109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 259.3 530.7 184.3 
     455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 412.9C98.8 422.4 94.4 
     442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 501C601 401 601 239 501
      139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 78.8 65.8C69.8 69.5 64 78.3 
      64 88L64 232C64 245.3 74.7 256 88 256z
  
  
      `),new Path2D(`

    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 168.3C362.4
     109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 380.7 530.7 455.7
      455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 421.7C536.7 431.8 540.2
       451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 139 501C39.1 401 39 239 139 
       139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 62.1 561.2 65.8C570.2 69.5 576 
       78.3 576 88L576 232C576 245.3 565.3 256 552 256z

  
      `),new Path2D(`


    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z

  
  
      `),new Path2D(`
    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 
    168.3C277.6 109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 
    259.3 530.7 184.3 455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 
    412.9C98.8 422.4 94.4 442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 
    501C601 401 601 239 501 139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 
    78.8 65.8C69.8 69.5 64 78.3 64 88L64 232C64 245.3 74.7 256 88 256z
  `),new Path2D(`
    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z
  `),new Path2D(`
    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 
    168.3C362.4 109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 
    380.7 530.7 455.7 455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 
    421.7C536.7 431.8 540.2 451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 
    139 501C39.1 401 39 239 139 139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 
    62.1 561.2 65.8C570.2 69.5 576 78.3 576 88L576 232C576 245.3 565.3 256 552 256z
  `),new Path2D(`
        M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 
        550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 
        85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320
        480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 
        288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 
        257.7C352.5 239.5 338.1 224 319.8 224z
    `),new Path2D(`
        M480 96C515.3 96 544 124.7 544 160L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 
        515.3 96 480L96 160C96 124.7 124.7 96 160 96L480 96zM438 209.7C427.3 201.9 412.3 204.3 404.5 
        215L285.1 379.2L233 327.1C223.6 317.7 208.4 317.7 199.1 327.1C189.8 336.5 189.7 351.7 199.1 
        361L271.1 433C276.1 438 283 440.5 289.9 440C296.8 439.5 303.3 435.9 307.4 430.2L443.3 243.2C451.1 
        232.5 448.7 217.5 438 209.7z
    `),new Path2D(`

      M259.1 73.5C262.1 58.7 275.2 48 290.4 48L350.2 48C365.4 48 378.5 58.7 381.5 73.5L396 143.5C410.1
       149.5 423.3 157.2 435.3 166.3L503.1 143.8C517.5 139 533.3 145 540.9 158.2L570.8 210C578.4 223.2
        575.7 239.8 564.3 249.9L511 297.3C511.9 304.7 512.3 312.3 512.3 320C512.3 327.7 511.8 335.3 511
         342.7L564.4 390.2C575.8 400.3 578.4 417 570.9 430.1L541 481.9C533.4 495 517.6 501.1 503.2 
         496.3L435.4 473.8C423.3 482.9 410.1 490.5 396.1 496.6L381.7 566.5C378.6 581.4 365.5 592 350.4
          592L290.6 592C275.4 592 262.3 581.3 259.3 566.5L244.9 496.6C230.8 490.6 217.7 482.9 205.6
           473.8L137.5 496.3C123.1 501.1 107.3 495.1 99.7 481.9L69.8 430.1C62.2 416.9 64.9 400.3 76.3
            390.2L129.7 342.7C128.8 335.3 128.4 327.7 128.4 320C128.4 312.3 128.9 304.7 129.7 297.3L76.3
             249.8C64.9 239.7 62.3 223 69.8 209.9L99.7 158.1C107.3 144.9 123.1 138.9 137.5 143.7L205.3 
             166.2C217.4 157.1 230.6 149.5 244.6 143.4L259.1 73.5zM320.3 400C364.5 399.8 400.2 363.9 400
              319.7C399.8 275.5 363.9 239.8 319.7 240C275.5 240.2 239.8 276.1 240 320.3C240.2 364.5 276.1
               400.2 320.3 400z

      
    `),new Path2D(`


      M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 
      160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 
      48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576
       197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z
      
    `),new Path2D(`

      M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 
      224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4
       106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 
       379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 
       95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 
       302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 
       192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576
        337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 
        448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 
        440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 
        440 128 440z

      
    `),new Path2D(`

      M504.6 148.5C515.9 134.9 514.1 114.7 500.5 103.4C486.9 92.1 466.7 93.9 455.4 107.5L320 270L184.6
       107.5C173.3 93.9 153.1 92.1 139.5 103.4C125.9 114.7 124.1 134.9 135.4 148.5L278.3 320L135.4
        491.5C124.1 505.1 125.9 525.3 139.5 536.6C153.1 547.9 173.3 546.1 184.6 532.5L320 370L455.4
         532.5C466.7 546.1 486.9 547.9 500.5 536.6C514.1 525.3 515.9 505.1 504.6 491.5L361.7 320L504.6 148.5z

      
    `),new Path2D(`


      M173.3 66.5C181.4 62.4 191.2 63.3 198.4 68.8L518.4 308.7C526.7 314.9 530 325.7 
      526.8 335.5C523.6 345.3 514.4 351.9 504 351.9L351.7 351.9L440.6 529.6C448.5
       545.4 442.1 564.6 426.3 572.5C410.5 580.4 391.3 574 383.4 558.2L294.5 380.5L203.2 
       502.3C197 510.6 186.2 513.9 176.4 510.7C166.6 507.5 160 498.3 160 488L160
        88C160 78.9 165.1 70.6 173.3 66.5z
      
    `);const c1={screen:{},_outerMargin:{parent:"screen",margin:()=>Re.flatConfig.outerMargin},topLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight},bottomLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},saveButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,bottom:0},addButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},removeButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,top:0},setTargetButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:"auto",top:0}},l1={layoutKey:"topLabel",display:{type:"panel",label:"Edit Tower",textAlign:"left",styles:{border:"none"}}},h1={layoutKey:"addButton",display:{type:"button",label:"Add Block"},click:({towerToppler:s})=>{s.editorAddClicked()}},d1={layoutKey:"setTargetButton",display:{type:"button",label:"Set Block"},click:({towerToppler:s})=>{s.editorSetTargetClicked()}},Yu={layoutKey:"removeButton",display:{type:"button",label:"Remove Block"},click:({towerToppler:s})=>{s.editorRemoveClicked()}},u1={layoutKey:"saveButton",display:{type:"button",label:"Save Level"},click:({towerToppler:s})=>{s.editorSaveClicked()}},Wl=class Wl extends fn{};fn.register("editor-gui",{factory:()=>new Wl,layoutFactory:()=>c1,elements:[l1,d1,h1,Yu,u1]});let Nd=Wl;class f1 extends fn{constructor(){super(...arguments);F(this,"_isShowing",!1)}get isShowing(){return this._isShowing}toggle(e,n){typeof n=="boolean"?this._isShowing=n:this._isShowing=!this._isShowing;for(const i in this.elements)this._isShowing?(this.elements[i].display.classes??[]).includes("hidden")||rs(i):Pi(i);this._isShowing&&this.refreshLayout(e),this.onToggle(e)}}const Xa={NAMES:["playing-gui","editor-gui"]};function p1(s){const t={N:co(s,"N"),S:co(s,"S"),E:co(s,"E"),W:co(s,"W")};return{bounds:s.bounds,boxes:s.boxes,targetBoxIndex:s.targetBoxIndex,sideViews:t}}function m1(s,t,e){const n=s.boxes[t];return e==="N"||e==="S"?{width:n[3],height:n[4]}:{width:n[5],height:n[4]}}function x1(s,t,e){const n=s.boxes[t],[i,r,o,a,c,l]=s.bounds,h=n[1]+n[4]/2-c/2;return e==="N"?[n[0]+n[3]/2-a/2,h]:e==="S"?[a-(n[0]+n[3]/2)-a/2,h]:e==="W"?[n[2]+n[5]/2-l/2,h]:[l-(n[2]+n[5]/2)-l/2,h]}function g1(s,t,e){const[n,i,r,o,a,c]=s.bounds,l=s.sideViews[e][t],h=l[0]+l[2]/2,d=l[1]+l[3]/2;return[h+o/2,d+a/2]}function co(s,t){const n=t==="N"||t==="S"?2:0,i=t==="N"||t==="S"?0:2,r=1,o=t==="N"||t==="S"?3:5,a=4,c=t==="S"||t==="W",l=s.boxes.map((C,D)=>({box:C,i:D})).sort((C,D)=>{const O=C.box[n],H=D.box[n];return c?O-H:H-O});let h=Number.MAX_VALUE,d=-Number.MAX_VALUE,u=Number.MAX_VALUE,m=-Number.MAX_VALUE;for(const C of s.boxes)h=Math.min(h,C[i]),d=Math.max(d,C[i]+C[o]),u=Math.min(u,C[r]),m=Math.max(m,C[r]+C[a]);const x=Math.floor(h/10)*10+10/2,g=Math.ceil(d/10)*10-10/2,p=Math.floor(u/10)*10+10/2,f=Math.ceil(m/10)*10-10/2,M=new Map,_=new Set;for(let C=x;C<=g;C+=10)for(let D=p;D<=f;D+=10)for(const{box:O,i:H}of l){const W=O[i],$=W+O[o],G=O[r],V=G+O[a];if(C>=W&&C<=$&&D>=G&&D<=V){_.add(H);let Y=M.get(H);Y||(Y=new Set,M.set(H,Y));const st=Math.round((C-10/2)/10),St=Math.round((D-10/2)/10);Y.add(`${st}|${St}`);break}}const v={},[b,S,T,P,A,E]=s.bounds;for(const C of _){const D=M.get(C);if(!D||D.size===0)continue;let O=Number.MAX_VALUE,H=-Number.MAX_VALUE,W=Number.MAX_VALUE,$=-Number.MAX_VALUE;for(const Z of D){const[Q,ut]=Z.split("|"),Lt=parseInt(Q,10),yt=parseInt(ut,10);O=Math.min(O,Lt),H=Math.max(H,Lt),W=Math.min(W,yt),$=Math.max($,yt)}const G=O*10,V=(H+1)*10,Y=W*10,st=($+1)*10,St=V-G,kt=st-Y;let qt;t==="N"?qt=G-P/2:t==="S"?qt=P-V-P/2:t==="W"?qt=G-E/2:qt=E-V-E/2;const ce=-A/2,le=Y+ce;v[C]=[qt,le,St,kt]}return v}function _1(s){return{getSetting:t=>Ds.flatConfig[t],applySetting:(t,e)=>{t in Ds.tree.children&&(Ds.tree.children[t].value=e),Ds.flatConfig[t]=e},getGameState:()=>"playing",getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.cursorForTestSupport}),locateElement(t){const e=[fn.create("playing-gui")];for(const n of e){const i=n.layoutRectangles[t];if(!i)continue;const[r,o,a,c]=i,l=1;return[r*l,o*l,a*l,c*l]}}}}class v1{constructor(){F(this,"levelIndex",0);F(this,"isFlat",!1);F(this,"flatDirection","N");F(this,"isEditor",!1);F(this,"removedBlockIndex",-1);F(this,"isActive",!1);F(this,"activeTime",0);F(this,"isToppled",!1);F(this,"isFailed",!1)}startLevel(){this.isActive=!1,this.isToppled=!1,this.activeTime=0,this.removedBlockIndex=-1}passLevel(){this.isToppled=!0}failLevel(){this.isFailed=!0}startActive(t){this.isActive=!0,this.activeTime=0,this.isToppled=!1,this.isFailed=!1,this.removedBlockIndex=t}}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class kn{constructor(t,e,n,i,r="div"){this.parent=t,this.object=e,this.property=n,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(r),this.domElement.classList.add("controller"),this.domElement.classList.add(i),this.$name=document.createElement("div"),this.$name.classList.add("name"),kn.nextNameID=kn.nextNameID||0,this.$name.id=`lil-gui-name-${++kn.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",o=>o.stopPropagation()),this.domElement.addEventListener("keyup",o=>o.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(n)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class b1 extends kn{constructor(t,e,n){super(t,e,n,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function rl(s){let t,e;return(t=s.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=s.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=s.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const M1={isPrimitive:!0,match:s=>typeof s=="string",fromHexString:rl,toHexString:rl},Cr={isPrimitive:!0,match:s=>typeof s=="number",fromHexString:s=>parseInt(s.substring(1),16),toHexString:s=>"#"+s.toString(16).padStart(6,0)},S1={isPrimitive:!1,match:s=>Array.isArray(s),fromHexString(s,t,e=1){const n=Cr.fromHexString(s);t[0]=(n>>16&255)/255*e,t[1]=(n>>8&255)/255*e,t[2]=(n&255)/255*e},toHexString([s,t,e],n=1){n=255/n;const i=s*n<<16^t*n<<8^e*n<<0;return Cr.toHexString(i)}},y1={isPrimitive:!1,match:s=>Object(s)===s,fromHexString(s,t,e=1){const n=Cr.fromHexString(s);t.r=(n>>16&255)/255*e,t.g=(n>>8&255)/255*e,t.b=(n&255)/255*e},toHexString({r:s,g:t,b:e},n=1){n=255/n;const i=s*n<<16^t*n<<8^e*n<<0;return Cr.toHexString(i)}},E1=[M1,Cr,S1,y1];function A1(s){return E1.find(t=>t.match(s))}class w1 extends kn{constructor(t,e,n,i){super(t,e,n,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=A1(this.initialValue),this._rgbScale=i,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const r=rl(this.$text.value);r&&this._setValueFromHexString(r)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class qa extends kn{constructor(t,e,n){super(t,e,n,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",i=>{i.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class T1 extends kn{constructor(t,e,n,i,r,o){super(t,e,n,"number"),this._initInput(),this.min(i),this.max(r);const a=o!==void 0;this.step(a?o:this._getImplicitStep(),a),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let M=parseFloat(this.$input.value);isNaN(M)||(this._stepExplicit&&(M=this._snap(M)),this.setValue(this._clamp(M)))},n=M=>{const _=parseFloat(this.$input.value);isNaN(_)||(this._snapClampSetValue(_+M),this.$input.value=this.getValue())},i=M=>{M.key==="Enter"&&this.$input.blur(),M.code==="ArrowUp"&&(M.preventDefault(),n(this._step*this._arrowKeyMultiplier(M))),M.code==="ArrowDown"&&(M.preventDefault(),n(this._step*this._arrowKeyMultiplier(M)*-1))},r=M=>{this._inputFocused&&(M.preventDefault(),n(this._step*this._normalizeMouseWheel(M)))};let o=!1,a,c,l,h,d;const u=5,m=M=>{a=M.clientX,c=l=M.clientY,o=!0,h=this.getValue(),d=0,window.addEventListener("mousemove",x),window.addEventListener("mouseup",g)},x=M=>{if(o){const _=M.clientX-a,v=M.clientY-c;Math.abs(v)>u?(M.preventDefault(),this.$input.blur(),o=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(_)>u&&g()}if(!o){const _=M.clientY-l;d-=_*this._step*this._arrowKeyMultiplier(M),h+d>this._max?d=this._max-h:h+d<this._min&&(d=this._min-h),this._snapClampSetValue(h+d)}l=M.clientY},g=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",x),window.removeEventListener("mouseup",g)},p=()=>{this._inputFocused=!0},f=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",i),this.$input.addEventListener("wheel",r,{passive:!1}),this.$input.addEventListener("mousedown",m),this.$input.addEventListener("focus",p),this.$input.addEventListener("blur",f)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(f,M,_,v,b)=>(f-M)/(_-M)*(b-v)+v,e=f=>{const M=this.$slider.getBoundingClientRect();let _=t(f,M.left,M.right,this._min,this._max);this._snapClampSetValue(_)},n=f=>{this._setDraggingStyle(!0),e(f.clientX),window.addEventListener("mousemove",i),window.addEventListener("mouseup",r)},i=f=>{e(f.clientX)},r=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",i),window.removeEventListener("mouseup",r)};let o=!1,a,c;const l=f=>{f.preventDefault(),this._setDraggingStyle(!0),e(f.touches[0].clientX),o=!1},h=f=>{f.touches.length>1||(this._hasScrollBar?(a=f.touches[0].clientX,c=f.touches[0].clientY,o=!0):l(f),window.addEventListener("touchmove",d,{passive:!1}),window.addEventListener("touchend",u))},d=f=>{if(o){const M=f.touches[0].clientX-a,_=f.touches[0].clientY-c;Math.abs(M)>Math.abs(_)?l(f):(window.removeEventListener("touchmove",d),window.removeEventListener("touchend",u))}else f.preventDefault(),e(f.touches[0].clientX)},u=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",d),window.removeEventListener("touchend",u)},m=this._callOnFinishChange.bind(this),x=400;let g;const p=f=>{if(Math.abs(f.deltaX)<Math.abs(f.deltaY)&&this._hasScrollBar)return;f.preventDefault();const _=this._normalizeMouseWheel(f)*this._step;this._snapClampSetValue(this.getValue()+_),this.$input.value=this.getValue(),clearTimeout(g),g=setTimeout(m,x)};this.$slider.addEventListener("mousedown",n),this.$slider.addEventListener("touchstart",h,{passive:!1}),this.$slider.addEventListener("wheel",p,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:n}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,n=-t.wheelDelta/120,n*=this._stepExplicit?1:10),e+-n}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class C1 extends kn{constructor(t,e,n,i){super(t,e,n,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(i)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const n=document.createElement("option");n.textContent=e,this.$select.appendChild(n)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class R1 extends kn{constructor(t,e,n){super(t,e,n,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",i=>{i.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var P1=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function L1(s){const t=document.createElement("style");t.innerHTML=s;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let Od=!1;class Il{constructor({parent:t,autoPlace:e=t===void 0,container:n,width:i,title:r="Controls",closeFolders:o=!1,injectStyles:a=!0,touchStyles:c=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(r),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),c&&this.domElement.classList.add("allow-touch-styles"),!Od&&a&&(L1(P1),Od=!0),n?n.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),i&&this.domElement.style.setProperty("--width",i+"px"),this._closeFolders=o}add(t,e,n,i,r){if(Object(n)===n)return new C1(this,t,e,n);const o=t[e];switch(typeof o){case"number":return new T1(this,t,e,n,i,r);case"boolean":return new b1(this,t,e);case"string":return new R1(this,t,e);case"function":return new qa(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,o)}addColor(t,e,n=1){return new w1(this,t,e,n)}addFolder(t){const e=new Il({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(n=>{n instanceof qa||n._name in t.controllers&&n.load(t.controllers[n._name])}),e&&t.folders&&this.folders.forEach(n=>{n._title in t.folders&&n.load(t.folders[n._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(n=>{if(!(n instanceof qa)){if(n._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${n._name}"`);e.controllers[n._name]=n.save()}}),t&&this.folders.forEach(n=>{if(n._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${n._title}"`);e.folders[n._title]=n.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const n=r=>{r.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",n))};this.$children.addEventListener("transitionend",n);const i=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=i+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(n=>n.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let ol={},$i;function I1(s){const t=V_.tree;ol={},$i&&$i.destroy(),$i=new Il({closeFolders:!0,container:document.getElementById("controls-container")}),$u($i,t,s),$i.onOpenClose(()=>{$i._closed&&setTimeout(()=>{$i.destroy()},200)})}function $u(s,t,e){const n=t.children;for(const i in n){const r=n[i];if(!("isHidden"in r&&r.isHidden))if("action"in r){const o=r,a=r.label??lo(i),c={[a]:async()=>{await o.action(e)}};s.add(c,a)}else if("options"in r&&Array.isArray(r.options)){const o=r,a={};for(const l of o.options)typeof l=="string"&&(a[l]=l);const c=s.add(o,"value",a).name(o.label??lo(i)).listen();c.onChange(l=>{o.value=l,o.onChange&&o.onChange(e,l)}),Ya(c,o.tooltip),ol[i]=c}else if("value"in r&&typeof r.value=="number"){const o=r,a=s.add(o,"value",o.min,o.max).name(o.label??lo(i));o.step&&a.step(o.step),a.onChange(c=>{typeof c=="number"&&(o.value=c,o.onChange&&o.onChange(e,c))}),Ya(a,o.tooltip),ol[i]=a}else{const o=s.addFolder(r.label??lo(i));Ya(o,r.tooltip),$u(o,r,e)}}}function Ya(s,t){if(typeof t!="string"||t.trim()==="")return;s.domElement.setAttribute("title",t)}function lo(s){return/^[A-Z0-9_]+$/.test(s)?s.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():s.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}const aa=typeof P2_ARRAY_TYPE<"u"?P2_ARRAY_TYPE:typeof Float32Array<"u"?Float32Array:Array,Fo=(s,t)=>{for(let e=0,n=t.length;e!==n;++e)s.push(t[e])},D1=function(s,t,e){e===void 0&&(e=1);const n=s.length-e;for(let i=t;i<n;i++)s[i]=s[i+e];s.length=n},ho=(s,t)=>{const e=s.indexOf(t);e!==-1&&D1(s,e,1)};function Hn(s,t){return s[0]*t[1]-s[1]*t[0]}function al(s,t,e){return Oe(s,t,-Math.PI/2),Ft(s,s,e),s}function Oe(s,t,e){if(e!==0){const n=Math.cos(e),i=Math.sin(e),r=t[0],o=t[1];s[0]=n*r-i*o,s[1]=i*r+n*o}else s[0]=t[0],s[1]=t[1];return s}function ts(s,t){const e=t[0],n=t[1];return s[0]=n,s[1]=-e,s}function Ni(s,t,e,n){const i=Math.cos(-n),r=Math.sin(-n),o=t[0]-e[0],a=t[1]-e[1];return s[0]=i*o-r*a,s[1]=r*o+i*a,s}function we(s,t,e,n){const i=Math.cos(n),r=Math.sin(n),o=t[0],a=t[1],c=e[0],l=e[1];s[0]=i*o-r*a+c,s[1]=r*o+i*a+l}function Ku(s,t,e){const n=Math.cos(-e),i=Math.sin(-e),r=t[0],o=t[1];return s[0]=n*r-i*o,s[1]=i*r+n*o,s}const F1=Oe;function U1(s,t,e,n){return _t(s,t,e),_t(s,s,n),Ft(s,s,1/3),s}function U(){const s=new aa(2);return s[0]=0,s[1]=0,s}function Mn(s){const t=new aa(2);return t[0]=s[0],t[1]=s[1],t}function nn(s,t){const e=new aa(2);return e[0]=s,e[1]=t,e}function Kt(s,t){return s[0]=t[0],s[1]=t[1],s}function Zt(s,t,e){return s[0]=t,s[1]=e,s}function _t(s,t,e){return s[0]=t[0]+e[0],s[1]=t[1]+e[1],s}function nt(s,t,e){return s[0]=t[0]-e[0],s[1]=t[1]-e[1],s}function qo(s,t,e){return s[0]=t[0]*e[0],s[1]=t[1]*e[1],s}function Ft(s,t,e){return s[0]=t[0]*e,s[1]=t[1]*e,s}function Dl(s,t){const e=t[0]-s[0],n=t[1]-s[1];return Math.sqrt(e*e+n*n)}function Fl(s,t){const e=t[0]-s[0],n=t[1]-s[1];return e*e+n*n}function Rr(s){const t=s[0],e=s[1];return Math.sqrt(t*t+e*e)}function yn(s){const t=s[0],e=s[1];return t*t+e*e}function be(s,t){const e=t[0],n=t[1];let i=e*e+n*n;return i>0&&(i=1/Math.sqrt(i),s[0]=t[0]*i,s[1]=t[1]*i),s}function ae(s,t){return s[0]*t[0]+s[1]*t[1]}function _r(s,t,e,n){const i=t[0],r=t[1];return s[0]=i+n*(e[0]-i),s[1]=r+n*(e[1]-r),s}function N1(s,t,e,n){const i=t[0]-s[0],r=t[1]-s[1],o=n[0]-e[0],a=n[1]-e[1],c=(-r*(s[0]-e[0])+i*(s[1]-e[1]))/(-o*r+i*a),l=(o*(s[1]-e[1])-a*(s[0]-e[0]))/(-o*r+i*a);return c>=0&&c<=1&&l>=0&&l<=1?l:-1}class Ul{constructor(t){t===void 0&&(t={}),this.lowerBound=t.lowerBound?Mn(t.lowerBound):U(),this.upperBound=t.upperBound?Mn(t.upperBound):U()}setFromPoints(t,e,n,i){n===void 0&&(n=0),i===void 0&&(i=0);const r=this.lowerBound,o=this.upperBound;n!==0?Oe(r,t[0],n):Kt(r,t[0]),Kt(o,r);const a=Math.cos(n),c=Math.sin(n);for(let l=1;l<t.length;l++){let h=t[l];if(n!==0){const d=h[0],u=h[1];$a[0]=a*d-c*u,$a[1]=c*d+a*u,h=$a}for(let d=0;d<2;d++)h[d]>o[d]&&(o[d]=h[d]),h[d]<r[d]&&(r[d]=h[d])}e&&(_t(r,r,e),_t(o,o,e)),i&&(r[0]-=i,r[1]-=i,o[0]+=i,o[1]+=i)}copy(t){Kt(this.lowerBound,t.lowerBound),Kt(this.upperBound,t.upperBound)}extend(t){const e=this.lowerBound,n=this.upperBound;let i=2;for(;i--;){const r=t.lowerBound[i];e[i]>r&&(e[i]=r);const o=t.upperBound[i];n[i]<o&&(n[i]=o)}}overlaps(t){const e=this.lowerBound,n=this.upperBound,i=t.lowerBound,r=t.upperBound;return(i[0]<=n[0]&&n[0]<=r[0]||e[0]<=r[0]&&r[0]<=n[0])&&(i[1]<=n[1]&&n[1]<=r[1]||e[1]<=r[1]&&r[1]<=n[1])}containsPoint(t){const e=this.lowerBound,n=this.upperBound;return e[0]<=t[0]&&t[0]<=n[0]&&e[1]<=t[1]&&t[1]<=n[1]}overlapsRay(t){const e=1/t.direction[0],n=1/t.direction[1],i=t.from,r=this.lowerBound,o=this.upperBound,a=(r[0]-i[0])*e,c=(o[0]-i[0])*e,l=(r[1]-i[1])*n,h=(o[1]-i[1])*n,d=Math.max(Math.max(Math.min(a,c),Math.min(l,h))),u=Math.min(Math.min(Math.max(a,c),Math.max(l,h)));return u<0||d>u?-1:d/t.length}}const $a=U(),O1=[0,0],B1=[0,0],z1=[[0,0],[0,0]],V1=[[0,0],[0,0]];function k1(s,t,e){e===void 0&&(e=0),e=e||0;const n=[0,0],i=s[1][1]-s[0][1],r=s[0][0]-s[1][0],o=i*s[0][0]+r*s[0][1],a=t[1][1]-t[0][1],c=t[0][0]-t[1][0],l=a*t[0][0]+c*t[0][1],h=i*c-a*r;return Qu(h,0,e)||(n[0]=(c*o-r*l)/h,n[1]=(i*l-a*o)/h),n}function cl(s,t,e,n){const i=t[0]-s[0],r=t[1]-s[1],o=n[0]-e[0],a=n[1]-e[1];if(o*r-a*i===0)return!1;const c=(i*(e[1]-s[1])+r*(s[0]-e[0]))/(o*r-a*i),l=(o*(s[1]-e[1])+a*(e[0]-s[0]))/(a*i-o*r);return c>=0&&c<=1&&l>=0&&l<=1}function Fr(s,t,e){return(t[0]-s[0])*(e[1]-s[1])-(e[0]-s[0])*(t[1]-s[1])}function Uo(s,t,e){return Fr(s,t,e)>0}function ll(s,t,e){return Fr(s,t,e)>=0}function Zu(s,t,e){return Fr(s,t,e)<0}function vr(s,t,e){return Fr(s,t,e)<=0}function G1(s,t,e,n){if(n===void 0&&(n=0),n){const i=O1,r=B1;i[0]=t[0]-s[0],i[1]=t[1]-s[1],r[0]=e[0]-t[0],r[1]=e[1]-t[1];const o=i[0]*r[0]+i[1]*r[1],a=Math.sqrt(i[0]*i[0]+i[1]*i[1]),c=Math.sqrt(r[0]*r[0]+r[1]*r[1]);return Math.acos(o/(a*c))<n}else return Fr(s,t,e)===0}function br(s,t){const e=t[0]-s[0],n=t[1]-s[1];return e*e+n*n}function mt(s,t){const e=s.length;return s[t<0?t%e+e:t%e]}function H1(s){s.length=0}function gn(s,t,e,n){for(let i=e;i<n;i++)s.push(t[i])}function W1(s){let t=0;const e=s;for(let n=1;n<s.length;++n)(e[n][1]<e[t][1]||e[n][1]===e[t][1]&&e[n][0]>e[t][0])&&(t=n);return Uo(mt(s,t-1),mt(s,t),mt(s,t+1))?!1:(X1(s),!0)}function X1(s){const t=[],e=s.length;for(let n=0;n!==e;n++)t.push(s.pop());for(let n=0;n!==e;n++)s[n]=t[n]}function ju(s,t){return Zu(mt(s,t-1),mt(s,t),mt(s,t+1))}function q1(s,t,e){const n=z1,i=V1;if(ll(mt(s,t+1),mt(s,t),mt(s,e))&&vr(mt(s,t-1),mt(s,t),mt(s,e)))return!1;const r=br(mt(s,t),mt(s,e));for(let o=0;o!==s.length;++o)if(!((o+1)%s.length===t||o===t)&&ll(mt(s,t),mt(s,e),mt(s,o+1))&&vr(mt(s,t),mt(s,e),mt(s,o))){n[0]=mt(s,t),n[1]=mt(s,e),i[0]=mt(s,o),i[1]=mt(s,o+1);const a=k1(n,i);if(br(mt(s,t),a)<r)return!1}return!0}function Y1(s,t,e){for(let n=0;n!==s.length;++n)if(!(n===t||n===e||(n+1)%s.length===t||(n+1)%s.length===e)&&cl(mt(s,t),mt(s,e),mt(s,n),mt(s,n+1)))return!1;return!0}function Yo(s,t,e,n){if(n===void 0&&(n=[]),H1(n),t<e)for(let i=t;i<=e;i++)n.push(s[i]);else{for(let i=0;i<=e;i++)n.push(s[i]);for(let i=t;i<s.length;i++)n.push(s[i])}return n}function hl(s){let t=[],e,n;const i=[];let r=Number.MAX_VALUE;for(let o=0;o<s.length;++o)if(ju(s,o)){for(let a=0;a<s.length;++a)if(q1(s,o,a)){e=hl(Yo(s,o,a,i)),n=hl(Yo(s,a,o,i));for(let c=0;c<n.length;c++)e.push(n[c]);e.length<r&&(t=e,r=e.length,t.push([mt(s,o),mt(s,a)]))}}return t}function $1(s){const t=hl(s);return t.length>0?Ju(s,t):[s]}function Ju(s,t){if(t.length===0)return[s];if(t instanceof Array&&t.length&&t[0]instanceof Array&&t[0].length===2&&t[0][0]instanceof Array){const e=[s];for(let n=0;n<t.length;n++){const i=t[n];for(let r=0;r<e.length;r++){const o=e[r],a=Ju(o,i);if(a){e.splice(r,1),e.push(a[0],a[1]);break}}}return e}else{const e=t,n=s.indexOf(e[0]),i=s.indexOf(e[1]);return n!==-1&&i!==-1?[Yo(s,n,i),Yo(s,i,n)]:!1}}function K1(s){const t=s;let e;for(e=0;e<t.length-1;e++)for(let n=0;n<e-1;n++)if(cl(t[e],t[e+1],t[n],t[n+1]))return!1;for(e=1;e<t.length-2;e++)if(cl(t[0],t[t.length-1],t[e],t[e+1]))return!1;return!0}function Bd(s,t,e,n,i){i===void 0&&(i=0);const r=t[1]-s[1],o=s[0]-t[0],a=r*s[0]+o*s[1],c=n[1]-e[1],l=e[0]-n[0],h=c*e[0]+l*e[1],d=r*l-c*o;return Qu(d,0,i)?[0,0]:[(l*a-o*h)/d,(r*h-c*a)/d]}function gr(s,t,e,n,i,r,o){t===void 0&&(t=[]),e===void 0&&(e=[]),n===void 0&&(n=[]),i===void 0&&(i=25),r===void 0&&(r=100),o===void 0&&(o=0);let a=[0,0],c=[0,0],l=[0,0],h=0,d=0,u=0,m=0,x=0,g=0,p=0;const f=[],M=[],_=s,v=s;if(v.length<3)return t;if(o++,o>r)return console.warn("quickDecomp: max level ("+r+") reached."),t;for(let b=0;b<s.length;++b)if(ju(_,b)){e.push(_[b]),h=d=Number.MAX_VALUE;for(let S=0;S<s.length;++S)Uo(mt(_,b-1),mt(_,b),mt(_,S))&&vr(mt(_,b-1),mt(_,b),mt(_,S-1))&&(l=Bd(mt(_,b-1),mt(_,b),mt(_,S),mt(_,S-1)),Zu(mt(_,b+1),mt(_,b),l)&&(u=br(_[b],l),u<d&&(d=u,c=l,g=S))),Uo(mt(_,b+1),mt(_,b),mt(_,S+1))&&vr(mt(_,b+1),mt(_,b),mt(_,S))&&(l=Bd(mt(_,b+1),mt(_,b),mt(_,S),mt(_,S+1)),Uo(mt(_,b-1),mt(_,b),l)&&(u=br(_[b],l),u<h&&(h=u,a=l,x=S)));if(g===(x+1)%s.length)l[0]=(c[0]+a[0])/2,l[1]=(c[1]+a[1])/2,n.push(l),b<x?(gn(f,_,b,x+1),f.push(l),M.push(l),g!==0&&gn(M,_,g,_.length),gn(M,_,0,b+1)):(b!==0&&gn(f,_,b,_.length),gn(f,_,0,x+1),f.push(l),M.push(l),gn(M,_,g,b+1));else{if(g>x&&(x+=s.length),m=Number.MAX_VALUE,x<g)return t;for(let S=g;S<=x;++S)ll(mt(_,b-1),mt(_,b),mt(_,S))&&vr(mt(_,b+1),mt(_,b),mt(_,S))&&(u=br(mt(_,b),mt(_,S)),u<m&&Y1(_,b,S)&&(m=u,p=S%s.length));b<p?(gn(f,_,b,p+1),p!==0&&gn(M,_,p,v.length),gn(M,_,0,b+1)):(b!==0&&gn(f,_,b,v.length),gn(f,_,0,p+1),gn(M,_,p,b+1))}return f.length<M.length?(gr(f,t,e,n,i,r,o),gr(M,t,e,n,i,r,o)):(gr(M,t,e,n,i,r,o),gr(f,t,e,n,i,r,o)),t}return t.push(s),t}function zd(s,t){t===void 0&&(t=0);let e=0;for(let n=s.length-1;s.length>3&&n>=0;--n)G1(mt(s,n-1),mt(s,n),mt(s,n+1),t)&&(s.splice(n%s.length,1),e++);return e}function Qu(s,t,e){return e===void 0&&(e=0),e=e||0,Math.abs(s-t)<=e}const ii=class ii{constructor(t){F(this,"direction",U());F(this,"length",1);F(this,"_currentBody",null);F(this,"_currentShape",null);t===void 0&&(t={}),this.from=t.from?Mn(t.from):U(),this.to=t.to?Mn(t.to):U(),this.checkCollisionResponse=t.checkCollisionResponse??!0,this.skipBackfaces=!!t.skipBackfaces,this.collisionMask=t.collisionMask??-1,this.collisionGroup=t.collisionGroup??-1,this.mode=t.mode??ii.ANY,this.callback=(t==null?void 0:t.callback)||function(){},this.update()}update(){const t=this.direction;nt(t,this.to,this.from),this.length=Rr(t),be(t,t)}intersectBodies(t,e){for(let n=0,i=e.length;!t.shouldStop(this)&&n<i;n++){const r=e[n],o=r.getAABB();(o.overlapsRay(this)>=0||o.containsPoint(this.from))&&this.intersectBody(t,r)}}intersectBody(t,e){const n=this.checkCollisionResponse;if(n&&!e.collisionResponse)return;const i=j1;for(let r=0,o=e.shapes.length;r<o;r++){const a=e.shapes[r];if(n&&!a.collisionResponse||(this.collisionGroup&a.collisionMask)===0||(a.collisionGroup&this.collisionMask)===0)continue;Oe(i,a.position,e.angle),_t(i,i,e.position);const c=a.angle+e.angle;if(this.intersectShape(t,a,c,i,e),t.shouldStop(this))break}}intersectShape(t,e,n,i,r){const o=this.from;Z1(o,this.direction,i)>e.boundingRadius*e.boundingRadius||(this._currentBody=r,this._currentShape=e,e.raycast(t,this,i,n),this._currentBody=this._currentShape=null)}getAABB(t){const e=this.to,n=this.from;Zt(t.lowerBound,Math.min(e[0],n[0]),Math.min(e[1],n[1])),Zt(t.upperBound,Math.max(e[0],n[0]),Math.max(e[1],n[1]))}reportIntersection(t,e,n,i){i===void 0&&(i=-1);const r=this._currentShape,o=this._currentBody;if(!(this.skipBackfaces&&ae(n,this.direction)>0))switch(this.mode){case ii.ALL:t.set(n,r,o,e,i),this.callback(t);break;case ii.CLOSEST:(e<t.fraction||!t.hasHit())&&t.set(n,r,o,e,i);break;case ii.ANY:t.set(n,r,o,e,i);break}}};F(ii,"CLOSEST",1),F(ii,"ANY",2),F(ii,"ALL",4);let Pr=ii;const Vd=U(),uo=U();function Z1(s,t,e){nt(Vd,e,s);const n=ae(Vd,t);return Ft(uo,t,n),_t(uo,uo,s),Fl(e,uo)}const j1=U();class J1{constructor(){this.normal=U(),this.shape=null,this.body=null,this.faceIndex=-1,this.fraction=-1,this.isStopped=!1}reset(){Zt(this.normal,0,0),this.shape=null,this.body=null,this.faceIndex=-1,this.fraction=-1,this.isStopped=!1}getHitDistance(t){return Dl(t.from,t.to)*this.fraction}hasHit(){return this.fraction!==-1}getHitPoint(t,e){return _r(t,e.from,e.to,this.fraction)}stop(){this.isStopped=!0}shouldStop(t){return this.isStopped||this.fraction!==-1&&t.mode===Pr.ANY}set(t,e,n,i,r){Kt(this.normal,t),this.shape=e,this.body=n,this.fraction=i,this.faceIndex=r}}class tf{constructor(){F(this,"listeners",{})}on(t,e){let n=this.listeners[t];return n===void 0&&(n=[],this.listeners[t]=n),n.indexOf(e)===-1&&n.push(e),this}off(t,e){const n=this.listeners[t];if(n){const i=n.indexOf(e);i!==-1&&n.splice(i,1)}return this}has(t,e){const n=this.listeners[t];return e?n!==void 0&&n.indexOf(e)!==-1:n!==void 0}emit(t){if(this.listeners===void 0)return this;const e=this.listeners[t.type];if(e!==void 0)for(const n of[...e])n(t);return this}}function Q1(s){const t=s.length>>1;if(t<3)return[];const e=[],n=[];for(let o=0;o<t;o++)n.push(o);let i=0,r=t;for(;r>3;){const o=n[(i+0)%r],a=n[(i+1)%r],c=n[(i+2)%r],l=s[2*o],h=s[2*o+1],d=s[2*a],u=s[2*a+1],m=s[2*c],x=s[2*c+1];let g=!1;if(eb(l,h,d,u,m,x)){g=!0;for(let p=0;p<r;p++){const f=n[p];if(!(f==o||f==a||f==c)&&tb(s[2*f],s[2*f+1],l,h,d,u,m,x)){g=!1;break}}}if(g)e.push(o,a,c),n.splice((i+1)%r,1),r--,i=0;else if(i++>3*r)break}return e.push(n[0],n[1],n[2]),e}function tb(s,t,e,n,i,r,o,a){const c=o-e,l=a-n,h=i-e,d=r-n,u=s-e,m=t-n,x=c*c+l*l,g=c*h+l*d,p=c*u+l*m,f=h*h+d*d,M=h*u+d*m,_=1/(x*f-g*g),v=(f*p-g*M)*_,b=(x*M-g*p)*_;return v>=0&&b>=0&&v+b<1}function eb(s,t,e,n,i,r){return(t-n)*(i-e)+(e-s)*(r-n)>=0}const vn=class vn{constructor(t){F(this,"body",null);F(this,"position",U());F(this,"boundingRadius",0);F(this,"area",0);this.id=vn.idCounter++,this.body=null,t.position&&Kt(this.position,t.position),this.type=t.type,this.angle=t.angle??0,this.collisionGroup=t.collisionGroup??1,this.collisionResponse=t.collisionResponse??!0,this.collisionMask=t.collisionMask??1,this.sensor=t.sensor??!1,this.material=t.material??null}updateBoundingRadius(){}updateArea(){}raycast(t,e,n,i){}pointTest(t){return!1}worldPointToLocal(t,e){const n=this.body;return Oe(fo,this.position,n.angle),_t(fo,fo,n.position),Ni(t,e,fo,this.body.angle+this.angle),t}};F(vn,"idCounter",0),F(vn,"CIRCLE",1),F(vn,"PARTICLE",2),F(vn,"PLANE",4),F(vn,"CONVEX",8),F(vn,"LINE",16),F(vn,"BOX",32),F(vn,"CAPSULE",64),F(vn,"HEIGHTFIELD",128);let Et=vn;const fo=U();class cs extends Et{constructor(t){t===void 0&&(t={});const e={type:Et.CONVEX,vertices:[],axes:[],...t};super(e),this.axes=e.axes,this.vertices=[];for(let n=0;n<e.vertices.length;n++)this.vertices.push(Mn(e.vertices[n]));this.normals=[];for(let n=0;n<e.vertices.length;n++)this.normals.push(U());if(this.updateNormals(),this.centerOfMass=U(),this.triangles=[],this.vertices.length&&(this.updateTriangles(),this.updateCenterOfMass()),this.boundingRadius=0,this.updateBoundingRadius(),this.updateArea(),this.area<0)throw new Error("Convex vertices must be given in counter-clockwise winding.")}updateNormals(){for(let t=0;t<this.vertices.length;t++){const e=this.vertices[t],n=this.vertices[(t+1)%this.vertices.length],i=this.normals[t];nt(i,n,e),ts(i,i),be(i,i)}}projectOntoLocalAxis(t,e){let n=0,i=0;t=nb;for(let r=0;r<this.vertices.length;r++){const o=this.vertices[r],a=ae(o,t);(n===null||a>n)&&(n=a),(i===null||a<i)&&(i=a)}if(i>n){const r=i;i=n,n=r}Zt(e,i,n)}projectOntoWorldAxis(t,e,n,i){let r=ib;this.projectOntoLocalAxis(t,i),n!==0?Oe(r,t,n):r=t;const o=ae(e,r);Zt(i,i[0]+o,i[1]+o)}updateTriangles(){this.triangles.length=0;const t=[];for(let n=0;n<this.vertices.length;n++){const i=this.vertices[n];t.push(i[0],i[1])}const e=Q1(t);for(let n=0;n<e.length;n+=3){const i=e[n],r=e[n+1],o=e[n+2];this.triangles.push([i,r,o])}}updateCenterOfMass(){const t=this.triangles,e=this.vertices,n=this.centerOfMass,i=sb;let r=ob,o=ab,a=cb;const c=rb;Zt(n,0,0);let l=0;for(let h=0;h!==t.length;h++){const d=t[h];r=e[d[0]],o=e[d[1]],a=e[d[2]],U1(i,r,o,a);const u=cs.triangleArea(r,o,a);l+=u,Ft(c,i,u),_t(n,n,c)}Ft(n,n,1/l)}computeMomentOfInertia(){let t=0,e=0;const n=this.vertices.length;for(let i=n-1,r=0;r<n;i=r,r++){const o=this.vertices[i],a=this.vertices[r],c=Math.abs(Hn(o,a)),l=ae(a,a)+ae(a,o)+ae(o,o);t+=c*l,e+=c}return 1/6*(t/e)}updateBoundingRadius(){const t=this.vertices;let e=0;for(let n=0;n!==t.length;n++){const i=yn(t[n]);i>e&&(e=i)}this.boundingRadius=Math.sqrt(e)}updateArea(){this.updateTriangles(),this.area=0;const t=this.triangles,e=this.vertices;for(let n=0;n!==t.length;n++){const i=t[n],r=e[i[0]],o=e[i[1]],a=e[i[2]],c=cs.triangleArea(r,o,a);this.area+=c}}computeAABB(t,e,n){t.setFromPoints(this.vertices,e,n,0)}raycast(t,e,n,i){const r=lb,o=hb,a=db,c=this.vertices;Ni(r,e.from,n,i),Ni(o,e.to,n,i);const l=c.length;for(let h=0;h<l&&!t.shouldStop(e);h++){const d=c[h],u=c[(h+1)%l],m=N1(r,o,d,u);m>=0&&(nt(a,u,d),Oe(a,a,-Math.PI/2+i),be(a,a),e.reportIntersection(t,m,a,h))}}pointTest(t){const e=ub,n=fb,i=this.vertices,r=i.length;let o=null;for(let a=0;a<r+1;a++){const c=i[a%r],l=i[(a+1)%r];nt(e,c,t),nt(n,l,t);const h=Hn(e,n);if(o===null&&(o=h),h*o<0)return!1;o=h}return!0}static triangleArea(t,e,n){return((e[0]-t[0])*(n[1]-t[1])-(n[0]-t[0])*(e[1]-t[1]))*.5}}const nb=U(),ib=U(),sb=U(),rb=U(),ob=U(),ab=U(),cb=U(),lb=U(),hb=U(),db=U(),ub=U(),fb=U(),xe=class xe extends tf{constructor(e){e===void 0&&(e={});super();F(this,"world",null);this.id=e.id||++xe._idCounter,this.index=-1,this.shapes=[],this.mass=e.mass||0,this.invMass=0,this.inertia=0,this.invInertia=0,this.invMassSolve=0,this.invInertiaSolve=0,this.fixedRotation=!!e.fixedRotation,this.fixedX=!!e.fixedX,this.fixedY=!!e.fixedY,this.massMultiplier=U(),this.position=e.position?Mn(e.position):U(),this.interpolatedPosition=Mn(this.position),this.previousPosition=Mn(this.position),this.velocity=e.velocity?Mn(e.velocity):U(),this.vlambda=U(),this.wlambda=0,this.angle=e.angle||0,this.previousAngle=this.angle,this.interpolatedAngle=this.angle,this.angularVelocity=e.angularVelocity||0,this.force=e.force?Mn(e.force):U(),this.angularForce=e.angularForce||0,this.damping=e.damping??.1,this.angularDamping=e.angularDamping??.1,this.type=xe.STATIC,e.type!==void 0?this.type=e.type:e.mass?this.type=xe.DYNAMIC:this.type=xe.STATIC,this.boundingRadius=0,this.aabb=new Ul,this.aabbNeedsUpdate=!0,this.allowSleep=e.allowSleep??!0,this.wantsToSleep=!1,this.sleepState=xe.AWAKE,this.sleepSpeedLimit=e.sleepSpeedLimit??.2,this.sleepTimeLimit=e.sleepTimeLimit??1,this.idleTime=0,this.timeLastSleepy=0,this.collisionResponse=e.collisionResponse??!0,this.ccdSpeedThreshold=e.ccdSpeedThreshold??-1,this.ccdIterations=e.ccdIterations??10,this.gravityScale=e.gravityScale??1,this.islandId=-1,this.concavePath=null,this._wakeUpAfterNarrowphase=!1,this.updateMassProperties()}updateSolveMassProperties(){this.sleepState===xe.SLEEPING||this.type===xe.KINEMATIC?(this.invMassSolve=0,this.invInertiaSolve=0):(this.invMassSolve=this.invMass,this.invInertiaSolve=this.invInertia)}setDensity(e){const n=this.getArea();this.mass=n*e,this.updateMassProperties()}getArea(){let e=0;for(let n=0;n<this.shapes.length;n++)e+=this.shapes[n].area;return e}getAABB(){return this.aabbNeedsUpdate&&this.updateAABB(),this.aabb}updateAABB(){const e=this.shapes,n=e.length,i=pb,r=this.angle;for(let o=0;o!==n;o++){const a=e[o],c=a.angle+r;we(i,a.position,this.position,r),a.computeAABB(Ka,i,c),o===0?this.aabb.copy(Ka):this.aabb.extend(Ka)}this.aabbNeedsUpdate=!1}updateBoundingRadius(){const e=this.shapes,n=e.length;let i=0;for(let r=0;r!==n;r++){const o=e[r],a=Rr(o.position),c=o.boundingRadius;a+c>i&&(i=a+c)}this.boundingRadius=i}addShape(e,n,i){if(e.body)throw new Error("A shape can only be added to one body.");const r=this.world;if(r&&r.stepping)throw new Error("A shape cannot be added during step.");e.body=this,n?Kt(e.position,n):Zt(e.position,0,0),e.angle=i||0,this.shapes.push(e),this.updateMassProperties(),this.updateBoundingRadius(),this.aabbNeedsUpdate=!0}removeShape(e){const n=this.world;if(n&&n.stepping)throw new Error("A shape cannot be removed during step.");const i=this.shapes.indexOf(e);return i!==-1?(this.shapes.splice(i,1),this.aabbNeedsUpdate=!0,e.body=null,!0):!1}updateMassProperties(){if(this.type===xe.STATIC||this.type===xe.KINEMATIC)this.mass=Number.MAX_VALUE,this.invMass=0,this.inertia=Number.MAX_VALUE,this.invInertia=0;else{const e=this.shapes,n=e.length;let i=0;if(this.fixedRotation)this.inertia=Number.MAX_VALUE,this.invInertia=0;else{for(let r=0;r<n;r++){const o=e[r],a=yn(o.position),c=o.computeMomentOfInertia();i+=c+a}this.inertia=this.mass*i,this.invInertia=i>0?1/i:0}this.invMass=1/this.mass,Zt(this.massMultiplier,this.fixedX?0:1,this.fixedY?0:1)}}applyForce(e,n){if(_t(this.force,this.force,e),n){const i=Hn(n,e);this.angularForce+=i}}applyForceLocal(e,n){n=n||gb;const i=mb,r=xb;this.vectorToWorldFrame(i,e),this.vectorToWorldFrame(r,n),this.applyForce(i,r)}applyImpulse(e,n){if(this.type!==xe.DYNAMIC)return;const i=_b;if(Ft(i,e,this.invMass),qo(i,this.massMultiplier,i),_t(this.velocity,i,this.velocity),n){let r=Hn(n,e);r*=this.invInertia,this.angularVelocity+=r}}applyImpulseLocal(e,n){n=n||Mb;const i=vb,r=bb;this.vectorToWorldFrame(i,e),this.vectorToWorldFrame(r,n),this.applyImpulse(i,r)}toLocalFrame(e,n){Ni(e,n,this.position,this.angle)}toWorldFrame(e,n){we(e,n,this.position,this.angle)}vectorToLocalFrame(e,n){Ku(e,n,this.angle)}vectorToWorldFrame(e,n){F1(e,n,this.angle)}fromPolygon(e,n){n===void 0&&(n={});for(let c=this.shapes.length;c>=0;--c)this.removeShape(this.shapes[c]);const i=[];for(let c=0;c<e.length;c++)i[c]=Mn(e[c]);if(W1(i),n.removeCollinearPoints!==void 0&&(typeof n.removeCollinearPoints=="boolean"?n.removeCollinearPoints===!0&&zd(i):zd(i,n.removeCollinearPoints)),!n.skipSimpleCheck&&!K1(i))return!1;const r=this.concavePath=[];for(let c=0;c<i.length;c++)r[c]=Mn(i[c]);let o;if(n.optimalDecomp){if(o=$1(i),o===!1)throw new Error("Convex decomposition failed!")}else o=gr(i);const a=U();for(let c=0;c!==o.length;c++){let l=new cs({vertices:o[c]});for(let h=0;h!==l.vertices.length;h++){const d=l.vertices[h];nt(d,d,l.centerOfMass)}Kt(a,l.centerOfMass),l=new cs({vertices:l.vertices}),this.addShape(l,a)}return this.adjustCenterOfMass(),this.aabbNeedsUpdate=!0,!0}adjustCenterOfMass(){const e=Sb,n=yb,i=Eb;let r=0;Zt(n,0,0);for(let o=0;o!==this.shapes.length;o++){const a=this.shapes[o];Ft(e,a.position,a.area),_t(n,n,e),r+=a.area}Ft(i,n,1/r);for(let o=0;o!==this.shapes.length;o++){const a=this.shapes[o];nt(a.position,a.position,i)}_t(this.position,this.position,i);for(let o=0;this.concavePath&&o<this.concavePath.length;o++)nt(this.concavePath[o],this.concavePath[o],i);this.updateMassProperties(),this.updateBoundingRadius()}setZeroForce(){const e=this.force;e[0]=e[1]=this.angularForce=0}applyDamping(e){if(this.type===xe.DYNAMIC){const n=this.velocity;Ft(n,n,Math.pow(1-this.damping,e)),this.angularVelocity*=Math.pow(1-this.angularDamping,e)}}wakeUp(){const e=this.sleepState;this.sleepState=xe.AWAKE,this.idleTime=0,e!==xe.AWAKE&&this.emit({type:"wakeup"})}sleep(){this.sleepState=xe.SLEEPING,this.angularVelocity=this.angularForce=0,Zt(this.velocity,0,0),Zt(this.force,0,0),this.emit({type:"sleep"})}sleepTick(e,n,i){if(!this.allowSleep||this.type===xe.SLEEPING)return;this.wantsToSleep=!1;const r=yn(this.velocity)+Math.pow(this.angularVelocity,2),o=Math.pow(this.sleepSpeedLimit,2);r>=o?(this.idleTime=0,this.sleepState=xe.AWAKE):(this.idleTime+=i,this.sleepState!==xe.SLEEPY&&(this.sleepState=xe.SLEEPY,this.emit({type:"sleepy"}))),this.idleTime>this.sleepTimeLimit&&(n?this.wantsToSleep=!0:this.sleep())}overlaps(e){return this.world===null?!1:this.world.overlapKeeper.bodiesAreOverlapping(this,e)}integrate(e){const n=this.invMass,i=this.force,r=this.position,o=this.velocity;Kt(this.previousPosition,this.position),this.previousAngle=this.angle,this.fixedRotation||(this.angularVelocity+=this.angularForce*this.invInertia*e),Ft(po,i,e*n),qo(po,this.massMultiplier,po),_t(o,po,o),this.integrateToTimeOfImpact(e)||(Ft(Rs,o,e),_t(r,r,Rs),this.fixedRotation||(this.angle+=this.angularVelocity*e)),this.aabbNeedsUpdate=!0}getVelocityAtPoint(e,n){return al(e,n,this.angularVelocity),nt(e,this.velocity,e),e}integrateToTimeOfImpact(e){if(this.world===null)throw new Error("world is not set for body");if(this.ccdSpeedThreshold<0||yn(this.velocity)<Math.pow(this.ccdSpeedThreshold,2))return!1;const n=[],i=this.world.disabledBodyCollisionPairs;for(let x=0;x<i.length;x+=2){const g=i[x],p=i[x+1];g===this?n.push(p):p===this&&n.push(g)}be(Ab,this.velocity),Ft(yi,this.velocity,e),_t(yi,yi,this.position),nt(lr,yi,this.position);const r=this.angularVelocity*e,o=Rr(lr);let a=1,c=null;Kt(Ki.from,this.position),Kt(Ki.to,yi),Ki.update();for(let x=0;x<this.shapes.length;x++){const g=this.shapes[x];if(mo.reset(),Ki.collisionGroup=g.collisionGroup,Ki.collisionMask=g.collisionMask,this.world.raycast(mo,Ki),c=mo.body,c!==null&&(c===this||n.indexOf(c)!==-1)&&(c=null),c)break}if(!c||!a)return!1;mo.getHitPoint(yi,Ki),nt(lr,yi,this.position),a=Dl(yi,this.position)/o;const l=this.angle;Kt(Za,this.position);let h=0,d=0,u=a,m=1;for(;m>=d&&h<this.ccdIterations;)h++,u=(m+d)/2,Ft(Rs,lr,u),_t(this.position,Za,Rs),this.angle=l+r*u,this.updateAABB(),this.aabb.overlaps(c.aabb)&&this.world.narrowphase.bodiesOverlap(this,c,!0)?m=u:d=u;return a=m,Kt(this.position,Za),this.angle=l,Ft(Rs,lr,a),_t(this.position,this.position,Rs),this.fixedRotation||(this.angle+=r*a),!0}resetConstraintVelocity(){const e=this.vlambda;Zt(e,0,0),this.wlambda=0}addConstraintVelocity(){const e=this.velocity;_t(e,e,this.vlambda),this.angularVelocity+=this.wlambda}};F(xe,"DYNAMIC",1),F(xe,"STATIC",2),F(xe,"KINEMATIC",4),F(xe,"AWAKE",0),F(xe,"SLEEPY",1),F(xe,"SLEEPING",2),F(xe,"_idCounter",0);let jt=xe;const Ka=new Ul,pb=U(),mb=U(),xb=U(),gb=U(),_b=U(),vb=U(),bb=U(),Mb=U(),Sb=U(),yb=U(),Eb=U(),po=U(),Rs=U(),mo=new J1,Ki=new Pr({mode:Pr.CLOSEST,skipBackfaces:!0}),Ab=U(),yi=U(),lr=U(),Za=U(),Rn=class Rn{static boundingRadiusCheck(t,e){const n=Fl(t.position,e.position),i=t.boundingRadius+e.boundingRadius;return n<=i*i}static aabbCheck(t,e){return t.getAABB().overlaps(e.getAABB())}static canCollide(t,e){const n=jt.KINEMATIC,i=jt.STATIC,r=t.type,o=e.type;return!(r===i&&o===i||r===n&&o===i||r===i&&o===n||r===n&&o===n||t.sleepState===jt.SLEEPING&&e.sleepState===jt.SLEEPING||t.sleepState===jt.SLEEPING&&o===i||e.sleepState===jt.SLEEPING&&r===i)}constructor(t){this.type=t,this.result=[],this.world=void 0,this.boundingVolumeType=Rn.AABB}setWorld(t){this.world=t}boundingVolumeCheck(t,e){switch(this.boundingVolumeType){case Rn.BOUNDING_CIRCLE:return Rn.boundingRadiusCheck(t,e);case Rn.AABB:return Rn.aabbCheck(t,e);default:throw new Error("Bounding volume type not recognized: "+this.boundingVolumeType)}}};F(Rn,"AABB",1),F(Rn,"BOUNDING_CIRCLE",2),F(Rn,"NAIVE",1),F(Rn,"SAP",2);let Mr=Rn;class $o extends cs{constructor(t){t===void 0&&(t={});const e=t.width??1,n=t.height??1,i=[nn(-e/2,-n/2),nn(e/2,-n/2),nn(e/2,n/2),nn(-e/2,n/2)],r={...t,type:Et.BOX,vertices:i};super(r),this.width=e,this.height=n,this.updateBoundingRadius(),this.updateArea()}computeMomentOfInertia(){const t=this.width,e=this.height;return(e*e+t*t)/12}updateBoundingRadius(){const t=this.width,e=this.height;this.boundingRadius=Math.sqrt(t*t+e*e)/2}computeAABB(t,e,n){const i=Math.abs(Math.cos(n)),r=Math.abs(Math.sin(n)),o=this.width,a=this.height,c=(o*r+a*i)*.5,l=(a*r+o*i)*.5,h=t.lowerBound,d=t.upperBound,u=e[0],m=e[1];h[0]=u-l,h[1]=m-c,d[0]=u+l,d[1]=m+c}updateArea(){this.area=this.width*this.height}pointTest(t){return Math.abs(t[0])<=this.width*.5&&Math.abs(t[1])<=this.height*.5}}class Nl extends Et{constructor(t){t===void 0&&(t={});const e={radius:1,...t,type:Et.CIRCLE};super(e),this.radius=e.radius,this.updateBoundingRadius(),this.updateArea()}updateBoundingRadius(){this.boundingRadius=this.radius}computeMomentOfInertia(){const t=this.radius;return t*t/2}updateArea(){this.area=Math.PI*this.radius*this.radius}computeAABB(t,e){const n=this.radius;Zt(t.upperBound,n,n),Zt(t.lowerBound,-n,-n),e&&(_t(t.lowerBound,t.lowerBound,e),_t(t.upperBound,t.upperBound,e))}raycast(t,e,n){const i=e.from,r=e.to,o=this.radius,a=Math.pow(r[0]-i[0],2)+Math.pow(r[1]-i[1],2),c=2*((r[0]-i[0])*(i[0]-n[0])+(r[1]-i[1])*(i[1]-n[1])),l=Math.pow(i[0]-n[0],2)+Math.pow(i[1]-n[1],2)-Math.pow(o,2),h=Math.pow(c,2)-4*a*l,d=wb,u=Tb;if(!(h<0))if(h===0)_r(d,i,r,h),nt(u,d,n),be(u,u),e.reportIntersection(t,h,u,-1);else{const m=Math.sqrt(h),x=1/(2*a),g=(-c-m)*x,p=(-c+m)*x;if(g>=0&&g<=1&&(_r(d,i,r,g),nt(u,d,n),be(u,u),e.reportIntersection(t,g,u,-1),t.shouldStop(e)))return;p>=0&&p<=1&&(_r(d,i,r,p),nt(u,d,n),be(u,u),e.reportIntersection(t,p,u,-1))}}pointTest(t){const e=this.radius;return yn(t)<=e*e}}const wb=U(),Tb=U(),Fs=class Fs{constructor(t,e,n,i){this.bodyA=t,this.bodyB=e,this.minForce=n??-Number.MAX_VALUE,this.maxForce=i??Number.MAX_VALUE,this.maxBias=Number.MAX_VALUE,this.stiffness=Fs.DEFAULT_STIFFNESS,this.relaxation=Fs.DEFAULT_RELAXATION,this.G=new aa(6);for(let r=0;r<6;r++)this.G[r]=0;this.offset=0,this.a=0,this.b=0,this.epsilon=0,this.timeStep=1/60,this.needsUpdate=!0,this.multiplier=0,this.relativeVelocity=0,this.enabled=!0,this.lambda=this.B=this.invC=this.minForceDt=this.maxForceDt=0,this.index=-1}update(){const t=this.stiffness,e=this.relaxation,n=this.timeStep;this.a=4/(n*(1+4*e)),this.b=4*e/(1+4*e),this.epsilon=4/(n*n*t*(1+4*e)),this.needsUpdate=!1}gmult(t,e,n,i,r){return t[0]*e[0]+t[1]*e[1]+t[2]*n+t[3]*i[0]+t[4]*i[1]+t[5]*r}computeB(t,e,n){const i=this.computeGW();let r=this.computeGq();const o=this.maxBias;Math.abs(r)>o&&(r=r>0?o:-o);const a=this.computeGiMf();return-r*t-i*e-a*n}computeGq(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.angle,r=n.angle;return this.gmult(t,Cb,i,Rb,r)+this.offset}computeGW(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.velocity,r=n.velocity,o=e.angularVelocity,a=n.angularVelocity;return this.gmult(t,i,o,r,a)+this.relativeVelocity}computeGWlambda(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.vlambda,r=n.vlambda,o=e.wlambda,a=n.wlambda;return this.gmult(t,i,o,r,a)}computeGiMf(){const t=this.bodyA,e=this.bodyB,n=t.force,i=t.angularForce,r=e.force,o=e.angularForce,a=t.invMassSolve,c=e.invMassSolve,l=t.invInertiaSolve,h=e.invInertiaSolve,d=this.G;return Ft(xo,n,a),qo(xo,t.massMultiplier,xo),Ft(go,r,c),qo(go,e.massMultiplier,go),this.gmult(d,xo,i*l,go,o*h)}computeGiMGt(){const t=this.bodyA,e=this.bodyB,n=t.invMassSolve,i=e.invMassSolve,r=t.invInertiaSolve,o=e.invInertiaSolve,a=this.G;return a[0]*a[0]*n*t.massMultiplier[0]+a[1]*a[1]*n*t.massMultiplier[1]+a[2]*a[2]*r+a[3]*a[3]*i*e.massMultiplier[0]+a[4]*a[4]*i*e.massMultiplier[1]+a[5]*a[5]*o}addToWlambda(t){const e=this.bodyA,n=this.bodyB,i=e.invMassSolve,r=n.invMassSolve,o=e.invInertiaSolve,a=n.invInertiaSolve,c=this.G;kd(e.vlambda,c[0],c[1],i,t,e.massMultiplier),e.wlambda+=o*c[2]*t,kd(n.vlambda,c[3],c[4],r,t,n.massMultiplier),n.wlambda+=a*c[5]*t}computeInvC(t){return 1/(this.computeGiMGt()+t)}};F(Fs,"DEFAULT_STIFFNESS",1e6),F(Fs,"DEFAULT_RELAXATION",4);let Ii=Fs;const Cb=U(),Rb=U(),xo=U(),go=U();function kd(s,t,e,n,i,r){s[0]+=t*n*i*r[0],s[1]+=e*n*i*r[1]}function Pb(s,t,e,n,i){s[0]=t[0]+e[0]-n[0]-i[0],s[1]=t[1]+e[1]-n[1]-i[1]}const Gd=U(),Hd=U(),Wd=U(),Xd=new Nl({radius:1});class Lb extends Ii{constructor(t,e){super(t,e,0,Number.MAX_VALUE),this.contactPointA=U(),this.penetrationVec=U(),this.contactPointB=U(),this.normalA=U(),this.restitution=0,this.firstImpact=!1,this.shapeA=Xd,this.shapeB=Xd}computeB(t,e,n){const i=this.bodyA,r=this.bodyB,o=this.contactPointA,a=this.contactPointB,c=i.position,l=r.position,h=this.normalA,d=this.G,u=Hn(o,h),m=Hn(a,h);d[0]=-h[0],d[1]=-h[1],d[2]=-u,d[3]=h[0],d[4]=h[1],d[5]=m;let x,g;if(this.firstImpact&&this.restitution!==0)g=0,x=1/e*(1+this.restitution)*this.computeGW();else{const M=this.penetrationVec;Pb(M,l,a,c,o),g=ae(h,M)+this.offset,x=this.computeGW()}const p=this.computeGiMf();return-g*t-x*e-n*p}getVelocityAlongNormal(){return this.bodyA.getVelocityAtPoint(Gd,this.contactPointA),this.bodyB.getVelocityAtPoint(Hd,this.contactPointB),nt(Wd,Gd,Hd),ae(this.normalA,Wd)}}class Ol{constructor(t){F(this,"objects",[]);(t==null?void 0:t.size)!==void 0&&this.resize(t.size)}resize(t){const e=this.objects;for(;e.length>t;)e.pop();for(;e.length<t;)e.push(this.create());return this}get(){const t=this.objects;return t.length?t.pop():this.create()}release(t){return this.destroy(t),this.objects.push(t),this}}class Ib extends Ol{create(){return new Lb(ja,ja)}destroy(t){return t.bodyA=t.bodyB=ja,this}}const ja=new jt;class ef extends Ii{constructor(t,e,n){n===void 0&&(n=Number.MAX_VALUE),super(t,e,-n,n),this.contactPointA=U(),this.contactPointB=U(),this.t=U(),this.contactEquations=[],this.shapeA=null,this.shapeB=null,this.frictionCoefficient=.3}setSlipForce(t){this.maxForce=t,this.minForce=-t}getSlipForce(){return this.maxForce}computeB(t,e,n){const i=this.contactPointA,r=this.contactPointB,o=this.t,a=this.G;a[0]=-o[0],a[1]=-o[1],a[2]=-Hn(i,o),a[3]=o[0],a[4]=o[1],a[5]=Hn(r,o);const c=this.computeGW(),l=this.computeGiMf();return-c*e-n*l}}class Db extends Ol{create(){return new ef(Ja,Ja)}destroy(t){return t.bodyA=t.bodyB=Ja,this}}const Ja=new jt;class No{constructor(){F(this,"data",{});F(this,"keys",[])}getKey(t,e){return t=t|0,e=e|0,(t|0)===(e|0)?-1:((t|0)>(e|0)?t<<16|e&65535:e<<16|t&65535)|0}getByKey(t){return t=t|0,this.data[t]}get(t,e){return this.data[this.getKey(t,e)]}set(t,e,n){if(!n)throw new Error("No data!");const i=this.getKey(t,e);return this.data[i]||this.keys.push(i),this.data[i]=n,i}reset(){this.keys=[],this.data={}}copy(t){this.keys=t.keys,this.data=t.data}}class Fb{constructor(){F(this,"convexLine",function(t,e,n,i,r,o,a,c,l){return 0});F(this,"lineBox",function(t,e,n,i,r,o,a,c,l){return 0});F(this,"convexCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=aM,u=a.length/2;Zt(d,u,0),we(d,d,c,l);const m=t.circleConvex(o,a,d,l,e,n,i,r,h,a.radius);Zt(d,-u,0),we(d,d,c,l);const x=t.circleConvex(o,a,d,l,e,n,i,r,h,a.radius);if(h&&m+x!==0)return 1;const g=oM;return nc(g,a),t.convexConvex(e,n,i,r,o,g,c,l,h)+m+x}})());F(this,"lineCapsule",function(t,e,n,i,r,o,a,c,l){return 0});F(this,"capsuleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);let d=!0;const u=cM,m=lM;let x=0;for(let M=0;M<2;M++){Zt(u,(M===0?-1:1)*n.length/2,0),we(u,u,i,r);for(let _=0;_<2;_++){Zt(m,(_===0?-1:1)*a.length/2,0),we(m,m,c,l),t.enableFrictionReduction&&(d=t.enableFriction,t.enableFriction=!1);const v=t.circleCircle(e,n,u,r,o,a,m,l,h,n.radius,a.radius);if(t.enableFrictionReduction&&(t.enableFriction=d),h&&v!==0)return 1;x+=v}}t.enableFrictionReduction&&(d=t.enableFriction,t.enableFriction=!1);const g=hM;nc(g,n);const p=t.convexCapsule(e,g,i,r,o,a,c,l,h);if(t.enableFrictionReduction&&(t.enableFriction=d),h&&p!==0)return 1;x+=p,t.enableFrictionReduction&&(d=t.enableFriction,t.enableFriction=!1),nc(g,a);const f=t.convexCapsule(o,g,c,l,e,n,i,r,h);return t.enableFrictionReduction&&(t.enableFriction=d),h&&f!==0?1:(x+=f,t.enableFrictionReduction&&x&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(x)),x)}})());F(this,"lineLine",function(t,e,n,i,r,o,a,c,l){return 0});F(this,"planeLine",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=ei,u=Zi,m=Ps,x=hr,g=dr,p=ur,f=vo,M=Qa,_=qd,v=Zd;let b=0;Zt(d,-a.length/2,0),Zt(u,a.length/2,0),we(m,d,c,l),we(x,u,c,l),Kt(d,m),Kt(u,x),nt(g,u,d),be(p,g),ts(_,p),Oe(M,_o,r),v[0]=d,v[1]=u;for(let S=0;S<v.length;S++){const T=v[S];nt(f,T,i);const P=ae(f,M);if(P<0){if(h)return 1;const A=t.createContactEquation(e,o,n,a);b++,Kt(A.normalA,M),be(A.normalA,A.normalA),Ft(f,M,P),nt(A.contactPointA,T,f),nt(A.contactPointA,A.contactPointA,e.position),nt(A.contactPointB,T,c),_t(A.contactPointB,A.contactPointB,c),nt(A.contactPointB,A.contactPointB,o.position),t.contactEquations.push(A),t.enableFrictionReduction||t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(A))}}return h?0:(t.enableFrictionReduction||b&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(b)),b)}})());F(this,"particleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){return h===void 0&&(h=!1),t.circleLine(e,n,i,r,o,a,c,l,h,a.radius,0)}})());F(this,"circleLine",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,d,u){h===void 0&&(h=!1),d===void 0&&(d=0),u===void 0&&(u=n.radius);const m=ei,x=Zi,g=Ps,p=hr,f=dr,M=ur,_=vo,v=Qa,b=qd,S=Yd,T=$d,P=Ub,A=tc,E=ec,C=Zd,D=a.length/2;Zt(v,-D,0),Zt(b,D,0),we(S,v,c,l),we(T,b,c,l),Kt(v,S),Kt(b,T),nt(M,b,v),be(_,M),ts(f,_),nt(P,i,v);const O=ae(P,f);nt(p,v,c),nt(A,i,c);const H=u+d;if(Math.abs(O)<H){Ft(m,f,O),nt(g,i,m),Ft(x,f,ae(f,A)),be(x,x),Ft(x,x,d),_t(g,g,x);const W=ae(_,g),$=ae(_,v),G=ae(_,b);if(W>$&&W<G){if(h)return 1;const V=t.createContactEquation(e,o,n,a);return Ft(V.normalA,m,-1),be(V.normalA,V.normalA),Ft(V.contactPointA,V.normalA,u),_t(V.contactPointA,V.contactPointA,i),nt(V.contactPointA,V.contactPointA,e.position),nt(V.contactPointB,g,c),_t(V.contactPointB,V.contactPointB,c),nt(V.contactPointB,V.contactPointB,o.position),t.contactEquations.push(V),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(V)),1}}C[0]=v,C[1]=b;for(let W=0;W<C.length;W++){const $=C[W];if(nt(P,$,i),yn(P)<Math.pow(H,2)){if(h)return 1;const G=t.createContactEquation(e,o,n,a);return Kt(G.normalA,P),be(G.normalA,G.normalA),Ft(G.contactPointA,G.normalA,u),_t(G.contactPointA,G.contactPointA,i),nt(G.contactPointA,G.contactPointA,e.position),nt(G.contactPointB,$,c),Ft(E,G.normalA,-d),_t(G.contactPointB,G.contactPointB,E),_t(G.contactPointB,G.contactPointB,c),nt(G.contactPointB,G.contactPointB,o.position),t.contactEquations.push(G),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(G)),1}}return 0}})());F(this,"circleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){return h===void 0&&(h=!1),t.circleLine(e,n,i,r,o,a,c,l,h,a.radius)}})());F(this,"circleConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,d){h===void 0&&(h=!1),d===void 0&&(d=n.radius);const u=ei,m=Zi,x=Ps,g=hr,p=dr,f=ur,M=vo,_=Qa,v=Yd,b=$d,S=tc,T=ec,P=Kd;let A=-1,E=Number.MAX_VALUE;Zt(f,0,0),Ni(M,i,c,l);const C=a.vertices,D=a.normals,O=C.length;let H=-1,W=-Number.MAX_VALUE;const $=a.boundingRadius+d;for(let G=0;G<O;G++){nt(_,M,C[G]);const V=ae(D[G],_);if(V>$)return 0;V>W&&(W=V,H=G)}for(let G=H+O-1;G<H+O+2;G++){const V=C[G%O],Y=D[G%O];if(Ft(T,Y,-d),_t(T,T,M),fM(T,a)){nt(P,V,T);const st=Math.abs(ae(P,Y));st<E&&(E=st,A=G)}}if(A!==-1){if(h)return 1;const G=C[A%O],V=C[(A+1)%O];we(u,G,c,l),we(m,V,c,l),nt(x,m,u),be(g,x),ts(p,g),Ft(T,p,-d),_t(T,T,i),Ft(S,p,E),_t(S,S,T);const Y=t.createContactEquation(e,o,n,a);return nt(Y.normalA,T,i),be(Y.normalA,Y.normalA),Ft(Y.contactPointA,Y.normalA,d),_t(Y.contactPointA,Y.contactPointA,i),nt(Y.contactPointA,Y.contactPointA,e.position),nt(Y.contactPointB,S,c),_t(Y.contactPointB,Y.contactPointB,c),nt(Y.contactPointB,Y.contactPointB,o.position),t.contactEquations.push(Y),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(Y)),1}if(d>0&&H!==-1)for(let G=H+O;G<H+O+2;G++){const V=C[G%O];if(nt(v,V,M),yn(v)<d*d){if(h)return 1;we(b,V,c,l),nt(v,b,i);const Y=t.createContactEquation(e,o,n,a);return Kt(Y.normalA,v),be(Y.normalA,Y.normalA),Ft(Y.contactPointA,Y.normalA,d),_t(Y.contactPointA,Y.contactPointA,i),nt(Y.contactPointA,Y.contactPointA,e.position),nt(Y.contactPointB,b,c),_t(Y.contactPointB,Y.contactPointB,c),nt(Y.contactPointB,Y.contactPointB,o.position),t.contactEquations.push(Y),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(Y)),1}}return 0}})());F(this,"particleConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=ei,u=Zi,m=Ps,x=hr,g=dr,p=ur,f=vo,M=tc,_=ec,v=Kd,b=a.vertices;let S=Number.MAX_VALUE,T=!1;if(!uM(i,a,c,l))return 0;if(h)return 1;for(let P=0,A=b.length;P!==A+1;P++){const E=b[P%A],C=b[(P+1)%A];Oe(d,E,l),Oe(u,C,l),_t(d,d,c),_t(u,u,c),nt(m,u,d),be(x,m),ts(g,x),nt(p,d,c),nt(f,i,c),nt(_,d,i);const D=Math.abs(ae(_,g));D<S&&(S=D,Ft(M,g,D),_t(M,M,i),Kt(v,g),T=!0)}if(T){const P=t.createContactEquation(e,o,n,a);return Ft(P.normalA,v,-1),be(P.normalA,P.normalA),Zt(P.contactPointA,0,0),_t(P.contactPointA,P.contactPointA,i),nt(P.contactPointA,P.contactPointA,e.position),nt(P.contactPointB,M,c),_t(P.contactPointB,P.contactPointB,c),nt(P.contactPointB,P.contactPointB,o.position),t.contactEquations.push(P),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(P)),1}return 0}})());F(this,"circleCircle",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,d,u){h===void 0&&(h=!1),d===void 0&&(d=n.radius),u===void 0&&(u=a.radius);const m=ei;nt(m,i,c);const x=d+u;if(yn(m)>x*x)return 0;if(h)return 1;const g=t.createContactEquation(e,o,n,a),p=g.contactPointA,f=g.contactPointB,M=g.normalA;return nt(M,c,i),be(M,M),Ft(p,M,d),Ft(f,M,-u),jd(p,p,i,e.position),jd(f,f,c,o.position),t.contactEquations.push(g),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(g)),1}})());F(this,"planeConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=ei,u=Zi,m=Ps,x=hr,g=dr,p=ur;let f=0;Oe(u,_o,r),Ku(g,u,l),Ni(x,i,c,l);const M=a.vertices;for(let _=0,v=M.length;_!==v;_++){const b=M[_];if(nt(p,b,x),ae(p,g)<=0){if(h)return 1;we(d,b,c,l),nt(m,d,i),f++;const S=t.createContactEquation(e,o,n,a);nt(m,d,i),Kt(S.normalA,u);const T=ae(m,S.normalA);Ft(m,S.normalA,T),nt(S.contactPointB,d,o.position),nt(S.contactPointA,d,m),nt(S.contactPointA,S.contactPointA,e.position),t.contactEquations.push(S),t.enableFrictionReduction||t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(S))}}return t.enableFrictionReduction&&t.enableFriction&&f&&t.frictionEquations.push(t.createFrictionFromAverage(f)),f}})());F(this,"particlePlane",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=ei,u=Zi;l=l||0,nt(d,i,c),Oe(u,_o,l);const m=ae(d,u);if(m>0)return 0;if(h)return 1;const x=t.createContactEquation(o,e,a,n);return Kt(x.normalA,u),Ft(d,x.normalA,m),nt(x.contactPointA,i,d),nt(x.contactPointA,x.contactPointA,o.position),nt(x.contactPointB,i,e.position),t.contactEquations.push(x),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(x)),1}})());F(this,"circleParticle",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=ei,u=n.radius;if(nt(d,c,i),yn(d)>u*u)return 0;if(h)return 1;const m=t.createContactEquation(e,o,n,a),x=m.normalA,g=m.contactPointA,p=m.contactPointB;return Kt(x,d),be(x,x),Ft(g,x,u),_t(g,g,i),nt(g,g,e.position),nt(p,c,o.position),t.contactEquations.push(m),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(m)),1}})());F(this,"planeCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=mM,u=xM,m=pM,x=a.length/2;Zt(d,-x,0),Zt(u,x,0),we(d,d,c,l),we(u,u,c,l),m.radius=a.radius;let g=!0;t.enableFrictionReduction&&(g=t.enableFriction,t.enableFriction=!1);const p=t.circlePlane(o,m,d,0,e,n,i,r,h),f=t.circlePlane(o,m,u,0,e,n,i,r,h);if(t.enableFrictionReduction&&(t.enableFriction=g),h)return p+f;{const M=p+f;return t.enableFrictionReduction&&M&&t.frictionEquations.push(t.createFrictionFromAverage(M)),M}}})());F(this,"circlePlane",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=n.radius,u=ei,m=Zi,x=Ps;nt(u,i,c),Oe(m,_o,l);const g=ae(m,u);if(g>d)return 0;if(h)return 1;const p=t.createContactEquation(o,e,a,n);Kt(p.normalA,m);const f=p.contactPointB;Ft(f,p.normalA,-d),_t(f,f,i),nt(f,f,e.position);const M=p.contactPointA;return Ft(x,p.normalA,g),nt(M,u,x),_t(M,M,c),nt(M,M,o.position),t.contactEquations.push(p),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(p)),1}})());F(this,"convexConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=0,u=$b,m=Bb,x=zb,g=Jd(m,n,i,r,a,c,l),p=m[0];if(p>d)return 0;const f=Jd(x,a,c,l,n,i,r),M=x[0];if(M>d)return 0;let _,v,b,S,T,P,A,E,C;M>p?(_=a,v=n,A=o,E=e,b=c,T=l,S=i,P=r,C=f):(_=n,v=a,A=e,E=o,b=i,T=r,S=c,P=l,C=g);const D=jb;SM(D,_,b,T,C,v,S,P);const O=_.vertices.length,H=_.vertices,W=C,$=C+1<O?C+1:0,G=qb,V=Yb;Kt(G,H[W]),Kt(V,H[$]);const Y=Vb;nt(Y,V,G),be(Y,Y),al(kb,Y,1);const St=Gb;_t(St,G,V),Ft(St,St,.5);const kt=Hb;Oe(kt,Y,T);const qt=Wb;al(qt,kt,1),we(G,G,b,T),we(V,V,b,T);const ce=ae(qt,G),le=-ae(kt,G)+d,Z=ae(kt,V)+d,Q=Kb,ut=Zb;let Lt=0;const yt=Xb;if(Ft(yt,kt,-1),Lt=Qd(Q,D,yt,le),Lt<2||(Lt=Qd(ut,Q,kt,Z),Lt<2))return 0;let Wt=0;for(let Se=0;Se<Jb;++Se){const Yt=ae(qt,ut[Se])-ce;if(Yt<=d){if(h)return 1;++Wt;const ie=t.createContactEquation(A,E,_,v);Kt(ie.normalA,qt),Kt(ie.contactPointB,ut[Se]),nt(ie.contactPointB,ie.contactPointB,E.position),Ft(u,qt,-Yt),_t(ie.contactPointA,ut[Se],u),nt(ie.contactPointA,ie.contactPointA,A.position),t.contactEquations.push(ie),t.enableFriction&&!t.enableFrictionReduction&&t.frictionEquations.push(t.createFrictionFromContact(ie))}}return Wt&&t.enableFrictionReduction&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(Wt)),Wt}})());F(this,"circleHeightfield",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,d){h===void 0&&(h=!1),d===void 0&&(d=n.radius);const u=a.heights,m=a.elementWidth,x=tM,g=Qb,p=iM,f=rM,M=sM,_=eM,v=nM;let b=Math.floor((i[0]-d-c[0])/m),S=Math.ceil((i[0]+d-c[0])/m);b<0&&(b=0),S>=u.length&&(S=u.length-1);let T=u[b],P=u[S];for(let E=b;E<S;E++)u[E]<P&&(P=u[E]),u[E]>T&&(T=u[E]);if(i[1]-d>T)return 0;let A=!1;for(let E=b;E<S;E++){Zt(_,E*m,u[E]),Zt(v,(E+1)*m,u[E+1]),_t(_,_,c),_t(v,v,c),nt(M,v,_),Oe(M,M,Math.PI/2),be(M,M),Ft(g,M,-d),_t(g,g,i),nt(x,g,_);const C=ae(x,M);if(g[0]>=_[0]&&g[0]<v[0]&&C<=0){if(h)return 1;A=!0,Ft(x,M,-C),_t(p,g,x),Kt(f,M);const D=t.createContactEquation(o,e,a,n);Kt(D.normalA,f),Ft(D.contactPointB,D.normalA,-d),_t(D.contactPointB,D.contactPointB,i),nt(D.contactPointB,D.contactPointB,e.position),Kt(D.contactPointA,p),nt(D.contactPointA,D.contactPointA,o.position),t.contactEquations.push(D),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(D))}}if(A=!1,d>0){for(let E=b;E<=S;E++)if(Zt(_,E*m,u[E]),_t(_,_,c),nt(x,i,_),yn(x)<Math.pow(d,2)){if(h)return 1;A=!0;const C=t.createContactEquation(o,e,a,n);Kt(C.normalA,x),be(C.normalA,C.normalA),Ft(C.contactPointB,C.normalA,-d),_t(C.contactPointB,C.contactPointB,i),nt(C.contactPointB,C.contactPointB,e.position),nt(C.contactPointA,_,c),_t(C.contactPointA,C.contactPointA,c),nt(C.contactPointA,C.contactPointA,o.position),t.contactEquations.push(C),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(C))}}return A?1:0}})());F(this,"convexHeightfield",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const d=a.heights,u=a.elementWidth,m=yM,x=EM,g=AM,p=wM;let f=Math.floor((e.aabb.lowerBound[0]-c[0])/u),M=Math.ceil((e.aabb.upperBound[0]-c[0])/u);f<0&&(f=0),M>=d.length&&(M=d.length-1);let _=d[f],v=d[M];for(let S=f;S<M;S++)d[S]<v&&(v=d[S]),d[S]>_&&(_=d[S]);if(e.aabb.lowerBound[1]>_)return 0;let b=0;for(let S=f;S<M;S++){Zt(m,S*u,d[S]),Zt(x,(S+1)*u,d[S+1]),_t(m,m,c),_t(x,x,c);const T=100;Zt(g,(x[0]+m[0])*.5,(x[1]+m[1]-T)*.5),nt(p.vertices[0],x,g),nt(p.vertices[1],m,g),Kt(p.vertices[2],p.vertices[1]),Kt(p.vertices[3],p.vertices[0]),p.vertices[2][1]-=T,p.vertices[3][1]-=T,p.updateNormals(),b+=t.convexConvex(e,n,i,r,o,p,g,0,h)}return b}})());F(this,"narrowphases",{[Et.CONVEX|Et.LINE]:this.convexLine,[Et.LINE|Et.BOX]:this.lineBox,[Et.CONVEX|Et.CAPSULE]:this.convexCapsule,[Et.BOX|Et.CAPSULE]:this.convexCapsule,[Et.LINE|Et.CAPSULE]:this.lineCapsule,[Et.CAPSULE]:this.capsuleCapsule,[Et.LINE]:this.lineLine,[Et.PLANE|Et.LINE]:this.planeLine,[Et.PARTICLE|Et.CAPSULE]:this.particleCapsule,[Et.CIRCLE|Et.LINE]:this.circleLine,[Et.CIRCLE|Et.CAPSULE]:this.circleCapsule,[Et.CIRCLE|Et.CONVEX]:this.circleConvex,[Et.CIRCLE|Et.BOX]:this.circleConvex,[Et.PARTICLE|Et.CONVEX]:this.particleConvex,[Et.PARTICLE|Et.BOX]:this.particleConvex,[Et.CIRCLE]:this.circleCircle,[Et.PLANE|Et.CONVEX]:this.planeConvex,[Et.PLANE|Et.BOX]:this.planeConvex,[Et.PARTICLE|Et.PLANE]:this.particlePlane,[Et.CIRCLE|Et.PARTICLE]:this.circleParticle,[Et.PLANE|Et.CAPSULE]:this.planeCapsule,[Et.CIRCLE|Et.PLANE]:this.circlePlane,[Et.CONVEX]:this.convexConvex,[Et.CONVEX|Et.BOX]:this.convexConvex,[Et.BOX]:this.convexConvex,[Et.CIRCLE|Et.HEIGHTFIELD]:this.circleHeightfield,[Et.BOX|Et.HEIGHTFIELD]:this.convexHeightfield,[Et.CONVEX|Et.HEIGHTFIELD]:this.convexHeightfield});this.contactEquations=[],this.frictionEquations=[],this.enableFriction=!0,this.enabledEquations=!0,this.slipForce=10,this.contactEquationPool=new Ib({size:32}),this.frictionEquationPool=new Db({size:64}),this.enableFrictionReduction=!0,this.collidingBodiesLastStep=new No,this.currentContactMaterial=null}bodiesOverlap(t,e,n){const i=Nb,r=Ob;for(let o=0,a=t.shapes.length;o!==a;o++){const c=t.shapes[o];for(let l=0,h=e.shapes.length;l!==h;l++){const d=e.shapes[l];if(n&&!((c.collisionGroup&d.collisionMask)!==0&&(d.collisionGroup&c.collisionMask)!==0))return!1;if(t.toWorldFrame(i,c.position),e.toWorldFrame(r,d.position),c.type<=d.type){if(this.narrowphases[c.type|d.type](t,c,i,c.angle+t.angle,e,d,r,d.angle+e.angle,!0))return!0}else if(this.narrowphases[c.type|d.type](e,d,r,d.angle+e.angle,t,c,i,c.angle+t.angle,!0))return!0}}return!1}collidedLastStep(t,e){const n=t.id|0,i=e.id|0;return!!this.collidingBodiesLastStep.get(n,i)}reset(){this.collidingBodiesLastStep.reset();const t=this.contactEquations;let e=t.length;for(;e--;){const r=t[e],o=r.bodyA.id,a=r.bodyB.id;this.collidingBodiesLastStep.set(o,a,!0)}const n=this.contactEquations,i=this.frictionEquations;for(let r=0;r<n.length;r++)this.contactEquationPool.release(n[r]);for(let r=0;r<i.length;r++)this.frictionEquationPool.release(i[r]);this.contactEquations.length=this.frictionEquations.length=0}createContactEquation(t,e,n,i){const r=this.contactEquationPool.get(),o=this.currentContactMaterial;return r.bodyA=t,r.bodyB=e,r.shapeA=n,r.shapeB=i,r.enabled=this.enabledEquations,r.firstImpact=!this.collidedLastStep(t,e),r.restitution=o.restitution,r.stiffness=o.stiffness,r.relaxation=o.relaxation,r.offset=o.contactSkinSize,r.needsUpdate=!0,r}createFrictionEquation(t,e,n,i){const r=this.frictionEquationPool.get(),o=this.currentContactMaterial;return r.bodyA=t,r.bodyB=e,r.shapeA=n,r.shapeB=i,r.setSlipForce(this.slipForce),r.enabled=this.enabledEquations,r.frictionCoefficient=o.friction,r.relativeVelocity=o.surfaceVelocity,r.stiffness=o.frictionStiffness,r.relaxation=o.frictionRelaxation,r.needsUpdate=!0,r.contactEquations.length=0,r}createFrictionFromContact(t){const e=this.createFrictionEquation(t.bodyA,t.bodyB,t.shapeA,t.shapeB);return Kt(e.contactPointA,t.contactPointA),Kt(e.contactPointB,t.contactPointB),ts(e.t,t.normalA),e.contactEquations.push(t),e}createFrictionFromAverage(t){let e=this.contactEquations[this.contactEquations.length-1];const n=this.createFrictionEquation(e.bodyA,e.bodyB,e.shapeA,e.shapeB),i=e.bodyA;Zt(n.contactPointA,0,0),Zt(n.contactPointB,0,0),Zt(n.t,0,0);for(let o=0;o!==t;o++)e=this.contactEquations[this.contactEquations.length-1-o],e.bodyA===i?(_t(n.t,n.t,e.normalA),_t(n.contactPointA,n.contactPointA,e.contactPointA),_t(n.contactPointB,n.contactPointB,e.contactPointB)):(nt(n.t,n.t,e.normalA),_t(n.contactPointA,n.contactPointA,e.contactPointB),_t(n.contactPointB,n.contactPointB,e.contactPointA)),n.contactEquations.push(e);const r=1/t;return Ft(n.contactPointA,n.contactPointA,r),Ft(n.contactPointB,n.contactPointB,r),be(n.t,n.t),ts(n.t,n.t),n}}const _o=nn(0,1),ei=U(),Zi=U(),Ps=U(),hr=U(),dr=U(),ur=U(),vo=U(),Qa=U(),qd=U(),Yd=U(),$d=U(),Ub=U(),tc=U(),ec=U(),Kd=U(),Zd=[],Nb=U(),Ob=U(),Bb=U(),zb=U(),Vb=U(),kb=U(),Gb=U(),Hb=U(),Wb=U(),Xb=U(),qb=U(),Yb=U(),$b=U(),Kb=[U(),U()],Zb=[U(),U()],jb=[U(),U()],Jb=2,Qb=U(),tM=U(),eM=U(),nM=U(),iM=U(),sM=U(),rM=U();function nc(s,t){const e=t.radius,n=t.length*.5,i=s.vertices;Zt(i[0],-n,-e),Zt(i[1],n,-e),Zt(i[2],n,e),Zt(i[3],-n,e)}const oM=new $o({width:1,height:1}),aM=U(),cM=U(),lM=U(),hM=new $o({width:1,height:1}),dM=U(),nf=U(),sf=U();function uM(s,t,e,n){const i=dM,r=nf,o=sf,a=t.vertices;let c=null;Ni(i,s,e,n);for(let l=0,h=a.length;l!==h+1;l++){const d=a[l%h],u=a[(l+1)%h];nt(r,d,i),nt(o,u,i);const m=Hn(r,o);if(c===null&&(c=m),m*c<0)return!1;c=m}return!0}function jd(s,t,e,n){s[0]=t[0]+e[0]-n[0],s[1]=t[1]+e[1]-n[1]}function fM(s,t){const e=nf,n=sf,i=t.vertices,r=i.length;let o=null;for(let a=0;a<r+1;a++){const c=i[a%r],l=i[(a+1)%r];nt(e,c,s),nt(n,l,s);const h=Hn(e,n);if(o===null&&(o=h),h*o<0)return!1;o=h}return!0}const pM=new Nl({radius:1}),mM=U(),xM=U(),gM=U(),_M=U(),vM=U(),bM=U();function Jd(s,t,e,n,i,r,o){const a=t.vertices.length,c=i.vertices.length,l=t.normals,h=t.vertices,d=i.vertices,u=gM,m=_M,x=vM,g=bM,p=n-o;let f=0,M=-Number.MAX_VALUE;for(let _=0;_<a;++_){Oe(u,l[_],p),we(g,h[_],e,n),Ni(m,g,r,o);let v=Number.MAX_VALUE;for(let b=0;b<c;++b){nt(x,d[b],m);const S=ae(u,x);S<v&&(v=S)}v>M&&(M=v,f=_)}return s[0]=M,f}const MM=U();function SM(s,t,e,n,i,r,o,a){const c=t.normals,l=r.vertices.length,h=r.vertices,d=r.normals,u=MM;Oe(u,c[i],n-a);let m=0,x=Number.MAX_VALUE;for(let f=0;f<l;++f){const M=ae(u,d[f]);M<x&&(x=M,m=f)}const g=m,p=g+1<l?g+1:0;we(s[0],h[g],o,a),we(s[1],h[p],o,a)}function Qd(s,t,e,n){let i=0;const r=ae(e,t[0])-n,o=ae(e,t[1])-n;if(r<=0&&Kt(s[i++],t[0]),o<=0&&Kt(s[i++],t[1]),r*o<0){const a=r/(r-o),c=s[i];nt(c,t[1],t[0]),Ft(c,c,a),_t(c,c,t[0]),++i}return i}const yM=U(),EM=U(),AM=U(),wM=new cs({vertices:[U(),U(),U(),U()]});class TM extends Mr{constructor(){super(Mr.SAP);F(this,"axisList",[]);F(this,"axisIndex",0);this.addBodyHandler=e=>{this.axisList.push(e.body)},this.removeBodyHandler=e=>{const n=this.axisList.indexOf(e.body);n!==-1&&this.axisList.splice(n,1)}}setWorld(e){this.axisList.length=0,Fo(this.axisList,e.bodies),e.off("addBody",this.addBodyHandler).off("removeBody",this.removeBodyHandler),e.on("addBody",this.addBodyHandler).on("removeBody",this.removeBodyHandler),this.world=e}sortList(){const e=this.axisList,n=this.axisIndex;CM(e,n)}getCollisionPairs(e){const n=this.axisList,i=this.result,r=this.axisIndex;i.length=0;let o=n.length;for(;o--;){const a=n[o];a.aabbNeedsUpdate&&a.updateAABB()}this.sortList();for(let a=0,c=n.length|0;a!==c;a++){const l=n[a];for(let h=a+1;h<c;h++){const d=n[h];if(!(d.aabb.lowerBound[r]<=l.aabb.upperBound[r]))break;Mr.canCollide(l,d)&&this.boundingVolumeCheck(l,d)&&i.push(l,d)}}return i}aabbQuery(e,n,i){i===void 0&&(i=[]),this.sortList();const r=this.axisList;for(let o=0;o<r.length;o++){const a=r[o];a.aabbNeedsUpdate&&a.updateAABB(),a.aabb.overlaps(n)&&i.push(a)}return i}}function CM(s,t){t=t|0;for(let e=1,n=s.length;e<n;e++){const i=s[e];let r;for(r=e-1;r>=0&&!(s[r].aabb.lowerBound[t]<=i.aabb.lowerBound[t]);r--)s[r+1]=s[r];s[r+1]=i}return s}U();U();U();U();U();U();nn(1,0);nn(0,1);U();U();nn(1,0);nn(0,1);U();U();U();U();U();U();U();U();nn(1,0);nn(0,1);U();const Zo=class Zo{constructor(){this.id=Zo.idCounter++}};F(Zo,"idCounter",0);let Lr=Zo;const jo=class jo{constructor(t,e,n){if(n===void 0&&(n={}),!(t instanceof Lr)||!(e instanceof Lr))throw new Error("First two arguments must be Material instances.");this.id=jo.idCounter++,this.materialA=t,this.materialB=e,this.friction=n.friction??.3,this.restitution=n.restitution??0,this.stiffness=n.stiffness??Ii.DEFAULT_STIFFNESS,this.relaxation=n.relaxation??Ii.DEFAULT_RELAXATION,this.frictionStiffness=n.frictionStiffness??Ii.DEFAULT_STIFFNESS,this.frictionRelaxation=n.frictionRelaxation??Ii.DEFAULT_RELAXATION,this.surfaceVelocity=n.surfaceVelocity??0,this.contactSkinSize=.005}};F(jo,"idCounter",0);let dl=jo;U();U();U();U();U();U();U();U();U();U();U();U();U();U();U();U();U();nn(0,1);U(),U(),U(),U();U();U();U();U();U();U(),U();U();U();U();nn(0,1);U();U();U();class ic{constructor(t,e){t===void 0&&(t={}),this.type=e,this.equations=[],this.equationSortFunction=t.equationSortFunction}sortEquations(){this.equationSortFunction&&this.equations.sort(this.equationSortFunction)}addEquation(t){t.enabled&&this.equations.push(t)}addEquations(t){for(let e=0,n=t.length;e!==n;e++){const i=t[e];i.enabled&&this.equations.push(i)}}removeEquation(t){const e=this.equations.indexOf(t);e!==-1&&this.equations.splice(e,1)}removeAllEquations(){this.equations.length=0}}class RM extends ic{constructor(e){e===void 0&&(e={});super(e,ic.GS);F(this,"type",ic.GS);this.iterations=e.iterations??10,this.tolerance=e.tolerance??1e-7,this.frictionIterations=e.frictionIterations??0,this.usedIterations=0}solve(e,n){this.sortEquations();let i=0;const r=this.iterations,o=this.frictionIterations,a=this.equations,c=a.length,l=Math.pow(this.tolerance*c,2),h=n.bodies,d=h.length;if(this.usedIterations=0,c)for(let p=0;p!==d;p++)h[p].updateSolveMassProperties();for(let p=0;p!==c;p++){const f=a[p];f.lambda=0,(f.timeStep!==e||f.needsUpdate)&&(f.timeStep=e,f.update()),f.B=f.computeB(f.a,f.b,e),f.invC=f.computeInvC(f.epsilon),f.maxForceDt=f.maxForce*e,f.minForceDt=f.minForce*e}let u,m,x,g;if(c!==0){for(x=0;x!==d;x++)h[x].resetConstraintVelocity();if(o){for(i=0;i!==o;i++){for(m=0,g=0;g!==c;g++){u=a[g];const p=eu(u);m+=Math.abs(p)}if(this.usedIterations++,m*m<=l)break}for(tu(a,1/e),g=0;g!==c;g++){const p=a[g];if(p instanceof ef){let f=0;for(let M=0;M!==p.contactEquations.length;M++)f+=p.contactEquations[M].multiplier;f*=p.frictionCoefficient/p.contactEquations.length,p.maxForce=f,p.minForce=-f,p.maxForceDt=f*e,p.minForceDt=-f*e}}}for(i=0;i!==r;i++){for(m=0,g=0;g!==c;g++){u=a[g];const p=eu(u);m+=Math.abs(p)}if(this.usedIterations++,m*m<l)break}for(x=0;x!==d;x++)h[x].addConstraintVelocity();tu(a,1/e)}}}function tu(s,t){let e=s.length;for(;e--;){const n=s[e];n.multiplier=n.lambda*t}}function eu(s){const t=s.B,e=s.epsilon,n=s.invC,i=s.lambda,r=s.computeGWlambda(),o=s.maxForceDt,a=s.minForceDt;let c=n*(t-r-e*i);const l=i+c;return l<a?c=a-i:l>o&&(c=o-i),s.lambda+=c,s.addToWlambda(c),c}class PM{constructor(t,e,n,i){this.bodyA=t,this.shapeA=e,this.bodyB=n,this.shapeB=i}set(t,e,n,i){this.bodyA=t,this.shapeA=e,this.bodyB=n,this.shapeB=i}}class LM extends Ol{create(){return new PM(rc,sc,rc,sc)}destroy(t){return t.bodyA=t.bodyB=rc,t.shapeA=t.shapeB=sc,this}}const sc=new Nl({radius:1}),rc=new jt;class IM{constructor(){this.overlappingShapesLastState=new No,this.overlappingShapesCurrentState=new No,this.recordPool=new LM({size:16}),this.tmpDict=new No,this.tmpArray1=[]}tick(){const t=this.overlappingShapesLastState,e=this.overlappingShapesCurrentState;let n=t.keys.length;for(;n--;){const i=t.keys[n],r=t.getByKey(i);r&&this.recordPool.release(r)}t.copy(e),e.reset()}bodiesAreOverlapping(t,e){const n=this.overlappingShapesCurrentState;let i=n.keys.length;for(;i--;){const r=n.keys[i],o=n.data[r];if(o.bodyA===t&&o.bodyB===e||o.bodyA===e&&o.bodyB===t)return!0}return!1}setOverlapping(t,e,n,i){const r=this.overlappingShapesCurrentState;if(!r.get(e.id,i.id)){const o=this.recordPool.get();o.set(t,e,n,i),r.set(e.id,i.id,o)}}getNewOverlaps(t){return this.getDiff(this.overlappingShapesLastState,this.overlappingShapesCurrentState,t)}getEndOverlaps(t){return this.getDiff(this.overlappingShapesCurrentState,this.overlappingShapesLastState,t)}getDiff(t,e,n){n===void 0&&(n=[]);const i=t,r=e;n.length=0;let o=r.keys.length;for(;o--;){const a=r.keys[o],c=r.data[a];if(!c)throw new Error("Key "+a+" had no data!");i.data[a]||n.push(c)}return n}isNewOverlap(t,e){const n=t.id|0,i=e.id|0,r=this.overlappingShapesLastState,o=this.overlappingShapesCurrentState;return!r.get(n,i)&&!!o.get(n,i)}getNewBodyOverlaps(t){this.tmpArray1.length=0;const e=this.getNewOverlaps(this.tmpArray1);return this.getBodyDiff(e,t)}getEndBodyOverlaps(t){this.tmpArray1.length=0;const e=this.getEndOverlaps(this.tmpArray1);return this.getBodyDiff(e,t)}getBodyDiff(t,e){e===void 0&&(e=[]);const n=this.tmpDict;let i=t.length;for(;i--;){const r=t[i];n.set(r.bodyA.id|0,r.bodyB.id|0,r)}for(i=n.keys.length;i--;){const r=n.getByKey(n.keys[i]);r&&e.push(r.bodyA,r.bodyB)}return n.reset(),e}}class DM{constructor(t){F(this,"id",[]);F(this,"sz",[]);this.size=t,this.count=t,this.resize(t)}resize(t){this.count=this.size=t;const e=this.sz,n=this.id;for(let i=0;i<t;i++)n[i]=i,e[i]=1}find(t){const e=this.id;for(;t!==e[t];)e[t]=e[e[t]],t=e[t];return t}union(t,e){const n=this.find(t),i=this.find(e);if(n===i)return;const r=this.sz,o=this.id;r[n]<r[i]?(o[n]=i,r[i]+=r[n]):(o[i]=n,r[n]+=r[i]),this.count--}}const Ci=class Ci extends tf{constructor(e){e===void 0&&(e={});super();F(this,"springs",[]);F(this,"bodies",[]);F(this,"hasActiveBodies",!1);F(this,"narrowphase",new Fb);F(this,"useWorldGravityAsFrictionGravity",!0);F(this,"useFrictionGravityOnZeroGravity",!0);F(this,"constraints",[]);F(this,"lastTimeStep",1/60);F(this,"applySpringForces",!0);F(this,"applyDamping",!0);F(this,"applyGravity",!0);F(this,"solveConstraints",!0);F(this,"contactMaterials",[]);F(this,"time",0);F(this,"accumulator",0);F(this,"stepping",!1);F(this,"emitImpactEvent",!0);F(this,"sleepMode",Ci.NO_SLEEPING);F(this,"overlapKeeper",new IM);F(this,"disabledBodyCollisionPairs",[]);F(this,"unionFind",new DM(1));this.solver=e.solver||new RM,this.gravity=nn(0,-9.78),e.gravity&&Kt(this.gravity,e.gravity),this.frictionGravity=Rr(this.gravity)||10,this.broadphase=e.broadphase||new TM,this.broadphase.setWorld(this),this.defaultMaterial=new Lr,this.defaultContactMaterial=new dl(this.defaultMaterial,this.defaultMaterial),this.islandSplit=e.islandSplit??!0}addConstraint(e){if(this.stepping)throw new Error("Constraints cannot be added during step.");const n=this.bodies;if(n.indexOf(e.bodyA)===-1)throw new Error("Cannot add Constraint: bodyA is not added to the World.");if(n.indexOf(e.bodyB)===-1)throw new Error("Cannot add Constraint: bodyB is not added to the World.");this.constraints.push(e)}addContactMaterial(e){this.contactMaterials.push(e)}removeContactMaterial(e){ho(this.contactMaterials,e)}getContactMaterial(e,n){const i=this.contactMaterials;for(let r=0,o=i.length;r!==o;r++){const a=i[r];if(a.materialA===e&&a.materialB===n||a.materialA===n&&a.materialB===e)return a}return!1}removeConstraint(e){if(this.stepping)throw new Error("Constraints cannot be removed during step.");ho(this.constraints,e)}step(e,n,i){if(i===void 0&&(i=10),n===void 0)this.internalStep(e),this.time+=e;else{this.accumulator+=n;let r=0;for(;this.accumulator>=e&&r<i;)this.internalStep(e),this.time+=e,this.accumulator-=e,r++;const o=this.accumulator%e/e;for(let a=0;a!==this.bodies.length;a++){const c=this.bodies[a];_r(c.interpolatedPosition,c.previousPosition,c.position,o),c.interpolatedAngle=c.previousAngle+o*(c.angle-c.previousAngle)}}}internalStep(e){this.stepping=!0;const n=this.springs.length,i=this.springs,r=this.bodies,o=this.gravity,a=this.solver,c=this.bodies.length,l=this.broadphase,h=this.narrowphase,d=this.constraints,u=OM,m=_t;if(this.overlapKeeper.tick(),this.lastTimeStep=e,this.useWorldGravityAsFrictionGravity){const v=Rr(this.gravity);v===0&&this.useFrictionGravityOnZeroGravity||(this.frictionGravity=v)}if(this.applyGravity)for(let v=0;v!==c;v++){const b=r[v],S=b.force;b.type!==jt.DYNAMIC||b.sleepState===jt.SLEEPING||(Ft(u,o,b.mass*b.gravityScale),m(S,S,u))}if(this.applySpringForces)for(let v=0;v!==n;v++)i[v].applyForce();if(this.applyDamping)for(let v=0;v!==c;v++){const b=r[v];b.type===jt.DYNAMIC&&b.applyDamping(e)}const x=l.getCollisionPairs(this),g=this.disabledBodyCollisionPairs;for(let v=g.length-2;v>=0;v-=2)for(let b=x.length-2;b>=0;b-=2)(g[v]===x[b]&&g[v+1]===x[b+1]||g[v+1]===x[b]&&g[v]===x[b+1])&&x.splice(b,2);let p=d.length;for(let v=0;v!==p;v++){const b=d[v];if(!b.collideConnected)for(let S=x.length-2;S>=0;S-=2)(b.bodyA===x[S]&&b.bodyB===x[S+1]||b.bodyB===x[S]&&b.bodyA===x[S+1])&&x.splice(S,2)}this.emit({type:"postBroadphase",pairs:x}),h.reset();const f=this.defaultContactMaterial,M=this.frictionGravity;for(let v=0,b=x.length;v!==b;v+=2){const S=x[v],T=x[v+1];for(let P=0,A=S.shapes.length;P!==A;P++){const E=S.shapes[P],C=E.position,D=E.angle;for(let O=0,H=T.shapes.length;O!==H;O++){const W=T.shapes[O],$=W.position,G=W.angle;let V=!1;E.material&&W.material&&(V=this.getContactMaterial(E.material,W.material)),NM(this,h,S,E,C,D,T,W,$,G,V||f,M)}}}for(let v=0;v!==c;v++){const b=r[v];b._wakeUpAfterNarrowphase&&(b.wakeUp(),b._wakeUpAfterNarrowphase=!1)}if(this.has("endContact")){this.overlapKeeper.getEndOverlaps(So);let v=So.length;for(;v--;){const b=So[v],S={type:"endContact",shapeA:b.shapeA,shapeB:b.shapeB,bodyA:b.bodyA,bodyB:b.bodyB};this.emit(S)}So.length=0}this.emit({type:"preSolve",contactEquations:h.contactEquations,frictionEquations:h.frictionEquations}),p=d.length;for(let v=0;v!==p;v++)d[v].update();if(h.contactEquations.length||h.frictionEquations.length||p){let v=[];Fo(v,h.contactEquations),Fo(v,h.frictionEquations);for(let b=0;b!==p;b++)Fo(v,d[b].equations);if(this.islandSplit){const b=this.unionFind;b.resize(this.bodies.length+1);for(let T=0;T<v.length;T++)v[T].index=T;for(let T=0;T<v.length;T++){const P=v[T].bodyA,A=v[T].bodyB;P.type===jt.DYNAMIC&&A.type===jt.DYNAMIC&&b.union(P.index,A.index)}for(let T=0;T<r.length;T++){const P=r[T];P.islandId=P.type===jt.DYNAMIC?b.find(P.index):-1}v=v.sort(UM);let S=0;for(;S<v.length;){const T=v[S++];a.addEquation(T);const P=T.bodyA.islandId>0?T.bodyA.islandId:T.bodyB.islandId;let A=-1;v[S]&&(A=v[S].bodyA.islandId>0?v[S].bodyA.islandId:v[S].bodyB.islandId),(A!==P||S===v.length)&&(this.solveConstraints&&a.solve(e,this),a.removeAllEquations())}}else a.addEquations(v),this.solveConstraints&&a.solve(e,this),a.removeAllEquations()}for(let v=0;v!==c;v++){const b=r[v];(b.type===jt.DYNAMIC||b.type===jt.KINEMATIC)&&b.integrate(e)}for(let v=0;v!==c;v++)r[v].setZeroForce();if(this.emitImpactEvent&&this.has("impact"))for(let v=0;v!==h.contactEquations.length;v++){const b=h.contactEquations[v];b.firstImpact&&this.emit({type:"impact",bodyA:b.bodyA,bodyB:b.bodyB,shapeA:b.shapeA,shapeB:b.shapeB,contactEquation:b})}let _=!0;if(this.sleepMode===Ci.BODY_SLEEPING){_=!1;for(let v=0;v!==c;v++){const b=r[v];b.sleepTick(this.time,!1,e),b.sleepState!==jt.SLEEPING&&b.type!==jt.STATIC&&(_=!0)}}else if(this.sleepMode===Ci.ISLAND_SLEEPING&&this.islandSplit){for(let S=0;S!==c;S++)r[S].sleepTick(this.time,!0,e);const v=r.sort(FM);let b=1;for(let S=0;S<v.length;S=b){const T=v[S].islandId;for(b=S+1;b<v.length&&v[b].islandId===T;b++);if(T===-1)continue;let P=!0;for(let A=S;A<b;A++)if(!v[A].wantsToSleep){P=!1;break}if(P)for(let A=S;A<b;A++)v[A].sleep()}_=!1;for(let S=0;S!==c;S++){const T=r[S];if(T.sleepState!==jt.SLEEPING&&T.type!==jt.STATIC){_=!0;break}}}this.hasActiveBodies=_,this.stepping=!1,this.emit({type:"postStep"})}addSpring(e){if(this.stepping)throw new Error("Springs cannot be added during step.");this.springs.push(e),this.emit({type:"addSpring",spring:e})}removeSpring(e){if(this.stepping)throw new Error("Springs cannot be removed during step.");ho(this.springs,e),this.emit({type:"removeSpring",spring:e})}addBody(e){if(this.stepping)throw new Error("Bodies cannot be added during step.");if(e.world)throw new Error("Body is already added to a World.");e.index=this.bodies.length,this.bodies.push(e),e.world=this,this.emit({type:"addBody",body:e})}removeBody(e){if(this.stepping)throw new Error("Bodies cannot be removed during step.");const n=this.constraints;let i=n.length;for(;i--;)if(n[i].bodyA===e||n[i].bodyB===e)throw new Error("Cannot remove Body from World: it still has constraints connected to it.");e.world=null;const r=this.bodies;for(ho(r,e),e.index=-1,i=r.length;i--;)r[i].index=i;e.resetConstraintVelocity(),this.emit({type:"removeBody",body:e});const o=this.disabledBodyCollisionPairs;let a=0;for(;a<o.length;)o[a]===e||o[a+1]===e?o.splice(a,2):a+=2}getBodyByID(e){const n=this.bodies;for(let i=0;i<n.length;i++){const r=n[i];if(r.id===e)return r}return!1}disableBodyCollision(e,n){this.disabledBodyCollisionPairs.push(e,n)}enableBodyCollision(e,n){const i=this.disabledBodyCollisionPairs;for(let r=0;r<i.length;r+=2)if(i[r]===e&&i[r+1]===n||i[r+1]===e&&i[r]===n){i.splice(r,2);return}}clear(){this.solver.removeAllEquations();const e=this.constraints;let n=e.length;for(;n--;)this.removeConstraint(e[n]);const i=this.bodies;for(n=i.length;n--;)this.removeBody(i[n]);const r=this.springs;for(n=r.length;n--;)this.removeSpring(r[n]);const o=this.contactMaterials;for(n=o.length;n--;)this.removeContactMaterial(o[n])}hitTest(e,n,i){i===void 0&&(i=0);const r=BM,o=zM,a=[];for(let c=0,l=n.length;c!==l;c++){const h=n[c];for(let d=0,u=h.shapes.length;d!==u;d++){const m=h.shapes[d];m.worldPointToLocal(o,e),m.pointTest(o)?a.push(h):(Oe(r,m.position,h.angle),_t(r,r,h.position),m.type===Et.PARTICLE&&Fl(r,e)<i*i&&a.push(h))}}return a}setGlobalStiffness(e){this.setGlobalEquationParameters({stiffness:e});const n=this.contactMaterials;for(let r=0;r!==n.length;r++){const o=n[r];o.stiffness=o.frictionStiffness=e}const i=this.defaultContactMaterial;i.stiffness=i.frictionStiffness=e}setGlobalRelaxation(e){this.setGlobalEquationParameters({relaxation:e});for(let i=0;i!==this.contactMaterials.length;i++){const r=this.contactMaterials[i];r.relaxation=r.frictionRelaxation=e}const n=this.defaultContactMaterial;n.relaxation=n.frictionRelaxation=e}raycast(e,n){return n.getAABB(nu),this.broadphase.aabbQuery(this,nu,oc),n.intersectBodies(e,oc),oc.length=0,e.hasHit()}setGlobalEquationParameters(e){const n=this.constraints;for(let i=0;i!==n.length;i++){const o=n[i].equations;for(let a=0;a!==o.length;a++){const c=o[a];c.relaxation=e.relaxation??c.relaxation,c.stiffness=e.stiffness??c.stiffness,c.needsUpdate=!0}}}};F(Ci,"NO_SLEEPING",1),F(Ci,"BODY_SLEEPING",2),F(Ci,"ISLAND_SLEEPING",4);let Ko=Ci;function FM(s,t){return s.islandId-t.islandId}function UM(s,t){const e=s.bodyA.islandId>0?s.bodyA.islandId:s.bodyB.islandId,n=t.bodyA.islandId>0?t.bodyA.islandId:t.bodyB.islandId;return e!==n?e-n:s.index-t.index}function NM(s,t,e,n,i,r,o,a,c,l,h,d){if(!((n.collisionGroup&a.collisionMask)!==0&&(a.collisionGroup&n.collisionMask)!==0)||(we(bo,i,e.position,e.angle),we(Mo,c,o.position,o.angle),Dl(bo,Mo)>n.boundingRadius+a.boundingRadius))return;const u=r+e.angle,m=l+o.angle;t.enableFriction=h.friction>0;let x;e.type===jt.STATIC||e.type===jt.KINEMATIC?x=o.mass:o.type===jt.STATIC||o.type===jt.KINEMATIC?x=e.mass:x=e.mass*o.mass/(e.mass+o.mass),t.slipForce=h.friction*d*x,t.currentContactMaterial=h,t.enabledEquations=e.collisionResponse&&o.collisionResponse&&n.collisionResponse&&a.collisionResponse;const g=t.narrowphases[n.type|a.type];let p=0;if(g){const f=n.sensor||a.sensor,M=t.frictionEquations.length;n.type<a.type?p=g.call(t,e,n,bo,u,o,a,Mo,m,f):p=g.call(t,o,a,Mo,m,e,n,bo,u,f);const _=t.frictionEquations.length-M;if(p){if(e.allowSleep&&e.type===jt.DYNAMIC&&e.sleepState===jt.SLEEPING&&o.sleepState===jt.AWAKE&&o.type!==jt.STATIC){const v=yn(o.velocity)+Math.pow(o.angularVelocity,2),b=Math.pow(o.sleepSpeedLimit,2);v>=b*2&&(e._wakeUpAfterNarrowphase=!0)}if(o.allowSleep&&o.type===jt.DYNAMIC&&o.sleepState===jt.SLEEPING&&e.sleepState===jt.AWAKE&&e.type!==jt.STATIC){const v=yn(e.velocity)+Math.pow(e.angularVelocity,2),b=Math.pow(e.sleepSpeedLimit,2);v>=b*2&&(o._wakeUpAfterNarrowphase=!0)}if(s.overlapKeeper.setOverlapping(e,n,o,a),s.has("beginContact")&&s.overlapKeeper.isNewOverlap(n,a)){const v=[];if(!f)for(let b=t.contactEquations.length-p;b<t.contactEquations.length;b++)v.push(t.contactEquations[b]);s.emit({type:"beginContact",shapeA:n,shapeB:a,bodyA:e,bodyB:o,contactEquations:v})}if(!f&&_>1)for(let v=t.frictionEquations.length-_;v<t.frictionEquations.length;v++){const b=t.frictionEquations[v];b.setSlipForce(b.getSlipForce()/_)}}}}const nu=new Ul,oc=[],OM=U(),bo=U(),Mo=U(),So=[],BM=U(),zM=U(),ji=new B,yo=new B,Eo=new B;function VM(s,t){const e=s.ray;ji.set(1/e.direction.x,1/e.direction.y,1/e.direction.z);let n=1/0,i=-1;const r=t.boxCount;for(let o=0;o<r;o++){const[a,c,l,h,d,u]=t.boxes[o];yo.set(a,c,l),Eo.set(a+h,c+d,l+u);const m=(yo.x-e.origin.x)*ji.x,x=(Eo.x-e.origin.x)*ji.x,g=(yo.y-e.origin.y)*ji.y,p=(Eo.y-e.origin.y)*ji.y,f=(yo.z-e.origin.z)*ji.z,M=(Eo.z-e.origin.z)*ji.z,_=Math.max(Math.max(Math.min(m,x),Math.min(g,p)),Math.min(f,M)),v=Math.min(Math.min(Math.max(m,x),Math.max(g,p)),Math.max(f,M));v<0||_>v||_>=0&&_<n&&(n=_,i=o)}return i}const kM=1e3;let Ao=0;const GM=1/600,HM=40,WM=5,XM=100,qM=.5,YM=1e3,$M=100,KM=0,ZM=1e6,jM=20,JM=1,QM=1;let iu=!1,su=!1;class tS{constructor(){F(this,"state",new v1);F(this,"gui");F(this,"level");F(this,"graphics");F(this,"p2World",new Ko({gravity:[0,XM]}));F(this,"activeTime",0);F(this,"isEditor",!1);F(this,"drawOffset",[0,0]);F(this,"drawScale",1);F(this,"mousePos");F(this,"isMouseDown",!1);F(this,"didBuildControls",!1);if(iu)throw new Error("TowerToppler constructed multiple times");iu=!0;for(const t of Xa.NAMES)fn.preload(this,t)}toggleEditor(){this.isEditor=!this.isEditor,is.hideAll(),this.gui=fn.create(this.isEditor?"editor-gui":"playing-gui"),this.resetLevel()}async init(){if(su)throw new Error("TowerToppler initialized multiple times");su=!0,window.addEventListener("pointermove",t=>{this.move([t.clientX,t.clientY])}),window.addEventListener("pointerdown",t=>{this.down([t.clientX,t.clientY])}),window.addEventListener("pointerup",t=>{this.up([t.clientX,t.clientY])}),this.graphics=new i1;for(const t of Xa.NAMES){const e=fn.create(t);e instanceof f1&&e.toggle(this,!1)}this.gui=fn.create("playing-gui"),this.initLevel(),window.addEventListener("resize",()=>this.onResize())}initLevel(){this.state.startLevel(),this.level=p1(Ei[this.state.levelIndex]),this.graphics.reset(this.level),is.reset(this.level,t=>this.clickBoxElem(t))}toggleViewDirection(t){if(this.state.isActive)return;const e=this.state.flatDirection,n=Go.indexOf(e),i=Go[(n+t+4)%4];this.state.flatDirection=i,this.graphics.camera.startDrag(),this.graphics.camera.isSnapping=!0,this.graphics.camera.isDragging=!1,this.graphics.camera.toggleViewMode("orthographic")}clickBoxElem(t){if(!this.graphics.camera.isFlat)return;const e=this.state.flatDirection,n=this.level.sideViews[e];if(!(t in n))return;this.p2World.clear(),this.p2World.defaultContactMaterial.friction=qM,this.p2World.defaultContactMaterial.frictionStiffness=YM,this.p2World.defaultContactMaterial.frictionRelaxation=$M,this.p2World.defaultContactMaterial.restitution=KM,this.p2World.defaultContactMaterial.stiffness=ZM,this.p2World.defaultContactMaterial.relaxation=jM,this.p2World.sleepMode=Ko.ISLAND_SLEEPING;for(const m of Object.keys(this.level.sideViews[e])){const x=Number(m);if(x===t)continue;const g=this.level.sideViews[e][x],p=new $o({width:g[2],height:g[3]}),f=new jt({mass:g[2]*g[3]/100});f.allowSleep=!0,f.sleepSpeedLimit=JM,f.sleepTimeLimit=QM,f.addShape(p),f.position=g1(this.level,x,e),f.boxIndex=x,this.p2World.addBody(f)}const[i,r,o,a,c,l]=this.level.bounds,h=5,d=new $o({width:2e4,height:h}),u=new jt({mass:0});u.position=[a/2,c+h/2],u.addShape(d),this.p2World.addBody(u),is.hideAll(),this.graphics.boxes.hideAll(),this.graphics.faces.hideAll(),this.state.startActive(t),this.graphics.camera.controls.enabled=!1,Ls.hasRemovedBlock=!0,this.onResize()}update(t){if(Q_(t),Qv(t),Ao>=0&&(Ao-=t),this.state.isActive){const n=t/1e3;this.p2World.step(GM,n,HM),this.activeTime+=n;const i=this.state.flatDirection;for(const r of this.p2World.bodies){const o=r.boxIndex;if(typeof o!="number")continue;this.graphics.boxes.updateActiveBox(this.level,o,r,i);let a=5;if(i==="N"?a=5:i==="S"?a=4:i==="E"?a=1:a=0,this.graphics.faces.updateActiveFace(this.graphics.boxes.facesIm[a],o),o===this.level.targetBoxIndex&&!this.state.isToppled&&!this.state.isFailed){const c=r.interpolatedPosition,l=r.interpolatedAngle;(c[1]>this.level.bounds[4]||Math.abs(l)>wi)&&(this.state.passLevel(),this.onResize()),this.activeTime>WM&&r.velocity[0]<.001&&r.velocity[1]<.001&&(this.state.failLevel(),this.onResize())}}this.graphics.faces.update(t,this.state),sd(),this.graphics.draw();return}if(Ao<=0&&$_(),this.graphics.camera.update(t,this.state))if(this.isEditor){const n=this.graphics.boxes.selectedBoxIndex;typeof n=="number"&&n>=0?ri.showAll():ri.hideAll()}else{is.hideAll();const n=this.state.flatDirection;for(const i of Object.keys(this.level.sideViews[n])){const r=Number(i);this.graphics.faces.placeFace(r,this.graphics.boxes.boxes[r],n);const o=this.level.sideViews[n][r];is.placeElement(r,this.locateWorldRectOnScreen(o))}}this.graphics.hills.faces.update(t),this.graphics.faces.update(t,this.state),this.graphics.draw()}locateBoxOnScreen(t){const e=this.graphics.camera.getScale2d(),n=this.state.flatDirection,i=x1(this.level,t,n),r=m1(this.level,t,n),o=i[0]*e+window.innerWidth/2,a=i[1]*e+window.innerHeight/2,c=r.width*e,l=r.height*e;return[o-c/2,a-l/2,c,l]}locateWorldRectOnScreen(t){const e=this.graphics.camera.getScale2d(),[n,i,r,o]=t,a=(n+r/2)*e+window.innerWidth/2,c=(i+o/2)*e+window.innerHeight/2;return[a-r*e/2,c-o*e/2,r*e,o*e]}rebuildGraphics(){const t=this.state.levelIndex,e=Ei[t],n=this.state.flatDirection,{boxes:i,faces:r}=this.graphics;i.clear(),r.clear();const[o,a,c,l,h,d]=e.bounds;for(const[u,m]of e.boxes.entries()){const[x,g,p,f,M,_]=m;i.addBox([x,h-g-M,p,f,M,_]);const v=u===e.targetBoxIndex?Du:sa;i.setColorAt(u,v),r.addFace(i.boxes[u],n)}i.updateColors()}resetLevel(){this.initLevel(),this.onResize()}goToNextLevel(){this.state.levelIndex=(this.state.levelIndex+1)%Ei.length,this.initLevel(),this.onResize()}move(t){sd(),Ao=kM;const e=[(t[0]-this.drawOffset[0])/this.drawScale,(t[1]-this.drawOffset[1])/this.drawScale];if(this.mousePos=e,this.isEditor===!0&&!this.state.isActive){const n=t[0]/window.innerWidth*2-1,i=-(t[1]/window.innerHeight)*2+1,r=new Vp;r.setFromCamera(new zt(n,i),this.graphics.camera.camera);const o=VM(r,this.graphics.boxes);this.graphics.boxes.hoveredBoxIndex=o,this.graphics.renderer.domElement.style.cursor=o>=0?"pointer":"default"}return e}editorAddClicked(){const t=this.graphics.boxes.selectedBoxIndex;if(t>=0){const e=Ei[this.state.levelIndex],[n,i,r,o,a,c]=e.boxes[t];e.boxes.push([n,i-a,r,o,a,c]),this.graphics.boxes.selectedBoxIndex=e.boxes.length-1,this.rebuildGraphics(),this.onResize()}}editorRemoveClicked(){const t=this.graphics.boxes.selectedBoxIndex;t>=0&&Ei[this.state.levelIndex].boxes.splice(t,1),this.graphics.boxes.selectedBoxIndex=-1,this.rebuildGraphics(),this.onResize()}editorSetTargetClicked(){Ei[this.state.levelIndex].targetBoxIndex=this.graphics.boxes.selectedBoxIndex}editorSaveClicked(){const t=eS(Ei[this.state.levelIndex]);navigator.clipboard.writeText(t)}down(t){this.move(t),this.isMouseDown=!0;const e=this.graphics.boxes.hoveredBoxIndex;e>=0&&e!==this.graphics.boxes.selectedBoxIndex&&(this.graphics.boxes.selectedBoxIndex=e,ri.towerToppler=this,ri.showAll(),this.onResize())}up(t){this.isMouseDown=!1}onResize(){for(const t of Xa.NAMES){const e=fn.create(t),n=e===this.gui;for(const i in e.elements)ar(i,n);this.gui.refreshLayout(this)}this.isEditor?ar(Yu,this.graphics.boxes.selectedBoxIndex>=0):this.state.isActive?(rs(nl),this.state.isToppled?(rs(mr),oo(Ti,'<span style="color:black">Success</span>')):this.state.isFailed?(Pi(mr),oo(Ti,'<span style="color:red">Failed</span>')):(oo(Ti,"Falling..."),Pi(mr))):(Ls.hasDragged?Pi(Ti):(oo(Ti,"Drag to rotate"),rs(Ti)),Pi(nl),Pi(mr)),ar(Gu,!Ls.hasRemovedBlock),ar(wl,!this.state.isActive&&Ls.hasDragged),ar(Tl,!this.state.isActive&&Ls.hasDragged),this.graphics.onResize()}rebuildControls(){this.didBuildControls=!0,I1(this)}}function eS(s,t="  "){function e(n,i){return n===null||typeof n!="object"?JSON.stringify(n):Array.isArray(n)?n.every(l=>typeof l=="number")?"["+n.map(l=>JSON.stringify(l)).join(",")+"]":`[
`+n.map(l=>e(l,i+1)).map(l=>t.repeat(i+1)+l).join(`,
`)+`
`+t.repeat(i)+"]":`{
`+Object.keys(n).map(a=>t.repeat(i+1)+JSON.stringify(a)+": "+e(n[a],i+1)).join(`,
`)+`
`+t.repeat(i)+"}"}return e(s,0)}async function nS(){Ys.refreshConfig();const s=new tS;window.TestSupport=_1(),await s.init(),s.onResize(),navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",n=>{window.mouseXForTestSupport=n.clientX,window.mouseYForTestSupport=n.clientY;const i=window.getComputedStyle(n.target).cursor;i==="auto"?window.cursorForTestSupport="default":window.cursorForTestSupport=i,n.stopPropagation()});let t=performance.now();function e(){requestAnimationFrame(e);const n=performance.now(),i=Math.min(50,n-t);t=n,s.update(i)}e()}nS();
