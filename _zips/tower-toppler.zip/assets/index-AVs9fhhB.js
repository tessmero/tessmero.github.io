var Hf=Object.defineProperty;var Wf=(s,t,e)=>t in s?Hf(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var U=(s,t,e)=>Wf(s,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&n(o)}).observe(document,{childList:!0,subtree:!0});function e(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(i){if(i.ep)return;i.ep=!0;const r=e(i);fetch(i.href,r)}})();/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Dl="181",Gs={ROTATE:0,DOLLY:1,PAN:2},Vs={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Xf=0,Eh=1,qf=2,Fd=1,Yf=2,ri=3,zi=0,nn=1,Bn=2,di=0,Hs=1,Ah=2,wh=3,Th=4,$f=5,os=100,Kf=101,Zf=102,jf=103,Jf=104,Qf=200,tp=201,ep=202,np=203,Cc=204,Rc=205,ip=206,sp=207,rp=208,op=209,ap=210,cp=211,lp=212,hp=213,up=214,Pc=0,Lc=1,Dc=2,Xs=3,Ic=4,Uc=5,Fc=6,Nc=7,Nd=0,dp=1,fp=2,Bi=0,pp=1,mp=2,xp=3,gp=4,_p=5,vp=6,bp=7,Od=300,qs=301,Ys=302,Oc=303,Bc=304,va=306,ia=1e3,li=1001,zc=1002,gn=1003,Mp=1004,Qr=1005,cn=1006,Ca=1007,hs=1008,pi=1009,Bd=1010,zd=1011,Or=1012,Il=1013,ds=1014,qn=1015,Js=1016,Ul=1017,Fl=1018,Br=1020,Vd=35902,kd=35899,Gd=1021,Hd=1022,Vn=1023,zr=1026,Vr=1027,Nl=1028,Ol=1029,Bl=1030,zl=1031,Vl=1033,$o=33776,Ko=33777,Zo=33778,jo=33779,Vc=35840,kc=35841,Gc=35842,Hc=35843,Wc=36196,Xc=37492,qc=37496,Yc=37808,$c=37809,Kc=37810,Zc=37811,jc=37812,Jc=37813,Qc=37814,tl=37815,el=37816,nl=37817,il=37818,sl=37819,rl=37820,ol=37821,al=36492,cl=36494,ll=36495,hl=36283,ul=36284,dl=36285,fl=36286,yp=3200,Sp=3201,Ep=0,Ap=1,Ui="",En="srgb",$s="srgb-linear",sa="linear",de="srgb",vs=7680,Ch=519,wp=512,Tp=513,Cp=514,Wd=515,Rp=516,Pp=517,Lp=518,Dp=519,Rh=35044,Ph="300 es",Yn=2e3,ra=2001;function Xd(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function oa(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function Ip(){const s=oa("canvas");return s.style.display="block",s}const Lh={};function Dh(...s){const t="THREE."+s.shift();console.log(t,...s)}function kt(...s){const t="THREE."+s.shift();console.warn(t,...s)}function Pe(...s){const t="THREE."+s.shift();console.error(t,...s)}function kr(...s){const t=s.join(" ");t in Lh||(Lh[t]=!0,kt(...s))}function Up(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}class xs{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){const n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){const n=this._listeners;if(n===void 0)return;const i=n[t];if(i!==void 0){const r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){const e=this._listeners;if(e===void 0)return;const n=e[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let r=0,o=i.length;r<o;r++)i[r].call(this,t);t.target=null}}}const qe=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Ih=1234567;const Pr=Math.PI/180,Gr=180/Math.PI;function Qs(){const s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(qe[s&255]+qe[s>>8&255]+qe[s>>16&255]+qe[s>>24&255]+"-"+qe[t&255]+qe[t>>8&255]+"-"+qe[t>>16&15|64]+qe[t>>24&255]+"-"+qe[e&63|128]+qe[e>>8&255]+"-"+qe[e>>16&255]+qe[e>>24&255]+qe[n&255]+qe[n>>8&255]+qe[n>>16&255]+qe[n>>24&255]).toLowerCase()}function Zt(s,t,e){return Math.max(t,Math.min(e,s))}function kl(s,t){return(s%t+t)%t}function Fp(s,t,e,n,i){return n+(s-t)*(i-n)/(e-t)}function Np(s,t,e){return s!==t?(e-s)/(t-s):0}function Lr(s,t,e){return(1-e)*s+e*t}function Op(s,t,e,n){return Lr(s,t,1-Math.exp(-e*n))}function Bp(s,t=1){return t-Math.abs(kl(s,t*2)-t)}function zp(s,t,e){return s<=t?0:s>=e?1:(s=(s-t)/(e-t),s*s*(3-2*s))}function Vp(s,t,e){return s<=t?0:s>=e?1:(s=(s-t)/(e-t),s*s*s*(s*(s*6-15)+10))}function kp(s,t){return s+Math.floor(Math.random()*(t-s+1))}function Gp(s,t){return s+Math.random()*(t-s)}function Hp(s){return s*(.5-Math.random())}function Wp(s){s!==void 0&&(Ih=s);let t=Ih+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Xp(s){return s*Pr}function qp(s){return s*Gr}function Yp(s){return(s&s-1)===0&&s!==0}function $p(s){return Math.pow(2,Math.ceil(Math.log(s)/Math.LN2))}function Kp(s){return Math.pow(2,Math.floor(Math.log(s)/Math.LN2))}function Zp(s,t,e,n,i){const r=Math.cos,o=Math.sin,a=r(e/2),c=o(e/2),l=r((t+n)/2),h=o((t+n)/2),u=r((t-n)/2),d=o((t-n)/2),p=r((n-t)/2),x=o((n-t)/2);switch(i){case"XYX":s.set(a*h,c*u,c*d,a*l);break;case"YZY":s.set(c*d,a*h,c*u,a*l);break;case"ZXZ":s.set(c*u,c*d,a*h,a*l);break;case"XZX":s.set(a*h,c*x,c*p,a*l);break;case"YXY":s.set(c*p,a*h,c*x,a*l);break;case"ZYZ":s.set(c*x,c*p,a*h,a*l);break;default:kt("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function Bs(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function tn(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}const Gl={DEG2RAD:Pr,RAD2DEG:Gr,generateUUID:Qs,clamp:Zt,euclideanModulo:kl,mapLinear:Fp,inverseLerp:Np,lerp:Lr,damp:Op,pingpong:Bp,smoothstep:zp,smootherstep:Vp,randInt:kp,randFloat:Gp,randFloatSpread:Hp,seededRandom:Wp,degToRad:Xp,radToDeg:qp,isPowerOfTwo:Yp,ceilPowerOfTwo:$p,floorPowerOfTwo:Kp,setQuaternionFromProperEuler:Zp,normalize:tn,denormalize:Bs};class zt{constructor(t=0,e=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),zt.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Zt(this.x,t.x,e.x),this.y=Zt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Zt(this.x,t,e),this.y=Zt(this.y,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Zt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Zt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*n-o*i+t.x,this.y=r*i+o*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Vi{constructor(t=0,e=0,n=0,i=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,o,a){let c=n[i+0],l=n[i+1],h=n[i+2],u=n[i+3],d=r[o+0],p=r[o+1],x=r[o+2],g=r[o+3];if(a<=0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u;return}if(a>=1){t[e+0]=d,t[e+1]=p,t[e+2]=x,t[e+3]=g;return}if(u!==g||c!==d||l!==p||h!==x){let m=c*d+l*p+h*x+u*g;m<0&&(d=-d,p=-p,x=-x,g=-g,m=-m);let f=1-a;if(m<.9995){const y=Math.acos(m),v=Math.sin(y);f=Math.sin(f*y)/v,a=Math.sin(a*y)/v,c=c*f+d*a,l=l*f+p*a,h=h*f+x*a,u=u*f+g*a}else{c=c*f+d*a,l=l*f+p*a,h=h*f+x*a,u=u*f+g*a;const y=1/Math.sqrt(c*c+l*l+h*h+u*u);c*=y,l*=y,h*=y,u*=y}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,o){const a=n[i],c=n[i+1],l=n[i+2],h=n[i+3],u=r[o],d=r[o+1],p=r[o+2],x=r[o+3];return t[e]=a*x+h*u+c*p-l*d,t[e+1]=c*x+h*d+l*u-a*p,t[e+2]=l*x+h*p+a*d-c*u,t[e+3]=h*x-a*u-c*d-l*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,r=t._z,o=t._order,a=Math.cos,c=Math.sin,l=a(n/2),h=a(i/2),u=a(r/2),d=c(n/2),p=c(i/2),x=c(r/2);switch(o){case"XYZ":this._x=d*h*u+l*p*x,this._y=l*p*u-d*h*x,this._z=l*h*x+d*p*u,this._w=l*h*u-d*p*x;break;case"YXZ":this._x=d*h*u+l*p*x,this._y=l*p*u-d*h*x,this._z=l*h*x-d*p*u,this._w=l*h*u+d*p*x;break;case"ZXY":this._x=d*h*u-l*p*x,this._y=l*p*u+d*h*x,this._z=l*h*x+d*p*u,this._w=l*h*u-d*p*x;break;case"ZYX":this._x=d*h*u-l*p*x,this._y=l*p*u+d*h*x,this._z=l*h*x-d*p*u,this._w=l*h*u+d*p*x;break;case"YZX":this._x=d*h*u+l*p*x,this._y=l*p*u+d*h*x,this._z=l*h*x-d*p*u,this._w=l*h*u-d*p*x;break;case"XZY":this._x=d*h*u-l*p*x,this._y=l*p*u-d*h*x,this._z=l*h*x+d*p*u,this._w=l*h*u+d*p*x;break;default:kt("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],r=e[8],o=e[1],a=e[5],c=e[9],l=e[2],h=e[6],u=e[10],d=n+a+u;if(d>0){const p=.5/Math.sqrt(d+1);this._w=.25/p,this._x=(h-c)*p,this._y=(r-l)*p,this._z=(o-i)*p}else if(n>a&&n>u){const p=2*Math.sqrt(1+n-a-u);this._w=(h-c)/p,this._x=.25*p,this._y=(i+o)/p,this._z=(r+l)/p}else if(a>u){const p=2*Math.sqrt(1+a-n-u);this._w=(r-l)/p,this._x=(i+o)/p,this._y=.25*p,this._z=(c+h)/p}else{const p=2*Math.sqrt(1+u-n-a);this._w=(o-i)/p,this._x=(r+l)/p,this._y=(c+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Zt(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,r=t._z,o=t._w,a=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+o*a+i*l-r*c,this._y=i*h+o*c+r*a-n*l,this._z=r*h+o*l+n*c-i*a,this._w=o*h-n*a-i*c-r*l,this._onChangeCallback(),this}slerp(t,e){if(e<=0)return this;if(e>=1)return this.copy(t);let n=t._x,i=t._y,r=t._z,o=t._w,a=this.dot(t);a<0&&(n=-n,i=-i,r=-r,o=-o,a=-a);let c=1-e;if(a<.9995){const l=Math.acos(a),h=Math.sin(l);c=Math.sin(c*l)/h,e=Math.sin(e*l)/h,this._x=this._x*c+n*e,this._y=this._y*c+i*e,this._z=this._z*c+r*e,this._w=this._w*c+o*e,this._onChangeCallback()}else this._x=this._x*c+n*e,this._y=this._y*c+i*e,this._z=this._z*c+r*e,this._w=this._w*c+o*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class F{constructor(t=0,e=0,n=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),F.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Uh.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Uh.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=t.elements,o=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*o,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*o,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*o,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,r=t.x,o=t.y,a=t.z,c=t.w,l=2*(o*i-a*n),h=2*(a*e-r*i),u=2*(r*n-o*e);return this.x=e+c*l+o*u-a*h,this.y=n+c*h+a*l-r*u,this.z=i+c*u+r*h-o*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Zt(this.x,t.x,e.x),this.y=Zt(this.y,t.y,e.y),this.z=Zt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Zt(this.x,t,e),this.y=Zt(this.y,t,e),this.z=Zt(this.z,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Zt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,r=t.z,o=e.x,a=e.y,c=e.z;return this.x=i*c-r*a,this.y=r*o-n*c,this.z=n*a-i*o,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Ra.copy(this).projectOnVector(t),this.sub(Ra)}reflect(t){return this.sub(Ra.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Zt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Ra=new F,Uh=new Vi;class Xt{constructor(t,e,n,i,r,o,a,c,l){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),Xt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l)}set(t,e,n,i,r,o,a,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=a,h[3]=e,h[4]=r,h[5]=c,h[6]=n,h[7]=o,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[3],c=n[6],l=n[1],h=n[4],u=n[7],d=n[2],p=n[5],x=n[8],g=i[0],m=i[3],f=i[6],y=i[1],v=i[4],b=i[7],_=i[2],M=i[5],T=i[8];return r[0]=o*g+a*y+c*_,r[3]=o*m+a*v+c*M,r[6]=o*f+a*b+c*T,r[1]=l*g+h*y+u*_,r[4]=l*m+h*v+u*M,r[7]=l*f+h*b+u*T,r[2]=d*g+p*y+x*_,r[5]=d*m+p*v+x*M,r[8]=d*f+p*b+x*T,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8];return e*o*h-e*a*l-n*r*h+n*a*c+i*r*l-i*o*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=h*o-a*l,d=a*c-h*r,p=l*r-o*c,x=e*u+n*d+i*p;if(x===0)return this.set(0,0,0,0,0,0,0,0,0);const g=1/x;return t[0]=u*g,t[1]=(i*l-h*n)*g,t[2]=(a*n-i*o)*g,t[3]=d*g,t[4]=(h*e-i*c)*g,t[5]=(i*r-a*e)*g,t[6]=p*g,t[7]=(n*c-l*e)*g,t[8]=(o*e-n*r)*g,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,o,a){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*o+l*a)+o+t,-i*l,i*c,-i*(-l*o+c*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(Pa.makeScale(t,e)),this}rotate(t){return this.premultiply(Pa.makeRotation(-t)),this}translate(t,e){return this.premultiply(Pa.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const Pa=new Xt,Fh=new Xt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Nh=new Xt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function jp(){const s={enabled:!0,workingColorSpace:$s,spaces:{},convert:function(i,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===de&&(i.r=fi(i.r),i.g=fi(i.g),i.b=fi(i.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===de&&(i.r=Ws(i.r),i.g=Ws(i.g),i.b=Ws(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Ui?sa:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,o){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return kr("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),s.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return kr("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),s.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return s.define({[$s]:{primaries:t,whitePoint:n,transfer:sa,toXYZ:Fh,fromXYZ:Nh,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:En},outputColorSpaceConfig:{drawingBufferColorSpace:En}},[En]:{primaries:t,whitePoint:n,transfer:de,toXYZ:Fh,fromXYZ:Nh,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:En}}}),s}const re=jp();function fi(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Ws(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}let bs;class Jp{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{bs===void 0&&(bs=oa("canvas")),bs.width=t.width,bs.height=t.height;const i=bs.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=bs}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=oa("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let o=0;o<r.length;o++)r[o]=fi(r[o]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(fi(e[n]/255)*255):e[n]=fi(e[n]);return{data:e,width:t.width,height:t.height}}else return kt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Qp=0;class Hl{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Qp++}),this.uuid=Qs(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):e instanceof VideoFrame?t.set(e.displayHeight,e.displayWidth,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?r.push(La(i[o].image)):r.push(La(i[o]))}else r=La(i);n.url=r}return e||(t.images[this.uuid]=n),n}}function La(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Jp.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(kt("Texture: Unable to serialize Texture."),{})}let t0=0;const Da=new F;class Ze extends xs{constructor(t=Ze.DEFAULT_IMAGE,e=Ze.DEFAULT_MAPPING,n=li,i=li,r=cn,o=hs,a=Vn,c=pi,l=Ze.DEFAULT_ANISOTROPY,h=Ui){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:t0++}),this.uuid=Qs(),this.name="",this.source=new Hl(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new zt(0,0),this.repeat=new zt(1,1),this.center=new zt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Da).x}get height(){return this.source.getSize(Da).y}get depth(){return this.source.getSize(Da).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const e in t){const n=t[e];if(n===void 0){kt(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){kt(`Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Od)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ia:t.x=t.x-Math.floor(t.x);break;case li:t.x=t.x<0?0:1;break;case zc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ia:t.y=t.y-Math.floor(t.y);break;case li:t.y=t.y<0?0:1;break;case zc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Ze.DEFAULT_IMAGE=null;Ze.DEFAULT_MAPPING=Od;Ze.DEFAULT_ANISOTROPY=1;class De{constructor(t=0,e=0,n=0,i=1){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),De.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*n+o[8]*i+o[12]*r,this.y=o[1]*e+o[5]*n+o[9]*i+o[13]*r,this.z=o[2]*e+o[6]*n+o[10]*i+o[14]*r,this.w=o[3]*e+o[7]*n+o[11]*i+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r;const c=t.elements,l=c[0],h=c[4],u=c[8],d=c[1],p=c[5],x=c[9],g=c[2],m=c[6],f=c[10];if(Math.abs(h-d)<.01&&Math.abs(u-g)<.01&&Math.abs(x-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+g)<.1&&Math.abs(x+m)<.1&&Math.abs(l+p+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const v=(l+1)/2,b=(p+1)/2,_=(f+1)/2,M=(h+d)/4,T=(u+g)/4,P=(x+m)/4;return v>b&&v>_?v<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(v),i=M/n,r=T/n):b>_?b<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(b),n=M/i,r=P/i):_<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(_),n=T/r,i=P/r),this.set(n,i,r,e),this}let y=Math.sqrt((m-x)*(m-x)+(u-g)*(u-g)+(d-h)*(d-h));return Math.abs(y)<.001&&(y=1),this.x=(m-x)/y,this.y=(u-g)/y,this.z=(d-h)/y,this.w=Math.acos((l+p+f-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Zt(this.x,t.x,e.x),this.y=Zt(this.y,t.y,e.y),this.z=Zt(this.z,t.z,e.z),this.w=Zt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Zt(this.x,t,e),this.y=Zt(this.y,t,e),this.z=Zt(this.z,t,e),this.w=Zt(this.w,t,e),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Zt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class e0 extends xs{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:cn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new De(0,0,t,e),this.scissorTest=!1,this.viewport=new De(0,0,t,e);const i={width:t,height:e,depth:n.depth},r=new Ze(i);this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(t={}){const e={minFilter:cn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n,this.textures[i].isData3DTexture!==!0&&(this.textures[i].isArrayTexture=this.textures[i].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;const i=Object.assign({},t.textures[e].image);this.textures[e].source=new Hl(i)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class fs extends e0{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class qd extends Ze{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=li,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class n0 extends Ze{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=li,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class gs{constructor(t=new F(1/0,1/0,1/0),e=new F(-1/0,-1/0,-1/0)){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Ln.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Ln.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Ln.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Ln):Ln.fromBufferAttribute(r,o),Ln.applyMatrix4(t.matrixWorld),this.expandByPoint(Ln);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),to.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),to.copy(n.boundingBox)),to.applyMatrix4(t.matrixWorld),this.union(to)}const i=t.children;for(let r=0,o=i.length;r<o;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Ln),Ln.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(ir),eo.subVectors(this.max,ir),Ms.subVectors(t.a,ir),ys.subVectors(t.b,ir),Ss.subVectors(t.c,ir),gi.subVectors(ys,Ms),_i.subVectors(Ss,ys),qi.subVectors(Ms,Ss);let e=[0,-gi.z,gi.y,0,-_i.z,_i.y,0,-qi.z,qi.y,gi.z,0,-gi.x,_i.z,0,-_i.x,qi.z,0,-qi.x,-gi.y,gi.x,0,-_i.y,_i.x,0,-qi.y,qi.x,0];return!Ia(e,Ms,ys,Ss,eo)||(e=[1,0,0,0,1,0,0,0,1],!Ia(e,Ms,ys,Ss,eo))?!1:(no.crossVectors(gi,_i),e=[no.x,no.y,no.z],Ia(e,Ms,ys,Ss,eo))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Ln).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Ln).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(jn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),jn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),jn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),jn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),jn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),jn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),jn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),jn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(jn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const jn=[new F,new F,new F,new F,new F,new F,new F,new F],Ln=new F,to=new gs,Ms=new F,ys=new F,Ss=new F,gi=new F,_i=new F,qi=new F,ir=new F,eo=new F,no=new F,Yi=new F;function Ia(s,t,e,n,i){for(let r=0,o=s.length-3;r<=o;r+=3){Yi.fromArray(s,r);const a=i.x*Math.abs(Yi.x)+i.y*Math.abs(Yi.y)+i.z*Math.abs(Yi.z),c=t.dot(Yi),l=e.dot(Yi),h=n.dot(Yi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>a)return!1}return!0}const i0=new gs,sr=new F,Ua=new F;class Kr{constructor(t=new F,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):i0.setFromPoints(t).getCenter(n);let i=0;for(let r=0,o=t.length;r<o;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;sr.subVectors(t,this.center);const e=sr.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(sr,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Ua.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(sr.copy(t.center).add(Ua)),this.expandByPoint(sr.copy(t.center).sub(Ua))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}const Jn=new F,Fa=new F,io=new F,vi=new F,Na=new F,so=new F,Oa=new F;let Wl=class{constructor(t=new F,e=new F(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Jn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=Jn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Jn.copy(this.origin).addScaledVector(this.direction,e),Jn.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){Fa.copy(t).add(e).multiplyScalar(.5),io.copy(e).sub(t).normalize(),vi.copy(this.origin).sub(Fa);const r=t.distanceTo(e)*.5,o=-this.direction.dot(io),a=vi.dot(this.direction),c=-vi.dot(io),l=vi.lengthSq(),h=Math.abs(1-o*o);let u,d,p,x;if(h>0)if(u=o*c-a,d=o*a-c,x=r*h,u>=0)if(d>=-x)if(d<=x){const g=1/h;u*=g,d*=g,p=u*(u+o*d+2*a)+d*(o*u+d+2*c)+l}else d=r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*c)+l;else d=-r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*c)+l;else d<=-x?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-c),r),p=-u*u+d*(d+2*c)+l):d<=x?(u=0,d=Math.min(Math.max(-r,-c),r),p=d*(d+2*c)+l):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-c),r),p=-u*u+d*(d+2*c)+l);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),p=-u*u+d*(d+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(Fa).addScaledVector(io,d),p}intersectSphere(t,e){Jn.subVectors(t.center,this.origin);const n=Jn.dot(this.direction),i=Jn.dot(Jn)-n*n,r=t.radius*t.radius;if(i>r)return null;const o=Math.sqrt(r-i),a=n-o,c=n+o;return c<0?null:a<0?this.at(c,e):this.at(a,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,o,a,c;const l=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return l>=0?(n=(t.min.x-d.x)*l,i=(t.max.x-d.x)*l):(n=(t.max.x-d.x)*l,i=(t.min.x-d.x)*l),h>=0?(r=(t.min.y-d.y)*h,o=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,o=(t.min.y-d.y)*h),n>o||r>i||((r>n||isNaN(n))&&(n=r),(o<i||isNaN(i))&&(i=o),u>=0?(a=(t.min.z-d.z)*u,c=(t.max.z-d.z)*u):(a=(t.max.z-d.z)*u,c=(t.min.z-d.z)*u),n>c||a>i)||((a>n||n!==n)&&(n=a),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,Jn)!==null}intersectTriangle(t,e,n,i,r){Na.subVectors(e,t),so.subVectors(n,t),Oa.crossVectors(Na,so);let o=this.direction.dot(Oa),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;vi.subVectors(this.origin,t);const c=a*this.direction.dot(so.crossVectors(vi,so));if(c<0)return null;const l=a*this.direction.dot(Na.cross(vi));if(l<0||c+l>o)return null;const h=-a*vi.dot(Oa);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}};class _e{constructor(t,e,n,i,r,o,a,c,l,h,u,d,p,x,g,m){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),_e.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,o,a,c,l,h,u,d,p,x,g,m)}set(t,e,n,i,r,o,a,c,l,h,u,d,p,x,g,m){const f=this.elements;return f[0]=t,f[4]=e,f[8]=n,f[12]=i,f[1]=r,f[5]=o,f[9]=a,f[13]=c,f[2]=l,f[6]=h,f[10]=u,f[14]=d,f[3]=p,f[7]=x,f[11]=g,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new _e().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/Es.setFromMatrixColumn(t,0).length(),r=1/Es.setFromMatrixColumn(t,1).length(),o=1/Es.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*o,e[9]=n[9]*o,e[10]=n[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,r=t.z,o=Math.cos(n),a=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){const d=o*h,p=o*u,x=a*h,g=a*u;e[0]=c*h,e[4]=-c*u,e[8]=l,e[1]=p+x*l,e[5]=d-g*l,e[9]=-a*c,e[2]=g-d*l,e[6]=x+p*l,e[10]=o*c}else if(t.order==="YXZ"){const d=c*h,p=c*u,x=l*h,g=l*u;e[0]=d+g*a,e[4]=x*a-p,e[8]=o*l,e[1]=o*u,e[5]=o*h,e[9]=-a,e[2]=p*a-x,e[6]=g+d*a,e[10]=o*c}else if(t.order==="ZXY"){const d=c*h,p=c*u,x=l*h,g=l*u;e[0]=d-g*a,e[4]=-o*u,e[8]=x+p*a,e[1]=p+x*a,e[5]=o*h,e[9]=g-d*a,e[2]=-o*l,e[6]=a,e[10]=o*c}else if(t.order==="ZYX"){const d=o*h,p=o*u,x=a*h,g=a*u;e[0]=c*h,e[4]=x*l-p,e[8]=d*l+g,e[1]=c*u,e[5]=g*l+d,e[9]=p*l-x,e[2]=-l,e[6]=a*c,e[10]=o*c}else if(t.order==="YZX"){const d=o*c,p=o*l,x=a*c,g=a*l;e[0]=c*h,e[4]=g-d*u,e[8]=x*u+p,e[1]=u,e[5]=o*h,e[9]=-a*h,e[2]=-l*h,e[6]=p*u+x,e[10]=d-g*u}else if(t.order==="XZY"){const d=o*c,p=o*l,x=a*c,g=a*l;e[0]=c*h,e[4]=-u,e[8]=l*h,e[1]=d*u+g,e[5]=o*h,e[9]=p*u-x,e[2]=x*u-p,e[6]=a*h,e[10]=g*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(s0,t,r0)}lookAt(t,e,n){const i=this.elements;return pn.subVectors(t,e),pn.lengthSq()===0&&(pn.z=1),pn.normalize(),bi.crossVectors(n,pn),bi.lengthSq()===0&&(Math.abs(n.z)===1?pn.x+=1e-4:pn.z+=1e-4,pn.normalize(),bi.crossVectors(n,pn)),bi.normalize(),ro.crossVectors(pn,bi),i[0]=bi.x,i[4]=ro.x,i[8]=pn.x,i[1]=bi.y,i[5]=ro.y,i[9]=pn.y,i[2]=bi.z,i[6]=ro.z,i[10]=pn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,r=this.elements,o=n[0],a=n[4],c=n[8],l=n[12],h=n[1],u=n[5],d=n[9],p=n[13],x=n[2],g=n[6],m=n[10],f=n[14],y=n[3],v=n[7],b=n[11],_=n[15],M=i[0],T=i[4],P=i[8],A=i[12],E=i[1],R=i[5],I=i[9],z=i[13],X=i[2],H=i[6],K=i[10],G=i[14],V=i[3],$=i[7],st=i[11],St=i[15];return r[0]=o*M+a*E+c*X+l*V,r[4]=o*T+a*R+c*H+l*$,r[8]=o*P+a*I+c*K+l*st,r[12]=o*A+a*z+c*G+l*St,r[1]=h*M+u*E+d*X+p*V,r[5]=h*T+u*R+d*H+p*$,r[9]=h*P+u*I+d*K+p*st,r[13]=h*A+u*z+d*G+p*St,r[2]=x*M+g*E+m*X+f*V,r[6]=x*T+g*R+m*H+f*$,r[10]=x*P+g*I+m*K+f*st,r[14]=x*A+g*z+m*G+f*St,r[3]=y*M+v*E+b*X+_*V,r[7]=y*T+v*R+b*H+_*$,r[11]=y*P+v*I+b*K+_*st,r[15]=y*A+v*z+b*G+_*St,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],o=t[1],a=t[5],c=t[9],l=t[13],h=t[2],u=t[6],d=t[10],p=t[14],x=t[3],g=t[7],m=t[11],f=t[15];return x*(+r*c*u-i*l*u-r*a*d+n*l*d+i*a*p-n*c*p)+g*(+e*c*p-e*l*d+r*o*d-i*o*p+i*l*h-r*c*h)+m*(+e*l*u-e*a*p-r*o*u+n*o*p+r*a*h-n*l*h)+f*(-i*a*h-e*c*u+e*a*d+i*o*u-n*o*d+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],o=t[4],a=t[5],c=t[6],l=t[7],h=t[8],u=t[9],d=t[10],p=t[11],x=t[12],g=t[13],m=t[14],f=t[15],y=u*m*l-g*d*l+g*c*p-a*m*p-u*c*f+a*d*f,v=x*d*l-h*m*l-x*c*p+o*m*p+h*c*f-o*d*f,b=h*g*l-x*u*l+x*a*p-o*g*p-h*a*f+o*u*f,_=x*u*c-h*g*c-x*a*d+o*g*d+h*a*m-o*u*m,M=e*y+n*v+i*b+r*_;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const T=1/M;return t[0]=y*T,t[1]=(g*d*r-u*m*r-g*i*p+n*m*p+u*i*f-n*d*f)*T,t[2]=(a*m*r-g*c*r+g*i*l-n*m*l-a*i*f+n*c*f)*T,t[3]=(u*c*r-a*d*r-u*i*l+n*d*l+a*i*p-n*c*p)*T,t[4]=v*T,t[5]=(h*m*r-x*d*r+x*i*p-e*m*p-h*i*f+e*d*f)*T,t[6]=(x*c*r-o*m*r-x*i*l+e*m*l+o*i*f-e*c*f)*T,t[7]=(o*d*r-h*c*r+h*i*l-e*d*l-o*i*p+e*c*p)*T,t[8]=b*T,t[9]=(x*u*r-h*g*r-x*n*p+e*g*p+h*n*f-e*u*f)*T,t[10]=(o*g*r-x*a*r+x*n*l-e*g*l-o*n*f+e*a*f)*T,t[11]=(h*a*r-o*u*r-h*n*l+e*u*l+o*n*p-e*a*p)*T,t[12]=_*T,t[13]=(h*g*i-x*u*i+x*n*d-e*g*d-h*n*m+e*u*m)*T,t[14]=(x*a*i-o*g*i-x*n*c+e*g*c+o*n*m-e*a*m)*T,t[15]=(o*u*i-h*a*i+h*n*c-e*u*c-o*n*d+e*a*d)*T,this}scale(t){const e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),r=1-n,o=t.x,a=t.y,c=t.z,l=r*o,h=r*a;return this.set(l*o+n,l*a-i*c,l*c+i*a,0,l*a+i*c,h*a+n,h*c-i*o,0,l*c-i*a,h*c+i*o,r*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,o){return this.set(1,n,r,0,t,1,o,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,r=e._x,o=e._y,a=e._z,c=e._w,l=r+r,h=o+o,u=a+a,d=r*l,p=r*h,x=r*u,g=o*h,m=o*u,f=a*u,y=c*l,v=c*h,b=c*u,_=n.x,M=n.y,T=n.z;return i[0]=(1-(g+f))*_,i[1]=(p+b)*_,i[2]=(x-v)*_,i[3]=0,i[4]=(p-b)*M,i[5]=(1-(d+f))*M,i[6]=(m+y)*M,i[7]=0,i[8]=(x+v)*T,i[9]=(m-y)*T,i[10]=(1-(d+g))*T,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let r=Es.set(i[0],i[1],i[2]).length();const o=Es.set(i[4],i[5],i[6]).length(),a=Es.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],Dn.copy(this);const l=1/r,h=1/o,u=1/a;return Dn.elements[0]*=l,Dn.elements[1]*=l,Dn.elements[2]*=l,Dn.elements[4]*=h,Dn.elements[5]*=h,Dn.elements[6]*=h,Dn.elements[8]*=u,Dn.elements[9]*=u,Dn.elements[10]*=u,e.setFromRotationMatrix(Dn),n.x=r,n.y=o,n.z=a,this}makePerspective(t,e,n,i,r,o,a=Yn,c=!1){const l=this.elements,h=2*r/(e-t),u=2*r/(n-i),d=(e+t)/(e-t),p=(n+i)/(n-i);let x,g;if(c)x=r/(o-r),g=o*r/(o-r);else if(a===Yn)x=-(o+r)/(o-r),g=-2*o*r/(o-r);else if(a===ra)x=-o/(o-r),g=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=u,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=x,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,o,a=Yn,c=!1){const l=this.elements,h=2/(e-t),u=2/(n-i),d=-(e+t)/(e-t),p=-(n+i)/(n-i);let x,g;if(c)x=1/(o-r),g=o/(o-r);else if(a===Yn)x=-2/(o-r),g=-(o+r)/(o-r);else if(a===ra)x=-1/(o-r),g=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=h,l[4]=0,l[8]=0,l[12]=d,l[1]=0,l[5]=u,l[9]=0,l[13]=p,l[2]=0,l[6]=0,l[10]=x,l[14]=g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const Es=new F,Dn=new _e,s0=new F(0,0,0),r0=new F(1,1,1),bi=new F,ro=new F,pn=new F,Oh=new _e,Bh=new Vi;class mi{constructor(t=0,e=0,n=0,i=mi.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,r=i[0],o=i[4],a=i[8],c=i[1],l=i[5],h=i[9],u=i[2],d=i[6],p=i[10];switch(e){case"XYZ":this._y=Math.asin(Zt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Zt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,p),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Zt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Zt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,p),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(Zt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,p));break;case"XZY":this._z=Math.asin(-Zt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,l),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,p),this._y=0);break;default:kt("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Oh.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Oh,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Bh.setFromEuler(this),this.setFromQuaternion(Bh,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}mi.DEFAULT_ORDER="XYZ";class Xl{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let o0=0;const zh=new F,As=new Vi,Qn=new _e,oo=new F,rr=new F,a0=new F,c0=new Vi,Vh=new F(1,0,0),kh=new F(0,1,0),Gh=new F(0,0,1),Hh={type:"added"},l0={type:"removed"},ws={type:"childadded",child:null},Ba={type:"childremoved",child:null};class oe extends xs{constructor(){super(),this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isObject3D=!0,Object.defineProperty(this,"id",{value:o0++}),this.uuid=Qs(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=oe.DEFAULT_UP.clone();const t=new F,e=new mi,n=new Vi,i=new F(1,1,1);function r(){n.setFromEuler(e,!1)}function o(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new _e},normalMatrix:{value:new Xt}}),this.matrix=new _e,this.matrixWorld=new _e,this.matrixAutoUpdate=oe.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=oe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Xl,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return As.setFromAxisAngle(t,e),this.quaternion.multiply(As),this}rotateOnWorldAxis(t,e){return As.setFromAxisAngle(t,e),this.quaternion.premultiply(As),this}rotateX(t){return this.rotateOnAxis(Vh,t)}rotateY(t){return this.rotateOnAxis(kh,t)}rotateZ(t){return this.rotateOnAxis(Gh,t)}translateOnAxis(t,e){return zh.copy(t).applyQuaternion(this.quaternion),this.position.add(zh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Vh,t)}translateY(t){return this.translateOnAxis(kh,t)}translateZ(t){return this.translateOnAxis(Gh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Qn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?oo.copy(t):oo.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),rr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Qn.lookAt(rr,oo,this.up):Qn.lookAt(oo,rr,this.up),this.quaternion.setFromRotationMatrix(Qn),i&&(Qn.extractRotation(i.matrixWorld),As.setFromRotationMatrix(Qn),this.quaternion.premultiply(As.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(Pe("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Hh),ws.child=t,this.dispatchEvent(ws),ws.child=null):Pe("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(l0),Ba.child=t,this.dispatchEvent(Ba),Ba.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Qn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Qn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Qn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Hh),ws.child=t,this.dispatchEvent(ws),ws.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const o=this.children[n].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,t,a0),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,c0,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const i=this.children;for(let r=0,o=i.length;r<o;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(a=>({...a})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const c=a.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const u=c[l];r(t.shapes,u)}else r(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(r(t.materials,this.material[c]));i.material=a}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){const c=this.animations[a];i.animations.push(r(t.animations,c))}}if(e){const a=o(t.geometries),c=o(t.materials),l=o(t.textures),h=o(t.images),u=o(t.shapes),d=o(t.skeletons),p=o(t.animations),x=o(t.nodes);a.length>0&&(n.geometries=a),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),p.length>0&&(n.animations=p),x.length>0&&(n.nodes=x)}return n.object=i,n;function o(a){const c=[];for(const l in a){const h=a[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}oe.DEFAULT_UP=new F(0,1,0);oe.DEFAULT_MATRIX_AUTO_UPDATE=!0;oe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const In=new F,ti=new F,za=new F,ei=new F,Ts=new F,Cs=new F,Wh=new F,Va=new F,ka=new F,Ga=new F,Ha=new De,Wa=new De,Xa=new De;class zn{constructor(t=new F,e=new F,n=new F){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),In.subVectors(t,e),i.cross(In);const r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){In.subVectors(i,e),ti.subVectors(n,e),za.subVectors(t,e);const o=In.dot(In),a=In.dot(ti),c=In.dot(za),l=ti.dot(ti),h=ti.dot(za),u=o*l-a*a;if(u===0)return r.set(0,0,0),null;const d=1/u,p=(l*c-a*h)*d,x=(o*h-a*c)*d;return r.set(1-p-x,x,p)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,ei)===null?!1:ei.x>=0&&ei.y>=0&&ei.x+ei.y<=1}static getInterpolation(t,e,n,i,r,o,a,c){return this.getBarycoord(t,e,n,i,ei)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,ei.x),c.addScaledVector(o,ei.y),c.addScaledVector(a,ei.z),c)}static getInterpolatedAttribute(t,e,n,i,r,o){return Ha.setScalar(0),Wa.setScalar(0),Xa.setScalar(0),Ha.fromBufferAttribute(t,e),Wa.fromBufferAttribute(t,n),Xa.fromBufferAttribute(t,i),o.setScalar(0),o.addScaledVector(Ha,r.x),o.addScaledVector(Wa,r.y),o.addScaledVector(Xa,r.z),o}static isFrontFacing(t,e,n,i){return In.subVectors(n,e),ti.subVectors(t,e),In.cross(ti).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return In.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),In.cross(ti).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return zn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return zn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return zn.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return zn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return zn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,r=this.c;let o,a;Ts.subVectors(i,n),Cs.subVectors(r,n),Va.subVectors(t,n);const c=Ts.dot(Va),l=Cs.dot(Va);if(c<=0&&l<=0)return e.copy(n);ka.subVectors(t,i);const h=Ts.dot(ka),u=Cs.dot(ka);if(h>=0&&u<=h)return e.copy(i);const d=c*u-h*l;if(d<=0&&c>=0&&h<=0)return o=c/(c-h),e.copy(n).addScaledVector(Ts,o);Ga.subVectors(t,r);const p=Ts.dot(Ga),x=Cs.dot(Ga);if(x>=0&&p<=x)return e.copy(r);const g=p*l-c*x;if(g<=0&&l>=0&&x<=0)return a=l/(l-x),e.copy(n).addScaledVector(Cs,a);const m=h*x-p*u;if(m<=0&&u-h>=0&&p-x>=0)return Wh.subVectors(r,i),a=(u-h)/(u-h+(p-x)),e.copy(i).addScaledVector(Wh,a);const f=1/(m+g+d);return o=g*f,a=d*f,e.copy(n).addScaledVector(Ts,o).addScaledVector(Cs,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const Yd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Mi={h:0,s:0,l:0},ao={h:0,s:0,l:0};function qa(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}class ee{constructor(t,e,n){return this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=En){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,re.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=re.workingColorSpace){return this.r=t,this.g=e,this.b=n,re.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=re.workingColorSpace){if(t=kl(t,1),e=Zt(e,0,1),n=Zt(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,o=2*n-r;this.r=qa(o,r,t+1/3),this.g=qa(o,r,t),this.b=qa(o,r,t-1/3)}return re.colorSpaceToWorking(this,i),this}setStyle(t,e=En){function n(r){r!==void 0&&parseFloat(r)<1&&kt("Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:kt("Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=i[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);kt("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=En){const n=Yd[t.toLowerCase()];return n!==void 0?this.setHex(n,e):kt("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=fi(t.r),this.g=fi(t.g),this.b=fi(t.b),this}copyLinearToSRGB(t){return this.r=Ws(t.r),this.g=Ws(t.g),this.b=Ws(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=En){return re.workingToColorSpace(Ye.copy(this),t),Math.round(Zt(Ye.r*255,0,255))*65536+Math.round(Zt(Ye.g*255,0,255))*256+Math.round(Zt(Ye.b*255,0,255))}getHexString(t=En){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=re.workingColorSpace){re.workingToColorSpace(Ye.copy(this),e);const n=Ye.r,i=Ye.g,r=Ye.b,o=Math.max(n,i,r),a=Math.min(n,i,r);let c,l;const h=(a+o)/2;if(a===o)c=0,l=0;else{const u=o-a;switch(l=h<=.5?u/(o+a):u/(2-o-a),o){case n:c=(i-r)/u+(i<r?6:0);break;case i:c=(r-n)/u+2;break;case r:c=(n-i)/u+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=re.workingColorSpace){return re.workingToColorSpace(Ye.copy(this),e),t.r=Ye.r,t.g=Ye.g,t.b=Ye.b,t}getStyle(t=En){re.workingToColorSpace(Ye.copy(this),t);const e=Ye.r,n=Ye.g,i=Ye.b;return t!==En?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Mi),this.setHSL(Mi.h+t,Mi.s+e,Mi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Mi),t.getHSL(ao);const n=Lr(Mi.h,ao.h,e),i=Lr(Mi.s,ao.s,e),r=Lr(Mi.l,ao.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ye=new ee;ee.NAMES=Yd;let h0=0,ba=class extends xs{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:h0++}),this.uuid=Qs(),this.name="",this.type="Material",this.blending=Hs,this.side=zi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Cc,this.blendDst=Rc,this.blendEquation=os,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ee(0,0,0),this.blendAlpha=0,this.depthFunc=Xs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Ch,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=vs,this.stencilZFail=vs,this.stencilZPass=vs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){kt(`Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){kt(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Hs&&(n.blending=this.blending),this.side!==zi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Cc&&(n.blendSrc=this.blendSrc),this.blendDst!==Rc&&(n.blendDst=this.blendDst),this.blendEquation!==os&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Xs&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Ch&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==vs&&(n.stencilFail=this.stencilFail),this.stencilZFail!==vs&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==vs&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){const o=[];for(const a in r){const c=r[a];delete c.metadata,o.push(c)}return o}if(e){const r=i(t.textures),o=i(t.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}};class sn extends ba{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ee(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new mi,this.combine=Nd,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Ie=new F,co=new zt;let u0=0;class _n{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:u0++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Rh,this.updateRanges=[],this.gpuType=qn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)co.fromBufferAttribute(this,e),co.applyMatrix3(t),this.setXY(e,co.x,co.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyMatrix3(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyMatrix4(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.applyNormalMatrix(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ie.fromBufferAttribute(this,e),Ie.transformDirection(t),this.setXYZ(e,Ie.x,Ie.y,Ie.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Bs(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=tn(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Bs(e,this.array)),e}setX(t,e){return this.normalized&&(e=tn(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Bs(e,this.array)),e}setY(t,e){return this.normalized&&(e=tn(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Bs(e,this.array)),e}setZ(t,e){return this.normalized&&(e=tn(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Bs(e,this.array)),e}setW(t,e){return this.normalized&&(e=tn(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=tn(e,this.array),n=tn(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=tn(e,this.array),n=tn(n,this.array),i=tn(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=tn(e,this.array),n=tn(n,this.array),i=tn(i,this.array),r=tn(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Rh&&(t.usage=this.usage),t}}class $d extends _n{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class Kd extends _n{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class je extends _n{constructor(t,e,n){super(new Float32Array(t),e,n)}}let d0=0;const bn=new _e,Ya=new oe,Rs=new F,mn=new gs,or=new gs,Oe=new F;class Rn extends xs{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:d0++}),this.uuid=Qs(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Xd(t)?Kd:$d)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Xt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return bn.makeRotationFromQuaternion(t),this.applyMatrix4(bn),this}rotateX(t){return bn.makeRotationX(t),this.applyMatrix4(bn),this}rotateY(t){return bn.makeRotationY(t),this.applyMatrix4(bn),this}rotateZ(t){return bn.makeRotationZ(t),this.applyMatrix4(bn),this}translate(t,e,n){return bn.makeTranslation(t,e,n),this.applyMatrix4(bn),this}scale(t,e,n){return bn.makeScale(t,e,n),this.applyMatrix4(bn),this}lookAt(t){return Ya.lookAt(t),Ya.updateMatrix(),this.applyMatrix4(Ya.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Rs).negate(),this.translate(Rs.x,Rs.y,Rs.z),this}setFromPoints(t){const e=this.getAttribute("position");if(e===void 0){const n=[];for(let i=0,r=t.length;i<r;i++){const o=t[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new je(n,3))}else{const n=Math.min(t.length,e.count);for(let i=0;i<n;i++){const r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&kt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new gs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Pe("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new F(-1/0,-1/0,-1/0),new F(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const r=e[n];mn.setFromBufferAttribute(r),this.morphTargetsRelative?(Oe.addVectors(this.boundingBox.min,mn.min),this.boundingBox.expandByPoint(Oe),Oe.addVectors(this.boundingBox.max,mn.max),this.boundingBox.expandByPoint(Oe)):(this.boundingBox.expandByPoint(mn.min),this.boundingBox.expandByPoint(mn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Pe('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Kr);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Pe("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new F,1/0);return}if(t){const n=this.boundingSphere.center;if(mn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){const a=e[r];or.setFromBufferAttribute(a),this.morphTargetsRelative?(Oe.addVectors(mn.min,or.min),mn.expandByPoint(Oe),Oe.addVectors(mn.max,or.max),mn.expandByPoint(Oe)):(mn.expandByPoint(or.min),mn.expandByPoint(or.max))}mn.getCenter(n);let i=0;for(let r=0,o=t.count;r<o;r++)Oe.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Oe));if(e)for(let r=0,o=e.length;r<o;r++){const a=e[r],c=this.morphTargetsRelative;for(let l=0,h=a.count;l<h;l++)Oe.fromBufferAttribute(a,l),c&&(Rs.fromBufferAttribute(t,l),Oe.add(Rs)),i=Math.max(i,n.distanceToSquared(Oe))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&Pe('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){Pe("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new _n(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],c=[];for(let P=0;P<n.count;P++)a[P]=new F,c[P]=new F;const l=new F,h=new F,u=new F,d=new zt,p=new zt,x=new zt,g=new F,m=new F;function f(P,A,E){l.fromBufferAttribute(n,P),h.fromBufferAttribute(n,A),u.fromBufferAttribute(n,E),d.fromBufferAttribute(r,P),p.fromBufferAttribute(r,A),x.fromBufferAttribute(r,E),h.sub(l),u.sub(l),p.sub(d),x.sub(d);const R=1/(p.x*x.y-x.x*p.y);isFinite(R)&&(g.copy(h).multiplyScalar(x.y).addScaledVector(u,-p.y).multiplyScalar(R),m.copy(u).multiplyScalar(p.x).addScaledVector(h,-x.x).multiplyScalar(R),a[P].add(g),a[A].add(g),a[E].add(g),c[P].add(m),c[A].add(m),c[E].add(m))}let y=this.groups;y.length===0&&(y=[{start:0,count:t.count}]);for(let P=0,A=y.length;P<A;++P){const E=y[P],R=E.start,I=E.count;for(let z=R,X=R+I;z<X;z+=3)f(t.getX(z+0),t.getX(z+1),t.getX(z+2))}const v=new F,b=new F,_=new F,M=new F;function T(P){_.fromBufferAttribute(i,P),M.copy(_);const A=a[P];v.copy(A),v.sub(_.multiplyScalar(_.dot(A))).normalize(),b.crossVectors(M,A);const R=b.dot(c[P])<0?-1:1;o.setXYZW(P,v.x,v.y,v.z,R)}for(let P=0,A=y.length;P<A;++P){const E=y[P],R=E.start,I=E.count;for(let z=R,X=R+I;z<X;z+=3)T(t.getX(z+0)),T(t.getX(z+1)),T(t.getX(z+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new _n(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,p=n.count;d<p;d++)n.setXYZ(d,0,0,0);const i=new F,r=new F,o=new F,a=new F,c=new F,l=new F,h=new F,u=new F;if(t)for(let d=0,p=t.count;d<p;d+=3){const x=t.getX(d+0),g=t.getX(d+1),m=t.getX(d+2);i.fromBufferAttribute(e,x),r.fromBufferAttribute(e,g),o.fromBufferAttribute(e,m),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),a.fromBufferAttribute(n,x),c.fromBufferAttribute(n,g),l.fromBufferAttribute(n,m),a.add(h),c.add(h),l.add(h),n.setXYZ(x,a.x,a.y,a.z),n.setXYZ(g,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let d=0,p=e.count;d<p;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),o.fromBufferAttribute(e,d+2),h.subVectors(o,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Oe.fromBufferAttribute(t,e),Oe.normalize(),t.setXYZ(e,Oe.x,Oe.y,Oe.z)}toNonIndexed(){function t(a,c){const l=a.array,h=a.itemSize,u=a.normalized,d=new l.constructor(c.length*h);let p=0,x=0;for(let g=0,m=c.length;g<m;g++){a.isInterleavedBufferAttribute?p=c[g]*a.data.stride+a.offset:p=c[g]*h;for(let f=0;f<h;f++)d[x++]=l[p++]}return new _n(d,h,u)}if(this.index===null)return kt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Rn,n=this.index.array,i=this.attributes;for(const a in i){const c=i[a],l=t(c,n);e.setAttribute(a,l)}const r=this.morphAttributes;for(const a in r){const c=[],l=r[a];for(let h=0,u=l.length;h<u;h++){const d=l[h],p=t(d,n);c.push(p)}e.morphAttributes[a]=c}e.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,c=o.length;a<c;a++){const l=o[a];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let u=0,d=l.length;u<d;u++){const p=l[u];h.push(p.toJSON(t.data))}h.length>0&&(i[c]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(t.data.boundingSphere=a.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone());const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const r=t.morphAttributes;for(const l in r){const h=[],u=r[l];for(let d=0,p=u.length;d<p;d++)h.push(u[d].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const o=t.groups;for(let l=0,h=o.length;l<h;l++){const u=o[l];this.addGroup(u.start,u.count,u.materialIndex)}const a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Xh=new _e,$i=new Wl,lo=new Kr,qh=new F,ho=new F,uo=new F,fo=new F,$a=new F,po=new F,Yh=new F,mo=new F;class hn extends oe{constructor(t=new Rn,e=new sn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=i.length;r<o;r++){const a=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const a=this.morphTargetInfluences;if(r&&a){po.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const h=a[c],u=r[c];h!==0&&($a.fromBufferAttribute(u,t),o?po.addScaledVector($a,h):po.addScaledVector($a.sub(e),h))}e.add(po)}return e}raycast(t,e){const n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),lo.copy(n.boundingSphere),lo.applyMatrix4(r),$i.copy(t.ray).recast(t.near),!(lo.containsPoint($i.origin)===!1&&($i.intersectSphere(lo,qh)===null||$i.origin.distanceToSquared(qh)>(t.far-t.near)**2))&&(Xh.copy(r).invert(),$i.copy(t.ray).applyMatrix4(Xh),!(n.boundingBox!==null&&$i.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,$i)))}_computeIntersections(t,e,n){let i;const r=this.geometry,o=this.material,a=r.index,c=r.attributes.position,l=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,p=r.drawRange;if(a!==null)if(Array.isArray(o))for(let x=0,g=d.length;x<g;x++){const m=d[x],f=o[m.materialIndex],y=Math.max(m.start,p.start),v=Math.min(a.count,Math.min(m.start+m.count,p.start+p.count));for(let b=y,_=v;b<_;b+=3){const M=a.getX(b),T=a.getX(b+1),P=a.getX(b+2);i=xo(this,f,t,n,l,h,u,M,T,P),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const x=Math.max(0,p.start),g=Math.min(a.count,p.start+p.count);for(let m=x,f=g;m<f;m+=3){const y=a.getX(m),v=a.getX(m+1),b=a.getX(m+2);i=xo(this,o,t,n,l,h,u,y,v,b),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(o))for(let x=0,g=d.length;x<g;x++){const m=d[x],f=o[m.materialIndex],y=Math.max(m.start,p.start),v=Math.min(c.count,Math.min(m.start+m.count,p.start+p.count));for(let b=y,_=v;b<_;b+=3){const M=b,T=b+1,P=b+2;i=xo(this,f,t,n,l,h,u,M,T,P),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const x=Math.max(0,p.start),g=Math.min(c.count,p.start+p.count);for(let m=x,f=g;m<f;m+=3){const y=m,v=m+1,b=m+2;i=xo(this,o,t,n,l,h,u,y,v,b),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function f0(s,t,e,n,i,r,o,a){let c;if(t.side===nn?c=n.intersectTriangle(o,r,i,!0,a):c=n.intersectTriangle(i,r,o,t.side===zi,a),c===null)return null;mo.copy(a),mo.applyMatrix4(s.matrixWorld);const l=e.ray.origin.distanceTo(mo);return l<e.near||l>e.far?null:{distance:l,point:mo.clone(),object:s}}function xo(s,t,e,n,i,r,o,a,c,l){s.getVertexPosition(a,ho),s.getVertexPosition(c,uo),s.getVertexPosition(l,fo);const h=f0(s,t,e,n,ho,uo,fo,Yh);if(h){const u=new F;zn.getBarycoord(Yh,ho,uo,fo,u),i&&(h.uv=zn.getInterpolatedAttribute(i,a,c,l,u,new zt)),r&&(h.uv1=zn.getInterpolatedAttribute(r,a,c,l,u,new zt)),o&&(h.normal=zn.getInterpolatedAttribute(o,a,c,l,u,new F),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:c,c:l,normal:new F,materialIndex:0};zn.getNormal(ho,uo,fo,d.normal),h.face=d,h.barycoord=u}return h}class ki extends Rn{constructor(t=1,e=1,n=1,i=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:o};const a=this;i=Math.floor(i),r=Math.floor(r),o=Math.floor(o);const c=[],l=[],h=[],u=[];let d=0,p=0;x("z","y","x",-1,-1,n,e,t,o,r,0),x("z","y","x",1,-1,n,e,-t,o,r,1),x("x","z","y",1,1,t,n,e,i,o,2),x("x","z","y",1,-1,t,n,-e,i,o,3),x("x","y","z",1,-1,t,e,n,i,r,4),x("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(c),this.setAttribute("position",new je(l,3)),this.setAttribute("normal",new je(h,3)),this.setAttribute("uv",new je(u,2));function x(g,m,f,y,v,b,_,M,T,P,A){const E=b/T,R=_/P,I=b/2,z=_/2,X=M/2,H=T+1,K=P+1;let G=0,V=0;const $=new F;for(let st=0;st<K;st++){const St=st*R-z;for(let Ht=0;Ht<H;Ht++){const ne=Ht*E-I;$[g]=ne*y,$[m]=St*v,$[f]=X,l.push($.x,$.y,$.z),$[g]=0,$[m]=0,$[f]=M>0?1:-1,h.push($.x,$.y,$.z),u.push(Ht/T),u.push(1-st/P),G+=1}}for(let st=0;st<P;st++)for(let St=0;St<T;St++){const Ht=d+St+H*st,ne=d+St+H*(st+1),ce=d+(St+1)+H*(st+1),le=d+(St+1)+H*st;c.push(Ht,ne,le),c.push(ne,ce,le),V+=6}a.addGroup(p,V,A),p+=V,d+=G}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ki(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function Ks(s){const t={};for(const e in s){t[e]={};for(const n in s[e]){const i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(kt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function en(s){const t={};for(let e=0;e<s.length;e++){const n=Ks(s[e]);for(const i in n)t[i]=n[i]}return t}function p0(s){const t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function Zd(s){const t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:re.workingColorSpace}const m0={clone:Ks,merge:en};var x0=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,g0=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Kn extends ba{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=x0,this.fragmentShader=g0,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Ks(t.uniforms),this.uniformsGroups=p0(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const o=this.uniforms[i].value;o&&o.isTexture?e.uniforms[i]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[i]={type:"m4",value:o.toArray()}:e.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}let jd=class extends oe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new _e,this.projectionMatrix=new _e,this.projectionMatrixInverse=new _e,this.coordinateSystem=Yn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}};const yi=new F,$h=new zt,Kh=new zt;class wn extends jd{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Gr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Pr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Gr*2*Math.atan(Math.tan(Pr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){yi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(yi.x,yi.y).multiplyScalar(-t/yi.z),yi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(yi.x,yi.y).multiplyScalar(-t/yi.z)}getViewSize(t,e){return this.getViewBounds(t,$h,Kh),e.subVectors(Kh,$h)}setViewOffset(t,e,n,i,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Pr*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i;const o=this.view;if(this.view!==null&&this.view.enabled){const c=o.fullWidth,l=o.fullHeight;r+=o.offsetX*i/c,e-=o.offsetY*n/l,i*=o.width/c,n*=o.height/l}const a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const Ps=-90,Ls=1;class _0 extends oe{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new wn(Ps,Ls,t,e);i.layers=this.layers,this.add(i);const r=new wn(Ps,Ls,t,e);r.layers=this.layers,this.add(r);const o=new wn(Ps,Ls,t,e);o.layers=this.layers,this.add(o);const a=new wn(Ps,Ls,t,e);a.layers=this.layers,this.add(a);const c=new wn(Ps,Ls,t,e);c.layers=this.layers,this.add(c);const l=new wn(Ps,Ls,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,r,o,a,c]=e;for(const l of e)this.remove(l);if(t===Yn)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===ra)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,o,a,c,l,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),x=t.xr.enabled;t.xr.enabled=!1;const g=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,o),t.setRenderTarget(n,2,i),t.render(e,a),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=g,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,d,p),t.xr.enabled=x,n.texture.needsPMREMUpdate=!0}}class Jd extends Ze{constructor(t=[],e=qs,n,i,r,o,a,c,l,h){super(t,e,n,i,r,o,a,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class v0 extends fs{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new Jd(i),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new ki(5,5,5),r=new Kn({name:"CubemapFromEquirect",uniforms:Ks(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:nn,blending:di});r.uniforms.tEquirect.value=e;const o=new hn(i,r),a=e.minFilter;return e.minFilter===hs&&(e.minFilter=cn),new _0(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e=!0,n=!0,i=!0){const r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,n,i);t.setRenderTarget(r)}}class Ar extends oe{constructor(){super(),this.isGroup=!0,this.type="Group"}}const b0={type:"move"};class Ka{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Ar,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Ar,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new F,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new F),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Ar,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new F,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new F),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,o=null;const a=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){o=!0;for(const g of t.hand.values()){const m=e.getJointPose(g,n),f=this._getHandJoint(l,g);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const h=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],d=h.position.distanceTo(u.position),p=.02,x=.005;l.inputState.pinching&&d>p+x?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&d<=p-x&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));a!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(b0)))}return a!==null&&(a.visible=i!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new Ar;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class M0 extends oe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new mi,this.environmentIntensity=1,this.environmentRotation=new mi,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}class Qd extends Ze{constructor(t=null,e=1,n=1,i,r,o,a,c,l=gn,h=gn,u,d){super(null,o,a,c,l,h,i,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Hr extends _n{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const Ds=new _e,Zh=new _e,go=[],jh=new gs,y0=new _e,ar=new hn,cr=new Kr;class Zs extends hn{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Hr(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,y0)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new gs),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ds),jh.copy(t.boundingBox).applyMatrix4(Ds),this.boundingBox.union(jh)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Kr),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ds),cr.copy(t.boundingSphere).applyMatrix4(Ds),this.boundingSphere.union(cr)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,o=t*r+1;for(let a=0;a<n.length;a++)n[a]=i[o+a]}raycast(t,e){const n=this.matrixWorld,i=this.count;if(ar.geometry=this.geometry,ar.material=this.material,ar.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cr.copy(this.boundingSphere),cr.applyMatrix4(n),t.ray.intersectsSphere(cr)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,Ds),Zh.multiplyMatrices(n,Ds),ar.matrixWorld=Zh,ar.raycast(t,go);for(let o=0,a=go.length;o<a;o++){const c=go[o];c.instanceId=r,c.object=this,e.push(c)}go.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Hr(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){const n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new Qd(new Float32Array(i*this.count),i,this.count,Nl,qn));const r=this.morphTexture.source.data.data;let o=0;for(let l=0;l<n.length;l++)o+=n[l];const a=this.geometry.morphTargetsRelative?1:1-o,c=i*t;r[c]=a,r.set(n,c+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Za=new F,S0=new F,E0=new Xt;class Li{constructor(t=new F(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Za.subVectors(n,e).cross(S0.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Za),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||E0.getNormalMatrix(t),i=this.coplanarPoint(Za).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Ki=new Kr,A0=new zt(.5,.5),_o=new F;class tf{constructor(t=new Li,e=new Li,n=new Li,i=new Li,r=new Li,o=new Li){this.planes=[t,e,n,i,r,o]}set(t,e,n,i,r,o){const a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(n),a[3].copy(i),a[4].copy(r),a[5].copy(o),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=Yn,n=!1){const i=this.planes,r=t.elements,o=r[0],a=r[1],c=r[2],l=r[3],h=r[4],u=r[5],d=r[6],p=r[7],x=r[8],g=r[9],m=r[10],f=r[11],y=r[12],v=r[13],b=r[14],_=r[15];if(i[0].setComponents(l-o,p-h,f-x,_-y).normalize(),i[1].setComponents(l+o,p+h,f+x,_+y).normalize(),i[2].setComponents(l+a,p+u,f+g,_+v).normalize(),i[3].setComponents(l-a,p-u,f-g,_-v).normalize(),n)i[4].setComponents(c,d,m,b).normalize(),i[5].setComponents(l-c,p-d,f-m,_-b).normalize();else if(i[4].setComponents(l-c,p-d,f-m,_-b).normalize(),e===Yn)i[5].setComponents(l+c,p+d,f+m,_+b).normalize();else if(e===ra)i[5].setComponents(c,d,m,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ki.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Ki.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ki)}intersectsSprite(t){Ki.center.set(0,0,0);const e=A0.distanceTo(t.center);return Ki.radius=.7071067811865476+e,Ki.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ki)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(_o.x=i.normal.x>0?t.max.x:t.min.x,_o.y=i.normal.y>0?t.max.y:t.min.y,_o.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(_o)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class w0 extends Ze{constructor(t,e,n,i,r,o,a,c,l){super(t,e,n,i,r,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class ef extends Ze{constructor(t,e,n=ds,i,r,o,a=gn,c=gn,l,h=zr,u=1){if(h!==zr&&h!==Vr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const d={width:t,height:e,depth:u};super(d,i,r,o,a,c,h,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new Hl(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}class nf extends Ze{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class ql extends Rn{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const r=[],o=[],a=[],c=[],l=new F,h=new zt;o.push(0,0,0),a.push(0,0,1),c.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){const p=n+u/e*i;l.x=t*Math.cos(p),l.y=t*Math.sin(p),o.push(l.x,l.y,l.z),a.push(0,0,1),h.x=(o[d]/t+1)/2,h.y=(o[d+1]/t+1)/2,c.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new je(o,3)),this.setAttribute("normal",new je(a,3)),this.setAttribute("uv",new je(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ql(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class ke extends Rn{constructor(t=1,e=1,n=1,i=32,r=1,o=!1,a=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:c};const l=this;i=Math.floor(i),r=Math.floor(r);const h=[],u=[],d=[],p=[];let x=0;const g=[],m=n/2;let f=0;y(),o===!1&&(t>0&&v(!0),e>0&&v(!1)),this.setIndex(h),this.setAttribute("position",new je(u,3)),this.setAttribute("normal",new je(d,3)),this.setAttribute("uv",new je(p,2));function y(){const b=new F,_=new F;let M=0;const T=(e-t)/n;for(let P=0;P<=r;P++){const A=[],E=P/r,R=E*(e-t)+t;for(let I=0;I<=i;I++){const z=I/i,X=z*c+a,H=Math.sin(X),K=Math.cos(X);_.x=R*H,_.y=-E*n+m,_.z=R*K,u.push(_.x,_.y,_.z),b.set(H,T,K).normalize(),d.push(b.x,b.y,b.z),p.push(z,1-E),A.push(x++)}g.push(A)}for(let P=0;P<i;P++)for(let A=0;A<r;A++){const E=g[A][P],R=g[A+1][P],I=g[A+1][P+1],z=g[A][P+1];(t>0||A!==0)&&(h.push(E,R,z),M+=3),(e>0||A!==r-1)&&(h.push(R,I,z),M+=3)}l.addGroup(f,M,0),f+=M}function v(b){const _=x,M=new zt,T=new F;let P=0;const A=b===!0?t:e,E=b===!0?1:-1;for(let I=1;I<=i;I++)u.push(0,m*E,0),d.push(0,E,0),p.push(.5,.5),x++;const R=x;for(let I=0;I<=i;I++){const X=I/i*c+a,H=Math.cos(X),K=Math.sin(X);T.x=A*K,T.y=m*E,T.z=A*H,u.push(T.x,T.y,T.z),d.push(0,E,0),M.x=H*.5+.5,M.y=K*.5*E+.5,p.push(M.x,M.y),x++}for(let I=0;I<i;I++){const z=_+I,X=R+I;b===!0?h.push(X,X+1,z):h.push(X+1,X,z),P+=3}l.addGroup(f,P,b===!0?1:2),f+=P}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ke(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Hi extends Rn{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const r=t/2,o=e/2,a=Math.floor(n),c=Math.floor(i),l=a+1,h=c+1,u=t/a,d=e/c,p=[],x=[],g=[],m=[];for(let f=0;f<h;f++){const y=f*d-o;for(let v=0;v<l;v++){const b=v*u-r;x.push(b,-y,0),g.push(0,0,1),m.push(v/a),m.push(1-f/c)}}for(let f=0;f<c;f++)for(let y=0;y<a;y++){const v=y+l*f,b=y+l*(f+1),_=y+1+l*(f+1),M=y+1+l*f;p.push(v,b,M),p.push(b,_,M)}this.setIndex(p),this.setAttribute("position",new je(x,3)),this.setAttribute("normal",new je(g,3)),this.setAttribute("uv",new je(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Hi(t.width,t.height,t.widthSegments,t.heightSegments)}}class tr extends Rn{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(o+a,Math.PI);let l=0;const h=[],u=new F,d=new F,p=[],x=[],g=[],m=[];for(let f=0;f<=n;f++){const y=[],v=f/n;let b=0;f===0&&o===0?b=.5/e:f===n&&c===Math.PI&&(b=-.5/e);for(let _=0;_<=e;_++){const M=_/e;u.x=-t*Math.cos(i+M*r)*Math.sin(o+v*a),u.y=t*Math.cos(o+v*a),u.z=t*Math.sin(i+M*r)*Math.sin(o+v*a),x.push(u.x,u.y,u.z),d.copy(u).normalize(),g.push(d.x,d.y,d.z),m.push(M+b,1-v),y.push(l++)}h.push(y)}for(let f=0;f<n;f++)for(let y=0;y<e;y++){const v=h[f][y+1],b=h[f][y],_=h[f+1][y],M=h[f+1][y+1];(f!==0||o>0)&&p.push(v,b,M),(f!==n-1||c<Math.PI)&&p.push(b,_,M)}this.setIndex(p),this.setAttribute("position",new je(x,3)),this.setAttribute("normal",new je(g,3)),this.setAttribute("uv",new je(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new tr(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class T0 extends ba{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=yp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class C0 extends ba{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class R0 extends jd{constructor(t=-1,e=1,n=1,i=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let r=n-t,o=n+t,a=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,o=r+l*this.view.width,a-=h*this.view.offsetY,c=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}class P0 extends wn{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const Jh=new _e;class L0{constructor(t,e,n=0,i=1/0){this.ray=new Wl(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new Xl,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):Pe("Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return Jh.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(Jh),this}intersectObject(t,e=!0,n=[]){return pl(t,this,n,e),n.sort(Qh),n}intersectObjects(t,e=!0,n=[]){for(let i=0,r=t.length;i<r;i++)pl(t[i],this,n,e);return n.sort(Qh),n}}function Qh(s,t){return s.distance-t.distance}function pl(s,t,e,n){let i=!0;if(s.layers.test(t.layers)&&s.raycast(t,e)===!1&&(i=!1),i===!0&&n===!0){const r=s.children;for(let o=0,a=r.length;o<a;o++)pl(r[o],t,e,!0)}}class aa{constructor(t=1,e=0,n=0){this.constructor.constructedCount=1+(this.constructor.constructedCount||0),this.radius=t,this.phi=e,this.theta=n}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Zt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(Zt(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}class D0 extends xs{constructor(t,e=null){super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(t){if(t===void 0){kt("Controls: connect() now requires an element.");return}this.domElement!==null&&this.disconnect(),this.domElement=t}disconnect(){}dispose(){}update(){}}function tu(s,t,e,n){const i=I0(n);switch(e){case Gd:return s*t;case Nl:return s*t/i.components*i.byteLength;case Ol:return s*t/i.components*i.byteLength;case Bl:return s*t*2/i.components*i.byteLength;case zl:return s*t*2/i.components*i.byteLength;case Hd:return s*t*3/i.components*i.byteLength;case Vn:return s*t*4/i.components*i.byteLength;case Vl:return s*t*4/i.components*i.byteLength;case $o:case Ko:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Zo:case jo:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case kc:case Hc:return Math.max(s,16)*Math.max(t,8)/4;case Vc:case Gc:return Math.max(s,8)*Math.max(t,8)/2;case Wc:case Xc:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case qc:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Yc:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case $c:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Kc:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case Zc:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case jc:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case Jc:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case Qc:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case tl:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case el:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case nl:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case il:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case sl:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case rl:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case ol:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case al:case cl:case ll:return Math.ceil(s/4)*Math.ceil(t/4)*16;case hl:case ul:return Math.ceil(s/4)*Math.ceil(t/4)*8;case dl:case fl:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function I0(s){switch(s){case pi:case Bd:return{byteLength:1,components:1};case Or:case zd:case Js:return{byteLength:2,components:1};case Ul:case Fl:return{byteLength:2,components:4};case ds:case Il:case qn:return{byteLength:4,components:1};case Vd:case kd:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Dl}}));typeof window<"u"&&(window.__THREE__?kt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Dl);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function sf(){let s=null,t=!1,e=null,n=null;function i(r,o){e(r,o),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function U0(s){const t=new WeakMap;function e(a,c){const l=a.array,h=a.usage,u=l.byteLength,d=s.createBuffer();s.bindBuffer(c,d),s.bufferData(c,l,h),a.onUploadCallback();let p;if(l instanceof Float32Array)p=s.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)p=s.HALF_FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?p=s.HALF_FLOAT:p=s.UNSIGNED_SHORT;else if(l instanceof Int16Array)p=s.SHORT;else if(l instanceof Uint32Array)p=s.UNSIGNED_INT;else if(l instanceof Int32Array)p=s.INT;else if(l instanceof Int8Array)p=s.BYTE;else if(l instanceof Uint8Array)p=s.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)p=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:d,type:p,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,c,l){const h=c.array,u=c.updateRanges;if(s.bindBuffer(l,a),u.length===0)s.bufferSubData(l,0,h);else{u.sort((p,x)=>p.start-x.start);let d=0;for(let p=1;p<u.length;p++){const x=u[d],g=u[p];g.start<=x.start+x.count+1?x.count=Math.max(x.count,g.start+g.count-x.start):(++d,u[d]=g)}u.length=d+1;for(let p=0,x=u.length;p<x;p++){const g=u[p];s.bufferSubData(l,g.start*h.BYTES_PER_ELEMENT,h,g.start,g.count)}c.clearUpdateRanges()}c.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);const c=t.get(a);c&&(s.deleteBuffer(c.buffer),t.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const l=t.get(a);if(l===void 0)t.set(a,e(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,a,c),l.version=a.version}}return{get:i,remove:r,update:o}}var F0=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,N0=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,O0=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,B0=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,z0=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,V0=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,k0=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,G0=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,H0=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,W0=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,X0=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,q0=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Y0=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,$0=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,K0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Z0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,j0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,J0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Q0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,tm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,em=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,nm=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,im=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,sm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,rm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,om=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,am=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,cm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,lm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,hm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,um="gl_FragColor = linearToOutputTexel( gl_FragColor );",dm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,fm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,pm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,mm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,xm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,gm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,_m=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,vm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,bm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Mm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,ym=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Sm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Em=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Am=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,wm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Tm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Cm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Rm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Pm=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Lm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Dm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Im=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 uv = vec2( roughness, dotNV );
	return texture2D( dfgLUT, uv ).rg;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNV * dotNV), 0.0, dotNV), material.roughness );
	vec2 dfgL = DFGApprox( vec3(0.0, 0.0, 1.0), vec3(sqrt(1.0 - dotNL * dotNL), 0.0, dotNL), material.roughness );
	vec3 FssEss_V = material.specularColor * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColor * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColor + ( 1.0 - material.specularColor ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Um=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Fm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Nm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Om=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Bm=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,zm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Vm=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,km=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Gm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Hm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Wm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Xm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,qm=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ym=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,$m=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Km=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Zm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,jm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Jm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Qm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,tx=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ex=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,nx=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,ix=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,sx=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,rx=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,ox=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ax=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,cx=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,lx=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,hx=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,ux=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dx=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,fx=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,px=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,mx=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,xx=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,gx=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,_x=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,vx=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,bx=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Mx=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,yx=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Sx=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Ex=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Ax=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,wx=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Tx=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Cx=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Rx=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Px=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Lx=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Dx=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Ix=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Ux=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Fx=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Nx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ox=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zx=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Vx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,kx=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Gx=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Hx=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Wx=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Xx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Yx=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,$x=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Kx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zx=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,jx=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jx=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Qx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,eg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,ng=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ig=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,rg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,og=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ag=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,cg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,lg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,hg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ug=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,dg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Yt={alphahash_fragment:F0,alphahash_pars_fragment:N0,alphamap_fragment:O0,alphamap_pars_fragment:B0,alphatest_fragment:z0,alphatest_pars_fragment:V0,aomap_fragment:k0,aomap_pars_fragment:G0,batching_pars_vertex:H0,batching_vertex:W0,begin_vertex:X0,beginnormal_vertex:q0,bsdfs:Y0,iridescence_fragment:$0,bumpmap_pars_fragment:K0,clipping_planes_fragment:Z0,clipping_planes_pars_fragment:j0,clipping_planes_pars_vertex:J0,clipping_planes_vertex:Q0,color_fragment:tm,color_pars_fragment:em,color_pars_vertex:nm,color_vertex:im,common:sm,cube_uv_reflection_fragment:rm,defaultnormal_vertex:om,displacementmap_pars_vertex:am,displacementmap_vertex:cm,emissivemap_fragment:lm,emissivemap_pars_fragment:hm,colorspace_fragment:um,colorspace_pars_fragment:dm,envmap_fragment:fm,envmap_common_pars_fragment:pm,envmap_pars_fragment:mm,envmap_pars_vertex:xm,envmap_physical_pars_fragment:Tm,envmap_vertex:gm,fog_vertex:_m,fog_pars_vertex:vm,fog_fragment:bm,fog_pars_fragment:Mm,gradientmap_pars_fragment:ym,lightmap_pars_fragment:Sm,lights_lambert_fragment:Em,lights_lambert_pars_fragment:Am,lights_pars_begin:wm,lights_toon_fragment:Cm,lights_toon_pars_fragment:Rm,lights_phong_fragment:Pm,lights_phong_pars_fragment:Lm,lights_physical_fragment:Dm,lights_physical_pars_fragment:Im,lights_fragment_begin:Um,lights_fragment_maps:Fm,lights_fragment_end:Nm,logdepthbuf_fragment:Om,logdepthbuf_pars_fragment:Bm,logdepthbuf_pars_vertex:zm,logdepthbuf_vertex:Vm,map_fragment:km,map_pars_fragment:Gm,map_particle_fragment:Hm,map_particle_pars_fragment:Wm,metalnessmap_fragment:Xm,metalnessmap_pars_fragment:qm,morphinstance_vertex:Ym,morphcolor_vertex:$m,morphnormal_vertex:Km,morphtarget_pars_vertex:Zm,morphtarget_vertex:jm,normal_fragment_begin:Jm,normal_fragment_maps:Qm,normal_pars_fragment:tx,normal_pars_vertex:ex,normal_vertex:nx,normalmap_pars_fragment:ix,clearcoat_normal_fragment_begin:sx,clearcoat_normal_fragment_maps:rx,clearcoat_pars_fragment:ox,iridescence_pars_fragment:ax,opaque_fragment:cx,packing:lx,premultiplied_alpha_fragment:hx,project_vertex:ux,dithering_fragment:dx,dithering_pars_fragment:fx,roughnessmap_fragment:px,roughnessmap_pars_fragment:mx,shadowmap_pars_fragment:xx,shadowmap_pars_vertex:gx,shadowmap_vertex:_x,shadowmask_pars_fragment:vx,skinbase_vertex:bx,skinning_pars_vertex:Mx,skinning_vertex:yx,skinnormal_vertex:Sx,specularmap_fragment:Ex,specularmap_pars_fragment:Ax,tonemapping_fragment:wx,tonemapping_pars_fragment:Tx,transmission_fragment:Cx,transmission_pars_fragment:Rx,uv_pars_fragment:Px,uv_pars_vertex:Lx,uv_vertex:Dx,worldpos_vertex:Ix,background_vert:Ux,background_frag:Fx,backgroundCube_vert:Nx,backgroundCube_frag:Ox,cube_vert:Bx,cube_frag:zx,depth_vert:Vx,depth_frag:kx,distanceRGBA_vert:Gx,distanceRGBA_frag:Hx,equirect_vert:Wx,equirect_frag:Xx,linedashed_vert:qx,linedashed_frag:Yx,meshbasic_vert:$x,meshbasic_frag:Kx,meshlambert_vert:Zx,meshlambert_frag:jx,meshmatcap_vert:Jx,meshmatcap_frag:Qx,meshnormal_vert:tg,meshnormal_frag:eg,meshphong_vert:ng,meshphong_frag:ig,meshphysical_vert:sg,meshphysical_frag:rg,meshtoon_vert:og,meshtoon_frag:ag,points_vert:cg,points_frag:lg,shadow_vert:hg,shadow_frag:ug,sprite_vert:dg,sprite_frag:fg},lt={common:{diffuse:{value:new ee(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xt}},envmap:{envMap:{value:null},envMapRotation:{value:new Xt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xt},normalScale:{value:new zt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ee(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new ee(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0},uvTransform:{value:new Xt}},sprite:{diffuse:{value:new ee(16777215)},opacity:{value:1},center:{value:new zt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xt},alphaMap:{value:null},alphaMapTransform:{value:new Xt},alphaTest:{value:0}}},Xn={basic:{uniforms:en([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.fog]),vertexShader:Yt.meshbasic_vert,fragmentShader:Yt.meshbasic_frag},lambert:{uniforms:en([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new ee(0)}}]),vertexShader:Yt.meshlambert_vert,fragmentShader:Yt.meshlambert_frag},phong:{uniforms:en([lt.common,lt.specularmap,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,lt.lights,{emissive:{value:new ee(0)},specular:{value:new ee(1118481)},shininess:{value:30}}]),vertexShader:Yt.meshphong_vert,fragmentShader:Yt.meshphong_frag},standard:{uniforms:en([lt.common,lt.envmap,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.roughnessmap,lt.metalnessmap,lt.fog,lt.lights,{emissive:{value:new ee(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag},toon:{uniforms:en([lt.common,lt.aomap,lt.lightmap,lt.emissivemap,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.gradientmap,lt.fog,lt.lights,{emissive:{value:new ee(0)}}]),vertexShader:Yt.meshtoon_vert,fragmentShader:Yt.meshtoon_frag},matcap:{uniforms:en([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,lt.fog,{matcap:{value:null}}]),vertexShader:Yt.meshmatcap_vert,fragmentShader:Yt.meshmatcap_frag},points:{uniforms:en([lt.points,lt.fog]),vertexShader:Yt.points_vert,fragmentShader:Yt.points_frag},dashed:{uniforms:en([lt.common,lt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Yt.linedashed_vert,fragmentShader:Yt.linedashed_frag},depth:{uniforms:en([lt.common,lt.displacementmap]),vertexShader:Yt.depth_vert,fragmentShader:Yt.depth_frag},normal:{uniforms:en([lt.common,lt.bumpmap,lt.normalmap,lt.displacementmap,{opacity:{value:1}}]),vertexShader:Yt.meshnormal_vert,fragmentShader:Yt.meshnormal_frag},sprite:{uniforms:en([lt.sprite,lt.fog]),vertexShader:Yt.sprite_vert,fragmentShader:Yt.sprite_frag},background:{uniforms:{uvTransform:{value:new Xt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Yt.background_vert,fragmentShader:Yt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Xt}},vertexShader:Yt.backgroundCube_vert,fragmentShader:Yt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Yt.cube_vert,fragmentShader:Yt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Yt.equirect_vert,fragmentShader:Yt.equirect_frag},distanceRGBA:{uniforms:en([lt.common,lt.displacementmap,{referencePosition:{value:new F},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Yt.distanceRGBA_vert,fragmentShader:Yt.distanceRGBA_frag},shadow:{uniforms:en([lt.lights,lt.fog,{color:{value:new ee(0)},opacity:{value:1}}]),vertexShader:Yt.shadow_vert,fragmentShader:Yt.shadow_frag}};Xn.physical={uniforms:en([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xt},clearcoatNormalScale:{value:new zt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xt},sheen:{value:0},sheenColor:{value:new ee(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xt},transmissionSamplerSize:{value:new zt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xt},attenuationDistance:{value:0},attenuationColor:{value:new ee(0)},specularColor:{value:new ee(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xt},anisotropyVector:{value:new zt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xt}}]),vertexShader:Yt.meshphysical_vert,fragmentShader:Yt.meshphysical_frag};const vo={r:0,b:0,g:0},Zi=new mi,pg=new _e;function mg(s,t,e,n,i,r,o){const a=new ee(0);let c=r===!0?0:1,l,h,u=null,d=0,p=null;function x(v){let b=v.isScene===!0?v.background:null;return b&&b.isTexture&&(b=(v.backgroundBlurriness>0?e:t).get(b)),b}function g(v){let b=!1;const _=x(v);_===null?f(a,c):_&&_.isColor&&(f(_,1),b=!0);const M=s.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,o):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(s.autoClear||b)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function m(v,b){const _=x(b);_&&(_.isCubeTexture||_.mapping===va)?(h===void 0&&(h=new hn(new ki(1,1,1),new Kn({name:"BackgroundCubeMaterial",uniforms:Ks(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:nn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(M,T,P){this.matrixWorld.copyPosition(P.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),Zi.copy(b.backgroundRotation),Zi.x*=-1,Zi.y*=-1,Zi.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(Zi.y*=-1,Zi.z*=-1),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(pg.makeRotationFromEuler(Zi)),h.material.toneMapped=re.getTransfer(_.colorSpace)!==de,(u!==_||d!==_.version||p!==s.toneMapping)&&(h.material.needsUpdate=!0,u=_,d=_.version,p=s.toneMapping),h.layers.enableAll(),v.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(l===void 0&&(l=new hn(new Hi(2,2),new Kn({name:"BackgroundMaterial",uniforms:Ks(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:zi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=_,l.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,l.material.toneMapped=re.getTransfer(_.colorSpace)!==de,_.matrixAutoUpdate===!0&&_.updateMatrix(),l.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||d!==_.version||p!==s.toneMapping)&&(l.material.needsUpdate=!0,u=_,d=_.version,p=s.toneMapping),l.layers.enableAll(),v.unshift(l,l.geometry,l.material,0,0,null))}function f(v,b){v.getRGB(vo,Zd(s)),n.buffers.color.setClear(vo.r,vo.g,vo.b,b,o)}function y(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(v,b=1){a.set(v),c=b,f(a,c)},getClearAlpha:function(){return c},setClearAlpha:function(v){c=v,f(a,c)},render:g,addToRenderList:m,dispose:y}}function xg(s,t){const e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=d(null);let r=i,o=!1;function a(E,R,I,z,X){let H=!1;const K=u(z,I,R);r!==K&&(r=K,l(r.object)),H=p(E,z,I,X),H&&x(E,z,I,X),X!==null&&t.update(X,s.ELEMENT_ARRAY_BUFFER),(H||o)&&(o=!1,b(E,R,I,z),X!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(X).buffer))}function c(){return s.createVertexArray()}function l(E){return s.bindVertexArray(E)}function h(E){return s.deleteVertexArray(E)}function u(E,R,I){const z=I.wireframe===!0;let X=n[E.id];X===void 0&&(X={},n[E.id]=X);let H=X[R.id];H===void 0&&(H={},X[R.id]=H);let K=H[z];return K===void 0&&(K=d(c()),H[z]=K),K}function d(E){const R=[],I=[],z=[];for(let X=0;X<e;X++)R[X]=0,I[X]=0,z[X]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:R,enabledAttributes:I,attributeDivisors:z,object:E,attributes:{},index:null}}function p(E,R,I,z){const X=r.attributes,H=R.attributes;let K=0;const G=I.getAttributes();for(const V in G)if(G[V].location>=0){const st=X[V];let St=H[V];if(St===void 0&&(V==="instanceMatrix"&&E.instanceMatrix&&(St=E.instanceMatrix),V==="instanceColor"&&E.instanceColor&&(St=E.instanceColor)),st===void 0||st.attribute!==St||St&&st.data!==St.data)return!0;K++}return r.attributesNum!==K||r.index!==z}function x(E,R,I,z){const X={},H=R.attributes;let K=0;const G=I.getAttributes();for(const V in G)if(G[V].location>=0){let st=H[V];st===void 0&&(V==="instanceMatrix"&&E.instanceMatrix&&(st=E.instanceMatrix),V==="instanceColor"&&E.instanceColor&&(st=E.instanceColor));const St={};St.attribute=st,st&&st.data&&(St.data=st.data),X[V]=St,K++}r.attributes=X,r.attributesNum=K,r.index=z}function g(){const E=r.newAttributes;for(let R=0,I=E.length;R<I;R++)E[R]=0}function m(E){f(E,0)}function f(E,R){const I=r.newAttributes,z=r.enabledAttributes,X=r.attributeDivisors;I[E]=1,z[E]===0&&(s.enableVertexAttribArray(E),z[E]=1),X[E]!==R&&(s.vertexAttribDivisor(E,R),X[E]=R)}function y(){const E=r.newAttributes,R=r.enabledAttributes;for(let I=0,z=R.length;I<z;I++)R[I]!==E[I]&&(s.disableVertexAttribArray(I),R[I]=0)}function v(E,R,I,z,X,H,K){K===!0?s.vertexAttribIPointer(E,R,I,X,H):s.vertexAttribPointer(E,R,I,z,X,H)}function b(E,R,I,z){g();const X=z.attributes,H=I.getAttributes(),K=R.defaultAttributeValues;for(const G in H){const V=H[G];if(V.location>=0){let $=X[G];if($===void 0&&(G==="instanceMatrix"&&E.instanceMatrix&&($=E.instanceMatrix),G==="instanceColor"&&E.instanceColor&&($=E.instanceColor)),$!==void 0){const st=$.normalized,St=$.itemSize,Ht=t.get($);if(Ht===void 0)continue;const ne=Ht.buffer,ce=Ht.type,le=Ht.bytesPerElement,Z=ce===s.INT||ce===s.UNSIGNED_INT||$.gpuType===Il;if($.isInterleavedBufferAttribute){const Q=$.data,ft=Q.stride,Ft=$.offset;if(Q.isInstancedInterleavedBuffer){for(let At=0;At<V.locationSize;At++)f(V.location+At,Q.meshPerAttribute);E.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=Q.meshPerAttribute*Q.count)}else for(let At=0;At<V.locationSize;At++)m(V.location+At);s.bindBuffer(s.ARRAY_BUFFER,ne);for(let At=0;At<V.locationSize;At++)v(V.location+At,St/V.locationSize,ce,st,ft*le,(Ft+St/V.locationSize*At)*le,Z)}else{if($.isInstancedBufferAttribute){for(let Q=0;Q<V.locationSize;Q++)f(V.location+Q,$.meshPerAttribute);E.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=$.meshPerAttribute*$.count)}else for(let Q=0;Q<V.locationSize;Q++)m(V.location+Q);s.bindBuffer(s.ARRAY_BUFFER,ne);for(let Q=0;Q<V.locationSize;Q++)v(V.location+Q,St/V.locationSize,ce,st,St*le,St/V.locationSize*Q*le,Z)}}else if(K!==void 0){const st=K[G];if(st!==void 0)switch(st.length){case 2:s.vertexAttrib2fv(V.location,st);break;case 3:s.vertexAttrib3fv(V.location,st);break;case 4:s.vertexAttrib4fv(V.location,st);break;default:s.vertexAttrib1fv(V.location,st)}}}}y()}function _(){P();for(const E in n){const R=n[E];for(const I in R){const z=R[I];for(const X in z)h(z[X].object),delete z[X];delete R[I]}delete n[E]}}function M(E){if(n[E.id]===void 0)return;const R=n[E.id];for(const I in R){const z=R[I];for(const X in z)h(z[X].object),delete z[X];delete R[I]}delete n[E.id]}function T(E){for(const R in n){const I=n[R];if(I[E.id]===void 0)continue;const z=I[E.id];for(const X in z)h(z[X].object),delete z[X];delete I[E.id]}}function P(){A(),o=!0,r!==i&&(r=i,l(r.object))}function A(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:P,resetDefaultState:A,dispose:_,releaseStatesOfGeometry:M,releaseStatesOfProgram:T,initAttributes:g,enableAttribute:m,disableUnusedAttributes:y}}function gg(s,t,e){let n;function i(l){n=l}function r(l,h){s.drawArrays(n,l,h),e.update(h,n,1)}function o(l,h,u){u!==0&&(s.drawArraysInstanced(n,l,h,u),e.update(h,n,u))}function a(l,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,h,0,u);let p=0;for(let x=0;x<u;x++)p+=h[x];e.update(p,n,1)}function c(l,h,u,d){if(u===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let x=0;x<l.length;x++)o(l[x],h[x],d[x]);else{p.multiDrawArraysInstancedWEBGL(n,l,0,h,0,d,0,u);let x=0;for(let g=0;g<u;g++)x+=h[g]*d[g];e.update(x,n,1)}}this.setMode=i,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=c}function _g(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){const T=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(T){return!(T!==Vn&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){const P=T===Js&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(T!==pi&&n.convert(T)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==qn&&!P)}function c(T){if(T==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=e.precision!==void 0?e.precision:"highp";const h=c(l);h!==l&&(kt("WebGLRenderer:",l,"not supported, using",h,"instead."),l=h);const u=e.logarithmicDepthBuffer===!0,d=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),p=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),x=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),g=s.getParameter(s.MAX_TEXTURE_SIZE),m=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),f=s.getParameter(s.MAX_VERTEX_ATTRIBS),y=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),v=s.getParameter(s.MAX_VARYING_VECTORS),b=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),_=x>0,M=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:p,maxVertexTextures:x,maxTextureSize:g,maxCubemapSize:m,maxAttributes:f,maxVertexUniforms:y,maxVaryings:v,maxFragmentUniforms:b,vertexTextures:_,maxSamples:M}}function vg(s){const t=this;let e=null,n=0,i=!1,r=!1;const o=new Li,a=new Xt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const p=u.length!==0||d||n!==0||i;return i=d,n=u.length,p},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,p){const x=u.clippingPlanes,g=u.clipIntersection,m=u.clipShadows,f=s.get(u);if(!i||x===null||x.length===0||r&&!m)r?h(null):l();else{const y=r?0:n,v=y*4;let b=f.clippingState||null;c.value=b,b=h(x,d,v,p);for(let _=0;_!==v;++_)b[_]=e[_];f.clippingState=b,this.numIntersection=g?this.numPlanes:0,this.numPlanes+=y}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,p,x){const g=u!==null?u.length:0;let m=null;if(g!==0){if(m=c.value,x!==!0||m===null){const f=p+g*4,y=d.matrixWorldInverse;a.getNormalMatrix(y),(m===null||m.length<f)&&(m=new Float32Array(f));for(let v=0,b=p;v!==g;++v,b+=4)o.copy(u[v]).applyMatrix4(y,a),o.normal.toArray(m,b),m[b+3]=o.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=g,t.numIntersection=0,m}}function bg(s){let t=new WeakMap;function e(o,a){return a===Oc?o.mapping=qs:a===Bc&&(o.mapping=Ys),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===Oc||a===Bc)if(t.has(o)){const c=t.get(o).texture;return e(c,o.mapping)}else{const c=o.image;if(c&&c.height>0){const l=new v0(c.height);return l.fromEquirectangularTexture(s,o),t.set(o,l),o.addEventListener("dispose",i),e(l.texture,o.mapping)}else return null}}return o}function i(o){const a=o.target;a.removeEventListener("dispose",i);const c=t.get(a);c!==void 0&&(t.delete(a),c.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}const Ni=4,eu=[.125,.215,.35,.446,.526,.582],as=20,Mg=256,lr=new R0,nu=new ee;let ja=null,Ja=0,Qa=0,tc=!1;const yg=new F;class iu{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,e=0,n=.1,i=100,r={}){const{size:o=256,position:a=yg}=r;ja=this._renderer.getRenderTarget(),Ja=this._renderer.getActiveCubeFace(),Qa=this._renderer.getActiveMipmapLevel(),tc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(t,n,i,c,a),e>0&&this._blur(c,0,0,e),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ou(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ru(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(ja,Ja,Qa),this._renderer.xr.enabled=tc,t.scissorTest=!1,Is(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===qs||t.mapping===Ys?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),ja=this._renderer.getRenderTarget(),Ja=this._renderer.getActiveCubeFace(),Qa=this._renderer.getActiveMipmapLevel(),tc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:cn,minFilter:cn,generateMipmaps:!1,type:Js,format:Vn,colorSpace:$s,depthBuffer:!1},i=su(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=su(t,e,n);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Sg(r)),this._blurMaterial=Ag(r,t,e),this._ggxMaterial=Eg(r,t,e)}return i}_compileMaterial(t){const e=new hn(new Rn,t);this._renderer.compile(e,lr)}_sceneToCubeUV(t,e,n,i,r){const c=new wn(90,1,e,n),l=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,p=u.toneMapping;u.getClearColor(nu),u.toneMapping=Bi,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(i),u.clearDepth(),u.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new hn(new ki,new sn({name:"PMREM.Background",side:nn,depthWrite:!1,depthTest:!1})));const g=this._backgroundBox,m=g.material;let f=!1;const y=t.background;y?y.isColor&&(m.color.copy(y),t.background=null,f=!0):(m.color.copy(nu),f=!0);for(let v=0;v<6;v++){const b=v%3;b===0?(c.up.set(0,l[v],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+h[v],r.y,r.z)):b===1?(c.up.set(0,0,l[v]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+h[v],r.z)):(c.up.set(0,l[v],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+h[v]));const _=this._cubeSize;Is(i,b*_,v>2?_:0,_,_),u.setRenderTarget(i),f&&u.render(g,c),u.render(t,c)}u.toneMapping=p,u.autoClear=d,t.background=y}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===qs||t.mapping===Ys;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=ou()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ru());const r=i?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=r;const a=r.uniforms;a.envMap.value=t;const c=this._cubeSize;Is(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(o,lr)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const i=this._lodMeshes.length;for(let r=1;r<i;r++)this._applyGGXFilter(t,r-1,r);e.autoClear=n}_applyGGXFilter(t,e,n){const i=this._renderer,r=this._pingPongRenderTarget,o=this._ggxMaterial,a=this._lodMeshes[n];a.material=o;const c=o.uniforms,l=n/(this._lodMeshes.length-1),h=e/(this._lodMeshes.length-1),u=Math.sqrt(l*l-h*h),d=.05+l*.95,p=u*d,{_lodMax:x}=this,g=this._sizeLods[n],m=3*g*(n>x-Ni?n-x+Ni:0),f=4*(this._cubeSize-g);c.envMap.value=t.texture,c.roughness.value=p,c.mipInt.value=x-e,Is(r,m,f,3*g,2*g),i.setRenderTarget(r),i.render(a,lr),c.envMap.value=r.texture,c.roughness.value=0,c.mipInt.value=x-n,Is(t,m,f,3*g,2*g),i.setRenderTarget(t),i.render(a,lr)}_blur(t,e,n,i,r){const o=this._pingPongRenderTarget;this._halfBlur(t,o,e,n,i,"latitudinal",r),this._halfBlur(o,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,o,a){const c=this._renderer,l=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&Pe("blur direction must be either latitudinal or longitudinal!");const h=3,u=this._lodMeshes[i];u.material=l;const d=l.uniforms,p=this._sizeLods[n]-1,x=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*as-1),g=r/x,m=isFinite(r)?1+Math.floor(h*g):as;m>as&&kt(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${as}`);const f=[];let y=0;for(let T=0;T<as;++T){const P=T/g,A=Math.exp(-P*P/2);f.push(A),T===0?y+=A:T<m&&(y+=2*A)}for(let T=0;T<f.length;T++)f[T]=f[T]/y;d.envMap.value=t.texture,d.samples.value=m,d.weights.value=f,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:v}=this;d.dTheta.value=x,d.mipInt.value=v-n;const b=this._sizeLods[i],_=3*b*(i>v-Ni?i-v+Ni:0),M=4*(this._cubeSize-b);Is(e,_,M,3*b,2*b),c.setRenderTarget(e),c.render(u,lr)}}function Sg(s){const t=[],e=[],n=[];let i=s;const r=s-Ni+1+eu.length;for(let o=0;o<r;o++){const a=Math.pow(2,i);t.push(a);let c=1/a;o>s-Ni?c=eu[o-s+Ni-1]:o===0&&(c=0),e.push(c);const l=1/(a-2),h=-l,u=1+l,d=[h,h,u,h,u,u,h,h,u,u,h,u],p=6,x=6,g=3,m=2,f=1,y=new Float32Array(g*x*p),v=new Float32Array(m*x*p),b=new Float32Array(f*x*p);for(let M=0;M<p;M++){const T=M%3*2/3-1,P=M>2?0:-1,A=[T,P,0,T+2/3,P,0,T+2/3,P+1,0,T,P,0,T+2/3,P+1,0,T,P+1,0];y.set(A,g*x*M),v.set(d,m*x*M);const E=[M,M,M,M,M,M];b.set(E,f*x*M)}const _=new Rn;_.setAttribute("position",new _n(y,g)),_.setAttribute("uv",new _n(v,m)),_.setAttribute("faceIndex",new _n(b,f)),n.push(new hn(_,null)),i>Ni&&i--}return{lodMeshes:n,sizeLods:t,sigmas:e}}function su(s,t,e){const n=new fs(s,t,e);return n.texture.mapping=va,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Is(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function Eg(s,t,e){return new Kn({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Mg,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ma(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:di,depthTest:!1,depthWrite:!1})}function Ag(s,t,e){const n=new Float32Array(as),i=new F(0,1,0);return new Kn({name:"SphericalGaussianBlur",defines:{n:as,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Ma(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:di,depthTest:!1,depthWrite:!1})}function ru(){return new Kn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ma(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:di,depthTest:!1,depthWrite:!1})}function ou(){return new Kn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ma(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:di,depthTest:!1,depthWrite:!1})}function Ma(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function wg(s){let t=new WeakMap,e=null;function n(a){if(a&&a.isTexture){const c=a.mapping,l=c===Oc||c===Bc,h=c===qs||c===Ys;if(l||h){let u=t.get(a);const d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return e===null&&(e=new iu(s)),u=l?e.fromEquirectangular(a,u):e.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),u.texture;if(u!==void 0)return u.texture;{const p=a.image;return l&&p&&p.height>0||h&&p&&i(p)?(e===null&&(e=new iu(s)),u=l?e.fromEquirectangular(a):e.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,t.set(a,u),a.addEventListener("dispose",r),u.texture):null}}}return a}function i(a){let c=0;const l=6;for(let h=0;h<l;h++)a[h]!==void 0&&c++;return c===l}function r(a){const c=a.target;c.removeEventListener("dispose",r);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:o}}function Tg(s){const t={};function e(n){if(t[n]!==void 0)return t[n];const i=s.getExtension(n);return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const i=e(n);return i===null&&kr("WebGLRenderer: "+n+" extension not supported."),i}}}function Cg(s,t,e,n){const i={},r=new WeakMap;function o(u){const d=u.target;d.index!==null&&t.remove(d.index);for(const x in d.attributes)t.remove(d.attributes[x]);d.removeEventListener("dispose",o),delete i[d.id];const p=r.get(d);p&&(t.remove(p),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function a(u,d){return i[d.id]===!0||(d.addEventListener("dispose",o),i[d.id]=!0,e.memory.geometries++),d}function c(u){const d=u.attributes;for(const p in d)t.update(d[p],s.ARRAY_BUFFER)}function l(u){const d=[],p=u.index,x=u.attributes.position;let g=0;if(p!==null){const y=p.array;g=p.version;for(let v=0,b=y.length;v<b;v+=3){const _=y[v+0],M=y[v+1],T=y[v+2];d.push(_,M,M,T,T,_)}}else if(x!==void 0){const y=x.array;g=x.version;for(let v=0,b=y.length/3-1;v<b;v+=3){const _=v+0,M=v+1,T=v+2;d.push(_,M,M,T,T,_)}}else return;const m=new(Xd(d)?Kd:$d)(d,1);m.version=g;const f=r.get(u);f&&t.remove(f),r.set(u,m)}function h(u){const d=r.get(u);if(d){const p=u.index;p!==null&&d.version<p.version&&l(u)}else l(u);return r.get(u)}return{get:a,update:c,getWireframeAttribute:h}}function Rg(s,t,e){let n;function i(d){n=d}let r,o;function a(d){r=d.type,o=d.bytesPerElement}function c(d,p){s.drawElements(n,p,r,d*o),e.update(p,n,1)}function l(d,p,x){x!==0&&(s.drawElementsInstanced(n,p,r,d*o,x),e.update(p,n,x))}function h(d,p,x){if(x===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,r,d,0,x);let m=0;for(let f=0;f<x;f++)m+=p[f];e.update(m,n,1)}function u(d,p,x,g){if(x===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<d.length;f++)l(d[f]/o,p[f],g[f]);else{m.multiDrawElementsInstancedWEBGL(n,p,0,r,d,0,g,0,x);let f=0;for(let y=0;y<x;y++)f+=p[y]*g[y];e.update(f,n,1)}}this.setMode=i,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function Pg(s){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(e.calls++,o){case s.TRIANGLES:e.triangles+=a*(r/3);break;case s.LINES:e.lines+=a*(r/2);break;case s.LINE_STRIP:e.lines+=a*(r-1);break;case s.LINE_LOOP:e.lines+=a*r;break;case s.POINTS:e.points+=a*r;break;default:Pe("WebGLInfo: Unknown draw mode:",o);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function Lg(s,t,e){const n=new WeakMap,i=new De;function r(o,a,c){const l=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(a);if(d===void 0||d.count!==u){let E=function(){P.dispose(),n.delete(a),a.removeEventListener("dispose",E)};var p=E;d!==void 0&&d.texture.dispose();const x=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,f=a.morphAttributes.position||[],y=a.morphAttributes.normal||[],v=a.morphAttributes.color||[];let b=0;x===!0&&(b=1),g===!0&&(b=2),m===!0&&(b=3);let _=a.attributes.position.count*b,M=1;_>t.maxTextureSize&&(M=Math.ceil(_/t.maxTextureSize),_=t.maxTextureSize);const T=new Float32Array(_*M*4*u),P=new qd(T,_,M,u);P.type=qn,P.needsUpdate=!0;const A=b*4;for(let R=0;R<u;R++){const I=f[R],z=y[R],X=v[R],H=_*M*4*R;for(let K=0;K<I.count;K++){const G=K*A;x===!0&&(i.fromBufferAttribute(I,K),T[H+G+0]=i.x,T[H+G+1]=i.y,T[H+G+2]=i.z,T[H+G+3]=0),g===!0&&(i.fromBufferAttribute(z,K),T[H+G+4]=i.x,T[H+G+5]=i.y,T[H+G+6]=i.z,T[H+G+7]=0),m===!0&&(i.fromBufferAttribute(X,K),T[H+G+8]=i.x,T[H+G+9]=i.y,T[H+G+10]=i.z,T[H+G+11]=X.itemSize===4?i.w:1)}}d={count:u,texture:P,size:new zt(_,M)},n.set(a,d),a.addEventListener("dispose",E)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(s,"morphTexture",o.morphTexture,e);else{let x=0;for(let m=0;m<l.length;m++)x+=l[m];const g=a.morphTargetsRelative?1:1-x;c.getUniforms().setValue(s,"morphTargetBaseInfluence",g),c.getUniforms().setValue(s,"morphTargetInfluences",l)}c.getUniforms().setValue(s,"morphTargetsTexture",d.texture,e),c.getUniforms().setValue(s,"morphTargetsTextureSize",d.size)}return{update:r}}function Dg(s,t,e,n){let i=new WeakMap;function r(c){const l=n.render.frame,h=c.geometry,u=t.get(c,h);if(i.get(u)!==l&&(t.update(u),i.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",a)===!1&&c.addEventListener("dispose",a),i.get(c)!==l&&(e.update(c.instanceMatrix,s.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,s.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const d=c.skeleton;i.get(d)!==l&&(d.update(),i.set(d,l))}return u}function o(){i=new WeakMap}function a(c){const l=c.target;l.removeEventListener("dispose",a),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:r,dispose:o}}const rf=new Ze,au=new ef(1,1),of=new qd,af=new n0,cf=new Jd,cu=[],lu=[],hu=new Float32Array(16),uu=new Float32Array(9),du=new Float32Array(4);function er(s,t,e){const n=s[0];if(n<=0||n>0)return s;const i=t*e;let r=cu[i];if(r===void 0&&(r=new Float32Array(i),cu[i]=r),t!==0){n.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,s[o].toArray(r,a)}return r}function Fe(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Ne(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function ya(s,t){let e=lu[t];e===void 0&&(e=new Int32Array(t),lu[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function Ig(s,t){const e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function Ug(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2fv(this.addr,t),Ne(e,t)}}function Fg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Fe(e,t))return;s.uniform3fv(this.addr,t),Ne(e,t)}}function Ng(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4fv(this.addr,t),Ne(e,t)}}function Og(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Ne(e,t)}else{if(Fe(e,n))return;du.set(n),s.uniformMatrix2fv(this.addr,!1,du),Ne(e,n)}}function Bg(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Ne(e,t)}else{if(Fe(e,n))return;uu.set(n),s.uniformMatrix3fv(this.addr,!1,uu),Ne(e,n)}}function zg(s,t){const e=this.cache,n=t.elements;if(n===void 0){if(Fe(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Ne(e,t)}else{if(Fe(e,n))return;hu.set(n),s.uniformMatrix4fv(this.addr,!1,hu),Ne(e,n)}}function Vg(s,t){const e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function kg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2iv(this.addr,t),Ne(e,t)}}function Gg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Fe(e,t))return;s.uniform3iv(this.addr,t),Ne(e,t)}}function Hg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4iv(this.addr,t),Ne(e,t)}}function Wg(s,t){const e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function Xg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Fe(e,t))return;s.uniform2uiv(this.addr,t),Ne(e,t)}}function qg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Fe(e,t))return;s.uniform3uiv(this.addr,t),Ne(e,t)}}function Yg(s,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Fe(e,t))return;s.uniform4uiv(this.addr,t),Ne(e,t)}}function $g(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(au.compareFunction=Wd,r=au):r=rf,e.setTexture2D(t||r,i)}function Kg(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||af,i)}function Zg(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||cf,i)}function jg(s,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||of,i)}function Jg(s){switch(s){case 5126:return Ig;case 35664:return Ug;case 35665:return Fg;case 35666:return Ng;case 35674:return Og;case 35675:return Bg;case 35676:return zg;case 5124:case 35670:return Vg;case 35667:case 35671:return kg;case 35668:case 35672:return Gg;case 35669:case 35673:return Hg;case 5125:return Wg;case 36294:return Xg;case 36295:return qg;case 36296:return Yg;case 35678:case 36198:case 36298:case 36306:case 35682:return $g;case 35679:case 36299:case 36307:return Kg;case 35680:case 36300:case 36308:case 36293:return Zg;case 36289:case 36303:case 36311:case 36292:return jg}}function Qg(s,t){s.uniform1fv(this.addr,t)}function t_(s,t){const e=er(t,this.size,2);s.uniform2fv(this.addr,e)}function e_(s,t){const e=er(t,this.size,3);s.uniform3fv(this.addr,e)}function n_(s,t){const e=er(t,this.size,4);s.uniform4fv(this.addr,e)}function i_(s,t){const e=er(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function s_(s,t){const e=er(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function r_(s,t){const e=er(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function o_(s,t){s.uniform1iv(this.addr,t)}function a_(s,t){s.uniform2iv(this.addr,t)}function c_(s,t){s.uniform3iv(this.addr,t)}function l_(s,t){s.uniform4iv(this.addr,t)}function h_(s,t){s.uniform1uiv(this.addr,t)}function u_(s,t){s.uniform2uiv(this.addr,t)}function d_(s,t){s.uniform3uiv(this.addr,t)}function f_(s,t){s.uniform4uiv(this.addr,t)}function p_(s,t,e){const n=this.cache,i=t.length,r=ya(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ne(n,r));for(let o=0;o!==i;++o)e.setTexture2D(t[o]||rf,r[o])}function m_(s,t,e){const n=this.cache,i=t.length,r=ya(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ne(n,r));for(let o=0;o!==i;++o)e.setTexture3D(t[o]||af,r[o])}function x_(s,t,e){const n=this.cache,i=t.length,r=ya(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ne(n,r));for(let o=0;o!==i;++o)e.setTextureCube(t[o]||cf,r[o])}function g_(s,t,e){const n=this.cache,i=t.length,r=ya(e,i);Fe(n,r)||(s.uniform1iv(this.addr,r),Ne(n,r));for(let o=0;o!==i;++o)e.setTexture2DArray(t[o]||of,r[o])}function __(s){switch(s){case 5126:return Qg;case 35664:return t_;case 35665:return e_;case 35666:return n_;case 35674:return i_;case 35675:return s_;case 35676:return r_;case 5124:case 35670:return o_;case 35667:case 35671:return a_;case 35668:case 35672:return c_;case 35669:case 35673:return l_;case 5125:return h_;case 36294:return u_;case 36295:return d_;case 36296:return f_;case 35678:case 36198:case 36298:case 36306:case 35682:return p_;case 35679:case 36299:case 36307:return m_;case 35680:case 36300:case 36308:case 36293:return x_;case 36289:case 36303:case 36311:case 36292:return g_}}class v_{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Jg(e.type)}}class b_{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=__(e.type)}}class M_{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let r=0,o=i.length;r!==o;++r){const a=i[r];a.setValue(t,e[a.id],n)}}}const ec=/(\w+)(\])?(\[|\.)?/g;function fu(s,t){s.seq.push(t),s.map[t.id]=t}function y_(s,t,e){const n=s.name,i=n.length;for(ec.lastIndex=0;;){const r=ec.exec(n),o=ec.lastIndex;let a=r[1];const c=r[2]==="]",l=r[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===i){fu(e,l===void 0?new v_(a,s,t):new b_(a,s,t));break}else{let u=e.map[a];u===void 0&&(u=new M_(a),fu(e,u)),e=u}}}class Jo{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const r=t.getActiveUniform(e,i),o=t.getUniformLocation(e,r.name);y_(r,o,this)}}setValue(t,e,n,i){const r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,o=e.length;r!==o;++r){const a=e[r],c=n[a.id];c.needsUpdate!==!1&&a.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,r=t.length;i!==r;++i){const o=t[i];o.id in e&&n.push(o)}return n}}function pu(s,t,e){const n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}const S_=37297;let E_=0;function A_(s,t){const e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=i;o<r;o++){const a=o+1;n.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return n.join(`
`)}const mu=new Xt;function w_(s){re._getMatrix(mu,re.workingColorSpace,s);const t=`mat3( ${mu.elements.map(e=>e.toFixed(4))} )`;switch(re.getTransfer(s)){case sa:return[t,"LinearTransferOETF"];case de:return[t,"sRGBTransferOETF"];default:return kt("WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function xu(s,t,e){const n=s.getShaderParameter(t,s.COMPILE_STATUS),r=(s.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";const o=/ERROR: 0:(\d+)/.exec(r);if(o){const a=parseInt(o[1]);return e.toUpperCase()+`

`+r+`

`+A_(s.getShaderSource(t),a)}else return r}function T_(s,t){const e=w_(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function C_(s,t){let e;switch(t){case pp:e="Linear";break;case mp:e="Reinhard";break;case xp:e="Cineon";break;case gp:e="ACESFilmic";break;case vp:e="AgX";break;case bp:e="Neutral";break;case _p:e="Custom";break;default:kt("WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const bo=new F;function R_(){re.getLuminanceCoefficients(bo);const s=bo.x.toFixed(4),t=bo.y.toFixed(4),e=bo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function P_(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(wr).join(`
`)}function L_(s){const t=[];for(const e in s){const n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function D_(s,t){const e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const r=s.getActiveAttrib(t,i),o=r.name;let a=1;r.type===s.FLOAT_MAT2&&(a=2),r.type===s.FLOAT_MAT3&&(a=3),r.type===s.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:s.getAttribLocation(t,o),locationSize:a}}return e}function wr(s){return s!==""}function gu(s,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function _u(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const I_=/^[ \t]*#include +<([\w\d./]+)>/gm;function ml(s){return s.replace(I_,F_)}const U_=new Map;function F_(s,t){let e=Yt[t];if(e===void 0){const n=U_.get(t);if(n!==void 0)e=Yt[n],kt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return ml(e)}const N_=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function vu(s){return s.replace(N_,O_)}function O_(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function bu(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function B_(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===Fd?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===Yf?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===ri&&(t="SHADOWMAP_TYPE_VSM"),t}function z_(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case qs:case Ys:t="ENVMAP_TYPE_CUBE";break;case va:t="ENVMAP_TYPE_CUBE_UV";break}return t}function V_(s){let t="ENVMAP_MODE_REFLECTION";if(s.envMap)switch(s.envMapMode){case Ys:t="ENVMAP_MODE_REFRACTION";break}return t}function k_(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case Nd:t="ENVMAP_BLENDING_MULTIPLY";break;case dp:t="ENVMAP_BLENDING_MIX";break;case fp:t="ENVMAP_BLENDING_ADD";break}return t}function G_(s){const t=s.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function H_(s,t,e,n){const i=s.getContext(),r=e.defines;let o=e.vertexShader,a=e.fragmentShader;const c=B_(e),l=z_(e),h=V_(e),u=k_(e),d=G_(e),p=P_(e),x=L_(r),g=i.createProgram();let m,f,y=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(wr).join(`
`),m.length>0&&(m+=`
`),f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x].filter(wr).join(`
`),f.length>0&&(f+=`
`)):(m=[bu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(wr).join(`
`),f=[bu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,x,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Bi?"#define TONE_MAPPING":"",e.toneMapping!==Bi?Yt.tonemapping_pars_fragment:"",e.toneMapping!==Bi?C_("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Yt.colorspace_pars_fragment,T_("linearToOutputTexel",e.outputColorSpace),R_(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(wr).join(`
`)),o=ml(o),o=gu(o,e),o=_u(o,e),a=ml(a),a=gu(a,e),a=_u(a,e),o=vu(o),a=vu(a),e.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,f=["#define varying in",e.glslVersion===Ph?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Ph?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const v=y+m+o,b=y+f+a,_=pu(i,i.VERTEX_SHADER,v),M=pu(i,i.FRAGMENT_SHADER,b);i.attachShader(g,_),i.attachShader(g,M),e.index0AttributeName!==void 0?i.bindAttribLocation(g,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(g,0,"position"),i.linkProgram(g);function T(R){if(s.debug.checkShaderErrors){const I=i.getProgramInfoLog(g)||"",z=i.getShaderInfoLog(_)||"",X=i.getShaderInfoLog(M)||"",H=I.trim(),K=z.trim(),G=X.trim();let V=!0,$=!0;if(i.getProgramParameter(g,i.LINK_STATUS)===!1)if(V=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,g,_,M);else{const st=xu(i,_,"vertex"),St=xu(i,M,"fragment");Pe("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(g,i.VALIDATE_STATUS)+`

Material Name: `+R.name+`
Material Type: `+R.type+`

Program Info Log: `+H+`
`+st+`
`+St)}else H!==""?kt("WebGLProgram: Program Info Log:",H):(K===""||G==="")&&($=!1);$&&(R.diagnostics={runnable:V,programLog:H,vertexShader:{log:K,prefix:m},fragmentShader:{log:G,prefix:f}})}i.deleteShader(_),i.deleteShader(M),P=new Jo(i,g),A=D_(i,g)}let P;this.getUniforms=function(){return P===void 0&&T(this),P};let A;this.getAttributes=function(){return A===void 0&&T(this),A};let E=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(g,S_)),E},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(g),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=E_++,this.cacheKey=t,this.usedTimes=1,this.program=g,this.vertexShader=_,this.fragmentShader=M,this}let W_=0;class X_{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),o=this._getShaderCacheForMaterial(t);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new q_(t),e.set(t,n)),n}}class q_{constructor(t){this.id=W_++,this.code=t,this.usedTimes=0}}function Y_(s,t,e,n,i,r,o){const a=new Xl,c=new X_,l=new Set,h=[],u=i.logarithmicDepthBuffer,d=i.vertexTextures;let p=i.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function g(A){return l.add(A),A===0?"uv":`uv${A}`}function m(A,E,R,I,z){const X=I.fog,H=z.geometry,K=A.isMeshStandardMaterial?I.environment:null,G=(A.isMeshStandardMaterial?e:t).get(A.envMap||K),V=G&&G.mapping===va?G.image.height:null,$=x[A.type];A.precision!==null&&(p=i.getMaxPrecision(A.precision),p!==A.precision&&kt("WebGLProgram.getParameters:",A.precision,"not supported, using",p,"instead."));const st=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,St=st!==void 0?st.length:0;let Ht=0;H.morphAttributes.position!==void 0&&(Ht=1),H.morphAttributes.normal!==void 0&&(Ht=2),H.morphAttributes.color!==void 0&&(Ht=3);let ne,ce,le,Z;if($){const he=Xn[$];ne=he.vertexShader,ce=he.fragmentShader}else ne=A.vertexShader,ce=A.fragmentShader,c.update(A),le=c.getVertexShaderID(A),Z=c.getFragmentShaderID(A);const Q=s.getRenderTarget(),ft=s.state.buffers.depth.getReversed(),Ft=z.isInstancedMesh===!0,At=z.isBatchedMesh===!0,Wt=!!A.map,Me=!!A.matcap,qt=!!G,ie=!!A.aoMap,L=!!A.lightMap,Jt=!!A.bumpMap,Qt=!!A.normalMap,xe=!!A.displacementMap,Mt=!!A.emissiveMap,ye=!!A.metalnessMap,Ct=!!A.roughnessMap,Gt=A.anisotropy>0,C=A.clearcoat>0,S=A.dispersion>0,k=A.iridescence>0,j=A.sheen>0,tt=A.transmission>0,Y=Gt&&!!A.anisotropyMap,wt=C&&!!A.clearcoatMap,ht=C&&!!A.clearcoatNormalMap,Rt=C&&!!A.clearcoatRoughnessMap,Et=k&&!!A.iridescenceMap,et=k&&!!A.iridescenceThicknessMap,ot=j&&!!A.sheenColorMap,Ut=j&&!!A.sheenRoughnessMap,Lt=!!A.specularMap,pt=!!A.specularColorMap,Ot=!!A.specularIntensityMap,D=tt&&!!A.transmissionMap,ut=tt&&!!A.thicknessMap,at=!!A.gradientMap,ct=!!A.alphaMap,it=A.alphaTest>0,J=!!A.alphaHash,vt=!!A.extensions;let Vt=Bi;A.toneMapped&&(Q===null||Q.isXRRenderTarget===!0)&&(Vt=s.toneMapping);const ge={shaderID:$,shaderType:A.type,shaderName:A.name,vertexShader:ne,fragmentShader:ce,defines:A.defines,customVertexShaderID:le,customFragmentShaderID:Z,isRawShaderMaterial:A.isRawShaderMaterial===!0,glslVersion:A.glslVersion,precision:p,batching:At,batchingColor:At&&z._colorsTexture!==null,instancing:Ft,instancingColor:Ft&&z.instanceColor!==null,instancingMorph:Ft&&z.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:Q===null?s.outputColorSpace:Q.isXRRenderTarget===!0?Q.texture.colorSpace:$s,alphaToCoverage:!!A.alphaToCoverage,map:Wt,matcap:Me,envMap:qt,envMapMode:qt&&G.mapping,envMapCubeUVHeight:V,aoMap:ie,lightMap:L,bumpMap:Jt,normalMap:Qt,displacementMap:d&&xe,emissiveMap:Mt,normalMapObjectSpace:Qt&&A.normalMapType===Ap,normalMapTangentSpace:Qt&&A.normalMapType===Ep,metalnessMap:ye,roughnessMap:Ct,anisotropy:Gt,anisotropyMap:Y,clearcoat:C,clearcoatMap:wt,clearcoatNormalMap:ht,clearcoatRoughnessMap:Rt,dispersion:S,iridescence:k,iridescenceMap:Et,iridescenceThicknessMap:et,sheen:j,sheenColorMap:ot,sheenRoughnessMap:Ut,specularMap:Lt,specularColorMap:pt,specularIntensityMap:Ot,transmission:tt,transmissionMap:D,thicknessMap:ut,gradientMap:at,opaque:A.transparent===!1&&A.blending===Hs&&A.alphaToCoverage===!1,alphaMap:ct,alphaTest:it,alphaHash:J,combine:A.combine,mapUv:Wt&&g(A.map.channel),aoMapUv:ie&&g(A.aoMap.channel),lightMapUv:L&&g(A.lightMap.channel),bumpMapUv:Jt&&g(A.bumpMap.channel),normalMapUv:Qt&&g(A.normalMap.channel),displacementMapUv:xe&&g(A.displacementMap.channel),emissiveMapUv:Mt&&g(A.emissiveMap.channel),metalnessMapUv:ye&&g(A.metalnessMap.channel),roughnessMapUv:Ct&&g(A.roughnessMap.channel),anisotropyMapUv:Y&&g(A.anisotropyMap.channel),clearcoatMapUv:wt&&g(A.clearcoatMap.channel),clearcoatNormalMapUv:ht&&g(A.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Rt&&g(A.clearcoatRoughnessMap.channel),iridescenceMapUv:Et&&g(A.iridescenceMap.channel),iridescenceThicknessMapUv:et&&g(A.iridescenceThicknessMap.channel),sheenColorMapUv:ot&&g(A.sheenColorMap.channel),sheenRoughnessMapUv:Ut&&g(A.sheenRoughnessMap.channel),specularMapUv:Lt&&g(A.specularMap.channel),specularColorMapUv:pt&&g(A.specularColorMap.channel),specularIntensityMapUv:Ot&&g(A.specularIntensityMap.channel),transmissionMapUv:D&&g(A.transmissionMap.channel),thicknessMapUv:ut&&g(A.thicknessMap.channel),alphaMapUv:ct&&g(A.alphaMap.channel),vertexTangents:!!H.attributes.tangent&&(Qt||Gt),vertexColors:A.vertexColors,vertexAlphas:A.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,pointsUvs:z.isPoints===!0&&!!H.attributes.uv&&(Wt||ct),fog:!!X,useFog:A.fog===!0,fogExp2:!!X&&X.isFogExp2,flatShading:A.flatShading===!0&&A.wireframe===!1,sizeAttenuation:A.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:ft,skinning:z.isSkinnedMesh===!0,morphTargets:H.morphAttributes.position!==void 0,morphNormals:H.morphAttributes.normal!==void 0,morphColors:H.morphAttributes.color!==void 0,morphTargetsCount:St,morphTextureStride:Ht,numDirLights:E.directional.length,numPointLights:E.point.length,numSpotLights:E.spot.length,numSpotLightMaps:E.spotLightMap.length,numRectAreaLights:E.rectArea.length,numHemiLights:E.hemi.length,numDirLightShadows:E.directionalShadowMap.length,numPointLightShadows:E.pointShadowMap.length,numSpotLightShadows:E.spotShadowMap.length,numSpotLightShadowsWithMaps:E.numSpotLightShadowsWithMaps,numLightProbes:E.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:A.dithering,shadowMapEnabled:s.shadowMap.enabled&&R.length>0,shadowMapType:s.shadowMap.type,toneMapping:Vt,decodeVideoTexture:Wt&&A.map.isVideoTexture===!0&&re.getTransfer(A.map.colorSpace)===de,decodeVideoTextureEmissive:Mt&&A.emissiveMap.isVideoTexture===!0&&re.getTransfer(A.emissiveMap.colorSpace)===de,premultipliedAlpha:A.premultipliedAlpha,doubleSided:A.side===Bn,flipSided:A.side===nn,useDepthPacking:A.depthPacking>=0,depthPacking:A.depthPacking||0,index0AttributeName:A.index0AttributeName,extensionClipCullDistance:vt&&A.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(vt&&A.extensions.multiDraw===!0||At)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:A.customProgramCacheKey()};return ge.vertexUv1s=l.has(1),ge.vertexUv2s=l.has(2),ge.vertexUv3s=l.has(3),l.clear(),ge}function f(A){const E=[];if(A.shaderID?E.push(A.shaderID):(E.push(A.customVertexShaderID),E.push(A.customFragmentShaderID)),A.defines!==void 0)for(const R in A.defines)E.push(R),E.push(A.defines[R]);return A.isRawShaderMaterial===!1&&(y(E,A),v(E,A),E.push(s.outputColorSpace)),E.push(A.customProgramCacheKey),E.join()}function y(A,E){A.push(E.precision),A.push(E.outputColorSpace),A.push(E.envMapMode),A.push(E.envMapCubeUVHeight),A.push(E.mapUv),A.push(E.alphaMapUv),A.push(E.lightMapUv),A.push(E.aoMapUv),A.push(E.bumpMapUv),A.push(E.normalMapUv),A.push(E.displacementMapUv),A.push(E.emissiveMapUv),A.push(E.metalnessMapUv),A.push(E.roughnessMapUv),A.push(E.anisotropyMapUv),A.push(E.clearcoatMapUv),A.push(E.clearcoatNormalMapUv),A.push(E.clearcoatRoughnessMapUv),A.push(E.iridescenceMapUv),A.push(E.iridescenceThicknessMapUv),A.push(E.sheenColorMapUv),A.push(E.sheenRoughnessMapUv),A.push(E.specularMapUv),A.push(E.specularColorMapUv),A.push(E.specularIntensityMapUv),A.push(E.transmissionMapUv),A.push(E.thicknessMapUv),A.push(E.combine),A.push(E.fogExp2),A.push(E.sizeAttenuation),A.push(E.morphTargetsCount),A.push(E.morphAttributeCount),A.push(E.numDirLights),A.push(E.numPointLights),A.push(E.numSpotLights),A.push(E.numSpotLightMaps),A.push(E.numHemiLights),A.push(E.numRectAreaLights),A.push(E.numDirLightShadows),A.push(E.numPointLightShadows),A.push(E.numSpotLightShadows),A.push(E.numSpotLightShadowsWithMaps),A.push(E.numLightProbes),A.push(E.shadowMapType),A.push(E.toneMapping),A.push(E.numClippingPlanes),A.push(E.numClipIntersection),A.push(E.depthPacking)}function v(A,E){a.disableAll(),E.supportsVertexTextures&&a.enable(0),E.instancing&&a.enable(1),E.instancingColor&&a.enable(2),E.instancingMorph&&a.enable(3),E.matcap&&a.enable(4),E.envMap&&a.enable(5),E.normalMapObjectSpace&&a.enable(6),E.normalMapTangentSpace&&a.enable(7),E.clearcoat&&a.enable(8),E.iridescence&&a.enable(9),E.alphaTest&&a.enable(10),E.vertexColors&&a.enable(11),E.vertexAlphas&&a.enable(12),E.vertexUv1s&&a.enable(13),E.vertexUv2s&&a.enable(14),E.vertexUv3s&&a.enable(15),E.vertexTangents&&a.enable(16),E.anisotropy&&a.enable(17),E.alphaHash&&a.enable(18),E.batching&&a.enable(19),E.dispersion&&a.enable(20),E.batchingColor&&a.enable(21),E.gradientMap&&a.enable(22),A.push(a.mask),a.disableAll(),E.fog&&a.enable(0),E.useFog&&a.enable(1),E.flatShading&&a.enable(2),E.logarithmicDepthBuffer&&a.enable(3),E.reversedDepthBuffer&&a.enable(4),E.skinning&&a.enable(5),E.morphTargets&&a.enable(6),E.morphNormals&&a.enable(7),E.morphColors&&a.enable(8),E.premultipliedAlpha&&a.enable(9),E.shadowMapEnabled&&a.enable(10),E.doubleSided&&a.enable(11),E.flipSided&&a.enable(12),E.useDepthPacking&&a.enable(13),E.dithering&&a.enable(14),E.transmission&&a.enable(15),E.sheen&&a.enable(16),E.opaque&&a.enable(17),E.pointsUvs&&a.enable(18),E.decodeVideoTexture&&a.enable(19),E.decodeVideoTextureEmissive&&a.enable(20),E.alphaToCoverage&&a.enable(21),A.push(a.mask)}function b(A){const E=x[A.type];let R;if(E){const I=Xn[E];R=m0.clone(I.uniforms)}else R=A.uniforms;return R}function _(A,E){let R;for(let I=0,z=h.length;I<z;I++){const X=h[I];if(X.cacheKey===E){R=X,++R.usedTimes;break}}return R===void 0&&(R=new H_(s,E,A,r),h.push(R)),R}function M(A){if(--A.usedTimes===0){const E=h.indexOf(A);h[E]=h[h.length-1],h.pop(),A.destroy()}}function T(A){c.remove(A)}function P(){c.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:b,acquireProgram:_,releaseProgram:M,releaseShaderCache:T,programs:h,dispose:P}}function $_(){let s=new WeakMap;function t(o){return s.has(o)}function e(o){let a=s.get(o);return a===void 0&&(a={},s.set(o,a)),a}function n(o){s.delete(o)}function i(o,a,c){s.get(o)[a]=c}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function K_(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function Mu(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function yu(){const s=[];let t=0;const e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function o(u,d,p,x,g,m){let f=s[t];return f===void 0?(f={id:u.id,object:u,geometry:d,material:p,groupOrder:x,renderOrder:u.renderOrder,z:g,group:m},s[t]=f):(f.id=u.id,f.object=u,f.geometry=d,f.material=p,f.groupOrder=x,f.renderOrder=u.renderOrder,f.z=g,f.group=m),t++,f}function a(u,d,p,x,g,m){const f=o(u,d,p,x,g,m);p.transmission>0?n.push(f):p.transparent===!0?i.push(f):e.push(f)}function c(u,d,p,x,g,m){const f=o(u,d,p,x,g,m);p.transmission>0?n.unshift(f):p.transparent===!0?i.unshift(f):e.unshift(f)}function l(u,d){e.length>1&&e.sort(u||K_),n.length>1&&n.sort(d||Mu),i.length>1&&i.sort(d||Mu)}function h(){for(let u=t,d=s.length;u<d;u++){const p=s[u];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:a,unshift:c,finish:h,sort:l}}function Z_(){let s=new WeakMap;function t(n,i){const r=s.get(n);let o;return r===void 0?(o=new yu,s.set(n,[o])):i>=r.length?(o=new yu,r.push(o)):o=r[i],o}function e(){s=new WeakMap}return{get:t,dispose:e}}function j_(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new F,color:new ee};break;case"SpotLight":e={position:new F,direction:new F,color:new ee,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new F,color:new ee,distance:0,decay:0};break;case"HemisphereLight":e={direction:new F,skyColor:new ee,groundColor:new ee};break;case"RectAreaLight":e={color:new ee,position:new F,halfWidth:new F,halfHeight:new F};break}return s[t.id]=e,e}}}function J_(){const s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new zt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}let Q_=0;function tv(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function ev(s){const t=new j_,e=J_(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new F);const i=new F,r=new _e,o=new _e;function a(l){let h=0,u=0,d=0;for(let A=0;A<9;A++)n.probe[A].set(0,0,0);let p=0,x=0,g=0,m=0,f=0,y=0,v=0,b=0,_=0,M=0,T=0;l.sort(tv);for(let A=0,E=l.length;A<E;A++){const R=l[A],I=R.color,z=R.intensity,X=R.distance,H=R.shadow&&R.shadow.map?R.shadow.map.texture:null;if(R.isAmbientLight)h+=I.r*z,u+=I.g*z,d+=I.b*z;else if(R.isLightProbe){for(let K=0;K<9;K++)n.probe[K].addScaledVector(R.sh.coefficients[K],z);T++}else if(R.isDirectionalLight){const K=t.get(R);if(K.color.copy(R.color).multiplyScalar(R.intensity),R.castShadow){const G=R.shadow,V=e.get(R);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,n.directionalShadow[p]=V,n.directionalShadowMap[p]=H,n.directionalShadowMatrix[p]=R.shadow.matrix,y++}n.directional[p]=K,p++}else if(R.isSpotLight){const K=t.get(R);K.position.setFromMatrixPosition(R.matrixWorld),K.color.copy(I).multiplyScalar(z),K.distance=X,K.coneCos=Math.cos(R.angle),K.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),K.decay=R.decay,n.spot[g]=K;const G=R.shadow;if(R.map&&(n.spotLightMap[_]=R.map,_++,G.updateMatrices(R),R.castShadow&&M++),n.spotLightMatrix[g]=G.matrix,R.castShadow){const V=e.get(R);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,n.spotShadow[g]=V,n.spotShadowMap[g]=H,b++}g++}else if(R.isRectAreaLight){const K=t.get(R);K.color.copy(I).multiplyScalar(z),K.halfWidth.set(R.width*.5,0,0),K.halfHeight.set(0,R.height*.5,0),n.rectArea[m]=K,m++}else if(R.isPointLight){const K=t.get(R);if(K.color.copy(R.color).multiplyScalar(R.intensity),K.distance=R.distance,K.decay=R.decay,R.castShadow){const G=R.shadow,V=e.get(R);V.shadowIntensity=G.intensity,V.shadowBias=G.bias,V.shadowNormalBias=G.normalBias,V.shadowRadius=G.radius,V.shadowMapSize=G.mapSize,V.shadowCameraNear=G.camera.near,V.shadowCameraFar=G.camera.far,n.pointShadow[x]=V,n.pointShadowMap[x]=H,n.pointShadowMatrix[x]=R.shadow.matrix,v++}n.point[x]=K,x++}else if(R.isHemisphereLight){const K=t.get(R);K.skyColor.copy(R.color).multiplyScalar(z),K.groundColor.copy(R.groundColor).multiplyScalar(z),n.hemi[f]=K,f++}}m>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=lt.LTC_FLOAT_1,n.rectAreaLTC2=lt.LTC_FLOAT_2):(n.rectAreaLTC1=lt.LTC_HALF_1,n.rectAreaLTC2=lt.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const P=n.hash;(P.directionalLength!==p||P.pointLength!==x||P.spotLength!==g||P.rectAreaLength!==m||P.hemiLength!==f||P.numDirectionalShadows!==y||P.numPointShadows!==v||P.numSpotShadows!==b||P.numSpotMaps!==_||P.numLightProbes!==T)&&(n.directional.length=p,n.spot.length=g,n.rectArea.length=m,n.point.length=x,n.hemi.length=f,n.directionalShadow.length=y,n.directionalShadowMap.length=y,n.pointShadow.length=v,n.pointShadowMap.length=v,n.spotShadow.length=b,n.spotShadowMap.length=b,n.directionalShadowMatrix.length=y,n.pointShadowMatrix.length=v,n.spotLightMatrix.length=b+_-M,n.spotLightMap.length=_,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=T,P.directionalLength=p,P.pointLength=x,P.spotLength=g,P.rectAreaLength=m,P.hemiLength=f,P.numDirectionalShadows=y,P.numPointShadows=v,P.numSpotShadows=b,P.numSpotMaps=_,P.numLightProbes=T,n.version=Q_++)}function c(l,h){let u=0,d=0,p=0,x=0,g=0;const m=h.matrixWorldInverse;for(let f=0,y=l.length;f<y;f++){const v=l[f];if(v.isDirectionalLight){const b=n.directional[u];b.direction.setFromMatrixPosition(v.matrixWorld),i.setFromMatrixPosition(v.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(m),u++}else if(v.isSpotLight){const b=n.spot[p];b.position.setFromMatrixPosition(v.matrixWorld),b.position.applyMatrix4(m),b.direction.setFromMatrixPosition(v.matrixWorld),i.setFromMatrixPosition(v.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(m),p++}else if(v.isRectAreaLight){const b=n.rectArea[x];b.position.setFromMatrixPosition(v.matrixWorld),b.position.applyMatrix4(m),o.identity(),r.copy(v.matrixWorld),r.premultiply(m),o.extractRotation(r),b.halfWidth.set(v.width*.5,0,0),b.halfHeight.set(0,v.height*.5,0),b.halfWidth.applyMatrix4(o),b.halfHeight.applyMatrix4(o),x++}else if(v.isPointLight){const b=n.point[d];b.position.setFromMatrixPosition(v.matrixWorld),b.position.applyMatrix4(m),d++}else if(v.isHemisphereLight){const b=n.hemi[g];b.direction.setFromMatrixPosition(v.matrixWorld),b.direction.transformDirection(m),g++}}}return{setup:a,setupView:c,state:n}}function Su(s){const t=new ev(s),e=[],n=[];function i(h){l.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function o(h){n.push(h)}function a(){t.setup(e)}function c(h){t.setupView(e,h)}const l={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:l,setupLights:a,setupLightsView:c,pushLight:r,pushShadow:o}}function nv(s){let t=new WeakMap;function e(i,r=0){const o=t.get(i);let a;return o===void 0?(a=new Su(s),t.set(i,[a])):r>=o.length?(a=new Su(s),o.push(a)):a=o[r],a}function n(){t=new WeakMap}return{get:e,dispose:n}}const iv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,sv=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function rv(s,t,e){let n=new tf;const i=new zt,r=new zt,o=new De,a=new T0({depthPacking:Sp}),c=new C0,l={},h=e.maxTextureSize,u={[zi]:nn,[nn]:zi,[Bn]:Bn},d=new Kn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new zt},radius:{value:4}},vertexShader:iv,fragmentShader:sv}),p=d.clone();p.defines.HORIZONTAL_PASS=1;const x=new Rn;x.setAttribute("position",new _n(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const g=new hn(x,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Fd;let f=this.type;this.render=function(M,T,P){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||M.length===0)return;const A=s.getRenderTarget(),E=s.getActiveCubeFace(),R=s.getActiveMipmapLevel(),I=s.state;I.setBlending(di),I.buffers.depth.getReversed()===!0?I.buffers.color.setClear(0,0,0,0):I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const z=f!==ri&&this.type===ri,X=f===ri&&this.type!==ri;for(let H=0,K=M.length;H<K;H++){const G=M[H],V=G.shadow;if(V===void 0){kt("WebGLShadowMap:",G,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;i.copy(V.mapSize);const $=V.getFrameExtents();if(i.multiply($),r.copy(V.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/$.x),i.x=r.x*$.x,V.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/$.y),i.y=r.y*$.y,V.mapSize.y=r.y)),V.map===null||z===!0||X===!0){const St=this.type!==ri?{minFilter:gn,magFilter:gn}:{};V.map!==null&&V.map.dispose(),V.map=new fs(i.x,i.y,St),V.map.texture.name=G.name+".shadowMap",V.camera.updateProjectionMatrix()}s.setRenderTarget(V.map),s.clear();const st=V.getViewportCount();for(let St=0;St<st;St++){const Ht=V.getViewport(St);o.set(r.x*Ht.x,r.y*Ht.y,r.x*Ht.z,r.y*Ht.w),I.viewport(o),V.updateMatrices(G,St),n=V.getFrustum(),b(T,P,V.camera,G,this.type)}V.isPointLightShadow!==!0&&this.type===ri&&y(V,P),V.needsUpdate=!1}f=this.type,m.needsUpdate=!1,s.setRenderTarget(A,E,R)};function y(M,T){const P=t.update(g);d.defines.VSM_SAMPLES!==M.blurSamples&&(d.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,d.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new fs(i.x,i.y)),d.uniforms.shadow_pass.value=M.map.texture,d.uniforms.resolution.value=M.mapSize,d.uniforms.radius.value=M.radius,s.setRenderTarget(M.mapPass),s.clear(),s.renderBufferDirect(T,null,P,d,g,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value=M.mapSize,p.uniforms.radius.value=M.radius,s.setRenderTarget(M.map),s.clear(),s.renderBufferDirect(T,null,P,p,g,null)}function v(M,T,P,A){let E=null;const R=P.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(R!==void 0)E=R;else if(E=P.isPointLight===!0?c:a,s.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){const I=E.uuid,z=T.uuid;let X=l[I];X===void 0&&(X={},l[I]=X);let H=X[z];H===void 0&&(H=E.clone(),X[z]=H,T.addEventListener("dispose",_)),E=H}if(E.visible=T.visible,E.wireframe=T.wireframe,A===ri?E.side=T.shadowSide!==null?T.shadowSide:T.side:E.side=T.shadowSide!==null?T.shadowSide:u[T.side],E.alphaMap=T.alphaMap,E.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,E.map=T.map,E.clipShadows=T.clipShadows,E.clippingPlanes=T.clippingPlanes,E.clipIntersection=T.clipIntersection,E.displacementMap=T.displacementMap,E.displacementScale=T.displacementScale,E.displacementBias=T.displacementBias,E.wireframeLinewidth=T.wireframeLinewidth,E.linewidth=T.linewidth,P.isPointLight===!0&&E.isMeshDistanceMaterial===!0){const I=s.properties.get(E);I.light=P}return E}function b(M,T,P,A,E){if(M.visible===!1)return;if(M.layers.test(T.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&E===ri)&&(!M.frustumCulled||n.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,M.matrixWorld);const z=t.update(M),X=M.material;if(Array.isArray(X)){const H=z.groups;for(let K=0,G=H.length;K<G;K++){const V=H[K],$=X[V.materialIndex];if($&&$.visible){const st=v(M,$,A,E);M.onBeforeShadow(s,M,T,P,z,st,V),s.renderBufferDirect(P,null,z,st,M,V),M.onAfterShadow(s,M,T,P,z,st,V)}}}else if(X.visible){const H=v(M,X,A,E);M.onBeforeShadow(s,M,T,P,z,H,null),s.renderBufferDirect(P,null,z,H,M,null),M.onAfterShadow(s,M,T,P,z,H,null)}}const I=M.children;for(let z=0,X=I.length;z<X;z++)b(I[z],T,P,A,E)}function _(M){M.target.removeEventListener("dispose",_);for(const P in l){const A=l[P],E=M.target.uuid;E in A&&(A[E].dispose(),delete A[E])}}}const ov={[Pc]:Lc,[Dc]:Fc,[Ic]:Nc,[Xs]:Uc,[Lc]:Pc,[Fc]:Dc,[Nc]:Ic,[Uc]:Xs};function av(s,t){function e(){let D=!1;const ut=new De;let at=null;const ct=new De(0,0,0,0);return{setMask:function(it){at!==it&&!D&&(s.colorMask(it,it,it,it),at=it)},setLocked:function(it){D=it},setClear:function(it,J,vt,Vt,ge){ge===!0&&(it*=Vt,J*=Vt,vt*=Vt),ut.set(it,J,vt,Vt),ct.equals(ut)===!1&&(s.clearColor(it,J,vt,Vt),ct.copy(ut))},reset:function(){D=!1,at=null,ct.set(-1,0,0,0)}}}function n(){let D=!1,ut=!1,at=null,ct=null,it=null;return{setReversed:function(J){if(ut!==J){const vt=t.get("EXT_clip_control");J?vt.clipControlEXT(vt.LOWER_LEFT_EXT,vt.ZERO_TO_ONE_EXT):vt.clipControlEXT(vt.LOWER_LEFT_EXT,vt.NEGATIVE_ONE_TO_ONE_EXT),ut=J;const Vt=it;it=null,this.setClear(Vt)}},getReversed:function(){return ut},setTest:function(J){J?Q(s.DEPTH_TEST):ft(s.DEPTH_TEST)},setMask:function(J){at!==J&&!D&&(s.depthMask(J),at=J)},setFunc:function(J){if(ut&&(J=ov[J]),ct!==J){switch(J){case Pc:s.depthFunc(s.NEVER);break;case Lc:s.depthFunc(s.ALWAYS);break;case Dc:s.depthFunc(s.LESS);break;case Xs:s.depthFunc(s.LEQUAL);break;case Ic:s.depthFunc(s.EQUAL);break;case Uc:s.depthFunc(s.GEQUAL);break;case Fc:s.depthFunc(s.GREATER);break;case Nc:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}ct=J}},setLocked:function(J){D=J},setClear:function(J){it!==J&&(ut&&(J=1-J),s.clearDepth(J),it=J)},reset:function(){D=!1,at=null,ct=null,it=null,ut=!1}}}function i(){let D=!1,ut=null,at=null,ct=null,it=null,J=null,vt=null,Vt=null,ge=null;return{setTest:function(he){D||(he?Q(s.STENCIL_TEST):ft(s.STENCIL_TEST))},setMask:function(he){ut!==he&&!D&&(s.stencilMask(he),ut=he)},setFunc:function(he,Gn,Pn){(at!==he||ct!==Gn||it!==Pn)&&(s.stencilFunc(he,Gn,Pn),at=he,ct=Gn,it=Pn)},setOp:function(he,Gn,Pn){(J!==he||vt!==Gn||Vt!==Pn)&&(s.stencilOp(he,Gn,Pn),J=he,vt=Gn,Vt=Pn)},setLocked:function(he){D=he},setClear:function(he){ge!==he&&(s.clearStencil(he),ge=he)},reset:function(){D=!1,ut=null,at=null,ct=null,it=null,J=null,vt=null,Vt=null,ge=null}}}const r=new e,o=new n,a=new i,c=new WeakMap,l=new WeakMap;let h={},u={},d=new WeakMap,p=[],x=null,g=!1,m=null,f=null,y=null,v=null,b=null,_=null,M=null,T=new ee(0,0,0),P=0,A=!1,E=null,R=null,I=null,z=null,X=null;const H=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let K=!1,G=0;const V=s.getParameter(s.VERSION);V.indexOf("WebGL")!==-1?(G=parseFloat(/^WebGL (\d)/.exec(V)[1]),K=G>=1):V.indexOf("OpenGL ES")!==-1&&(G=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),K=G>=2);let $=null,st={};const St=s.getParameter(s.SCISSOR_BOX),Ht=s.getParameter(s.VIEWPORT),ne=new De().fromArray(St),ce=new De().fromArray(Ht);function le(D,ut,at,ct){const it=new Uint8Array(4),J=s.createTexture();s.bindTexture(D,J),s.texParameteri(D,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(D,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let vt=0;vt<at;vt++)D===s.TEXTURE_3D||D===s.TEXTURE_2D_ARRAY?s.texImage3D(ut,0,s.RGBA,1,1,ct,0,s.RGBA,s.UNSIGNED_BYTE,it):s.texImage2D(ut+vt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,it);return J}const Z={};Z[s.TEXTURE_2D]=le(s.TEXTURE_2D,s.TEXTURE_2D,1),Z[s.TEXTURE_CUBE_MAP]=le(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Z[s.TEXTURE_2D_ARRAY]=le(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Z[s.TEXTURE_3D]=le(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),Q(s.DEPTH_TEST),o.setFunc(Xs),Jt(!1),Qt(Eh),Q(s.CULL_FACE),ie(di);function Q(D){h[D]!==!0&&(s.enable(D),h[D]=!0)}function ft(D){h[D]!==!1&&(s.disable(D),h[D]=!1)}function Ft(D,ut){return u[D]!==ut?(s.bindFramebuffer(D,ut),u[D]=ut,D===s.DRAW_FRAMEBUFFER&&(u[s.FRAMEBUFFER]=ut),D===s.FRAMEBUFFER&&(u[s.DRAW_FRAMEBUFFER]=ut),!0):!1}function At(D,ut){let at=p,ct=!1;if(D){at=d.get(ut),at===void 0&&(at=[],d.set(ut,at));const it=D.textures;if(at.length!==it.length||at[0]!==s.COLOR_ATTACHMENT0){for(let J=0,vt=it.length;J<vt;J++)at[J]=s.COLOR_ATTACHMENT0+J;at.length=it.length,ct=!0}}else at[0]!==s.BACK&&(at[0]=s.BACK,ct=!0);ct&&s.drawBuffers(at)}function Wt(D){return x!==D?(s.useProgram(D),x=D,!0):!1}const Me={[os]:s.FUNC_ADD,[Kf]:s.FUNC_SUBTRACT,[Zf]:s.FUNC_REVERSE_SUBTRACT};Me[jf]=s.MIN,Me[Jf]=s.MAX;const qt={[Qf]:s.ZERO,[tp]:s.ONE,[ep]:s.SRC_COLOR,[Cc]:s.SRC_ALPHA,[ap]:s.SRC_ALPHA_SATURATE,[rp]:s.DST_COLOR,[ip]:s.DST_ALPHA,[np]:s.ONE_MINUS_SRC_COLOR,[Rc]:s.ONE_MINUS_SRC_ALPHA,[op]:s.ONE_MINUS_DST_COLOR,[sp]:s.ONE_MINUS_DST_ALPHA,[cp]:s.CONSTANT_COLOR,[lp]:s.ONE_MINUS_CONSTANT_COLOR,[hp]:s.CONSTANT_ALPHA,[up]:s.ONE_MINUS_CONSTANT_ALPHA};function ie(D,ut,at,ct,it,J,vt,Vt,ge,he){if(D===di){g===!0&&(ft(s.BLEND),g=!1);return}if(g===!1&&(Q(s.BLEND),g=!0),D!==$f){if(D!==m||he!==A){if((f!==os||b!==os)&&(s.blendEquation(s.FUNC_ADD),f=os,b=os),he)switch(D){case Hs:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ah:s.blendFunc(s.ONE,s.ONE);break;case wh:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case Th:s.blendFuncSeparate(s.DST_COLOR,s.ONE_MINUS_SRC_ALPHA,s.ZERO,s.ONE);break;default:Pe("WebGLState: Invalid blending: ",D);break}else switch(D){case Hs:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case Ah:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE,s.ONE,s.ONE);break;case wh:Pe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Th:Pe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Pe("WebGLState: Invalid blending: ",D);break}y=null,v=null,_=null,M=null,T.set(0,0,0),P=0,m=D,A=he}return}it=it||ut,J=J||at,vt=vt||ct,(ut!==f||it!==b)&&(s.blendEquationSeparate(Me[ut],Me[it]),f=ut,b=it),(at!==y||ct!==v||J!==_||vt!==M)&&(s.blendFuncSeparate(qt[at],qt[ct],qt[J],qt[vt]),y=at,v=ct,_=J,M=vt),(Vt.equals(T)===!1||ge!==P)&&(s.blendColor(Vt.r,Vt.g,Vt.b,ge),T.copy(Vt),P=ge),m=D,A=!1}function L(D,ut){D.side===Bn?ft(s.CULL_FACE):Q(s.CULL_FACE);let at=D.side===nn;ut&&(at=!at),Jt(at),D.blending===Hs&&D.transparent===!1?ie(di):ie(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),o.setFunc(D.depthFunc),o.setTest(D.depthTest),o.setMask(D.depthWrite),r.setMask(D.colorWrite);const ct=D.stencilWrite;a.setTest(ct),ct&&(a.setMask(D.stencilWriteMask),a.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),a.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),Mt(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?Q(s.SAMPLE_ALPHA_TO_COVERAGE):ft(s.SAMPLE_ALPHA_TO_COVERAGE)}function Jt(D){E!==D&&(D?s.frontFace(s.CW):s.frontFace(s.CCW),E=D)}function Qt(D){D!==Xf?(Q(s.CULL_FACE),D!==R&&(D===Eh?s.cullFace(s.BACK):D===qf?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):ft(s.CULL_FACE),R=D}function xe(D){D!==I&&(K&&s.lineWidth(D),I=D)}function Mt(D,ut,at){D?(Q(s.POLYGON_OFFSET_FILL),(z!==ut||X!==at)&&(s.polygonOffset(ut,at),z=ut,X=at)):ft(s.POLYGON_OFFSET_FILL)}function ye(D){D?Q(s.SCISSOR_TEST):ft(s.SCISSOR_TEST)}function Ct(D){D===void 0&&(D=s.TEXTURE0+H-1),$!==D&&(s.activeTexture(D),$=D)}function Gt(D,ut,at){at===void 0&&($===null?at=s.TEXTURE0+H-1:at=$);let ct=st[at];ct===void 0&&(ct={type:void 0,texture:void 0},st[at]=ct),(ct.type!==D||ct.texture!==ut)&&($!==at&&(s.activeTexture(at),$=at),s.bindTexture(D,ut||Z[D]),ct.type=D,ct.texture=ut)}function C(){const D=st[$];D!==void 0&&D.type!==void 0&&(s.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function S(){try{s.compressedTexImage2D(...arguments)}catch(D){D("WebGLState:",D)}}function k(){try{s.compressedTexImage3D(...arguments)}catch(D){D("WebGLState:",D)}}function j(){try{s.texSubImage2D(...arguments)}catch(D){D("WebGLState:",D)}}function tt(){try{s.texSubImage3D(...arguments)}catch(D){D("WebGLState:",D)}}function Y(){try{s.compressedTexSubImage2D(...arguments)}catch(D){D("WebGLState:",D)}}function wt(){try{s.compressedTexSubImage3D(...arguments)}catch(D){D("WebGLState:",D)}}function ht(){try{s.texStorage2D(...arguments)}catch(D){D("WebGLState:",D)}}function Rt(){try{s.texStorage3D(...arguments)}catch(D){D("WebGLState:",D)}}function Et(){try{s.texImage2D(...arguments)}catch(D){D("WebGLState:",D)}}function et(){try{s.texImage3D(...arguments)}catch(D){D("WebGLState:",D)}}function ot(D){ne.equals(D)===!1&&(s.scissor(D.x,D.y,D.z,D.w),ne.copy(D))}function Ut(D){ce.equals(D)===!1&&(s.viewport(D.x,D.y,D.z,D.w),ce.copy(D))}function Lt(D,ut){let at=l.get(ut);at===void 0&&(at=new WeakMap,l.set(ut,at));let ct=at.get(D);ct===void 0&&(ct=s.getUniformBlockIndex(ut,D.name),at.set(D,ct))}function pt(D,ut){const ct=l.get(ut).get(D);c.get(ut)!==ct&&(s.uniformBlockBinding(ut,ct,D.__bindingPointIndex),c.set(ut,ct))}function Ot(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),o.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},$=null,st={},u={},d=new WeakMap,p=[],x=null,g=!1,m=null,f=null,y=null,v=null,b=null,_=null,M=null,T=new ee(0,0,0),P=0,A=!1,E=null,R=null,I=null,z=null,X=null,ne.set(0,0,s.canvas.width,s.canvas.height),ce.set(0,0,s.canvas.width,s.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:Q,disable:ft,bindFramebuffer:Ft,drawBuffers:At,useProgram:Wt,setBlending:ie,setMaterial:L,setFlipSided:Jt,setCullFace:Qt,setLineWidth:xe,setPolygonOffset:Mt,setScissorTest:ye,activeTexture:Ct,bindTexture:Gt,unbindTexture:C,compressedTexImage2D:S,compressedTexImage3D:k,texImage2D:Et,texImage3D:et,updateUBOMapping:Lt,uniformBlockBinding:pt,texStorage2D:ht,texStorage3D:Rt,texSubImage2D:j,texSubImage3D:tt,compressedTexSubImage2D:Y,compressedTexSubImage3D:wt,scissor:ot,viewport:Ut,reset:Ot}}function cv(s,t,e,n,i,r,o){const a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new zt,h=new WeakMap;let u;const d=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function x(C,S){return p?new OffscreenCanvas(C,S):oa("canvas")}function g(C,S,k){let j=1;const tt=Gt(C);if((tt.width>k||tt.height>k)&&(j=k/Math.max(tt.width,tt.height)),j<1)if(typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&C instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&C instanceof ImageBitmap||typeof VideoFrame<"u"&&C instanceof VideoFrame){const Y=Math.floor(j*tt.width),wt=Math.floor(j*tt.height);u===void 0&&(u=x(Y,wt));const ht=S?x(Y,wt):u;return ht.width=Y,ht.height=wt,ht.getContext("2d").drawImage(C,0,0,Y,wt),kt("WebGLRenderer: Texture has been resized from ("+tt.width+"x"+tt.height+") to ("+Y+"x"+wt+")."),ht}else return"data"in C&&kt("WebGLRenderer: Image in DataTexture is too big ("+tt.width+"x"+tt.height+")."),C;return C}function m(C){return C.generateMipmaps}function f(C){s.generateMipmap(C)}function y(C){return C.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:C.isWebGL3DRenderTarget?s.TEXTURE_3D:C.isWebGLArrayRenderTarget||C.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function v(C,S,k,j,tt=!1){if(C!==null){if(s[C]!==void 0)return s[C];kt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+C+"'")}let Y=S;if(S===s.RED&&(k===s.FLOAT&&(Y=s.R32F),k===s.HALF_FLOAT&&(Y=s.R16F),k===s.UNSIGNED_BYTE&&(Y=s.R8)),S===s.RED_INTEGER&&(k===s.UNSIGNED_BYTE&&(Y=s.R8UI),k===s.UNSIGNED_SHORT&&(Y=s.R16UI),k===s.UNSIGNED_INT&&(Y=s.R32UI),k===s.BYTE&&(Y=s.R8I),k===s.SHORT&&(Y=s.R16I),k===s.INT&&(Y=s.R32I)),S===s.RG&&(k===s.FLOAT&&(Y=s.RG32F),k===s.HALF_FLOAT&&(Y=s.RG16F),k===s.UNSIGNED_BYTE&&(Y=s.RG8)),S===s.RG_INTEGER&&(k===s.UNSIGNED_BYTE&&(Y=s.RG8UI),k===s.UNSIGNED_SHORT&&(Y=s.RG16UI),k===s.UNSIGNED_INT&&(Y=s.RG32UI),k===s.BYTE&&(Y=s.RG8I),k===s.SHORT&&(Y=s.RG16I),k===s.INT&&(Y=s.RG32I)),S===s.RGB_INTEGER&&(k===s.UNSIGNED_BYTE&&(Y=s.RGB8UI),k===s.UNSIGNED_SHORT&&(Y=s.RGB16UI),k===s.UNSIGNED_INT&&(Y=s.RGB32UI),k===s.BYTE&&(Y=s.RGB8I),k===s.SHORT&&(Y=s.RGB16I),k===s.INT&&(Y=s.RGB32I)),S===s.RGBA_INTEGER&&(k===s.UNSIGNED_BYTE&&(Y=s.RGBA8UI),k===s.UNSIGNED_SHORT&&(Y=s.RGBA16UI),k===s.UNSIGNED_INT&&(Y=s.RGBA32UI),k===s.BYTE&&(Y=s.RGBA8I),k===s.SHORT&&(Y=s.RGBA16I),k===s.INT&&(Y=s.RGBA32I)),S===s.RGB&&(k===s.UNSIGNED_INT_5_9_9_9_REV&&(Y=s.RGB9_E5),k===s.UNSIGNED_INT_10F_11F_11F_REV&&(Y=s.R11F_G11F_B10F)),S===s.RGBA){const wt=tt?sa:re.getTransfer(j);k===s.FLOAT&&(Y=s.RGBA32F),k===s.HALF_FLOAT&&(Y=s.RGBA16F),k===s.UNSIGNED_BYTE&&(Y=wt===de?s.SRGB8_ALPHA8:s.RGBA8),k===s.UNSIGNED_SHORT_4_4_4_4&&(Y=s.RGBA4),k===s.UNSIGNED_SHORT_5_5_5_1&&(Y=s.RGB5_A1)}return(Y===s.R16F||Y===s.R32F||Y===s.RG16F||Y===s.RG32F||Y===s.RGBA16F||Y===s.RGBA32F)&&t.get("EXT_color_buffer_float"),Y}function b(C,S){let k;return C?S===null||S===ds||S===Br?k=s.DEPTH24_STENCIL8:S===qn?k=s.DEPTH32F_STENCIL8:S===Or&&(k=s.DEPTH24_STENCIL8,kt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):S===null||S===ds||S===Br?k=s.DEPTH_COMPONENT24:S===qn?k=s.DEPTH_COMPONENT32F:S===Or&&(k=s.DEPTH_COMPONENT16),k}function _(C,S){return m(C)===!0||C.isFramebufferTexture&&C.minFilter!==gn&&C.minFilter!==cn?Math.log2(Math.max(S.width,S.height))+1:C.mipmaps!==void 0&&C.mipmaps.length>0?C.mipmaps.length:C.isCompressedTexture&&Array.isArray(C.image)?S.mipmaps.length:1}function M(C){const S=C.target;S.removeEventListener("dispose",M),P(S),S.isVideoTexture&&h.delete(S)}function T(C){const S=C.target;S.removeEventListener("dispose",T),E(S)}function P(C){const S=n.get(C);if(S.__webglInit===void 0)return;const k=C.source,j=d.get(k);if(j){const tt=j[S.__cacheKey];tt.usedTimes--,tt.usedTimes===0&&A(C),Object.keys(j).length===0&&d.delete(k)}n.remove(C)}function A(C){const S=n.get(C);s.deleteTexture(S.__webglTexture);const k=C.source,j=d.get(k);delete j[S.__cacheKey],o.memory.textures--}function E(C){const S=n.get(C);if(C.depthTexture&&(C.depthTexture.dispose(),n.remove(C.depthTexture)),C.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(S.__webglFramebuffer[j]))for(let tt=0;tt<S.__webglFramebuffer[j].length;tt++)s.deleteFramebuffer(S.__webglFramebuffer[j][tt]);else s.deleteFramebuffer(S.__webglFramebuffer[j]);S.__webglDepthbuffer&&s.deleteRenderbuffer(S.__webglDepthbuffer[j])}else{if(Array.isArray(S.__webglFramebuffer))for(let j=0;j<S.__webglFramebuffer.length;j++)s.deleteFramebuffer(S.__webglFramebuffer[j]);else s.deleteFramebuffer(S.__webglFramebuffer);if(S.__webglDepthbuffer&&s.deleteRenderbuffer(S.__webglDepthbuffer),S.__webglMultisampledFramebuffer&&s.deleteFramebuffer(S.__webglMultisampledFramebuffer),S.__webglColorRenderbuffer)for(let j=0;j<S.__webglColorRenderbuffer.length;j++)S.__webglColorRenderbuffer[j]&&s.deleteRenderbuffer(S.__webglColorRenderbuffer[j]);S.__webglDepthRenderbuffer&&s.deleteRenderbuffer(S.__webglDepthRenderbuffer)}const k=C.textures;for(let j=0,tt=k.length;j<tt;j++){const Y=n.get(k[j]);Y.__webglTexture&&(s.deleteTexture(Y.__webglTexture),o.memory.textures--),n.remove(k[j])}n.remove(C)}let R=0;function I(){R=0}function z(){const C=R;return C>=i.maxTextures&&kt("WebGLTextures: Trying to use "+C+" texture units while this GPU supports only "+i.maxTextures),R+=1,C}function X(C){const S=[];return S.push(C.wrapS),S.push(C.wrapT),S.push(C.wrapR||0),S.push(C.magFilter),S.push(C.minFilter),S.push(C.anisotropy),S.push(C.internalFormat),S.push(C.format),S.push(C.type),S.push(C.generateMipmaps),S.push(C.premultiplyAlpha),S.push(C.flipY),S.push(C.unpackAlignment),S.push(C.colorSpace),S.join()}function H(C,S){const k=n.get(C);if(C.isVideoTexture&&ye(C),C.isRenderTargetTexture===!1&&C.isExternalTexture!==!0&&C.version>0&&k.__version!==C.version){const j=C.image;if(j===null)kt("WebGLRenderer: Texture marked for update but no image data found.");else if(j.complete===!1)kt("WebGLRenderer: Texture marked for update but image is incomplete");else{Z(k,C,S);return}}else C.isExternalTexture&&(k.__webglTexture=C.sourceTexture?C.sourceTexture:null);e.bindTexture(s.TEXTURE_2D,k.__webglTexture,s.TEXTURE0+S)}function K(C,S){const k=n.get(C);if(C.isRenderTargetTexture===!1&&C.version>0&&k.__version!==C.version){Z(k,C,S);return}else C.isExternalTexture&&(k.__webglTexture=C.sourceTexture?C.sourceTexture:null);e.bindTexture(s.TEXTURE_2D_ARRAY,k.__webglTexture,s.TEXTURE0+S)}function G(C,S){const k=n.get(C);if(C.isRenderTargetTexture===!1&&C.version>0&&k.__version!==C.version){Z(k,C,S);return}e.bindTexture(s.TEXTURE_3D,k.__webglTexture,s.TEXTURE0+S)}function V(C,S){const k=n.get(C);if(C.version>0&&k.__version!==C.version){Q(k,C,S);return}e.bindTexture(s.TEXTURE_CUBE_MAP,k.__webglTexture,s.TEXTURE0+S)}const $={[ia]:s.REPEAT,[li]:s.CLAMP_TO_EDGE,[zc]:s.MIRRORED_REPEAT},st={[gn]:s.NEAREST,[Mp]:s.NEAREST_MIPMAP_NEAREST,[Qr]:s.NEAREST_MIPMAP_LINEAR,[cn]:s.LINEAR,[Ca]:s.LINEAR_MIPMAP_NEAREST,[hs]:s.LINEAR_MIPMAP_LINEAR},St={[wp]:s.NEVER,[Dp]:s.ALWAYS,[Tp]:s.LESS,[Wd]:s.LEQUAL,[Cp]:s.EQUAL,[Lp]:s.GEQUAL,[Rp]:s.GREATER,[Pp]:s.NOTEQUAL};function Ht(C,S){if(S.type===qn&&t.has("OES_texture_float_linear")===!1&&(S.magFilter===cn||S.magFilter===Ca||S.magFilter===Qr||S.magFilter===hs||S.minFilter===cn||S.minFilter===Ca||S.minFilter===Qr||S.minFilter===hs)&&kt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(C,s.TEXTURE_WRAP_S,$[S.wrapS]),s.texParameteri(C,s.TEXTURE_WRAP_T,$[S.wrapT]),(C===s.TEXTURE_3D||C===s.TEXTURE_2D_ARRAY)&&s.texParameteri(C,s.TEXTURE_WRAP_R,$[S.wrapR]),s.texParameteri(C,s.TEXTURE_MAG_FILTER,st[S.magFilter]),s.texParameteri(C,s.TEXTURE_MIN_FILTER,st[S.minFilter]),S.compareFunction&&(s.texParameteri(C,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(C,s.TEXTURE_COMPARE_FUNC,St[S.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(S.magFilter===gn||S.minFilter!==Qr&&S.minFilter!==hs||S.type===qn&&t.has("OES_texture_float_linear")===!1)return;if(S.anisotropy>1||n.get(S).__currentAnisotropy){const k=t.get("EXT_texture_filter_anisotropic");s.texParameterf(C,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(S.anisotropy,i.getMaxAnisotropy())),n.get(S).__currentAnisotropy=S.anisotropy}}}function ne(C,S){let k=!1;C.__webglInit===void 0&&(C.__webglInit=!0,S.addEventListener("dispose",M));const j=S.source;let tt=d.get(j);tt===void 0&&(tt={},d.set(j,tt));const Y=X(S);if(Y!==C.__cacheKey){tt[Y]===void 0&&(tt[Y]={texture:s.createTexture(),usedTimes:0},o.memory.textures++,k=!0),tt[Y].usedTimes++;const wt=tt[C.__cacheKey];wt!==void 0&&(tt[C.__cacheKey].usedTimes--,wt.usedTimes===0&&A(S)),C.__cacheKey=Y,C.__webglTexture=tt[Y].texture}return k}function ce(C,S,k){return Math.floor(Math.floor(C/k)/S)}function le(C,S,k,j){const Y=C.updateRanges;if(Y.length===0)e.texSubImage2D(s.TEXTURE_2D,0,0,0,S.width,S.height,k,j,S.data);else{Y.sort((et,ot)=>et.start-ot.start);let wt=0;for(let et=1;et<Y.length;et++){const ot=Y[wt],Ut=Y[et],Lt=ot.start+ot.count,pt=ce(Ut.start,S.width,4),Ot=ce(ot.start,S.width,4);Ut.start<=Lt+1&&pt===Ot&&ce(Ut.start+Ut.count-1,S.width,4)===pt?ot.count=Math.max(ot.count,Ut.start+Ut.count-ot.start):(++wt,Y[wt]=Ut)}Y.length=wt+1;const ht=s.getParameter(s.UNPACK_ROW_LENGTH),Rt=s.getParameter(s.UNPACK_SKIP_PIXELS),Et=s.getParameter(s.UNPACK_SKIP_ROWS);s.pixelStorei(s.UNPACK_ROW_LENGTH,S.width);for(let et=0,ot=Y.length;et<ot;et++){const Ut=Y[et],Lt=Math.floor(Ut.start/4),pt=Math.ceil(Ut.count/4),Ot=Lt%S.width,D=Math.floor(Lt/S.width),ut=pt,at=1;s.pixelStorei(s.UNPACK_SKIP_PIXELS,Ot),s.pixelStorei(s.UNPACK_SKIP_ROWS,D),e.texSubImage2D(s.TEXTURE_2D,0,Ot,D,ut,at,k,j,S.data)}C.clearUpdateRanges(),s.pixelStorei(s.UNPACK_ROW_LENGTH,ht),s.pixelStorei(s.UNPACK_SKIP_PIXELS,Rt),s.pixelStorei(s.UNPACK_SKIP_ROWS,Et)}}function Z(C,S,k){let j=s.TEXTURE_2D;(S.isDataArrayTexture||S.isCompressedArrayTexture)&&(j=s.TEXTURE_2D_ARRAY),S.isData3DTexture&&(j=s.TEXTURE_3D);const tt=ne(C,S),Y=S.source;e.bindTexture(j,C.__webglTexture,s.TEXTURE0+k);const wt=n.get(Y);if(Y.version!==wt.__version||tt===!0){e.activeTexture(s.TEXTURE0+k);const ht=re.getPrimaries(re.workingColorSpace),Rt=S.colorSpace===Ui?null:re.getPrimaries(S.colorSpace),Et=S.colorSpace===Ui||ht===Rt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Et);let et=g(S.image,!1,i.maxTextureSize);et=Ct(S,et);const ot=r.convert(S.format,S.colorSpace),Ut=r.convert(S.type);let Lt=v(S.internalFormat,ot,Ut,S.colorSpace,S.isVideoTexture);Ht(j,S);let pt;const Ot=S.mipmaps,D=S.isVideoTexture!==!0,ut=wt.__version===void 0||tt===!0,at=Y.dataReady,ct=_(S,et);if(S.isDepthTexture)Lt=b(S.format===Vr,S.type),ut&&(D?e.texStorage2D(s.TEXTURE_2D,1,Lt,et.width,et.height):e.texImage2D(s.TEXTURE_2D,0,Lt,et.width,et.height,0,ot,Ut,null));else if(S.isDataTexture)if(Ot.length>0){D&&ut&&e.texStorage2D(s.TEXTURE_2D,ct,Lt,Ot[0].width,Ot[0].height);for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],D?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,Ut,pt.data):e.texImage2D(s.TEXTURE_2D,it,Lt,pt.width,pt.height,0,ot,Ut,pt.data);S.generateMipmaps=!1}else D?(ut&&e.texStorage2D(s.TEXTURE_2D,ct,Lt,et.width,et.height),at&&le(S,et,ot,Ut)):e.texImage2D(s.TEXTURE_2D,0,Lt,et.width,et.height,0,ot,Ut,et.data);else if(S.isCompressedTexture)if(S.isCompressedArrayTexture){D&&ut&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ct,Lt,Ot[0].width,Ot[0].height,et.depth);for(let it=0,J=Ot.length;it<J;it++)if(pt=Ot[it],S.format!==Vn)if(ot!==null)if(D){if(at)if(S.layerUpdates.size>0){const vt=tu(pt.width,pt.height,S.format,S.type);for(const Vt of S.layerUpdates){const ge=pt.data.subarray(Vt*vt/pt.data.BYTES_PER_ELEMENT,(Vt+1)*vt/pt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,Vt,pt.width,pt.height,1,ot,ge)}S.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,0,pt.width,pt.height,et.depth,ot,pt.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,it,Lt,pt.width,pt.height,et.depth,0,pt.data,0,0);else kt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else D?at&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,it,0,0,0,pt.width,pt.height,et.depth,ot,Ut,pt.data):e.texImage3D(s.TEXTURE_2D_ARRAY,it,Lt,pt.width,pt.height,et.depth,0,ot,Ut,pt.data)}else{D&&ut&&e.texStorage2D(s.TEXTURE_2D,ct,Lt,Ot[0].width,Ot[0].height);for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],S.format!==Vn?ot!==null?D?at&&e.compressedTexSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,pt.data):e.compressedTexImage2D(s.TEXTURE_2D,it,Lt,pt.width,pt.height,0,pt.data):kt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):D?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,pt.width,pt.height,ot,Ut,pt.data):e.texImage2D(s.TEXTURE_2D,it,Lt,pt.width,pt.height,0,ot,Ut,pt.data)}else if(S.isDataArrayTexture)if(D){if(ut&&e.texStorage3D(s.TEXTURE_2D_ARRAY,ct,Lt,et.width,et.height,et.depth),at)if(S.layerUpdates.size>0){const it=tu(et.width,et.height,S.format,S.type);for(const J of S.layerUpdates){const vt=et.data.subarray(J*it/et.data.BYTES_PER_ELEMENT,(J+1)*it/et.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,J,et.width,et.height,1,ot,Ut,vt)}S.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,et.width,et.height,et.depth,ot,Ut,et.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,Lt,et.width,et.height,et.depth,0,ot,Ut,et.data);else if(S.isData3DTexture)D?(ut&&e.texStorage3D(s.TEXTURE_3D,ct,Lt,et.width,et.height,et.depth),at&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,et.width,et.height,et.depth,ot,Ut,et.data)):e.texImage3D(s.TEXTURE_3D,0,Lt,et.width,et.height,et.depth,0,ot,Ut,et.data);else if(S.isFramebufferTexture){if(ut)if(D)e.texStorage2D(s.TEXTURE_2D,ct,Lt,et.width,et.height);else{let it=et.width,J=et.height;for(let vt=0;vt<ct;vt++)e.texImage2D(s.TEXTURE_2D,vt,Lt,it,J,0,ot,Ut,null),it>>=1,J>>=1}}else if(Ot.length>0){if(D&&ut){const it=Gt(Ot[0]);e.texStorage2D(s.TEXTURE_2D,ct,Lt,it.width,it.height)}for(let it=0,J=Ot.length;it<J;it++)pt=Ot[it],D?at&&e.texSubImage2D(s.TEXTURE_2D,it,0,0,ot,Ut,pt):e.texImage2D(s.TEXTURE_2D,it,Lt,ot,Ut,pt);S.generateMipmaps=!1}else if(D){if(ut){const it=Gt(et);e.texStorage2D(s.TEXTURE_2D,ct,Lt,it.width,it.height)}at&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,ot,Ut,et)}else e.texImage2D(s.TEXTURE_2D,0,Lt,ot,Ut,et);m(S)&&f(j),wt.__version=Y.version,S.onUpdate&&S.onUpdate(S)}C.__version=S.version}function Q(C,S,k){if(S.image.length!==6)return;const j=ne(C,S),tt=S.source;e.bindTexture(s.TEXTURE_CUBE_MAP,C.__webglTexture,s.TEXTURE0+k);const Y=n.get(tt);if(tt.version!==Y.__version||j===!0){e.activeTexture(s.TEXTURE0+k);const wt=re.getPrimaries(re.workingColorSpace),ht=S.colorSpace===Ui?null:re.getPrimaries(S.colorSpace),Rt=S.colorSpace===Ui||wt===ht?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,S.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,S.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,S.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Rt);const Et=S.isCompressedTexture||S.image[0].isCompressedTexture,et=S.image[0]&&S.image[0].isDataTexture,ot=[];for(let J=0;J<6;J++)!Et&&!et?ot[J]=g(S.image[J],!0,i.maxCubemapSize):ot[J]=et?S.image[J].image:S.image[J],ot[J]=Ct(S,ot[J]);const Ut=ot[0],Lt=r.convert(S.format,S.colorSpace),pt=r.convert(S.type),Ot=v(S.internalFormat,Lt,pt,S.colorSpace),D=S.isVideoTexture!==!0,ut=Y.__version===void 0||j===!0,at=tt.dataReady;let ct=_(S,Ut);Ht(s.TEXTURE_CUBE_MAP,S);let it;if(Et){D&&ut&&e.texStorage2D(s.TEXTURE_CUBE_MAP,ct,Ot,Ut.width,Ut.height);for(let J=0;J<6;J++){it=ot[J].mipmaps;for(let vt=0;vt<it.length;vt++){const Vt=it[vt];S.format!==Vn?Lt!==null?D?at&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,0,0,Vt.width,Vt.height,Lt,Vt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,Ot,Vt.width,Vt.height,0,Vt.data):kt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,0,0,Vt.width,Vt.height,Lt,pt,Vt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt,Ot,Vt.width,Vt.height,0,Lt,pt,Vt.data)}}}else{if(it=S.mipmaps,D&&ut){it.length>0&&ct++;const J=Gt(ot[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,ct,Ot,J.width,J.height)}for(let J=0;J<6;J++)if(et){D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,ot[J].width,ot[J].height,Lt,pt,ot[J].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,Ot,ot[J].width,ot[J].height,0,Lt,pt,ot[J].data);for(let vt=0;vt<it.length;vt++){const ge=it[vt].image[J].image;D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,0,0,ge.width,ge.height,Lt,pt,ge.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,Ot,ge.width,ge.height,0,Lt,pt,ge.data)}}else{D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,0,0,Lt,pt,ot[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,0,Ot,Lt,pt,ot[J]);for(let vt=0;vt<it.length;vt++){const Vt=it[vt];D?at&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,0,0,Lt,pt,Vt.image[J]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+J,vt+1,Ot,Lt,pt,Vt.image[J])}}}m(S)&&f(s.TEXTURE_CUBE_MAP),Y.__version=tt.version,S.onUpdate&&S.onUpdate(S)}C.__version=S.version}function ft(C,S,k,j,tt,Y){const wt=r.convert(k.format,k.colorSpace),ht=r.convert(k.type),Rt=v(k.internalFormat,wt,ht,k.colorSpace),Et=n.get(S),et=n.get(k);if(et.__renderTarget=S,!Et.__hasExternalTextures){const ot=Math.max(1,S.width>>Y),Ut=Math.max(1,S.height>>Y);tt===s.TEXTURE_3D||tt===s.TEXTURE_2D_ARRAY?e.texImage3D(tt,Y,Rt,ot,Ut,S.depth,0,wt,ht,null):e.texImage2D(tt,Y,Rt,ot,Ut,0,wt,ht,null)}e.bindFramebuffer(s.FRAMEBUFFER,C),Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,j,tt,et.__webglTexture,0,xe(S)):(tt===s.TEXTURE_2D||tt>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&tt<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,j,tt,et.__webglTexture,Y),e.bindFramebuffer(s.FRAMEBUFFER,null)}function Ft(C,S,k){if(s.bindRenderbuffer(s.RENDERBUFFER,C),S.depthBuffer){const j=S.depthTexture,tt=j&&j.isDepthTexture?j.type:null,Y=b(S.stencilBuffer,tt),wt=S.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,ht=xe(S);Mt(S)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ht,Y,S.width,S.height):k?s.renderbufferStorageMultisample(s.RENDERBUFFER,ht,Y,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,Y,S.width,S.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,wt,s.RENDERBUFFER,C)}else{const j=S.textures;for(let tt=0;tt<j.length;tt++){const Y=j[tt],wt=r.convert(Y.format,Y.colorSpace),ht=r.convert(Y.type),Rt=v(Y.internalFormat,wt,ht,Y.colorSpace),Et=xe(S);k&&Mt(S)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,Et,Rt,S.width,S.height):Mt(S)?a.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,Et,Rt,S.width,S.height):s.renderbufferStorage(s.RENDERBUFFER,Rt,S.width,S.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function At(C,S){if(S&&S.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,C),!(S.depthTexture&&S.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const j=n.get(S.depthTexture);j.__renderTarget=S,(!j.__webglTexture||S.depthTexture.image.width!==S.width||S.depthTexture.image.height!==S.height)&&(S.depthTexture.image.width=S.width,S.depthTexture.image.height=S.height,S.depthTexture.needsUpdate=!0),H(S.depthTexture,0);const tt=j.__webglTexture,Y=xe(S);if(S.depthTexture.format===zr)Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0,Y):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,tt,0);else if(S.depthTexture.format===Vr)Mt(S)?a.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0,Y):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,tt,0);else throw new Error("Unknown depthTexture format")}function Wt(C){const S=n.get(C),k=C.isWebGLCubeRenderTarget===!0;if(S.__boundDepthTexture!==C.depthTexture){const j=C.depthTexture;if(S.__depthDisposeCallback&&S.__depthDisposeCallback(),j){const tt=()=>{delete S.__boundDepthTexture,delete S.__depthDisposeCallback,j.removeEventListener("dispose",tt)};j.addEventListener("dispose",tt),S.__depthDisposeCallback=tt}S.__boundDepthTexture=j}if(C.depthTexture&&!S.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");const j=C.texture.mipmaps;j&&j.length>0?At(S.__webglFramebuffer[0],C):At(S.__webglFramebuffer,C)}else if(k){S.__webglDepthbuffer=[];for(let j=0;j<6;j++)if(e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer[j]),S.__webglDepthbuffer[j]===void 0)S.__webglDepthbuffer[j]=s.createRenderbuffer(),Ft(S.__webglDepthbuffer[j],C,!1);else{const tt=C.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Y=S.__webglDepthbuffer[j];s.bindRenderbuffer(s.RENDERBUFFER,Y),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,Y)}}else{const j=C.texture.mipmaps;if(j&&j.length>0?e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer[0]):e.bindFramebuffer(s.FRAMEBUFFER,S.__webglFramebuffer),S.__webglDepthbuffer===void 0)S.__webglDepthbuffer=s.createRenderbuffer(),Ft(S.__webglDepthbuffer,C,!1);else{const tt=C.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,Y=S.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,Y),s.framebufferRenderbuffer(s.FRAMEBUFFER,tt,s.RENDERBUFFER,Y)}}e.bindFramebuffer(s.FRAMEBUFFER,null)}function Me(C,S,k){const j=n.get(C);S!==void 0&&ft(j.__webglFramebuffer,C,C.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),k!==void 0&&Wt(C)}function qt(C){const S=C.texture,k=n.get(C),j=n.get(S);C.addEventListener("dispose",T);const tt=C.textures,Y=C.isWebGLCubeRenderTarget===!0,wt=tt.length>1;if(wt||(j.__webglTexture===void 0&&(j.__webglTexture=s.createTexture()),j.__version=S.version,o.memory.textures++),Y){k.__webglFramebuffer=[];for(let ht=0;ht<6;ht++)if(S.mipmaps&&S.mipmaps.length>0){k.__webglFramebuffer[ht]=[];for(let Rt=0;Rt<S.mipmaps.length;Rt++)k.__webglFramebuffer[ht][Rt]=s.createFramebuffer()}else k.__webglFramebuffer[ht]=s.createFramebuffer()}else{if(S.mipmaps&&S.mipmaps.length>0){k.__webglFramebuffer=[];for(let ht=0;ht<S.mipmaps.length;ht++)k.__webglFramebuffer[ht]=s.createFramebuffer()}else k.__webglFramebuffer=s.createFramebuffer();if(wt)for(let ht=0,Rt=tt.length;ht<Rt;ht++){const Et=n.get(tt[ht]);Et.__webglTexture===void 0&&(Et.__webglTexture=s.createTexture(),o.memory.textures++)}if(C.samples>0&&Mt(C)===!1){k.__webglMultisampledFramebuffer=s.createFramebuffer(),k.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let ht=0;ht<tt.length;ht++){const Rt=tt[ht];k.__webglColorRenderbuffer[ht]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,k.__webglColorRenderbuffer[ht]);const Et=r.convert(Rt.format,Rt.colorSpace),et=r.convert(Rt.type),ot=v(Rt.internalFormat,Et,et,Rt.colorSpace,C.isXRRenderTarget===!0),Ut=xe(C);s.renderbufferStorageMultisample(s.RENDERBUFFER,Ut,ot,C.width,C.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ht,s.RENDERBUFFER,k.__webglColorRenderbuffer[ht])}s.bindRenderbuffer(s.RENDERBUFFER,null),C.depthBuffer&&(k.__webglDepthRenderbuffer=s.createRenderbuffer(),Ft(k.__webglDepthRenderbuffer,C,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(Y){e.bindTexture(s.TEXTURE_CUBE_MAP,j.__webglTexture),Ht(s.TEXTURE_CUBE_MAP,S);for(let ht=0;ht<6;ht++)if(S.mipmaps&&S.mipmaps.length>0)for(let Rt=0;Rt<S.mipmaps.length;Rt++)ft(k.__webglFramebuffer[ht][Rt],C,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ht,Rt);else ft(k.__webglFramebuffer[ht],C,S,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ht,0);m(S)&&f(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(wt){for(let ht=0,Rt=tt.length;ht<Rt;ht++){const Et=tt[ht],et=n.get(Et);let ot=s.TEXTURE_2D;(C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(ot=C.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ot,et.__webglTexture),Ht(ot,Et),ft(k.__webglFramebuffer,C,Et,s.COLOR_ATTACHMENT0+ht,ot,0),m(Et)&&f(ot)}e.unbindTexture()}else{let ht=s.TEXTURE_2D;if((C.isWebGL3DRenderTarget||C.isWebGLArrayRenderTarget)&&(ht=C.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ht,j.__webglTexture),Ht(ht,S),S.mipmaps&&S.mipmaps.length>0)for(let Rt=0;Rt<S.mipmaps.length;Rt++)ft(k.__webglFramebuffer[Rt],C,S,s.COLOR_ATTACHMENT0,ht,Rt);else ft(k.__webglFramebuffer,C,S,s.COLOR_ATTACHMENT0,ht,0);m(S)&&f(ht),e.unbindTexture()}C.depthBuffer&&Wt(C)}function ie(C){const S=C.textures;for(let k=0,j=S.length;k<j;k++){const tt=S[k];if(m(tt)){const Y=y(C),wt=n.get(tt).__webglTexture;e.bindTexture(Y,wt),f(Y),e.unbindTexture()}}}const L=[],Jt=[];function Qt(C){if(C.samples>0){if(Mt(C)===!1){const S=C.textures,k=C.width,j=C.height;let tt=s.COLOR_BUFFER_BIT;const Y=C.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,wt=n.get(C),ht=S.length>1;if(ht)for(let Et=0;Et<S.length;Et++)e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,wt.__webglMultisampledFramebuffer);const Rt=C.texture.mipmaps;Rt&&Rt.length>0?e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglFramebuffer[0]):e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglFramebuffer);for(let Et=0;Et<S.length;Et++){if(C.resolveDepthBuffer&&(C.depthBuffer&&(tt|=s.DEPTH_BUFFER_BIT),C.stencilBuffer&&C.resolveStencilBuffer&&(tt|=s.STENCIL_BUFFER_BIT)),ht){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,wt.__webglColorRenderbuffer[Et]);const et=n.get(S[Et]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,et,0)}s.blitFramebuffer(0,0,k,j,0,0,k,j,tt,s.NEAREST),c===!0&&(L.length=0,Jt.length=0,L.push(s.COLOR_ATTACHMENT0+Et),C.depthBuffer&&C.resolveDepthBuffer===!1&&(L.push(Y),Jt.push(Y),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,Jt)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,L))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ht)for(let Et=0;Et<S.length;Et++){e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.RENDERBUFFER,wt.__webglColorRenderbuffer[Et]);const et=n.get(S[Et]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,wt.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+Et,s.TEXTURE_2D,et,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,wt.__webglMultisampledFramebuffer)}else if(C.depthBuffer&&C.resolveDepthBuffer===!1&&c){const S=C.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[S])}}}function xe(C){return Math.min(i.maxSamples,C.samples)}function Mt(C){const S=n.get(C);return C.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&S.__useRenderToTexture!==!1}function ye(C){const S=o.render.frame;h.get(C)!==S&&(h.set(C,S),C.update())}function Ct(C,S){const k=C.colorSpace,j=C.format,tt=C.type;return C.isCompressedTexture===!0||C.isVideoTexture===!0||k!==$s&&k!==Ui&&(re.getTransfer(k)===de?(j!==Vn||tt!==pi)&&kt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Pe("WebGLTextures: Unsupported texture color space:",k)),S}function Gt(C){return typeof HTMLImageElement<"u"&&C instanceof HTMLImageElement?(l.width=C.naturalWidth||C.width,l.height=C.naturalHeight||C.height):typeof VideoFrame<"u"&&C instanceof VideoFrame?(l.width=C.displayWidth,l.height=C.displayHeight):(l.width=C.width,l.height=C.height),l}this.allocateTextureUnit=z,this.resetTextureUnits=I,this.setTexture2D=H,this.setTexture2DArray=K,this.setTexture3D=G,this.setTextureCube=V,this.rebindTextures=Me,this.setupRenderTarget=qt,this.updateRenderTargetMipmap=ie,this.updateMultisampleRenderTarget=Qt,this.setupDepthRenderbuffer=Wt,this.setupFrameBufferTexture=ft,this.useMultisampledRTT=Mt}function lv(s,t){function e(n,i=Ui){let r;const o=re.getTransfer(i);if(n===pi)return s.UNSIGNED_BYTE;if(n===Ul)return s.UNSIGNED_SHORT_4_4_4_4;if(n===Fl)return s.UNSIGNED_SHORT_5_5_5_1;if(n===Vd)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===kd)return s.UNSIGNED_INT_10F_11F_11F_REV;if(n===Bd)return s.BYTE;if(n===zd)return s.SHORT;if(n===Or)return s.UNSIGNED_SHORT;if(n===Il)return s.INT;if(n===ds)return s.UNSIGNED_INT;if(n===qn)return s.FLOAT;if(n===Js)return s.HALF_FLOAT;if(n===Gd)return s.ALPHA;if(n===Hd)return s.RGB;if(n===Vn)return s.RGBA;if(n===zr)return s.DEPTH_COMPONENT;if(n===Vr)return s.DEPTH_STENCIL;if(n===Nl)return s.RED;if(n===Ol)return s.RED_INTEGER;if(n===Bl)return s.RG;if(n===zl)return s.RG_INTEGER;if(n===Vl)return s.RGBA_INTEGER;if(n===$o||n===Ko||n===Zo||n===jo)if(o===de)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===$o)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ko)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Zo)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===jo)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===$o)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ko)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Zo)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===jo)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Vc||n===kc||n===Gc||n===Hc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Vc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===kc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Gc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Hc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Wc||n===Xc||n===qc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Wc||n===Xc)return o===de?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===qc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Yc||n===$c||n===Kc||n===Zc||n===jc||n===Jc||n===Qc||n===tl||n===el||n===nl||n===il||n===sl||n===rl||n===ol)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Yc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===$c)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Kc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Zc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===jc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Jc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Qc)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===tl)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===el)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===nl)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===il)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===sl)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===rl)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ol)return o===de?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===al||n===cl||n===ll)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===al)return o===de?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===cl)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===ll)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===hl||n===ul||n===dl||n===fl)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===hl)return r.COMPRESSED_RED_RGTC1_EXT;if(n===ul)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===dl)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===fl)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Br?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}const hv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,uv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class dv{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){const n=new nf(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new Kn({vertexShader:hv,fragmentShader:uv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new hn(new Hi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class fv extends xs{constructor(t,e){super();const n=this;let i=null,r=1,o=null,a="local-floor",c=1,l=null,h=null,u=null,d=null,p=null,x=null;const g=typeof XRWebGLBinding<"u",m=new dv,f={},y=e.getContextAttributes();let v=null,b=null;const _=[],M=[],T=new zt;let P=null;const A=new wn;A.viewport=new De;const E=new wn;E.viewport=new De;const R=[A,E],I=new P0;let z=null,X=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let Q=_[Z];return Q===void 0&&(Q=new Ka,_[Z]=Q),Q.getTargetRaySpace()},this.getControllerGrip=function(Z){let Q=_[Z];return Q===void 0&&(Q=new Ka,_[Z]=Q),Q.getGripSpace()},this.getHand=function(Z){let Q=_[Z];return Q===void 0&&(Q=new Ka,_[Z]=Q),Q.getHandSpace()};function H(Z){const Q=M.indexOf(Z.inputSource);if(Q===-1)return;const ft=_[Q];ft!==void 0&&(ft.update(Z.inputSource,Z.frame,l||o),ft.dispatchEvent({type:Z.type,data:Z.inputSource}))}function K(){i.removeEventListener("select",H),i.removeEventListener("selectstart",H),i.removeEventListener("selectend",H),i.removeEventListener("squeeze",H),i.removeEventListener("squeezestart",H),i.removeEventListener("squeezeend",H),i.removeEventListener("end",K),i.removeEventListener("inputsourceschange",G);for(let Z=0;Z<_.length;Z++){const Q=M[Z];Q!==null&&(M[Z]=null,_[Z].disconnect(Q))}z=null,X=null,m.reset();for(const Z in f)delete f[Z];t.setRenderTarget(v),p=null,d=null,u=null,i=null,b=null,le.stop(),n.isPresenting=!1,t.setPixelRatio(P),t.setSize(T.width,T.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){r=Z,n.isPresenting===!0&&kt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){a=Z,n.isPresenting===!0&&kt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(Z){l=Z},this.getBaseLayer=function(){return d!==null?d:p},this.getBinding=function(){return u===null&&g&&(u=new XRWebGLBinding(i,e)),u},this.getFrame=function(){return x},this.getSession=function(){return i},this.setSession=async function(Z){if(i=Z,i!==null){if(v=t.getRenderTarget(),i.addEventListener("select",H),i.addEventListener("selectstart",H),i.addEventListener("selectend",H),i.addEventListener("squeeze",H),i.addEventListener("squeezestart",H),i.addEventListener("squeezeend",H),i.addEventListener("end",K),i.addEventListener("inputsourceschange",G),y.xrCompatible!==!0&&await e.makeXRCompatible(),P=t.getPixelRatio(),t.getSize(T),g&&"createProjectionLayer"in XRWebGLBinding.prototype){let ft=null,Ft=null,At=null;y.depth&&(At=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,ft=y.stencil?Vr:zr,Ft=y.stencil?Br:ds);const Wt={colorFormat:e.RGBA8,depthFormat:At,scaleFactor:r};u=this.getBinding(),d=u.createProjectionLayer(Wt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),b=new fs(d.textureWidth,d.textureHeight,{format:Vn,type:pi,depthTexture:new ef(d.textureWidth,d.textureHeight,Ft,void 0,void 0,void 0,void 0,void 0,void 0,ft),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const ft={antialias:y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(i,e,ft),i.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),b=new fs(p.framebufferWidth,p.framebufferHeight,{format:Vn,type:pi,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}b.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await i.requestReferenceSpace(a),le.setContext(i),le.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function G(Z){for(let Q=0;Q<Z.removed.length;Q++){const ft=Z.removed[Q],Ft=M.indexOf(ft);Ft>=0&&(M[Ft]=null,_[Ft].disconnect(ft))}for(let Q=0;Q<Z.added.length;Q++){const ft=Z.added[Q];let Ft=M.indexOf(ft);if(Ft===-1){for(let Wt=0;Wt<_.length;Wt++)if(Wt>=M.length){M.push(ft),Ft=Wt;break}else if(M[Wt]===null){M[Wt]=ft,Ft=Wt;break}if(Ft===-1)break}const At=_[Ft];At&&At.connect(ft)}}const V=new F,$=new F;function st(Z,Q,ft){V.setFromMatrixPosition(Q.matrixWorld),$.setFromMatrixPosition(ft.matrixWorld);const Ft=V.distanceTo($),At=Q.projectionMatrix.elements,Wt=ft.projectionMatrix.elements,Me=At[14]/(At[10]-1),qt=At[14]/(At[10]+1),ie=(At[9]+1)/At[5],L=(At[9]-1)/At[5],Jt=(At[8]-1)/At[0],Qt=(Wt[8]+1)/Wt[0],xe=Me*Jt,Mt=Me*Qt,ye=Ft/(-Jt+Qt),Ct=ye*-Jt;if(Q.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(Ct),Z.translateZ(ye),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),At[10]===-1)Z.projectionMatrix.copy(Q.projectionMatrix),Z.projectionMatrixInverse.copy(Q.projectionMatrixInverse);else{const Gt=Me+ye,C=qt+ye,S=xe-Ct,k=Mt+(Ft-Ct),j=ie*qt/C*Gt,tt=L*qt/C*Gt;Z.projectionMatrix.makePerspective(S,k,j,tt,Gt,C),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function St(Z,Q){Q===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(Q.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(i===null)return;let Q=Z.near,ft=Z.far;m.texture!==null&&(m.depthNear>0&&(Q=m.depthNear),m.depthFar>0&&(ft=m.depthFar)),I.near=E.near=A.near=Q,I.far=E.far=A.far=ft,(z!==I.near||X!==I.far)&&(i.updateRenderState({depthNear:I.near,depthFar:I.far}),z=I.near,X=I.far),I.layers.mask=Z.layers.mask|6,A.layers.mask=I.layers.mask&3,E.layers.mask=I.layers.mask&5;const Ft=Z.parent,At=I.cameras;St(I,Ft);for(let Wt=0;Wt<At.length;Wt++)St(At[Wt],Ft);At.length===2?st(I,A,E):I.projectionMatrix.copy(A.projectionMatrix),Ht(Z,I,Ft)};function Ht(Z,Q,ft){ft===null?Z.matrix.copy(Q.matrixWorld):(Z.matrix.copy(ft.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(Q.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(Q.projectionMatrix),Z.projectionMatrixInverse.copy(Q.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=Gr*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return I},this.getFoveation=function(){if(!(d===null&&p===null))return c},this.setFoveation=function(Z){c=Z,d!==null&&(d.fixedFoveation=Z),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=Z)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(I)},this.getCameraTexture=function(Z){return f[Z]};let ne=null;function ce(Z,Q){if(h=Q.getViewerPose(l||o),x=Q,h!==null){const ft=h.views;p!==null&&(t.setRenderTargetFramebuffer(b,p.framebuffer),t.setRenderTarget(b));let Ft=!1;ft.length!==I.cameras.length&&(I.cameras.length=0,Ft=!0);for(let qt=0;qt<ft.length;qt++){const ie=ft[qt];let L=null;if(p!==null)L=p.getViewport(ie);else{const Qt=u.getViewSubImage(d,ie);L=Qt.viewport,qt===0&&(t.setRenderTargetTextures(b,Qt.colorTexture,Qt.depthStencilTexture),t.setRenderTarget(b))}let Jt=R[qt];Jt===void 0&&(Jt=new wn,Jt.layers.enable(qt),Jt.viewport=new De,R[qt]=Jt),Jt.matrix.fromArray(ie.transform.matrix),Jt.matrix.decompose(Jt.position,Jt.quaternion,Jt.scale),Jt.projectionMatrix.fromArray(ie.projectionMatrix),Jt.projectionMatrixInverse.copy(Jt.projectionMatrix).invert(),Jt.viewport.set(L.x,L.y,L.width,L.height),qt===0&&(I.matrix.copy(Jt.matrix),I.matrix.decompose(I.position,I.quaternion,I.scale)),Ft===!0&&I.cameras.push(Jt)}const At=i.enabledFeatures;if(At&&At.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&g){u=n.getBinding();const qt=u.getDepthInformation(ft[0]);qt&&qt.isValid&&qt.texture&&m.init(qt,i.renderState)}if(At&&At.includes("camera-access")&&g){t.state.unbindTexture(),u=n.getBinding();for(let qt=0;qt<ft.length;qt++){const ie=ft[qt].camera;if(ie){let L=f[ie];L||(L=new nf,f[ie]=L);const Jt=u.getCameraImage(ie);L.sourceTexture=Jt}}}}for(let ft=0;ft<_.length;ft++){const Ft=M[ft],At=_[ft];Ft!==null&&At!==void 0&&At.update(Ft,Q,l||o)}ne&&ne(Z,Q),Q.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Q}),x=null}const le=new sf;le.setAnimationLoop(ce),this.setAnimationLoop=function(Z){ne=Z},this.dispose=function(){}}}const ji=new mi,pv=new _e;function mv(s,t){function e(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,Zd(s)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function i(m,f,y,v,b){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(m,f):f.isMeshToonMaterial?(r(m,f),u(m,f)):f.isMeshPhongMaterial?(r(m,f),h(m,f)):f.isMeshStandardMaterial?(r(m,f),d(m,f),f.isMeshPhysicalMaterial&&p(m,f,b)):f.isMeshMatcapMaterial?(r(m,f),x(m,f)):f.isMeshDepthMaterial?r(m,f):f.isMeshDistanceMaterial?(r(m,f),g(m,f)):f.isMeshNormalMaterial?r(m,f):f.isLineBasicMaterial?(o(m,f),f.isLineDashedMaterial&&a(m,f)):f.isPointsMaterial?c(m,f,y,v):f.isSpriteMaterial?l(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,e(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===nn&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,e(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===nn&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,e(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,e(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const y=t.get(f),v=y.envMap,b=y.envMapRotation;v&&(m.envMap.value=v,ji.copy(b),ji.x*=-1,ji.y*=-1,ji.z*=-1,v.isCubeTexture&&v.isRenderTargetTexture===!1&&(ji.y*=-1,ji.z*=-1),m.envMapRotation.value.setFromMatrix4(pv.makeRotationFromEuler(ji)),m.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap&&(m.lightMap.value=f.lightMap,m.lightMapIntensity.value=f.lightMapIntensity,e(f.lightMap,m.lightMapTransform)),f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,m.aoMapTransform))}function o(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform))}function a(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function c(m,f,y,v){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*y,m.scale.value=v*.5,f.map&&(m.map.value=f.map,e(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function l(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function h(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function u(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function d(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,m.roughnessMapTransform)),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,y){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===nn&&m.clearcoatNormalScale.value.negate())),f.dispersion>0&&(m.dispersion.value=f.dispersion),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=y.texture,m.transmissionSamplerSize.value.set(y.width,y.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,m.specularIntensityMapTransform))}function x(m,f){f.matcap&&(m.matcap.value=f.matcap)}function g(m,f){const y=t.get(f).light;m.referencePosition.value.setFromMatrixPosition(y.matrixWorld),m.nearDistance.value=y.shadow.camera.near,m.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function xv(s,t,e,n){let i={},r={},o=[];const a=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function c(y,v){const b=v.program;n.uniformBlockBinding(y,b)}function l(y,v){let b=i[y.id];b===void 0&&(x(y),b=h(y),i[y.id]=b,y.addEventListener("dispose",m));const _=v.program;n.updateUBOMapping(y,_);const M=t.render.frame;r[y.id]!==M&&(d(y),r[y.id]=M)}function h(y){const v=u();y.__bindingPointIndex=v;const b=s.createBuffer(),_=y.__size,M=y.usage;return s.bindBuffer(s.UNIFORM_BUFFER,b),s.bufferData(s.UNIFORM_BUFFER,_,M),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,v,b),b}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return Pe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){const v=i[y.id],b=y.uniforms,_=y.__cache;s.bindBuffer(s.UNIFORM_BUFFER,v);for(let M=0,T=b.length;M<T;M++){const P=Array.isArray(b[M])?b[M]:[b[M]];for(let A=0,E=P.length;A<E;A++){const R=P[A];if(p(R,M,A,_)===!0){const I=R.__offset,z=Array.isArray(R.value)?R.value:[R.value];let X=0;for(let H=0;H<z.length;H++){const K=z[H],G=g(K);typeof K=="number"||typeof K=="boolean"?(R.__data[0]=K,s.bufferSubData(s.UNIFORM_BUFFER,I+X,R.__data)):K.isMatrix3?(R.__data[0]=K.elements[0],R.__data[1]=K.elements[1],R.__data[2]=K.elements[2],R.__data[3]=0,R.__data[4]=K.elements[3],R.__data[5]=K.elements[4],R.__data[6]=K.elements[5],R.__data[7]=0,R.__data[8]=K.elements[6],R.__data[9]=K.elements[7],R.__data[10]=K.elements[8],R.__data[11]=0):(K.toArray(R.__data,X),X+=G.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,I,R.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function p(y,v,b,_){const M=y.value,T=v+"_"+b;if(_[T]===void 0)return typeof M=="number"||typeof M=="boolean"?_[T]=M:_[T]=M.clone(),!0;{const P=_[T];if(typeof M=="number"||typeof M=="boolean"){if(P!==M)return _[T]=M,!0}else if(P.equals(M)===!1)return P.copy(M),!0}return!1}function x(y){const v=y.uniforms;let b=0;const _=16;for(let T=0,P=v.length;T<P;T++){const A=Array.isArray(v[T])?v[T]:[v[T]];for(let E=0,R=A.length;E<R;E++){const I=A[E],z=Array.isArray(I.value)?I.value:[I.value];for(let X=0,H=z.length;X<H;X++){const K=z[X],G=g(K),V=b%_,$=V%G.boundary,st=V+$;b+=$,st!==0&&_-st<G.storage&&(b+=_-st),I.__data=new Float32Array(G.storage/Float32Array.BYTES_PER_ELEMENT),I.__offset=b,b+=G.storage}}}const M=b%_;return M>0&&(b+=_-M),y.__size=b,y.__cache={},this}function g(y){const v={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(v.boundary=4,v.storage=4):y.isVector2?(v.boundary=8,v.storage=8):y.isVector3||y.isColor?(v.boundary=16,v.storage=12):y.isVector4?(v.boundary=16,v.storage=16):y.isMatrix3?(v.boundary=48,v.storage=48):y.isMatrix4?(v.boundary=64,v.storage=64):y.isTexture?kt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):kt("WebGLRenderer: Unsupported uniform value type.",y),v}function m(y){const v=y.target;v.removeEventListener("dispose",m);const b=o.indexOf(v.__bindingPointIndex);o.splice(b,1),s.deleteBuffer(i[v.id]),delete i[v.id],delete r[v.id]}function f(){for(const y in i)s.deleteBuffer(i[y]);o=[],i={},r={}}return{bind:c,update:l,dispose:f}}const gv=new Uint16Array([11481,15204,11534,15171,11808,15015,12385,14843,12894,14716,13396,14600,13693,14483,13976,14366,14237,14171,14405,13961,14511,13770,14605,13598,14687,13444,14760,13305,14822,13066,14876,12857,14923,12675,14963,12517,14997,12379,15025,12230,15049,12023,15070,11843,15086,11687,15100,11551,15111,11433,15120,11330,15127,11217,15132,11060,15135,10922,15138,10801,15139,10695,15139,10600,13012,14923,13020,14917,13064,14886,13176,14800,13349,14666,13513,14526,13724,14398,13960,14230,14200,14020,14383,13827,14488,13651,14583,13491,14667,13348,14740,13132,14803,12908,14856,12713,14901,12542,14938,12394,14968,12241,14992,12017,15010,11822,15024,11654,15034,11507,15041,11380,15044,11269,15044,11081,15042,10913,15037,10764,15031,10635,15023,10520,15014,10419,15003,10330,13657,14676,13658,14673,13670,14660,13698,14622,13750,14547,13834,14442,13956,14317,14112,14093,14291,13889,14407,13704,14499,13538,14586,13389,14664,13201,14733,12966,14792,12758,14842,12577,14882,12418,14915,12272,14940,12033,14959,11826,14972,11646,14980,11490,14983,11355,14983,11212,14979,11008,14971,10830,14961,10675,14950,10540,14936,10420,14923,10315,14909,10204,14894,10041,14089,14460,14090,14459,14096,14452,14112,14431,14141,14388,14186,14305,14252,14130,14341,13941,14399,13756,14467,13585,14539,13430,14610,13272,14677,13026,14737,12808,14790,12617,14833,12449,14869,12303,14896,12065,14916,11845,14929,11655,14937,11490,14939,11347,14936,11184,14930,10970,14921,10783,14912,10621,14900,10480,14885,10356,14867,10247,14848,10062,14827,9894,14805,9745,14400,14208,14400,14206,14402,14198,14406,14174,14415,14122,14427,14035,14444,13913,14469,13767,14504,13613,14548,13463,14598,13324,14651,13082,14704,12858,14752,12658,14795,12483,14831,12330,14860,12106,14881,11875,14895,11675,14903,11501,14905,11351,14903,11178,14900,10953,14892,10757,14880,10589,14865,10442,14847,10313,14827,10162,14805,9965,14782,9792,14757,9642,14731,9507,14562,13883,14562,13883,14563,13877,14566,13862,14570,13830,14576,13773,14584,13689,14595,13582,14613,13461,14637,13336,14668,13120,14704,12897,14741,12695,14776,12516,14808,12358,14835,12150,14856,11910,14870,11701,14878,11519,14882,11361,14884,11187,14880,10951,14871,10748,14858,10572,14842,10418,14823,10286,14801,10099,14777,9897,14751,9722,14725,9567,14696,9430,14666,9309,14702,13604,14702,13604,14702,13600,14703,13591,14705,13570,14707,13533,14709,13477,14712,13400,14718,13305,14727,13106,14743,12907,14762,12716,14784,12539,14807,12380,14827,12190,14844,11943,14855,11727,14863,11539,14870,11376,14871,11204,14868,10960,14858,10748,14845,10565,14829,10406,14809,10269,14786,10058,14761,9852,14734,9671,14705,9512,14674,9374,14641,9253,14608,9076,14821,13366,14821,13365,14821,13364,14821,13358,14821,13344,14821,13320,14819,13252,14817,13145,14815,13011,14814,12858,14817,12698,14823,12539,14832,12389,14841,12214,14850,11968,14856,11750,14861,11558,14866,11390,14867,11226,14862,10972,14853,10754,14840,10565,14823,10401,14803,10259,14780,10032,14754,9820,14725,9635,14694,9473,14661,9333,14627,9203,14593,8988,14557,8798,14923,13014,14922,13014,14922,13012,14922,13004,14920,12987,14919,12957,14915,12907,14909,12834,14902,12738,14894,12623,14888,12498,14883,12370,14880,12203,14878,11970,14875,11759,14873,11569,14874,11401,14872,11243,14865,10986,14855,10762,14842,10568,14825,10401,14804,10255,14781,10017,14754,9799,14725,9611,14692,9445,14658,9301,14623,9139,14587,8920,14548,8729,14509,8562,15008,12672,15008,12672,15008,12671,15007,12667,15005,12656,15001,12637,14997,12605,14989,12556,14978,12490,14966,12407,14953,12313,14940,12136,14927,11934,14914,11742,14903,11563,14896,11401,14889,11247,14879,10992,14866,10767,14851,10570,14833,10400,14812,10252,14789,10007,14761,9784,14731,9592,14698,9424,14663,9279,14627,9088,14588,8868,14548,8676,14508,8508,14467,8360,15080,12386,15080,12386,15079,12385,15078,12383,15076,12378,15072,12367,15066,12347,15057,12315,15045,12253,15030,12138,15012,11998,14993,11845,14972,11685,14951,11530,14935,11383,14920,11228,14904,10981,14887,10762,14870,10567,14850,10397,14827,10248,14803,9997,14774,9771,14743,9578,14710,9407,14674,9259,14637,9048,14596,8826,14555,8632,14514,8464,14471,8317,14427,8182,15139,12008,15139,12008,15138,12008,15137,12007,15135,12003,15130,11990,15124,11969,15115,11929,15102,11872,15086,11794,15064,11693,15041,11581,15013,11459,14987,11336,14966,11170,14944,10944,14921,10738,14898,10552,14875,10387,14850,10239,14824,9983,14794,9758,14762,9563,14728,9392,14692,9244,14653,9014,14611,8791,14569,8597,14526,8427,14481,8281,14436,8110,14391,7885,15188,11617,15188,11617,15187,11617,15186,11618,15183,11617,15179,11612,15173,11601,15163,11581,15150,11546,15133,11495,15110,11427,15083,11346,15051,11246,15024,11057,14996,10868,14967,10687,14938,10517,14911,10362,14882,10206,14853,9956,14821,9737,14787,9543,14752,9375,14715,9228,14675,8980,14632,8760,14589,8565,14544,8395,14498,8248,14451,8049,14404,7824,14357,7630,15228,11298,15228,11298,15227,11299,15226,11301,15223,11303,15219,11302,15213,11299,15204,11290,15191,11271,15174,11217,15150,11129,15119,11015,15087,10886,15057,10744,15024,10599,14990,10455,14957,10318,14924,10143,14891,9911,14856,9701,14820,9516,14782,9352,14744,9200,14703,8946,14659,8725,14615,8533,14568,8366,14521,8220,14472,7992,14423,7770,14374,7578,14315,7408,15260,10819,15260,10819,15259,10822,15258,10826,15256,10832,15251,10836,15246,10841,15237,10838,15225,10821,15207,10788,15183,10734,15151,10660,15120,10571,15087,10469,15049,10359,15012,10249,14974,10041,14937,9837,14900,9647,14860,9475,14820,9320,14779,9147,14736,8902,14691,8688,14646,8499,14598,8335,14549,8189,14499,7940,14448,7720,14397,7529,14347,7363,14256,7218,15285,10410,15285,10411,15285,10413,15284,10418,15282,10425,15278,10434,15272,10442,15264,10449,15252,10445,15235,10433,15210,10403,15179,10358,15149,10301,15113,10218,15073,10059,15033,9894,14991,9726,14951,9565,14909,9413,14865,9273,14822,9073,14777,8845,14730,8641,14682,8459,14633,8300,14583,8129,14531,7883,14479,7670,14426,7482,14373,7321,14305,7176,14201,6939,15305,9939,15305,9940,15305,9945,15304,9955,15302,9967,15298,9989,15293,10010,15286,10033,15274,10044,15258,10045,15233,10022,15205,9975,15174,9903,15136,9808,15095,9697,15053,9578,15009,9451,14965,9327,14918,9198,14871,8973,14825,8766,14775,8579,14725,8408,14675,8259,14622,8058,14569,7821,14515,7615,14460,7435,14405,7276,14350,7108,14256,6866,14149,6653,15321,9444,15321,9445,15321,9448,15320,9458,15317,9470,15314,9490,15310,9515,15302,9540,15292,9562,15276,9579,15251,9577,15226,9559,15195,9519,15156,9463,15116,9389,15071,9304,15025,9208,14978,9023,14927,8838,14878,8661,14827,8496,14774,8344,14722,8206,14667,7973,14612,7749,14556,7555,14499,7382,14443,7229,14385,7025,14322,6791,14210,6588,14100,6409,15333,8920,15333,8921,15332,8927,15332,8943,15329,8965,15326,9002,15322,9048,15316,9106,15307,9162,15291,9204,15267,9221,15244,9221,15212,9196,15175,9134,15133,9043,15088,8930,15040,8801,14990,8665,14938,8526,14886,8391,14830,8261,14775,8087,14719,7866,14661,7664,14603,7482,14544,7322,14485,7178,14426,6936,14367,6713,14281,6517,14166,6348,14054,6198,15341,8360,15341,8361,15341,8366,15341,8379,15339,8399,15336,8431,15332,8473,15326,8527,15318,8585,15302,8632,15281,8670,15258,8690,15227,8690,15191,8664,15149,8612,15104,8543,15055,8456,15001,8360,14948,8259,14892,8122,14834,7923,14776,7734,14716,7558,14656,7397,14595,7250,14534,7070,14472,6835,14410,6628,14350,6443,14243,6283,14125,6135,14010,5889,15348,7715,15348,7717,15348,7725,15347,7745,15345,7780,15343,7836,15339,7905,15334,8e3,15326,8103,15310,8193,15293,8239,15270,8270,15240,8287,15204,8283,15163,8260,15118,8223,15067,8143,15014,8014,14958,7873,14899,7723,14839,7573,14778,7430,14715,7293,14652,7164,14588,6931,14524,6720,14460,6531,14396,6362,14330,6210,14207,6015,14086,5781,13969,5576,15352,7114,15352,7116,15352,7128,15352,7159,15350,7195,15348,7237,15345,7299,15340,7374,15332,7457,15317,7544,15301,7633,15280,7703,15251,7754,15216,7775,15176,7767,15131,7733,15079,7670,15026,7588,14967,7492,14906,7387,14844,7278,14779,7171,14714,6965,14648,6770,14581,6587,14515,6420,14448,6269,14382,6123,14299,5881,14172,5665,14049,5477,13929,5310,15355,6329,15355,6330,15355,6339,15355,6362,15353,6410,15351,6472,15349,6572,15344,6688,15337,6835,15323,6985,15309,7142,15287,7220,15260,7277,15226,7310,15188,7326,15142,7318,15090,7285,15036,7239,14976,7177,14914,7045,14849,6892,14782,6736,14714,6581,14645,6433,14576,6293,14506,6164,14438,5946,14369,5733,14270,5540,14140,5369,14014,5216,13892,5043,15357,5483,15357,5484,15357,5496,15357,5528,15356,5597,15354,5692,15351,5835,15347,6011,15339,6195,15328,6317,15314,6446,15293,6566,15268,6668,15235,6746,15197,6796,15152,6811,15101,6790,15046,6748,14985,6673,14921,6583,14854,6479,14785,6371,14714,6259,14643,6149,14571,5946,14499,5750,14428,5567,14358,5401,14242,5250,14109,5111,13980,4870,13856,4657,15359,4555,15359,4557,15358,4573,15358,4633,15357,4715,15355,4841,15353,5061,15349,5216,15342,5391,15331,5577,15318,5770,15299,5967,15274,6150,15243,6223,15206,6280,15161,6310,15111,6317,15055,6300,14994,6262,14928,6208,14860,6141,14788,5994,14715,5838,14641,5684,14566,5529,14492,5384,14418,5247,14346,5121,14216,4892,14079,4682,13948,4496,13822,4330,15359,3498,15359,3501,15359,3520,15359,3598,15358,3719,15356,3860,15355,4137,15351,4305,15344,4563,15334,4809,15321,5116,15303,5273,15280,5418,15250,5547,15214,5653,15170,5722,15120,5761,15064,5763,15002,5733,14935,5673,14865,5597,14792,5504,14716,5400,14640,5294,14563,5185,14486,5041,14410,4841,14335,4655,14191,4482,14051,4325,13918,4183,13790,4012,15360,2282,15360,2285,15360,2306,15360,2401,15359,2547,15357,2748,15355,3103,15352,3349,15345,3675,15336,4020,15324,4272,15307,4496,15285,4716,15255,4908,15220,5086,15178,5170,15128,5214,15072,5234,15010,5231,14943,5206,14871,5166,14796,5102,14718,4971,14639,4833,14559,4687,14480,4541,14402,4401,14315,4268,14167,4142,14025,3958,13888,3747,13759,3556,15360,923,15360,925,15360,946,15360,1052,15359,1214,15357,1494,15356,1892,15352,2274,15346,2663,15338,3099,15326,3393,15309,3679,15288,3980,15260,4183,15226,4325,15185,4437,15136,4517,15080,4570,15018,4591,14950,4581,14877,4545,14800,4485,14720,4411,14638,4325,14556,4231,14475,4136,14395,3988,14297,3803,14145,3628,13999,3465,13861,3314,13729,3177,15360,263,15360,264,15360,272,15360,325,15359,407,15358,548,15356,780,15352,1144,15347,1580,15339,2099,15328,2425,15312,2795,15292,3133,15264,3329,15232,3517,15191,3689,15143,3819,15088,3923,15025,3978,14956,3999,14882,3979,14804,3931,14722,3855,14639,3756,14554,3645,14470,3529,14388,3409,14279,3289,14124,3173,13975,3055,13834,2848,13701,2658,15360,49,15360,49,15360,52,15360,75,15359,111,15358,201,15356,283,15353,519,15348,726,15340,1045,15329,1415,15314,1795,15295,2173,15269,2410,15237,2649,15197,2866,15150,3054,15095,3140,15032,3196,14963,3228,14888,3236,14808,3224,14725,3191,14639,3146,14553,3088,14466,2976,14382,2836,14262,2692,14103,2549,13952,2409,13808,2278,13674,2154,15360,4,15360,4,15360,4,15360,13,15359,33,15358,59,15357,112,15353,199,15348,302,15341,456,15331,628,15316,827,15297,1082,15272,1332,15241,1601,15202,1851,15156,2069,15101,2172,15039,2256,14970,2314,14894,2348,14813,2358,14728,2344,14640,2311,14551,2263,14463,2203,14376,2133,14247,2059,14084,1915,13930,1761,13784,1609,13648,1464,15360,0,15360,0,15360,0,15360,3,15359,18,15358,26,15357,53,15354,80,15348,97,15341,165,15332,238,15318,326,15299,427,15275,529,15245,654,15207,771,15161,885,15108,994,15046,1089,14976,1170,14900,1229,14817,1266,14731,1284,14641,1282,14550,1260,14460,1223,14370,1174,14232,1116,14066,1050,13909,981,13761,910,13623,839]);let ni=null;function _v(){return ni===null&&(ni=new Qd(gv,32,32,Bl,Js),ni.minFilter=cn,ni.magFilter=cn,ni.wrapS=li,ni.wrapT=li,ni.generateMipmaps=!1,ni.needsUpdate=!0),ni}class vv{constructor(t={}){const{canvas:e=Ip(),context:n=null,depth:i=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=o;const x=new Set([Vl,zl,Ol]),g=new Set([pi,ds,Or,Br,Ul,Fl]),m=new Uint32Array(4),f=new Int32Array(4);let y=null,v=null;const b=[],_=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Bi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const M=this;let T=!1;this._outputColorSpace=En;let P=0,A=0,E=null,R=-1,I=null;const z=new De,X=new De;let H=null;const K=new ee(0);let G=0,V=e.width,$=e.height,st=1,St=null,Ht=null;const ne=new De(0,0,V,$),ce=new De(0,0,V,$);let le=!1;const Z=new tf;let Q=!1,ft=!1;const Ft=new _e,At=new F,Wt=new De,Me={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let qt=!1;function ie(){return E===null?st:1}let L=n;function Jt(w,O){return e.getContext(w,O)}try{const w={alpha:!0,depth:i,stencil:r,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Dl}`),e.addEventListener("webglcontextlost",it,!1),e.addEventListener("webglcontextrestored",J,!1),e.addEventListener("webglcontextcreationerror",vt,!1),L===null){const O="webgl2";if(L=Jt(O,w),L===null)throw Jt(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw w("WebGLRenderer: "+w.message),w}let Qt,xe,Mt,ye,Ct,Gt,C,S,k,j,tt,Y,wt,ht,Rt,Et,et,ot,Ut,Lt,pt,Ot,D,ut;function at(){Qt=new Tg(L),Qt.init(),Ot=new lv(L,Qt),xe=new _g(L,Qt,t,Ot),Mt=new av(L,Qt),xe.reversedDepthBuffer&&d&&Mt.buffers.depth.setReversed(!0),ye=new Pg(L),Ct=new $_,Gt=new cv(L,Qt,Mt,Ct,xe,Ot,ye),C=new bg(M),S=new wg(M),k=new U0(L),D=new xg(L,k),j=new Cg(L,k,ye,D),tt=new Dg(L,j,k,ye),Ut=new Lg(L,xe,Gt),Et=new vg(Ct),Y=new Y_(M,C,S,Qt,xe,D,Et),wt=new mv(M,Ct),ht=new Z_,Rt=new nv(Qt),ot=new mg(M,C,S,Mt,tt,p,c),et=new rv(M,tt,xe),ut=new xv(L,ye,xe,Mt),Lt=new gg(L,Qt,ye),pt=new Rg(L,Qt,ye),ye.programs=Y.programs,M.capabilities=xe,M.extensions=Qt,M.properties=Ct,M.renderLists=ht,M.shadowMap=et,M.state=Mt,M.info=ye}at();const ct=new fv(M,L);this.xr=ct,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const w=Qt.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=Qt.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return st},this.setPixelRatio=function(w){w!==void 0&&(st=w,this.setSize(V,$,!1))},this.getSize=function(w){return w.set(V,$)},this.setSize=function(w,O,W=!0){if(ct.isPresenting){kt("WebGLRenderer: Can't change size while VR device is presenting.");return}V=w,$=O,e.width=Math.floor(w*st),e.height=Math.floor(O*st),W===!0&&(e.style.width=w+"px",e.style.height=O+"px"),this.setViewport(0,0,w,O)},this.getDrawingBufferSize=function(w){return w.set(V*st,$*st).floor()},this.setDrawingBufferSize=function(w,O,W){V=w,$=O,st=W,e.width=Math.floor(w*W),e.height=Math.floor(O*W),this.setViewport(0,0,w,O)},this.getCurrentViewport=function(w){return w.copy(z)},this.getViewport=function(w){return w.copy(ne)},this.setViewport=function(w,O,W,q){w.isVector4?ne.set(w.x,w.y,w.z,w.w):ne.set(w,O,W,q),Mt.viewport(z.copy(ne).multiplyScalar(st).round())},this.getScissor=function(w){return w.copy(ce)},this.setScissor=function(w,O,W,q){w.isVector4?ce.set(w.x,w.y,w.z,w.w):ce.set(w,O,W,q),Mt.scissor(X.copy(ce).multiplyScalar(st).round())},this.getScissorTest=function(){return le},this.setScissorTest=function(w){Mt.setScissorTest(le=w)},this.setOpaqueSort=function(w){St=w},this.setTransparentSort=function(w){Ht=w},this.getClearColor=function(w){return w.copy(ot.getClearColor())},this.setClearColor=function(){ot.setClearColor(...arguments)},this.getClearAlpha=function(){return ot.getClearAlpha()},this.setClearAlpha=function(){ot.setClearAlpha(...arguments)},this.clear=function(w=!0,O=!0,W=!0){let q=0;if(w){let B=!1;if(E!==null){const rt=E.texture.format;B=x.has(rt)}if(B){const rt=E.texture.type,dt=g.has(rt),bt=ot.getClearColor(),xt=ot.getClearAlpha(),Dt=bt.r,Nt=bt.g,Tt=bt.b;dt?(m[0]=Dt,m[1]=Nt,m[2]=Tt,m[3]=xt,L.clearBufferuiv(L.COLOR,0,m)):(f[0]=Dt,f[1]=Nt,f[2]=Tt,f[3]=xt,L.clearBufferiv(L.COLOR,0,f))}else q|=L.COLOR_BUFFER_BIT}O&&(q|=L.DEPTH_BUFFER_BIT),W&&(q|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",it,!1),e.removeEventListener("webglcontextrestored",J,!1),e.removeEventListener("webglcontextcreationerror",vt,!1),ot.dispose(),ht.dispose(),Rt.dispose(),Ct.dispose(),C.dispose(),S.dispose(),tt.dispose(),D.dispose(),ut.dispose(),Y.dispose(),ct.dispose(),ct.removeEventListener("sessionstart",gh),ct.removeEventListener("sessionend",_h),Wi.stop()};function it(w){w.preventDefault(),Dh("WebGLRenderer: Context Lost."),T=!0}function J(){Dh("WebGLRenderer: Context Restored."),T=!1;const w=ye.autoReset,O=et.enabled,W=et.autoUpdate,q=et.needsUpdate,B=et.type;at(),ye.autoReset=w,et.enabled=O,et.autoUpdate=W,et.needsUpdate=q,et.type=B}function vt(w){Pe("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function Vt(w){const O=w.target;O.removeEventListener("dispose",Vt),ge(O)}function ge(w){he(w),Ct.remove(w)}function he(w){const O=Ct.get(w).programs;O!==void 0&&(O.forEach(function(W){Y.releaseProgram(W)}),w.isShaderMaterial&&Y.releaseShaderCache(w))}this.renderBufferDirect=function(w,O,W,q,B,rt){O===null&&(O=Me);const dt=B.isMesh&&B.matrixWorld.determinant()<0,bt=Of(w,O,W,q,B);Mt.setMaterial(q,dt);let xt=W.index,Dt=1;if(q.wireframe===!0){if(xt=j.getWireframeAttribute(W),xt===void 0)return;Dt=2}const Nt=W.drawRange,Tt=W.attributes.position;let te=Nt.start*Dt,ue=(Nt.start+Nt.count)*Dt;rt!==null&&(te=Math.max(te,rt.start*Dt),ue=Math.min(ue,(rt.start+rt.count)*Dt)),xt!==null?(te=Math.max(te,0),ue=Math.min(ue,xt.count)):Tt!=null&&(te=Math.max(te,0),ue=Math.min(ue,Tt.count));const we=ue-te;if(we<0||we===1/0)return;D.setup(B,q,bt,W,xt);let Te,pe=Lt;if(xt!==null&&(Te=k.get(xt),pe=pt,pe.setIndex(Te)),B.isMesh)q.wireframe===!0?(Mt.setLineWidth(q.wireframeLinewidth*ie()),pe.setMode(L.LINES)):pe.setMode(L.TRIANGLES);else if(B.isLine){let Pt=q.linewidth;Pt===void 0&&(Pt=1),Mt.setLineWidth(Pt*ie()),B.isLineSegments?pe.setMode(L.LINES):B.isLineLoop?pe.setMode(L.LINE_LOOP):pe.setMode(L.LINE_STRIP)}else B.isPoints?pe.setMode(L.POINTS):B.isSprite&&pe.setMode(L.TRIANGLES);if(B.isBatchedMesh)if(B._multiDrawInstances!==null)kr("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),pe.renderMultiDrawInstances(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount,B._multiDrawInstances);else if(Qt.get("WEBGL_multi_draw"))pe.renderMultiDraw(B._multiDrawStarts,B._multiDrawCounts,B._multiDrawCount);else{const Pt=B._multiDrawStarts,Se=B._multiDrawCounts,se=B._multiDrawCount,dn=xt?k.get(xt).bytesPerElement:1,_s=Ct.get(q).currentProgram.getUniforms();for(let fn=0;fn<se;fn++)_s.setValue(L,"_gl_DrawID",fn),pe.render(Pt[fn]/dn,Se[fn])}else if(B.isInstancedMesh)pe.renderInstances(te,we,B.count);else if(W.isInstancedBufferGeometry){const Pt=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,Se=Math.min(W.instanceCount,Pt);pe.renderInstances(te,we,Se)}else pe.render(te,we)};function Gn(w,O,W){w.transparent===!0&&w.side===Bn&&w.forceSinglePass===!1?(w.side=nn,w.needsUpdate=!0,Jr(w,O,W),w.side=zi,w.needsUpdate=!0,Jr(w,O,W),w.side=Bn):Jr(w,O,W)}this.compile=function(w,O,W=null){W===null&&(W=w),v=Rt.get(W),v.init(O),_.push(v),W.traverseVisible(function(B){B.isLight&&B.layers.test(O.layers)&&(v.pushLight(B),B.castShadow&&v.pushShadow(B))}),w!==W&&w.traverseVisible(function(B){B.isLight&&B.layers.test(O.layers)&&(v.pushLight(B),B.castShadow&&v.pushShadow(B))}),v.setupLights();const q=new Set;return w.traverse(function(B){if(!(B.isMesh||B.isPoints||B.isLine||B.isSprite))return;const rt=B.material;if(rt)if(Array.isArray(rt))for(let dt=0;dt<rt.length;dt++){const bt=rt[dt];Gn(bt,W,B),q.add(bt)}else Gn(rt,W,B),q.add(rt)}),v=_.pop(),q},this.compileAsync=function(w,O,W=null){const q=this.compile(w,O,W);return new Promise(B=>{function rt(){if(q.forEach(function(dt){Ct.get(dt).currentProgram.isReady()&&q.delete(dt)}),q.size===0){B(w);return}setTimeout(rt,10)}Qt.get("KHR_parallel_shader_compile")!==null?rt():setTimeout(rt,10)})};let Pn=null;function Nf(w){Pn&&Pn(w)}function gh(){Wi.stop()}function _h(){Wi.start()}const Wi=new sf;Wi.setAnimationLoop(Nf),typeof self<"u"&&Wi.setContext(self),this.setAnimationLoop=function(w){Pn=w,ct.setAnimationLoop(w),w===null?Wi.stop():Wi.start()},ct.addEventListener("sessionstart",gh),ct.addEventListener("sessionend",_h),this.render=function(w,O){if(O!==void 0&&O.isCamera!==!0){Pe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(T===!0)return;if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),ct.enabled===!0&&ct.isPresenting===!0&&(ct.cameraAutoUpdate===!0&&ct.updateCamera(O),O=ct.getCamera()),w.isScene===!0&&w.onBeforeRender(M,w,O,E),v=Rt.get(w,_.length),v.init(O),_.push(v),Ft.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),Z.setFromProjectionMatrix(Ft,Yn,O.reversedDepth),ft=this.localClippingEnabled,Q=Et.init(this.clippingPlanes,ft),y=ht.get(w,b.length),y.init(),b.push(y),ct.enabled===!0&&ct.isPresenting===!0){const rt=M.xr.getDepthSensingMesh();rt!==null&&wa(rt,O,-1/0,M.sortObjects)}wa(w,O,0,M.sortObjects),y.finish(),M.sortObjects===!0&&y.sort(St,Ht),qt=ct.enabled===!1||ct.isPresenting===!1||ct.hasDepthSensing()===!1,qt&&ot.addToRenderList(y,w),this.info.render.frame++,Q===!0&&Et.beginShadows();const W=v.state.shadowsArray;et.render(W,w,O),Q===!0&&Et.endShadows(),this.info.autoReset===!0&&this.info.reset();const q=y.opaque,B=y.transmissive;if(v.setupLights(),O.isArrayCamera){const rt=O.cameras;if(B.length>0)for(let dt=0,bt=rt.length;dt<bt;dt++){const xt=rt[dt];bh(q,B,w,xt)}qt&&ot.render(w);for(let dt=0,bt=rt.length;dt<bt;dt++){const xt=rt[dt];vh(y,w,xt,xt.viewport)}}else B.length>0&&bh(q,B,w,O),qt&&ot.render(w),vh(y,w,O);E!==null&&A===0&&(Gt.updateMultisampleRenderTarget(E),Gt.updateRenderTargetMipmap(E)),w.isScene===!0&&w.onAfterRender(M,w,O),D.resetDefaultState(),R=-1,I=null,_.pop(),_.length>0?(v=_[_.length-1],Q===!0&&Et.setGlobalState(M.clippingPlanes,v.state.camera)):v=null,b.pop(),b.length>0?y=b[b.length-1]:y=null};function wa(w,O,W,q){if(w.visible===!1)return;if(w.layers.test(O.layers)){if(w.isGroup)W=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(O);else if(w.isLight)v.pushLight(w),w.castShadow&&v.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||Z.intersectsSprite(w)){q&&Wt.setFromMatrixPosition(w.matrixWorld).applyMatrix4(Ft);const dt=tt.update(w),bt=w.material;bt.visible&&y.push(w,dt,bt,W,Wt.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||Z.intersectsObject(w))){const dt=tt.update(w),bt=w.material;if(q&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Wt.copy(w.boundingSphere.center)):(dt.boundingSphere===null&&dt.computeBoundingSphere(),Wt.copy(dt.boundingSphere.center)),Wt.applyMatrix4(w.matrixWorld).applyMatrix4(Ft)),Array.isArray(bt)){const xt=dt.groups;for(let Dt=0,Nt=xt.length;Dt<Nt;Dt++){const Tt=xt[Dt],te=bt[Tt.materialIndex];te&&te.visible&&y.push(w,dt,te,W,Wt.z,Tt)}}else bt.visible&&y.push(w,dt,bt,W,Wt.z,null)}}const rt=w.children;for(let dt=0,bt=rt.length;dt<bt;dt++)wa(rt[dt],O,W,q)}function vh(w,O,W,q){const{opaque:B,transmissive:rt,transparent:dt}=w;v.setupLightsView(W),Q===!0&&Et.setGlobalState(M.clippingPlanes,W),q&&Mt.viewport(z.copy(q)),B.length>0&&jr(B,O,W),rt.length>0&&jr(rt,O,W),dt.length>0&&jr(dt,O,W),Mt.buffers.depth.setTest(!0),Mt.buffers.depth.setMask(!0),Mt.buffers.color.setMask(!0),Mt.setPolygonOffset(!1)}function bh(w,O,W,q){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;v.state.transmissionRenderTarget[q.id]===void 0&&(v.state.transmissionRenderTarget[q.id]=new fs(1,1,{generateMipmaps:!0,type:Qt.has("EXT_color_buffer_half_float")||Qt.has("EXT_color_buffer_float")?Js:pi,minFilter:hs,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:re.workingColorSpace}));const rt=v.state.transmissionRenderTarget[q.id],dt=q.viewport||z;rt.setSize(dt.z*M.transmissionResolutionScale,dt.w*M.transmissionResolutionScale);const bt=M.getRenderTarget(),xt=M.getActiveCubeFace(),Dt=M.getActiveMipmapLevel();M.setRenderTarget(rt),M.getClearColor(K),G=M.getClearAlpha(),G<1&&M.setClearColor(16777215,.5),M.clear(),qt&&ot.render(W);const Nt=M.toneMapping;M.toneMapping=Bi;const Tt=q.viewport;if(q.viewport!==void 0&&(q.viewport=void 0),v.setupLightsView(q),Q===!0&&Et.setGlobalState(M.clippingPlanes,q),jr(w,W,q),Gt.updateMultisampleRenderTarget(rt),Gt.updateRenderTargetMipmap(rt),Qt.has("WEBGL_multisampled_render_to_texture")===!1){let te=!1;for(let ue=0,we=O.length;ue<we;ue++){const Te=O[ue],{object:pe,geometry:Pt,material:Se,group:se}=Te;if(Se.side===Bn&&pe.layers.test(q.layers)){const dn=Se.side;Se.side=nn,Se.needsUpdate=!0,Mh(pe,W,q,Pt,Se,se),Se.side=dn,Se.needsUpdate=!0,te=!0}}te===!0&&(Gt.updateMultisampleRenderTarget(rt),Gt.updateRenderTargetMipmap(rt))}M.setRenderTarget(bt,xt,Dt),M.setClearColor(K,G),Tt!==void 0&&(q.viewport=Tt),M.toneMapping=Nt}function jr(w,O,W){const q=O.isScene===!0?O.overrideMaterial:null;for(let B=0,rt=w.length;B<rt;B++){const dt=w[B],{object:bt,geometry:xt,group:Dt}=dt;let Nt=dt.material;Nt.allowOverride===!0&&q!==null&&(Nt=q),bt.layers.test(W.layers)&&Mh(bt,O,W,xt,Nt,Dt)}}function Mh(w,O,W,q,B,rt){w.onBeforeRender(M,O,W,q,B,rt),w.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),B.onBeforeRender(M,O,W,q,w,rt),B.transparent===!0&&B.side===Bn&&B.forceSinglePass===!1?(B.side=nn,B.needsUpdate=!0,M.renderBufferDirect(W,O,q,B,w,rt),B.side=zi,B.needsUpdate=!0,M.renderBufferDirect(W,O,q,B,w,rt),B.side=Bn):M.renderBufferDirect(W,O,q,B,w,rt),w.onAfterRender(M,O,W,q,B,rt)}function Jr(w,O,W){O.isScene!==!0&&(O=Me);const q=Ct.get(w),B=v.state.lights,rt=v.state.shadowsArray,dt=B.state.version,bt=Y.getParameters(w,B.state,rt,O,W),xt=Y.getProgramCacheKey(bt);let Dt=q.programs;q.environment=w.isMeshStandardMaterial?O.environment:null,q.fog=O.fog,q.envMap=(w.isMeshStandardMaterial?S:C).get(w.envMap||q.environment),q.envMapRotation=q.environment!==null&&w.envMap===null?O.environmentRotation:w.envMapRotation,Dt===void 0&&(w.addEventListener("dispose",Vt),Dt=new Map,q.programs=Dt);let Nt=Dt.get(xt);if(Nt!==void 0){if(q.currentProgram===Nt&&q.lightsStateVersion===dt)return Sh(w,bt),Nt}else bt.uniforms=Y.getUniforms(w),w.onBeforeCompile(bt,M),Nt=Y.acquireProgram(bt,xt),Dt.set(xt,Nt),q.uniforms=bt.uniforms;const Tt=q.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(Tt.clippingPlanes=Et.uniform),Sh(w,bt),q.needsLights=zf(w),q.lightsStateVersion=dt,q.needsLights&&(Tt.ambientLightColor.value=B.state.ambient,Tt.lightProbe.value=B.state.probe,Tt.directionalLights.value=B.state.directional,Tt.directionalLightShadows.value=B.state.directionalShadow,Tt.spotLights.value=B.state.spot,Tt.spotLightShadows.value=B.state.spotShadow,Tt.rectAreaLights.value=B.state.rectArea,Tt.ltc_1.value=B.state.rectAreaLTC1,Tt.ltc_2.value=B.state.rectAreaLTC2,Tt.pointLights.value=B.state.point,Tt.pointLightShadows.value=B.state.pointShadow,Tt.hemisphereLights.value=B.state.hemi,Tt.directionalShadowMap.value=B.state.directionalShadowMap,Tt.directionalShadowMatrix.value=B.state.directionalShadowMatrix,Tt.spotShadowMap.value=B.state.spotShadowMap,Tt.spotLightMatrix.value=B.state.spotLightMatrix,Tt.spotLightMap.value=B.state.spotLightMap,Tt.pointShadowMap.value=B.state.pointShadowMap,Tt.pointShadowMatrix.value=B.state.pointShadowMatrix),q.currentProgram=Nt,q.uniformsList=null,Nt}function yh(w){if(w.uniformsList===null){const O=w.currentProgram.getUniforms();w.uniformsList=Jo.seqWithValue(O.seq,w.uniforms)}return w.uniformsList}function Sh(w,O){const W=Ct.get(w);W.outputColorSpace=O.outputColorSpace,W.batching=O.batching,W.batchingColor=O.batchingColor,W.instancing=O.instancing,W.instancingColor=O.instancingColor,W.instancingMorph=O.instancingMorph,W.skinning=O.skinning,W.morphTargets=O.morphTargets,W.morphNormals=O.morphNormals,W.morphColors=O.morphColors,W.morphTargetsCount=O.morphTargetsCount,W.numClippingPlanes=O.numClippingPlanes,W.numIntersection=O.numClipIntersection,W.vertexAlphas=O.vertexAlphas,W.vertexTangents=O.vertexTangents,W.toneMapping=O.toneMapping}function Of(w,O,W,q,B){O.isScene!==!0&&(O=Me),Gt.resetTextureUnits();const rt=O.fog,dt=q.isMeshStandardMaterial?O.environment:null,bt=E===null?M.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:$s,xt=(q.isMeshStandardMaterial?S:C).get(q.envMap||dt),Dt=q.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,Nt=!!W.attributes.tangent&&(!!q.normalMap||q.anisotropy>0),Tt=!!W.morphAttributes.position,te=!!W.morphAttributes.normal,ue=!!W.morphAttributes.color;let we=Bi;q.toneMapped&&(E===null||E.isXRRenderTarget===!0)&&(we=M.toneMapping);const Te=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,pe=Te!==void 0?Te.length:0,Pt=Ct.get(q),Se=v.state.lights;if(Q===!0&&(ft===!0||w!==I)){const Qe=w===I&&q.id===R;Et.setState(q,w,Qe)}let se=!1;q.version===Pt.__version?(Pt.needsLights&&Pt.lightsStateVersion!==Se.state.version||Pt.outputColorSpace!==bt||B.isBatchedMesh&&Pt.batching===!1||!B.isBatchedMesh&&Pt.batching===!0||B.isBatchedMesh&&Pt.batchingColor===!0&&B.colorTexture===null||B.isBatchedMesh&&Pt.batchingColor===!1&&B.colorTexture!==null||B.isInstancedMesh&&Pt.instancing===!1||!B.isInstancedMesh&&Pt.instancing===!0||B.isSkinnedMesh&&Pt.skinning===!1||!B.isSkinnedMesh&&Pt.skinning===!0||B.isInstancedMesh&&Pt.instancingColor===!0&&B.instanceColor===null||B.isInstancedMesh&&Pt.instancingColor===!1&&B.instanceColor!==null||B.isInstancedMesh&&Pt.instancingMorph===!0&&B.morphTexture===null||B.isInstancedMesh&&Pt.instancingMorph===!1&&B.morphTexture!==null||Pt.envMap!==xt||q.fog===!0&&Pt.fog!==rt||Pt.numClippingPlanes!==void 0&&(Pt.numClippingPlanes!==Et.numPlanes||Pt.numIntersection!==Et.numIntersection)||Pt.vertexAlphas!==Dt||Pt.vertexTangents!==Nt||Pt.morphTargets!==Tt||Pt.morphNormals!==te||Pt.morphColors!==ue||Pt.toneMapping!==we||Pt.morphTargetsCount!==pe)&&(se=!0):(se=!0,Pt.__version=q.version);let dn=Pt.currentProgram;se===!0&&(dn=Jr(q,O,B));let _s=!1,fn=!1,nr=!1;const Ee=dn.getUniforms(),rn=Pt.uniforms;if(Mt.useProgram(dn.program)&&(_s=!0,fn=!0,nr=!0),q.id!==R&&(R=q.id,fn=!0),_s||I!==w){Mt.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),Ee.setValue(L,"projectionMatrix",w.projectionMatrix),Ee.setValue(L,"viewMatrix",w.matrixWorldInverse);const on=Ee.map.cameraPosition;on!==void 0&&on.setValue(L,At.setFromMatrixPosition(w.matrixWorld)),xe.logarithmicDepthBuffer&&Ee.setValue(L,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(q.isMeshPhongMaterial||q.isMeshToonMaterial||q.isMeshLambertMaterial||q.isMeshBasicMaterial||q.isMeshStandardMaterial||q.isShaderMaterial)&&Ee.setValue(L,"isOrthographic",w.isOrthographicCamera===!0),I!==w&&(I=w,fn=!0,nr=!0)}if(B.isSkinnedMesh){Ee.setOptional(L,B,"bindMatrix"),Ee.setOptional(L,B,"bindMatrixInverse");const Qe=B.skeleton;Qe&&(Qe.boneTexture===null&&Qe.computeBoneTexture(),Ee.setValue(L,"boneTexture",Qe.boneTexture,Gt))}B.isBatchedMesh&&(Ee.setOptional(L,B,"batchingTexture"),Ee.setValue(L,"batchingTexture",B._matricesTexture,Gt),Ee.setOptional(L,B,"batchingIdTexture"),Ee.setValue(L,"batchingIdTexture",B._indirectTexture,Gt),Ee.setOptional(L,B,"batchingColorTexture"),B._colorsTexture!==null&&Ee.setValue(L,"batchingColorTexture",B._colorsTexture,Gt));const vn=W.morphAttributes;if((vn.position!==void 0||vn.normal!==void 0||vn.color!==void 0)&&Ut.update(B,W,dn),(fn||Pt.receiveShadow!==B.receiveShadow)&&(Pt.receiveShadow=B.receiveShadow,Ee.setValue(L,"receiveShadow",B.receiveShadow)),q.isMeshGouraudMaterial&&q.envMap!==null&&(rn.envMap.value=xt,rn.flipEnvMap.value=xt.isCubeTexture&&xt.isRenderTargetTexture===!1?-1:1),q.isMeshStandardMaterial&&q.envMap===null&&O.environment!==null&&(rn.envMapIntensity.value=O.environmentIntensity),rn.dfgLUT!==void 0&&(rn.dfgLUT.value=_v()),fn&&(Ee.setValue(L,"toneMappingExposure",M.toneMappingExposure),Pt.needsLights&&Bf(rn,nr),rt&&q.fog===!0&&wt.refreshFogUniforms(rn,rt),wt.refreshMaterialUniforms(rn,q,st,$,v.state.transmissionRenderTarget[w.id]),Jo.upload(L,yh(Pt),rn,Gt)),q.isShaderMaterial&&q.uniformsNeedUpdate===!0&&(Jo.upload(L,yh(Pt),rn,Gt),q.uniformsNeedUpdate=!1),q.isSpriteMaterial&&Ee.setValue(L,"center",B.center),Ee.setValue(L,"modelViewMatrix",B.modelViewMatrix),Ee.setValue(L,"normalMatrix",B.normalMatrix),Ee.setValue(L,"modelMatrix",B.matrixWorld),q.isShaderMaterial||q.isRawShaderMaterial){const Qe=q.uniformsGroups;for(let on=0,Ta=Qe.length;on<Ta;on++){const Xi=Qe[on];ut.update(Xi,dn),ut.bind(Xi,dn)}}return dn}function Bf(w,O){w.ambientLightColor.needsUpdate=O,w.lightProbe.needsUpdate=O,w.directionalLights.needsUpdate=O,w.directionalLightShadows.needsUpdate=O,w.pointLights.needsUpdate=O,w.pointLightShadows.needsUpdate=O,w.spotLights.needsUpdate=O,w.spotLightShadows.needsUpdate=O,w.rectAreaLights.needsUpdate=O,w.hemisphereLights.needsUpdate=O}function zf(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return P},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(w,O,W){const q=Ct.get(w);q.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,q.__autoAllocateDepthBuffer===!1&&(q.__useRenderToTexture=!1),Ct.get(w.texture).__webglTexture=O,Ct.get(w.depthTexture).__webglTexture=q.__autoAllocateDepthBuffer?void 0:W,q.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,O){const W=Ct.get(w);W.__webglFramebuffer=O,W.__useDefaultFramebuffer=O===void 0};const Vf=L.createFramebuffer();this.setRenderTarget=function(w,O=0,W=0){E=w,P=O,A=W;let q=!0,B=null,rt=!1,dt=!1;if(w){const xt=Ct.get(w);if(xt.__useDefaultFramebuffer!==void 0)Mt.bindFramebuffer(L.FRAMEBUFFER,null),q=!1;else if(xt.__webglFramebuffer===void 0)Gt.setupRenderTarget(w);else if(xt.__hasExternalTextures)Gt.rebindTextures(w,Ct.get(w.texture).__webglTexture,Ct.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const Tt=w.depthTexture;if(xt.__boundDepthTexture!==Tt){if(Tt!==null&&Ct.has(Tt)&&(w.width!==Tt.image.width||w.height!==Tt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Gt.setupDepthRenderbuffer(w)}}const Dt=w.texture;(Dt.isData3DTexture||Dt.isDataArrayTexture||Dt.isCompressedArrayTexture)&&(dt=!0);const Nt=Ct.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Nt[O])?B=Nt[O][W]:B=Nt[O],rt=!0):w.samples>0&&Gt.useMultisampledRTT(w)===!1?B=Ct.get(w).__webglMultisampledFramebuffer:Array.isArray(Nt)?B=Nt[W]:B=Nt,z.copy(w.viewport),X.copy(w.scissor),H=w.scissorTest}else z.copy(ne).multiplyScalar(st).floor(),X.copy(ce).multiplyScalar(st).floor(),H=le;if(W!==0&&(B=Vf),Mt.bindFramebuffer(L.FRAMEBUFFER,B)&&q&&Mt.drawBuffers(w,B),Mt.viewport(z),Mt.scissor(X),Mt.setScissorTest(H),rt){const xt=Ct.get(w.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+O,xt.__webglTexture,W)}else if(dt){const xt=O;for(let Dt=0;Dt<w.textures.length;Dt++){const Nt=Ct.get(w.textures[Dt]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+Dt,Nt.__webglTexture,W,xt)}}else if(w!==null&&W!==0){const xt=Ct.get(w.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,xt.__webglTexture,W)}R=-1},this.readRenderTargetPixels=function(w,O,W,q,B,rt,dt,bt=0){if(!(w&&w.isWebGLRenderTarget)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let xt=Ct.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&dt!==void 0&&(xt=xt[dt]),xt){Mt.bindFramebuffer(L.FRAMEBUFFER,xt);try{const Dt=w.textures[bt],Nt=Dt.format,Tt=Dt.type;if(!xe.textureFormatReadable(Nt)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!xe.textureTypeReadable(Tt)){Pe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=w.width-q&&W>=0&&W<=w.height-B&&(w.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+bt),L.readPixels(O,W,q,B,Ot.convert(Nt),Ot.convert(Tt),rt))}finally{const Dt=E!==null?Ct.get(E).__webglFramebuffer:null;Mt.bindFramebuffer(L.FRAMEBUFFER,Dt)}}},this.readRenderTargetPixelsAsync=async function(w,O,W,q,B,rt,dt,bt=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let xt=Ct.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&dt!==void 0&&(xt=xt[dt]),xt)if(O>=0&&O<=w.width-q&&W>=0&&W<=w.height-B){Mt.bindFramebuffer(L.FRAMEBUFFER,xt);const Dt=w.textures[bt],Nt=Dt.format,Tt=Dt.type;if(!xe.textureFormatReadable(Nt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!xe.textureTypeReadable(Tt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const te=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,te),L.bufferData(L.PIXEL_PACK_BUFFER,rt.byteLength,L.STREAM_READ),w.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+bt),L.readPixels(O,W,q,B,Ot.convert(Nt),Ot.convert(Tt),0);const ue=E!==null?Ct.get(E).__webglFramebuffer:null;Mt.bindFramebuffer(L.FRAMEBUFFER,ue);const we=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await Up(L,we,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,te),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,rt),L.deleteBuffer(te),L.deleteSync(we),rt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,O=null,W=0){const q=Math.pow(2,-W),B=Math.floor(w.image.width*q),rt=Math.floor(w.image.height*q),dt=O!==null?O.x:0,bt=O!==null?O.y:0;Gt.setTexture2D(w,0),L.copyTexSubImage2D(L.TEXTURE_2D,W,0,0,dt,bt,B,rt),Mt.unbindTexture()};const kf=L.createFramebuffer(),Gf=L.createFramebuffer();this.copyTextureToTexture=function(w,O,W=null,q=null,B=0,rt=null){rt===null&&(B!==0?(kr("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),rt=B,B=0):rt=0);let dt,bt,xt,Dt,Nt,Tt,te,ue,we;const Te=w.isCompressedTexture?w.mipmaps[rt]:w.image;if(W!==null)dt=W.max.x-W.min.x,bt=W.max.y-W.min.y,xt=W.isBox3?W.max.z-W.min.z:1,Dt=W.min.x,Nt=W.min.y,Tt=W.isBox3?W.min.z:0;else{const vn=Math.pow(2,-B);dt=Math.floor(Te.width*vn),bt=Math.floor(Te.height*vn),w.isDataArrayTexture?xt=Te.depth:w.isData3DTexture?xt=Math.floor(Te.depth*vn):xt=1,Dt=0,Nt=0,Tt=0}q!==null?(te=q.x,ue=q.y,we=q.z):(te=0,ue=0,we=0);const pe=Ot.convert(O.format),Pt=Ot.convert(O.type);let Se;O.isData3DTexture?(Gt.setTexture3D(O,0),Se=L.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(Gt.setTexture2DArray(O,0),Se=L.TEXTURE_2D_ARRAY):(Gt.setTexture2D(O,0),Se=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,O.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,O.unpackAlignment);const se=L.getParameter(L.UNPACK_ROW_LENGTH),dn=L.getParameter(L.UNPACK_IMAGE_HEIGHT),_s=L.getParameter(L.UNPACK_SKIP_PIXELS),fn=L.getParameter(L.UNPACK_SKIP_ROWS),nr=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,Te.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,Te.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Dt),L.pixelStorei(L.UNPACK_SKIP_ROWS,Nt),L.pixelStorei(L.UNPACK_SKIP_IMAGES,Tt);const Ee=w.isDataArrayTexture||w.isData3DTexture,rn=O.isDataArrayTexture||O.isData3DTexture;if(w.isDepthTexture){const vn=Ct.get(w),Qe=Ct.get(O),on=Ct.get(vn.__renderTarget),Ta=Ct.get(Qe.__renderTarget);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,on.__webglFramebuffer),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,Ta.__webglFramebuffer);for(let Xi=0;Xi<xt;Xi++)Ee&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ct.get(w).__webglTexture,B,Tt+Xi),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ct.get(O).__webglTexture,rt,we+Xi)),L.blitFramebuffer(Dt,Nt,dt,bt,te,ue,dt,bt,L.DEPTH_BUFFER_BIT,L.NEAREST);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,null),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(B!==0||w.isRenderTargetTexture||Ct.has(w)){const vn=Ct.get(w),Qe=Ct.get(O);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,kf),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,Gf);for(let on=0;on<xt;on++)Ee?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,vn.__webglTexture,B,Tt+on):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,vn.__webglTexture,B),rn?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Qe.__webglTexture,rt,we+on):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,Qe.__webglTexture,rt),B!==0?L.blitFramebuffer(Dt,Nt,dt,bt,te,ue,dt,bt,L.COLOR_BUFFER_BIT,L.NEAREST):rn?L.copyTexSubImage3D(Se,rt,te,ue,we+on,Dt,Nt,dt,bt):L.copyTexSubImage2D(Se,rt,te,ue,Dt,Nt,dt,bt);Mt.bindFramebuffer(L.READ_FRAMEBUFFER,null),Mt.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else rn?w.isDataTexture||w.isData3DTexture?L.texSubImage3D(Se,rt,te,ue,we,dt,bt,xt,pe,Pt,Te.data):O.isCompressedArrayTexture?L.compressedTexSubImage3D(Se,rt,te,ue,we,dt,bt,xt,pe,Te.data):L.texSubImage3D(Se,rt,te,ue,we,dt,bt,xt,pe,Pt,Te):w.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,rt,te,ue,dt,bt,pe,Pt,Te.data):w.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,rt,te,ue,Te.width,Te.height,pe,Te.data):L.texSubImage2D(L.TEXTURE_2D,rt,te,ue,dt,bt,pe,Pt,Te);L.pixelStorei(L.UNPACK_ROW_LENGTH,se),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,dn),L.pixelStorei(L.UNPACK_SKIP_PIXELS,_s),L.pixelStorei(L.UNPACK_SKIP_ROWS,fn),L.pixelStorei(L.UNPACK_SKIP_IMAGES,nr),rt===0&&O.generateMipmaps&&L.generateMipmap(Se),Mt.unbindTexture()},this.initRenderTarget=function(w){Ct.get(w).__webglFramebuffer===void 0&&Gt.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?Gt.setTextureCube(w,0):w.isData3DTexture?Gt.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?Gt.setTexture2DArray(w,0):Gt.setTexture2D(w,0),Mt.unbindTexture()},this.resetState=function(){P=0,A=0,E=null,Mt.reset(),D.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Yn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=re._getDrawingBufferColorSpace(t),e.unpackColorSpace=re._getUnpackColorSpace()}}const bv=13626615,lf=7829367,Mv=6728294,hf=11132329,ca=11132329,yv=15658736,Sv=16764074,uf=new ee(16711680),Sa=new ee(13421772),Ev=new ee(13434828),Av=new ee(16763904);class Je{constructor(){U(this,"flatConfig")}refreshConfig(){this.flatConfig=df(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],n=e();return n.refreshConfig(),n}}U(Je,"_registry",{});function df(s,t={}){for(const[e,n]of Object.entries(s.children))"action"in n||("value"in n?t[e]=n.value:df(n,t));return t}function hr(s){Tn.refreshConfig(),s.onResize()}const wv={label:"Graphics",children:{pixelScale:{value:1,min:1,max:10,step:1,onChange:hr},emoteProbability:{tooltip:"probability to change facial expression per ms",value:.001,min:0,max:.01,onChange:hr},sceneryEntrance:{children:{seDamping:{value:15,min:0,max:100,onChange:hr},seFreq:{value:6,min:1,max:100,onChange:hr},seMaxTime:{value:.5,min:.1,max:10,onChange:hr}}}}},sh=class sh extends Je{constructor(){super(...arguments);U(this,"tree",wv)}};Je.register("gfx-config",()=>new sh);let Eu=sh;const Tn=Je.create("gfx-config"),ff={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:50,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:40,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const s of Object.values(ff.children))s.onChange=t=>{Re.refreshConfig(),t.onResize()};const rh=class rh extends Je{constructor(){super(...arguments);U(this,"tree",ff)}};Je.register("layout-config",()=>new rh);let Au=rh;const Re=Je.create("layout-config");function wu(){pf.refreshConfig()}const Tv={label:"Physics",children:{stepDelay:{value:3,min:3,max:1e4,step:1,onChange:wu},spawnDelay:{value:3,min:3,max:1e4,step:1,onChange:wu}}},oh=class oh extends Je{constructor(){super(...arguments);U(this,"tree",Tv)}};Je.register("physics-config",()=>new oh);let Tu=oh;const pf=Je.create("physics-config"),Cv={bounds:[0,0,0,200,200,200],boxes:[[90,80,90,20,50,20],[90,-60,90,20,50,20],[40,130,50,120,20,100],[80,150,120,40,50,30],[130,150,50,30,50,30],[40,150,50,30,50,30],[20,60,40,160,20,120],[80,30,80,40,30,40],[70,10,70,60,20,60],[80,-10,80,40,20,40],[60,80,130,30,50,20],[110,80,130,30,50,20],[140,80,50,20,50,20],[40,80,50,20,50,20],[20,40,40,20,20,20],[20,40,140,20,20,20],[160,40,140,20,20,20],[160,40,40,20,20,20]],targetBoxIndex:1},Rv={bounds:[0,0,0,200,130,200],boxes:[[90,0,150,20,60,20],[90,0,30,20,60,20],[90,0,90,20,60,20],[40,60,30,120,20,140],[40,80,90,30,50,20]],targetBoxIndex:0},Pv={bounds:[0,0,0,200,200,200],boxes:[[90,10,90,20,50,20],[40,130,40,120,20,140],[40,150,140,20,50,20],[140,150,140,20,50,20],[90,150,90,20,50,20],[20,130,30,20,70,30],[20,80,30,40,50,30],[20,60,20,160,20,160],[90,80,90,20,50,20],[20,-30,140,40,90,40],[20,80,160,20,120,20],[160,80,160,20,120,20],[40,150,30,20,50,30],[160,80,30,20,120,30],[140,150,30,20,50,30],[140,80,30,20,50,30],[140,80,140,20,50,20],[40,80,140,20,50,20]],targetBoxIndex:0},Lv={bounds:[0,0,0,200,200,200],boxes:[[90,10,90,20,50,20],[20,80,160,20,120,20],[90,180,100,20,20,20],[140,80,20,40,120,40],[0,60,0,200,20,200],[20,-30,140,40,90,40],[160,80,160,20,120,20],[20,80,20,40,120,40],[80,160,90,20,20,20],[90,140,100,20,20,20],[100,120,90,20,20,20],[90,100,100,20,20,20],[80,80,90,20,20,20],[40,80,140,20,120,20],[140,80,140,20,120,20],[100,160,90,20,20,20],[80,120,90,20,20,20],[100,80,90,20,20,20],[90,180,80,20,20,20],[90,140,80,20,20,20],[90,100,80,20,20,20]],targetBoxIndex:0},oi=[Cv,Rv,Pv,Lv],Dv={children:{speedMultiplier:{value:1,min:1,max:10,step:1,onChange:()=>hi.refreshConfig()},levelIndex:{value:0,min:0,max:oi.length-1,step:1,onChange:s=>{hi.refreshConfig(),s.state.levelIndex=hi.flatConfig.levelIndex,s.resetLevel()}}}},ah=class ah extends Je{constructor(){super(...arguments);U(this,"tree",Dv)}};Je.register("top-config",()=>new ah);let Cu=ah;const hi=Je.create("top-config"),Iv={children:{...hi.tree.children,...pf.tree.children,...Tn.tree.children,layout:Re.tree}},ch=class ch extends Je{constructor(){super(...arguments);U(this,"tree",Iv)}};Je.register("tower-toppler-config",()=>new ch);let Ru=ch;const Uv=Je.create("tower-toppler-config"),ps=Math.PI,xl=2*ps,Ge=ps/2,ci=ps/4;function la(s,t,e){return s+(t-s)*e}function Fv(s=0,t=1){let e=0,n=0;for(;e===0;)e=Math.random();for(;n===0;)n=Math.random();return Math.sqrt(-2*Math.log(e))*Math.cos(2*Math.PI*n)*t+s}const Wr=["N","E","S","W"];function Nv(s,t){const e=s.position.x-t.x,n=s.position.z-t.z,i=Math.atan2(e,n);return i>=-ci&&i<ci?"N":i>=ci&&i<3*ci?"E":i>=-3*ci&&i<-ci?"W":"S"}function Ov(s,t,e){switch(e){case"N":return[s.x,s.y,t];case"S":return[s.x,s.y,-t];case"E":return[t,s.y,s.z];case"W":return[-t,s.y,s.z];default:return[s.x,s.y,t]}}function Bv(s,t){if(s===t)return 0;const e=Wr.indexOf(t)-Wr.indexOf(s);return e===-3?1:e===3?-1:e<-1||e>1?Math.random()>.5?1:-1:e}const zv=["isShocked","areEyesOpen","isMouthOpen","isFilled"],yn=class yn{static getFaceImage(t){return this._getGfx(t)}static drawFace(t,e,n){const i=this._getGfx(n),[r,o,a,c]=e,l=a/yn._bufferWidth,h=c/yn._bufferHeight,u=Math.min(l,h);t.save(),t.translate(r,o),t.scale(u,u),t.drawImage(i,0,0),t.restore()}static _getGfx(t){const e=yn._hash(t),n=yn._graphics;return Object.hasOwn(n,e)||(n[e]=new yn()._buildFaceGfx(t)),n[e]}static _hash(t){let e="base";for(const n of zv)t[n]&&(e=`${e}-${n}`);return t.rotations&&(e=`${e}-rot=${t.rotations}`),e}_buildFaceGfx(t){const i=yn._bufferWidth,r=yn._bufferHeight,o=document.createElement("canvas");o.width=i,o.height=r;const a=o.getContext("2d"),{rotations:c=0}=t;if(c){const[h,u]=[i/2,r/2],d=Ge*c;a.translate(h,u),a.rotate(d),a.translate(-h,-u)}if(a.lineCap="round",a.lineWidth=80,t.isFilled){a.fillStyle="#ddd";const h="#666";a.fillRect(0,0,i,r),a.strokeStyle=h,a.strokeRect(0,0,i,r),a.fillStyle=h,a.strokeStyle=h}else a.fillStyle="black",a.strokeStyle="black";const{isShocked:l}=t;return l?this._isShockedFace(a,{x:0,y:0,w:i,h:r,...t}):this._idleFace(a,{x:0,y:0,w:i,h:r,...t}),o}_isShockedFace(t,e){const{x:n,y:i,w:r,h:o}=e;t.beginPath(),t.arc(n+r/2,i+o/2,r/4,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+r/4,i+o/5,r/10,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+3*r/4,i+o/5,r/10,0,2*Math.PI),t.fill()}_idleFace(t,e){const{x:n,y:i,w:r,h:o,isMouthOpen:a,areEyesOpen:c}=e;a?(t.beginPath(),t.arc(n+r/2,i+o/3,r/3,.1*Math.PI,.9*Math.PI),t.fill()):(t.beginPath(),t.arc(n+r/2,i,r/2,.3*Math.PI,.7*Math.PI),t.stroke()),c?(t.beginPath(),t.arc(n+r/4,i+o/5,r/10,0,2*Math.PI),t.fill(),t.beginPath(),t.arc(n+3*r/4,i+o/5,r/10,0,2*Math.PI),t.fill()):(t.beginPath(),t.arc(n+r/4,i+o/3,r/6,1.25*Math.PI,1.75*Math.PI),t.stroke(),t.beginPath(),t.arc(n+3*r/4,i+o/3,r/6,1.25*Math.PI,1.75*Math.PI),t.stroke())}};U(yn,"_bufferWidth",1e3),U(yn,"_bufferHeight",1e3),U(yn,"_graphics",{});let gl=yn;const js=[{areEyesOpen:!0,isFilled:!1,isMouthOpen:!0,isShocked:!1,rotations:0},{areEyesOpen:!0,isFilled:!1,isMouthOpen:!1,isShocked:!1,rotations:0},{areEyesOpen:!1,isFilled:!1,isMouthOpen:!0,isShocked:!1,rotations:0},{areEyesOpen:!1,isFilled:!1,isMouthOpen:!1,isShocked:!1,rotations:0}],kn=1+2*js.length,mf=1e3,Vv=1e3,Ea=document.createElement("canvas");Ea.width=kn*mf;Ea.height=Vv;const kv=Ea.getContext("2d");for(let s=0;s<js.length;s++)kv.drawImage(gl.getFaceImage(js[s]),0,0,1e3,1e3,(1+2*s)*mf,0,1e3,1e3);const xi=new w0(Ea);xi.minFilter=cn;xi.magFilter=cn;xi.wrapS=xi.wrapT=ia;xi.offset.set(0,0);xi.repeat.set(1,1);const xf=new sn({color:Sa}),gf=new sn({color:0}),Yl=new sn({map:xi,transparent:!0}),Gv=[xf,gf,Yl];let ha=!0;function Hv(){ha=!0}function Pu(){ha=!1}const Lu=.005,Du=.02,Wv=.005,Xv=1e-5,qv=1e-4,Yv={value:.0025},ss={value:0},_l={value:1e4};function $v(s){_l.value+=s*Wv*(.2+.2*Math.sin(_l.value*1e-4)),ha&&ss.value<Du?ss.value=Math.min(Du,ss.value+s*Xv):!ha&&ss.value>Lu&&(ss.value=Math.max(Lu,ss.value-s*qv))}const Kv=Gl.generateUUID();for(const s of Gv)s.customProgramCacheKey=()=>Kv,s.onBeforeCompile=t=>{t.uniforms.uTime=_l,t.uniforms.uGlobalFreq=Yv,t.uniforms.uGlobalAmp=ss,t.vertexShader=`
  uniform float uTime;
  uniform float uGlobalFreq;
  uniform float uGlobalAmp;
  ${t.vertexShader}
  `.replace("#include <begin_vertex>",`
        // Cartoonish jello hose wave: spine anchored at bottom, top moves most.
        vec3 transformed = vec3(position);

        #ifdef USE_INSTANCING
          mat4 worldMat = modelMatrix * instanceMatrix;
        #else
          mat4 worldMat = modelMatrix;
        #endif

        vec3 worldPos = (worldMat * vec4(transformed, 1.0)).xyz;

        // Per-axis scale so deformation magnitude is scale-invariant.
        vec3 scaleVec = vec3(
          length(worldMat[0].xyz),
          length(worldMat[1].xyz),
          length(worldMat[2].xyz)
        );

        float t = uTime;            // Time driver
        float freq = uGlobalFreq;    // Spatial frequency along height
        float baseAmp = uGlobalAmp;  // Overall amplitude control

        // Height factor: bottom (y≈0) almost rigid; top flexes fully.
        float hFactor = clamp(worldPos.y * 0.08, 0.0, 1.0);
        hFactor = smoothstep(0.0, 1.0, hFactor);

        // Bending angle of vertical spine (hose) depending on height & time.
        float bend = sin(t * 0.8 + worldPos.y * freq) * baseAmp * hFactor;

        // Side-to-side displacement proportional to height (rotation around spine).
        float lateralX = bend * worldPos.y;

        // Light jello wobble in Z for extra cartoon feel.
        float lateralZ = 0.35 * bend * worldPos.y + 0.08 * sin(worldPos.y * freq * 1.7 + t * 1.3);

        // Vertical offset: when leaning sideways, top shifts up/down preserving length illusion.
        float verticalOffset = -0.15 * abs(bend) * worldPos.y + 0.05 * sin(worldPos.y * freq * 1.2 + t * 2.0);

        vec3 offset = vec3(lateralX, verticalOffset, lateralZ);

        // Map world-space offset back into the mesh's local space taking rotation into account.
        // Using the normalized world axes (columns of worldMat) as a basis allows consistent
        // deformation even when instances have different rotations.
        vec3 axisX = normalize(worldMat[0].xyz);
        vec3 axisY = normalize(worldMat[1].xyz);
        vec3 axisZ = normalize(worldMat[2].xyz);

        vec3 localOffset;
        localOffset.x = dot(offset, axisX) / scaleVec.x; // project onto local X then remove scale
        localOffset.y = dot(offset, axisY) / scaleVec.y; // project onto local Y then remove scale
        localOffset.z = dot(offset, axisZ) / scaleVec.z; // project onto local Z then remove scale

        transformed += localOffset;
      `),s===Yl&&(t.uniforms.atlasSize={value:kn},t.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`)))};const $l=100,ur=.1,dr=new F(0,1,0),fr=new F,Iu=new F,Us=new F,Uu=new F,Fs=new F,Fu=new _e,Nu=new F,$e=new oe,Le=new oe,_f=new Float32Array($l);for(let s=0;s<$l;++s)_f[s]=Math.floor(Math.random()*kn)/kn;class Zv{constructor(){U(this,"im");U(this,"faceStates",{});U(this,"uvOffsets");const t=new Hi(1,1,10,10);this.im=new Zs(t,Yl,$l),this.uvOffsets=new Hr(_f,1),t.setAttribute("uvOffset",this.uvOffsets),this.im.instanceMatrix.needsUpdate=!0}getFaceState(t,e){const n=`${t}|${e}`;return this.faceStates[n]||(this.faceStates[n]={dir:"N",faceIndex:0,slideOffset:-1,meshIndex:0}),this.faceStates[n]}clear(){this.im.count=0,this.im.instanceMatrix.needsUpdate=!0,this.im.instanceColor&&(this.im.instanceColor.needsUpdate=!0)}update(t,e){const i=t*.01,r=this.uvOffsets;for(const o of Object.values(this.faceStates)){Math.random()<t*Tn.flatConfig.emoteProbability&&(o.faceIndex=Math.floor(Math.random()*js.length));const{slideOffset:a,faceIndex:c}=o;a<0?o.slideOffset=Math.min(0,a+i):a>0&&(o.slideOffset=Math.max(0,a-i));const l=o.meshIndex;r.setX(l,(1+2*c+a)/kn)}r.needsUpdate=!0}placeFace(t,e,n,i,r){const[o,a,c,l,h,u]=t,d=this.getFaceState(i,r);d.meshIndex=this.im.count++;const p=d.meshIndex;d.dir!==e&&(d.slideOffset=Bv(d.dir,e)),d.dir=e;let x=0,g=0,m;e==="N"?(n?(x=n[0]-t[0]+.5*(n[2]-t[3]),g=.5*(n[3]-t[4]),m=Math.min(n[2],n[3])):m=Math.min(l,h),$e.position.set(o+l/2+x,a+h/2+g,c+u+ur),$e.setRotationFromAxisAngle(dr,0)):e==="S"?(n?(x=n[0]-t[0]+.5*(n[2]-t[3]),g=.5*(n[3]-t[4]),m=Math.min(n[2],n[3])):m=Math.min(l,h),$e.position.set(o+l/2+x,a+h/2+g,c-ur),$e.setRotationFromAxisAngle(dr,ps)):e==="E"?(n?(x=n[0]-t[2]+.5*(n[2]-t[5]),g=.5*(n[3]-t[4]),m=Math.min(n[2],n[3])):m=Math.min(u,h),$e.position.set(o+l+ur,a+h/2+g,c+u/2+x),$e.setRotationFromAxisAngle(dr,Ge)):e==="W"&&(n?(x=n[0]-t[2]+.5*(n[2]-t[5]),g=.5*(n[3]-t[4]),m=Math.min(n[2],n[3])):m=Math.min(u,h),$e.position.set(o-ur,a+h/2+g,c+u/2+x),$e.setRotationFromAxisAngle(dr,3*Ge)),$e.scale.set(m,m,u),$e.updateMatrix(),this.im.setMatrixAt(p,$e.matrix),this.im.instanceMatrix.needsUpdate=!0}updateActiveFace(t,e,n){const{boxIndex:i,rectIndex:r,meshIndex:o}=n;t.getMatrixAt(e,Le.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale);const c=this.getFaceState(i,r).dir;let l=0;c==="N"?(fr.set(0,0,1),l=Le.scale.z*.5):c==="S"?(fr.set(0,0,-1),l=Le.scale.z*.5):c==="E"?(fr.set(1,0,0),l=Le.scale.x*.5):(fr.set(-1,0,0),l=Le.scale.x*.5),Fs.copy(fr).applyQuaternion(Le.quaternion).normalize(),Iu.set(0,1,0).applyQuaternion(Le.quaternion).normalize(),Us.crossVectors(Iu,Fs),Us.lengthSq()<1e-8&&Us.crossVectors(dr,Fs),Us.normalize(),Uu.crossVectors(Fs,Us).normalize(),Fu.makeBasis(Us,Uu,Fs),Nu.copy(Le.position).add(Fs.multiplyScalar(l+ur));let h;c==="N"||c==="S"?h=Math.min(Le.scale.x,Le.scale.y):(c==="E"||c==="W")&&(h=Math.min(Le.scale.z,Le.scale.y)),$e.position.copy(Nu),$e.setRotationFromMatrix(Fu),$e.scale.set(h,h,Le.scale.z),$e.updateMatrix(),this.im.setMatrixAt(o,$e.matrix),this.im.count=Math.max(this.im.count,o+1),this.im.instanceMatrix.needsUpdate=!0}}const nc=100,ic=new F,pr=new Vi,Mo=new F,ii=new oe,Bt=new oe,Ou=new ee,Bu=new F(1,0,0),zu=new F(0,0,1),gt=2,Nr=class Nr{constructor(){U(this,"facesIm");U(this,"edgesIm");U(this,"boxes",{});U(this,"brightnessFactors",[1,1.3,.5,1.5,1.1,1.2]);U(this,"_boxCount",0);U(this,"_hoveredBoxIndex",-1);U(this,"_selectedBoxIndex",-1);this.facesIm=new Zs(new ki(1,1,1,1,1,1),xf,nc*6),this.edgesIm=new Zs(new ki(1,1,1,10,10,10),gf,12*nc)}get hoveredBoxIndex(){return this._hoveredBoxIndex}set hoveredBoxIndex(t){this._hoveredBoxIndex=t,this.updateColors()}set selectedBoxIndex(t){this._selectedBoxIndex=t,this.updateColors()}get selectedBoxIndex(){return this._selectedBoxIndex}clear(){for(const t of this.instancedMeshes)t.count=0,t.instanceMatrix.needsUpdate=!0,t.instanceColor&&(t.instanceColor.needsUpdate=!0);this._boxCount=0}get boxCount(){return this._boxCount}get instancedMeshes(){return[this.facesIm,this.edgesIm]}updateColors(){var e;const t=nc;for(let n=0;n<t;n++){let i=((e=this.boxes[n])==null?void 0:e.baseColor)??Sa;n===this._hoveredBoxIndex?i=Ev:n===this._selectedBoxIndex&&(i=Av);for(let r=0;r<6;r++)Ou.copy(i).multiplyScalar(this.brightnessFactors[r]),this.facesIm.setColorAt(n*6+r,Ou)}this.facesIm.instanceColor.needsUpdate=!0}setColorAt(t,e){const n=this.boxes[t];n?n.baseColor=e:this.boxes[t]={baseColor:e,box:[0,0,0,1,1,1]}}addBox(t){const e=this._boxCount;this.boxes[e]={box:t};const[n,i,r,o,a,c]=t,l=Nr.FACE_THICKNESS,h=gt/2,u=[[n+h,i+a/2,r+c/2,l,a,c],[n+o-h,i+a/2,r+c/2,l,a,c],[n+o/2,i+h,r+c/2,o,l,c],[n+o/2,i+a-h,r+c/2,o,l,c],[n+o/2,i+a/2,r+h,o,a,l],[n+o/2,i+a/2,r+c-h,o,a,l]];for(let d=0;d<6;d++){const[p,x,g,m,f,y]=u[d];ii.position.set(p,x,g),ii.scale.set(m,f,y),ii.quaternion.identity(),ii.updateMatrix(),this.facesIm.setMatrixAt(e*6+d,ii.matrix)}this.facesIm.count=(e+1)*6,this._boxCount++,this.addEdge(n,i+a/2,r,gt,a+gt,gt),this.addEdge(n+o,i+a/2,r,gt,a+gt,gt),this.addEdge(n+o,i+a/2,r+c,gt,a+gt,gt),this.addEdge(n,i+a/2,r+c,gt,a+gt,gt),this.addEdge(n+o/2,i,r,o+gt,gt,gt),this.addEdge(n+o,i,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i,r+c,o+gt,gt,gt),this.addEdge(n,i,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i+a,r,o+gt,gt,gt),this.addEdge(n+o,i+a,r+c/2,gt,gt,c+gt),this.addEdge(n+o/2,i+a,r+c,o+gt,gt,gt),this.addEdge(n,i+a,r+c/2,gt,gt,c+gt)}addEdge(t,e,n,i,r,o){ii.position.set(t,e,n),ii.scale.set(i,r,o),ii.updateMatrix(),this.edgesIm.setMatrixAt(this.edgesIm.count++,ii.matrix)}updateActiveBox(t,e,n,i){this._boxCount++,this.facesIm.count+=6,this.edgesIm.count+=12;const[r,o,a,c,l,h]=t.bounds,u=n.interpolatedPosition,d=n.interpolatedAngle,[p,x]=u,g=n.shapes[0].height,m=n.shapes[0].width;Bt.position.setY(l-x),Bt.scale.setY(g),i==="W"?(Bt.scale.setZ(m),Bt.position.setZ(p),Bt.position.setX(r+c/2),Bt.scale.setX(m),Bt.setRotationFromAxisAngle(Bu,d)):i==="E"?(Bt.scale.setZ(m),Bt.position.setZ(h-p),Bt.position.setX(r+c/2),Bt.scale.setX(m),Bt.setRotationFromAxisAngle(Bu,-d)):i==="N"?(Bt.scale.setX(m),Bt.position.setX(p),Bt.position.setZ(a+h/2),Bt.scale.setZ(m),Bt.setRotationFromAxisAngle(zu,-d)):i==="S"&&(Bt.scale.setX(m),Bt.position.setX(c-p),Bt.position.setZ(a+h/2),Bt.scale.setZ(m),Bt.setRotationFromAxisAngle(zu,d)),Bt.updateMatrix();let f=12*e;ic.copy(Bt.position),pr.copy(Bt.quaternion);const y=Bt.scale.x,v=Bt.scale.y,b=Bt.scale.z,_=y/2,M=v/2,T=b/2,P=y+gt,A=v+gt,E=b+gt,R=(H,K,G,V,$,st)=>{Mo.set(H,K,G).applyQuaternion(pr).add(ic),Bt.position.copy(Mo),Bt.quaternion.copy(pr),Bt.scale.set(V,$,st),Bt.updateMatrix(),this.edgesIm.setMatrixAt(f++,Bt.matrix)};R(-_,0,-T,gt,A,gt),R(+_,0,-T,gt,A,gt),R(+_,0,+T,gt,A,gt),R(-_,0,+T,gt,A,gt),R(0,-M,-T,P,gt,gt),R(+_,-M,0,gt,gt,E),R(0,-M,+T,P,gt,gt),R(-_,-M,0,gt,gt,E),R(0,+M,-T,P,gt,gt),R(+_,+M,0,gt,gt,E),R(0,+M,+T,P,gt,gt),R(-_,+M,0,gt,gt,E),this.edgesIm.instanceMatrix.needsUpdate=!0;const I=Nr.FACE_THICKNESS,z=(H,K,G,V,$,st,St)=>{Mo.set(H,K,G).applyQuaternion(pr).add(ic),Bt.position.copy(Mo),Bt.quaternion.copy(pr),Bt.scale.set(V,$,st),Bt.updateMatrix(),this.facesIm.setMatrixAt(e*6+St,Bt.matrix)},X=gt/2;z(-_+X,0,0,I,v,b,0),z(+_-X,0,0,I,v,b,1),z(0,-M+X,0,y,I,b,2),z(0,+M-X,0,y,I,b,3),z(0,0,-T+X,y,v,I,4),z(0,0,+T-X,y,v,I,5),this.facesIm.instanceMatrix.needsUpdate=!0}hideAll(){for(const t of[this.facesIm,this.edgesIm]){for(let e=0;e<t.count;e++)t.getMatrixAt(e,Bt.matrix),Bt.matrix.decompose(Bt.position,Bt.quaternion,Bt.scale),Bt.position.setY(1e6),Bt.updateMatrix(),t.setMatrixAt(e,Bt.matrix);t.instanceMatrix.needsUpdate=!0}}};U(Nr,"FACE_THICKNESS",.01);let vl=Nr;const sc="tt-box";class cs{static reset(t,e){document.querySelectorAll(`.${sc}`).forEach(n=>n.remove());for(const[n,i]of t.boxes.entries()){if(n===t.targetBoxIndex)continue;const r=Math.max(...Object.values(t.sideViews).map(o=>{var a;return((a=o[n])==null?void 0:a.length)??0}));for(let o=0;o<r;o++){const a=document.createElement("div");a.className=sc,a.style.display="none",a.id=`box-${n}-rect-${o}`,a.onclick=()=>e(n,o),document.body.appendChild(a)}}}static placeElement(t,e,[n,i,r,o]){const a=document.getElementById(`box-${t}-rect-${e}`);a&&(a.style.display="block",a.style.left=`${n}px`,a.style.top=`${i}px`,a.style.width=`${r}px`,a.style.height=`${o}px`)}static hideAll(){document.querySelectorAll(`.${sc}`).forEach(t=>{t.style.display="none"})}}const ua="tt-box-editor",bl=[{type:"center"},{type:"edge",dir:"E"},{type:"edge",dir:"S"},{type:"edge",dir:"N"},{type:"edge",dir:"W"},{type:"corner",dir:["N","E"]},{type:"corner",dir:["S","E"]},{type:"corner",dir:["N","W"]},{type:"corner",dir:["S","W"]}],Un=10;function vf([s,t,e,n],i){const r=Un/2,o=s+e/2,a=t+n/2;switch(i.type){case"center":return[s,t,e,n];case"edge":{switch(i.dir){case"N":return[o-r,t-r,Un,Un];case"S":return[o-r,t+n-r,Un,Un];case"E":return[s+e-r,a-r,Un,Un];case"W":return[s-r,a-r,Un,Un]}break}case"corner":{const[c,l]=i.dir,h=l==="E"?s+e:s,u=c==="S"?t+n:t;return[h-r,u-r,Un,Un]}}return[0,0,0,0]}const Vu=10;function yo(s){return Vu*Math.round(s/Vu)}function jv(s,t,e,n,i){const r=vf(e,n),o=r[0]+r[2]/2,a=r[1]+r[3]/2;let c=i[0]-o;const l=i[1]-a,h=t==="S"||t==="N"?0:2,u=t==="S"||t==="N"?3:5,d=t==="S"||t==="E";let p=s[h],x=s[1],g=s[u],m=s[4];const f=()=>{let _=c;const M=g-_;if(M<1){_=g-1,p+=_,g=1;return}p+=_,g=M},y=()=>{const _=g+c;g=_<1?1:_},v=()=>{let _=l;const M=m-_;if(M<1){_=m-1,x+=_,m=1;return}x+=_,m=M},b=()=>{const _=m+l;m=_<1?1:_};switch(d&&(c*=-1),n.type){case"center":p+=c,x+=l;break;case"edge":switch(n.dir){case"W":d?y():f();break;case"E":d?f():y();break;case"N":v();break;case"S":b();break}break;case"corner":{const[_,M]=n.dir;M==="W"?d?y():f():d?f():y(),_==="N"?v():b();break}}s[h]=yo(p),s[1]=yo(x),s[u]=yo(g),s[4]=yo(m)}let Si=-1;class ui{static down(t,e){Si=e;const n=document.getElementById(`node-${Si}`);n&&n.classList.add("active")}static move(t){if(Si===-1)return;const e=Si;if(this.towerToppler){const n=this.towerToppler.graphics.boxes.selectedBoxIndex;if(n>=0){const i=this.towerToppler.state.levelIndex,o=oi[i].boxes[n],a=this.towerToppler.state.flatDirection,c=this.towerToppler.locateBoxOnScreen(n);jv(o,a,c,bl[e],t),this.towerToppler.rebuildGraphics(),this.showAll(),Si=e}}}static up(t){Si>=0&&(document.querySelectorAll(`.${ua}`).forEach(e=>{e.classList.remove("active")}),Si=-1)}static showAll(){if(Si=-1,this.towerToppler){const t=this.towerToppler.graphics.boxes.selectedBoxIndex;if(t>=0){const e=this.towerToppler.locateBoxOnScreen(t);for(const[n,i]of bl.entries()){const r=vf(e,i);this.placeNode(n,r)}}}}static hideAll(){document.querySelectorAll(`.${ua}`).forEach(t=>{t.style.display="none"})}static placeNode(t,[e,n,i,r]){const o=document.getElementById(`node-${t}`);o&&(o.style.display="block",o.style.left=`${e}px`,o.style.top=`${n}px`,o.style.width=`${i}px`,o.style.height=`${r}px`)}}U(ui,"towerToppler",null);for(const[s,t]of bl.entries()){const e=document.createElement("div");e.classList.add(ua,`${ua}-${t.type}`),e.style.display="none",e.id=`node-${s}`,e.onpointerdown=n=>{ui.down([n.clientX,n.clientY],s),n.stopPropagation()},document.body.appendChild(e)}document.addEventListener("mousemove",s=>ui.move([s.clientX,s.clientY]));document.addEventListener("mouseup",s=>ui.up([s.clientX,s.clientY]));function Jv(s,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",n=t.display.classes??[],i=n.filter(a=>a.startsWith("fa-")),r=n.filter(a=>!a.startsWith("fa-"));t.display.type!=="button"&&r.push("noselect");const o=t1(`
    <${e} 
       id="${s}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${r.join(" ")}
        ">

      <span 
        class="${i.join(" ")}" 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[a,c]of Object.entries(t.display.styles??{}))o.style.setProperty(a,c);return t.id=s,t.htmlElem=o,o}function mr(s,t){t?us(s):Fi(s)}function Fi(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function us(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function So(s,t){if(s.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:n}=s;n&&(n.innerHTML=`
    <span ${s.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function Qv(s,t,e){if(!e){s.classList.add("hidden");return}s.style.opacity="";const[n,i,r,o]=e;s.style.display="",s.style.left=`${n}px`,s.style.top=`${i}px`,s.style.width=`${r}px`,s.style.height=`${o}px`;const a=s;a.width=r*window.devicePixelRatio,a.height=o*window.devicePixelRatio}function t1(s){const t=document.createElement("div");return t.innerHTML=s.trim(),t.firstChild}function e1(s){s.isLandscape,s.isPortrait}function n1(s){return Object.entries(s)}function i1(s,t){return new Ml(s,t)._computedRects}const Wn=class Wn{constructor(t,e){U(this,"_computedRects",{});U(this,"isPortrait",!1);U(this,"isLandscape",!1);U(this,"parent");U(this,"_currentLayoutKey","");U(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const n=600;t[2]<n||t[3]<n?Wn.isSmall=!0:Wn.isSmall=!1,e1(this),this.parent=t;for(const[r,o]of Object.entries(e))this.parent=t,this._currentLayoutKey=r,this._computedRects[r]=this.computeRect(o);const i=this._childrenToParse;for(;Object.keys(i).length>0;){const r=Object.keys(i)[0],o=i[r];delete i[r];const a=this._computedRects[r],{_computedRects:c}=new Wn(a,o);for(const l in c)this._computedRects[`${r}.${l}`]=c[l]}}computeRect(t){let e=[...this.parent];for(const[n,i]of n1(t))if(n==="parent"){if(!(i in this._computedRects))throw new Error(`layout parent '${i}' not defined by any previous rulesets`);this.parent=this._computedRects[i],e=[...this.parent]}else if(n.startsWith("parent@")){const[r,o]=n.split("@");if(typeof i!="string"||!(i in this._computedRects))throw new Error(`layout parent '${i}' not defined by any previous rulesets`);if(o==="portrait")this.isPortrait&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="landscape")this.isLandscape&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="sm-portrait")this.isPortrait&&Wn.isSmall&&(this.parent=this._computedRects[i],e=[...this.parent]);else if(o==="sm-landscape")this.isLandscape&&Wn.isSmall&&(this.parent=this._computedRects[i],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else if(n==="children")this._childrenToParse[this._currentLayoutKey]=i;else if(n.includes("@")){const[r,o]=n.split("@");if(o==="portrait")this.isPortrait&&(e=this.applyRule(e,r,i));else if(o==="landscape")this.isLandscape&&(e=this.applyRule(e,r,i));else if(o==="sm-portrait")this.isPortrait&&Wn.isSmall&&(e=this.applyRule(e,r,i));else if(o==="sm-landscape")this.isLandscape&&Wn.isSmall&&(e=this.applyRule(e,r,i));else throw new Error(`invalid @ condition suffix: '${o}'. expected portait or landscape.`)}else e=this.applyRule(e,n,i);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,n){const[i,r,o,a]=t,[c,l,h,u]=this.parent,d=(x,g)=>{if(typeof g=="function"&&(g=g()),typeof g=="string"&&g.endsWith("%")){const m=parseFloat(g)/100;return["left","right","width","margin"].includes(x)?h*m:u*m}else{if(g==="auto")return x==="width"?c+h-i:x==="height"?l+u-r:["left","right"].includes(x)?(h-o)/2:(u-a)/2;if(typeof g=="number"&&g<0){if(x==="width")return h+g;if(x==="height")return u+g}}return Number(g)},p=e.split("-");if(p.length===2){const[x,g]=p;let m;if(x==="min")m=Math.max;else if(x==="max")m=Math.min;else throw new Error("only min- or max- prefixed allowed");if(g==="width")return[i,r,m(o,d("width",n)),a];if(g==="height")return[i,r,o,m(a,d("height",n))];if(g==="left")return[m(i,d("left",n)),r,o,a];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[c+d("left",n),r,o,a];case"right":return[c+h-o-d("right",n),r,o,a];case"top":return[i,l+d("top",n),o,a];case"bottom":return[i,l+u-a-d("bottom",n),o,a];case"width":return[i,r,d("width",n),a];case"height":return[i,r,o,d("height",n)];case"margin":{const x=d("margin",n);return[i+x,r+x,o-2*x,a-2*x]}default:return t}}};U(Wn,"isSmall",!1);let Ml=Wn;const ku={};let s1=0;class xn{constructor(){U(this,"guiLayout");U(this,"layoutRectangles",{});U(this,"elements",{});U(this,"layoutFactory")}init(t,e,n){this.layoutFactory=e;for(const i of n)if(typeof i.id=="string")this.elements[i.id]=i;else{const r=`_${s1++}`;this.elements[r]=i;const o=Jv(r,i);o.onclick=a=>{a.preventDefault(),i.click&&i.click({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerdown=a=>{a.preventDefault(),i.down&&i.down({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointermove=a=>{a.preventDefault(),i.move&&i.move({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerup=a=>{a.preventDefault(),i.up&&i.up({elementId:r,towerToppler:t,pointerEvent:a})},o.onpointerleave=a=>{a.preventDefault(),i.up&&i.up({elementId:r,towerToppler:t,pointerEvent:a})},o.style.display="none",document.body.appendChild(o),ku[r]=o,i.id=r}}refreshLayout(t){const e=[0,0,window.innerWidth,window.innerHeight];this.guiLayout=this.layoutFactory(t),this.layoutRectangles=i1(e,this.guiLayout);for(const n in this.elements){const i=this.elements[n],r=this.layoutRectangles[i.layoutKey];i.rectangle=r,i.rectangle&&(i.dprRectangle=i.rectangle.map(o=>o*window.devicePixelRatio)),Qv(ku[n],i,r)}}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const n=this._registry[e];if(!n)throw new Error(`gui ${e} not registered `);const{factory:i,layoutFactory:r,elements:o}=n,a=i();this._preloaded[e]=a,a.init(t,r,o)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}U(xn,"_registry",{}),U(xn,"_preloaded",{});const r1={screen:{},_outerMargin:{parent:"screen",margin:()=>Re.flatConfig.outerMargin},topLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight},bottomLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},nextLevelBtn:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,bottom:0},resetBtn:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,top:0},bottomBar:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:"auto",bottom:0},rotateLeft:{parent:"bottomBar",width:"50%"},rotateRight:{parent:"bottomBar",width:"50%",right:0}},bf={layoutKey:"topLabel",display:{type:"panel",label:"Remove one block",textAlign:"left",styles:{border:"none"}}},Di={layoutKey:"bottomLabel",display:{type:"panel",label:"Drag to rotate",textAlign:"left",styles:{border:"none"}}},yl={layoutKey:"resetBtn",display:{type:"button",label:"Reset",classes:["click-me"]},click:({towerToppler:s})=>{s.resetLevel()}},Tr={layoutKey:"nextLevelBtn",display:{type:"button",label:"Next",classes:["click-me"]},click:({towerToppler:s})=>{s.goToNextLevel()}},Kl={layoutKey:"rotateLeft",display:{type:"button",label:"<"},click:({towerToppler:s})=>{s.toggleViewDirection(-1)}},Zl={layoutKey:"rotateRight",display:{type:"button",label:">"},click:({towerToppler:s})=>{s.toggleViewDirection(1)}},lh=class lh extends xn{};xn.register("playing-gui",{factory:()=>new lh,layoutFactory:()=>r1,elements:[bf,yl,Di,Tr,Kl,Zl]});let Gu=lh;const zs={hasDragged:!1,hasRemovedBlock:!1},Hu={type:"change"},jl={type:"start"},Mf={type:"end"},Eo=new Wl,Wu=new Li,o1=Math.cos(70*Gl.DEG2RAD),Ue=new F,an=2*Math.PI,fe={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},rc=1e-6;class a1 extends D0{constructor(t,e=null){super(t,e),this.state=fe.NONE,this.target=new F,this.cursor=new F,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Gs.ROTATE,MIDDLE:Gs.DOLLY,RIGHT:Gs.PAN},this.touches={ONE:Vs.ROTATE,TWO:Vs.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new F,this._lastQuaternion=new Vi,this._lastTargetPosition=new F,this._quat=new Vi().setFromUnitVectors(t.up,new F(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new aa,this._sphericalDelta=new aa,this._scale=1,this._panOffset=new F,this._rotateStart=new zt,this._rotateEnd=new zt,this._rotateDelta=new zt,this._panStart=new zt,this._panEnd=new zt,this._panDelta=new zt,this._dollyStart=new zt,this._dollyEnd=new zt,this._dollyDelta=new zt,this._dollyDirection=new F,this._mouse=new zt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=l1.bind(this),this._onPointerDown=c1.bind(this),this._onPointerUp=h1.bind(this),this._onContextMenu=g1.bind(this),this._onMouseWheel=f1.bind(this),this._onKeyDown=p1.bind(this),this._onTouchStart=m1.bind(this),this._onTouchMove=x1.bind(this),this._onMouseDown=u1.bind(this),this._onMouseMove=d1.bind(this),this._interceptControlDown=_1.bind(this),this._interceptControlUp=v1.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}connect(t){super.connect(t),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Hu),this.update(),this.state=fe.NONE}update(t=null){const e=this.object.position;Ue.copy(e).sub(this.target),Ue.applyQuaternion(this._quat),this._spherical.setFromVector3(Ue),this.autoRotate&&this.state===fe.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,i=this.maxAzimuthAngle;isFinite(n)&&isFinite(i)&&(n<-Math.PI?n+=an:n>Math.PI&&(n-=an),i<-Math.PI?i+=an:i>Math.PI&&(i-=an),n<=i?this._spherical.theta=Math.max(n,Math.min(i,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+i)/2?Math.max(n,this._spherical.theta):Math.min(i,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(Ue.setFromSpherical(this._spherical),Ue.applyQuaternion(this._quatInverse),e.copy(this.target).add(Ue),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const a=Ue.length();o=this._clampDistance(a*this._scale);const c=a-o;this.object.position.addScaledVector(this._dollyDirection,c),this.object.updateMatrixWorld(),r=!!c}else if(this.object.isOrthographicCamera){const a=new F(this._mouse.x,this._mouse.y,0);a.unproject(this.object);const c=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=c!==this.object.zoom;const l=new F(this._mouse.x,this._mouse.y,0);l.unproject(this.object),this.object.position.sub(l).add(a),this.object.updateMatrixWorld(),o=Ue.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(Eo.origin.copy(this.object.position),Eo.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Eo.direction))<o1?this.object.lookAt(this.target):(Wu.setFromNormalAndCoplanarPoint(this.object.up,this.target),Eo.intersectPlane(Wu,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>rc||8*(1-this._lastQuaternion.dot(this.object.quaternion))>rc||this._lastTargetPosition.distanceToSquared(this.target)>rc?(this.dispatchEvent(Hu),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?an/60*this.autoRotateSpeed*t:an/60/60*this.autoRotateSpeed}_getZoomScale(t){const e=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*e)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,e){Ue.setFromMatrixColumn(e,0),Ue.multiplyScalar(-t),this._panOffset.add(Ue)}_panUp(t,e){this.screenSpacePanning===!0?Ue.setFromMatrixColumn(e,1):(Ue.setFromMatrixColumn(e,0),Ue.crossVectors(this.object.up,Ue)),Ue.multiplyScalar(t),this._panOffset.add(Ue)}_pan(t,e){const n=this.domElement;if(this.object.isPerspectiveCamera){const i=this.object.position;Ue.copy(i).sub(this.target);let r=Ue.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*r/n.clientHeight,this.object.matrix),this._panUp(2*e*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(e*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,e){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),i=t-n.left,r=e-n.top,o=n.width,a=n.height;this._mouse.x=i/o*2-1,this._mouse.y=-(r/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientX),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(an*this._rotateDelta.x/e.clientHeight),this._rotateUp(an*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let e=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(an*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),e=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-an*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),e=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(an*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),e=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-an*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),e=!0;break}e&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._rotateStart.set(n,i)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._panStart.set(n,i)}}_handleTouchStartDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,i=t.pageY-e.y,r=Math.sqrt(n*n+i*i);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{const n=this._getSecondPointerPosition(t),i=.5*(t.pageX+n.x),r=.5*(t.pageY+n.y);this._rotateEnd.set(i,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const e=this.domElement;this._rotateLeft(an*this._rotateDelta.x/e.clientHeight),this._rotateUp(an*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{const e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),i=.5*(t.pageY+e.y);this._panEnd.set(n,i)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){const e=this._getSecondPointerPosition(t),n=t.pageX-e.x,i=t.pageY-e.y,r=Math.sqrt(n*n+i*i);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(t.pageX+e.x)*.5,a=(t.pageY+e.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId){this._pointers.splice(e,1);return}}_isTrackingPointer(t){for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId)return!0;return!1}_trackPointer(t){let e=this._pointerPositions[t.pointerId];e===void 0&&(e=new zt,this._pointerPositions[t.pointerId]=e),e.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){const e=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[e]}_customWheelEvent(t){const e=t.deltaMode,n={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(e){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function c1(s){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(s.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(s)&&(this._addPointer(s),s.pointerType==="touch"?this._onTouchStart(s):this._onMouseDown(s)))}function l1(s){this.enabled!==!1&&(s.pointerType==="touch"?this._onTouchMove(s):this._onMouseMove(s))}function h1(s){switch(this._removePointer(s),this._pointers.length){case 0:this.domElement.releasePointerCapture(s.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Mf),this.state=fe.NONE;break;case 1:const t=this._pointers[0],e=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:e.x,pageY:e.y});break}}function u1(s){let t;switch(s.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case Gs.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(s),this.state=fe.DOLLY;break;case Gs.ROTATE:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=fe.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=fe.ROTATE}break;case Gs.PAN:if(s.ctrlKey||s.metaKey||s.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(s),this.state=fe.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(s),this.state=fe.PAN}break;default:this.state=fe.NONE}this.state!==fe.NONE&&this.dispatchEvent(jl)}function d1(s){switch(this.state){case fe.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(s);break;case fe.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(s);break;case fe.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(s);break}}function f1(s){this.enabled===!1||this.enableZoom===!1||this.state!==fe.NONE||(s.preventDefault(),this.dispatchEvent(jl),this._handleMouseWheel(this._customWheelEvent(s)),this.dispatchEvent(Mf))}function p1(s){this.enabled!==!1&&this._handleKeyDown(s)}function m1(s){switch(this._trackPointer(s),this._pointers.length){case 1:switch(this.touches.ONE){case Vs.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(s),this.state=fe.TOUCH_ROTATE;break;case Vs.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(s),this.state=fe.TOUCH_PAN;break;default:this.state=fe.NONE}break;case 2:switch(this.touches.TWO){case Vs.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(s),this.state=fe.TOUCH_DOLLY_PAN;break;case Vs.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(s),this.state=fe.TOUCH_DOLLY_ROTATE;break;default:this.state=fe.NONE}break;default:this.state=fe.NONE}this.state!==fe.NONE&&this.dispatchEvent(jl)}function x1(s){switch(this._trackPointer(s),this.state){case fe.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(s),this.update();break;case fe.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(s),this.update();break;case fe.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(s),this.update();break;case fe.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(s),this.update();break;default:this.state=fe.NONE}}function g1(s){this.enabled!==!1&&s.preventDefault()}function _1(s){s.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function v1(s){s.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const b1=.01,oc=30,Xu=new F,qu=new F,Yu=new F,Ji=new F,M1=new F,y1=new F,xr=new F,Ei=new aa,Qi=new aa;class S1{constructor(t){U(this,"camera");U(this,"controls");U(this,"currentViewMode","perspective");U(this,"cameraDist",100);U(this,"isDragging",!1);U(this,"isSnapping",!1);U(this,"isFlat",!1);U(this,"reachedTargetPerspective",!1);this.camera=new wn(oc,window.innerWidth/window.innerHeight,10,1e10),this.controls=new a1(this.camera,t),this.controls.enableDamping=!0,this.controls.dampingFactor=.1,this.controls.enablePan=!1,this.controls.enableZoom=!0,this.controls.minDistance=10,this.controls.maxDistance=1e10,this.controls.addEventListener("start",()=>this.startDrag()),this.controls.addEventListener("end",()=>this.endDrag())}startDrag(){this.isDragging=!0,this.isSnapping=!1,this.isFlat=!1,this.toggleViewMode("perspective"),cs.hideAll(),ui.hideAll()}endDrag(){this.isDragging=!1}reset(t){const[e,n,i,r,o,a]=t.bounds,c=[r/2,o/2,a/2];this.isDragging=!1,this.isSnapping=!1,this.isFlat=!1,this.camera.fov=oc,this.currentViewMode="perspective",this.reachedTargetPerspective=!1,this.cameraDist=100;const l=40;this.camera.position.set(c[0]+10*l,c[1]+12*l,c[2]+14*l),this.camera.lookAt(...c),this.camera.updateProjectionMatrix(),this.controls.enabled=!0,this.controls.target.set(...c),this.controls.update(),this.cameraDist=this.camera.position.distanceTo(this.controls.target)}update(t,e){if(!this.reachedTargetPerspective){let n;this.currentViewMode==="orthographic"?n=b1:n=oc,this.animatePerspective(n,t)}if(this.controls.update(),!this.isFlat&&!this.isSnapping&&!this.isDragging&&(Math.abs(this.controls._sphericalDelta.theta)>.01||Math.abs(this.controls._sphericalDelta.phi)>.01||Math.abs(this.controls._sphericalDelta.radius)>.01||(e.flatDirection=Nv(this.camera,this.controls.target),(e.flatDirection==="E"||e.flatDirection==="W")&&(zs.hasDragged=!0,Fi(Di),us(Kl),us(Zl)),this.isSnapping=!0,this.toggleViewMode("orthographic"))),!this.isDragging&&this.isSnapping){const n=this.camera,i=this.controls.target;xr.copy(n.position).sub(i);const r=Ov(this.controls.target,this.cameraDist,e.flatDirection);Ji.set(r[0]-i.x,r[1]-i.y,r[2]-i.z),Ei.radius=xr.length(),Ei.theta=Math.atan2(xr.x,xr.z),Ei.phi=Math.acos(xr.y/(Ei.radius||1e-8)),Xu.set(Ji.x,Ji.y,Ji.z),Qi.radius=Xu.length(),Qi.theta=Math.atan2(Ji.x,Ji.z),Qi.phi=Math.acos(Ji.y/(Qi.radius||1e-8));const o=.18;let a=Qi.theta-Ei.theta;a>Math.PI&&(a-=2*Math.PI),a<-Math.PI&&(a+=2*Math.PI);const c=Ei.theta+a*o,l=la(Ei.phi,Qi.phi,o),h=la(Ei.radius,Qi.radius,o),u=Math.sin(l),d=h*u*Math.sin(c),p=h*Math.cos(l),x=h*u*Math.cos(c);n.position.set(i.x+d,i.y+p,i.z+x),n.lookAt(i.x,i.y,i.z),n.updateProjectionMatrix(),this.controls.update(),qu.subVectors(n.position,i).normalize(),Yu.set(r[0]-i.x,r[1]-i.y,r[2]-i.z).normalize();const g=qu.dot(Yu);if(Math.acos(Math.max(-1,Math.min(1,g)))<1e-4)return n.position.set(r[0],r[1],r[2]),n.lookAt(i.x,i.y,i.z),n.updateProjectionMatrix(),this.controls.update(),this.isSnapping=!1,this.isFlat=!0,!0}return!1}getScale2d(){const t=this.camera.fov*Math.PI/180,n=2*Math.tan(t/2)*this.cameraDist*this.camera.aspect;return window.innerWidth/n}onResize(){this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix(),this.controls&&this.controls.update(),this.isFlat=!1}toggleViewMode(t){t||(this.currentViewMode==="orthographic"?t="perspective":t="orthographic"),t!==this.currentViewMode&&(this.currentViewMode=t,this.reachedTargetPerspective=!1)}animatePerspective(t,e){const n=this.camera,i=this.controls,r=i.target,o=this.cameraDist,a=n.fov,c=Math.tan(a*Math.PI/180/2)*o,l=.1;let h=a;Math.abs(t-a)<=l*e?(h=t,this.reachedTargetPerspective=!0):h+=Math.sign(t-a)*l*e;const u=c/Math.tan(h*Math.PI/180/2);this.cameraDist=u;const d=M1.copy(r).sub(n.position).normalize();n.position.copy(y1.copy(r).sub(d.multiplyScalar(u))),n.fov=h,n.updateProjectionMatrix(),i.update()}}const E1=new sn({color:Mv}),da=1e3,$u=1e3,A1=new ke(da,da,$u).translate(0,-$u/2,0),w1=new hn(A1,E1),T1=new sn({color:0,side:Bn}),C1=new ke(da,da,2,32,1,!0).translate(0,1,0),R1=new hn(C1,T1),P1=new sn({color:14540253,side:Bn}),L1=new ke(1,1,1,4,1,!0).rotateY(ci).translate(0,.5,0),Ku=new hn(L1,P1);class Cr{static reset(t){const[e,n,i,r,o,a]=t.bounds;this.mesh.position.set(e+r/2,n,i+a/2),Ku.scale.set(r,1,a)}}U(Cr,"mesh",new Ar().add(w1,Ku,R1));const Zu=new oe,Ai=new oe,Fn=new oe,ac=new F;class D1{constructor(t,e,n=1,i=new F(0,0,0)){U(this,"im");U(this,"faceStates",[]);U(this,"uvOffsets");U(this,"geometry");this.maxCount=t;const r=new Hi().translate(i.x/n,i.y/n,1+i.z/n).scale(n,n,1);this.im=new Zs(r,e,t);const o=new Float32Array(t);for(let a=0;a<t;++a)o[a]=Math.floor(Math.random()*kn)/kn;this.uvOffsets=new Hr(o,1),r.setAttribute("uvOffset",this.uvOffsets),this.im.instanceMatrix.needsUpdate=!0,this.geometry=r}clear(){this.im.count=0,this.im.instanceMatrix.needsUpdate=!0,this.im.instanceColor&&(this.im.instanceColor.needsUpdate=!0)}hideAll(){const t=this.im;for(let e=0;e<t.count;e++)t.getMatrixAt(e,Ai.matrix),Ai.matrix.decompose(Ai.position,Ai.quaternion,Ai.scale),Ai.position.setY(1e6),Ai.updateMatrix(),t.setMatrixAt(e,Ai.matrix);t.instanceMatrix.needsUpdate=!0}addFace(){const t=this.im.count,e=Math.floor(Math.random()*js.length);this.faceStates.push({faceIndex:e,slideOffset:-1}),this.uvOffsets.setX(t,(1+2*e)/kn),this.im.count++}update(t){const n=t*.01,i=this.uvOffsets;for(let r=0;r<this.im.count;r++){const o=this.faceStates[r];Math.random()<t*Tn.flatConfig.emoteProbability&&(o.faceIndex=Math.floor(Math.random()*js.length));const{slideOffset:a,faceIndex:c}=o;a<0?o.slideOffset=Math.min(0,a+n):a>0&&(o.slideOffset=Math.max(0,a-n)),i.setX(r,(1+2*c+a)/kn)}i.needsUpdate=!0,this.im.instanceMatrix.needsUpdate=!0}positionFaces(t,e){let n=0;for(const i of t)Fn.matrix.copy(i),Fn.matrix.decompose(Fn.position,Fn.quaternion,Fn.scale),Fn.scale.setY(Fn.scale.x),ac.copy(e.position),ac.y=Fn.position.y,Fn.lookAt(ac),Fn.updateMatrix(),this.im.setMatrixAt(n,Fn.matrix),n++,n>=this.faceStates.length&&this.addFace();this.im.count=n,this.im.instanceMatrix.needsUpdate=!0}*_getAnchors(t){for(let e=0;e<t.count;e++)t.getMatrixAt(e,Zu.matrix),yield Zu.matrix}positionFacesOnMeshes(t,e){this.positionFaces(this._getAnchors(t),e)}}function I1(s,t=!1){const e=s[0].index!==null,n=new Set(Object.keys(s[0].attributes)),i=new Set(Object.keys(s[0].morphAttributes)),r={},o={},a=s[0].morphTargetsRelative,c=new Rn;let l=0;for(let h=0;h<s.length;++h){const u=s[h];let d=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const p in u.attributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;r[p]===void 0&&(r[p]=[]),r[p].push(u.attributes[p]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const p in u.morphAttributes){if(!i.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[p]===void 0&&(o[p]=[]),o[p].push(u.morphAttributes[p])}if(t){let p;if(e)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;c.addGroup(l,p,h),l+=p}}if(e){let h=0;const u=[];for(let d=0;d<s.length;++d){const p=s[d].index;for(let x=0;x<p.count;++x)u.push(p.getX(x)+h);h+=s[d].attributes.position.count}c.setIndex(u)}for(const h in r){const u=ju(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;c.setAttribute(h,u)}for(const h in o){const u=o[h][0].length;if(u===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[h]=[];for(let d=0;d<u;++d){const p=[];for(let g=0;g<o[h].length;++g)p.push(o[h][g][d]);const x=ju(p);if(!x)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;c.morphAttributes[h].push(x)}}return c}function ju(s){let t,e,n,i=-1,r=0;for(let l=0;l<s.length;++l){const h=s[l];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(i===-1&&(i=h.gpuType),i!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}const o=new t(r),a=new _n(o,e,n);let c=0;for(let l=0;l<s.length;++l){const h=s[l];if(h.isInterleavedBufferAttribute){const u=c/e;for(let d=0,p=h.count;d<p;d++)for(let x=0;x<e;x++){const g=h.getComponent(d,x);a.setComponent(d+u,x,g)}}else o.set(h.array,c);c+=h.count*e}return i!==void 0&&(a.gpuType=i),a}function U1(s){const t=[],e=[];for(const o in s){if(!("color"in s[o]))throw new Error("must have color defined");const{geometry:a,color:c,count:l=1}=s[o];if(l!==1)throw new Error("simple scenery groups must have count of 1 or unspecified");t.push(a),e.push(c)}const n=I1(t);n.computeBoundingBox(),n.computeBoundingSphere();const i=new sn({vertexColors:!0}),r=[];for(let o=0;o<t.length;o++){const c=t[o].getAttribute("position").count,{r:l,g:h,b:u}=new ee(e[o]);for(let d=0;d<c;d++)r.push(l,h,u)}return n.setAttribute("color",new _n(new Float32Array(r),3)),{geometry:n,material:i}}class un{constructor(t,e){U(this,"memberData",[]);U(this,"fillerNames",[]);U(this,"edgeNames",[]);U(this,"fillers");U(this,"edges");U(this,"faces");U(this,"instancedMeshes");U(this,"anchorIm");U(this,"initShader");U(this,"edgeMaterial",new sn({color:lf}));U(this,"faceMaterial",new sn({map:xi,transparent:!0,opacity:.5}));U(this,"didInit",!1);U(this,"groundY",0);U(this,"centerX",0);U(this,"centerZ",0);this.data=t,this.params=e;const n={};for(const r in e.fillers){const o=e.fillers[r],{geometry:a,count:c=1}=o;this.fillerNames.push(r),n[r]=new Zs(a,"color"in o?new sn({color:o.color}):o.material,c*t.maxCount)}this.fillers=n;const i={};for(const r in e.edges){const{geometry:o,count:a=1}=e.edges[r];this.edgeNames.push(r),i[r]=new Zs(o,this.edgeMaterial,a*t.maxCount)}this.edges=i,this.instancedMeshes=[...Object.values(this.fillers),...Object.values(this.edges)],this.params.faceAnchor&&(this.faces=new D1(t.maxCount,this.faceMaterial,this.params.faceScale,this.params.faceOffset),this.instancedMeshes.push(this.faces.im),typeof this.params.faceAnchor=="string"&&(this.anchorIm=this.fillers[this.params.faceAnchor]))}init(){if(this.didInit)throw new Error("already called init");this.didInit=!0;const{initShader:t}=this;if(t){const e=[...Object.values(this.fillers).map(i=>i.material),this.edgeMaterial,this.faceMaterial],n=Gl.generateUUID();for(const i of e)i.customProgramCacheKey=()=>n,i.onBeforeCompile=r=>{t(r),i===this.faceMaterial&&(r.uniforms.atlasSize={value:kn},r.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+r.vertexShader,r.vertexShader=r.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`)))}}else this.faceMaterial.onBeforeCompile=e=>{e.uniforms.atlasSize={value:kn},e.vertexShader=`uniform float atlasSize;
attribute float uvOffset;
`+e.vertexShader,e.vertexShader=e.vertexShader.replace("#include <uv_vertex>",["#ifdef USE_MAP","vMapUv = ( mapTransform * vec3( vec2( uv.x / atlasSize, uv.y ), 1 ) ).xy;","vMapUv.x += uvOffset;","#endif"].join(`
`))}}clear(){this.memberData.length=0;for(const t of this.instancedMeshes)t.count=0;this.faces&&this.faces.clear()}addMember(t){const e=this.memberData.length;this.memberData.push(t);for(const n of this.fillerNames)this.fillers[n].count+=this.params.fillers[n].count??1;for(const n of this.edgeNames)this.edges[n].count+=this.params.edges[n].count??1;this.initMember(e,t)}spawnMembers(t){const[e,n,i,r,o,a]=t.bounds;this.groundY=n;const c=e+r/2,l=i+a/2;this.centerX=c,this.centerZ=l;for(let h=0;h<this.data.maxCount;h++){const u=la(...this.data.distance,Math.random()),d=Ge*Math.floor(Math.random()*4)+Fv(0,.1),p=this.centerX+u*Math.cos(d),x=this.centerZ+u*Math.sin(d);this.addMember(this.spawnMember(h,{pos:new F(p,0,x),animState:"shown",animStart:performance.now(),maxOffset:50,entranceOffset:0}))}}forEachIm(t){const{fillers:e,fillerNames:n,edges:i,edgeNames:r,faces:o,params:a}=this;for(const c of n){const l=a.fillers[c].count??1;t(e[c],l)}for(const c of r){const l=a.edges[c].count??1;t(i[c],l)}o&&t(o.im,1)}update(t,e,n,i){const r=this.data.maxCount;let o=0;for(let l=0;l<r;l++){const h=this.memberData[l];this.updateMemberData(l,h,t);const u=this.updateMemberEntrance(h,i);h.entranceOffset=u,u!==null&&this.updateMemberGfx(o++,h,u,e,n)}const{faces:a,anchorIm:c}=this;a&&c?(a.positionFacesOnMeshes(c,e),a.update(t)):a&&(a.positionFaces(this.params.faceAnchor,e),a.update(t)),this.forEachIm((l,h)=>{l.count=o*h});for(const l of this.instancedMeshes)l.instanceMatrix.needsUpdate=!0}updateMemberEntrance(t,e){const n=Math.atan2(t.pos.x-this.centerX,t.pos.z-this.centerZ),i=Math.abs((n-e+xl+ps)%xl-ps),r=i<ci,o=i>Ge;r?(t.animState==="hidden"||t.animState==="hiding")&&(t.animState="showing",t.animStart=performance.now()):(t.animState==="shown"||t.animState==="showing")&&(t.animState="hiding",t.animStart=performance.now()),o&&(t.animState="hidden");let a=0;if(t.animState==="hidden")return null;if(t.animState==="shown")a=0;else{const c=(performance.now()-t.animStart)/1e3,l=Tn.flatConfig.seDamping,h=Tn.flatConfig.seFreq;if(t.animState==="showing"){const u=1-Math.exp(-l*c)*Math.cos(h*c);a=t.maxOffset*(1-u),c>Tn.flatConfig.seMaxTime&&(t.animState="shown",a=0)}else if(t.animState==="hiding"){const u=Tn.flatConfig.seMaxTime-c,d=1-Math.exp(-l*u)*Math.cos(h*u);a=t.maxOffset*(1-d),c>Tn.flatConfig.seMaxTime&&(t.animState="hidden",a=t.maxOffset)}}return a}static register(t,e){if(t in this._registry)throw new Error(`Scenery group already registered: '${t}'`);this._registry[t]=e}static create(t,e){if(t in this._registry)return this._registry[t](e);throw new Error(`scenery group '${t}' was not registered`)}}U(un,"_registry",{});const F1=[["sun",{maxCount:1,distance:[1400,1400]}],["rainbow",{maxCount:2,distance:[1e3,1200]}],["tall-hill",{maxCount:10,distance:[600,700]}],["hill",{maxCount:10,distance:[550,650]}],["stalk",{maxCount:20,distance:[550,600]}],["cloud",{maxCount:20,distance:[600,650]}]],N1=100;let ls;function O1(s,t){ls=[];for(const e of t)for(const[n,i]of e.memberData.entries()){const r=e.getRadiusForSolver(i);r&&ls.push({group:e,indexInGroup:n,datum:i,radius:r,fx:0,fz:0})}for(let e=0;e<N1&&B1();e++);}const Ju=.3;function B1(){let s=0;for(const n of ls)n.fx=0,n.fz=0;const t=ls.length;for(let n=0;n<t;n++){const i=ls[n];for(let r=n+1;r<t;r++){const o=ls[r],a=i.datum.pos.x-o.datum.pos.x,c=i.datum.pos.z-o.datum.pos.z,l=Math.sqrt(a*a+c*c);if(l<i.radius+o.radius){s++;const h=i.radius+o.radius-l,u=Math.atan2(c,a),d=Math.cos(u)*h*Ju,p=Math.sin(u)*h*Ju;i.fx+=d,i.fz+=p,o.fx-=d,o.fz-=p}}}const e=s>0;if(e)for(const{datum:n,fx:i,fz:r}of ls)n.pos.set(n.pos.x+i,n.pos.y,n.pos.z+r);return e}let Qu=!1;class z1{constructor(){U(this,"renderer");U(this,"scene");U(this,"camera");U(this,"boxes");U(this,"faces");U(this,"sceneryGroups");if(Qu)throw new Error("Graphics constructed multiple times");Qu=!0,this.renderer=new vv({logarithmicDepthBuffer:!0}),this.renderer.setPixelRatio(window.devicePixelRatio/Tn.flatConfig.pixelScale),this.renderer.setSize(window.innerWidth,window.innerHeight),document.body.appendChild(this.renderer.domElement),this.camera=new S1(this.renderer.domElement),this.scene=new M0,this.scene.background=new ee(bv),this.boxes=new vl,this.faces=new Zv,this.sceneryGroups=F1.map(([t,e])=>un.create(t,e));for(const t of this.sceneryGroups)t.init()}draw(t){const e=this.camera.camera,n=this.camera.controls.target;Cr.mesh.visible=this.camera.cameraDist>1e3||e.position.y>Cr.mesh.position.y;const i=Math.atan2(e.position.x-n.x,e.position.z-n.z)+ps;for(const r of this.sceneryGroups)r.update(t,e,n,i);this.renderer.render(this.scene,e)}onResize(){this.renderer.setSize(window.innerWidth,window.innerHeight),this.renderer.setPixelRatio(window.devicePixelRatio/Tn.flatConfig.pixelScale),this.camera.onResize(),cs.hideAll()}reset(t){this.scene.clear();for(const c of this.sceneryGroups)c.clear();this.boxes.clear(),this.faces.clear(),Cr.reset(t),this.scene.add(Cr.mesh);for(const c of this.sceneryGroups){c.spawnMembers(t);for(const l of c.instancedMeshes)l.frustumCulled=!1;this.scene.add(...c.instancedMeshes)}O1(t,this.sceneryGroups),this.scene.add(...this.boxes.instancedMeshes),this.scene.add(this.faces.im),this.camera.reset(t);const[e,n,i,r,o,a]=t.bounds;for(const[c,l]of t.boxes.entries()){const[h,u,d,p,x,g]=l;this.boxes.addBox([h,o-u-x,d,p,x,g]);const m=c===t.targetBoxIndex?uf:Sa;this.boxes.setColorAt(c,m)}this.boxes.updateColors()}}const V1=2,wi=new oe,Ti=new oe,Ao=new F,cc=new F,gr=new F,td=new F,wo=new F,ed=new F,To=new F,Co=new F,yf=2,Hn=10,Sf=[],lc=20;for(let s=0;s<yf;s++)Sf.push(new _e().makeScale(lc,lc,lc));const hh=class hh extends un{constructor(){super(...arguments);U(this,"groups",[]);U(this,"t",0)}getRadiusForSolver(e){return 0}spawnMembers(e){for(let n=0;n<yf;n++){const i=la(...this.data.distance,Math.random()),r=200+Math.random()*20-10,o={speed:(Math.random()+1)*25,center:new F(0,r,0),massCenter:new F,dist:i,baseAngle:Ge*Math.floor(4*Math.random()),animOffset:xl*Math.random()};n>0&&o.baseAngle===this.groups[n-1].baseAngle&&(o.baseAngle+=Ge*Math.floor(3*Math.random())),this.pickCloudGroupCenterXZ(o,o.center),o.massCenter.copy(o.center),this.groups.push(o)}super.spawnMembers(e)}spawnMember(e,n){const i=Math.floor(e/Hn),r=this.groups[i].center,o=50+Math.random()*20,a=10+Math.random()*10;return{...n,pos:new F(r.x+o*(Math.random()-.5),r.y+o*(Math.random()-.5),r.z+o*(Math.random()-.5)),vel:new F((Math.random()-.5)*1,(Math.random()-.5)*1,(Math.random()-.5)*1),radius:a,maxOffset:-1e3}}initMember(e,n){}clear(){this.groups.length=0,super.clear()}update(e,n,i,r){super.update(e,n,i,r),e*=1,this.slideCloudGroups(e),this.twistCloudGroups(n,e),this.collideCloudGroups(e)}collideCloudGroups(e){for(const[n,i]of this.groups.entries())for(let r=1;r<Hn;r++)for(let o=0;o<r;o++){const a=this.memberData[n*Hn+r],c=this.memberData[n*Hn+o];cc.subVectors(c.pos,a.pos);const l=cc.length(),h=(a.radius+c.radius)*.7;if(l>0&&l<h*1.02){const u=cc.multiplyScalar(e*-1e-5*(h-l));a.vel.add(u),c.vel.sub(u)}}}slideCloudGroups(e){this.t+=e;for(const[n,i]of this.groups.entries())this.pickCloudGroupCenterXZ(i,i.center)}pickCloudGroupCenterXZ(e,n){const i=e.animOffset+e.speed*this.t*1e-6,r=e.baseAngle+.2*Math.sin(i),o=e.dist,a=Math.cos(r),c=Math.sin(r);return n.setX(this.centerX+o*a),n.setZ(this.centerZ+o*c),n}twistCloudGroups(e,n){const i=-1e-6*n;for(const[r,o]of this.groups.entries()){const a=o.center,c=o.massCenter;wo.subVectors(a,e.position).normalize();const l=wo,h=Hn*r;Co.set(0,0,0);let u=0;for(let x=0;x<Hn;x++){const g=this.memberData[h+x];ed.subVectors(g.pos,a),To.copy(ed).cross(l).normalize().multiplyScalar(i),To.setY(To.y*.1),g.vel.add(To),Co.add(g.pos),u++}Co.multiplyScalar(1/u),c.copy(Co);const d=this.params.faceAnchor[r],p=this.memberData[r*Hn].entranceOffset??1e7;Ao.set(c.x,c.y-p,c.z),wo.subVectors(Ao,e.position).normalize().multiplyScalar(-30),Ao.add(wo),d.setPosition(Ao)}}updateMemberData(e,n,i){const r=Math.floor(e/Hn),o=this.groups[r].center;if(td.copy(n.vel).multiplyScalar(i),n.pos.add(td),n.vel.multiplyScalar(1-5e-5*i),gr.subVectors(o,n.pos),gr.length()>10){const y=gr.normalize().multiplyScalar(1e-6*i);n.vel.add(y)}gr.set(this.centerX,n.pos.y,this.centerZ).sub(n.pos);const c=n.pos.x-this.centerX,l=n.pos.z-this.centerZ,h=Math.hypot(c,l),u=o.x-this.centerX,d=o.z-this.centerZ,p=Math.hypot(u,d),x=h-p,g=5;if(Math.abs(x)>g){const y=gr.normalize().multiplyScalar(1e-5*i*(Math.sign(x)*(Math.abs(x)-g)));n.vel.add(y)}const m=o.y-10;n.pos.y<m&&n.vel.setY(n.vel.y+1e-5*(m-n.pos.y)*i);const f=.01;n.vel.length()>f&&n.vel.normalize().multiplyScalar(f)}updateMemberGfx(e,n,i,r,o){wi.position.copy(n.pos),wi.position.y-=i,wi.scale.set(n.radius,n.radius,n.radius),wi.updateMatrix(),this.fillers.dome.setMatrixAt(e,wi.matrix);const a=n.radius+V1;wi.scale.set(a,a,a),wi.updateMatrix(),this.edges.crown.setMatrixAt(e,wi.matrix),this.edges.crown.getMatrixAt(e,Ti.matrix),Ti.matrix.decompose(Ti.position,Ti.quaternion,Ti.scale),Ti.lookAt(r.position),Ti.updateMatrix(),this.edges.crown.setMatrixAt(e,Ti.matrix)}getMembersInGroup(e){const n=e*Hn,i=n+Hn;return this.memberData.slice(n,i)}};un.register("cloud",e=>new hh(e,{faceAnchor:Sf,fillers:{dome:{geometry:new tr(1,32,16),color:yv}},edges:{crown:{geometry:new ke(.8,1,0,32,1,!0).rotateX(Ge)}}}));let nd=hh;const Ro=2,He=new oe,Ci=new oe,uh=class uh extends un{spawnMember(t,e){const n=30+20*Math.random();return{...e,radius:n,maxOffset:n+10}}getRadiusForSolver(t){return t.radius*.7}initMember(t,e){}updateMemberData(t,e,n){}updateMemberGfx(t,e,n,i,r){He.position.copy(e.pos),He.position.y-=n,He.scale.set(e.radius,e.radius,e.radius),He.updateMatrix(),this.fillers.dome.setMatrixAt(t,He.matrix),He.position.setY(Math.min(He.position.y,this.groundY)+Ro/2);const o=e.radius+Ro;He.scale.set(o,Ro,o),He.updateMatrix(),this.edges.ringTop.setMatrixAt(t,He.matrix),He.position.setY(Math.min(He.position.y,this.groundY));const a=e.radius+Ro;He.scale.set(a,a,1),He.updateMatrix(),this.edges.crown.setMatrixAt(t,He.matrix),this.edges.crown.getMatrixAt(t,Ci.matrix),Ci.matrix.decompose(Ci.position,Ci.quaternion,Ci.scale),Ci.lookAt(i.position),Ci.updateMatrix(),this.edges.crown.setMatrixAt(t,Ci.matrix),He.scale.set(a,1,a),He.updateMatrix()}};un.register("hill",t=>new uh(t,{faceAnchor:"dome",faceOffset:new F(0,.3,0),faceScale:.5,fillers:{dome:{geometry:new tr(1,32,16,0,Math.PI*2,0,Math.PI/2),color:hf}},edges:{crown:{geometry:new ke(.95,1,.05,48,1,!0,0,Math.PI).rotateX(Ge).rotateZ(Ge)},ringTop:{geometry:new ke(.95,1,0,48,1,!0)}}}));let id=uh;const sd=2,Nn=new oe,ve=new oe;new F;let Po=0;const Sl=.05,Ef=5;function _r(){const s=Po*(360/Ef)%360,t={geometry:new ke(1-Sl*(Po+1),1-Sl*Po,0,100,1,!0).rotateX(Ge).translate(0,0,10),color:new ee(`hsl(${s}, 50%, 80%)`)};return Po++,t}const k1={merged:U1({band0:_r(),band1:_r(),band2:_r(),band3:_r(),band4:_r()})},dh=class dh extends un{spawnMember(t,e){const n=100+Math.random()*150;return{...e,radius:n,maxOffset:1e3}}getRadiusForSolver(t){return 100}initMember(t,e){}updateMemberData(t,e,n){}updateMemberGfx(t,e,n,i,r){const o=this.fillers.merged;Nn.position.copy(e.pos),Nn.position.y-=n,Nn.scale.set(e.radius,e.radius,1),Nn.updateMatrix(),o.setMatrixAt(t,Nn.matrix),o.getMatrixAt(t,ve.matrix),ve.matrix.decompose(ve.position,ve.quaternion,ve.scale),ve.lookAt(i.position),ve.updateMatrix(),o.setMatrixAt(t,ve.matrix);const a=e.radius+sd;Nn.scale.set(a,a,1),Nn.updateMatrix(),this.edges.outer.setMatrixAt(t,Nn.matrix),this.edges.outer.getMatrixAt(t,ve.matrix),ve.matrix.decompose(ve.position,ve.quaternion,ve.scale),ve.lookAt(i.position),ve.updateMatrix(),this.edges.outer.setMatrixAt(t,ve.matrix);const c=e.radius*(1-Sl*Ef)-sd;Nn.scale.set(c,c,1),Nn.updateMatrix(),this.edges.inner.setMatrixAt(t,Nn.matrix),this.edges.inner.getMatrixAt(t,ve.matrix),ve.matrix.decompose(ve.position,ve.quaternion,ve.scale),ve.lookAt(i.position),ve.updateMatrix(),this.edges.inner.setMatrixAt(t,ve.matrix)}};un.register("rainbow",t=>new dh(t,{faceAnchor:"merged",faceScale:.2,faceOffset:new F(0,.85,2.1),fillers:k1,edges:{inner:{geometry:new ke(1,1.05,0,100,1,!0).rotateX(Ge)},outer:{geometry:new ke(.98,1,0,100,1,!0).rotateX(Ge)}}}));let rd=dh;new sn({map:xi,transparent:!0,opacity:.5});new sn({color:hf});new sn({color:lf});const od=.05,G1=.005,H1=1e-5,W1={value:.0025},Qo={value:.05},El={value:0};function X1(s){El.value+=s*G1*(.2+.4*Math.sin(El.value*1e-4)),Qo.value<od&&(Qo.value=Math.min(od,Qo.value+s*H1))}function q1(s){s.uniforms.uTime=El,s.uniforms.uGlobalFreq=W1,s.uniforms.uGlobalAmp=Qo,s.vertexShader=`
  uniform float uTime;
  uniform float uGlobalFreq;
  uniform float uGlobalAmp;
  attribute float instanceOffset; // per-hill random phase
  attribute float subCount; // number of meshes per instanceOffset
  ${s.vertexShader}
  `.replace("#include <begin_vertex>",`
        // Cartoonish jello hose wave: spine anchored at bottom, top moves most.
        vec3 transformed = vec3(position);

        #ifdef USE_INSTANCING
          mat4 worldMat = modelMatrix * instanceMatrix;
        #else
          mat4 worldMat = modelMatrix;
        #endif

        vec3 worldPos = (worldMat * vec4(transformed, 1.0)).xyz;

        // Per-axis scale so deformation magnitude is scale-invariant.
        vec3 scaleVec = vec3(
          length(worldMat[0].xyz),
          length(worldMat[1].xyz),
          length(worldMat[2].xyz)
        );

        float t = uTime + instanceOffset; // Time driver with unique per-hill phase
        float freq = uGlobalFreq;    // Spatial frequency along height
        float baseAmp = uGlobalAmp;  // Overall amplitude control

        // Height factor: bottom (y≈0) almost rigid; top flexes fully.
        float hFactor = clamp(worldPos.y * 0.08, 0.0, 1.0);
        hFactor = smoothstep(0.0, 1.0, hFactor);

        // Bending angle of vertical spine (hose) depending on height & time.
        float bend = sin(t * 0.8 + worldPos.y * freq) * baseAmp * hFactor;

        // Side-to-side displacement proportional to height (rotation around spine).
        float lateralX = bend * worldPos.y;

        // Light jello wobble in Z for extra cartoon feel.
        float lateralZ = 0.35 * bend * worldPos.y + 0.08 * sin(worldPos.y * freq * 1.7 + t * 1.3);

        // Vertical offset: when leaning sideways, top shifts up/down preserving length illusion.
        float verticalOffset = -0.15 * abs(bend) * worldPos.y + 0.05 * sin(worldPos.y * freq * 1.2 + t * 2.0);

        vec3 offset = vec3(lateralX, verticalOffset, lateralZ);

        // Map world-space offset back into the mesh's local space taking rotation into account.
        // Using the normalized world axes (columns of worldMat) as a basis allows consistent
        // deformation even when instances have different rotations.
        vec3 axisX = normalize(worldMat[0].xyz);
        vec3 axisY = normalize(worldMat[1].xyz);
        vec3 axisZ = normalize(worldMat[2].xyz);

        vec3 localOffset;
        localOffset.x = dot(offset, axisX) / scaleVec.x; // project onto local X then remove scale
        localOffset.y = dot(offset, axisY) / scaleVec.y; // project onto local Y then remove scale
        localOffset.z = dot(offset, axisZ) / scaleVec.z; // project onto local Z then remove scale

        transformed += localOffset;
      `)}const vr=2,ad=20,Be=new oe,We=new oe,hc=new F,fh=class fh extends un{constructor(){super(...arguments);U(this,"distinctSubCounts",[]);U(this,"instanceOffsetAttrs",{});U(this,"initShader",e=>{q1(e)})}init(){super.init();const e=[...new Set([...this.faces?[1]:[],...Object.values(this.params.fillers).map(n=>n.count??1),...Object.values(this.params.edges).map(n=>n.count??1)])].sort();this.distinctSubCounts=e,this.instanceOffsetAttrs={};for(const n of e){const i=this.data.maxCount*n,r=new Float32Array(i);this.instanceOffsetAttrs[n]=new Hr(r,1)}this.forEachIm((n,i)=>{n.geometry.setAttribute("instanceOffset",this.instanceOffsetAttrs[i])})}updateInstanceOffset(e,n){for(const i of this.distinctSubCounts){const r=this.instanceOffsetAttrs[i];for(let o=0;o<i;o++)r.set([e.instanceOffset],n*i+o);r.needsUpdate=!0}}spawnMember(e,n){let i;Math.random()<.9?i=50+Math.random()*50:i=100+Math.random()*150;const r=10+5*Math.floor(Math.random()*2)*i/200;return n.pos.setY(i),{...n,radius:r,instanceOffset:Math.random()*Math.PI*2,maxOffset:i+r+10}}getRadiusForSolver(e){return e.radius*4}updateMemberData(e,n,i){}updateMemberGfx(e,n,i,r,o){const a=n.pos.y;hc.copy(r.position),this.updateInstanceOffset(n,e);const{tube:c,dome:l}=this.fillers,{crown:h,ring:u,plate:d}=this.edges;Be.position.set(n.pos.x,a/2-i-ad,n.pos.z),Be.scale.set(n.radius,a,n.radius),Be.updateMatrix(),c.setMatrixAt(e,Be.matrix);const p=n.radius+vr;Be.scale.set(2*p,a+2*vr,2*p),Be.updateMatrix(),d.setMatrixAt(e,Be.matrix);const x=n.pos.y-i-ad;Be.position.set(n.pos.x,x,n.pos.z),Be.scale.set(n.radius,n.radius,n.radius),Be.updateMatrix(),l.setMatrixAt(e,Be.matrix);const g=n.radius+vr;Be.scale.set(g,g,g),Be.updateMatrix(),h.setMatrixAt(e,Be.matrix),Be.position.setY(Math.min(x,this.groundY+vr/2)),Be.scale.setY(1),Be.updateMatrix(),u.setMatrixAt(e,Be.matrix),h.getMatrixAt(e,We.matrix),We.matrix.decompose(We.position,We.quaternion,We.scale),We.lookAt(r.position),We.updateMatrix(),h.setMatrixAt(e,We.matrix),d.getMatrixAt(e,We.matrix),We.matrix.decompose(We.position,We.quaternion,We.scale),hc.set(r.position.x,We.position.y,r.position.z),We.lookAt(hc),We.updateMatrix(),d.setMatrixAt(e,We.matrix)}initMember(e,n){}};un.register("stalk",e=>new fh(e,{faceAnchor:"tube",faceScale:1.7,faceOffset:new F(0,0,.1),fillers:{dome:{geometry:new tr(1,32,16,0,Math.PI*2,0,Math.PI/2),color:ca},tube:{geometry:new ke(1,1,1,32,32),color:ca}},edges:{crown:{geometry:new ke(.8,1,0,48,1,!0,0,Math.PI).rotateX(Ge).rotateZ(Ge)},plate:{geometry:new Hi(1,1,2,32)},ring:{geometry:new ke(1,1,vr)}}}));let cd=fh;const Y1=2,Ri=new oe,Ke=new oe;new F;const ph=class ph extends un{spawnMember(t,e){return e.pos.setY(250),{...e,radius:50,maxOffset:-1e3}}getRadiusForSolver(t){return t.radius}initMember(t,e){}updateMemberData(t,e,n){}updateMemberGfx(t,e,n,i,r){Ri.position.copy(e.pos),Ri.position.y-=n,Ri.scale.set(e.radius,e.radius,e.radius),Ri.updateMatrix(),this.fillers.dome.setMatrixAt(t,Ri.matrix),this.fillers.dome.getMatrixAt(t,Ke.matrix),Ke.matrix.decompose(Ke.position,Ke.quaternion,Ke.scale),Ke.lookAt(i.position),Ke.updateMatrix(),this.fillers.dome.setMatrixAt(t,Ke.matrix);const o=e.radius+Y1;Ri.scale.set(o,o,o),Ri.updateMatrix(),this.edges.crown.setMatrixAt(t,Ri.matrix),this.edges.crown.getMatrixAt(t,Ke.matrix),Ke.matrix.decompose(Ke.position,Ke.quaternion,Ke.scale),Ke.lookAt(i.position),Ke.updateMatrix(),this.edges.crown.setMatrixAt(t,Ke.matrix)}};un.register("sun",t=>new ph(t,{faceScale:.5,faceAnchor:"dome",fillers:{dome:{geometry:new ql,color:Sv}},edges:{crown:{geometry:new ke(.95,1,0,100,1,!0).rotateX(Ge)}}}));let ld=ph;const br=2,hd=20,ze=new oe,Xe=new oe,uc=new F,mh=class mh extends un{getRadiusForSolver(t){return t.radius*1.1}spawnMember(t,e){e.pos.setY(100+Math.random()*100);const n=30+20*Math.random();return{...e,radius:n,maxOffset:e.pos.y+n+10}}initMember(t,e){}updateMemberData(t,e,n){}updateMemberGfx(t,e,n,i,r){const o=e.pos.y;uc.copy(i.position);const{tube:a,dome:c}=this.fillers,{crown:l,ring:h,plate:u}=this.edges;ze.position.set(e.pos.x,o/2-n-hd,e.pos.z),ze.scale.set(e.radius,o,e.radius),ze.updateMatrix(),a.setMatrixAt(t,ze.matrix);const d=e.radius+br;ze.scale.set(2*d,o+2*br,2*d),ze.updateMatrix(),u.setMatrixAt(t,ze.matrix);const p=e.pos.y-n-hd;ze.position.set(e.pos.x,p,e.pos.z),ze.scale.set(e.radius,e.radius,e.radius),ze.updateMatrix(),c.setMatrixAt(t,ze.matrix);const x=e.radius+br;ze.scale.set(x,x,x),ze.updateMatrix(),l.setMatrixAt(t,ze.matrix),ze.position.setY(Math.min(p,this.groundY+br/2)),ze.scale.setY(1),ze.updateMatrix(),h.setMatrixAt(t,ze.matrix),l.getMatrixAt(t,Xe.matrix),Xe.matrix.decompose(Xe.position,Xe.quaternion,Xe.scale),Xe.lookAt(i.position),Xe.updateMatrix(),l.setMatrixAt(t,Xe.matrix),u.getMatrixAt(t,Xe.matrix),Xe.matrix.decompose(Xe.position,Xe.quaternion,Xe.scale),uc.set(i.position.x,Xe.position.y,i.position.z),Xe.lookAt(uc),Xe.updateMatrix(),u.setMatrixAt(t,Xe.matrix)}};un.register("tall-hill",t=>new mh(t,{faceAnchor:"tube",faceScale:.5,fillers:{dome:{geometry:new tr(1,32,16,0,Math.PI*2,0,Math.PI/2),color:ca},tube:{geometry:new ke(1,1,1,32,1),color:ca}},edges:{crown:{geometry:new ke(.8,1,0,48,1,!0,0,Math.PI).rotateX(Ge).rotateZ(Ge)},plate:{geometry:new Hi(1,1,1,1)},ring:{geometry:new ke(1,1,br)}}}));let ud=mh;function $1(){return new Kn({side:nn,depthTest:!0,depthWrite:!1,uniforms:{skyColor:{value:[.12,.15,.45]},noiseOffset:{value:new zt(0,0)},resolution:{value:new zt(1,1)},noiseScale:{value:2.5},noiseStrength:{value:.2},noiseExtra:{value:new zt(0,0)},posterizeLevels:{value:6}},vertexShader:`
      void main() {
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,fragmentShader:`
      precision highp float;
      uniform vec2 resolution;
      uniform vec2 noiseOffset;
      uniform vec2 noiseExtra; // two additional dimensions to morph noise
      uniform vec3 skyColor;
      uniform float noiseScale;
      uniform float noiseStrength;
      uniform float posterizeLevels;

      // Scalar hash: maps a 2D point to a repeatable pseudo-random float in [-1,1].
      float hash2(vec2 p) {
        return -1.0 + 2.0 * fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
      }

      // 4D hash in [-1,1]
      float hash4(vec4 p) {
        return -1.0 + 2.0 * fract(sin(dot(p, vec4(127.1, 311.7, 74.7, 192.5))) * 43758.5453123);
      }

      // Classic value noise in 4D with smoothstep-like fade (same as 2D but extended).
      float noise4(vec4 p) {
        vec4 i = floor(p);
        vec4 f = fract(p);
        vec4 u = f * f * (3.0 - 2.0 * f);

        // Mix along x for all 8 yz w corners
        float n0000 = mix(hash4(i + vec4(0.0,0.0,0.0,0.0)), hash4(i + vec4(1.0,0.0,0.0,0.0)), u.x);
        float n0100 = mix(hash4(i + vec4(0.0,1.0,0.0,0.0)), hash4(i + vec4(1.0,1.0,0.0,0.0)), u.x);
        float n0010 = mix(hash4(i + vec4(0.0,0.0,1.0,0.0)), hash4(i + vec4(1.0,0.0,1.0,0.0)), u.x);
        float n0110 = mix(hash4(i + vec4(0.0,1.0,1.0,0.0)), hash4(i + vec4(1.0,1.0,1.0,0.0)), u.x);
        float n0001 = mix(hash4(i + vec4(0.0,0.0,0.0,1.0)), hash4(i + vec4(1.0,0.0,0.0,1.0)), u.x);
        float n0101 = mix(hash4(i + vec4(0.0,1.0,0.0,1.0)), hash4(i + vec4(1.0,1.0,0.0,1.0)), u.x);
        float n0011 = mix(hash4(i + vec4(0.0,0.0,1.0,1.0)), hash4(i + vec4(1.0,0.0,1.0,1.0)), u.x);
        float n0111 = mix(hash4(i + vec4(0.0,1.0,1.0,1.0)), hash4(i + vec4(1.0,1.0,1.0,1.0)), u.x);

        // Mix along y
        float ny000 = mix(n0000, n0100, u.y);
        float ny010 = mix(n0010, n0110, u.y);
        float ny001 = mix(n0001, n0101, u.y);
        float ny011 = mix(n0011, n0111, u.y);

        // Mix along z
        float nz00 = mix(ny000, ny010, u.z);
        float nz01 = mix(ny001, ny011, u.z);

        // Mix along w
        return mix(nz00, nz01, u.w);
      }

      void main() {
        vec2 uv = gl_FragCoord.xy / resolution.xy; // 0..1
        // Compose 4D point: visible (x,y) plus hidden (z,w) drives morphology.
        vec4 p4 = vec4(uv * noiseScale, noiseExtra.x, noiseExtra.y);
        float n = noise4(p4) * 0.5 + 0.5; // 0..1 smooth
        vec3 color = skyColor + (n - 0.5) * noiseStrength; // subtle variation around base
        color = clamp(color, 0.0, 1.0);
        // Posterize per channel
        float levels = max(2.0, posterizeLevels);
        color = floor(color * levels) / levels;
        gl_FragColor = vec4(color, 1.0);
      }
    `})}const K1=$1(),Z1=new ki(1e3,1e3,1e3),j1=new hn(Z1,K1);j1.renderOrder=-1;new Path2D(`
    
    M224 32c-17.7 0-32 14.3-32 32L96 64C78.3 64 64 78.3 64 96s14.3 32 32 32l96 0 0 
    64-18.7 0c-8.5 0-16.6 3.4-22.6 9.4L128 224 32 224c-17.7 0-32 14.3-32 32l0 64c0 
    17.7 14.3 32 32 32l100.1 0c20.2 29 53.9 48 91.9 48s71.7-19 91.9-48l36.1 0c17.7 
    0 32 14.3 32 32s14.3 32 32 32l64 0c17.7 0 32-14.3 32-32 0-88.4-71.6-160-160-160l-32 
    0-22.6-22.6c-6-6-14.1-9.4-22.6-9.4l-18.7 0 0-64 96 0c17.7 0 32-14.3 
    32-32s-14.3-32-32-32l-96 0c0-17.7-14.3-32-32-32zM436.8 455.4l-18.2 42.4c-1.8 
    4.1-2.7 8.6-2.7 13.1l0 1.2c0 17.7 14.3 32 32 
    32s32-14.3 32-32l0-1.2c0-4.5-.9-8.9-2.7-13.1l-18.2-42.4c-1.9-4.5-6.3-7.4-11.2-7.4s-9.2 2.9-11.2 7.4z
    
    
    `),new Path2D(`

    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 168.3C277.6
     109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 259.3 530.7 184.3 
     455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 412.9C98.8 422.4 94.4 
     442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 501C601 401 601 239 501
      139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 78.8 65.8C69.8 69.5 64 78.3 
      64 88L64 232C64 245.3 74.7 256 88 256z
  
  
      `),new Path2D(`

    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 168.3C362.4
     109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 380.7 530.7 455.7
      455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 421.7C536.7 431.8 540.2
       451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 139 501C39.1 401 39 239 139 
       139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 62.1 561.2 65.8C570.2 69.5 576 
       78.3 576 88L576 232C576 245.3 565.3 256 552 256z

  
      `),new Path2D(`


    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z

  
  
      `),new Path2D(`
    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 
    168.3C277.6 109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 
    259.3 530.7 184.3 455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 
    412.9C98.8 422.4 94.4 442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 
    501C601 401 601 239 501 139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 
    78.8 65.8C69.8 69.5 64 78.3 64 88L64 232C64 245.3 74.7 256 88 256z
  `),new Path2D(`
    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z
  `),new Path2D(`
    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 
    168.3C362.4 109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 
    380.7 530.7 455.7 455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 
    421.7C536.7 431.8 540.2 451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 
    139 501C39.1 401 39 239 139 139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 
    62.1 561.2 65.8C570.2 69.5 576 78.3 576 88L576 232C576 245.3 565.3 256 552 256z
  `),new Path2D(`
        M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 
        550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 
        85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320
        480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 
        288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 
        257.7C352.5 239.5 338.1 224 319.8 224z
    `),new Path2D(`
        M480 96C515.3 96 544 124.7 544 160L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 
        515.3 96 480L96 160C96 124.7 124.7 96 160 96L480 96zM438 209.7C427.3 201.9 412.3 204.3 404.5 
        215L285.1 379.2L233 327.1C223.6 317.7 208.4 317.7 199.1 327.1C189.8 336.5 189.7 351.7 199.1 
        361L271.1 433C276.1 438 283 440.5 289.9 440C296.8 439.5 303.3 435.9 307.4 430.2L443.3 243.2C451.1 
        232.5 448.7 217.5 438 209.7z
    `),new Path2D(`

      M259.1 73.5C262.1 58.7 275.2 48 290.4 48L350.2 48C365.4 48 378.5 58.7 381.5 73.5L396 143.5C410.1
       149.5 423.3 157.2 435.3 166.3L503.1 143.8C517.5 139 533.3 145 540.9 158.2L570.8 210C578.4 223.2
        575.7 239.8 564.3 249.9L511 297.3C511.9 304.7 512.3 312.3 512.3 320C512.3 327.7 511.8 335.3 511
         342.7L564.4 390.2C575.8 400.3 578.4 417 570.9 430.1L541 481.9C533.4 495 517.6 501.1 503.2 
         496.3L435.4 473.8C423.3 482.9 410.1 490.5 396.1 496.6L381.7 566.5C378.6 581.4 365.5 592 350.4
          592L290.6 592C275.4 592 262.3 581.3 259.3 566.5L244.9 496.6C230.8 490.6 217.7 482.9 205.6
           473.8L137.5 496.3C123.1 501.1 107.3 495.1 99.7 481.9L69.8 430.1C62.2 416.9 64.9 400.3 76.3
            390.2L129.7 342.7C128.8 335.3 128.4 327.7 128.4 320C128.4 312.3 128.9 304.7 129.7 297.3L76.3
             249.8C64.9 239.7 62.3 223 69.8 209.9L99.7 158.1C107.3 144.9 123.1 138.9 137.5 143.7L205.3 
             166.2C217.4 157.1 230.6 149.5 244.6 143.4L259.1 73.5zM320.3 400C364.5 399.8 400.2 363.9 400
              319.7C399.8 275.5 363.9 239.8 319.7 240C275.5 240.2 239.8 276.1 240 320.3C240.2 364.5 276.1
               400.2 320.3 400z

      
    `),new Path2D(`


      M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 
      160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 
      48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576
       197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z
      
    `),new Path2D(`

      M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 
      224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4
       106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 
       379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 
       95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 
       302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 
       192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576
        337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 
        448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 
        440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 
        440 128 440z

      
    `),new Path2D(`

      M504.6 148.5C515.9 134.9 514.1 114.7 500.5 103.4C486.9 92.1 466.7 93.9 455.4 107.5L320 270L184.6
       107.5C173.3 93.9 153.1 92.1 139.5 103.4C125.9 114.7 124.1 134.9 135.4 148.5L278.3 320L135.4
        491.5C124.1 505.1 125.9 525.3 139.5 536.6C153.1 547.9 173.3 546.1 184.6 532.5L320 370L455.4
         532.5C466.7 546.1 486.9 547.9 500.5 536.6C514.1 525.3 515.9 505.1 504.6 491.5L361.7 320L504.6 148.5z

      
    `),new Path2D(`


      M173.3 66.5C181.4 62.4 191.2 63.3 198.4 68.8L518.4 308.7C526.7 314.9 530 325.7 
      526.8 335.5C523.6 345.3 514.4 351.9 504 351.9L351.7 351.9L440.6 529.6C448.5
       545.4 442.1 564.6 426.3 572.5C410.5 580.4 391.3 574 383.4 558.2L294.5 380.5L203.2 
       502.3C197 510.6 186.2 513.9 176.4 510.7C166.6 507.5 160 498.3 160 488L160
        88C160 78.9 165.1 70.6 173.3 66.5z
      
    `);const J1={screen:{},_outerMargin:{parent:"screen",margin:()=>Re.flatConfig.outerMargin},topLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight},bottomLabel:{parent:"_outerMargin",height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},saveButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,bottom:0},addButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:0,bottom:0},removeButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,right:0,top:0},setTargetButton:{parent:"_outerMargin",width:()=>Re.flatConfig.buttonWidth,height:()=>Re.flatConfig.buttonHeight,left:"auto",top:0}},Q1={layoutKey:"topLabel",display:{type:"panel",label:"Edit Tower",textAlign:"left",styles:{border:"none"}}},tb={layoutKey:"addButton",display:{type:"button",label:"Add Block"},click:({towerToppler:s})=>{s.editorAddClicked()}},eb={layoutKey:"setTargetButton",display:{type:"button",label:"Set Block"},click:({towerToppler:s})=>{s.editorSetTargetClicked()}},Af={layoutKey:"removeButton",display:{type:"button",label:"Remove Block"},click:({towerToppler:s})=>{s.editorRemoveClicked()}},nb={layoutKey:"saveButton",display:{type:"button",label:"Save Level"},click:({towerToppler:s})=>{s.editorSaveClicked()}},xh=class xh extends xn{};xn.register("editor-gui",{factory:()=>new xh,layoutFactory:()=>J1,elements:[Q1,eb,tb,Af,nb]});let dd=xh;class ib extends xn{constructor(){super(...arguments);U(this,"_isShowing",!1)}get isShowing(){return this._isShowing}toggle(e,n){typeof n=="boolean"?this._isShowing=n:this._isShowing=!this._isShowing;for(const i in this.elements)this._isShowing?(this.elements[i].display.classes??[]).includes("hidden")||us(i):Fi(i);this._isShowing&&this.refreshLayout(e),this.onToggle(e)}}const dc={NAMES:["playing-gui","editor-gui"]},Ce=10;function Lo(s,t){return new sb(s,t).getSideView()}class sb{constructor(t,e){this.level=t,this.dir=e}getSideView(){const{level:t,dir:e}=this,n=e==="N"||e==="S"?2:0,i=e==="N"||e==="S"?0:2,r=1,o=e==="N"||e==="S"?3:5,a=4,c=e==="S"||e==="W",l=t.boxes.map((_,M)=>({box:_,i:M})).sort((_,M)=>{const T=_.box[n],P=M.box[n];return c?T-P:P-T});let h=Number.MAX_VALUE,u=-Number.MAX_VALUE,d=Number.MAX_VALUE,p=-Number.MAX_VALUE;for(const _ of t.boxes)h=Math.min(h,_[i]),u=Math.max(u,_[i]+_[o]),d=Math.min(d,_[r]),p=Math.max(p,_[r]+_[a]);const x=Math.floor(h/Ce)*Ce+Ce/2,g=Math.ceil(u/Ce)*Ce-Ce/2,m=Math.floor(d/Ce)*Ce+Ce/2,f=Math.ceil(p/Ce)*Ce-Ce/2,y=new Map,v=new Set;for(let _=x;_<=g;_+=Ce)for(let M=m;M<=f;M+=Ce)for(const{box:T,i:P}of l){const A=T[i],E=A+T[o],R=T[r],I=R+T[a];if(_>=A&&_<=E&&M>=R&&M<=I){v.add(P);let z=y.get(P);z||(z=new Set,y.set(P,z));const X=Math.round((_-Ce/2)/Ce),H=Math.round((M-Ce/2)/Ce);z.add(`${X}|${H}`);break}}const b={};for(const _ of v){const M=y.get(_);if(!M||M.size===0)continue;const T=ob(M);b[_]=T.map(P=>({rawRect:P,worldRect:rb(P,this.level,this.dir)}))}return b}}function rb(s,t,e){const[n,i,r,o]=s,[a,c,l,h,u,d]=t.bounds;let p;e==="N"?p=n-h/2:e==="S"?p=h-n-r-h/2:e==="W"?p=n-d/2:p=d-n-r-d/2;const x=-u/2,g=i+x;return[p,g,r,o]}function ob(s){const t=new Set,e=[],n=[[1,0],[-1,0],[0,1],[0,-1]];function i(r){const o=[r];t.add(r);let a=Number.MAX_VALUE,c=-Number.MAX_VALUE,l=Number.MAX_VALUE,h=-Number.MAX_VALUE;for(;o.length>0;){const f=o.shift(),[y,v]=f.split("|"),b=parseInt(y,10),_=parseInt(v,10);a=Math.min(a,b),c=Math.max(c,b),l=Math.min(l,_),h=Math.max(h,_);for(const[M,T]of n){const P=`${b+M}|${_+T}`;s.has(P)&&!t.has(P)&&(t.add(P),o.push(P))}}const u=a*Ce,d=(c+1)*Ce,p=l*Ce,x=(h+1)*Ce,g=d-u,m=x-p;return[u,p,g,m]}for(const r of s)t.has(r)||e.push(i(r));return e}function ab(s){const t={N:Lo(s,"N"),S:Lo(s,"S"),E:Lo(s,"E"),W:Lo(s,"W")};return{bounds:s.bounds,boxes:s.boxes,targetBoxIndex:s.targetBoxIndex,sideViews:t}}function cb(s,t,e){const n=s.boxes[t];return e==="N"||e==="S"?{width:n[3],height:n[4]}:{width:n[5],height:n[4]}}function lb(s,t,e){const n=s.boxes[t],[i,r,o,a,c,l]=s.bounds,h=n[1]+n[4]/2-c/2;return e==="N"?[n[0]+n[3]/2-a/2,h]:e==="S"?[a-(n[0]+n[3]/2)-a/2,h]:e==="W"?[n[2]+n[5]/2-l/2,h]:[l-(n[2]+n[5]/2)-l/2,h]}function hb(s,t,e,n){const[i,r,o,a,c,l]=s.bounds,h=s.sideViews[n][t][e].worldRect,u=h[0]+h[2]/2,d=h[1]+h[3]/2;return[u+a/2,d+c/2]}const Aa=typeof P2_ARRAY_TYPE<"u"?P2_ARRAY_TYPE:typeof Float32Array<"u"?Float32Array:Array,ta=(s,t)=>{for(let e=0,n=t.length;e!==n;++e)s.push(t[e])},ub=function(s,t,e){e===void 0&&(e=1);const n=s.length-e;for(let i=t;i<n;i++)s[i]=s[i+e];s.length=n},Do=(s,t)=>{const e=s.indexOf(t);e!==-1&&ub(s,e,1)};function Zn(s,t){return s[0]*t[1]-s[1]*t[0]}function Al(s,t,e){return Ve(s,t,-Math.PI/2),It(s,s,e),s}function Ve(s,t,e){if(e!==0){const n=Math.cos(e),i=Math.sin(e),r=t[0],o=t[1];s[0]=n*r-i*o,s[1]=i*r+n*o}else s[0]=t[0],s[1]=t[1];return s}function rs(s,t){const e=t[0],n=t[1];return s[0]=n,s[1]=-e,s}function Gi(s,t,e,n){const i=Math.cos(-n),r=Math.sin(-n),o=t[0]-e[0],a=t[1]-e[1];return s[0]=i*o-r*a,s[1]=r*o+i*a,s}function Ae(s,t,e,n){const i=Math.cos(n),r=Math.sin(n),o=t[0],a=t[1],c=e[0],l=e[1];s[0]=i*o-r*a+c,s[1]=r*o+i*a+l}function wf(s,t,e){const n=Math.cos(-e),i=Math.sin(-e),r=t[0],o=t[1];return s[0]=n*r-i*o,s[1]=i*r+n*o,s}const db=Ve;function fb(s,t,e,n){return _t(s,t,e),_t(s,s,n),It(s,s,1/3),s}function N(){const s=new Aa(2);return s[0]=0,s[1]=0,s}function An(s){const t=new Aa(2);return t[0]=s[0],t[1]=s[1],t}function ln(s,t){const e=new Aa(2);return e[0]=s,e[1]=t,e}function $t(s,t){return s[0]=t[0],s[1]=t[1],s}function Kt(s,t,e){return s[0]=t,s[1]=e,s}function _t(s,t,e){return s[0]=t[0]+e[0],s[1]=t[1]+e[1],s}function nt(s,t,e){return s[0]=t[0]-e[0],s[1]=t[1]-e[1],s}function fa(s,t,e){return s[0]=t[0]*e[0],s[1]=t[1]*e[1],s}function It(s,t,e){return s[0]=t[0]*e,s[1]=t[1]*e,s}function Jl(s,t){const e=t[0]-s[0],n=t[1]-s[1];return Math.sqrt(e*e+n*n)}function Ql(s,t){const e=t[0]-s[0],n=t[1]-s[1];return e*e+n*n}function Xr(s){const t=s[0],e=s[1];return Math.sqrt(t*t+e*e)}function Cn(s){const t=s[0],e=s[1];return t*t+e*e}function be(s,t){const e=t[0],n=t[1];let i=e*e+n*n;return i>0&&(i=1/Math.sqrt(i),s[0]=t[0]*i,s[1]=t[1]*i),s}function ae(s,t){return s[0]*t[0]+s[1]*t[1]}function Dr(s,t,e,n){const i=t[0],r=t[1];return s[0]=i+n*(e[0]-i),s[1]=r+n*(e[1]-r),s}function pb(s,t,e,n){const i=t[0]-s[0],r=t[1]-s[1],o=n[0]-e[0],a=n[1]-e[1],c=(-r*(s[0]-e[0])+i*(s[1]-e[1]))/(-o*r+i*a),l=(o*(s[1]-e[1])-a*(s[0]-e[0]))/(-o*r+i*a);return c>=0&&c<=1&&l>=0&&l<=1?l:-1}class th{constructor(t){t===void 0&&(t={}),this.lowerBound=t.lowerBound?An(t.lowerBound):N(),this.upperBound=t.upperBound?An(t.upperBound):N()}setFromPoints(t,e,n,i){n===void 0&&(n=0),i===void 0&&(i=0);const r=this.lowerBound,o=this.upperBound;n!==0?Ve(r,t[0],n):$t(r,t[0]),$t(o,r);const a=Math.cos(n),c=Math.sin(n);for(let l=1;l<t.length;l++){let h=t[l];if(n!==0){const u=h[0],d=h[1];fc[0]=a*u-c*d,fc[1]=c*u+a*d,h=fc}for(let u=0;u<2;u++)h[u]>o[u]&&(o[u]=h[u]),h[u]<r[u]&&(r[u]=h[u])}e&&(_t(r,r,e),_t(o,o,e)),i&&(r[0]-=i,r[1]-=i,o[0]+=i,o[1]+=i)}copy(t){$t(this.lowerBound,t.lowerBound),$t(this.upperBound,t.upperBound)}extend(t){const e=this.lowerBound,n=this.upperBound;let i=2;for(;i--;){const r=t.lowerBound[i];e[i]>r&&(e[i]=r);const o=t.upperBound[i];n[i]<o&&(n[i]=o)}}overlaps(t){const e=this.lowerBound,n=this.upperBound,i=t.lowerBound,r=t.upperBound;return(i[0]<=n[0]&&n[0]<=r[0]||e[0]<=r[0]&&r[0]<=n[0])&&(i[1]<=n[1]&&n[1]<=r[1]||e[1]<=r[1]&&r[1]<=n[1])}containsPoint(t){const e=this.lowerBound,n=this.upperBound;return e[0]<=t[0]&&t[0]<=n[0]&&e[1]<=t[1]&&t[1]<=n[1]}overlapsRay(t){const e=1/t.direction[0],n=1/t.direction[1],i=t.from,r=this.lowerBound,o=this.upperBound,a=(r[0]-i[0])*e,c=(o[0]-i[0])*e,l=(r[1]-i[1])*n,h=(o[1]-i[1])*n,u=Math.max(Math.max(Math.min(a,c),Math.min(l,h))),d=Math.min(Math.min(Math.max(a,c),Math.max(l,h)));return d<0||u>d?-1:u/t.length}}const fc=N(),mb=[0,0],xb=[0,0],gb=[[0,0],[0,0]],_b=[[0,0],[0,0]];function vb(s,t,e){e===void 0&&(e=0),e=e||0;const n=[0,0],i=s[1][1]-s[0][1],r=s[0][0]-s[1][0],o=i*s[0][0]+r*s[0][1],a=t[1][1]-t[0][1],c=t[0][0]-t[1][0],l=a*t[0][0]+c*t[0][1],h=i*c-a*r;return Pf(h,0,e)||(n[0]=(c*o-r*l)/h,n[1]=(i*l-a*o)/h),n}function wl(s,t,e,n){const i=t[0]-s[0],r=t[1]-s[1],o=n[0]-e[0],a=n[1]-e[1];if(o*r-a*i===0)return!1;const c=(i*(e[1]-s[1])+r*(s[0]-e[0]))/(o*r-a*i),l=(o*(s[1]-e[1])+a*(e[0]-s[0]))/(a*i-o*r);return c>=0&&c<=1&&l>=0&&l<=1}function Zr(s,t,e){return(t[0]-s[0])*(e[1]-s[1])-(e[0]-s[0])*(t[1]-s[1])}function ea(s,t,e){return Zr(s,t,e)>0}function Tl(s,t,e){return Zr(s,t,e)>=0}function Tf(s,t,e){return Zr(s,t,e)<0}function Ir(s,t,e){return Zr(s,t,e)<=0}function bb(s,t,e,n){if(n===void 0&&(n=0),n){const i=mb,r=xb;i[0]=t[0]-s[0],i[1]=t[1]-s[1],r[0]=e[0]-t[0],r[1]=e[1]-t[1];const o=i[0]*r[0]+i[1]*r[1],a=Math.sqrt(i[0]*i[0]+i[1]*i[1]),c=Math.sqrt(r[0]*r[0]+r[1]*r[1]);return Math.acos(o/(a*c))<n}else return Zr(s,t,e)===0}function Ur(s,t){const e=t[0]-s[0],n=t[1]-s[1];return e*e+n*n}function mt(s,t){const e=s.length;return s[t<0?t%e+e:t%e]}function Mb(s){s.length=0}function Mn(s,t,e,n){for(let i=e;i<n;i++)s.push(t[i])}function yb(s){let t=0;const e=s;for(let n=1;n<s.length;++n)(e[n][1]<e[t][1]||e[n][1]===e[t][1]&&e[n][0]>e[t][0])&&(t=n);return ea(mt(s,t-1),mt(s,t),mt(s,t+1))?!1:(Sb(s),!0)}function Sb(s){const t=[],e=s.length;for(let n=0;n!==e;n++)t.push(s.pop());for(let n=0;n!==e;n++)s[n]=t[n]}function Cf(s,t){return Tf(mt(s,t-1),mt(s,t),mt(s,t+1))}function Eb(s,t,e){const n=gb,i=_b;if(Tl(mt(s,t+1),mt(s,t),mt(s,e))&&Ir(mt(s,t-1),mt(s,t),mt(s,e)))return!1;const r=Ur(mt(s,t),mt(s,e));for(let o=0;o!==s.length;++o)if(!((o+1)%s.length===t||o===t)&&Tl(mt(s,t),mt(s,e),mt(s,o+1))&&Ir(mt(s,t),mt(s,e),mt(s,o))){n[0]=mt(s,t),n[1]=mt(s,e),i[0]=mt(s,o),i[1]=mt(s,o+1);const a=vb(n,i);if(Ur(mt(s,t),a)<r)return!1}return!0}function Ab(s,t,e){for(let n=0;n!==s.length;++n)if(!(n===t||n===e||(n+1)%s.length===t||(n+1)%s.length===e)&&wl(mt(s,t),mt(s,e),mt(s,n),mt(s,n+1)))return!1;return!0}function pa(s,t,e,n){if(n===void 0&&(n=[]),Mb(n),t<e)for(let i=t;i<=e;i++)n.push(s[i]);else{for(let i=0;i<=e;i++)n.push(s[i]);for(let i=t;i<s.length;i++)n.push(s[i])}return n}function Cl(s){let t=[],e,n;const i=[];let r=Number.MAX_VALUE;for(let o=0;o<s.length;++o)if(Cf(s,o)){for(let a=0;a<s.length;++a)if(Eb(s,o,a)){e=Cl(pa(s,o,a,i)),n=Cl(pa(s,a,o,i));for(let c=0;c<n.length;c++)e.push(n[c]);e.length<r&&(t=e,r=e.length,t.push([mt(s,o),mt(s,a)]))}}return t}function wb(s){const t=Cl(s);return t.length>0?Rf(s,t):[s]}function Rf(s,t){if(t.length===0)return[s];if(t instanceof Array&&t.length&&t[0]instanceof Array&&t[0].length===2&&t[0][0]instanceof Array){const e=[s];for(let n=0;n<t.length;n++){const i=t[n];for(let r=0;r<e.length;r++){const o=e[r],a=Rf(o,i);if(a){e.splice(r,1),e.push(a[0],a[1]);break}}}return e}else{const e=t,n=s.indexOf(e[0]),i=s.indexOf(e[1]);return n!==-1&&i!==-1?[pa(s,n,i),pa(s,i,n)]:!1}}function Tb(s){const t=s;let e;for(e=0;e<t.length-1;e++)for(let n=0;n<e-1;n++)if(wl(t[e],t[e+1],t[n],t[n+1]))return!1;for(e=1;e<t.length-2;e++)if(wl(t[0],t[t.length-1],t[e],t[e+1]))return!1;return!0}function fd(s,t,e,n,i){i===void 0&&(i=0);const r=t[1]-s[1],o=s[0]-t[0],a=r*s[0]+o*s[1],c=n[1]-e[1],l=e[0]-n[0],h=c*e[0]+l*e[1],u=r*l-c*o;return Pf(u,0,i)?[0,0]:[(l*a-o*h)/u,(r*h-c*a)/u]}function Rr(s,t,e,n,i,r,o){t===void 0&&(t=[]),e===void 0&&(e=[]),n===void 0&&(n=[]),i===void 0&&(i=25),r===void 0&&(r=100),o===void 0&&(o=0);let a=[0,0],c=[0,0],l=[0,0],h=0,u=0,d=0,p=0,x=0,g=0,m=0;const f=[],y=[],v=s,b=s;if(b.length<3)return t;if(o++,o>r)return console.warn("quickDecomp: max level ("+r+") reached."),t;for(let _=0;_<s.length;++_)if(Cf(v,_)){e.push(v[_]),h=u=Number.MAX_VALUE;for(let M=0;M<s.length;++M)ea(mt(v,_-1),mt(v,_),mt(v,M))&&Ir(mt(v,_-1),mt(v,_),mt(v,M-1))&&(l=fd(mt(v,_-1),mt(v,_),mt(v,M),mt(v,M-1)),Tf(mt(v,_+1),mt(v,_),l)&&(d=Ur(v[_],l),d<u&&(u=d,c=l,g=M))),ea(mt(v,_+1),mt(v,_),mt(v,M+1))&&Ir(mt(v,_+1),mt(v,_),mt(v,M))&&(l=fd(mt(v,_+1),mt(v,_),mt(v,M),mt(v,M+1)),ea(mt(v,_-1),mt(v,_),l)&&(d=Ur(v[_],l),d<h&&(h=d,a=l,x=M)));if(g===(x+1)%s.length)l[0]=(c[0]+a[0])/2,l[1]=(c[1]+a[1])/2,n.push(l),_<x?(Mn(f,v,_,x+1),f.push(l),y.push(l),g!==0&&Mn(y,v,g,v.length),Mn(y,v,0,_+1)):(_!==0&&Mn(f,v,_,v.length),Mn(f,v,0,x+1),f.push(l),y.push(l),Mn(y,v,g,_+1));else{if(g>x&&(x+=s.length),p=Number.MAX_VALUE,x<g)return t;for(let M=g;M<=x;++M)Tl(mt(v,_-1),mt(v,_),mt(v,M))&&Ir(mt(v,_+1),mt(v,_),mt(v,M))&&(d=Ur(mt(v,_),mt(v,M)),d<p&&Ab(v,_,M)&&(p=d,m=M%s.length));_<m?(Mn(f,v,_,m+1),m!==0&&Mn(y,v,m,b.length),Mn(y,v,0,_+1)):(_!==0&&Mn(f,v,_,b.length),Mn(f,v,0,m+1),Mn(y,v,m,_+1))}return f.length<y.length?(Rr(f,t,e,n,i,r,o),Rr(y,t,e,n,i,r,o)):(Rr(y,t,e,n,i,r,o),Rr(f,t,e,n,i,r,o)),t}return t.push(s),t}function pd(s,t){t===void 0&&(t=0);let e=0;for(let n=s.length-1;s.length>3&&n>=0;--n)bb(mt(s,n-1),mt(s,n),mt(s,n+1),t)&&(s.splice(n%s.length,1),e++);return e}function Pf(s,t,e){return e===void 0&&(e=0),e=e||0,Math.abs(s-t)<=e}const ai=class ai{constructor(t){U(this,"direction",N());U(this,"length",1);U(this,"_currentBody",null);U(this,"_currentShape",null);t===void 0&&(t={}),this.from=t.from?An(t.from):N(),this.to=t.to?An(t.to):N(),this.checkCollisionResponse=t.checkCollisionResponse??!0,this.skipBackfaces=!!t.skipBackfaces,this.collisionMask=t.collisionMask??-1,this.collisionGroup=t.collisionGroup??-1,this.mode=t.mode??ai.ANY,this.callback=(t==null?void 0:t.callback)||function(){},this.update()}update(){const t=this.direction;nt(t,this.to,this.from),this.length=Xr(t),be(t,t)}intersectBodies(t,e){for(let n=0,i=e.length;!t.shouldStop(this)&&n<i;n++){const r=e[n],o=r.getAABB();(o.overlapsRay(this)>=0||o.containsPoint(this.from))&&this.intersectBody(t,r)}}intersectBody(t,e){const n=this.checkCollisionResponse;if(n&&!e.collisionResponse)return;const i=Rb;for(let r=0,o=e.shapes.length;r<o;r++){const a=e.shapes[r];if(n&&!a.collisionResponse||(this.collisionGroup&a.collisionMask)===0||(a.collisionGroup&this.collisionMask)===0)continue;Ve(i,a.position,e.angle),_t(i,i,e.position);const c=a.angle+e.angle;if(this.intersectShape(t,a,c,i,e),t.shouldStop(this))break}}intersectShape(t,e,n,i,r){const o=this.from;Cb(o,this.direction,i)>e.boundingRadius*e.boundingRadius||(this._currentBody=r,this._currentShape=e,e.raycast(t,this,i,n),this._currentBody=this._currentShape=null)}getAABB(t){const e=this.to,n=this.from;Kt(t.lowerBound,Math.min(e[0],n[0]),Math.min(e[1],n[1])),Kt(t.upperBound,Math.max(e[0],n[0]),Math.max(e[1],n[1]))}reportIntersection(t,e,n,i){i===void 0&&(i=-1);const r=this._currentShape,o=this._currentBody;if(!(this.skipBackfaces&&ae(n,this.direction)>0))switch(this.mode){case ai.ALL:t.set(n,r,o,e,i),this.callback(t);break;case ai.CLOSEST:(e<t.fraction||!t.hasHit())&&t.set(n,r,o,e,i);break;case ai.ANY:t.set(n,r,o,e,i);break}}};U(ai,"CLOSEST",1),U(ai,"ANY",2),U(ai,"ALL",4);let qr=ai;const md=N(),Io=N();function Cb(s,t,e){nt(md,e,s);const n=ae(md,t);return It(Io,t,n),_t(Io,Io,s),Ql(e,Io)}const Rb=N();class Pb{constructor(){this.normal=N(),this.shape=null,this.body=null,this.faceIndex=-1,this.fraction=-1,this.isStopped=!1}reset(){Kt(this.normal,0,0),this.shape=null,this.body=null,this.faceIndex=-1,this.fraction=-1,this.isStopped=!1}getHitDistance(t){return Jl(t.from,t.to)*this.fraction}hasHit(){return this.fraction!==-1}getHitPoint(t,e){return Dr(t,e.from,e.to,this.fraction)}stop(){this.isStopped=!0}shouldStop(t){return this.isStopped||this.fraction!==-1&&t.mode===qr.ANY}set(t,e,n,i,r){$t(this.normal,t),this.shape=e,this.body=n,this.fraction=i,this.faceIndex=r}}class Lf{constructor(){U(this,"listeners",{})}on(t,e){let n=this.listeners[t];return n===void 0&&(n=[],this.listeners[t]=n),n.indexOf(e)===-1&&n.push(e),this}off(t,e){const n=this.listeners[t];if(n){const i=n.indexOf(e);i!==-1&&n.splice(i,1)}return this}has(t,e){const n=this.listeners[t];return e?n!==void 0&&n.indexOf(e)!==-1:n!==void 0}emit(t){if(this.listeners===void 0)return this;const e=this.listeners[t.type];if(e!==void 0)for(const n of[...e])n(t);return this}}function Lb(s){const t=s.length>>1;if(t<3)return[];const e=[],n=[];for(let o=0;o<t;o++)n.push(o);let i=0,r=t;for(;r>3;){const o=n[(i+0)%r],a=n[(i+1)%r],c=n[(i+2)%r],l=s[2*o],h=s[2*o+1],u=s[2*a],d=s[2*a+1],p=s[2*c],x=s[2*c+1];let g=!1;if(Ib(l,h,u,d,p,x)){g=!0;for(let m=0;m<r;m++){const f=n[m];if(!(f==o||f==a||f==c)&&Db(s[2*f],s[2*f+1],l,h,u,d,p,x)){g=!1;break}}}if(g)e.push(o,a,c),n.splice((i+1)%r,1),r--,i=0;else if(i++>3*r)break}return e.push(n[0],n[1],n[2]),e}function Db(s,t,e,n,i,r,o,a){const c=o-e,l=a-n,h=i-e,u=r-n,d=s-e,p=t-n,x=c*c+l*l,g=c*h+l*u,m=c*d+l*p,f=h*h+u*u,y=h*d+u*p,v=1/(x*f-g*g),b=(f*m-g*y)*v,_=(x*y-g*m)*v;return b>=0&&_>=0&&b+_<1}function Ib(s,t,e,n,i,r){return(t-n)*(i-e)+(e-s)*(r-n)>=0}const Sn=class Sn{constructor(t){U(this,"body",null);U(this,"position",N());U(this,"boundingRadius",0);U(this,"area",0);this.id=Sn.idCounter++,this.body=null,t.position&&$t(this.position,t.position),this.type=t.type,this.angle=t.angle??0,this.collisionGroup=t.collisionGroup??1,this.collisionResponse=t.collisionResponse??!0,this.collisionMask=t.collisionMask??1,this.sensor=t.sensor??!1,this.material=t.material??null}updateBoundingRadius(){}updateArea(){}raycast(t,e,n,i){}pointTest(t){return!1}worldPointToLocal(t,e){const n=this.body;return Ve(Uo,this.position,n.angle),_t(Uo,Uo,n.position),Gi(t,e,Uo,this.body.angle+this.angle),t}};U(Sn,"idCounter",0),U(Sn,"CIRCLE",1),U(Sn,"PARTICLE",2),U(Sn,"PLANE",4),U(Sn,"CONVEX",8),U(Sn,"LINE",16),U(Sn,"BOX",32),U(Sn,"CAPSULE",64),U(Sn,"HEIGHTFIELD",128);let yt=Sn;const Uo=N();class ms extends yt{constructor(t){t===void 0&&(t={});const e={type:yt.CONVEX,vertices:[],axes:[],...t};super(e),this.axes=e.axes,this.vertices=[];for(let n=0;n<e.vertices.length;n++)this.vertices.push(An(e.vertices[n]));this.normals=[];for(let n=0;n<e.vertices.length;n++)this.normals.push(N());if(this.updateNormals(),this.centerOfMass=N(),this.triangles=[],this.vertices.length&&(this.updateTriangles(),this.updateCenterOfMass()),this.boundingRadius=0,this.updateBoundingRadius(),this.updateArea(),this.area<0)throw new Error("Convex vertices must be given in counter-clockwise winding.")}updateNormals(){for(let t=0;t<this.vertices.length;t++){const e=this.vertices[t],n=this.vertices[(t+1)%this.vertices.length],i=this.normals[t];nt(i,n,e),rs(i,i),be(i,i)}}projectOntoLocalAxis(t,e){let n=0,i=0;t=Ub;for(let r=0;r<this.vertices.length;r++){const o=this.vertices[r],a=ae(o,t);(n===null||a>n)&&(n=a),(i===null||a<i)&&(i=a)}if(i>n){const r=i;i=n,n=r}Kt(e,i,n)}projectOntoWorldAxis(t,e,n,i){let r=Fb;this.projectOntoLocalAxis(t,i),n!==0?Ve(r,t,n):r=t;const o=ae(e,r);Kt(i,i[0]+o,i[1]+o)}updateTriangles(){this.triangles.length=0;const t=[];for(let n=0;n<this.vertices.length;n++){const i=this.vertices[n];t.push(i[0],i[1])}const e=Lb(t);for(let n=0;n<e.length;n+=3){const i=e[n],r=e[n+1],o=e[n+2];this.triangles.push([i,r,o])}}updateCenterOfMass(){const t=this.triangles,e=this.vertices,n=this.centerOfMass,i=Nb;let r=Bb,o=zb,a=Vb;const c=Ob;Kt(n,0,0);let l=0;for(let h=0;h!==t.length;h++){const u=t[h];r=e[u[0]],o=e[u[1]],a=e[u[2]],fb(i,r,o,a);const d=ms.triangleArea(r,o,a);l+=d,It(c,i,d),_t(n,n,c)}It(n,n,1/l)}computeMomentOfInertia(){let t=0,e=0;const n=this.vertices.length;for(let i=n-1,r=0;r<n;i=r,r++){const o=this.vertices[i],a=this.vertices[r],c=Math.abs(Zn(o,a)),l=ae(a,a)+ae(a,o)+ae(o,o);t+=c*l,e+=c}return 1/6*(t/e)}updateBoundingRadius(){const t=this.vertices;let e=0;for(let n=0;n!==t.length;n++){const i=Cn(t[n]);i>e&&(e=i)}this.boundingRadius=Math.sqrt(e)}updateArea(){this.updateTriangles(),this.area=0;const t=this.triangles,e=this.vertices;for(let n=0;n!==t.length;n++){const i=t[n],r=e[i[0]],o=e[i[1]],a=e[i[2]],c=ms.triangleArea(r,o,a);this.area+=c}}computeAABB(t,e,n){t.setFromPoints(this.vertices,e,n,0)}raycast(t,e,n,i){const r=kb,o=Gb,a=Hb,c=this.vertices;Gi(r,e.from,n,i),Gi(o,e.to,n,i);const l=c.length;for(let h=0;h<l&&!t.shouldStop(e);h++){const u=c[h],d=c[(h+1)%l],p=pb(r,o,u,d);p>=0&&(nt(a,d,u),Ve(a,a,-Math.PI/2+i),be(a,a),e.reportIntersection(t,p,a,h))}}pointTest(t){const e=Wb,n=Xb,i=this.vertices,r=i.length;let o=null;for(let a=0;a<r+1;a++){const c=i[a%r],l=i[(a+1)%r];nt(e,c,t),nt(n,l,t);const h=Zn(e,n);if(o===null&&(o=h),h*o<0)return!1;o=h}return!0}static triangleArea(t,e,n){return((e[0]-t[0])*(n[1]-t[1])-(n[0]-t[0])*(e[1]-t[1]))*.5}}const Ub=N(),Fb=N(),Nb=N(),Ob=N(),Bb=N(),zb=N(),Vb=N(),kb=N(),Gb=N(),Hb=N(),Wb=N(),Xb=N(),me=class me extends Lf{constructor(e){e===void 0&&(e={});super();U(this,"world",null);this.id=e.id||++me._idCounter,this.index=-1,this.shapes=[],this.mass=e.mass||0,this.invMass=0,this.inertia=0,this.invInertia=0,this.invMassSolve=0,this.invInertiaSolve=0,this.fixedRotation=!!e.fixedRotation,this.fixedX=!!e.fixedX,this.fixedY=!!e.fixedY,this.massMultiplier=N(),this.position=e.position?An(e.position):N(),this.interpolatedPosition=An(this.position),this.previousPosition=An(this.position),this.velocity=e.velocity?An(e.velocity):N(),this.vlambda=N(),this.wlambda=0,this.angle=e.angle||0,this.previousAngle=this.angle,this.interpolatedAngle=this.angle,this.angularVelocity=e.angularVelocity||0,this.force=e.force?An(e.force):N(),this.angularForce=e.angularForce||0,this.damping=e.damping??.1,this.angularDamping=e.angularDamping??.1,this.type=me.STATIC,e.type!==void 0?this.type=e.type:e.mass?this.type=me.DYNAMIC:this.type=me.STATIC,this.boundingRadius=0,this.aabb=new th,this.aabbNeedsUpdate=!0,this.allowSleep=e.allowSleep??!0,this.wantsToSleep=!1,this.sleepState=me.AWAKE,this.sleepSpeedLimit=e.sleepSpeedLimit??.2,this.sleepTimeLimit=e.sleepTimeLimit??1,this.idleTime=0,this.timeLastSleepy=0,this.collisionResponse=e.collisionResponse??!0,this.ccdSpeedThreshold=e.ccdSpeedThreshold??-1,this.ccdIterations=e.ccdIterations??10,this.gravityScale=e.gravityScale??1,this.islandId=-1,this.concavePath=null,this._wakeUpAfterNarrowphase=!1,this.updateMassProperties()}updateSolveMassProperties(){this.sleepState===me.SLEEPING||this.type===me.KINEMATIC?(this.invMassSolve=0,this.invInertiaSolve=0):(this.invMassSolve=this.invMass,this.invInertiaSolve=this.invInertia)}setDensity(e){const n=this.getArea();this.mass=n*e,this.updateMassProperties()}getArea(){let e=0;for(let n=0;n<this.shapes.length;n++)e+=this.shapes[n].area;return e}getAABB(){return this.aabbNeedsUpdate&&this.updateAABB(),this.aabb}updateAABB(){const e=this.shapes,n=e.length,i=qb,r=this.angle;for(let o=0;o!==n;o++){const a=e[o],c=a.angle+r;Ae(i,a.position,this.position,r),a.computeAABB(pc,i,c),o===0?this.aabb.copy(pc):this.aabb.extend(pc)}this.aabbNeedsUpdate=!1}updateBoundingRadius(){const e=this.shapes,n=e.length;let i=0;for(let r=0;r!==n;r++){const o=e[r],a=Xr(o.position),c=o.boundingRadius;a+c>i&&(i=a+c)}this.boundingRadius=i}addShape(e,n,i){if(e.body)throw new Error("A shape can only be added to one body.");const r=this.world;if(r&&r.stepping)throw new Error("A shape cannot be added during step.");e.body=this,n?$t(e.position,n):Kt(e.position,0,0),e.angle=i||0,this.shapes.push(e),this.updateMassProperties(),this.updateBoundingRadius(),this.aabbNeedsUpdate=!0}removeShape(e){const n=this.world;if(n&&n.stepping)throw new Error("A shape cannot be removed during step.");const i=this.shapes.indexOf(e);return i!==-1?(this.shapes.splice(i,1),this.aabbNeedsUpdate=!0,e.body=null,!0):!1}updateMassProperties(){if(this.type===me.STATIC||this.type===me.KINEMATIC)this.mass=Number.MAX_VALUE,this.invMass=0,this.inertia=Number.MAX_VALUE,this.invInertia=0;else{const e=this.shapes,n=e.length;let i=0;if(this.fixedRotation)this.inertia=Number.MAX_VALUE,this.invInertia=0;else{for(let r=0;r<n;r++){const o=e[r],a=Cn(o.position),c=o.computeMomentOfInertia();i+=c+a}this.inertia=this.mass*i,this.invInertia=i>0?1/i:0}this.invMass=1/this.mass,Kt(this.massMultiplier,this.fixedX?0:1,this.fixedY?0:1)}}applyForce(e,n){if(_t(this.force,this.force,e),n){const i=Zn(n,e);this.angularForce+=i}}applyForceLocal(e,n){n=n||Kb;const i=Yb,r=$b;this.vectorToWorldFrame(i,e),this.vectorToWorldFrame(r,n),this.applyForce(i,r)}applyImpulse(e,n){if(this.type!==me.DYNAMIC)return;const i=Zb;if(It(i,e,this.invMass),fa(i,this.massMultiplier,i),_t(this.velocity,i,this.velocity),n){let r=Zn(n,e);r*=this.invInertia,this.angularVelocity+=r}}applyImpulseLocal(e,n){n=n||Qb;const i=jb,r=Jb;this.vectorToWorldFrame(i,e),this.vectorToWorldFrame(r,n),this.applyImpulse(i,r)}toLocalFrame(e,n){Gi(e,n,this.position,this.angle)}toWorldFrame(e,n){Ae(e,n,this.position,this.angle)}vectorToLocalFrame(e,n){wf(e,n,this.angle)}vectorToWorldFrame(e,n){db(e,n,this.angle)}fromPolygon(e,n){n===void 0&&(n={});for(let c=this.shapes.length;c>=0;--c)this.removeShape(this.shapes[c]);const i=[];for(let c=0;c<e.length;c++)i[c]=An(e[c]);if(yb(i),n.removeCollinearPoints!==void 0&&(typeof n.removeCollinearPoints=="boolean"?n.removeCollinearPoints===!0&&pd(i):pd(i,n.removeCollinearPoints)),!n.skipSimpleCheck&&!Tb(i))return!1;const r=this.concavePath=[];for(let c=0;c<i.length;c++)r[c]=An(i[c]);let o;if(n.optimalDecomp){if(o=wb(i),o===!1)throw new Error("Convex decomposition failed!")}else o=Rr(i);const a=N();for(let c=0;c!==o.length;c++){let l=new ms({vertices:o[c]});for(let h=0;h!==l.vertices.length;h++){const u=l.vertices[h];nt(u,u,l.centerOfMass)}$t(a,l.centerOfMass),l=new ms({vertices:l.vertices}),this.addShape(l,a)}return this.adjustCenterOfMass(),this.aabbNeedsUpdate=!0,!0}adjustCenterOfMass(){const e=tM,n=eM,i=nM;let r=0;Kt(n,0,0);for(let o=0;o!==this.shapes.length;o++){const a=this.shapes[o];It(e,a.position,a.area),_t(n,n,e),r+=a.area}It(i,n,1/r);for(let o=0;o!==this.shapes.length;o++){const a=this.shapes[o];nt(a.position,a.position,i)}_t(this.position,this.position,i);for(let o=0;this.concavePath&&o<this.concavePath.length;o++)nt(this.concavePath[o],this.concavePath[o],i);this.updateMassProperties(),this.updateBoundingRadius()}setZeroForce(){const e=this.force;e[0]=e[1]=this.angularForce=0}applyDamping(e){if(this.type===me.DYNAMIC){const n=this.velocity;It(n,n,Math.pow(1-this.damping,e)),this.angularVelocity*=Math.pow(1-this.angularDamping,e)}}wakeUp(){const e=this.sleepState;this.sleepState=me.AWAKE,this.idleTime=0,e!==me.AWAKE&&this.emit({type:"wakeup"})}sleep(){this.sleepState=me.SLEEPING,this.angularVelocity=this.angularForce=0,Kt(this.velocity,0,0),Kt(this.force,0,0),this.emit({type:"sleep"})}sleepTick(e,n,i){if(!this.allowSleep||this.type===me.SLEEPING)return;this.wantsToSleep=!1;const r=Cn(this.velocity)+Math.pow(this.angularVelocity,2),o=Math.pow(this.sleepSpeedLimit,2);r>=o?(this.idleTime=0,this.sleepState=me.AWAKE):(this.idleTime+=i,this.sleepState!==me.SLEEPY&&(this.sleepState=me.SLEEPY,this.emit({type:"sleepy"}))),this.idleTime>this.sleepTimeLimit&&(n?this.wantsToSleep=!0:this.sleep())}overlaps(e){return this.world===null?!1:this.world.overlapKeeper.bodiesAreOverlapping(this,e)}integrate(e){const n=this.invMass,i=this.force,r=this.position,o=this.velocity;$t(this.previousPosition,this.position),this.previousAngle=this.angle,this.fixedRotation||(this.angularVelocity+=this.angularForce*this.invInertia*e),It(Fo,i,e*n),fa(Fo,this.massMultiplier,Fo),_t(o,Fo,o),this.integrateToTimeOfImpact(e)||(It(Ns,o,e),_t(r,r,Ns),this.fixedRotation||(this.angle+=this.angularVelocity*e)),this.aabbNeedsUpdate=!0}getVelocityAtPoint(e,n){return Al(e,n,this.angularVelocity),nt(e,this.velocity,e),e}integrateToTimeOfImpact(e){if(this.world===null)throw new Error("world is not set for body");if(this.ccdSpeedThreshold<0||Cn(this.velocity)<Math.pow(this.ccdSpeedThreshold,2))return!1;const n=[],i=this.world.disabledBodyCollisionPairs;for(let x=0;x<i.length;x+=2){const g=i[x],m=i[x+1];g===this?n.push(m):m===this&&n.push(g)}be(iM,this.velocity),It(Pi,this.velocity,e),_t(Pi,Pi,this.position),nt(Mr,Pi,this.position);const r=this.angularVelocity*e,o=Xr(Mr);let a=1,c=null;$t(ts.from,this.position),$t(ts.to,Pi),ts.update();for(let x=0;x<this.shapes.length;x++){const g=this.shapes[x];if(No.reset(),ts.collisionGroup=g.collisionGroup,ts.collisionMask=g.collisionMask,this.world.raycast(No,ts),c=No.body,c!==null&&(c===this||n.indexOf(c)!==-1)&&(c=null),c)break}if(!c||!a)return!1;No.getHitPoint(Pi,ts),nt(Mr,Pi,this.position),a=Jl(Pi,this.position)/o;const l=this.angle;$t(mc,this.position);let h=0,u=0,d=a,p=1;for(;p>=u&&h<this.ccdIterations;)h++,d=(p+u)/2,It(Ns,Mr,d),_t(this.position,mc,Ns),this.angle=l+r*d,this.updateAABB(),this.aabb.overlaps(c.aabb)&&this.world.narrowphase.bodiesOverlap(this,c,!0)?p=d:u=d;return a=p,$t(this.position,mc),this.angle=l,It(Ns,Mr,a),_t(this.position,this.position,Ns),this.fixedRotation||(this.angle+=r*a),!0}resetConstraintVelocity(){const e=this.vlambda;Kt(e,0,0),this.wlambda=0}addConstraintVelocity(){const e=this.velocity;_t(e,e,this.vlambda),this.angularVelocity+=this.wlambda}};U(me,"DYNAMIC",1),U(me,"STATIC",2),U(me,"KINEMATIC",4),U(me,"AWAKE",0),U(me,"SLEEPY",1),U(me,"SLEEPING",2),U(me,"_idCounter",0);let jt=me;const pc=new th,qb=N(),Yb=N(),$b=N(),Kb=N(),Zb=N(),jb=N(),Jb=N(),Qb=N(),tM=N(),eM=N(),nM=N(),Fo=N(),Ns=N(),No=new Pb,ts=new qr({mode:qr.CLOSEST,skipBackfaces:!0}),iM=N(),Pi=N(),Mr=N(),mc=N(),On=class On{static boundingRadiusCheck(t,e){const n=Ql(t.position,e.position),i=t.boundingRadius+e.boundingRadius;return n<=i*i}static aabbCheck(t,e){return t.getAABB().overlaps(e.getAABB())}static canCollide(t,e){const n=jt.KINEMATIC,i=jt.STATIC,r=t.type,o=e.type;return!(r===i&&o===i||r===n&&o===i||r===i&&o===n||r===n&&o===n||t.sleepState===jt.SLEEPING&&e.sleepState===jt.SLEEPING||t.sleepState===jt.SLEEPING&&o===i||e.sleepState===jt.SLEEPING&&r===i)}constructor(t){this.type=t,this.result=[],this.world=void 0,this.boundingVolumeType=On.AABB}setWorld(t){this.world=t}boundingVolumeCheck(t,e){switch(this.boundingVolumeType){case On.BOUNDING_CIRCLE:return On.boundingRadiusCheck(t,e);case On.AABB:return On.aabbCheck(t,e);default:throw new Error("Bounding volume type not recognized: "+this.boundingVolumeType)}}};U(On,"AABB",1),U(On,"BOUNDING_CIRCLE",2),U(On,"NAIVE",1),U(On,"SAP",2);let Fr=On;class ma extends ms{constructor(t){t===void 0&&(t={});const e=t.width??1,n=t.height??1,i=[ln(-e/2,-n/2),ln(e/2,-n/2),ln(e/2,n/2),ln(-e/2,n/2)],r={...t,type:yt.BOX,vertices:i};super(r),this.width=e,this.height=n,this.updateBoundingRadius(),this.updateArea()}computeMomentOfInertia(){const t=this.width,e=this.height;return(e*e+t*t)/12}updateBoundingRadius(){const t=this.width,e=this.height;this.boundingRadius=Math.sqrt(t*t+e*e)/2}computeAABB(t,e,n){const i=Math.abs(Math.cos(n)),r=Math.abs(Math.sin(n)),o=this.width,a=this.height,c=(o*r+a*i)*.5,l=(a*r+o*i)*.5,h=t.lowerBound,u=t.upperBound,d=e[0],p=e[1];h[0]=d-l,h[1]=p-c,u[0]=d+l,u[1]=p+c}updateArea(){this.area=this.width*this.height}pointTest(t){return Math.abs(t[0])<=this.width*.5&&Math.abs(t[1])<=this.height*.5}}class eh extends yt{constructor(t){t===void 0&&(t={});const e={radius:1,...t,type:yt.CIRCLE};super(e),this.radius=e.radius,this.updateBoundingRadius(),this.updateArea()}updateBoundingRadius(){this.boundingRadius=this.radius}computeMomentOfInertia(){const t=this.radius;return t*t/2}updateArea(){this.area=Math.PI*this.radius*this.radius}computeAABB(t,e){const n=this.radius;Kt(t.upperBound,n,n),Kt(t.lowerBound,-n,-n),e&&(_t(t.lowerBound,t.lowerBound,e),_t(t.upperBound,t.upperBound,e))}raycast(t,e,n){const i=e.from,r=e.to,o=this.radius,a=Math.pow(r[0]-i[0],2)+Math.pow(r[1]-i[1],2),c=2*((r[0]-i[0])*(i[0]-n[0])+(r[1]-i[1])*(i[1]-n[1])),l=Math.pow(i[0]-n[0],2)+Math.pow(i[1]-n[1],2)-Math.pow(o,2),h=Math.pow(c,2)-4*a*l,u=sM,d=rM;if(!(h<0))if(h===0)Dr(u,i,r,h),nt(d,u,n),be(d,d),e.reportIntersection(t,h,d,-1);else{const p=Math.sqrt(h),x=1/(2*a),g=(-c-p)*x,m=(-c+p)*x;if(g>=0&&g<=1&&(Dr(u,i,r,g),nt(d,u,n),be(d,d),e.reportIntersection(t,g,d,-1),t.shouldStop(e)))return;m>=0&&m<=1&&(Dr(u,i,r,m),nt(d,u,n),be(d,d),e.reportIntersection(t,m,d,-1))}}pointTest(t){const e=this.radius;return Cn(t)<=e*e}}const sM=N(),rM=N(),ks=class ks{constructor(t,e,n,i){this.bodyA=t,this.bodyB=e,this.minForce=n??-Number.MAX_VALUE,this.maxForce=i??Number.MAX_VALUE,this.maxBias=Number.MAX_VALUE,this.stiffness=ks.DEFAULT_STIFFNESS,this.relaxation=ks.DEFAULT_RELAXATION,this.G=new Aa(6);for(let r=0;r<6;r++)this.G[r]=0;this.offset=0,this.a=0,this.b=0,this.epsilon=0,this.timeStep=1/60,this.needsUpdate=!0,this.multiplier=0,this.relativeVelocity=0,this.enabled=!0,this.lambda=this.B=this.invC=this.minForceDt=this.maxForceDt=0,this.index=-1}update(){const t=this.stiffness,e=this.relaxation,n=this.timeStep;this.a=4/(n*(1+4*e)),this.b=4*e/(1+4*e),this.epsilon=4/(n*n*t*(1+4*e)),this.needsUpdate=!1}gmult(t,e,n,i,r){return t[0]*e[0]+t[1]*e[1]+t[2]*n+t[3]*i[0]+t[4]*i[1]+t[5]*r}computeB(t,e,n){const i=this.computeGW();let r=this.computeGq();const o=this.maxBias;Math.abs(r)>o&&(r=r>0?o:-o);const a=this.computeGiMf();return-r*t-i*e-a*n}computeGq(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.angle,r=n.angle;return this.gmult(t,oM,i,aM,r)+this.offset}computeGW(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.velocity,r=n.velocity,o=e.angularVelocity,a=n.angularVelocity;return this.gmult(t,i,o,r,a)+this.relativeVelocity}computeGWlambda(){const t=this.G,e=this.bodyA,n=this.bodyB,i=e.vlambda,r=n.vlambda,o=e.wlambda,a=n.wlambda;return this.gmult(t,i,o,r,a)}computeGiMf(){const t=this.bodyA,e=this.bodyB,n=t.force,i=t.angularForce,r=e.force,o=e.angularForce,a=t.invMassSolve,c=e.invMassSolve,l=t.invInertiaSolve,h=e.invInertiaSolve,u=this.G;return It(Oo,n,a),fa(Oo,t.massMultiplier,Oo),It(Bo,r,c),fa(Bo,e.massMultiplier,Bo),this.gmult(u,Oo,i*l,Bo,o*h)}computeGiMGt(){const t=this.bodyA,e=this.bodyB,n=t.invMassSolve,i=e.invMassSolve,r=t.invInertiaSolve,o=e.invInertiaSolve,a=this.G;return a[0]*a[0]*n*t.massMultiplier[0]+a[1]*a[1]*n*t.massMultiplier[1]+a[2]*a[2]*r+a[3]*a[3]*i*e.massMultiplier[0]+a[4]*a[4]*i*e.massMultiplier[1]+a[5]*a[5]*o}addToWlambda(t){const e=this.bodyA,n=this.bodyB,i=e.invMassSolve,r=n.invMassSolve,o=e.invInertiaSolve,a=n.invInertiaSolve,c=this.G;xd(e.vlambda,c[0],c[1],i,t,e.massMultiplier),e.wlambda+=o*c[2]*t,xd(n.vlambda,c[3],c[4],r,t,n.massMultiplier),n.wlambda+=a*c[5]*t}computeInvC(t){return 1/(this.computeGiMGt()+t)}};U(ks,"DEFAULT_STIFFNESS",1e6),U(ks,"DEFAULT_RELAXATION",4);let Oi=ks;const oM=N(),aM=N(),Oo=N(),Bo=N();function xd(s,t,e,n,i,r){s[0]+=t*n*i*r[0],s[1]+=e*n*i*r[1]}function cM(s,t,e,n,i){s[0]=t[0]+e[0]-n[0]-i[0],s[1]=t[1]+e[1]-n[1]-i[1]}const gd=N(),_d=N(),vd=N(),bd=new eh({radius:1});class lM extends Oi{constructor(t,e){super(t,e,0,Number.MAX_VALUE),this.contactPointA=N(),this.penetrationVec=N(),this.contactPointB=N(),this.normalA=N(),this.restitution=0,this.firstImpact=!1,this.shapeA=bd,this.shapeB=bd}computeB(t,e,n){const i=this.bodyA,r=this.bodyB,o=this.contactPointA,a=this.contactPointB,c=i.position,l=r.position,h=this.normalA,u=this.G,d=Zn(o,h),p=Zn(a,h);u[0]=-h[0],u[1]=-h[1],u[2]=-d,u[3]=h[0],u[4]=h[1],u[5]=p;let x,g;if(this.firstImpact&&this.restitution!==0)g=0,x=1/e*(1+this.restitution)*this.computeGW();else{const y=this.penetrationVec;cM(y,l,a,c,o),g=ae(h,y)+this.offset,x=this.computeGW()}const m=this.computeGiMf();return-g*t-x*e-n*m}getVelocityAlongNormal(){return this.bodyA.getVelocityAtPoint(gd,this.contactPointA),this.bodyB.getVelocityAtPoint(_d,this.contactPointB),nt(vd,gd,_d),ae(this.normalA,vd)}}class nh{constructor(t){U(this,"objects",[]);(t==null?void 0:t.size)!==void 0&&this.resize(t.size)}resize(t){const e=this.objects;for(;e.length>t;)e.pop();for(;e.length<t;)e.push(this.create());return this}get(){const t=this.objects;return t.length?t.pop():this.create()}release(t){return this.destroy(t),this.objects.push(t),this}}class hM extends nh{create(){return new lM(xc,xc)}destroy(t){return t.bodyA=t.bodyB=xc,this}}const xc=new jt;class Df extends Oi{constructor(t,e,n){n===void 0&&(n=Number.MAX_VALUE),super(t,e,-n,n),this.contactPointA=N(),this.contactPointB=N(),this.t=N(),this.contactEquations=[],this.shapeA=null,this.shapeB=null,this.frictionCoefficient=.3}setSlipForce(t){this.maxForce=t,this.minForce=-t}getSlipForce(){return this.maxForce}computeB(t,e,n){const i=this.contactPointA,r=this.contactPointB,o=this.t,a=this.G;a[0]=-o[0],a[1]=-o[1],a[2]=-Zn(i,o),a[3]=o[0],a[4]=o[1],a[5]=Zn(r,o);const c=this.computeGW(),l=this.computeGiMf();return-c*e-n*l}}class uM extends nh{create(){return new Df(gc,gc)}destroy(t){return t.bodyA=t.bodyB=gc,this}}const gc=new jt;class na{constructor(){U(this,"data",{});U(this,"keys",[])}getKey(t,e){return t=t|0,e=e|0,(t|0)===(e|0)?-1:((t|0)>(e|0)?t<<16|e&65535:e<<16|t&65535)|0}getByKey(t){return t=t|0,this.data[t]}get(t,e){return this.data[this.getKey(t,e)]}set(t,e,n){if(!n)throw new Error("No data!");const i=this.getKey(t,e);return this.data[i]||this.keys.push(i),this.data[i]=n,i}reset(){this.keys=[],this.data={}}copy(t){this.keys=t.keys,this.data=t.data}}class dM{constructor(){U(this,"convexLine",function(t,e,n,i,r,o,a,c,l){return 0});U(this,"lineBox",function(t,e,n,i,r,o,a,c,l){return 0});U(this,"convexCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=zM,d=a.length/2;Kt(u,d,0),Ae(u,u,c,l);const p=t.circleConvex(o,a,u,l,e,n,i,r,h,a.radius);Kt(u,-d,0),Ae(u,u,c,l);const x=t.circleConvex(o,a,u,l,e,n,i,r,h,a.radius);if(h&&p+x!==0)return 1;const g=BM;return Mc(g,a),t.convexConvex(e,n,i,r,o,g,c,l,h)+p+x}})());U(this,"lineCapsule",function(t,e,n,i,r,o,a,c,l){return 0});U(this,"capsuleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);let u=!0;const d=VM,p=kM;let x=0;for(let y=0;y<2;y++){Kt(d,(y===0?-1:1)*n.length/2,0),Ae(d,d,i,r);for(let v=0;v<2;v++){Kt(p,(v===0?-1:1)*a.length/2,0),Ae(p,p,c,l),t.enableFrictionReduction&&(u=t.enableFriction,t.enableFriction=!1);const b=t.circleCircle(e,n,d,r,o,a,p,l,h,n.radius,a.radius);if(t.enableFrictionReduction&&(t.enableFriction=u),h&&b!==0)return 1;x+=b}}t.enableFrictionReduction&&(u=t.enableFriction,t.enableFriction=!1);const g=GM;Mc(g,n);const m=t.convexCapsule(e,g,i,r,o,a,c,l,h);if(t.enableFrictionReduction&&(t.enableFriction=u),h&&m!==0)return 1;x+=m,t.enableFrictionReduction&&(u=t.enableFriction,t.enableFriction=!1),Mc(g,a);const f=t.convexCapsule(o,g,c,l,e,n,i,r,h);return t.enableFrictionReduction&&(t.enableFriction=u),h&&f!==0?1:(x+=f,t.enableFrictionReduction&&x&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(x)),x)}})());U(this,"lineLine",function(t,e,n,i,r,o,a,c,l){return 0});U(this,"planeLine",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=si,d=es,p=Os,x=yr,g=Sr,m=Er,f=Vo,y=_c,v=Md,b=Ad;let _=0;Kt(u,-a.length/2,0),Kt(d,a.length/2,0),Ae(p,u,c,l),Ae(x,d,c,l),$t(u,p),$t(d,x),nt(g,d,u),be(m,g),rs(v,m),Ve(y,zo,r),b[0]=u,b[1]=d;for(let M=0;M<b.length;M++){const T=b[M];nt(f,T,i);const P=ae(f,y);if(P<0){if(h)return 1;const A=t.createContactEquation(e,o,n,a);_++,$t(A.normalA,y),be(A.normalA,A.normalA),It(f,y,P),nt(A.contactPointA,T,f),nt(A.contactPointA,A.contactPointA,e.position),nt(A.contactPointB,T,c),_t(A.contactPointB,A.contactPointB,c),nt(A.contactPointB,A.contactPointB,o.position),t.contactEquations.push(A),t.enableFrictionReduction||t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(A))}}return h?0:(t.enableFrictionReduction||_&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(_)),_)}})());U(this,"particleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){return h===void 0&&(h=!1),t.circleLine(e,n,i,r,o,a,c,l,h,a.radius,0)}})());U(this,"circleLine",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,u,d){h===void 0&&(h=!1),u===void 0&&(u=0),d===void 0&&(d=n.radius);const p=si,x=es,g=Os,m=yr,f=Sr,y=Er,v=Vo,b=_c,_=Md,M=yd,T=Sd,P=fM,A=vc,E=bc,R=Ad,I=a.length/2;Kt(b,-I,0),Kt(_,I,0),Ae(M,b,c,l),Ae(T,_,c,l),$t(b,M),$t(_,T),nt(y,_,b),be(v,y),rs(f,v),nt(P,i,b);const z=ae(P,f);nt(m,b,c),nt(A,i,c);const X=d+u;if(Math.abs(z)<X){It(p,f,z),nt(g,i,p),It(x,f,ae(f,A)),be(x,x),It(x,x,u),_t(g,g,x);const H=ae(v,g),K=ae(v,b),G=ae(v,_);if(H>K&&H<G){if(h)return 1;const V=t.createContactEquation(e,o,n,a);return It(V.normalA,p,-1),be(V.normalA,V.normalA),It(V.contactPointA,V.normalA,d),_t(V.contactPointA,V.contactPointA,i),nt(V.contactPointA,V.contactPointA,e.position),nt(V.contactPointB,g,c),_t(V.contactPointB,V.contactPointB,c),nt(V.contactPointB,V.contactPointB,o.position),t.contactEquations.push(V),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(V)),1}}R[0]=b,R[1]=_;for(let H=0;H<R.length;H++){const K=R[H];if(nt(P,K,i),Cn(P)<Math.pow(X,2)){if(h)return 1;const G=t.createContactEquation(e,o,n,a);return $t(G.normalA,P),be(G.normalA,G.normalA),It(G.contactPointA,G.normalA,d),_t(G.contactPointA,G.contactPointA,i),nt(G.contactPointA,G.contactPointA,e.position),nt(G.contactPointB,K,c),It(E,G.normalA,-u),_t(G.contactPointB,G.contactPointB,E),_t(G.contactPointB,G.contactPointB,c),nt(G.contactPointB,G.contactPointB,o.position),t.contactEquations.push(G),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(G)),1}}return 0}})());U(this,"circleCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){return h===void 0&&(h=!1),t.circleLine(e,n,i,r,o,a,c,l,h,a.radius)}})());U(this,"circleConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,u){h===void 0&&(h=!1),u===void 0&&(u=n.radius);const d=si,p=es,x=Os,g=yr,m=Sr,f=Er,y=Vo,v=_c,b=yd,_=Sd,M=vc,T=bc,P=Ed;let A=-1,E=Number.MAX_VALUE;Kt(f,0,0),Gi(y,i,c,l);const R=a.vertices,I=a.normals,z=R.length;let X=-1,H=-Number.MAX_VALUE;const K=a.boundingRadius+u;for(let G=0;G<z;G++){nt(v,y,R[G]);const V=ae(I[G],v);if(V>K)return 0;V>H&&(H=V,X=G)}for(let G=X+z-1;G<X+z+2;G++){const V=R[G%z],$=I[G%z];if(It(T,$,-u),_t(T,T,y),XM(T,a)){nt(P,V,T);const st=Math.abs(ae(P,$));st<E&&(E=st,A=G)}}if(A!==-1){if(h)return 1;const G=R[A%z],V=R[(A+1)%z];Ae(d,G,c,l),Ae(p,V,c,l),nt(x,p,d),be(g,x),rs(m,g),It(T,m,-u),_t(T,T,i),It(M,m,E),_t(M,M,T);const $=t.createContactEquation(e,o,n,a);return nt($.normalA,T,i),be($.normalA,$.normalA),It($.contactPointA,$.normalA,u),_t($.contactPointA,$.contactPointA,i),nt($.contactPointA,$.contactPointA,e.position),nt($.contactPointB,M,c),_t($.contactPointB,$.contactPointB,c),nt($.contactPointB,$.contactPointB,o.position),t.contactEquations.push($),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact($)),1}if(u>0&&X!==-1)for(let G=X+z;G<X+z+2;G++){const V=R[G%z];if(nt(b,V,y),Cn(b)<u*u){if(h)return 1;Ae(_,V,c,l),nt(b,_,i);const $=t.createContactEquation(e,o,n,a);return $t($.normalA,b),be($.normalA,$.normalA),It($.contactPointA,$.normalA,u),_t($.contactPointA,$.contactPointA,i),nt($.contactPointA,$.contactPointA,e.position),nt($.contactPointB,_,c),_t($.contactPointB,$.contactPointB,c),nt($.contactPointB,$.contactPointB,o.position),t.contactEquations.push($),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact($)),1}}return 0}})());U(this,"particleConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=si,d=es,p=Os,x=yr,g=Sr,m=Er,f=Vo,y=vc,v=bc,b=Ed,_=a.vertices;let M=Number.MAX_VALUE,T=!1;if(!WM(i,a,c,l))return 0;if(h)return 1;for(let P=0,A=_.length;P!==A+1;P++){const E=_[P%A],R=_[(P+1)%A];Ve(u,E,l),Ve(d,R,l),_t(u,u,c),_t(d,d,c),nt(p,d,u),be(x,p),rs(g,x),nt(m,u,c),nt(f,i,c),nt(v,u,i);const I=Math.abs(ae(v,g));I<M&&(M=I,It(y,g,I),_t(y,y,i),$t(b,g),T=!0)}if(T){const P=t.createContactEquation(e,o,n,a);return It(P.normalA,b,-1),be(P.normalA,P.normalA),Kt(P.contactPointA,0,0),_t(P.contactPointA,P.contactPointA,i),nt(P.contactPointA,P.contactPointA,e.position),nt(P.contactPointB,y,c),_t(P.contactPointB,P.contactPointB,c),nt(P.contactPointB,P.contactPointB,o.position),t.contactEquations.push(P),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(P)),1}return 0}})());U(this,"circleCircle",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,u,d){h===void 0&&(h=!1),u===void 0&&(u=n.radius),d===void 0&&(d=a.radius);const p=si;nt(p,i,c);const x=u+d;if(Cn(p)>x*x)return 0;if(h)return 1;const g=t.createContactEquation(e,o,n,a),m=g.contactPointA,f=g.contactPointB,y=g.normalA;return nt(y,c,i),be(y,y),It(m,y,u),It(f,y,-d),wd(m,m,i,e.position),wd(f,f,c,o.position),t.contactEquations.push(g),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(g)),1}})());U(this,"planeConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=si,d=es,p=Os,x=yr,g=Sr,m=Er;let f=0;Ve(d,zo,r),wf(g,d,l),Gi(x,i,c,l);const y=a.vertices;for(let v=0,b=y.length;v!==b;v++){const _=y[v];if(nt(m,_,x),ae(m,g)<=0){if(h)return 1;Ae(u,_,c,l),nt(p,u,i),f++;const M=t.createContactEquation(e,o,n,a);nt(p,u,i),$t(M.normalA,d);const T=ae(p,M.normalA);It(p,M.normalA,T),nt(M.contactPointB,u,o.position),nt(M.contactPointA,u,p),nt(M.contactPointA,M.contactPointA,e.position),t.contactEquations.push(M),t.enableFrictionReduction||t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(M))}}return t.enableFrictionReduction&&t.enableFriction&&f&&t.frictionEquations.push(t.createFrictionFromAverage(f)),f}})());U(this,"particlePlane",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=si,d=es;l=l||0,nt(u,i,c),Ve(d,zo,l);const p=ae(u,d);if(p>0)return 0;if(h)return 1;const x=t.createContactEquation(o,e,a,n);return $t(x.normalA,d),It(u,x.normalA,p),nt(x.contactPointA,i,u),nt(x.contactPointA,x.contactPointA,o.position),nt(x.contactPointB,i,e.position),t.contactEquations.push(x),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(x)),1}})());U(this,"circleParticle",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=si,d=n.radius;if(nt(u,c,i),Cn(u)>d*d)return 0;if(h)return 1;const p=t.createContactEquation(e,o,n,a),x=p.normalA,g=p.contactPointA,m=p.contactPointB;return $t(x,u),be(x,x),It(g,x,d),_t(g,g,i),nt(g,g,e.position),nt(m,c,o.position),t.contactEquations.push(p),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(p)),1}})());U(this,"planeCapsule",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=YM,d=$M,p=qM,x=a.length/2;Kt(u,-x,0),Kt(d,x,0),Ae(u,u,c,l),Ae(d,d,c,l),p.radius=a.radius;let g=!0;t.enableFrictionReduction&&(g=t.enableFriction,t.enableFriction=!1);const m=t.circlePlane(o,p,u,0,e,n,i,r,h),f=t.circlePlane(o,p,d,0,e,n,i,r,h);if(t.enableFrictionReduction&&(t.enableFriction=g),h)return m+f;{const y=m+f;return t.enableFrictionReduction&&y&&t.frictionEquations.push(t.createFrictionFromAverage(y)),y}}})());U(this,"circlePlane",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=n.radius,d=si,p=es,x=Os;nt(d,i,c),Ve(p,zo,l);const g=ae(p,d);if(g>u)return 0;if(h)return 1;const m=t.createContactEquation(o,e,a,n);$t(m.normalA,p);const f=m.contactPointB;It(f,m.normalA,-u),_t(f,f,i),nt(f,f,e.position);const y=m.contactPointA;return It(x,m.normalA,g),nt(y,d,x),_t(y,y,c),nt(y,y,o.position),t.contactEquations.push(m),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(m)),1}})());U(this,"convexConvex",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=0,d=wM,p=xM,x=gM,g=Td(p,n,i,r,a,c,l),m=p[0];if(m>u)return 0;const f=Td(x,a,c,l,n,i,r),y=x[0];if(y>u)return 0;let v,b,_,M,T,P,A,E,R;y>m?(v=a,b=n,A=o,E=e,_=c,T=l,M=i,P=r,R=f):(v=n,b=a,A=e,E=o,_=i,T=r,M=c,P=l,R=g);const I=RM;ty(I,v,_,T,R,b,M,P);const z=v.vertices.length,X=v.vertices,H=R,K=R+1<z?R+1:0,G=EM,V=AM;$t(G,X[H]),$t(V,X[K]);const $=_M;nt($,V,G),be($,$),Al(vM,$,1);const St=bM;_t(St,G,V),It(St,St,.5);const Ht=MM;Ve(Ht,$,T);const ne=yM;Al(ne,Ht,1),Ae(G,G,_,T),Ae(V,V,_,T);const ce=ae(ne,G),le=-ae(Ht,G)+u,Z=ae(Ht,V)+u,Q=TM,ft=CM;let Ft=0;const At=SM;if(It(At,Ht,-1),Ft=Cd(Q,I,At,le),Ft<2||(Ft=Cd(ft,Q,Ht,Z),Ft<2))return 0;let Wt=0;for(let Me=0;Me<PM;++Me){const qt=ae(ne,ft[Me])-ce;if(qt<=u){if(h)return 1;++Wt;const ie=t.createContactEquation(A,E,v,b);$t(ie.normalA,ne),$t(ie.contactPointB,ft[Me]),nt(ie.contactPointB,ie.contactPointB,E.position),It(d,ne,-qt),_t(ie.contactPointA,ft[Me],d),nt(ie.contactPointA,ie.contactPointA,A.position),t.contactEquations.push(ie),t.enableFriction&&!t.enableFrictionReduction&&t.frictionEquations.push(t.createFrictionFromContact(ie))}}return Wt&&t.enableFrictionReduction&&t.enableFriction&&t.frictionEquations.push(t.createFrictionFromAverage(Wt)),Wt}})());U(this,"circleHeightfield",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h,u){h===void 0&&(h=!1),u===void 0&&(u=n.radius);const d=a.heights,p=a.elementWidth,x=DM,g=LM,m=FM,f=OM,y=NM,v=IM,b=UM;let _=Math.floor((i[0]-u-c[0])/p),M=Math.ceil((i[0]+u-c[0])/p);_<0&&(_=0),M>=d.length&&(M=d.length-1);let T=d[_],P=d[M];for(let E=_;E<M;E++)d[E]<P&&(P=d[E]),d[E]>T&&(T=d[E]);if(i[1]-u>T)return 0;let A=!1;for(let E=_;E<M;E++){Kt(v,E*p,d[E]),Kt(b,(E+1)*p,d[E+1]),_t(v,v,c),_t(b,b,c),nt(y,b,v),Ve(y,y,Math.PI/2),be(y,y),It(g,y,-u),_t(g,g,i),nt(x,g,v);const R=ae(x,y);if(g[0]>=v[0]&&g[0]<b[0]&&R<=0){if(h)return 1;A=!0,It(x,y,-R),_t(m,g,x),$t(f,y);const I=t.createContactEquation(o,e,a,n);$t(I.normalA,f),It(I.contactPointB,I.normalA,-u),_t(I.contactPointB,I.contactPointB,i),nt(I.contactPointB,I.contactPointB,e.position),$t(I.contactPointA,m),nt(I.contactPointA,I.contactPointA,o.position),t.contactEquations.push(I),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(I))}}if(A=!1,u>0){for(let E=_;E<=M;E++)if(Kt(v,E*p,d[E]),_t(v,v,c),nt(x,i,v),Cn(x)<Math.pow(u,2)){if(h)return 1;A=!0;const R=t.createContactEquation(o,e,a,n);$t(R.normalA,x),be(R.normalA,R.normalA),It(R.contactPointB,R.normalA,-u),_t(R.contactPointB,R.contactPointB,i),nt(R.contactPointB,R.contactPointB,e.position),nt(R.contactPointA,v,c),_t(R.contactPointA,R.contactPointA,c),nt(R.contactPointA,R.contactPointA,o.position),t.contactEquations.push(R),t.enableFriction&&t.frictionEquations.push(t.createFrictionFromContact(R))}}return A?1:0}})());U(this,"convexHeightfield",(()=>{var t=this;return function(e,n,i,r,o,a,c,l,h){h===void 0&&(h=!1);const u=a.heights,d=a.elementWidth,p=ey,x=ny,g=iy,m=sy;let f=Math.floor((e.aabb.lowerBound[0]-c[0])/d),y=Math.ceil((e.aabb.upperBound[0]-c[0])/d);f<0&&(f=0),y>=u.length&&(y=u.length-1);let v=u[f],b=u[y];for(let M=f;M<y;M++)u[M]<b&&(b=u[M]),u[M]>v&&(v=u[M]);if(e.aabb.lowerBound[1]>v)return 0;let _=0;for(let M=f;M<y;M++){Kt(p,M*d,u[M]),Kt(x,(M+1)*d,u[M+1]),_t(p,p,c),_t(x,x,c);const T=100;Kt(g,(x[0]+p[0])*.5,(x[1]+p[1]-T)*.5),nt(m.vertices[0],x,g),nt(m.vertices[1],p,g),$t(m.vertices[2],m.vertices[1]),$t(m.vertices[3],m.vertices[0]),m.vertices[2][1]-=T,m.vertices[3][1]-=T,m.updateNormals(),_+=t.convexConvex(e,n,i,r,o,m,g,0,h)}return _}})());U(this,"narrowphases",{[yt.CONVEX|yt.LINE]:this.convexLine,[yt.LINE|yt.BOX]:this.lineBox,[yt.CONVEX|yt.CAPSULE]:this.convexCapsule,[yt.BOX|yt.CAPSULE]:this.convexCapsule,[yt.LINE|yt.CAPSULE]:this.lineCapsule,[yt.CAPSULE]:this.capsuleCapsule,[yt.LINE]:this.lineLine,[yt.PLANE|yt.LINE]:this.planeLine,[yt.PARTICLE|yt.CAPSULE]:this.particleCapsule,[yt.CIRCLE|yt.LINE]:this.circleLine,[yt.CIRCLE|yt.CAPSULE]:this.circleCapsule,[yt.CIRCLE|yt.CONVEX]:this.circleConvex,[yt.CIRCLE|yt.BOX]:this.circleConvex,[yt.PARTICLE|yt.CONVEX]:this.particleConvex,[yt.PARTICLE|yt.BOX]:this.particleConvex,[yt.CIRCLE]:this.circleCircle,[yt.PLANE|yt.CONVEX]:this.planeConvex,[yt.PLANE|yt.BOX]:this.planeConvex,[yt.PARTICLE|yt.PLANE]:this.particlePlane,[yt.CIRCLE|yt.PARTICLE]:this.circleParticle,[yt.PLANE|yt.CAPSULE]:this.planeCapsule,[yt.CIRCLE|yt.PLANE]:this.circlePlane,[yt.CONVEX]:this.convexConvex,[yt.CONVEX|yt.BOX]:this.convexConvex,[yt.BOX]:this.convexConvex,[yt.CIRCLE|yt.HEIGHTFIELD]:this.circleHeightfield,[yt.BOX|yt.HEIGHTFIELD]:this.convexHeightfield,[yt.CONVEX|yt.HEIGHTFIELD]:this.convexHeightfield});this.contactEquations=[],this.frictionEquations=[],this.enableFriction=!0,this.enabledEquations=!0,this.slipForce=10,this.contactEquationPool=new hM({size:32}),this.frictionEquationPool=new uM({size:64}),this.enableFrictionReduction=!0,this.collidingBodiesLastStep=new na,this.currentContactMaterial=null}bodiesOverlap(t,e,n){const i=pM,r=mM;for(let o=0,a=t.shapes.length;o!==a;o++){const c=t.shapes[o];for(let l=0,h=e.shapes.length;l!==h;l++){const u=e.shapes[l];if(n&&!((c.collisionGroup&u.collisionMask)!==0&&(u.collisionGroup&c.collisionMask)!==0))return!1;if(t.toWorldFrame(i,c.position),e.toWorldFrame(r,u.position),c.type<=u.type){if(this.narrowphases[c.type|u.type](t,c,i,c.angle+t.angle,e,u,r,u.angle+e.angle,!0))return!0}else if(this.narrowphases[c.type|u.type](e,u,r,u.angle+e.angle,t,c,i,c.angle+t.angle,!0))return!0}}return!1}collidedLastStep(t,e){const n=t.id|0,i=e.id|0;return!!this.collidingBodiesLastStep.get(n,i)}reset(){this.collidingBodiesLastStep.reset();const t=this.contactEquations;let e=t.length;for(;e--;){const r=t[e],o=r.bodyA.id,a=r.bodyB.id;this.collidingBodiesLastStep.set(o,a,!0)}const n=this.contactEquations,i=this.frictionEquations;for(let r=0;r<n.length;r++)this.contactEquationPool.release(n[r]);for(let r=0;r<i.length;r++)this.frictionEquationPool.release(i[r]);this.contactEquations.length=this.frictionEquations.length=0}createContactEquation(t,e,n,i){const r=this.contactEquationPool.get(),o=this.currentContactMaterial;return r.bodyA=t,r.bodyB=e,r.shapeA=n,r.shapeB=i,r.enabled=this.enabledEquations,r.firstImpact=!this.collidedLastStep(t,e),r.restitution=o.restitution,r.stiffness=o.stiffness,r.relaxation=o.relaxation,r.offset=o.contactSkinSize,r.needsUpdate=!0,r}createFrictionEquation(t,e,n,i){const r=this.frictionEquationPool.get(),o=this.currentContactMaterial;return r.bodyA=t,r.bodyB=e,r.shapeA=n,r.shapeB=i,r.setSlipForce(this.slipForce),r.enabled=this.enabledEquations,r.frictionCoefficient=o.friction,r.relativeVelocity=o.surfaceVelocity,r.stiffness=o.frictionStiffness,r.relaxation=o.frictionRelaxation,r.needsUpdate=!0,r.contactEquations.length=0,r}createFrictionFromContact(t){const e=this.createFrictionEquation(t.bodyA,t.bodyB,t.shapeA,t.shapeB);return $t(e.contactPointA,t.contactPointA),$t(e.contactPointB,t.contactPointB),rs(e.t,t.normalA),e.contactEquations.push(t),e}createFrictionFromAverage(t){let e=this.contactEquations[this.contactEquations.length-1];const n=this.createFrictionEquation(e.bodyA,e.bodyB,e.shapeA,e.shapeB),i=e.bodyA;Kt(n.contactPointA,0,0),Kt(n.contactPointB,0,0),Kt(n.t,0,0);for(let o=0;o!==t;o++)e=this.contactEquations[this.contactEquations.length-1-o],e.bodyA===i?(_t(n.t,n.t,e.normalA),_t(n.contactPointA,n.contactPointA,e.contactPointA),_t(n.contactPointB,n.contactPointB,e.contactPointB)):(nt(n.t,n.t,e.normalA),_t(n.contactPointA,n.contactPointA,e.contactPointB),_t(n.contactPointB,n.contactPointB,e.contactPointA)),n.contactEquations.push(e);const r=1/t;return It(n.contactPointA,n.contactPointA,r),It(n.contactPointB,n.contactPointB,r),be(n.t,n.t),rs(n.t,n.t),n}}const zo=ln(0,1),si=N(),es=N(),Os=N(),yr=N(),Sr=N(),Er=N(),Vo=N(),_c=N(),Md=N(),yd=N(),Sd=N(),fM=N(),vc=N(),bc=N(),Ed=N(),Ad=[],pM=N(),mM=N(),xM=N(),gM=N(),_M=N(),vM=N(),bM=N(),MM=N(),yM=N(),SM=N(),EM=N(),AM=N(),wM=N(),TM=[N(),N()],CM=[N(),N()],RM=[N(),N()],PM=2,LM=N(),DM=N(),IM=N(),UM=N(),FM=N(),NM=N(),OM=N();function Mc(s,t){const e=t.radius,n=t.length*.5,i=s.vertices;Kt(i[0],-n,-e),Kt(i[1],n,-e),Kt(i[2],n,e),Kt(i[3],-n,e)}const BM=new ma({width:1,height:1}),zM=N(),VM=N(),kM=N(),GM=new ma({width:1,height:1}),HM=N(),If=N(),Uf=N();function WM(s,t,e,n){const i=HM,r=If,o=Uf,a=t.vertices;let c=null;Gi(i,s,e,n);for(let l=0,h=a.length;l!==h+1;l++){const u=a[l%h],d=a[(l+1)%h];nt(r,u,i),nt(o,d,i);const p=Zn(r,o);if(c===null&&(c=p),p*c<0)return!1;c=p}return!0}function wd(s,t,e,n){s[0]=t[0]+e[0]-n[0],s[1]=t[1]+e[1]-n[1]}function XM(s,t){const e=If,n=Uf,i=t.vertices,r=i.length;let o=null;for(let a=0;a<r+1;a++){const c=i[a%r],l=i[(a+1)%r];nt(e,c,s),nt(n,l,s);const h=Zn(e,n);if(o===null&&(o=h),h*o<0)return!1;o=h}return!0}const qM=new eh({radius:1}),YM=N(),$M=N(),KM=N(),ZM=N(),jM=N(),JM=N();function Td(s,t,e,n,i,r,o){const a=t.vertices.length,c=i.vertices.length,l=t.normals,h=t.vertices,u=i.vertices,d=KM,p=ZM,x=jM,g=JM,m=n-o;let f=0,y=-Number.MAX_VALUE;for(let v=0;v<a;++v){Ve(d,l[v],m),Ae(g,h[v],e,n),Gi(p,g,r,o);let b=Number.MAX_VALUE;for(let _=0;_<c;++_){nt(x,u[_],p);const M=ae(d,x);M<b&&(b=M)}b>y&&(y=b,f=v)}return s[0]=y,f}const QM=N();function ty(s,t,e,n,i,r,o,a){const c=t.normals,l=r.vertices.length,h=r.vertices,u=r.normals,d=QM;Ve(d,c[i],n-a);let p=0,x=Number.MAX_VALUE;for(let f=0;f<l;++f){const y=ae(d,u[f]);y<x&&(x=y,p=f)}const g=p,m=g+1<l?g+1:0;Ae(s[0],h[g],o,a),Ae(s[1],h[m],o,a)}function Cd(s,t,e,n){let i=0;const r=ae(e,t[0])-n,o=ae(e,t[1])-n;if(r<=0&&$t(s[i++],t[0]),o<=0&&$t(s[i++],t[1]),r*o<0){const a=r/(r-o),c=s[i];nt(c,t[1],t[0]),It(c,c,a),_t(c,c,t[0]),++i}return i}const ey=N(),ny=N(),iy=N(),sy=new ms({vertices:[N(),N(),N(),N()]});class ry extends Fr{constructor(){super(Fr.SAP);U(this,"axisList",[]);U(this,"axisIndex",0);this.addBodyHandler=e=>{this.axisList.push(e.body)},this.removeBodyHandler=e=>{const n=this.axisList.indexOf(e.body);n!==-1&&this.axisList.splice(n,1)}}setWorld(e){this.axisList.length=0,ta(this.axisList,e.bodies),e.off("addBody",this.addBodyHandler).off("removeBody",this.removeBodyHandler),e.on("addBody",this.addBodyHandler).on("removeBody",this.removeBodyHandler),this.world=e}sortList(){const e=this.axisList,n=this.axisIndex;oy(e,n)}getCollisionPairs(e){const n=this.axisList,i=this.result,r=this.axisIndex;i.length=0;let o=n.length;for(;o--;){const a=n[o];a.aabbNeedsUpdate&&a.updateAABB()}this.sortList();for(let a=0,c=n.length|0;a!==c;a++){const l=n[a];for(let h=a+1;h<c;h++){const u=n[h];if(!(u.aabb.lowerBound[r]<=l.aabb.upperBound[r]))break;Fr.canCollide(l,u)&&this.boundingVolumeCheck(l,u)&&i.push(l,u)}}return i}aabbQuery(e,n,i){i===void 0&&(i=[]),this.sortList();const r=this.axisList;for(let o=0;o<r.length;o++){const a=r[o];a.aabbNeedsUpdate&&a.updateAABB(),a.aabb.overlaps(n)&&i.push(a)}return i}}function oy(s,t){t=t|0;for(let e=1,n=s.length;e<n;e++){const i=s[e];let r;for(r=e-1;r>=0&&!(s[r].aabb.lowerBound[t]<=i.aabb.lowerBound[t]);r--)s[r+1]=s[r];s[r+1]=i}return s}N();N();N();N();N();N();ln(1,0);ln(0,1);N();N();ln(1,0);ln(0,1);N();N();N();N();N();N();N();N();ln(1,0);ln(0,1);N();const ga=class ga{constructor(){this.id=ga.idCounter++}};U(ga,"idCounter",0);let Yr=ga;const _a=class _a{constructor(t,e,n){if(n===void 0&&(n={}),!(t instanceof Yr)||!(e instanceof Yr))throw new Error("First two arguments must be Material instances.");this.id=_a.idCounter++,this.materialA=t,this.materialB=e,this.friction=n.friction??.3,this.restitution=n.restitution??0,this.stiffness=n.stiffness??Oi.DEFAULT_STIFFNESS,this.relaxation=n.relaxation??Oi.DEFAULT_RELAXATION,this.frictionStiffness=n.frictionStiffness??Oi.DEFAULT_STIFFNESS,this.frictionRelaxation=n.frictionRelaxation??Oi.DEFAULT_RELAXATION,this.surfaceVelocity=n.surfaceVelocity??0,this.contactSkinSize=.005}};U(_a,"idCounter",0);let Rl=_a;N();N();N();N();N();N();N();N();N();N();N();N();N();N();N();N();N();ln(0,1);N(),N(),N(),N();N();N();N();N();N();N(),N();N();N();N();ln(0,1);N();N();N();class yc{constructor(t,e){t===void 0&&(t={}),this.type=e,this.equations=[],this.equationSortFunction=t.equationSortFunction}sortEquations(){this.equationSortFunction&&this.equations.sort(this.equationSortFunction)}addEquation(t){t.enabled&&this.equations.push(t)}addEquations(t){for(let e=0,n=t.length;e!==n;e++){const i=t[e];i.enabled&&this.equations.push(i)}}removeEquation(t){const e=this.equations.indexOf(t);e!==-1&&this.equations.splice(e,1)}removeAllEquations(){this.equations.length=0}}class ay extends yc{constructor(e){e===void 0&&(e={});super(e,yc.GS);U(this,"type",yc.GS);this.iterations=e.iterations??10,this.tolerance=e.tolerance??1e-7,this.frictionIterations=e.frictionIterations??0,this.usedIterations=0}solve(e,n){this.sortEquations();let i=0;const r=this.iterations,o=this.frictionIterations,a=this.equations,c=a.length,l=Math.pow(this.tolerance*c,2),h=n.bodies,u=h.length;if(this.usedIterations=0,c)for(let m=0;m!==u;m++)h[m].updateSolveMassProperties();for(let m=0;m!==c;m++){const f=a[m];f.lambda=0,(f.timeStep!==e||f.needsUpdate)&&(f.timeStep=e,f.update()),f.B=f.computeB(f.a,f.b,e),f.invC=f.computeInvC(f.epsilon),f.maxForceDt=f.maxForce*e,f.minForceDt=f.minForce*e}let d,p,x,g;if(c!==0){for(x=0;x!==u;x++)h[x].resetConstraintVelocity();if(o){for(i=0;i!==o;i++){for(p=0,g=0;g!==c;g++){d=a[g];const m=Pd(d);p+=Math.abs(m)}if(this.usedIterations++,p*p<=l)break}for(Rd(a,1/e),g=0;g!==c;g++){const m=a[g];if(m instanceof Df){let f=0;for(let y=0;y!==m.contactEquations.length;y++)f+=m.contactEquations[y].multiplier;f*=m.frictionCoefficient/m.contactEquations.length,m.maxForce=f,m.minForce=-f,m.maxForceDt=f*e,m.minForceDt=-f*e}}}for(i=0;i!==r;i++){for(p=0,g=0;g!==c;g++){d=a[g];const m=Pd(d);p+=Math.abs(m)}if(this.usedIterations++,p*p<l)break}for(x=0;x!==u;x++)h[x].addConstraintVelocity();Rd(a,1/e)}}}function Rd(s,t){let e=s.length;for(;e--;){const n=s[e];n.multiplier=n.lambda*t}}function Pd(s){const t=s.B,e=s.epsilon,n=s.invC,i=s.lambda,r=s.computeGWlambda(),o=s.maxForceDt,a=s.minForceDt;let c=n*(t-r-e*i);const l=i+c;return l<a?c=a-i:l>o&&(c=o-i),s.lambda+=c,s.addToWlambda(c),c}class cy{constructor(t,e,n,i){this.bodyA=t,this.shapeA=e,this.bodyB=n,this.shapeB=i}set(t,e,n,i){this.bodyA=t,this.shapeA=e,this.bodyB=n,this.shapeB=i}}class ly extends nh{create(){return new cy(Ec,Sc,Ec,Sc)}destroy(t){return t.bodyA=t.bodyB=Ec,t.shapeA=t.shapeB=Sc,this}}const Sc=new eh({radius:1}),Ec=new jt;class hy{constructor(){this.overlappingShapesLastState=new na,this.overlappingShapesCurrentState=new na,this.recordPool=new ly({size:16}),this.tmpDict=new na,this.tmpArray1=[]}tick(){const t=this.overlappingShapesLastState,e=this.overlappingShapesCurrentState;let n=t.keys.length;for(;n--;){const i=t.keys[n],r=t.getByKey(i);r&&this.recordPool.release(r)}t.copy(e),e.reset()}bodiesAreOverlapping(t,e){const n=this.overlappingShapesCurrentState;let i=n.keys.length;for(;i--;){const r=n.keys[i],o=n.data[r];if(o.bodyA===t&&o.bodyB===e||o.bodyA===e&&o.bodyB===t)return!0}return!1}setOverlapping(t,e,n,i){const r=this.overlappingShapesCurrentState;if(!r.get(e.id,i.id)){const o=this.recordPool.get();o.set(t,e,n,i),r.set(e.id,i.id,o)}}getNewOverlaps(t){return this.getDiff(this.overlappingShapesLastState,this.overlappingShapesCurrentState,t)}getEndOverlaps(t){return this.getDiff(this.overlappingShapesCurrentState,this.overlappingShapesLastState,t)}getDiff(t,e,n){n===void 0&&(n=[]);const i=t,r=e;n.length=0;let o=r.keys.length;for(;o--;){const a=r.keys[o],c=r.data[a];if(!c)throw new Error("Key "+a+" had no data!");i.data[a]||n.push(c)}return n}isNewOverlap(t,e){const n=t.id|0,i=e.id|0,r=this.overlappingShapesLastState,o=this.overlappingShapesCurrentState;return!r.get(n,i)&&!!o.get(n,i)}getNewBodyOverlaps(t){this.tmpArray1.length=0;const e=this.getNewOverlaps(this.tmpArray1);return this.getBodyDiff(e,t)}getEndBodyOverlaps(t){this.tmpArray1.length=0;const e=this.getEndOverlaps(this.tmpArray1);return this.getBodyDiff(e,t)}getBodyDiff(t,e){e===void 0&&(e=[]);const n=this.tmpDict;let i=t.length;for(;i--;){const r=t[i];n.set(r.bodyA.id|0,r.bodyB.id|0,r)}for(i=n.keys.length;i--;){const r=n.getByKey(n.keys[i]);r&&e.push(r.bodyA,r.bodyB)}return n.reset(),e}}class uy{constructor(t){U(this,"id",[]);U(this,"sz",[]);this.size=t,this.count=t,this.resize(t)}resize(t){this.count=this.size=t;const e=this.sz,n=this.id;for(let i=0;i<t;i++)n[i]=i,e[i]=1}find(t){const e=this.id;for(;t!==e[t];)e[t]=e[e[t]],t=e[t];return t}union(t,e){const n=this.find(t),i=this.find(e);if(n===i)return;const r=this.sz,o=this.id;r[n]<r[i]?(o[n]=i,r[i]+=r[n]):(o[i]=n,r[n]+=r[i]),this.count--}}const Ii=class Ii extends Lf{constructor(e){e===void 0&&(e={});super();U(this,"springs",[]);U(this,"bodies",[]);U(this,"hasActiveBodies",!1);U(this,"narrowphase",new dM);U(this,"useWorldGravityAsFrictionGravity",!0);U(this,"useFrictionGravityOnZeroGravity",!0);U(this,"constraints",[]);U(this,"lastTimeStep",1/60);U(this,"applySpringForces",!0);U(this,"applyDamping",!0);U(this,"applyGravity",!0);U(this,"solveConstraints",!0);U(this,"contactMaterials",[]);U(this,"time",0);U(this,"accumulator",0);U(this,"stepping",!1);U(this,"emitImpactEvent",!0);U(this,"sleepMode",Ii.NO_SLEEPING);U(this,"overlapKeeper",new hy);U(this,"disabledBodyCollisionPairs",[]);U(this,"unionFind",new uy(1));this.solver=e.solver||new ay,this.gravity=ln(0,-9.78),e.gravity&&$t(this.gravity,e.gravity),this.frictionGravity=Xr(this.gravity)||10,this.broadphase=e.broadphase||new ry,this.broadphase.setWorld(this),this.defaultMaterial=new Yr,this.defaultContactMaterial=new Rl(this.defaultMaterial,this.defaultMaterial),this.islandSplit=e.islandSplit??!0}addConstraint(e){if(this.stepping)throw new Error("Constraints cannot be added during step.");const n=this.bodies;if(n.indexOf(e.bodyA)===-1)throw new Error("Cannot add Constraint: bodyA is not added to the World.");if(n.indexOf(e.bodyB)===-1)throw new Error("Cannot add Constraint: bodyB is not added to the World.");this.constraints.push(e)}addContactMaterial(e){this.contactMaterials.push(e)}removeContactMaterial(e){Do(this.contactMaterials,e)}getContactMaterial(e,n){const i=this.contactMaterials;for(let r=0,o=i.length;r!==o;r++){const a=i[r];if(a.materialA===e&&a.materialB===n||a.materialA===n&&a.materialB===e)return a}return!1}removeConstraint(e){if(this.stepping)throw new Error("Constraints cannot be removed during step.");Do(this.constraints,e)}step(e,n,i){if(i===void 0&&(i=10),n===void 0)this.internalStep(e),this.time+=e;else{this.accumulator+=n;let r=0;for(;this.accumulator>=e&&r<i;)this.internalStep(e),this.time+=e,this.accumulator-=e,r++;const o=this.accumulator%e/e;for(let a=0;a!==this.bodies.length;a++){const c=this.bodies[a];Dr(c.interpolatedPosition,c.previousPosition,c.position,o),c.interpolatedAngle=c.previousAngle+o*(c.angle-c.previousAngle)}}}internalStep(e){this.stepping=!0;const n=this.springs.length,i=this.springs,r=this.bodies,o=this.gravity,a=this.solver,c=this.bodies.length,l=this.broadphase,h=this.narrowphase,u=this.constraints,d=my,p=_t;if(this.overlapKeeper.tick(),this.lastTimeStep=e,this.useWorldGravityAsFrictionGravity){const b=Xr(this.gravity);b===0&&this.useFrictionGravityOnZeroGravity||(this.frictionGravity=b)}if(this.applyGravity)for(let b=0;b!==c;b++){const _=r[b],M=_.force;_.type!==jt.DYNAMIC||_.sleepState===jt.SLEEPING||(It(d,o,_.mass*_.gravityScale),p(M,M,d))}if(this.applySpringForces)for(let b=0;b!==n;b++)i[b].applyForce();if(this.applyDamping)for(let b=0;b!==c;b++){const _=r[b];_.type===jt.DYNAMIC&&_.applyDamping(e)}const x=l.getCollisionPairs(this),g=this.disabledBodyCollisionPairs;for(let b=g.length-2;b>=0;b-=2)for(let _=x.length-2;_>=0;_-=2)(g[b]===x[_]&&g[b+1]===x[_+1]||g[b+1]===x[_]&&g[b]===x[_+1])&&x.splice(_,2);let m=u.length;for(let b=0;b!==m;b++){const _=u[b];if(!_.collideConnected)for(let M=x.length-2;M>=0;M-=2)(_.bodyA===x[M]&&_.bodyB===x[M+1]||_.bodyB===x[M]&&_.bodyA===x[M+1])&&x.splice(M,2)}this.emit({type:"postBroadphase",pairs:x}),h.reset();const f=this.defaultContactMaterial,y=this.frictionGravity;for(let b=0,_=x.length;b!==_;b+=2){const M=x[b],T=x[b+1];for(let P=0,A=M.shapes.length;P!==A;P++){const E=M.shapes[P],R=E.position,I=E.angle;for(let z=0,X=T.shapes.length;z!==X;z++){const H=T.shapes[z],K=H.position,G=H.angle;let V=!1;E.material&&H.material&&(V=this.getContactMaterial(E.material,H.material)),py(this,h,M,E,R,I,T,H,K,G,V||f,y)}}}for(let b=0;b!==c;b++){const _=r[b];_._wakeUpAfterNarrowphase&&(_.wakeUp(),_._wakeUpAfterNarrowphase=!1)}if(this.has("endContact")){this.overlapKeeper.getEndOverlaps(Ho);let b=Ho.length;for(;b--;){const _=Ho[b],M={type:"endContact",shapeA:_.shapeA,shapeB:_.shapeB,bodyA:_.bodyA,bodyB:_.bodyB};this.emit(M)}Ho.length=0}this.emit({type:"preSolve",contactEquations:h.contactEquations,frictionEquations:h.frictionEquations}),m=u.length;for(let b=0;b!==m;b++)u[b].update();if(h.contactEquations.length||h.frictionEquations.length||m){let b=[];ta(b,h.contactEquations),ta(b,h.frictionEquations);for(let _=0;_!==m;_++)ta(b,u[_].equations);if(this.islandSplit){const _=this.unionFind;_.resize(this.bodies.length+1);for(let T=0;T<b.length;T++)b[T].index=T;for(let T=0;T<b.length;T++){const P=b[T].bodyA,A=b[T].bodyB;P.type===jt.DYNAMIC&&A.type===jt.DYNAMIC&&_.union(P.index,A.index)}for(let T=0;T<r.length;T++){const P=r[T];P.islandId=P.type===jt.DYNAMIC?_.find(P.index):-1}b=b.sort(fy);let M=0;for(;M<b.length;){const T=b[M++];a.addEquation(T);const P=T.bodyA.islandId>0?T.bodyA.islandId:T.bodyB.islandId;let A=-1;b[M]&&(A=b[M].bodyA.islandId>0?b[M].bodyA.islandId:b[M].bodyB.islandId),(A!==P||M===b.length)&&(this.solveConstraints&&a.solve(e,this),a.removeAllEquations())}}else a.addEquations(b),this.solveConstraints&&a.solve(e,this),a.removeAllEquations()}for(let b=0;b!==c;b++){const _=r[b];(_.type===jt.DYNAMIC||_.type===jt.KINEMATIC)&&_.integrate(e)}for(let b=0;b!==c;b++)r[b].setZeroForce();if(this.emitImpactEvent&&this.has("impact"))for(let b=0;b!==h.contactEquations.length;b++){const _=h.contactEquations[b];_.firstImpact&&this.emit({type:"impact",bodyA:_.bodyA,bodyB:_.bodyB,shapeA:_.shapeA,shapeB:_.shapeB,contactEquation:_})}let v=!0;if(this.sleepMode===Ii.BODY_SLEEPING){v=!1;for(let b=0;b!==c;b++){const _=r[b];_.sleepTick(this.time,!1,e),_.sleepState!==jt.SLEEPING&&_.type!==jt.STATIC&&(v=!0)}}else if(this.sleepMode===Ii.ISLAND_SLEEPING&&this.islandSplit){for(let M=0;M!==c;M++)r[M].sleepTick(this.time,!0,e);const b=r.sort(dy);let _=1;for(let M=0;M<b.length;M=_){const T=b[M].islandId;for(_=M+1;_<b.length&&b[_].islandId===T;_++);if(T===-1)continue;let P=!0;for(let A=M;A<_;A++)if(!b[A].wantsToSleep){P=!1;break}if(P)for(let A=M;A<_;A++)b[A].sleep()}v=!1;for(let M=0;M!==c;M++){const T=r[M];if(T.sleepState!==jt.SLEEPING&&T.type!==jt.STATIC){v=!0;break}}}this.hasActiveBodies=v,this.stepping=!1,this.emit({type:"postStep"})}addSpring(e){if(this.stepping)throw new Error("Springs cannot be added during step.");this.springs.push(e),this.emit({type:"addSpring",spring:e})}removeSpring(e){if(this.stepping)throw new Error("Springs cannot be removed during step.");Do(this.springs,e),this.emit({type:"removeSpring",spring:e})}addBody(e){if(this.stepping)throw new Error("Bodies cannot be added during step.");if(e.world)throw new Error("Body is already added to a World.");e.index=this.bodies.length,this.bodies.push(e),e.world=this,this.emit({type:"addBody",body:e})}removeBody(e){if(this.stepping)throw new Error("Bodies cannot be removed during step.");const n=this.constraints;let i=n.length;for(;i--;)if(n[i].bodyA===e||n[i].bodyB===e)throw new Error("Cannot remove Body from World: it still has constraints connected to it.");e.world=null;const r=this.bodies;for(Do(r,e),e.index=-1,i=r.length;i--;)r[i].index=i;e.resetConstraintVelocity(),this.emit({type:"removeBody",body:e});const o=this.disabledBodyCollisionPairs;let a=0;for(;a<o.length;)o[a]===e||o[a+1]===e?o.splice(a,2):a+=2}getBodyByID(e){const n=this.bodies;for(let i=0;i<n.length;i++){const r=n[i];if(r.id===e)return r}return!1}disableBodyCollision(e,n){this.disabledBodyCollisionPairs.push(e,n)}enableBodyCollision(e,n){const i=this.disabledBodyCollisionPairs;for(let r=0;r<i.length;r+=2)if(i[r]===e&&i[r+1]===n||i[r+1]===e&&i[r]===n){i.splice(r,2);return}}clear(){this.solver.removeAllEquations();const e=this.constraints;let n=e.length;for(;n--;)this.removeConstraint(e[n]);const i=this.bodies;for(n=i.length;n--;)this.removeBody(i[n]);const r=this.springs;for(n=r.length;n--;)this.removeSpring(r[n]);const o=this.contactMaterials;for(n=o.length;n--;)this.removeContactMaterial(o[n])}hitTest(e,n,i){i===void 0&&(i=0);const r=xy,o=gy,a=[];for(let c=0,l=n.length;c!==l;c++){const h=n[c];for(let u=0,d=h.shapes.length;u!==d;u++){const p=h.shapes[u];p.worldPointToLocal(o,e),p.pointTest(o)?a.push(h):(Ve(r,p.position,h.angle),_t(r,r,h.position),p.type===yt.PARTICLE&&Ql(r,e)<i*i&&a.push(h))}}return a}setGlobalStiffness(e){this.setGlobalEquationParameters({stiffness:e});const n=this.contactMaterials;for(let r=0;r!==n.length;r++){const o=n[r];o.stiffness=o.frictionStiffness=e}const i=this.defaultContactMaterial;i.stiffness=i.frictionStiffness=e}setGlobalRelaxation(e){this.setGlobalEquationParameters({relaxation:e});for(let i=0;i!==this.contactMaterials.length;i++){const r=this.contactMaterials[i];r.relaxation=r.frictionRelaxation=e}const n=this.defaultContactMaterial;n.relaxation=n.frictionRelaxation=e}raycast(e,n){return n.getAABB(Ld),this.broadphase.aabbQuery(this,Ld,Ac),n.intersectBodies(e,Ac),Ac.length=0,e.hasHit()}setGlobalEquationParameters(e){const n=this.constraints;for(let i=0;i!==n.length;i++){const o=n[i].equations;for(let a=0;a!==o.length;a++){const c=o[a];c.relaxation=e.relaxation??c.relaxation,c.stiffness=e.stiffness??c.stiffness,c.needsUpdate=!0}}}};U(Ii,"NO_SLEEPING",1),U(Ii,"BODY_SLEEPING",2),U(Ii,"ISLAND_SLEEPING",4);let xa=Ii;function dy(s,t){return s.islandId-t.islandId}function fy(s,t){const e=s.bodyA.islandId>0?s.bodyA.islandId:s.bodyB.islandId,n=t.bodyA.islandId>0?t.bodyA.islandId:t.bodyB.islandId;return e!==n?e-n:s.index-t.index}function py(s,t,e,n,i,r,o,a,c,l,h,u){if(!((n.collisionGroup&a.collisionMask)!==0&&(a.collisionGroup&n.collisionMask)!==0)||(Ae(ko,i,e.position,e.angle),Ae(Go,c,o.position,o.angle),Jl(ko,Go)>n.boundingRadius+a.boundingRadius))return;const d=r+e.angle,p=l+o.angle;t.enableFriction=h.friction>0;let x;e.type===jt.STATIC||e.type===jt.KINEMATIC?x=o.mass:o.type===jt.STATIC||o.type===jt.KINEMATIC?x=e.mass:x=e.mass*o.mass/(e.mass+o.mass),t.slipForce=h.friction*u*x,t.currentContactMaterial=h,t.enabledEquations=e.collisionResponse&&o.collisionResponse&&n.collisionResponse&&a.collisionResponse;const g=t.narrowphases[n.type|a.type];let m=0;if(g){const f=n.sensor||a.sensor,y=t.frictionEquations.length;n.type<a.type?m=g.call(t,e,n,ko,d,o,a,Go,p,f):m=g.call(t,o,a,Go,p,e,n,ko,d,f);const v=t.frictionEquations.length-y;if(m){if(e.allowSleep&&e.type===jt.DYNAMIC&&e.sleepState===jt.SLEEPING&&o.sleepState===jt.AWAKE&&o.type!==jt.STATIC){const b=Cn(o.velocity)+Math.pow(o.angularVelocity,2),_=Math.pow(o.sleepSpeedLimit,2);b>=_*2&&(e._wakeUpAfterNarrowphase=!0)}if(o.allowSleep&&o.type===jt.DYNAMIC&&o.sleepState===jt.SLEEPING&&e.sleepState===jt.AWAKE&&e.type!==jt.STATIC){const b=Cn(e.velocity)+Math.pow(e.angularVelocity,2),_=Math.pow(e.sleepSpeedLimit,2);b>=_*2&&(o._wakeUpAfterNarrowphase=!0)}if(s.overlapKeeper.setOverlapping(e,n,o,a),s.has("beginContact")&&s.overlapKeeper.isNewOverlap(n,a)){const b=[];if(!f)for(let _=t.contactEquations.length-m;_<t.contactEquations.length;_++)b.push(t.contactEquations[_]);s.emit({type:"beginContact",shapeA:n,shapeB:a,bodyA:e,bodyB:o,contactEquations:b})}if(!f&&v>1)for(let b=t.frictionEquations.length-v;b<t.frictionEquations.length;b++){const _=t.frictionEquations[b];_.setSlipForce(_.getSlipForce()/v)}}}}const Ld=new th,Ac=[],my=N(),ko=N(),Go=N(),Ho=[],xy=N(),gy=N(),_y=1/600,vy=40,by=8,My=100,yy=.5,Sy=1e3,Ey=100,Ay=0,wy=1e5,Ty=10,Cy=1,Ry=1;class Py{constructor(){U(this,"p2World",new xa({gravity:[0,My]}));U(this,"activeTime",0);U(this,"level");this.p2World.defaultContactMaterial.friction=yy,this.p2World.defaultContactMaterial.frictionStiffness=Sy,this.p2World.defaultContactMaterial.frictionRelaxation=Ey,this.p2World.defaultContactMaterial.restitution=Ay,this.p2World.defaultContactMaterial.stiffness=wy,this.p2World.defaultContactMaterial.relaxation=Ty,this.p2World.sleepMode=xa.ISLAND_SLEEPING}update(t,e){const n=t/1e3;this.p2World.step(_y,n,vy),this.activeTime+=n;for(const i of this.p2World.bodies){const r=i.ttDatum;if(!r)continue;const{boxIndex:o}=r;if(o===this.level.targetBoxIndex&&!e.isToppled&&!e.isFailed){const a=i.interpolatedPosition,c=i.interpolatedAngle;if(a[1]>this.level.bounds[4]||Math.abs(c)>ci)return"passed";if(this.activeTime>by&&i.velocity[0]<.001&&i.velocity[1]<.001)return"failed"}}}reset(t,e,n,i){this.level=t;const r=e.flatDirection;this.activeTime=0,this.p2World.clear();let o=0;for(const a of Object.keys(t.sideViews[r])){const c=Number(a);for(const[y,v]of t.sideViews[r][c].entries()){if(c===n&&y===i)continue;const b=new ma({width:v.worldRect[2],height:v.worldRect[3]}),_=new jt({mass:v.worldRect[2]*v.worldRect[3]/100});_.allowSleep=!0,_.sleepSpeedLimit=Cy,_.sleepTimeLimit=Ry,_.addShape(b),_.position=hb(t,c,y,r);const M={boxIndex:c,rectIndex:y,meshIndex:o++};_.ttDatum=M,this.p2World.addBody(_)}const[l,h,u,d,p,x]=t.bounds,g=5,m=new ma({width:2e4,height:g}),f=new jt({mass:0});f.position=[d/2,p+g/2],f.addShape(m),this.p2World.addBody(f)}}}function Ly(s){return{getSetting:t=>hi.flatConfig[t],applySetting:(t,e)=>{t in hi.tree.children&&(hi.tree.children[t].value=e),hi.flatConfig[t]=e},getGameState:()=>s.state.isToppled?"level-passed":s.state.isActive?"simulation":s.graphics.camera.isFlat?"flat-view":"rotating",getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.cursorForTestSupport}),getCameraPos:()=>{const{x:t,y:e,z:n}=s.graphics.camera.camera.position;return[t,e,n]},locateElement(t){const e=t.split("-");if(e.length===3&&Wr.includes(e[0])){const i=e[0],r=Number(e[1]),o=Number(e[2]);if(s.state.flatDirection!==i)return;const a=s.level.sideViews[i],{worldRect:c}=a[r][o];return s.locateWorldRectOnScreen(c)}const n=[xn.create("playing-gui")];for(const i of n){const r=i.layoutRectangles[t];if(!r)continue;const[o,a,c,l]=r,h=1;return[o*h,a*h,c*h,l*h]}}}}class Dy{constructor(){U(this,"levelIndex",0);U(this,"flatDirection","N");U(this,"isEditor",!1);U(this,"isActive",!1);U(this,"activeTime",0);U(this,"isToppled",!1);U(this,"isFailed",!1)}startLevel(){this.isActive=!1,this.isToppled=!1,this.activeTime=0}passLevel(){this.isToppled=!0}failLevel(){this.isFailed=!0}startActive(t){this.isActive=!0,this.activeTime=0,this.isToppled=!1,this.isFailed=!1}}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class $n{constructor(t,e,n,i,r="div"){this.parent=t,this.object=e,this.property=n,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(r),this.domElement.classList.add("controller"),this.domElement.classList.add(i),this.$name=document.createElement("div"),this.$name.classList.add("name"),$n.nextNameID=$n.nextNameID||0,this.$name.id=`lil-gui-name-${++$n.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",o=>o.stopPropagation()),this.domElement.addEventListener("keyup",o=>o.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(n)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class Iy extends $n{constructor(t,e,n){super(t,e,n,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function Pl(s){let t,e;return(t=s.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=s.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=s.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const Uy={isPrimitive:!0,match:s=>typeof s=="string",fromHexString:Pl,toHexString:Pl},$r={isPrimitive:!0,match:s=>typeof s=="number",fromHexString:s=>parseInt(s.substring(1),16),toHexString:s=>"#"+s.toString(16).padStart(6,0)},Fy={isPrimitive:!1,match:s=>Array.isArray(s),fromHexString(s,t,e=1){const n=$r.fromHexString(s);t[0]=(n>>16&255)/255*e,t[1]=(n>>8&255)/255*e,t[2]=(n&255)/255*e},toHexString([s,t,e],n=1){n=255/n;const i=s*n<<16^t*n<<8^e*n<<0;return $r.toHexString(i)}},Ny={isPrimitive:!1,match:s=>Object(s)===s,fromHexString(s,t,e=1){const n=$r.fromHexString(s);t.r=(n>>16&255)/255*e,t.g=(n>>8&255)/255*e,t.b=(n&255)/255*e},toHexString({r:s,g:t,b:e},n=1){n=255/n;const i=s*n<<16^t*n<<8^e*n<<0;return $r.toHexString(i)}},Oy=[Uy,$r,Fy,Ny];function By(s){return Oy.find(t=>t.match(s))}class zy extends $n{constructor(t,e,n,i){super(t,e,n,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=By(this.initialValue),this._rgbScale=i,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const r=Pl(this.$text.value);r&&this._setValueFromHexString(r)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class wc extends $n{constructor(t,e,n){super(t,e,n,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",i=>{i.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class Vy extends $n{constructor(t,e,n,i,r,o){super(t,e,n,"number"),this._initInput(),this.min(i),this.max(r);const a=o!==void 0;this.step(a?o:this._getImplicitStep(),a),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let y=parseFloat(this.$input.value);isNaN(y)||(this._stepExplicit&&(y=this._snap(y)),this.setValue(this._clamp(y)))},n=y=>{const v=parseFloat(this.$input.value);isNaN(v)||(this._snapClampSetValue(v+y),this.$input.value=this.getValue())},i=y=>{y.key==="Enter"&&this.$input.blur(),y.code==="ArrowUp"&&(y.preventDefault(),n(this._step*this._arrowKeyMultiplier(y))),y.code==="ArrowDown"&&(y.preventDefault(),n(this._step*this._arrowKeyMultiplier(y)*-1))},r=y=>{this._inputFocused&&(y.preventDefault(),n(this._step*this._normalizeMouseWheel(y)))};let o=!1,a,c,l,h,u;const d=5,p=y=>{a=y.clientX,c=l=y.clientY,o=!0,h=this.getValue(),u=0,window.addEventListener("mousemove",x),window.addEventListener("mouseup",g)},x=y=>{if(o){const v=y.clientX-a,b=y.clientY-c;Math.abs(b)>d?(y.preventDefault(),this.$input.blur(),o=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(v)>d&&g()}if(!o){const v=y.clientY-l;u-=v*this._step*this._arrowKeyMultiplier(y),h+u>this._max?u=this._max-h:h+u<this._min&&(u=this._min-h),this._snapClampSetValue(h+u)}l=y.clientY},g=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",x),window.removeEventListener("mouseup",g)},m=()=>{this._inputFocused=!0},f=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",i),this.$input.addEventListener("wheel",r,{passive:!1}),this.$input.addEventListener("mousedown",p),this.$input.addEventListener("focus",m),this.$input.addEventListener("blur",f)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(f,y,v,b,_)=>(f-y)/(v-y)*(_-b)+b,e=f=>{const y=this.$slider.getBoundingClientRect();let v=t(f,y.left,y.right,this._min,this._max);this._snapClampSetValue(v)},n=f=>{this._setDraggingStyle(!0),e(f.clientX),window.addEventListener("mousemove",i),window.addEventListener("mouseup",r)},i=f=>{e(f.clientX)},r=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",i),window.removeEventListener("mouseup",r)};let o=!1,a,c;const l=f=>{f.preventDefault(),this._setDraggingStyle(!0),e(f.touches[0].clientX),o=!1},h=f=>{f.touches.length>1||(this._hasScrollBar?(a=f.touches[0].clientX,c=f.touches[0].clientY,o=!0):l(f),window.addEventListener("touchmove",u,{passive:!1}),window.addEventListener("touchend",d))},u=f=>{if(o){const y=f.touches[0].clientX-a,v=f.touches[0].clientY-c;Math.abs(y)>Math.abs(v)?l(f):(window.removeEventListener("touchmove",u),window.removeEventListener("touchend",d))}else f.preventDefault(),e(f.touches[0].clientX)},d=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",u),window.removeEventListener("touchend",d)},p=this._callOnFinishChange.bind(this),x=400;let g;const m=f=>{if(Math.abs(f.deltaX)<Math.abs(f.deltaY)&&this._hasScrollBar)return;f.preventDefault();const v=this._normalizeMouseWheel(f)*this._step;this._snapClampSetValue(this.getValue()+v),this.$input.value=this.getValue(),clearTimeout(g),g=setTimeout(p,x)};this.$slider.addEventListener("mousedown",n),this.$slider.addEventListener("touchstart",h,{passive:!1}),this.$slider.addEventListener("wheel",m,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:n}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,n=-t.wheelDelta/120,n*=this._stepExplicit?1:10),e+-n}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class ky extends $n{constructor(t,e,n,i){super(t,e,n,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(i)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const n=document.createElement("option");n.textContent=e,this.$select.appendChild(n)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class Gy extends $n{constructor(t,e,n){super(t,e,n,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",i=>{i.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var Hy=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function Wy(s){const t=document.createElement("style");t.innerHTML=s;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let Dd=!1;class ih{constructor({parent:t,autoPlace:e=t===void 0,container:n,width:i,title:r="Controls",closeFolders:o=!1,injectStyles:a=!0,touchStyles:c=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(r),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),c&&this.domElement.classList.add("allow-touch-styles"),!Dd&&a&&(Wy(Hy),Dd=!0),n?n.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),i&&this.domElement.style.setProperty("--width",i+"px"),this._closeFolders=o}add(t,e,n,i,r){if(Object(n)===n)return new ky(this,t,e,n);const o=t[e];switch(typeof o){case"number":return new Vy(this,t,e,n,i,r);case"boolean":return new Iy(this,t,e);case"string":return new Gy(this,t,e);case"function":return new wc(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,o)}addColor(t,e,n=1){return new zy(this,t,e,n)}addFolder(t){const e=new ih({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(n=>{n instanceof wc||n._name in t.controllers&&n.load(t.controllers[n._name])}),e&&t.folders&&this.folders.forEach(n=>{n._title in t.folders&&n.load(t.folders[n._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(n=>{if(!(n instanceof wc)){if(n._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${n._name}"`);e.controllers[n._name]=n.save()}}),t&&this.folders.forEach(n=>{if(n._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${n._title}"`);e.folders[n._title]=n.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const n=r=>{r.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",n))};this.$children.addEventListener("transitionend",n);const i=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=i+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(n=>n.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let Ll={},ns;function Xy(s){const t=Uv.tree;Ll={},ns&&ns.destroy(),ns=new ih({closeFolders:!0,container:document.getElementById("controls-container")}),Ff(ns,t,s),ns.onOpenClose(()=>{ns._closed&&setTimeout(()=>{ns.destroy()},200)})}function Ff(s,t,e){const n=t.children;for(const i in n){const r=n[i];if(!("isHidden"in r&&r.isHidden))if("action"in r){const o=r,a=r.label??Wo(i),c={[a]:async()=>{await o.action(e)}};s.add(c,a)}else if("options"in r&&Array.isArray(r.options)){const o=r,a={};for(const l of o.options)typeof l=="string"&&(a[l]=l);const c=s.add(o,"value",a).name(o.label??Wo(i)).listen();c.onChange(l=>{o.value=l,o.onChange&&o.onChange(e,l)}),Tc(c,o.tooltip),Ll[i]=c}else if("value"in r&&typeof r.value=="number"){const o=r,a=s.add(o,"value",o.min,o.max).name(o.label??Wo(i));o.step&&a.step(o.step),a.onChange(c=>{typeof c=="number"&&(o.value=c,o.onChange&&o.onChange(e,c))}),Tc(a,o.tooltip),Ll[i]=a}else{const o=s.addFolder(r.label??Wo(i));Tc(o,r.tooltip),Ff(o,r,e)}}}function Tc(s,t){if(typeof t!="string"||t.trim()==="")return;s.domElement.setAttribute("title",t)}function Wo(s){return/^[A-Z0-9_]+$/.test(s)?s.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():s.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}const is=new F,Xo=new F,qo=new F;function qy(s,t){const e=s.ray;is.set(1/e.direction.x,1/e.direction.y,1/e.direction.z);let n=1/0,i=-1;const r=t.boxCount;for(let o=0;o<r;o++){const[a,c,l,h,u,d]=t.boxes[o].box;Xo.set(a,c,l),qo.set(a+h,c+u,l+d);const p=(Xo.x-e.origin.x)*is.x,x=(qo.x-e.origin.x)*is.x,g=(Xo.y-e.origin.y)*is.y,m=(qo.y-e.origin.y)*is.y,f=(Xo.z-e.origin.z)*is.z,y=(qo.z-e.origin.z)*is.z,v=Math.max(Math.max(Math.min(p,x),Math.min(g,m)),Math.min(f,y)),b=Math.min(Math.min(Math.max(p,x),Math.max(g,m)),Math.max(f,y));b<0||v>b||v>=0&&v<n&&(n=v,i=o)}return i}const Yy=1e3;let Yo=0,Id=!1,Ud=!1;class $y{constructor(){U(this,"state",new Dy);U(this,"gui");U(this,"level");U(this,"graphics");U(this,"simulation",new Py);U(this,"isEditor",!1);U(this,"drawOffset",[0,0]);U(this,"drawScale",1);U(this,"mousePos");U(this,"isMouseDown",!1);U(this,"didBuildControls",!1);if(Id)throw new Error("TowerToppler constructed multiple times");Id=!0;for(const t of dc.NAMES)xn.preload(this,t)}toggleEditor(){this.isEditor=!this.isEditor,cs.hideAll(),this.gui=xn.create(this.isEditor?"editor-gui":"playing-gui"),this.resetLevel()}async init(){if(Ud)throw new Error("TowerToppler initialized multiple times");Ud=!0,window.addEventListener("pointermove",t=>{this.move([t.clientX,t.clientY])}),window.addEventListener("pointerdown",t=>{this.down([t.clientX,t.clientY])}),window.addEventListener("pointerup",t=>{this.up([t.clientX,t.clientY])}),this.graphics=new z1;for(const t of dc.NAMES){const e=xn.create(t);e instanceof ib&&e.toggle(this,!1)}this.gui=xn.create("playing-gui"),this.initLevel(),window.addEventListener("resize",()=>this.onResize())}initLevel(){this.state.startLevel(),this.level=ab(oi[this.state.levelIndex]),this.graphics.reset(this.level),cs.reset(this.level,(t,e)=>this.clickBoxElem(t,e))}toggleViewDirection(t){if(this.state.isActive)return;const e=this.state.flatDirection,n=Wr.indexOf(e),i=Wr[(n+t+4)%4];this.state.flatDirection=i,this.graphics.camera.startDrag(),this.graphics.camera.isSnapping=!0,this.graphics.camera.isDragging=!1,this.graphics.camera.toggleViewMode("orthographic")}clickBoxElem(t,e){if(!this.graphics.camera.isFlat)return;const n=this.state.flatDirection,i=this.level.sideViews[n];t in i&&(this.simulation.reset(this.level,this.state,t,e),this.graphics.boxes.updateColors(),cs.hideAll(),this.state.startActive(t),this.graphics.camera.controls.enabled=!1,zs.hasRemovedBlock=!0,this.onResize())}update(t){if($v(t),X1(t),Yo>=0&&(Yo-=t),this.state.isActive){let n;const i=hi.flatConfig.speedMultiplier;for(let o=0;o<i&&(n=this.simulation.update(t,this.state),!n);o++);const r=this.state.flatDirection;this.graphics.faces.clear(),this.graphics.boxes.clear();for(const o of this.simulation.p2World.bodies){const a=o.ttDatum;if(!a)continue;const{meshIndex:c}=a;this.graphics.boxes.updateActiveBox(this.level,c,o,r);let l=5;r==="N"?l=5:r==="S"?l=4:r==="E"?l=1:l=0,this.graphics.faces.updateActiveFace(this.graphics.boxes.facesIm,c*6+l,a)}this.graphics.faces.update(t,this.state),Pu(),this.graphics.draw(t),n==="passed"?(this.state.passLevel(),this.onResize()):n==="failed"&&(this.state.failLevel(),this.onResize());return}if(Yo<=0&&Hv(),this.graphics.camera.update(t,this.state))if(this.isEditor){const n=this.graphics.boxes.selectedBoxIndex;typeof n=="number"&&n>=0?ui.showAll():ui.hideAll()}else{cs.hideAll();const n=this.state.flatDirection;this.graphics.faces.clear();const i=this.level.sideViews[n];for(const r of Object.keys(i)){const o=Number(r);for(const[a,c]of i[o].entries())this.graphics.faces.placeFace(this.graphics.boxes.boxes[o].box,n,c.rawRect,o,a),cs.placeElement(o,a,this.locateWorldRectOnScreen(c.worldRect))}}this.graphics.faces.update(t,this.state),this.graphics.draw(t)}locateBoxOnScreen(t){const e=this.graphics.camera.getScale2d(),n=this.state.flatDirection,i=lb(this.level,t,n),r=cb(this.level,t,n),o=i[0]*e+window.innerWidth/2,a=i[1]*e+window.innerHeight/2,c=r.width*e,l=r.height*e;return[o-c/2,a-l/2,c,l]}locateWorldRectOnScreen(t){const e=this.graphics.camera.getScale2d(),[n,i,r,o]=t,a=(n+r/2)*e+window.innerWidth/2,c=(i+o/2)*e+window.innerHeight/2;return[a-r*e/2,c-o*e/2,r*e,o*e]}rebuildGraphics(){const t=this.state.levelIndex,e=oi[t],{boxes:n,faces:i}=this.graphics;n.clear(),i.clear();const[r,o,a,c,l,h]=e.bounds;for(const[u,d]of e.boxes.entries()){const[p,x,g,m,f,y]=d;n.addBox([p,l-x-f,g,m,f,y]);const v=u===e.targetBoxIndex?uf:Sa;n.setColorAt(u,v)}n.updateColors()}resetLevel(){this.initLevel(),this.onResize()}goToNextLevel(){this.state.levelIndex=(this.state.levelIndex+1)%oi.length,this.initLevel(),this.onResize()}move(t){Pu(),Yo=Yy;const e=[(t[0]-this.drawOffset[0])/this.drawScale,(t[1]-this.drawOffset[1])/this.drawScale];if(this.mousePos=e,this.isEditor===!0&&!this.state.isActive){const n=t[0]/window.innerWidth*2-1,i=-(t[1]/window.innerHeight)*2+1,r=new L0;r.setFromCamera(new zt(n,i),this.graphics.camera.camera);const o=qy(r,this.graphics.boxes);this.graphics.boxes.hoveredBoxIndex=o,this.graphics.renderer.domElement.style.cursor=o>=0?"pointer":"default"}return e}editorAddClicked(){const t=this.graphics.boxes.selectedBoxIndex;if(t>=0){const e=oi[this.state.levelIndex],[n,i,r,o,a,c]=e.boxes[t];e.boxes.push([n,i-a,r,o,a,c]),this.graphics.boxes.selectedBoxIndex=e.boxes.length-1,this.rebuildGraphics(),this.onResize()}}editorRemoveClicked(){const t=this.graphics.boxes.selectedBoxIndex;t>=0&&oi[this.state.levelIndex].boxes.splice(t,1),this.graphics.boxes.selectedBoxIndex=-1,this.rebuildGraphics(),this.onResize()}editorSetTargetClicked(){oi[this.state.levelIndex].targetBoxIndex=this.graphics.boxes.selectedBoxIndex}editorSaveClicked(){const t=Ky(oi[this.state.levelIndex]);navigator.clipboard.writeText(t)}down(t){this.move(t),this.isMouseDown=!0;const e=this.graphics.boxes.hoveredBoxIndex;e>=0&&e!==this.graphics.boxes.selectedBoxIndex&&(this.graphics.boxes.selectedBoxIndex=e,ui.towerToppler=this,ui.showAll(),this.onResize())}up(t){this.isMouseDown=!1}onResize(){for(const t of dc.NAMES){const e=xn.create(t),n=e===this.gui;for(const i in e.elements)mr(i,n);this.gui.refreshLayout(this)}this.isEditor?mr(Af,this.graphics.boxes.selectedBoxIndex>=0):this.state.isActive?(us(yl),this.state.isToppled?(us(Tr),So(Di,'<span style="color:black">Success</span>')):this.state.isFailed?(Fi(Tr),So(Di,'<span style="color:red">Failed</span>')):(So(Di,"Falling..."),Fi(Tr))):(zs.hasDragged?Fi(Di):(So(Di,"Drag to rotate"),us(Di)),Fi(yl),Fi(Tr)),mr(bf,!zs.hasRemovedBlock),mr(Kl,!this.state.isActive&&zs.hasDragged),mr(Zl,!this.state.isActive&&zs.hasDragged),this.graphics.onResize()}rebuildControls(){this.didBuildControls=!0,Xy(this)}}function Ky(s,t="  "){function e(n,i){return n===null||typeof n!="object"?JSON.stringify(n):Array.isArray(n)?n.every(l=>typeof l=="number")?"["+n.map(l=>JSON.stringify(l)).join(",")+"]":`[
`+n.map(l=>e(l,i+1)).map(l=>t.repeat(i+1)+l).join(`,
`)+`
`+t.repeat(i)+"]":`{
`+Object.keys(n).map(a=>t.repeat(i+1)+JSON.stringify(a)+": "+e(n[a],i+1)).join(`,
`)+`
`+t.repeat(i)+"}"}return e(s,0)}async function Zy(){Tn.refreshConfig();const s=new $y;window.TestSupport=Ly(s),await s.init(),s.onResize(),navigator.webdriver&&document.querySelector("*").addEventListener("mousemove",n=>{window.mouseXForTestSupport=n.clientX,window.mouseYForTestSupport=n.clientY;const i=window.getComputedStyle(n.target).cursor;i==="auto"?window.cursorForTestSupport="default":window.cursorForTestSupport=i,n.stopPropagation()});let t=performance.now();function e(){requestAnimationFrame(e);const n=performance.now(),i=Math.min(50,n-t);t=n,s.update(i)}e()}Zy();
