var B=Object.defineProperty;var G=(s,t,e)=>t in s?B(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var d=(s,t,e)=>G(s,typeof t!="symbol"?t+"":t,e);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))i(n);new MutationObserver(n=>{for(const o of n)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function e(n){const o={};return n.integrity&&(o.integrity=n.integrity),n.referrerPolicy&&(o.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?o.credentials="include":n.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function i(n){if(n.ep)return;n.ep=!0;const o=e(n);fetch(n.href,o)}})();class Configurable{constructor(){d(this,"flatConfig")}refreshConfig(){this.flatConfig=flattenTree(this.tree)}static register(t,e){if(t in this._registry)throw new Error(`configurable already registered: '${t}'`);this._registry[t]=e}static create(t){const e=this._registry[t],i=e();return i.refreshConfig(),i}}d(Configurable,"_registry",{});function flattenTree(s,t={}){for(const[e,i]of Object.entries(s.children))"action"in i||("value"in i?t[e]=i.value:flattenTree(i,t));return t}function onChange(s){gfxConfig.refreshConfig(),_scaledVals=null,s.onResize()}function setBoardScale(s){gfxConfigTree.children.boardScale.value=s,gfxConfig.refreshConfig(),_scaledVals=null}const gfxConfigTree={label:"Graphics",children:{slotsDisplay:{value:"hidden",options:["visible","hidden"],onChange},boardScale:{value:1,min:.1,max:20,onChange},stickLong:{value:125,min:10,max:1e3,step:1,onChange},stickLongSegments:{value:6,min:3,max:100,step:1,onChange},stickLongAmp:{value:2,min:1,max:10,onChange},stickLongFreq:{value:-5,min:-5,max:0,onChange},stickShort:{value:15,min:1,max:100,step:1,onChange},stickShortSegments:{value:5,min:3,max:100,step:1,onChange},stickShortAmp:{value:3,min:1,max:10,onChange},stickShortFreq:{value:-3,min:-5,max:0,onChange},hlThickness:{value:4,min:1,max:100,step:1,onChange},slotPadding:{value:10,min:-100,max:100,step:1,onChange},slotMargin:{value:0,min:-100,max:100,step:1,onChange},digitMargin:{value:80,min:0,max:200,step:1,onChange},angleAlpha:{value:.03,min:1e-5,max:.5,onChange},posAlpha:{value:.03,min:1e-5,max:.5,onChange}}};let _scaledVals=null;function getScaledGfxConfigVals(){if(!_scaledVals){const{boardScale:s}=gfxConfig.flatConfig;let{stickLong:t,stickLongAmp:e,stickShort:i,stickShortAmp:n,slotPadding:o,slotMargin:r,digitMargin:l,hlThickness:a}=gfxConfig.flatConfig;t*=s,e*=s,i*=s,n*=s,o*=s,r*=s,l*=s,a*=s,_scaledVals={stickLong:t,stickLongAmp:e,stickShort:i,stickShortAmp:n,slotPadding:o,slotMargin:r,digitMargin:l,hlThickness:a}}return _scaledVals}const F=class F extends Configurable{constructor(){super(...arguments);d(this,"tree",gfxConfigTree)}};Configurable.register("gfx-config",()=>new F);let GfxConfig=F;const gfxConfig=Configurable.create("gfx-config");class Slot{constructor(t,e){this.pos=t,this.isHorizontal=e}draw(t){const{pos:e,isHorizontal:i}=this,{stickLong:n,stickShort:o,slotPadding:r}=getScaledGfxConfigVals(),l=n+2*r,a=o+2*r,h=i?0:Math.PI/2;traceSlot(t,e,h,l,a),t.lineWidth=1,t.strokeStyle="black",t.stroke()}contains([t,e]){const{stickLong:i,stickShort:n,slotPadding:o}=getScaledGfxConfigVals(),r=i+2*o,l=n+2*o,[a,h]=this.pos,c=Math.abs(a-t),p=Math.abs(h-e);return this.isHorizontal?c<r/2&&p<l/2:c<l/2&&p<r/2}}function traceSlot(s,t,e,i,n){const o=t[0],r=t[1],l=i,a=n,h=l/2,c=a/2,p=[[-h,-c],[h,-c],[h,c],[-h,c]];s.save(),s.translate(o,r),s.rotate(e),s.beginPath(),s.moveTo(p[0][0],p[0][1]);for(let g=1;g<4;++g)s.lineTo(p[g][0],p[g][1]);s.closePath(),s.restore()}function getRawDigitWidth(){const{stickLong:s,slotPadding:t,slotMargin:e}=gfxConfig.flatConfig;return s+2*(t+e)}function buildSlots(s,t){const e=getRawDigitWidth();if(t[2]>t[3])return window.devicePixelRatio>1.5||window.screen.width<1e3?setBoardScale(t[2]/e/8):setBoardScale(t[2]/e/12),buildRow(s,t);setBoardScale(t[2]/e/5);const{stickLong:i,slotPadding:n,slotMargin:o}=getScaledGfxConfigVals(),l=(i+2*(n+o))*1.3,a=buildRow(s.slice(0,3),t);a.forEach(c=>c.pos[1]-=l);const h=buildRow(s.slice(3),t);return h.forEach(c=>c.pos[1]+=l),[...a,...h]}function buildRow(s,t){const{stickLong:e,slotPadding:i,slotMargin:n,digitMargin:o}=getScaledGfxConfigVals(),[r,l,a,h]=t,c=r+a/2,p=l+h/2,g=e+2*(i+n),w=s.length*g+(s.length-1)*o,C=c-w/2+g/2,m=[];for(const[y,{board:f}]of s.entries()){const u=C+y*(g+o);for(const b of f.slots){const v=u+b[0]*g,L=p+b[1]*g,_=b[2];m.push(new Slot([v,L],_))}}return m}const EQUALS_OP_BOARD={slots:[[0,-.125,!0],[0,.125,!0],[0,-.125,!1],[0,.125,!1]],symbols:{"-":[[0],[1]],"=":[[0,1]],"+":[[0,2],[1,3]]}},PLUS_OP_BOARD={slots:[[0,-.25,!0],[0,.25,!0],[0,0,!0],[0,0,!1]],symbols:{"-":[[2]],"+":[[2,3]],"=":[[0,2],[1,2]]}},SINGLE_DIGIT_BOARD={slots:[[0,0,!0],[0,-1,!0],[0,1,!0],[-.5,-.5,!1],[-.5,.5,!1],[.5,.5,!1],[.5,-.5,!1]],symbols:{0:[[1,2,3,4,5,6]],1:[[5,6]],2:[[0,1,2,4,6]],3:[[0,1,2,5,6]],4:[[0,3,5,6]],5:[[0,1,2,3,5]],6:[[0,1,2,3,4,5]],7:[[1,5,6]],8:[[0,1,2,3,4,5,6]],9:[[0,1,2,3,5,6]],11:[[3,4,5,6]],L:[[2,3,4]],"[":[[1,2,3,4]],"]":[[1,2,5,6]],F:[[0,1,3,4]],"-":[[0]],_:[[2]],i:[[4],[5]],b:[[0,2,3,4,5]],d:[[0,2,4,5,6]],c:[[0,2,4]],o:[[0,2,4,5]],q:[[0,1,3,5,6]],P:[[0,1,3,4,6]],h:[[0,3,4,5]],H:[[0,3,4,5,6]],A:[[0,1,3,4,5,6]],U:[[2,3,4,5,6]],u:[[2,4,5]],n:[[0,4,5]],r:[[0,4]],"°":[[0,1,3,6]],j:[[2,4,5,6]],E:[[0,1,2,3,4]]}},layoutConfigTree={children:{outerMargin:{tooltip:"margin at viewport bounds",value:10,min:0,max:100,step:1},innerMargin:{tooltip:"margin at dialog panel bounds",value:10,min:0,max:100,step:1},smButtonWidth:{tooltip:"width for small square-ish buttons on small screens",value:50,min:10,max:100,step:1},buttonWidth:{tooltip:"width for small square-ish buttons on desktop",value:150,min:10,max:100,step:1},smButtonHeight:{tooltip:"standard button thickness on small screens",value:40,min:10,max:100,step:1},buttonHeight:{tooltip:"standard button thickness on desktop",value:50,min:10,max:100,step:1}}};for(const s of Object.values(layoutConfigTree.children))s.onChange=t=>{layoutConfig.refreshConfig(),t.onResize()};const R=class R extends Configurable{constructor(){super(...arguments);d(this,"tree",layoutConfigTree)}};Configurable.register("layout-config",()=>new R);let LayoutConfig=R;const layoutConfig=Configurable.create("layout-config"),topConfigTree={children:{flashPeriod:{value:1e3,min:100,max:1e4,onChange:()=>topConfig.refreshConfig()}}},z=class z extends Configurable{constructor(){super(...arguments);d(this,"tree",topConfigTree)}};Configurable.register("top-config",()=>new z);let TopConfig=z;const topConfig=Configurable.create("top-config"),ZeroConfigTree={label:"Level Zero",children:{}},O=class O extends Configurable{constructor(){super(...arguments);d(this,"tree",ZeroConfigTree)}};Configurable.register("zero-config",()=>new O);let ZeroConfig=O;const zeroConfig=Configurable.create("zero-config"),matchsticksConfigTree={children:{...topConfig.tree.children,graphics:gfxConfig.tree,layout:layoutConfig.tree,zero:zeroConfig.tree}},V=class V extends Configurable{constructor(){super(...arguments);d(this,"tree",matchsticksConfigTree)}};Configurable.register("matchsticks-config",()=>new V);let MatchsticksConfig=V;const matchsticksConfig=Configurable.create("matchsticks-config"),extremeA=[170,170,170],extremeB=[100,100,100];function _bounceState(s){return s<=.5?s=s*2:s=(1-s)*2,s}function updateClickMeColor(){const s=topConfig.flatConfig.flashPeriod,t=performance.now(),e=_bounceState(t%s/s),i=extremeA.map((n,o)=>Math.round(n+(extremeB[o]-n)*e));`${i[0]}${i[1]}${i[2]}`}function buildHtmlElement(s,t){const e=t.display.draw?"canvas":t.display.type==="button"?"button":"div",i=t.display.classes??[],n=i.filter(l=>l.startsWith("fa-")),o=i.filter(l=>!l.startsWith("fa-"));t.display.type!=="button"&&o.push("noselect");const r=asElement(`
    <${e} 
       id="${s}" 
       class="
          hidden
          gui-element 
          ${t.display.type} 
          ${o.join(" ")}
        ">

      <span 
        class="${n.join(" ")}" 
        ${t.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
      >
        ${t.display.label??""}
      </span>
    </${e}>
  `);for(const[l,a]of Object.entries(t.display.styles??{}))r.style.setProperty(l,a);return t.id=s,t.htmlElem=r,r}function hideElement(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.add("hidden")}function showElement(s){let t;typeof s=="string"?t=document.getElementById(s):t=s.htmlElem,t&&t&&t.classList.contains("gui-element")&&t.classList.remove("hidden")}function setElementLabel(s,t){if(s.display.label=t,/~[^n]/.test(t))throw new Error('Invalid tilde usage: only "~n" is allowed.');const e=t.replace(/~n/g,""),{htmlElem:i}=s;i&&(i.innerHTML=`
    <span ${s.display.textAlign==="left"?'style="width:100%;text-align:left;"':""}
    >${e}</span>
  `)}function repaintDiagram(s,t){if(!t.display.draw)throw new Error("diagram gui element should define draw");const{htmlElem:e,rectangle:i}=t;if(!i||!e)return;if(e.tagName!=="CANVAS")throw new Error("diagram html element is not canvas");const o=e.getContext("2d");t.display.draw(o,s,i.map(r=>r*window.devicePixelRatio))}function updateElement(s,t,e){if(!e){s.classList.add("hidden");return}s.style.opacity="";const[i,n,o,r]=e;s.style.display="",s.style.left=`${i}px`,s.style.top=`${n}px`,s.style.width=`${o}px`,s.style.height=`${r}px`;const l=s;l.width=o*window.devicePixelRatio,l.height=r*window.devicePixelRatio}function asElement(s){const t=document.createElement("div");return t.innerHTML=s.trim(),t.firstChild}class LayeredViewport{constructor(){d(this,"canvas");d(this,"ctx");d(this,"w");d(this,"h");d(this,"screenRectangle");d(this,"pxScreenRectangle")}handleResize(t){const e=window.devicePixelRatio;this.w=this.canvas.offsetWidth*e,this.h=this.canvas.offsetHeight*e,this.screenRectangle=[0,0,this.w,this.h],this.pxScreenRectangle=[0,0,this.canvas.offsetWidth,this.canvas.offsetHeight],this.canvas.width=this.w,this.canvas.height=this.h}init(t,e){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.handleResize(t)}}new Path2D(`

    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 168.3C277.6
     109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 259.3 530.7 184.3 
     455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 412.9C98.8 422.4 94.4 
     442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 501C601 401 601 239 501
      139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 78.8 65.8C69.8 69.5 64 78.3 
      64 88L64 232C64 245.3 74.7 256 88 256z
  
  
      `),new Path2D(`

    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 168.3C362.4
     109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 380.7 530.7 455.7
      455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 421.7C536.7 431.8 540.2
       451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 139 501C39.1 401 39 239 139 
       139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 62.1 561.2 65.8C570.2 69.5 576 
       78.3 576 88L576 232C576 245.3 565.3 256 552 256z

  
      `),new Path2D(`


    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z

  
  
      `),new Path2D(`
    M88 256L232 256C241.7 256 250.5 250.2 254.2 241.2C257.9 232.2 255.9 221.9 249 215L202.3 
    168.3C277.6 109.7 386.6 115 455.8 184.2C530.8 259.2 530.8 380.7 455.8 455.7C380.8 530.7 
    259.3 530.7 184.3 455.7C174.1 445.5 165.3 434.4 157.9 422.7C148.4 407.8 128.6 403.4 113.7 
    412.9C98.8 422.4 94.4 442.2 103.9 457.1C113.7 472.7 125.4 487.5 139 501C239 601 401 601 501 
    501C601 401 601 239 501 139C406.8 44.7 257.3 39.3 156.7 122.8L105 71C98.1 64.2 87.8 62.1 
    78.8 65.8C69.8 69.5 64 78.3 64 88L64 232C64 245.3 74.7 256 88 256z
  `),new Path2D(`
    M342.6 81.4C330.1 68.9 309.8 68.9 297.3 81.4L137.3 241.4C124.8 253.9 124.8 274.2 137.3 
    286.7C149.8 299.2 170.1 299.2 182.6 286.7L288 181.3L288 552C288 569.7 302.3 584 320 
    584C337.7 584 352 569.7 352 552L352 181.3L457.4 286.7C469.9 299.2 490.2 299.2 502.7 
    286.7C515.2 274.2 515.2 253.9 502.7 241.4L342.7 81.4z
  `),new Path2D(`
    M552 256L408 256C398.3 256 389.5 250.2 385.8 241.2C382.1 232.2 384.1 221.9 391 215L437.7 
    168.3C362.4 109.7 253.4 115 184.2 184.2C109.2 259.2 109.2 380.7 184.2 455.7C259.2 530.7 
    380.7 530.7 455.7 455.7C463.9 447.5 471.2 438.8 477.6 429.6C487.7 415.1 507.7 411.6 522.2 
    421.7C536.7 431.8 540.2 451.8 530.1 466.3C521.6 478.5 511.9 490.1 501 501C401 601 238.9 601 
    139 501C39.1 401 39 239 139 139C233.3 44.7 382.7 39.4 483.3 122.8L535 71C541.9 64.1 552.2 
    62.1 561.2 65.8C570.2 69.5 576 78.3 576 88L576 232C576 245.3 565.3 256 552 256z
  `),new Path2D(`
        M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 
        550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 
        85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320
        480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 
        288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 
        257.7C352.5 239.5 338.1 224 319.8 224z
    `),new Path2D(`
        M480 96C515.3 96 544 124.7 544 160L544 480C544 515.3 515.3 544 480 544L160 544C124.7 544 96 
        515.3 96 480L96 160C96 124.7 124.7 96 160 96L480 96zM438 209.7C427.3 201.9 412.3 204.3 404.5 
        215L285.1 379.2L233 327.1C223.6 317.7 208.4 317.7 199.1 327.1C189.8 336.5 189.7 351.7 199.1 
        361L271.1 433C276.1 438 283 440.5 289.9 440C296.8 439.5 303.3 435.9 307.4 430.2L443.3 243.2C451.1 
        232.5 448.7 217.5 438 209.7z
    `),new Path2D(`

      M259.1 73.5C262.1 58.7 275.2 48 290.4 48L350.2 48C365.4 48 378.5 58.7 381.5 73.5L396 143.5C410.1
       149.5 423.3 157.2 435.3 166.3L503.1 143.8C517.5 139 533.3 145 540.9 158.2L570.8 210C578.4 223.2
        575.7 239.8 564.3 249.9L511 297.3C511.9 304.7 512.3 312.3 512.3 320C512.3 327.7 511.8 335.3 511
         342.7L564.4 390.2C575.8 400.3 578.4 417 570.9 430.1L541 481.9C533.4 495 517.6 501.1 503.2 
         496.3L435.4 473.8C423.3 482.9 410.1 490.5 396.1 496.6L381.7 566.5C378.6 581.4 365.5 592 350.4
          592L290.6 592C275.4 592 262.3 581.3 259.3 566.5L244.9 496.6C230.8 490.6 217.7 482.9 205.6
           473.8L137.5 496.3C123.1 501.1 107.3 495.1 99.7 481.9L69.8 430.1C62.2 416.9 64.9 400.3 76.3
            390.2L129.7 342.7C128.8 335.3 128.4 327.7 128.4 320C128.4 312.3 128.9 304.7 129.7 297.3L76.3
             249.8C64.9 239.7 62.3 223 69.8 209.9L99.7 158.1C107.3 144.9 123.1 138.9 137.5 143.7L205.3 
             166.2C217.4 157.1 230.6 149.5 244.6 143.4L259.1 73.5zM320.3 400C364.5 399.8 400.2 363.9 400
              319.7C399.8 275.5 363.9 239.8 319.7 240C275.5 240.2 239.8 276.1 240 320.3C240.2 364.5 276.1
               400.2 320.3 400z

      
    `),new Path2D(`


      M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 
      160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 
      48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576
       197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z
      
    `),new Path2D(`

      M197.8 100.3C208.7 107.9 211.3 122.9 203.7 133.7L147.7 213.7C143.6 219.5 137.2 223.2 130.1 223.8C123 
      224.4 116 222 111 217L71 177C61.7 167.6 61.7 152.4 71 143C80.3 133.6 95.6 133.7 105 143L124.8 162.8L164.4
       106.2C172 95.3 187 92.7 197.8 100.3zM197.8 260.3C208.7 267.9 211.3 282.9 203.7 293.7L147.7 373.7C143.6 
       379.5 137.2 383.2 130.1 383.8C123 384.4 116 382 111 377L71 337C61.6 327.6 61.6 312.4 71 303.1C80.4 293.8 
       95.6 293.7 104.9 303.1L124.7 322.9L164.3 266.3C171.9 255.4 186.9 252.8 197.7 260.4zM288 160C288 142.3 
       302.3 128 320 128L544 128C561.7 128 576 142.3 576 160C576 177.7 561.7 192 544 192L320 192C302.3 
       192 288 177.7 288 160zM288 320C288 302.3 302.3 288 320 288L544 288C561.7 288 576 302.3 576 320C576
        337.7 561.7 352 544 352L320 352C302.3 352 288 337.7 288 320zM224 480C224 462.3 238.3 448 256 448L544 
        448C561.7 448 576 462.3 576 480C576 497.7 561.7 512 544 512L256 512C238.3 512 224 497.7 224 480zM128 
        440C150.1 440 168 457.9 168 480C168 502.1 150.1 520 128 520C105.9 520 88 502.1 88 480C88 457.9 105.9 
        440 128 440z

      
    `),new Path2D(`

      M504.6 148.5C515.9 134.9 514.1 114.7 500.5 103.4C486.9 92.1 466.7 93.9 455.4 107.5L320 270L184.6
       107.5C173.3 93.9 153.1 92.1 139.5 103.4C125.9 114.7 124.1 134.9 135.4 148.5L278.3 320L135.4
        491.5C124.1 505.1 125.9 525.3 139.5 536.6C153.1 547.9 173.3 546.1 184.6 532.5L320 370L455.4
         532.5C466.7 546.1 486.9 547.9 500.5 536.6C514.1 525.3 515.9 505.1 504.6 491.5L361.7 320L504.6 148.5z

      
    `),new Path2D(`


      M173.3 66.5C181.4 62.4 191.2 63.3 198.4 68.8L518.4 308.7C526.7 314.9 530 325.7 
      526.8 335.5C523.6 345.3 514.4 351.9 504 351.9L351.7 351.9L440.6 529.6C448.5
       545.4 442.1 564.6 426.3 572.5C410.5 580.4 391.3 574 383.4 558.2L294.5 380.5L203.2 
       502.3C197 510.6 186.2 513.9 176.4 510.7C166.6 507.5 160 498.3 160 488L160
        88C160 78.9 165.1 70.6 173.3 66.5z
      
    `);function setLayoutUtilMode(s){s.isLandscape,s.isPortrait}function typedEntries(s){return Object.entries(s)}function parseLayoutRectangles(s,t){return new GuiLayoutParser(s,t)._computedRects}const x=class x{constructor(t,e){d(this,"_computedRects",{});d(this,"isPortrait",!1);d(this,"isLandscape",!1);d(this,"parent");d(this,"_currentLayoutKey","");d(this,"_childrenToParse",{});t[2]>t[3]?this.isLandscape=!0:this.isPortrait=!0;const i=600;t[2]<i||t[3]<i?x.isSmall=!0:x.isSmall=!1,setLayoutUtilMode(this),this.parent=t;for(const[o,r]of Object.entries(e))this.parent=t,this._currentLayoutKey=o,this._computedRects[o]=this.computeRect(r);const n=this._childrenToParse;for(;Object.keys(n).length>0;){const o=Object.keys(n)[0],r=n[o];delete n[o];const l=this._computedRects[o],{_computedRects:a}=new x(l,r);for(const h in a)this._computedRects[`${o}.${h}`]=a[h]}}computeRect(t){let e=[...this.parent];for(const[i,n]of typedEntries(t))if(i==="parent"){if(!(n in this._computedRects))throw new Error(`layout parent '${n}' not defined by any previous rulesets`);this.parent=this._computedRects[n],e=[...this.parent]}else if(i.startsWith("parent@")){const[o,r]=i.split("@");if(typeof n!="string"||!(n in this._computedRects))throw new Error(`layout parent '${n}' not defined by any previous rulesets`);if(r==="portrait")this.isPortrait&&(this.parent=this._computedRects[n],e=[...this.parent]);else if(r==="landscape")this.isLandscape&&(this.parent=this._computedRects[n],e=[...this.parent]);else if(r==="sm-portrait")this.isPortrait&&x.isSmall&&(this.parent=this._computedRects[n],e=[...this.parent]);else if(r==="sm-landscape")this.isLandscape&&x.isSmall&&(this.parent=this._computedRects[n],e=[...this.parent]);else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else if(i==="children")this._childrenToParse[this._currentLayoutKey]=n;else if(i.includes("@")){const[o,r]=i.split("@");if(r==="portrait")this.isPortrait&&(e=this.applyRule(e,o,n));else if(r==="landscape")this.isLandscape&&(e=this.applyRule(e,o,n));else if(r==="sm-portrait")this.isPortrait&&x.isSmall&&(e=this.applyRule(e,o,n));else if(r==="sm-landscape")this.isLandscape&&x.isSmall&&(e=this.applyRule(e,o,n));else throw new Error(`invalid @ condition suffix: '${r}'. expected portait or landscape.`)}else e=this.applyRule(e,i,n);return[e[0],e[1],e[2],e[3]]}applyRule(t,e,i){const[n,o,r,l]=t,[a,h,c,p]=this.parent,g=(C,m)=>{if(typeof m=="function"&&(m=m()),typeof m=="string"&&m.endsWith("%")){const y=parseFloat(m)/100;return["left","right","width","margin"].includes(C)?c*y:p*y}else{if(m==="auto")return C==="width"?a+c-n:C==="height"?h+p-o:["left","right"].includes(C)?(c-r)/2:(p-l)/2;if(typeof m=="number"&&m<0){if(C==="width")return c+m;if(C==="height")return p+m}}return Number(m)},w=e.split("-");if(w.length===2){const[C,m]=w;let y;if(C==="min")y=Math.max;else if(C==="max")y=Math.min;else throw new Error("only min- or max- prefixed allowed");if(m==="width")return[n,o,y(r,g("width",i)),l];if(m==="height")return[n,o,r,y(l,g("height",i))];if(m==="left")return[y(n,g("left",i)),o,r,l];throw new Error("only min/max-width, -height, or -left allowed")}switch(e){case"left":return[a+g("left",i),o,r,l];case"right":return[a+c-r-g("right",i),o,r,l];case"top":return[n,h+g("top",i),r,l];case"bottom":return[n,h+p-l-g("bottom",i),r,l];case"width":return[n,o,g("width",i),l];case"height":return[n,o,r,g("height",i)];case"margin":{const C=g("margin",i);return[n+C,o+C,r-2*C,l-2*C]}default:return t}}};d(x,"isSmall",!1);let GuiLayoutParser=x;const allHtmlElems={};let nextElementId=0;class Gui{constructor(){d(this,"guiLayout");d(this,"layoutRectangles",{});d(this,"elements",{});d(this,"layoutFactory")}init(t,e,i){this.layoutFactory=e;for(const n of i)if(typeof n.id=="string")this.elements[n.id]=n;else{const o=`_${nextElementId++}`;this.elements[o]=n;const r=buildHtmlElement(o,n);r.onclick=l=>{l.preventDefault(),n.click&&n.click({elementId:o,matchsticks:t,pointerEvent:l})},r.onpointerdown=l=>{l.preventDefault(),n.down&&n.down({elementId:o,matchsticks:t,pointerEvent:l})},r.onpointermove=l=>{l.preventDefault(),n.move&&n.move({elementId:o,matchsticks:t,pointerEvent:l})},r.onpointerup=l=>{l.preventDefault(),n.up&&n.up({elementId:o,matchsticks:t,pointerEvent:l})},r.onpointerleave=l=>{l.preventDefault(),n.up&&n.up({elementId:o,matchsticks:t,pointerEvent:l})},r.style.display="none",document.body.appendChild(r),allHtmlElems[o]=r,n.id=o}}refreshLayout(t){const{pxScreenRectangle:e}=t.layeredViewport;this.guiLayout=this.layoutFactory(t),this.layoutRectangles=parseLayoutRectangles(e,this.guiLayout);for(const i in this.elements){const n=this.elements[i],o=this.layoutRectangles[n.layoutKey];n.rectangle=o,n.rectangle&&(n.dprRectangle=n.rectangle.map(r=>r*window.devicePixelRatio)),updateElement(allHtmlElems[i],n,o)}}static register(t,e){if(t in this._registry)throw new Error(`Game already registered: '${t}'`);this._registry[t]=e}static preload(t,e){const i=this._registry[e];if(!i)throw new Error(`gui ${e} not registered `);const{factory:n,layoutFactory:o,elements:r}=i,l=n();this._preloaded[e]=l,l.init(t,o,r)}static create(t){if(t in this._preloaded)return this._preloaded[t];throw new Error(`gui '${t}' was not preloaded`)}}d(Gui,"_registry",{}),d(Gui,"_preloaded",{});const ZERO_LAYOUT={screen:{},_outerMargin:{parent:"screen",margin:()=>layoutConfig.flatConfig.outerMargin},hintBtn:{parent:"_outerMargin",width:()=>layoutConfig.flatConfig.buttonWidth,height:()=>layoutConfig.flatConfig.buttonHeight,left:0,top:0},topLabel:{parent:"_outerMargin",height:()=>layoutConfig.flatConfig.buttonHeight,"top@portrait":"-100%"},bottomLabel:{parent:"_outerMargin",height:()=>layoutConfig.flatConfig.buttonHeight,left:0,bottom:0},resetBtn:{parent:"_outerMargin",width:()=>layoutConfig.flatConfig.buttonWidth,height:()=>layoutConfig.flatConfig.buttonHeight,right:0,top:0},nextLevelBtn:{parent:"_outerMargin",width:()=>layoutConfig.flatConfig.buttonWidth,height:()=>layoutConfig.flatConfig.buttonHeight,right:0,bottom:0}},playArea={layoutKey:"screen",display:{type:"diagram",draw:(s,t,e)=>{t.draw(s,e)}},down:({matchsticks:s,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,n=window.devicePixelRatio,o=[e*n,i*n];s.down(o)},up:({matchsticks:s,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,n=window.devicePixelRatio,o=[e*n,i*n];s.up(o)},move:({matchsticks:s,pointerEvent:t})=>{const{clientX:e,clientY:i}=t,n=window.devicePixelRatio,o=[e*n,i*n];s.move(o)}},topLabel={layoutKey:"topLabel",display:{type:"panel",label:"MOVE ONE STICK",styles:{border:"none"}}},bottomLabel={layoutKey:"bottomLabel",display:{type:"panel",label:'2+2=5 <span style="color:red">FALSE</span>',styles:{border:"none","font-family":"Lexend"}}},hintBtn={layoutKey:"hintBtn",display:{type:"button",label:"HINT"},click:({matchsticks:s})=>{s.hint()}},resetBtn={layoutKey:"resetBtn",display:{type:"button",label:"RESET"},click:({matchsticks:s})=>{s.resetSticks()}},nextLevelBtn={layoutKey:"nextLevelBtn",display:{type:"button",label:"NEXT",classes:["click-me"]},click:({matchsticks:s})=>{s.goToNextLevel()}},P=class P extends Gui{};Gui.register("zero-gui",{factory:()=>new P,layoutFactory:()=>ZERO_LAYOUT,elements:[topLabel,bottomLabel,playArea,hintBtn,resetBtn,nextLevelBtn]});let ZeroGui=P;class ToggledGui extends Gui{constructor(){super(...arguments);d(this,"_isShowing",!1)}get isShowing(){return this._isShowing}toggle(e,i){typeof i=="boolean"?this._isShowing=i:this._isShowing=!this._isShowing;for(const n in this.elements)this._isShowing?(this.elements[n].display.classes??[]).includes("hidden")||showElement(n):hideElement(n);this._isShowing&&this.refreshLayout(e),this.onToggle(e)}}const GUI$1={NAMES:["zero-gui"]};function randChoice(s){return s[Math.floor(Math.random()*s.length)]}function getRandomEquationLevel(){return getEquationLevel(randChoice(_allEquations))}function getEquationLevel(s){const t=[];for(let e=0;e<s.length;e++){const i=s[e];if("0123456789".includes(i))t.push({board:SINGLE_DIGIT_BOARD,sticks:SINGLE_DIGIT_BOARD.symbols[i][0]});else if("+-".includes(i))t.push({board:PLUS_OP_BOARD,sticks:PLUS_OP_BOARD.symbols[i][0]});else if(i==="=")t.push({board:EQUALS_OP_BOARD,sticks:EQUALS_OP_BOARD.symbols[i][0]});else throw new Error(`unrecognized equation character ${i} in level string ${s}`)}return t}const _allEquations=["8-2=2","2-8=2","8-3=3","7-2=3","2-7=3","3-8=3","3-7=4","4-8=4","8-5=5","7-4=5","2-9=5","2-3=6","2-3=9","9-2=5","3-2=6","3-2=9","4-7=5","5-8=5","8-6=6","8+5=6","8+6=5","7-5=6","7+5=5","2-4=8","3-9=6","3-3=8","9+3=5","3+9=5","4-2=8","5-7=6","5+7=5","5+8=6","6-8=6","6+8=5","8-7=7","7-6=7","7+5=7","2-6=7","2-9=7","9-4=7","4-9=7","6-2=7","5+7=7","6-7=7","7-8=7","8-8=8","8+9=8","8+6=8","8+8=9","8+8=6","7-7=8","7+7=9","7+7=6","2-8=8","2+8=9","2+8=6","9-5=8","3-6=8","3-9=8","9+5=9","3+9=9","9+5=6","3+6=6","3+9=6","6-3=8","9-3=8","5-9=8","9+3=9","5+9=9","6+3=6","9+3=6","5+9=6","8-2=8","8+2=9","8+2=6","7-7=8","7+7=9","7+7=6","9+8=8","6+8=8","8-8=8","8+8=9","8+8=6","8-9=9","8+3=9","8+5=9","8+9=3","8+9=5","7-8=9","7+9=9","7+6=9","7+8=3","7+8=5","2-7=8","9-6=9","3-8=9","3-6=8","9+5=9","9+6=3","3+8=3","9+6=5","3+8=5","4-6=9","4-9=9","4-5=8","4+6=3","4+9=3","4+6=5","4+9=5","6-4=9","9-4=9","5-4=8","6+4=3","9+4=3","6+4=5","9+4=5","5+9=9","8-3=9","6-9=9","6-3=8","8+3=3","6+9=3","8+3=5","6+9=5","7-2=8","9+7=9","6+7=9","8-7=9","8+7=3","8+7=5","3+8=9","5+8=9","9-8=9","9+8=3","9+8=5","5-6=8","6-5=8","9-8=8","6-8=8","8-9=8","8-6=8","3-9=8","5-9=8","9-3=8","9-5=8","5-5=7","7-5=7","9-7=7","6-7=7","3-8=7","5-8=7","9-9=7","9-6=7","5+4=2","9+6=2","9-8=2","6+6=2","6-8=2","8+5=2","3+7=2","5+7=2","5+3=3","5-9=3","5-3=9","9+5=3","9-9=3","9-5=9","6+5=3","6-6=3","6-9=3","6-5=9","3+6=3","3-8=3","3-6=9","5+6=3","5-8=3","5-6=9","9+5=3","9-5=9","5+2=4","9+4=4","6+4=4","3+5=4","3-6=4","3-9=4","5+5=4","5-6=4","5-9=4","5-7=5","9+3=5","9-9=5","9-3=9","6+3=5","6-9=5","6-3=6","6-3=9","3+4=5","3-4=6","3-4=9","5+4=5","5-4=6","5-4=9","5-8=6","6-8=5","7-7=5","9+2=6","9-2=8","6+2=6","6-2=8","8+2=5","3-9=6","3-3=8","5+3=6","5-9=6","5-3=8","9+3=5","9-9=5","9-7=7","6-7=7","3+2=7","9-8=8","6-8=8","8-8=9","8-8=6","3-7=8","5-7=8","9-7=9","9-7=6","3-8=9","5-8=9","9-8=3","9-8=5"],SQRT3=Math.sqrt(3),F2=.5*(SQRT3-1),G2=(3-SQRT3)/6,fastFloor=s=>Math.floor(s)|0,grad2=new Float64Array([1,1,-1,1,1,-1,-1,-1,1,0,-1,0,1,0,-1,0,0,1,0,-1,0,1,0,-1]);function createNoise2D(s=Math.random){const t=buildPermutationTable(s),e=new Float64Array(t).map(n=>grad2[n%12*2]),i=new Float64Array(t).map(n=>grad2[n%12*2+1]);return function(o,r){let l=0,a=0,h=0;const c=(o+r)*F2,p=fastFloor(o+c),g=fastFloor(r+c),w=(p+g)*G2,C=p-w,m=g-w,y=o-C,f=r-m;let u,b;y>f?(u=1,b=0):(u=0,b=1);const v=y-u+G2,L=f-b+G2,_=y-1+2*G2,I=f-1+2*G2,D=p&255,T=g&255;let S=.5-y*y-f*f;if(S>=0){const A=D+t[T],$=e[A],M=i[A];S*=S,l=S*S*($*y+M*f)}let E=.5-v*v-L*L;if(E>=0){const A=D+u+t[T+b],$=e[A],M=i[A];E*=E,a=E*E*($*v+M*L)}let k=.5-_*_-I*I;if(k>=0){const A=D+1+t[T+1],$=e[A],M=i[A];k*=k,h=k*k*($*_+M*I)}return 70*(l+a+h)}}function buildPermutationTable(s){const e=new Uint8Array(512);for(let i=0;i<512/2;i++)e[i]=i;for(let i=0;i<512/2-1;i++){const n=i+~~(s()*(256-i)),o=e[i];e[i]=e[n],e[n]=o}for(let i=256;i<512;i++)e[i]=e[i-256];return e}const vec2={fromValues(s,t){return[s,t]},add(s,t,e){return s[0]=t[0]+e[0],s[1]=t[1]+e[1],s},scale(s,t,e){return s[0]=t[0]*e,s[1]=t[1]*e,s},rotate(s,t,e){const i=Math.cos(e),n=Math.sin(e),o=t[0],r=t[1];return s[0]=o*i-r*n,s[1]=o*n+r*i,s},lerp(s,t,e,i){return s[0]=lerp(t[0],e[0],i),s[1]=lerp(t[1],e[1],i),s}};function lerp(s,t,e){return s*(1-e)+t*e}class Stick{constructor(t,e){d(this,"angle",0);d(this,"slotIndex");d(this,"isLocked",!1);d(this,"verts");d(this,"headVerts");this.pos=t,this.originalSlotIndex=e,this.slotIndex=e}resetGraphics(){this.verts=void 0,this.headVerts=void 0}draw(t,e,i,n){const{pos:o,angle:r}=this;this.verts||(this.verts=computeStickVerts(),this.headVerts=computeHeadVerts()),this.outline(t,e,i,n),traceStick(t,o,r,this.verts),t.fillStyle=n?"rgba(216, 188, 160, 1)":"#c96",t.fill(),traceStick(t,o,r,this.headVerts),t.fillStyle=n?"#7D2020":"#970303",t.fill()}outline(t,e,i,n){const{pos:o,angle:r}=this,{hlThickness:l}=getScaledGfxConfigVals();!i&&!e||(traceStick(t,o,r,this.verts),i?(t.strokeStyle="#CCC",t.lineWidth=l,t.stroke()):e&&(t.strokeStyle="black",t.lineWidth=l,t.stroke()),traceStick(t,o,r,this.headVerts),i?(t.strokeStyle="#CCC",t.lineWidth=l,t.stroke()):e&&(t.strokeStyle="black",t.lineWidth=l,t.stroke()))}}function computeHeadVerts(){const{stickLong:s,stickShort:t}=getScaledGfxConfigVals(),e=s/2,i=t/2,n=[],o=10,r=1.5*i,l=Math.random()>.5?[-e,0]:[e,0];for(let a=0;a<o;a++){const h=a*2*Math.PI/o,c=[l[0]+Math.cos(h)*r,l[1]+Math.sin(h)*r];n.push(c)}return n}function computeStickVerts(){const{stickLong:s,stickShort:t,stickLongAmp:e,stickShortAmp:i}=getScaledGfxConfigVals(),{stickLongSegments:n,stickLongFreq:o,stickShortSegments:r,stickShortFreq:l}=gfxConfig.flatConfig,a=Math.exp(o),h=Math.exp(l),c=s/2,p=t/2,g=[[-c,-p],[c,-p],[c,p],[-c,p]],w=[];return buildSide(g[0],g[1],n,[0,e],a,w),buildSide(g[1],g[2],r,[i,0],h,w),buildSide(g[2],g[3],n,[0,e],a,w),buildSide(g[3],g[0],r,[i,0],h,w),w}function buildSide(s,t,e,i,n,o){const r=createNoise2D(),l=0,a=e-l;for(let h=l;h<a;h++){const c=vec2.lerp([0,0],s,t,h/e),p=vec2.scale([0,0],i,r(...vec2.scale([0,0],c,n)));vec2.add(c,c,p),o.push(c)}}function traceStick(s,t,e,i){s.save(),s.translate(...t),s.rotate(e),s.beginPath(),s.moveTo(i[0][0],i[0][1]);for(let n=1;n<i.length;++n)s.lineTo(i[n][0],i[n][1]);s.closePath(),s.restore()}function buildSticks(s){var i;const t=[];let e=0;for(const n of s){for(const o of n.sticks){const r=new Stick([0,0],o+e);(i=n.lockedSticks)!=null&&i.includes(o)&&(r.isLocked=!0),t.push(r)}e+=n.board.slots.length}return t}function evalEquation(s){if(!s.includes("="))return!1;const t=s.indexOf("=");if(s.lastIndexOf("=")!==t)return!1;const e=s.substring(0,t),i=s.substring(t+1),n=evalExpression(e),o=evalExpression(i);return typeof n=="number"&&typeof o=="number"&&n===o}function evalExpression(expression){try{return eval(expression)}catch{return}}function parseSymbols(s,t){let e=0;const i=[];for(const n of s){const o=t.filter(l=>l>=e&&l<e+n.board.slots.length).map(l=>l-e),r=parseSymbol(n.board,o);if(r===void 0)return;i.push(r),e+=n.board.slots.length}return i.join("")}function parseSymbol(s,t){for(const e in s.symbols)for(const i of s.symbols[e])if(indicesEqual(t,i))return e;if(s===SINGLE_DIGIT_BOARD)return"?"}function indicesEqual(s,t){if(s.length!==t.length)return!1;for(let e=0;e<s.length;++e)if(s[e]!==t[e])return!1;return!0}function getHint(s,t){const e=s.map(o=>o.originalSlotIndex).filter(o=>typeof o=="number").sort((o,r)=>o-r);let i=0;for(const o of t)i+=o.board.slots.length;const n=[];for(let o=0;o<i;o++)e.includes(o)||n.push(o);for(const o of e)for(const r of n){const l=[...e.filter(h=>h!==o),r];l.sort((h,c)=>h-c);const a=parseSymbols(t,l);if(a&&evalEquation(a)){const h=s.find(c=>c.originalSlotIndex===o);h&&(h.angle+=Math.PI/2)}}}/**
 * lil-gui
 * https://lil-gui.georgealways.com
 * @version 0.20.0
 * @author George Michael Brower
 * @license MIT
 */class Controller{constructor(t,e,i,n,o="div"){this.parent=t,this.object=e,this.property=i,this._disabled=!1,this._hidden=!1,this.initialValue=this.getValue(),this.domElement=document.createElement(o),this.domElement.classList.add("controller"),this.domElement.classList.add(n),this.$name=document.createElement("div"),this.$name.classList.add("name"),Controller.nextNameID=Controller.nextNameID||0,this.$name.id=`lil-gui-name-${++Controller.nextNameID}`,this.$widget=document.createElement("div"),this.$widget.classList.add("widget"),this.$disable=this.$widget,this.domElement.appendChild(this.$name),this.domElement.appendChild(this.$widget),this.domElement.addEventListener("keydown",r=>r.stopPropagation()),this.domElement.addEventListener("keyup",r=>r.stopPropagation()),this.parent.children.push(this),this.parent.controllers.push(this),this.parent.$children.appendChild(this.domElement),this._listenCallback=this._listenCallback.bind(this),this.name(i)}name(t){return this._name=t,this.$name.textContent=t,this}onChange(t){return this._onChange=t,this}_callOnChange(){this.parent._callOnChange(this),this._onChange!==void 0&&this._onChange.call(this,this.getValue()),this._changed=!0}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(){this._changed&&(this.parent._callOnFinishChange(this),this._onFinishChange!==void 0&&this._onFinishChange.call(this,this.getValue())),this._changed=!1}reset(){return this.setValue(this.initialValue),this._callOnFinishChange(),this}enable(t=!0){return this.disable(!t)}disable(t=!0){return t===this._disabled?this:(this._disabled=t,this.domElement.classList.toggle("disabled",t),this.$disable.toggleAttribute("disabled",t),this)}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}options(t){const e=this.parent.add(this.object,this.property,t);return e.name(this._name),this.destroy(),e}min(t){return this}max(t){return this}step(t){return this}decimals(t){return this}listen(t=!0){return this._listening=t,this._listenCallbackID!==void 0&&(cancelAnimationFrame(this._listenCallbackID),this._listenCallbackID=void 0),this._listening&&this._listenCallback(),this}_listenCallback(){this._listenCallbackID=requestAnimationFrame(this._listenCallback);const t=this.save();t!==this._listenPrevValue&&this.updateDisplay(),this._listenPrevValue=t}getValue(){return this.object[this.property]}setValue(t){return this.getValue()!==t&&(this.object[this.property]=t,this._callOnChange(),this.updateDisplay()),this}updateDisplay(){return this}load(t){return this.setValue(t),this._callOnFinishChange(),this}save(){return this.getValue()}destroy(){this.listen(!1),this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.controllers.splice(this.parent.controllers.indexOf(this),1),this.parent.$children.removeChild(this.domElement)}}class BooleanController extends Controller{constructor(t,e,i){super(t,e,i,"boolean","label"),this.$input=document.createElement("input"),this.$input.setAttribute("type","checkbox"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$widget.appendChild(this.$input),this.$input.addEventListener("change",()=>{this.setValue(this.$input.checked),this._callOnFinishChange()}),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.checked=this.getValue(),this}}function normalizeColorString(s){let t,e;return(t=s.match(/(#|0x)?([a-f0-9]{6})/i))?e=t[2]:(t=s.match(/rgb\(\s*(\d*)\s*,\s*(\d*)\s*,\s*(\d*)\s*\)/))?e=parseInt(t[1]).toString(16).padStart(2,0)+parseInt(t[2]).toString(16).padStart(2,0)+parseInt(t[3]).toString(16).padStart(2,0):(t=s.match(/^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i))&&(e=t[1]+t[1]+t[2]+t[2]+t[3]+t[3]),e?"#"+e:!1}const STRING={isPrimitive:!0,match:s=>typeof s=="string",fromHexString:normalizeColorString,toHexString:normalizeColorString},INT={isPrimitive:!0,match:s=>typeof s=="number",fromHexString:s=>parseInt(s.substring(1),16),toHexString:s=>"#"+s.toString(16).padStart(6,0)},ARRAY={isPrimitive:!1,match:s=>Array.isArray(s),fromHexString(s,t,e=1){const i=INT.fromHexString(s);t[0]=(i>>16&255)/255*e,t[1]=(i>>8&255)/255*e,t[2]=(i&255)/255*e},toHexString([s,t,e],i=1){i=255/i;const n=s*i<<16^t*i<<8^e*i<<0;return INT.toHexString(n)}},OBJECT={isPrimitive:!1,match:s=>Object(s)===s,fromHexString(s,t,e=1){const i=INT.fromHexString(s);t.r=(i>>16&255)/255*e,t.g=(i>>8&255)/255*e,t.b=(i&255)/255*e},toHexString({r:s,g:t,b:e},i=1){i=255/i;const n=s*i<<16^t*i<<8^e*i<<0;return INT.toHexString(n)}},FORMATS=[STRING,INT,ARRAY,OBJECT];function getColorFormat(s){return FORMATS.find(t=>t.match(s))}class ColorController extends Controller{constructor(t,e,i,n){super(t,e,i,"color"),this.$input=document.createElement("input"),this.$input.setAttribute("type","color"),this.$input.setAttribute("tabindex",-1),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$text=document.createElement("input"),this.$text.setAttribute("type","text"),this.$text.setAttribute("spellcheck","false"),this.$text.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$display.appendChild(this.$input),this.$widget.appendChild(this.$display),this.$widget.appendChild(this.$text),this._format=getColorFormat(this.initialValue),this._rgbScale=n,this._initialValueHexString=this.save(),this._textFocused=!1,this.$input.addEventListener("input",()=>{this._setValueFromHexString(this.$input.value)}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$text.addEventListener("input",()=>{const o=normalizeColorString(this.$text.value);o&&this._setValueFromHexString(o)}),this.$text.addEventListener("focus",()=>{this._textFocused=!0,this.$text.select()}),this.$text.addEventListener("blur",()=>{this._textFocused=!1,this.updateDisplay(),this._callOnFinishChange()}),this.$disable=this.$text,this.updateDisplay()}reset(){return this._setValueFromHexString(this._initialValueHexString),this}_setValueFromHexString(t){if(this._format.isPrimitive){const e=this._format.fromHexString(t);this.setValue(e)}else this._format.fromHexString(t,this.getValue(),this._rgbScale),this._callOnChange(),this.updateDisplay()}save(){return this._format.toHexString(this.getValue(),this._rgbScale)}load(t){return this._setValueFromHexString(t),this._callOnFinishChange(),this}updateDisplay(){return this.$input.value=this._format.toHexString(this.getValue(),this._rgbScale),this._textFocused||(this.$text.value=this.$input.value.substring(1)),this.$display.style.backgroundColor=this.$input.value,this}}class FunctionController extends Controller{constructor(t,e,i){super(t,e,i,"function"),this.$button=document.createElement("button"),this.$button.appendChild(this.$name),this.$widget.appendChild(this.$button),this.$button.addEventListener("click",n=>{n.preventDefault(),this.getValue().call(this.object),this._callOnChange()}),this.$button.addEventListener("touchstart",()=>{},{passive:!0}),this.$disable=this.$button}}class NumberController extends Controller{constructor(t,e,i,n,o,r){super(t,e,i,"number"),this._initInput(),this.min(n),this.max(o);const l=r!==void 0;this.step(l?r:this._getImplicitStep(),l),this.updateDisplay()}decimals(t){return this._decimals=t,this.updateDisplay(),this}min(t){return this._min=t,this._onUpdateMinMax(),this}max(t){return this._max=t,this._onUpdateMinMax(),this}step(t,e=!0){return this._step=t,this._stepExplicit=e,this}updateDisplay(){const t=this.getValue();if(this._hasSlider){let e=(t-this._min)/(this._max-this._min);e=Math.max(0,Math.min(e,1)),this.$fill.style.width=e*100+"%"}return this._inputFocused||(this.$input.value=this._decimals===void 0?t:t.toFixed(this._decimals)),this}_initInput(){this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("aria-labelledby",this.$name.id),window.matchMedia("(pointer: coarse)").matches&&(this.$input.setAttribute("type","number"),this.$input.setAttribute("step","any")),this.$widget.appendChild(this.$input),this.$disable=this.$input;const e=()=>{let u=parseFloat(this.$input.value);isNaN(u)||(this._stepExplicit&&(u=this._snap(u)),this.setValue(this._clamp(u)))},i=u=>{const b=parseFloat(this.$input.value);isNaN(b)||(this._snapClampSetValue(b+u),this.$input.value=this.getValue())},n=u=>{u.key==="Enter"&&this.$input.blur(),u.code==="ArrowUp"&&(u.preventDefault(),i(this._step*this._arrowKeyMultiplier(u))),u.code==="ArrowDown"&&(u.preventDefault(),i(this._step*this._arrowKeyMultiplier(u)*-1))},o=u=>{this._inputFocused&&(u.preventDefault(),i(this._step*this._normalizeMouseWheel(u)))};let r=!1,l,a,h,c,p;const g=5,w=u=>{l=u.clientX,a=h=u.clientY,r=!0,c=this.getValue(),p=0,window.addEventListener("mousemove",C),window.addEventListener("mouseup",m)},C=u=>{if(r){const b=u.clientX-l,v=u.clientY-a;Math.abs(v)>g?(u.preventDefault(),this.$input.blur(),r=!1,this._setDraggingStyle(!0,"vertical")):Math.abs(b)>g&&m()}if(!r){const b=u.clientY-h;p-=b*this._step*this._arrowKeyMultiplier(u),c+p>this._max?p=this._max-c:c+p<this._min&&(p=this._min-c),this._snapClampSetValue(c+p)}h=u.clientY},m=()=>{this._setDraggingStyle(!1,"vertical"),this._callOnFinishChange(),window.removeEventListener("mousemove",C),window.removeEventListener("mouseup",m)},y=()=>{this._inputFocused=!0},f=()=>{this._inputFocused=!1,this.updateDisplay(),this._callOnFinishChange()};this.$input.addEventListener("input",e),this.$input.addEventListener("keydown",n),this.$input.addEventListener("wheel",o,{passive:!1}),this.$input.addEventListener("mousedown",w),this.$input.addEventListener("focus",y),this.$input.addEventListener("blur",f)}_initSlider(){this._hasSlider=!0,this.$slider=document.createElement("div"),this.$slider.classList.add("slider"),this.$fill=document.createElement("div"),this.$fill.classList.add("fill"),this.$slider.appendChild(this.$fill),this.$widget.insertBefore(this.$slider,this.$input),this.domElement.classList.add("hasSlider");const t=(f,u,b,v,L)=>(f-u)/(b-u)*(L-v)+v,e=f=>{const u=this.$slider.getBoundingClientRect();let b=t(f,u.left,u.right,this._min,this._max);this._snapClampSetValue(b)},i=f=>{this._setDraggingStyle(!0),e(f.clientX),window.addEventListener("mousemove",n),window.addEventListener("mouseup",o)},n=f=>{e(f.clientX)},o=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("mousemove",n),window.removeEventListener("mouseup",o)};let r=!1,l,a;const h=f=>{f.preventDefault(),this._setDraggingStyle(!0),e(f.touches[0].clientX),r=!1},c=f=>{f.touches.length>1||(this._hasScrollBar?(l=f.touches[0].clientX,a=f.touches[0].clientY,r=!0):h(f),window.addEventListener("touchmove",p,{passive:!1}),window.addEventListener("touchend",g))},p=f=>{if(r){const u=f.touches[0].clientX-l,b=f.touches[0].clientY-a;Math.abs(u)>Math.abs(b)?h(f):(window.removeEventListener("touchmove",p),window.removeEventListener("touchend",g))}else f.preventDefault(),e(f.touches[0].clientX)},g=()=>{this._callOnFinishChange(),this._setDraggingStyle(!1),window.removeEventListener("touchmove",p),window.removeEventListener("touchend",g)},w=this._callOnFinishChange.bind(this),C=400;let m;const y=f=>{if(Math.abs(f.deltaX)<Math.abs(f.deltaY)&&this._hasScrollBar)return;f.preventDefault();const b=this._normalizeMouseWheel(f)*this._step;this._snapClampSetValue(this.getValue()+b),this.$input.value=this.getValue(),clearTimeout(m),m=setTimeout(w,C)};this.$slider.addEventListener("mousedown",i),this.$slider.addEventListener("touchstart",c,{passive:!1}),this.$slider.addEventListener("wheel",y,{passive:!1})}_setDraggingStyle(t,e="horizontal"){this.$slider&&this.$slider.classList.toggle("active",t),document.body.classList.toggle("lil-gui-dragging",t),document.body.classList.toggle(`lil-gui-${e}`,t)}_getImplicitStep(){return this._hasMin&&this._hasMax?(this._max-this._min)/1e3:.1}_onUpdateMinMax(){!this._hasSlider&&this._hasMin&&this._hasMax&&(this._stepExplicit||this.step(this._getImplicitStep(),!1),this._initSlider(),this.updateDisplay())}_normalizeMouseWheel(t){let{deltaX:e,deltaY:i}=t;return Math.floor(t.deltaY)!==t.deltaY&&t.wheelDelta&&(e=0,i=-t.wheelDelta/120,i*=this._stepExplicit?1:10),e+-i}_arrowKeyMultiplier(t){let e=this._stepExplicit?1:10;return t.shiftKey?e*=10:t.altKey&&(e/=10),e}_snap(t){let e=0;return this._hasMin?e=this._min:this._hasMax&&(e=this._max),t-=e,t=Math.round(t/this._step)*this._step,t+=e,t=parseFloat(t.toPrecision(15)),t}_clamp(t){return t<this._min&&(t=this._min),t>this._max&&(t=this._max),t}_snapClampSetValue(t){this.setValue(this._clamp(this._snap(t)))}get _hasScrollBar(){const t=this.parent.root.$children;return t.scrollHeight>t.clientHeight}get _hasMin(){return this._min!==void 0}get _hasMax(){return this._max!==void 0}}class OptionController extends Controller{constructor(t,e,i,n){super(t,e,i,"option"),this.$select=document.createElement("select"),this.$select.setAttribute("aria-labelledby",this.$name.id),this.$display=document.createElement("div"),this.$display.classList.add("display"),this.$select.addEventListener("change",()=>{this.setValue(this._values[this.$select.selectedIndex]),this._callOnFinishChange()}),this.$select.addEventListener("focus",()=>{this.$display.classList.add("focus")}),this.$select.addEventListener("blur",()=>{this.$display.classList.remove("focus")}),this.$widget.appendChild(this.$select),this.$widget.appendChild(this.$display),this.$disable=this.$select,this.options(n)}options(t){return this._values=Array.isArray(t)?t:Object.values(t),this._names=Array.isArray(t)?t:Object.keys(t),this.$select.replaceChildren(),this._names.forEach(e=>{const i=document.createElement("option");i.textContent=e,this.$select.appendChild(i)}),this.updateDisplay(),this}updateDisplay(){const t=this.getValue(),e=this._values.indexOf(t);return this.$select.selectedIndex=e,this.$display.textContent=e===-1?t:this._names[e],this}}class StringController extends Controller{constructor(t,e,i){super(t,e,i,"string"),this.$input=document.createElement("input"),this.$input.setAttribute("type","text"),this.$input.setAttribute("spellcheck","false"),this.$input.setAttribute("aria-labelledby",this.$name.id),this.$input.addEventListener("input",()=>{this.setValue(this.$input.value)}),this.$input.addEventListener("keydown",n=>{n.code==="Enter"&&this.$input.blur()}),this.$input.addEventListener("blur",()=>{this._callOnFinishChange()}),this.$widget.appendChild(this.$input),this.$disable=this.$input,this.updateDisplay()}updateDisplay(){return this.$input.value=this.getValue(),this}}var stylesheet=`.lil-gui {
  font-family: var(--font-family);
  font-size: var(--font-size);
  line-height: 1;
  font-weight: normal;
  font-style: normal;
  text-align: left;
  color: var(--text-color);
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  --background-color: #1f1f1f;
  --text-color: #ebebeb;
  --title-background-color: #111111;
  --title-text-color: #ebebeb;
  --widget-color: #424242;
  --hover-color: #4f4f4f;
  --focus-color: #595959;
  --number-color: #2cc9ff;
  --string-color: #a2db3c;
  --font-size: 11px;
  --input-font-size: 11px;
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  --font-family-mono: Menlo, Monaco, Consolas, "Droid Sans Mono", monospace;
  --padding: 4px;
  --spacing: 4px;
  --widget-height: 20px;
  --title-height: calc(var(--widget-height) + var(--spacing) * 1.25);
  --name-width: 45%;
  --slider-knob-width: 2px;
  --slider-input-width: 27%;
  --color-input-width: 27%;
  --slider-input-min-width: 45px;
  --color-input-min-width: 45px;
  --folder-indent: 7px;
  --widget-padding: 0 0 0 3px;
  --widget-border-radius: 2px;
  --checkbox-size: calc(0.75 * var(--widget-height));
  --scrollbar-width: 5px;
}
.lil-gui, .lil-gui * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.lil-gui.root {
  width: var(--width, 245px);
  display: flex;
  flex-direction: column;
  background: var(--background-color);
}
.lil-gui.root > .title {
  background: var(--title-background-color);
  color: var(--title-text-color);
}
.lil-gui.root > .children {
  overflow-x: hidden;
  overflow-y: auto;
}
.lil-gui.root > .children::-webkit-scrollbar {
  width: var(--scrollbar-width);
  height: var(--scrollbar-width);
  background: var(--background-color);
}
.lil-gui.root > .children::-webkit-scrollbar-thumb {
  border-radius: var(--scrollbar-width);
  background: var(--focus-color);
}
@media (pointer: coarse) {
  .lil-gui.allow-touch-styles, .lil-gui.allow-touch-styles .lil-gui {
    --widget-height: 28px;
    --padding: 6px;
    --spacing: 6px;
    --font-size: 13px;
    --input-font-size: 16px;
    --folder-indent: 10px;
    --scrollbar-width: 7px;
    --slider-input-min-width: 50px;
    --color-input-min-width: 65px;
  }
}
.lil-gui.force-touch-styles, .lil-gui.force-touch-styles .lil-gui {
  --widget-height: 28px;
  --padding: 6px;
  --spacing: 6px;
  --font-size: 13px;
  --input-font-size: 16px;
  --folder-indent: 10px;
  --scrollbar-width: 7px;
  --slider-input-min-width: 50px;
  --color-input-min-width: 65px;
}
.lil-gui.autoPlace {
  max-height: 100%;
  position: fixed;
  top: 0;
  right: 15px;
  z-index: 1001;
}

.lil-gui .controller {
  display: flex;
  align-items: center;
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
}
.lil-gui .controller.disabled {
  opacity: 0.5;
}
.lil-gui .controller.disabled, .lil-gui .controller.disabled * {
  pointer-events: none !important;
}
.lil-gui .controller > .name {
  min-width: var(--name-width);
  flex-shrink: 0;
  white-space: pre;
  padding-right: var(--spacing);
  line-height: var(--widget-height);
}
.lil-gui .controller .widget {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
  min-height: var(--widget-height);
}
.lil-gui .controller.string input {
  color: var(--string-color);
}
.lil-gui .controller.boolean {
  cursor: pointer;
}
.lil-gui .controller.color .display {
  width: 100%;
  height: var(--widget-height);
  border-radius: var(--widget-border-radius);
  position: relative;
}
@media (hover: hover) {
  .lil-gui .controller.color .display:hover:before {
    content: " ";
    display: block;
    position: absolute;
    border-radius: var(--widget-border-radius);
    border: 1px solid #fff9;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
  }
}
.lil-gui .controller.color input[type=color] {
  opacity: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
}
.lil-gui .controller.color input[type=text] {
  margin-left: var(--spacing);
  font-family: var(--font-family-mono);
  min-width: var(--color-input-min-width);
  width: var(--color-input-width);
  flex-shrink: 0;
}
.lil-gui .controller.option select {
  opacity: 0;
  position: absolute;
  width: 100%;
  max-width: 100%;
}
.lil-gui .controller.option .display {
  position: relative;
  pointer-events: none;
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  line-height: var(--widget-height);
  max-width: 100%;
  overflow: hidden;
  word-break: break-all;
  padding-left: 0.55em;
  padding-right: 1.75em;
  background: var(--widget-color);
}
@media (hover: hover) {
  .lil-gui .controller.option .display.focus {
    background: var(--focus-color);
  }
}
.lil-gui .controller.option .display.active {
  background: var(--focus-color);
}
.lil-gui .controller.option .display:after {
  font-family: "lil-gui";
  content: "↕";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding-right: 0.375em;
}
.lil-gui .controller.option .widget,
.lil-gui .controller.option select {
  cursor: pointer;
}
@media (hover: hover) {
  .lil-gui .controller.option .widget:hover .display {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number input {
  color: var(--number-color);
}
.lil-gui .controller.number.hasSlider input {
  margin-left: var(--spacing);
  width: var(--slider-input-width);
  min-width: var(--slider-input-min-width);
  flex-shrink: 0;
}
.lil-gui .controller.number .slider {
  width: 100%;
  height: var(--widget-height);
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
  padding-right: var(--slider-knob-width);
  overflow: hidden;
  cursor: ew-resize;
  touch-action: pan-y;
}
@media (hover: hover) {
  .lil-gui .controller.number .slider:hover {
    background: var(--hover-color);
  }
}
.lil-gui .controller.number .slider.active {
  background: var(--focus-color);
}
.lil-gui .controller.number .slider.active .fill {
  opacity: 0.95;
}
.lil-gui .controller.number .fill {
  height: 100%;
  border-right: var(--slider-knob-width) solid var(--number-color);
  box-sizing: content-box;
}

.lil-gui-dragging .lil-gui {
  --hover-color: var(--widget-color);
}
.lil-gui-dragging * {
  cursor: ew-resize !important;
}

.lil-gui-dragging.lil-gui-vertical * {
  cursor: ns-resize !important;
}

.lil-gui .title {
  height: var(--title-height);
  font-weight: 600;
  padding: 0 var(--padding);
  width: 100%;
  text-align: left;
  background: none;
  text-decoration-skip: objects;
}
.lil-gui .title:before {
  font-family: "lil-gui";
  content: "▾";
  padding-right: 2px;
  display: inline-block;
}
.lil-gui .title:active {
  background: var(--title-background-color);
  opacity: 0.75;
}
@media (hover: hover) {
  body:not(.lil-gui-dragging) .lil-gui .title:hover {
    background: var(--title-background-color);
    opacity: 0.85;
  }
  .lil-gui .title:focus {
    text-decoration: underline var(--focus-color);
  }
}
.lil-gui.root > .title:focus {
  text-decoration: none !important;
}
.lil-gui.closed > .title:before {
  content: "▸";
}
.lil-gui.closed > .children {
  transform: translateY(-7px);
  opacity: 0;
}
.lil-gui.closed:not(.transition) > .children {
  display: none;
}
.lil-gui.transition > .children {
  transition-duration: 300ms;
  transition-property: height, opacity, transform;
  transition-timing-function: cubic-bezier(0.2, 0.6, 0.35, 1);
  overflow: hidden;
  pointer-events: none;
}
.lil-gui .children:empty:before {
  content: "Empty";
  padding: 0 var(--padding);
  margin: var(--spacing) 0;
  display: block;
  height: var(--widget-height);
  font-style: italic;
  line-height: var(--widget-height);
  opacity: 0.5;
}
.lil-gui.root > .children > .lil-gui > .title {
  border: 0 solid var(--widget-color);
  border-width: 1px 0;
  transition: border-color 300ms;
}
.lil-gui.root > .children > .lil-gui.closed > .title {
  border-bottom-color: transparent;
}
.lil-gui + .controller {
  border-top: 1px solid var(--widget-color);
  margin-top: 0;
  padding-top: var(--spacing);
}
.lil-gui .lil-gui .lil-gui > .title {
  border: none;
}
.lil-gui .lil-gui .lil-gui > .children {
  border: none;
  margin-left: var(--folder-indent);
  border-left: 2px solid var(--widget-color);
}
.lil-gui .lil-gui .controller {
  border: none;
}

.lil-gui label, .lil-gui input, .lil-gui button {
  -webkit-tap-highlight-color: transparent;
}
.lil-gui input {
  border: 0;
  outline: none;
  font-family: var(--font-family);
  font-size: var(--input-font-size);
  border-radius: var(--widget-border-radius);
  height: var(--widget-height);
  background: var(--widget-color);
  color: var(--text-color);
  width: 100%;
}
@media (hover: hover) {
  .lil-gui input:hover {
    background: var(--hover-color);
  }
  .lil-gui input:active {
    background: var(--focus-color);
  }
}
.lil-gui input:disabled {
  opacity: 1;
}
.lil-gui input[type=text],
.lil-gui input[type=number] {
  padding: var(--widget-padding);
  -moz-appearance: textfield;
}
.lil-gui input[type=text]:focus,
.lil-gui input[type=number]:focus {
  background: var(--focus-color);
}
.lil-gui input[type=checkbox] {
  appearance: none;
  width: var(--checkbox-size);
  height: var(--checkbox-size);
  border-radius: var(--widget-border-radius);
  text-align: center;
  cursor: pointer;
}
.lil-gui input[type=checkbox]:checked:before {
  font-family: "lil-gui";
  content: "✓";
  font-size: var(--checkbox-size);
  line-height: var(--checkbox-size);
}
@media (hover: hover) {
  .lil-gui input[type=checkbox]:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui button {
  outline: none;
  cursor: pointer;
  font-family: var(--font-family);
  font-size: var(--font-size);
  color: var(--text-color);
  width: 100%;
  border: none;
}
.lil-gui .controller button {
  height: var(--widget-height);
  text-transform: none;
  background: var(--widget-color);
  border-radius: var(--widget-border-radius);
}
@media (hover: hover) {
  .lil-gui .controller button:hover {
    background: var(--hover-color);
  }
  .lil-gui .controller button:focus {
    box-shadow: inset 0 0 0 1px var(--focus-color);
  }
}
.lil-gui .controller button:active {
  background: var(--focus-color);
}

@font-face {
  font-family: "lil-gui";
  src: url("data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAUsAAsAAAAACJwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAAH4AAADAImwmYE9TLzIAAAGIAAAAPwAAAGBKqH5SY21hcAAAAcgAAAD0AAACrukyyJBnbHlmAAACvAAAAF8AAACEIZpWH2hlYWQAAAMcAAAAJwAAADZfcj2zaGhlYQAAA0QAAAAYAAAAJAC5AHhobXR4AAADXAAAABAAAABMAZAAAGxvY2EAAANsAAAAFAAAACgCEgIybWF4cAAAA4AAAAAeAAAAIAEfABJuYW1lAAADoAAAASIAAAIK9SUU/XBvc3QAAATEAAAAZgAAAJCTcMc2eJxVjbEOgjAURU+hFRBK1dGRL+ALnAiToyMLEzFpnPz/eAshwSa97517c/MwwJmeB9kwPl+0cf5+uGPZXsqPu4nvZabcSZldZ6kfyWnomFY/eScKqZNWupKJO6kXN3K9uCVoL7iInPr1X5baXs3tjuMqCtzEuagm/AAlzQgPAAB4nGNgYRBlnMDAysDAYM/gBiT5oLQBAwuDJAMDEwMrMwNWEJDmmsJwgCFeXZghBcjlZMgFCzOiKOIFAB71Bb8AeJy1kjFuwkAQRZ+DwRAwBtNQRUGKQ8OdKCAWUhAgKLhIuAsVSpWz5Bbkj3dEgYiUIszqWdpZe+Z7/wB1oCYmIoboiwiLT2WjKl/jscrHfGg/pKdMkyklC5Zs2LEfHYpjcRoPzme9MWWmk3dWbK9ObkWkikOetJ554fWyoEsmdSlt+uR0pCJR34b6t/TVg1SY3sYvdf8vuiKrpyaDXDISiegp17p7579Gp3p++y7HPAiY9pmTibljrr85qSidtlg4+l25GLCaS8e6rRxNBmsnERunKbaOObRz7N72ju5vdAjYpBXHgJylOAVsMseDAPEP8LYoUHicY2BiAAEfhiAGJgZWBgZ7RnFRdnVJELCQlBSRlATJMoLV2DK4glSYs6ubq5vbKrJLSbGrgEmovDuDJVhe3VzcXFwNLCOILB/C4IuQ1xTn5FPilBTj5FPmBAB4WwoqAHicY2BkYGAA4sk1sR/j+W2+MnAzpDBgAyEMQUCSg4EJxAEAwUgFHgB4nGNgZGBgSGFggJMhDIwMqEAYAByHATJ4nGNgAIIUNEwmAABl3AGReJxjYAACIQYlBiMGJ3wQAEcQBEV4nGNgZGBgEGZgY2BiAAEQyQWEDAz/wXwGAAsPATIAAHicXdBNSsNAHAXwl35iA0UQXYnMShfS9GPZA7T7LgIu03SSpkwzYTIt1BN4Ak/gKTyAeCxfw39jZkjymzcvAwmAW/wgwHUEGDb36+jQQ3GXGot79L24jxCP4gHzF/EIr4jEIe7wxhOC3g2TMYy4Q7+Lu/SHuEd/ivt4wJd4wPxbPEKMX3GI5+DJFGaSn4qNzk8mcbKSR6xdXdhSzaOZJGtdapd4vVPbi6rP+cL7TGXOHtXKll4bY1Xl7EGnPtp7Xy2n00zyKLVHfkHBa4IcJ2oD3cgggWvt/V/FbDrUlEUJhTn/0azVWbNTNr0Ens8de1tceK9xZmfB1CPjOmPH4kitmvOubcNpmVTN3oFJyjzCvnmrwhJTzqzVj9jiSX911FjeAAB4nG3HMRKCMBBA0f0giiKi4DU8k0V2GWbIZDOh4PoWWvq6J5V8If9NVNQcaDhyouXMhY4rPTcG7jwYmXhKq8Wz+p762aNaeYXom2n3m2dLTVgsrCgFJ7OTmIkYbwIbC6vIB7WmFfAAAA==") format("woff");
}`;function _injectStyles(s){const t=document.createElement("style");t.innerHTML=s;const e=document.querySelector("head link[rel=stylesheet], head style");e?document.head.insertBefore(t,e):document.head.appendChild(t)}let stylesInjected=!1;class GUI{constructor({parent:t,autoPlace:e=t===void 0,container:i,width:n,title:o="Controls",closeFolders:r=!1,injectStyles:l=!0,touchStyles:a=!0}={}){if(this.parent=t,this.root=t?t.root:this,this.children=[],this.controllers=[],this.folders=[],this._closed=!1,this._hidden=!1,this.domElement=document.createElement("div"),this.domElement.classList.add("lil-gui"),this.$title=document.createElement("button"),this.$title.classList.add("title"),this.$title.setAttribute("aria-expanded",!0),this.$title.addEventListener("click",()=>this.openAnimated(this._closed)),this.$title.addEventListener("touchstart",()=>{},{passive:!0}),this.$children=document.createElement("div"),this.$children.classList.add("children"),this.domElement.appendChild(this.$title),this.domElement.appendChild(this.$children),this.title(o),this.parent){this.parent.children.push(this),this.parent.folders.push(this),this.parent.$children.appendChild(this.domElement);return}this.domElement.classList.add("root"),a&&this.domElement.classList.add("allow-touch-styles"),!stylesInjected&&l&&(_injectStyles(stylesheet),stylesInjected=!0),i?i.appendChild(this.domElement):e&&(this.domElement.classList.add("autoPlace"),document.body.appendChild(this.domElement)),n&&this.domElement.style.setProperty("--width",n+"px"),this._closeFolders=r}add(t,e,i,n,o){if(Object(i)===i)return new OptionController(this,t,e,i);const r=t[e];switch(typeof r){case"number":return new NumberController(this,t,e,i,n,o);case"boolean":return new BooleanController(this,t,e);case"string":return new StringController(this,t,e);case"function":return new FunctionController(this,t,e)}console.error(`gui.add failed
	property:`,e,`
	object:`,t,`
	value:`,r)}addColor(t,e,i=1){return new ColorController(this,t,e,i)}addFolder(t){const e=new GUI({parent:this,title:t});return this.root._closeFolders&&e.close(),e}load(t,e=!0){return t.controllers&&this.controllers.forEach(i=>{i instanceof FunctionController||i._name in t.controllers&&i.load(t.controllers[i._name])}),e&&t.folders&&this.folders.forEach(i=>{i._title in t.folders&&i.load(t.folders[i._title])}),this}save(t=!0){const e={controllers:{},folders:{}};return this.controllers.forEach(i=>{if(!(i instanceof FunctionController)){if(i._name in e.controllers)throw new Error(`Cannot save GUI with duplicate property "${i._name}"`);e.controllers[i._name]=i.save()}}),t&&this.folders.forEach(i=>{if(i._title in e.folders)throw new Error(`Cannot save GUI with duplicate folder "${i._title}"`);e.folders[i._title]=i.save()}),e}open(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),this.domElement.classList.toggle("closed",this._closed),this}close(){return this.open(!1)}_setClosed(t){this._closed!==t&&(this._closed=t,this._callOnOpenClose(this))}show(t=!0){return this._hidden=!t,this.domElement.style.display=this._hidden?"none":"",this}hide(){return this.show(!1)}openAnimated(t=!0){return this._setClosed(!t),this.$title.setAttribute("aria-expanded",!this._closed),requestAnimationFrame(()=>{const e=this.$children.clientHeight;this.$children.style.height=e+"px",this.domElement.classList.add("transition");const i=o=>{o.target===this.$children&&(this.$children.style.height="",this.domElement.classList.remove("transition"),this.$children.removeEventListener("transitionend",i))};this.$children.addEventListener("transitionend",i);const n=t?this.$children.scrollHeight:0;this.domElement.classList.toggle("closed",!t),requestAnimationFrame(()=>{this.$children.style.height=n+"px"})}),this}title(t){return this._title=t,this.$title.textContent=t,this}reset(t=!0){return(t?this.controllersRecursive():this.controllers).forEach(i=>i.reset()),this}onChange(t){return this._onChange=t,this}_callOnChange(t){this.parent&&this.parent._callOnChange(t),this._onChange!==void 0&&this._onChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onFinishChange(t){return this._onFinishChange=t,this}_callOnFinishChange(t){this.parent&&this.parent._callOnFinishChange(t),this._onFinishChange!==void 0&&this._onFinishChange.call(this,{object:t.object,property:t.property,value:t.getValue(),controller:t})}onOpenClose(t){return this._onOpenClose=t,this}_callOnOpenClose(t){this.parent&&this.parent._callOnOpenClose(t),this._onOpenClose!==void 0&&this._onOpenClose.call(this,t)}destroy(){this.parent&&(this.parent.children.splice(this.parent.children.indexOf(this),1),this.parent.folders.splice(this.parent.folders.indexOf(this),1)),this.domElement.parentElement&&this.domElement.parentElement.removeChild(this.domElement),Array.from(this.children).forEach(t=>t.destroy())}controllersRecursive(){let t=Array.from(this.controllers);return this.folders.forEach(e=>{t=t.concat(e.controllersRecursive())}),t}foldersRecursive(){let t=Array.from(this.folders);return this.folders.forEach(e=>{t=t.concat(e.foldersRecursive())}),t}}let _allControls={},gui;function showDebugControls(s){const t=s.config.tree;_allControls={},gui&&gui.destroy(),gui=new GUI({closeFolders:!0,container:document.getElementById("controls-container")}),addControls(gui,t,s),gui.onOpenClose(()=>{gui._closed&&setTimeout(()=>{gui.destroy()},200)})}function addControls(s,t,e){const i=t.children;for(const n in i){const o=i[n];if(!("isHidden"in o&&o.isHidden))if("action"in o){const r=o,l=o.label??camelCaseToLabel(n),a={[l]:async()=>{await r.action(e)}};s.add(a,l)}else if("options"in o&&Array.isArray(o.options)){const r=o,l={};for(const h of r.options)typeof h=="string"&&(l[h]=h);const a=s.add(r,"value",l).name(r.label??camelCaseToLabel(n)).listen();a.onChange(h=>{r.value=h,r.onChange&&r.onChange(e,h)}),addTooltip(a,r.tooltip),_allControls[n]=a}else if("value"in o&&typeof o.value=="number"){const r=o,l=s.add(r,"value",r.min,r.max).name(r.label??camelCaseToLabel(n));r.step&&l.step(r.step),l.onChange(a=>{typeof a=="number"&&(r.value=a,r.onChange&&r.onChange(e,a))}),addTooltip(l,r.tooltip),_allControls[n]=l}else{const r=s.addFolder(o.label??camelCaseToLabel(n));addTooltip(r,o.tooltip),addControls(r,o,e)}}}function addTooltip(s,t){if(typeof t!="string"||t.trim()==="")return;s.domElement.setAttribute("title",t)}function camelCaseToLabel(s){return/^[A-Z0-9_]+$/.test(s)?s.toLowerCase().split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ").trim():s.replace(/([A-Z])/g," $1").replace(/^./,t=>t.toUpperCase()).trim()}let didConstruct=!1,didInit=!1;class Matchsticks{constructor(t){d(this,"config",matchsticksConfig);d(this,"layeredViewport");d(this,"gui");d(this,"level",getRandomEquationLevel());d(this,"slots");d(this,"sticks",buildSticks(this.level));d(this,"hoveredStick");d(this,"draggingStick");d(this,"draggingSlotIndex");d(this,"isFinished",!1);d(this,"interludeCountdown",0);d(this,"didBuildControls",!1);if(this.defaultLayeredViewport=t,this.layeredViewport=t,didConstruct)throw new Error("Matchsticks constructed multiple times");didConstruct=!0;for(const e of GUI$1.NAMES)Gui.preload(this,e)}init(){if(didInit)throw new Error("Matchsticks initialized multiple times");didInit=!0;for(const t of GUI$1.NAMES){const e=Gui.create(t);e instanceof ToggledGui&&e.toggle(this,!1)}this.gui=Gui.create("zero-gui"),window.addEventListener("resize",()=>this.onResize())}update(t){updateClickMeColor();const e=Math.min(1,t*gfxConfig.flatConfig.angleAlpha),i=Math.min(1,t*gfxConfig.flatConfig.posAlpha);for(const n of this.sticks){const o=this.getSlotForStick(n);let r;if(o?r=o.isHorizontal?0:Math.PI/2:r=Math.PI/4,n.angle=lerp(n.angle,r,e),o){const l=o.pos;n.pos=vec2.lerp(n.pos,n.pos,l,i)}}repaintDiagram(this,playArea)}getSlotForStick(t){if(this.slots&&typeof t.slotIndex=="number")return this.slots[t.slotIndex]}goToNextLevel(){this.level=getRandomEquationLevel(),this.sticks=buildSticks(this.level),this.slots=void 0}hint(){this.resetSticks(),getHint(this.sticks,this.level)}resetSticks(){for(const t of this.sticks)t.slotIndex=t.originalSlotIndex;this.draggingStick=void 0,this.draggingSlotIndex=void 0,this.checkSolution()}checkSolution(){let t=!1;const e=this.sticks.map(n=>n.slotIndex).filter(n=>typeof n=="number"&&n>=0).sort((n,o)=>Number(n)-Number(o)),i=parseSymbols(this.level,e);i?(t=evalEquation(i),t?setElementLabel(bottomLabel,`${i} <span style="color:blue">TRUE</span>`):setElementLabel(bottomLabel,`${i} <span style="color:red">FALSE</span>`)):setElementLabel(bottomLabel,'<span style="color:red">???</span>'),t?(showElement(nextLevelBtn),showElement(resetBtn)):(hideElement(nextLevelBtn),this.sticks.some(n=>n.originalSlotIndex!==n.slotIndex)?showElement(resetBtn):hideElement(resetBtn))}draw(t,e){this.slots||(this.slots=buildSlots(this.level,e),this.checkSolution());const[i,n,o,r]=e;if(t.clearRect(i,n,o,r),gfxConfig.flatConfig.slotsDisplay==="visible")for(const l of this.slots)l.draw(t);for(const l of this.sticks){const a=l===this.hoveredStick,h=l===this.draggingStick,c=l.slotIndex!==l.originalSlotIndex;l.draw(t,a,h,c)}}findDragSlot(t){if(this.slots){for(const[e,i]of this.slots.entries())if(i.contains(t)){const n=this.sticks.find(l=>l.slotIndex===e);if(n&&n!==this.draggingStick)continue;const o=this.sticks.filter(l=>l!==this.draggingStick).map(l=>l.slotIndex).filter(l=>typeof l=="number"&&l>=0);if(o.push(e),o.sort((l,a)=>Number(l)-Number(a)),parseSymbols(this.level,o)===void 0)continue;return e}}}move(t){if(this.draggingStick){const e=this.sticks.find(n=>n.originalSlotIndex!==n.slotIndex);e&&e!==this.draggingStick&&(e.slotIndex=e.originalSlotIndex);const i=this.findDragSlot(t);typeof i=="number"&&i>=0?(this.draggingStick.slotIndex=i,this.draggingSlotIndex=i):(this.draggingStick.slotIndex=void 0,this.draggingStick.pos=t)}else if(this.slots){const e=this.slots.findIndex((i,n)=>i.contains(t)&&this.sticks.some(o=>o.slotIndex===n&&!o.isLocked));this.hoveredStick=this.sticks.find(i=>i.slotIndex===e)}else this.hoveredStick=void 0}down(t){if(this.slots){const e=this.slots.findIndex((i,n)=>i.contains(t)&&this.sticks.some(o=>o.slotIndex===n&&!o.isLocked));this.draggingStick=this.sticks.find(i=>i.slotIndex===e),this.draggingSlotIndex=e}else this.draggingStick=void 0}up(t){this.draggingStick&&typeof this.draggingStick.slotIndex!="number"&&(this.draggingStick.slotIndex=this.draggingSlotIndex),this.draggingStick=void 0,this.checkSolution()}onResize(){this.slots=void 0,this.sticks.forEach(e=>e.resetGraphics()),this.layeredViewport=this.defaultLayeredViewport,this.layeredViewport.ctx.clearRect(0,0,this.layeredViewport.w,this.layeredViewport.h);const{layeredViewport:t}=this;t.handleResize(this);for(const e in this.gui.elements)showElement(e);this.gui.refreshLayout(this)}rebuildControls(){this.didBuildControls=!0,showDebugControls(this)}}function getTestSupport(s){return{getSetting:t=>s.config.flatConfig[t],applySetting:(t,e)=>{t in s.config.tree.children&&(s.config.tree.children[t].value=e),s.config.flatConfig[t]=e,s.onResize()},getGameState:()=>"playing",getCursorState:()=>({x:window.mouseXForTestSupport,y:window.mouseYForTestSupport,style:window.mouseCursorTestSupport}),locateElement(t){const e=[s.gui];for(const i of GUI$1.NAMES){const n=Gui.create(i);n instanceof ToggledGui&&n.isShowing&&e.push(n)}for(const i of e){const n=i.layoutRectangles[t];if(!n)continue;const[o,r,l,a]=n,h=1;return[o*h,r*h,l*h,a*h]}}}}async function main(){const s=new LayeredViewport;gfxConfig.refreshConfig();const t=new Matchsticks(s);t.config.refreshConfig(),s.init(t,document.getElementById("midCanvas")),window.TestSupport=getTestSupport(t),t.init(),t.onResize();let e=performance.now();function i(){requestAnimationFrame(i);const n=performance.now(),o=Math.min(50,n-e);e=n,t.update(o)}i()}main();
